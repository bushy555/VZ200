; ===========================================================================
;  RUSH HOUR  -  sliding block puzzle for the VZ200 / Laser 200 / Laser 210
;  Z80 machine code, MODE(1) graphics (128 x 64, 4 colours)
;
;  Needs the 16K RAM expansion (code lives at $8000).
;  40 puzzles in 5 difficulty tiers (8 puzzles each, hardest last).
;
;  KEYS     Q = up   A = down   O = left   P = right   (moves selected car)
;           SPACE = next car    Z = previous car
;           M = restart level   N = back to menu
;           On the menu: 1..5 = choose starting difficulty, X = exit to BASIC,
;           SPACE = define your own keys (every key can be re-assigned)
;
;  GOAL     the RED car starts at the bottom: slide it UP and out through the
;           gap in the top wall.
;           A "move" is sliding one car any distance in one direction.
;           The selected car is drawn striped.
; ===========================================================================

        ORG     $8000

VRAM    EQU     $7000           ; MODE(1) screen, 32 bytes per row, 4 px/byte
LATCH   EQU     $6800           ; output latch (mode, colour set, speaker)
KEYBD   EQU     $6800           ; keyboard matrix (read)
SHADOW  EQU     $783B           ; ROM copy of the latch
MAXLEV  EQU     40

; ---- variables (outside the program image) --------------------------------
VARS    EQU     $9000
CARS    EQU     VARS            ; 16 cars x (x,y,len,dir)
GRID    EQU     VARS+64         ; 6x6 occupancy map
NCARS   EQU     VARS+100
SEL     EQU     VARS+101
LEVEL   EQU     VARS+102
MOVES   EQU     VARS+103        ; word
LASTCAR EQU     VARS+105
LASTDIR EQU     VARS+106
AXIS    EQU     VARS+107
NEG     EQU     VARS+108
KEYV    EQU     VARS+109
DMODE   EQU     VARS+110
DCOL    EQU     VARS+111
TCOL    EQU     VARS+112
BGCNT   EQU     VARS+113
BGID    EQU     VARS+114
NUMBUF  EQU     VARS+115        ; 4 bytes
SAVESP  EQU     VARS+120        ; word
DEFFLAG EQU     VARS+122        ; 1 = user defined keys
DEFIDX  EQU     VARS+123
BCNT    EQU     VARS+124
KEYRAM  EQU     VARS+128        ; working key table (copied from KEYDEF)

; ---- key codes -------------------------------------------------------------
K_UP    EQU     1
K_DOWN  EQU     2
K_LEFT  EQU     3
K_RIGHT EQU     4
K_NEXT  EQU     5
K_PREV  EQU     6
K_RESTART EQU   7
K_TITLE EQU     8
K_EXIT  EQU     9
K_DEF   EQU     10
K_1     EQU     11

; ===========================================================================
START:  DI                      ; keep the ROM's 50Hz interrupt (keyboard/cursor
                                ; handling) away from the graphics screen
        LD      (SAVESP),SP
        LD      A,$08           ; graphics on, colour set 0
        LD      (SHADOW),A      ; (green, yellow, blue, red)
        LD      (LATCH),A
        LD      HL,KEYDEF
        LD      DE,KEYRAM
        LD      BC,KEYEND-KEYDEF
        LDIR
        XOR     A
        LD      (DEFFLAG),A
        CALL    SPLASH          ; box-art screen, first start only

; ---- title / difficulty menu ------------------------------------------------
TITLE:  CALL    CLS
        CALL    WAITREL
        LD      A,$FF
        LD      (TCOL),A
        LD      HL,VRAM+1*32+11
        LD      DE,S_TITLE
        CALL    PRTSTR
        LD      A,$AA
        LD      (TCOL),A
        LD      A,(DEFFLAG)
        OR      A
        JR      NZ,TLC
        LD      HL,VRAM+8*32+8
        LD      DE,S_H1
        CALL    PRTSTR
        LD      HL,VRAM+14*32+8
        LD      DE,S_H2
        CALL    PRTSTR
        LD      HL,VRAM+20*32+8
        LD      DE,S_H3
        CALL    PRTSTR
        JR      TLD
TLC:    LD      HL,VRAM+14*32+6
        LD      DE,S_CUST
        CALL    PRTSTR
TLD:    LD      HL,VRAM+26*32+5
        LD      DE,S_H4
        CALL    PRTSTR
        LD      A,$55
        LD      (TCOL),A
        LD      HL,VRAM+34*32+10
        LD      DE,S_M1
        CALL    PRTSTR
        LD      HL,VRAM+40*32+10
        LD      DE,S_M2
        CALL    PRTSTR
        LD      HL,VRAM+46*32+10
        LD      DE,S_M3
        CALL    PRTSTR
        LD      HL,VRAM+52*32+10
        LD      DE,S_M4
        CALL    PRTSTR
        LD      HL,VRAM+58*32+10
        LD      DE,S_M5
        CALL    PRTSTR
TL1:    CALL    SCAN
        OR      A
        JR      Z,TL1
        CP      K_EXIT
        JP      Z,EXIT
        CP      K_NEXT
        JP      Z,DEFKEYS
        CP      K_DEF
        JP      Z,DEFKEYS
        SUB     K_1
        JR      C,TL1
        CP      5
        JR      NC,TL1
        ADD     A,A
        ADD     A,A
        ADD     A,A
        INC     A               ; level = tier*8 + 1
        LD      (LEVEL),A
        CALL    WAITREL

; ---- start a level ---------------------------------------------------------
NEWLEVEL:
        CALL    CLS
        CALL    DRAWFRAME
        LD      A,(LEVEL)
        CALL    LOADLV
        XOR     A
        LD      (SEL),A
        LD      (MOVES),A
        LD      (MOVES+1),A
        DEC     A
        LD      (LASTCAR),A
        CALL    PANEL
        CALL    DRAWALL
        XOR     A
        LD      B,2
        CALL    DRAWCAR

; ---- main loop --------------------------------------------------------------
GAME:   CALL    SCAN
        OR      A
        JR      Z,GAME
        CP      K_NEXT
        JR      Z,DONEXT
        CP      K_PREV
        JR      Z,DOPREV
        CP      K_RESTART
        JR      Z,DORST
        CP      K_TITLE
        JP      Z,TITLE
        CP      5
        JR      NC,GAME
        CALL    TRYMOVE
        LD      A,(CARS+1)      ; red car in row 0 = at the exit
        OR      A
        JP      Z,WIN
        LD      C,140
        CALL    DELAY           ; key-repeat delay
        JR      GAME

DONEXT: LD      A,(SEL)
        LD      B,1
        CALL    DRAWCAR
        LD      A,(SEL)
        INC     A
        LD      B,A
        LD      A,(NCARS)
        CP      B
        LD      A,B
        JR      NZ,DN1
        XOR     A
DN1:    LD      (SEL),A
        LD      B,2
        CALL    DRAWCAR
        CALL    WAITREL
        JR      GAME

DOPREV: LD      A,(SEL)
        LD      B,1
        CALL    DRAWCAR
        LD      A,(SEL)
        OR      A
        JR      NZ,DP1
        LD      A,(NCARS)
DP1:    DEC     A
        LD      (SEL),A
        LD      B,2
        CALL    DRAWCAR
        CALL    WAITREL
        JR      GAME

DORST:  CALL    WAITREL
        JP      NEWLEVEL

; ---- level solved ----------------------------------------------------------
WIN:    XOR     A
        LD      B,1
        CALL    DRAWCAR
        LD      HL,JINGLE
        CALL    PLAYJ
        LD      A,$FF
        LD      (TCOL),A
        LD      HL,VRAM+50*32+21
        LD      DE,S_SOLVED
        CALL    PRTSTR
        LD      DE,S_SPACE
        LD      A,(DEFFLAG)
        OR      A
        JR      Z,WN1
        LD      DE,S_SPACE2
WN1:    LD      HL,VRAM+56*32+21
        CALL    PRTSTR
        CALL    WAITSPC
        LD      A,(LEVEL)
        INC     A
        CP      MAXLEV+1
        JR      NC,ALLDONE
        LD      (LEVEL),A
        JP      NEWLEVEL

ALLDONE:
        CALL    CLS
        LD      A,$FF
        LD      (TCOL),A
        LD      HL,VRAM+22*32+11
        LD      DE,S_ALL
        CALL    PRTSTR
        LD      A,$55
        LD      (TCOL),A
        LD      HL,VRAM+30*32+8
        LD      DE,S_CONG
        CALL    PRTSTR
        LD      HL,JINGLE
        CALL    PLAYJ
        LD      HL,JINGLE
        CALL    PLAYJ
        CALL    WAITSPC
        JP      TITLE

; ---- start-up screen (shown once): the board from the final level, big title ----
SPLASH: CALL    CLS
        CALL    DRAWFRAME
        LD      A,MAXLEV
        CALL    LOADLV          ; the most crowded puzzle makes the "box art"
        CALL    DRAWALL
        LD      A,$FF
        LD      (TCOL),A
        LD      HL,VRAM+4*32+22
        LD      DE,S_RUSH
        CALL    BIGSTR
        LD      A,$55
        LD      (TCOL),A
        LD      HL,VRAM+17*32+22
        LD      DE,S_HOUR
        CALL    BIGSTR
        LD      A,$AA
        LD      (TCOL),A
        LD      HL,VRAM+40*32+21
        LD      DE,S_MADE
        CALL    PRTSTR
        LD      A,$55
        LD      (TCOL),A
        LD      HL,VRAM+47*32+21
        LD      DE,S_CLAUDE
        CALL    PRTSTR
        LD      HL,JINGLE
        CALL    PLAYJ
        CALL    WAITREL
        LD      DE,230          ; about 3.5 seconds, any key skips
SP1:    LD      C,16
        CALL    DELAY           ; ~15 ms slices so a short key tap is seen
        LD      A,(KEYBD)
        OR      $C0
        CP      $FF
        JR      NZ,SP2
        DEC     DE
        LD      A,D
        OR      E
        JR      NZ,SP1
SP2:    RET

; ---- define keys: every entry of KEYRAM can be re-assigned --------------------
DEFKEYS:
        LD      A,1
        LD      (DEFFLAG),A
        XOR     A
        LD      (DEFIDX),A
DK1:    CALL    CLS
        LD      A,$FF
        LD      (TCOL),A
        LD      HL,VRAM+6*32+10
        LD      DE,S_DEFT
        CALL    PRTSTR
        LD      A,$55
        LD      (TCOL),A
        LD      HL,VRAM+24*32+9
        LD      DE,S_PRESS
        CALL    PRTSTR
        LD      A,(DEFIDX)
        ADD     A,A
        LD      E,A
        LD      D,0
        LD      HL,DEFNAMES
        ADD     HL,DE
        LD      E,(HL)
        INC     HL
        LD      D,(HL)
        LD      A,$FF
        LD      (TCOL),A
        LD      HL,VRAM+32*32+11
        CALL    PRTSTR
        CALL    WAITREL
        CALL    GETKEY          ; C = row byte, B = mask
        LD      A,(DEFIDX)
        LD      E,A
        ADD     A,A
        ADD     A,E
        LD      E,A
        LD      D,0
        LD      HL,KEYRAM
        ADD     HL,DE
        LD      (HL),C
        INC     HL
        LD      (HL),B
        LD      D,60
        LD      E,12
        CALL    BEEP
        LD      A,(DEFIDX)
        INC     A
        LD      (DEFIDX),A
        CP      14
        JR      NZ,DK1
        JP      TITLE

; wait for any key, return its matrix position: C = row address byte, B = mask
GETKEY: LD      C,$FE
        LD      D,8
GK1:    LD      B,$68
        LD      A,(BC)
        OR      $C0
        CP      $FF
        JR      NZ,GK2
        LD      A,C
        RLCA
        LD      C,A
        DEC     D
        JR      NZ,GK1
        JR      GETKEY
GK2:    CPL
        AND     $3F
        LD      E,A
        CPL
        INC     A
        AND     E               ; lowest pressed bit only
        LD      B,A
        RET

; ---- leave to BASIC ---------------------------------------------------------
EXIT:   LD      SP,(SAVESP)
        XOR     A
        LD      (SHADOW),A
        LD      (LATCH),A
        LD      HL,VRAM
        LD      DE,VRAM+1
        LD      BC,511
        LD      (HL),$20
        LDIR
        LD      HL,0
        EI
        RET

; ===========================================================================
;  Move the selected car one cell.  A = key code 1..4
; ===========================================================================
TRYMOVE:
        LD      (KEYV),A
        CP      3
        LD      A,1
        JR      C,TM1           ; Q/A -> vertical axis
        XOR     A               ; O/P -> horizontal axis
TM1:    LD      (AXIS),A
        LD      A,(KEYV)
        AND     1
        LD      (NEG),A         ; odd keys (Q,O) = negative step
        CALL    GETSEL
        INC     HL
        INC     HL
        INC     HL
        LD      A,(AXIS)
        CP      (HL)            ; car's orientation must match the key
        RET     NZ
        CALL    BUILDGRID
        CALL    GETSEL
        LD      D,(HL)          ; x
        INC     HL
        LD      E,(HL)          ; y
        INC     HL
        LD      C,(HL)          ; length
        LD      A,(AXIS)
        OR      A
        JR      NZ,TMV
        LD      A,(NEG)         ; horizontal: target column
        OR      A
        JR      Z,TMH1
        LD      A,D
        DEC     A
        JR      TMH2
TMH1:   LD      A,D
        ADD     A,C
TMH2:   LD      D,A
        JR      TMCHK
TMV:    LD      A,(NEG)         ; vertical: target row
        OR      A
        JR      Z,TMV1
        LD      A,E
        DEC     A
        JR      TMV2
TMV1:   LD      A,E
        ADD     A,C
TMV2:   LD      E,A
TMCHK:  LD      A,D
        CP      6
        JR      NC,BLOCK
        LD      A,E
        CP      6
        JR      NC,BLOCK
        LD      A,E
        ADD     A,A
        LD      B,A
        ADD     A,A
        ADD     A,B
        ADD     A,D
        LD      E,A
        LD      D,0
        LD      HL,GRID
        ADD     HL,DE
        LD      A,(HL)
        OR      A
        JR      NZ,BLOCK        ; cell occupied
        LD      A,(SEL)         ; --- perform the move
        LD      B,0
        CALL    DRAWCAR         ; erase
        CALL    GETSEL
        LD      A,(AXIS)
        OR      A
        JR      Z,TX
        INC     HL
TX:     LD      A,(NEG)
        OR      A
        LD      A,(HL)
        JR      Z,TP
        DEC     A
        JR      TW
TP:     INC     A
TW:     LD      (HL),A
        LD      A,(SEL)
        LD      B,2
        CALL    DRAWCAR         ; redraw selected
        LD      A,(SEL)         ; count a move unless it continues the
        LD      B,A             ; previous slide of the same car
        LD      A,(LASTCAR)
        CP      B
        JR      NZ,TMC
        LD      A,(LASTDIR)
        LD      B,A
        LD      A,(NEG)
        CP      B
        JR      Z,TMN
TMC:    LD      HL,(MOVES)
        INC     HL
        LD      (MOVES),HL
        LD      A,(SEL)
        LD      (LASTCAR),A
        LD      A,(NEG)
        LD      (LASTDIR),A
        CALL    SHOWMOVES
TMN:    LD      D,20
        LD      E,6
        JP      BEEP
BLOCK:  LD      D,200           ; low buzz = blocked
        LD      E,10
        JP      BEEP

GETSEL: LD      A,(SEL)
        ADD     A,A
        ADD     A,A
        LD      E,A
        LD      D,0
        LD      HL,CARS
        ADD     HL,DE
        RET

; ---- build 6x6 occupancy grid (0 = free, else car index+1) -----------------
BUILDGRID:
        LD      HL,GRID
        LD      B,36
        XOR     A
BG0:    LD      (HL),A
        INC     HL
        DJNZ    BG0
        LD      A,(NCARS)
        LD      (BGCNT),A
        LD      A,1
        LD      (BGID),A
        LD      HL,CARS
BG1:    LD      D,(HL)          ; x
        INC     HL
        LD      E,(HL)          ; y
        INC     HL
        LD      B,(HL)          ; length
        INC     HL
        LD      A,(HL)          ; direction
        INC     HL
        PUSH    HL
        LD      C,1             ; step 1 (horizontal) or 6 (vertical)
        OR      A
        JR      Z,BG2
        LD      C,6
BG2:    LD      A,E
        ADD     A,A
        LD      E,A
        ADD     A,A
        ADD     A,E
        ADD     A,D             ; y*6+x
        LD      E,A
        LD      D,0
        LD      HL,GRID
        ADD     HL,DE
        LD      A,(BGID)
        LD      D,0
        LD      E,C
BG3:    LD      (HL),A
        ADD     HL,DE
        DJNZ    BG3
        LD      A,(BGID)
        INC     A
        LD      (BGID),A
        POP     HL
        LD      A,(BGCNT)
        DEC     A
        LD      (BGCNT),A
        JR      NZ,BG1
        RET

; ---- load level A (1..MAXLEV) into CARS -------------------------------------
LOADLV: DEC     A
        LD      L,A
        LD      H,0
        LD      E,A
        LD      D,0
        ADD     HL,HL
        ADD     HL,HL
        ADD     HL,HL
        ADD     HL,HL           ; *16
        OR      A
        SBC     HL,DE           ; *15
        LD      DE,LEVELS
        ADD     HL,DE
        LD      A,(HL)
        LD      (NCARS),A
        LD      B,A
        INC     HL
        LD      DE,CARS
LL1:    LD      A,(HL)
        INC     HL
        PUSH    HL
        LD      C,A             ; packed: d l ccc rrr
        RRCA
        RRCA
        RRCA
        AND     7
        LD      (DE),A          ; x
        INC     DE
        LD      A,C
        AND     7
        LD      (DE),A          ; y
        INC     DE
        LD      A,C
        RLCA
        RLCA
        AND     1
        ADD     A,2
        LD      (DE),A          ; len 2/3
        INC     DE
        LD      A,C
        RLCA
        AND     1
        LD      (DE),A          ; dir
        INC     DE
        POP     HL
        DJNZ    LL1
        RET

; ===========================================================================
;  Graphics
; ===========================================================================
CLS:    LD      HL,VRAM
        LD      DE,VRAM+1
        LD      BC,2047
        LD      (HL),0
        LDIR
        RET

DRAWFRAME:
        LD      A,$AA
        LD      HL,VRAM+5*32            ; top wall, gap over column 2
        LD      B,7
        CALL    HLINE
        LD      HL,VRAM+5*32+10
        LD      B,10
        CALL    HLINE
        LD      HL,VRAM+6*32
        LD      B,7
        CALL    HLINE
        LD      HL,VRAM+6*32+10
        LD      B,10
        CALL    HLINE
        LD      HL,VRAM+61*32           ; bottom wall
        LD      B,20
        CALL    HLINE
        LD      HL,VRAM+62*32
        LD      B,20
        CALL    HLINE
        LD      HL,VRAM+7*32            ; left and right walls
        LD      B,54
        CALL    VLINE
        LD      HL,VRAM+7*32+19
        LD      B,54
        CALL    VLINE
        LD      HL,ARROW                ; red arrow above the exit gap
        LD      DE,VRAM+7
        LD      B,5
AR1:    LD      A,(HL)
        LD      (DE),A
        INC     HL
        INC     DE
        LD      A,(HL)
        LD      (DE),A
        INC     HL
        INC     DE
        LD      A,(HL)
        LD      (DE),A
        INC     HL
        LD      A,E
        ADD     A,30
        LD      E,A
        JR      NC,AR2
        INC     D
AR2:    DJNZ    AR1
        RET

HLINE:  LD      (HL),A
        INC     HL
        DJNZ    HLINE
        RET

VLINE:  LD      DE,32
VL1:    LD      (HL),A
        ADD     HL,DE
        DJNZ    VL1
        RET

DRAWALL:
        XOR     A
DA1:    PUSH    AF
        LD      B,1
        CALL    DRAWCAR
        POP     AF
        INC     A
        LD      B,A
        LD      A,(NCARS)
        CP      B
        LD      A,B
        JR      NZ,DA1
        RET

; ---- draw car A in mode B (0 erase, 1 normal, 2 selected/striped) -----------
DRAWCAR:
        LD      C,A
        LD      A,B
        LD      (DMODE),A
        LD      A,C
        OR      A
        LD      B,$FF           ; car 0 = red
        JR      Z,DC1
        AND     1
        LD      B,$55           ; odd = yellow
        JR      NZ,DC1
        LD      B,$AA           ; even = blue
DC1:    LD      A,(DMODE)
        OR      A
        JR      NZ,DC2
        LD      B,0
DC2:    LD      A,B
        LD      (DCOL),A
        LD      A,C
        ADD     A,A
        ADD     A,A
        LD      E,A
        LD      D,0
        LD      HL,CARS
        ADD     HL,DE
        LD      C,(HL)          ; x
        INC     HL
        LD      B,(HL)          ; y
        INC     HL
        LD      D,(HL)          ; len
        INC     HL
        LD      E,(HL)          ; dir
        PUSH    DE
        LD      A,B
        ADD     A,A
        LD      L,A
        LD      H,0
        LD      DE,ROWTAB
        ADD     HL,DE
        LD      A,(HL)
        INC     HL
        LD      H,(HL)
        LD      L,A             ; HL = screen address of the cell row
        LD      A,C
        ADD     A,A
        ADD     A,C             ; 3*x bytes
        LD      E,A
        LD      D,0
        ADD     HL,DE
        POP     DE              ; D=len E=dir
        LD      A,D
        ADD     A,A
        ADD     A,D
        LD      C,A             ; C = 3*len
        LD      A,D
        ADD     A,A
        ADD     A,A
        ADD     A,A
        ADD     A,D
        LD      B,A             ; B = 9*len
        LD      A,E
        OR      A
        JR      NZ,DCV
        LD      D,C             ; horizontal: width 3*len, height 9
        LD      E,9
        JR      DCGO
DCV:    LD      D,3             ; vertical: width 3, height 9*len
        LD      E,B
DCGO:   LD      B,0
DCLOOP: LD      A,(DCOL)
        LD      C,A
        LD      A,B
        OR      A
        JR      Z,DCB           ; first row blank (gap)
        INC     A
        CP      E
        JR      Z,DCB           ; last row blank (gap)
        LD      A,(DMODE)
        CP      2
        JR      NZ,DCR
        LD      A,B
        AND     1
        JR      Z,DCR
DCB:    LD      C,0
DCR:    CALL    DRAWROW
        LD      A,L
        ADD     A,32
        LD      L,A
        JR      NC,DCN
        INC     H
DCN:    INC     B
        LD      A,B
        CP      E
        JR      NZ,DCLOOP
        RET

; one pixel row of a car: HL=addr D=width(>=3) C=colour byte
DRAWROW:
        PUSH    HL
        PUSH    DE
        LD      A,C
        AND     $3F             ; left pixel = background
        LD      (HL),A
        INC     HL
        DEC     D
        DEC     D
DR1:    LD      (HL),C
        INC     HL
        DEC     D
        JR      NZ,DR1
        LD      A,C
        AND     $FC             ; right pixel = background
        LD      (HL),A
        POP     DE
        POP     HL
        RET

; ---- 3x5 text ---------------------------------------------------------------
; HL = screen address, DE = zero-terminated string, colour pattern in TCOL
PRTSTR: LD      A,(DE)
        OR      A
        RET     Z
        INC     DE
        PUSH    DE
        PUSH    HL
        CALL    GLYPH
        POP     HL
        POP     DE
        INC     HL
        JR      PRTSTR

; A = character -> HL = address of its glyph in FONT
GLPTR:  CP      ' '
        JR      NZ,GP1
        XOR     A
        JR      GP3
GP1:    CP      'A'
        JR      C,GP2
        SUB     54
        JR      GP3
GP2:    SUB     47
GP3:    LD      E,A
        ADD     A,A
        ADD     A,A
        ADD     A,E
        LD      E,A
        LD      D,0
        LD      HL,FONT
        ADD     HL,DE
        RET

GLYPH:  PUSH    HL
        CALL    GLPTR
        POP     DE
; HL = glyph data (5 bytes), DE = screen address
DRAWGL: LD      A,(TCOL)
        LD      C,A
        LD      B,5
DG1:    LD      A,(HL)
        AND     C
        LD      (DE),A
        INC     HL
        LD      A,E
        ADD     A,32
        LD      E,A
        JR      NC,DG2
        INC     D
DG2:    DJNZ    DG1
        RET

; double-size text (each font pixel = 2x2 screen pixels, 2 bytes per letter)
BIGSTR: LD      A,(DE)
        OR      A
        RET     Z
        INC     DE
        PUSH    DE
        PUSH    HL
        CALL    BIGGL
        POP     HL
        POP     DE
        INC     HL
        INC     HL
        JR      BIGSTR

BIGGL:  PUSH    HL
        CALL    GLPTR
        POP     DE              ; DE = screen address
        LD      A,(TCOL)
        LD      C,A
        LD      A,5
        LD      (BCNT),A
BG_1:   LD      A,(HL)          ; one glyph row (pixels as $C0/$30/$0C)
        INC     HL
        PUSH    HL
        LD      H,A
        LD      L,0
        AND     $C0
        JR      Z,BA
        LD      L,$F0
BA:     LD      A,H
        AND     $30
        JR      Z,BB
        LD      A,L
        OR      $0F
        LD      L,A
BB:     LD      A,H
        AND     $0C
        LD      H,0
        JR      Z,BC
        LD      H,$F0
BC:     LD      A,L
        AND     C
        LD      L,A
        LD      A,H
        AND     C
        LD      H,A
        EX      DE,HL           ; HL = screen, D = right byte, E = left byte
        CALL    PUTP
        CALL    PUTP
        EX      DE,HL
        POP     HL
        LD      A,(BCNT)
        DEC     A
        LD      (BCNT),A
        JR      NZ,BG_1
        RET

PUTP:   LD      (HL),E
        INC     HL
        LD      (HL),D
        LD      A,L
        ADD     A,31
        LD      L,A
        RET     NC
        INC     H
        RET

; HL = value 0..999, DE = screen address; prints 3 digits, leading zeros blank
PRTNUM: PUSH    DE
        LD      DE,100
        CALL    DIGIT
        LD      A,B
        LD      (NUMBUF),A
        LD      DE,10
        CALL    DIGIT
        LD      A,B
        LD      (NUMBUF+1),A
        LD      A,L
        ADD     A,'0'
        LD      (NUMBUF+2),A
        XOR     A
        LD      (NUMBUF+3),A
        LD      A,(NUMBUF)
        CP      '0'
        JR      NZ,PN9
        LD      A,' '
        LD      (NUMBUF),A
        LD      A,(NUMBUF+1)
        CP      '0'
        JR      NZ,PN9
        LD      A,' '
        LD      (NUMBUF+1),A
PN9:    POP     HL
        LD      DE,NUMBUF
        JP      PRTSTR

DIGIT:  LD      B,'0'
DG3:    OR      A
        SBC     HL,DE
        JR      C,DG4
        INC     B
        JR      DG3
DG4:    ADD     HL,DE
        RET

SHOWMOVES:
        LD      A,$55
        LD      (TCOL),A
        LD      HL,(MOVES)
        LD      DE,VRAM+40*32+21
        JP      PRTNUM

SHOWLEVEL:
        LD      A,$55
        LD      (TCOL),A
        LD      A,(LEVEL)
        LD      L,A
        LD      H,0
        LD      DE,VRAM+16*32+21
        JP      PRTNUM

; ---- side panel -------------------------------------------------------------
PANEL:  LD      A,$FF
        LD      (TCOL),A
        LD      A,(LEVEL)
        DEC     A
        LD      B,0
PN1:    CP      8
        JR      C,PN2
        SUB     8
        INC     B
        JR      PN1
PN2:    LD      A,B
        ADD     A,A
        LD      E,A
        LD      D,0
        LD      HL,TIERPTR
        ADD     HL,DE
        LD      E,(HL)
        INC     HL
        LD      D,(HL)
        LD      HL,VRAM+3*32+21
        CALL    PRTSTR
        LD      A,$55
        LD      (TCOL),A
        LD      HL,VRAM+10*32+21
        LD      DE,S_LEVEL
        CALL    PRTSTR
        LD      HL,VRAM+34*32+21
        LD      DE,S_MOVES
        CALL    PRTSTR
        CALL    SHOWLEVEL
        CALL    SHOWMOVES
        LD      A,$AA
        LD      (TCOL),A
        LD      DE,S_RST
        LD      A,(DEFFLAG)
        OR      A
        JR      Z,PX1
        LD      DE,S_RST2
PX1:    LD      HL,VRAM+50*32+21
        CALL    PRTSTR
        LD      DE,S_MENU
        LD      A,(DEFFLAG)
        OR      A
        JR      Z,PX2
        LD      DE,S_MENU2
PX2:    LD      HL,VRAM+56*32+21
        JP      PRTSTR

; ===========================================================================
;  Keyboard and sound
; ===========================================================================
; returns A = key code (0 = none)
SCAN:   LD      HL,KEYRAM
SC1:    LD      C,(HL)
        INC     HL
        LD      A,C
        OR      A
        RET     Z
        LD      B,$68
        LD      A,(BC)
        AND     (HL)            ; zero when the key is down
        INC     HL
        LD      C,(HL)
        INC     HL
        JR      NZ,SC1
        LD      A,C
        RET

WAITREL:
        LD      A,(KEYBD)
        OR      $C0
        CP      $FF
        JR      NZ,WAITREL
        LD      C,12
        JP      DELAY

WAITSPC:
        CALL    WAITREL
WS1:    CALL    SCAN
        CP      K_NEXT
        JR      NZ,WS1
        JP      WAITREL

DELAY:  LD      B,0
DL1:    DJNZ    DL1
        DEC     C
        JR      NZ,DELAY
        RET

; D = delay, E = number of 4-step cycles
BEEP:   LD      HL,SNDTAB
        LD      C,4
BP1:    LD      A,(HL)
        INC     HL
        LD      (LATCH),A
        LD      B,D
BP2:    DJNZ    BP2
        DEC     C
        JR      NZ,BP1
        DEC     E
        JR      NZ,BEEP
        LD      A,$08
        LD      (LATCH),A
        RET

PLAYJ:  LD      D,(HL)
        LD      A,D
        OR      A
        RET     Z
        INC     HL
        LD      E,(HL)
        INC     HL
        PUSH    HL
        CALL    BEEP
        POP     HL
        JR      PLAYJ

SNDTAB: DB      $09,$29,$28,$08
JINGLE: DB      90,60,70,70,55,90,40,140,0

;  default keys: row address byte, mask, code.  Matrix rows are selected by
;  address lines A0-A7; within a row the LEFT-most key listed in the technical
;  docs is bit 5 and the right-most bit 0.
KEYDEF: DB      $FE,$10,K_UP        ; Q
        DB      $FD,$10,K_DOWN      ; A
        DB      $BF,$02,K_LEFT      ; O
        DB      $BF,$10,K_RIGHT     ; P
        DB      $EF,$10,K_NEXT      ; SPACE
        DB      $FB,$10,K_PREV      ; Z
        DB      $EF,$20,K_RESTART   ; M
        DB      $EF,$01,K_TITLE     ; N
        DB      $F7,$10,K_1         ; 1
        DB      $F7,$02,K_1+1       ; 2
        DB      $F7,$08,K_1+2       ; 3
        DB      $F7,$20,K_1+3       ; 4
        DB      $F7,$01,K_1+4       ; 5
        DB      $FB,$02,K_EXIT      ; X
        DB      $EF,$10,K_DEF       ; SPACE (always opens "define keys" on the menu)
        DB      $EF,$02,K_DEF       ; (same key if the matrix is ordered the other way)
        DB      0
KEYEND:

; ===========================================================================
;  Data
; ===========================================================================
ROWTAB: DW      VRAM+7*32+1,VRAM+7*32+1+288,VRAM+7*32+1+576
        DW      VRAM+7*32+1+864,VRAM+7*32+1+1152,VRAM+7*32+1+1440

TIERPTR: DW     T0,T1,T2,T3,T4
T0:     DB      "BEGINNER",0
T1:     DB      "EASY",0
T2:     DB      "MEDIUM",0
T3:     DB      "HARD",0
T4:     DB      "EXPERT",0

S_TITLE: DB     "RUSH HOUR",0
S_H1:   DB      "Q A O P MOVE CAR",0
S_H2:   DB      "SPACE Z PICK CAR",0
S_H3:   DB      "M RESTART N MENU",0
S_H4:   DB      "X EXIT SPACE SETS KEYS",0
S_CUST: DB      "USING YOUR OWN KEYS",0
S_DEFT: DB      "DEFINE KEYS",0
S_PRESS: DB     "PRESS KEY FOR",0
N_UP:   DB      "UP",0
N_DOWN: DB      "DOWN",0
N_LEFT: DB      "LEFT",0
N_RIGHT: DB     "RIGHT",0
N_NEXT: DB      "NEXT CAR",0
N_PREV: DB      "PREV CAR",0
N_RST:  DB      "RESTART",0
N_MENU: DB      "MENU",0
N_EXIT: DB      "EXIT",0
DEFNAMES: DW    N_UP,N_DOWN,N_LEFT,N_RIGHT,N_NEXT,N_PREV,N_RST,N_MENU
        DW      T0,T1,T2,T3,T4,N_EXIT
S_M1:   DB      "1 BEGINNER",0
S_M2:   DB      "2 EASY",0
S_M3:   DB      "3 MEDIUM",0
S_M4:   DB      "4 HARD",0
S_M5:   DB      "5 EXPERT",0
S_LEVEL: DB     "LEVEL",0
S_MOVES: DB     "MOVES",0
S_RST:  DB      "M RESTART",0
S_RST2: DB      "RESTART  ",0
S_MENU: DB      "N MENU   ",0
S_MENU2: DB     "MENU     ",0
S_SOLVED: DB    "SOLVED   ",0
S_SPACE: DB     "SPACE    ",0
S_SPACE2: DB    "NEXT KEY ",0
S_ALL:  DB      "ALL SOLVED",0
S_RUSH: DB      "RUSH",0
S_HOUR: DB      "HOUR",0
S_MADE: DB      "MADE WITH",0
S_CLAUDE: DB    "CLAUDE AI",0
S_CONG: DB      "YOU ARE A MASTER",0

FONT:   ; 3x5 glyphs, 5 bytes each, pixels stored as colour 3 (AND with TCOL)
        DB      $00,$00,$00,$00,$00   ; ' '
        DB      $FC,$CC,$CC,$CC,$FC   ; '0'
        DB      $30,$F0,$30,$30,$FC   ; '1'
        DB      $F0,$0C,$30,$C0,$FC   ; '2'
        DB      $F0,$0C,$30,$0C,$F0   ; '3'
        DB      $CC,$CC,$FC,$0C,$0C   ; '4'
        DB      $FC,$C0,$F0,$0C,$F0   ; '5'
        DB      $3C,$C0,$FC,$CC,$FC   ; '6'
        DB      $FC,$0C,$30,$30,$30   ; '7'
        DB      $FC,$CC,$FC,$CC,$FC   ; '8'
        DB      $FC,$CC,$FC,$0C,$F0   ; '9'
        DB      $30,$CC,$FC,$CC,$CC   ; 'A'
        DB      $F0,$CC,$F0,$CC,$F0   ; 'B'
        DB      $3C,$C0,$C0,$C0,$3C   ; 'C'
        DB      $F0,$CC,$CC,$CC,$F0   ; 'D'
        DB      $FC,$C0,$F0,$C0,$FC   ; 'E'
        DB      $FC,$C0,$F0,$C0,$C0   ; 'F'
        DB      $3C,$C0,$CC,$CC,$3C   ; 'G'
        DB      $CC,$CC,$FC,$CC,$CC   ; 'H'
        DB      $FC,$30,$30,$30,$FC   ; 'I'
        DB      $0C,$0C,$0C,$CC,$30   ; 'J'
        DB      $CC,$CC,$F0,$CC,$CC   ; 'K'
        DB      $C0,$C0,$C0,$C0,$FC   ; 'L'
        DB      $CC,$FC,$FC,$CC,$CC   ; 'M'
        DB      $F0,$CC,$CC,$CC,$CC   ; 'N'
        DB      $30,$CC,$CC,$CC,$30   ; 'O'
        DB      $F0,$CC,$F0,$C0,$C0   ; 'P'
        DB      $30,$CC,$CC,$F0,$3C   ; 'Q'
        DB      $F0,$CC,$F0,$CC,$CC   ; 'R'
        DB      $3C,$C0,$30,$0C,$F0   ; 'S'
        DB      $FC,$30,$30,$30,$30   ; 'T'
        DB      $CC,$CC,$CC,$CC,$FC   ; 'U'
        DB      $CC,$CC,$CC,$CC,$30   ; 'V'
        DB      $CC,$CC,$FC,$FC,$CC   ; 'W'
        DB      $CC,$CC,$30,$CC,$CC   ; 'X'
        DB      $CC,$CC,$30,$30,$30   ; 'Y'
        DB      $FC,$0C,$30,$C0,$FC   ; 'Z'
ARROW:  ; 12x5 pixel up-arrow (red), 3 bytes per row
        DB      $00,$3C,$00
        DB      $00,$FF,$00
        DB      $03,$FF,$C0
        DB      $0F,$FF,$F0
        DB      $3F,$FF,$FC

LEVELS: ; per level: car count, then up to 14 cars packed as  d l ccc rrr  (dir, len-2, col, row); car 0 = red (vertical, column 2)
        DB      $09,$94,$99,$5C,$0B,$08,$23,$C1,$89,$04,$00,$00,$00,$00,$00   ; level  1  (4 moves)
        DB      $0B,$94,$A2,$C0,$CA,$12,$9B,$11,$AB,$E8,$18,$83,$00,$00,$00   ; level  2  (4 moves)
        DB      $0C,$94,$98,$A9,$43,$88,$A2,$05,$80,$04,$9B,$AB,$02,$00,$00   ; level  3  (5 moves)
        DB      $0B,$94,$A4,$04,$51,$05,$A9,$9B,$08,$12,$03,$18,$00,$00,$00   ; level  4  (5 moves)
        DB      $0B,$94,$A2,$C0,$CB,$08,$9C,$11,$AB,$E8,$18,$83,$00,$00,$00   ; level  5  (5 moves)
        DB      $0C,$94,$58,$A9,$43,$89,$A1,$05,$80,$04,$9B,$AB,$12,$00,$00   ; level  6  (6 moves)
        DB      $0A,$94,$98,$5C,$0B,$08,$23,$C1,$89,$04,$20,$00,$00,$00,$00   ; level  7  (7 moves)
        DB      $0C,$94,$58,$A9,$43,$A3,$05,$80,$04,$9B,$AB,$12,$09,$00,$00   ; level  8  (7 moves)
        DB      $0B,$94,$99,$5C,$13,$00,$23,$C1,$89,$04,$20,$05,$00,$00,$00   ; level  9  (8 moves)
        DB      $0C,$94,$A3,$04,$49,$05,$A8,$9C,$AB,$0A,$0B,$08,$25,$00,$00   ; level 10  (9 moves)
        DB      $0A,$94,$A1,$11,$25,$0A,$53,$A9,$88,$AB,$8B,$00,$00,$00,$00   ; level 11  (9 moves)
        DB      $0B,$94,$99,$5C,$13,$00,$23,$C1,$C9,$04,$20,$05,$00,$00,$00   ; level 12  (10 moves)
        DB      $0C,$94,$04,$41,$05,$A8,$9C,$AB,$0A,$0B,$08,$25,$A0,$00,$00   ; level 13  (10 moves)
        DB      $0C,$94,$99,$5C,$13,$00,$23,$C1,$C9,$04,$10,$05,$25,$00,$00   ; level 14  (11 moves)
        DB      $0C,$94,$41,$05,$A8,$9C,$AB,$0A,$13,$08,$25,$A0,$22,$00,$00   ; level 15  (12 moves)
        DB      $0D,$94,$A8,$5C,$13,$00,$23,$C1,$C9,$04,$10,$05,$25,$1A,$00   ; level 16  (12 moves)
        DB      $0D,$94,$58,$A9,$43,$A3,$05,$80,$04,$9B,$AB,$12,$09,$1D,$00   ; level 17  (13 moves)
        DB      $0C,$94,$A8,$13,$00,$23,$C1,$CA,$10,$25,$22,$19,$05,$00,$00   ; level 18  (13 moves)
        DB      $0D,$94,$58,$A9,$43,$A3,$05,$80,$04,$9B,$AB,$0A,$09,$25,$00   ; level 19  (14 moves)
        DB      $0C,$94,$41,$05,$A8,$1C,$AB,$0A,$48,$82,$25,$A0,$22,$00,$00   ; level 20  (15 moves)
        DB      $0C,$94,$48,$A9,$43,$A3,$80,$04,$9C,$AB,$0A,$09,$25,$00,$00   ; level 21  (15 moves)
        DB      $0C,$94,$41,$05,$A8,$1C,$AB,$0A,$40,$83,$25,$A0,$22,$00,$00   ; level 22  (16 moves)
        DB      $0C,$94,$48,$A8,$43,$A2,$80,$04,$9C,$AA,$0A,$11,$25,$00,$00   ; level 23  (17 moves)
        DB      $0C,$94,$41,$05,$A8,$1C,$AB,$02,$40,$83,$25,$A0,$22,$00,$00   ; level 24  (17 moves)
        DB      $0C,$94,$48,$A8,$4B,$A2,$80,$04,$9C,$AA,$0A,$11,$25,$00,$00   ; level 25  (18 moves)
        DB      $0C,$94,$41,$05,$A8,$1C,$AB,$02,$40,$83,$25,$A0,$12,$00,$00   ; level 26  (18 moves)
        DB      $0C,$94,$48,$A8,$4B,$A2,$82,$04,$9C,$AA,$0A,$19,$25,$00,$00   ; level 27  (19 moves)
        DB      $0C,$94,$41,$A8,$24,$AA,$02,$40,$84,$5D,$A1,$12,$1B,$00,$00   ; level 28  (20 moves)
        DB      $0C,$94,$40,$A8,$4B,$A0,$82,$04,$9C,$AA,$12,$01,$25,$00,$00   ; level 29  (20 moves)
        DB      $0D,$94,$21,$53,$EB,$03,$20,$12,$81,$22,$10,$11,$04,$05,$00   ; level 30  (21 moves)
        DB      $0C,$94,$AA,$02,$4B,$9C,$05,$48,$19,$80,$25,$A8,$1A,$00,$00   ; level 31  (21 moves)
        DB      $0C,$94,$9C,$C0,$22,$CA,$13,$99,$05,$E3,$EB,$48,$09,$00,$00   ; level 32  (22 moves)
        DB      $0C,$94,$50,$A8,$4B,$E2,$81,$04,$9C,$AB,$0A,$19,$25,$00,$00   ; level 33  (23 moves)
        DB      $0D,$94,$41,$A8,$24,$AA,$02,$40,$84,$98,$A1,$12,$1B,$1D,$00   ; level 34  (23 moves)
        DB      $0D,$94,$AA,$02,$4B,$9C,$05,$50,$19,$80,$25,$A8,$1A,$04,$00   ; level 35  (24 moves)
        DB      $0D,$94,$41,$A8,$24,$AA,$02,$40,$84,$98,$A1,$12,$13,$5D,$00   ; level 36  (25 moves)
        DB      $0D,$94,$AA,$0A,$4B,$9C,$05,$50,$19,$80,$25,$A8,$1A,$04,$00   ; level 37  (25 moves)
        DB      $0C,$94,$D8,$A0,$9B,$C3,$E9,$E2,$AC,$40,$8C,$1D,$0B,$00,$00   ; level 38  (26 moves)
        DB      $0D,$94,$AA,$0A,$53,$9C,$05,$48,$19,$81,$25,$A8,$1A,$04,$00   ; level 39  (26 moves)
        DB      $0D,$94,$AA,$0A,$53,$9C,$05,$40,$11,$81,$25,$A8,$1A,$04,$00   ; level 40  (27 moves)
PROGEND:
