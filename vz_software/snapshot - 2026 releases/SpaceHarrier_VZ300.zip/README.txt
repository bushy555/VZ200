SPACE HARRIER  -  Dick Smith VZ300 conversion
=============================================
Converted from Kazuhiro Furuhata's 1988 Sharp MZ-700 version
(Space Harrier (C) SEGA 1985).

FILE
  SHARRIER.VZ   machine-code .VZ file (type $F1), loads at $7B00 and
                unpacks itself into the expansion RAM (about 1 second).

REQUIREMENTS
  VZ300 with the BennVenn SD loader and its 128K RAM expansion.
  The game uses the BennVenn RAM banks (ports $37/$3A) and the DOS
  window at $4000-$67FF once loaded.

CONTROLS
  Q / A        up / down
  M / ,        left / right
  SPACE or .   fire
  Joystick 1   move and fire (either button)
  Joystick 2   also works - both are read at once, so either player
               can play.  With no joystick interface plugged in the
               game simply uses the keyboard.
  P            pause (any key resumes)
  CTRL + -     break back to the title screen
  1 - 5        MZ-700 F1-F5 options (hold while the game starts)

NOTES
  * 7 lives per game.
  * Screen: 64x32 mode(0) semigraphics with a text status line
    (HI score, score, stage, lives) in the buff / dark red scheme.
  * Title screen redrawn for the VZ, with the theme tune, blinking
    mammoth, flashing robot eyes, waving Harrier and glinting title.
  * Sound effects on the VZ beeper: shots, explosions, hits and the
    falling "Ahhhh".

source/  the assembly listings and include files used for this build
         (assemble main.asm with sjasmplus; boot.asm packs the parts).
screenshots/  title and gameplay screens captured from an emulator.
