; ===========================================================================
; VZ300 Space Harrier - extras: title screen, title music, "Ahhh" voice
; (lives in E0, always mapped while the game runs normally)
; ===========================================================================

; --------------------------------------------------------------------------
; Title mode bookkeeping.  VZ_GETKY sets titlemode when it is called from
; the MZ title loop; VZ_FRAME then draws the VZ title picture instead of
; converting the MZ screen.
; --------------------------------------------------------------------------
titlemode:  db 0
tframe:     db 0

; draw the title picture (VZ rows 1-15) into VZBUF with the current
; animation frame: blinking mammoth eye, waving Harrier, flashing robot eyes
title_draw:
            ld hl,TITLEART
            ld de,VZBUF+32
            ld bc,480
            ldir
            ld a,(tframe)
            inc a
            ld (tframe),a
            dec a
            and 7
            add a,a
            ld e,a
            ld d,0
            ld hl,TDIFFS
            add hl,de
            ld a,(hl)
            inc hl
            ld h,(hl)
            ld l,a                  ; HL -> diff list: count, then (offset.w, value)
            ld b,(hl)
            inc hl
            ld a,b
            or a
            ret z
.lp:        ld e,(hl)
            inc hl
            ld d,(hl)
            inc hl
            ld a,(hl)
            inc hl
            push hl
            ld hl,VZBUF+32
            add hl,de
            ld (hl),a
            pop hl
            djnz .lp
            ret

            include "title.inc"     ; TITLEART (480 bytes) + TDIFFS

; --------------------------------------------------------------------------
; TITLE_MUSIC - plays the next ~0.25 s of the Space Harrier theme.
; Returns A = 1 if a key / fire was pressed (playback stops at once).
; Note data: delay.b (25-cycle steps), halfcycles per tick.w, ticks.b, mask.b
; --------------------------------------------------------------------------
mus_ptr:    dw MUSIC
mus_left:   db 0                    ; ticks left in the current note

TITLE_MUSIC:
            push bc
            push de
            push hl
            ld a,8                  ; ticks per call
            ld (mus_budget),a
.tick:      ld hl,(mus_ptr)
            ld a,(mus_left)
            or a
            jr nz,.have
            ld a,(hl)
            cp $ff
            jr nz,.new
            ld hl,MUSIC             ; loop the tune
            ld (mus_ptr),hl
.new:       inc hl
            inc hl
            inc hl
            ld a,(hl)               ; ticks
            ld (mus_left),a
            ld hl,(mus_ptr)
.have:      ; HL -> current note
            ld d,(hl)               ; delay
            inc hl
            ld c,(hl)
            inc hl
            ld b,(hl)               ; BC = half-cycles per tick
            inc hl
            inc hl
            ld e,(hl)               ; mask ($21 tone, 0 rest)
            ld a,(mus_left)
            cp 1
            jr nz,.full
            ; last tick of the note: 5/8 sound, 3/8 silence (articulation)
            ld h,b
            ld l,c                  ; HL = all
            srl b
            rr c                    ; BC = 1/2
            push bc
            srl b
            rr c
            srl b
            rr c                    ; BC = 1/8
            ex (sp),hl              ; HL = 1/2, stack = all
            add hl,bc               ; HL = 5/8
            ex (sp),hl              ; HL = all, stack = 5/8
            pop bc                  ; BC = 5/8
            or a
            sbc hl,bc               ; HL = 3/8
            push hl
            call mus_play
            pop bc
            ld e,0
            call mus_play
            jr .next
.full:      call mus_play
.next:      ld a,(mus_left)
            dec a
            ld (mus_left),a
            jr nz,.chk
            ld hl,(mus_ptr)         ; advance to the next note
            ld de,5
            add hl,de
            ld (mus_ptr),hl
.chk:       call anykey
            jr nz,.key
            ld a,(mus_budget)
            dec a
            ld (mus_budget),a
            jr nz,.tick
            xor a
            jr .out
.key:       ld a,1
.out:       pop hl
            pop de
            pop bc
            ret
mus_budget: db 0

; BC half-cycles, D delay, E toggle mask
mus_play:   ld a,b
            or c
            ret z
            ld h,b
            ld l,c
            ld a,(latch_shadow)
            or $01                  ; speaker bits 0/5 must differ to drive the cone
            ld c,a
.h:         ld a,c
            xor e
            ld c,a
            ld (VZLATCH),a
            ld b,d
.d:         nop
            nop
            nop
            djnz .d
            dec hl
            ld a,h
            or l
            jr nz,.h
            ld a,(latch_shadow)
            ld (VZLATCH),a
            ret

; --------------------------------------------------------------------------
; joyread - both joysticks merged: A = bits (1 = pressed)
;           0 up  1 down  2 left  3 right  4 fire (either button)
; Joystick 1 is read on port $2C, joystick 2 on $29 (the ports where this
; interface reports directions).  A port is only trusted after it has once
; read "nothing pressed", so with no interface plugged in (floating bus)
; the game ignores it.  Readings with opposite directions together are
; treated as noise and ignored.
; --------------------------------------------------------------------------
joyread:    push bc
            ld c,0
            in a,($2c)
            ld b,a
            ld a,(joyok1)
            call .chk
            ld (joyok1),a
            in a,($29)
            ld b,a
            ld a,(joyok2)
            call .chk
            ld (joyok2),a
            ld a,c
            pop bc
            ret
; B = raw port value, A = trusted flag -> A = new flag, C |= pressed bits
.chk:       push af
            ld a,b
            cpl
            and $1f
            ld b,a
            jr nz,1f
            pop af                  ; idle reading: port is real
            ld a,1
            ret
1:          pop af
            or a
            ret z                   ; not trusted yet
            ld a,b
            and $03
            cp $03
            jr z,.bad               ; up+down together
            ld a,b
            and $0c
            cp $0c
            jr z,.bad               ; left+right together
            ld a,b
            or c
            ld c,a
.bad:       ld a,1
            ret
joyok1:     db 0
joyok2:     db 0

; Z clear if a key or fire button is down
anykey:     call joyread
            and $10
            ret nz
            ld a,($6800)
            and $3f
            cp $3f
            ret

            include "music.inc"     ; MUSIC: notes, $FF end

; --------------------------------------------------------------------------
; VZ_AHH - the Harrier's falling cry.  Called once per step of the fall;
; each call is a short burst of a vowel-like buzz whose pitch drops.
; --------------------------------------------------------------------------
ahidx:      db 0
VZ_AHHRESET:
            push af
            xor a
            ld (ahidx),a
            pop af
            ret
VZ_AHH:
            push af
            push bc
            push de
            push hl
            ld a,(ahidx)
            cp AHH_STEPS
            jr nc,.out
            inc a
            ld (ahidx),a
            dec a
            ld l,a
            ld h,0
            add hl,hl
            add hl,hl               ; 4 bytes per step
            ld de,AHHTAB
            add hl,de
            ld b,(hl)               ; periods in this burst
            inc hl
            ld c,(hl)               ; formant half-cycles per period
            inc hl
            ld e,(hl)
            inc hl
            ld d,(hl)               ; DE = silence count (26-cycle steps)
.per:       push bc
            push de
            ld a,(latch_shadow)
            or $01
            ld b,c
.f:         xor $21                 ; formant burst (~850 Hz)
            ld (VZLATCH),a
            ld h,AHH_FDLY
.fd:        dec h
            jr nz,.fd
            djnz .f
            ld a,(latch_shadow)
            ld (VZLATCH),a
.sil:       dec de                  ; rest of the pitch period
            ld a,d
            or e
            jr nz,.sil
            pop de
            pop bc
            djnz .per
.out:       pop hl
            pop de
            pop bc
            pop af
            ret
            include "ahh.inc"       ; AHH_STEPS, AHH_FDLY, AHHTAB
