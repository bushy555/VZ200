L8000:
	dec a                       ; 8000
	add a,a                     ; 8001
	push de                     ; 8002
	push hl                     ; 8003
	ld e,a                      ; 8004
	ld d,$00                    ; 8005
	ld hl,L8017                 ; 8007
	add hl,de                   ; 800a
	ld e,(hl)                   ; 800b
	inc hl                      ; 800c
	ld d,(hl)                   ; 800d
	ld (L8014+1),de             ; 800e
	pop hl                      ; 8012
	pop de                      ; 8013
L8014:
	jp L809c                    ; 8014
L8017:
	dw L83ab                    ; 8017
	dw L841d                    ; 8019
	dw L82d9                    ; 801b
	dw L84f6                    ; 801d
	dw L82c1                    ; 801f
	dw L82a8                    ; 8021
	dw L809c                    ; 8023
	dw L853d                    ; 8025
	dw L8549                    ; 8027
	dw L867a                    ; 8029
	dw L8d8a                    ; 802b
	dw L8d91                    ; 802d
	dw L8dd1                    ; 802f
	dw L8846                    ; 8031
	dw L8953                    ; 8033
	dw L8ba8                    ; 8035
	dw L8c1b                    ; 8037
	dw L8b1d                    ; 8039
	dw L8b1d                    ; 803b
	dw L8b6f                    ; 803d
	dw L8b32                    ; 803f
	dw L8c4f                    ; 8041
L8043:
	push af
	ld a,MAP_GFX
	out (MAPPORT),a
	pop af
	call VZ_BLIT
	push af
	ld a,MAP_NORMAL
	out (MAPPORT),a
	pop af
	ret
L8043_b:
	ld a,l                      ; 8043
	cp $1f                      ; 8044
	ret nc                      ; 8046
	ld a,h                      ; 8047
	cp $34                      ; 8048
	ret nc                      ; 804a
	push de                     ; 804b
	ld e,h                      ; 804c
	ld d,$00                    ; 804d
	ld h,d                      ; 804f
	ld a,l                      ; 8050
	add a,a                     ; 8051
	add a,a                     ; 8052
	add a,a                     ; 8053
	ld l,a                      ; 8054
	add hl,hl                   ; 8055
	add hl,hl                   ; 8056
	add hl,hl                   ; 8057
	add hl,de                   ; 8058
	ld de,BUF+$000              ; 8059
	add hl,de                   ; 805c
	pop de                      ; 805d
	exx                         ; 805e
	ld b,$00                    ; 805f
	exx                         ; 8061
L8062:
	push bc                     ; 8062
	push de                     ; 8063
	ld a,c                      ; 8064
	exx                         ; 8065
	ld hl,L8661                 ; 8066
L8069:
	ld bc,$0011                 ; 8069
	cpir                        ; 806c
	exx                         ; 806e
	jp z,L808f                  ; 806f
	push hl                     ; 8072
L8073:
	ld a,b                      ; 8073
	exx                         ; 8074
	ld hl,L8655                 ; 8075
L8078:
	ld bc,$0009                 ; 8078
	cpir                        ; 807b
	exx                         ; 807d
	jp z,L8088                  ; 807e
	ld a,(de)                   ; 8081
	or a                        ; 8082
	jp m,L8087                  ; 8083
	ld (hl),a                   ; 8086
L8087:
	inc l                       ; 8087
L8088:
	inc de                      ; 8088
	djnz L8073                  ; 8089
	pop hl                      ; 808b
	ld c,$40                    ; 808c
	add hl,bc                   ; 808e
L808f:
	pop de                      ; 808f
	ld bc,$000b                 ; 8090
	ex de,hl                    ; 8093
	add hl,bc                   ; 8094
	ex de,hl                    ; 8095
	pop bc                      ; 8096
	dec c                       ; 8097
	jp nz,L8062                 ; 8098
	ret                         ; 809b
L809c:
	jp VZ_SPRITES               ; 809c patched
	ld (L80a8+1),a              ; 809e
L80a1:
	ld ix,WRK+$079              ; 80a1
	ld b,$10                    ; 80a5
L80a7:
	push bc                     ; 80a7
L80a8:
	ld a,$14                    ; 80a8
	cp (ix+3)                   ; 80aa
	jp nz,L80ed                 ; 80ad
	bit 7,(ix+7)                ; 80b0
	jp z,L80ed                  ; 80b4
	ld a,(ix+0)                 ; 80b7
	dec a                       ; 80ba
	jp m,L80ed                  ; 80bb
L80be:
	ld l,a                      ; 80be
	ld h,$00                    ; 80bf
	add hl,hl                   ; 80c1
	add hl,hl                   ; 80c2
	add hl,hl                   ; 80c3
	ld a,(ix+6)                 ; 80c4
	and $03                     ; 80c7
	add a,a                     ; 80c9
	ld e,a                      ; 80ca
	ld d,$00                    ; 80cb
	add hl,de                   ; 80cd
	ld de,L8100                 ; 80ce
	add hl,de                   ; 80d1
	ld e,(hl)                   ; 80d2
	inc hl                      ; 80d3
	ld d,(hl)                   ; 80d4
	ld l,(ix+1)                 ; 80d5
	ld h,(ix+2)                 ; 80d8
	call L8610                  ; 80db
	ld bc,$0b14                 ; 80de
	ld a,(ix+9)                 ; 80e1
	or a                        ; 80e4
	jp z,L80ea                  ; 80e5
	ld c,$0a                    ; 80e8
L80ea:
	call L8043                  ; 80ea
L80ed:
	ret                         ; 80ed patched
	add ix,de                   ; 80f0
	pop bc                      ; 80f2
	djnz L80a7                  ; 80f3
	ld a,(L80a8+1)              ; 80f5
	dec a                       ; 80f8
	ld (L80a8+1),a              ; 80f9
	jp nz,L80a1                 ; 80fc
	ret                         ; 80ff
L8100:
	dw L46e0                    ; 8100
	dw L46e0                    ; 8102
	dw L46e0                    ; 8104
	dw L46e0                    ; 8106
	dw L5356                    ; 8108
	dw L53c4                    ; 810a
	dw L53c4                    ; 810c
	dw L5356                    ; 810e
	dw L4974                    ; 8110
	dw L4974                    ; 8112
	dw L4974                    ; 8114
	dw L4974                    ; 8116
	dw L49e2                    ; 8118
	dw L49e2                    ; 811a
	dw L49e2                    ; 811c
	dw L49e2                    ; 811e
	dw L4a50                    ; 8120
	dw L4a50                    ; 8122
	dw L4a50                    ; 8124
	dw L4a50                    ; 8126
	dw L4abe                    ; 8128
	dw L4abe                    ; 812a
	dw L4abe                    ; 812c
	dw L4abe                    ; 812e
	dw L4b2c                    ; 8130
	dw L4b2c                    ; 8132
	dw L4b2c                    ; 8134
	dw L4b2c                    ; 8136
	dw L4b9a                    ; 8138
	dw L4b9a                    ; 813a
	dw L4b9a                    ; 813c
	dw L4b9a                    ; 813e
	dw L4906                    ; 8140
	dw L4898                    ; 8142
	dw L482a                    ; 8144
	dw L47bc                    ; 8146
	dw L4e9c                    ; 8148
	dw L4e9c                    ; 814a
	dw L4e9c                    ; 814c
	dw L4e9c                    ; 814e
	dw L4e2e                    ; 8150
	dw L4e2e                    ; 8152
	dw L4e2e                    ; 8154
	dw L4e2e                    ; 8156
	dw L4f0a                    ; 8158
	dw L4f0a                    ; 815a
	dw L4f0a                    ; 815c
	dw L4f0a                    ; 815e
	dw L5130                    ; 8160
	dw L5130                    ; 8162
	dw L5130                    ; 8164
	dw L5130                    ; 8166
	dw L4f78                    ; 8168
	dw L4f78                    ; 816a
	dw L4f78                    ; 816c
	dw L4f78                    ; 816e
	dw L4fe6                    ; 8170
	dw L4fe6                    ; 8172
	dw L4fe6                    ; 8174
	dw L4fe6                    ; 8176
	dw L5054                    ; 8178
	dw L50c2                    ; 817a
	dw L5054                    ; 817c
	dw L50c2                    ; 817e
	dw L52e8                    ; 8180
	dw L52e8                    ; 8182
	dw L52e8                    ; 8184
	dw L52e8                    ; 8186
	dw L5432                    ; 8188
	dw L5432                    ; 818a
	dw L54a0                    ; 818c
	dw L550e                    ; 818e
	dw L557c                    ; 8190
	dw L5658                    ; 8192
	dw L557c                    ; 8194
	dw L5658                    ; 8196
	dw L5734                    ; 8198
	dw L5810                    ; 819a
	dw L5734                    ; 819c
	dw L5810                    ; 819e
	dw L58ec                    ; 81a0
	dw L59c8                    ; 81a2
	dw L58ec                    ; 81a4
	dw L59c8                    ; 81a6
	dw L5aa4                    ; 81a8
	dw L5b80                    ; 81aa
	dw L5c5c                    ; 81ac
	dw L5d38                    ; 81ae
	dw L4000                    ; 81b0
	dw L4000                    ; 81b2
	db $00,$00,$00,$00          ; 81b4
	dw L40dc                    ; 81b8
	dw L40dc                    ; 81ba
	db $00,$00,$00,$00          ; 81bc
	dw L41b8                    ; 81c0
	dw L41b8                    ; 81c2
	db $00,$00,$00,$00          ; 81c4
	dw L4294                    ; 81c8
	dw L4294                    ; 81ca
	db $00,$00,$00,$00          ; 81cc
	dw L444c                    ; 81d0
	dw L444c                    ; 81d2
	db $00,$00,$00,$00          ; 81d4
	dw L4528                    ; 81d8
	dw L4528                    ; 81da
	db $00,$00,$00,$00          ; 81dc
	dw L4604                    ; 81e0
	dw L4604                    ; 81e2
	db $00,$00,$00,$00          ; 81e4
	dw L4370                    ; 81e8
	dw L4370                    ; 81ea
	db $00,$00,$00,$00          ; 81ec
	dw L520c                    ; 81f0
	dw L520c                    ; 81f2
	db $00,$00,$00,$00          ; 81f4
	dw L4c08                    ; 81f8
	dw L4c08                    ; 81fa
	db $00,$00,$00,$00          ; 81fc
	dw L4c76                    ; 8200
	dw L4c76                    ; 8202
	db $00,$00,$00,$00          ; 8204
	dw L4ce4                    ; 8208
	dw L4ce4                    ; 820a
	db $00,$00,$00,$00          ; 820c
	dw L4dc0                    ; 8210
	dw L4dc0                    ; 8212
	db $00,$00,$00,$00          ; 8214
	dw L519e                    ; 8218
	dw L519e                    ; 821a
	db $00,$00,$00,$00          ; 821c
	dw L519e                    ; 8220
	dw L519e                    ; 8222
	db $00,$00,$00,$00          ; 8224
	dw L4d52                    ; 8228
	dw L4d52                    ; 822a
	db $00,$00,$00,$00          ; 822c
	dw L52e8                    ; 8230
	dw L52e8                    ; 8232
	db $00,$00,$00,$00          ; 8234
	dw L5e14                    ; 8238
	dw L5e14                    ; 823a
	db $00,$00,$00,$00          ; 823c
	dw L5e82                    ; 8240
	dw L5e82                    ; 8242
	db $00,$00,$00,$00          ; 8244
	dw L5f5e                    ; 8248
	dw L5f5e                    ; 824a
	db $00,$00,$00,$00          ; 824c
	dw L603a                    ; 8250
	dw L603a                    ; 8252
	db $00,$00,$00,$00          ; 8254
	dw L6116                    ; 8258
	dw L6116                    ; 825a
	db $00,$00,$00,$00          ; 825c
	dw L61f2                    ; 8260
	dw L61f2                    ; 8262
	db $00,$00,$00,$00          ; 8264
	dw L6260                    ; 8268
	dw L519e                    ; 826a
	db $00,$00,$00,$00          ; 826c
	dw L62ce                    ; 8270
	dw L62ce                    ; 8272
	db $00,$00,$00,$00          ; 8274
	dw L7926                    ; 8278
	dw L7a02                    ; 827a
	dw L7ade                    ; 827c
	dw L7a02                    ; 827e
	dw L7994                    ; 8280
	dw L7a70                    ; 8282
	dw L7b4c                    ; 8284
	dw L7a70                    ; 8286
	dw L7bba                    ; 8288
	dw L7bba                    ; 828a
	db $00,$00,$00,$00          ; 828c
	dw L7d72                    ; 8290
	dw L7d72                    ; 8292
	db $00,$00,$00,$00          ; 8294
	dw L7de0                    ; 8298
	dw L7de0                    ; 829a
	db $00,$00,$00,$00          ; 829c
	dw L7e4e                    ; 82a0
	dw L7e4e                    ; 82a2
	db $00,$00,$00,$00          ; 82a4
L82a8:
	ld hl,$7070                 ; 82a8
	ld (BUF+$78c),hl            ; 82ab
	ld a,h                      ; 82ae
	ld (BUF+$78e),a             ; 82af
	ld hl,$2bca                 ; 82b2
	ld (VRAM+$3c0),hl           ; 82b5
	ld a,(WRK+$06a)             ; 82b8
	or $20                      ; 82bb
	ld (VRAM+$3c2),a            ; 82bd
	ret                         ; 82c0
L82c1:
	ld a,(WRK+$064)             ; 82c1
	ld c,a                      ; 82c4
	and $10                     ; 82c5
	rlca                        ; 82c7
	rlca                        ; 82c8
	rlca                        ; 82c9
	rlca                        ; 82ca
	or $20                      ; 82cb
	ld (VRAM+$025),a            ; 82cd
	ld a,c                      ; 82d0
	and $0f                     ; 82d1
	or $20                      ; 82d3
	ld (VRAM+$026),a            ; 82d5
	ret                         ; 82d8
L82d9:
	ld hl,MZW+$009              ; 82d9
	inc (hl)                    ; 82dc
	ld a,(hl)                   ; 82dd
	and $03                     ; 82de
	ld l,a                      ; 82e0
	ld h,$00                    ; 82e1
	ld de,L8366                 ; 82e3
	add hl,de                   ; 82e6
	ld a,(hl)                   ; 82e7
	ld (L8359),a                ; 82e8
	ld a,(WRK+$056)             ; 82eb
	dec a                       ; 82ee
	jp m,L82fa                  ; 82ef
	ld (WRK+$056),a             ; 82f2
	ld a,$19                    ; 82f5
	ld (WRK+$05c),a             ; 82f7
L82fa:
	ld hl,WRK+$052              ; 82fa
	bit 7,(hl)                  ; 82fd
	jp nz,L8306                 ; 82ff
	dec (hl)                    ; 8302
	bit 0,(hl)                  ; 8303
	ret z                       ; 8305
L8306:
	ld ix,L835e                 ; 8306
	ld (ix+0),$05               ; 830a
	ld (ix+2),$05               ; 830e
	ld (ix+4),$22               ; 8312
	ld (ix+6),$22               ; 8316
	ld a,(WRK+$05c)             ; 831a
	cp $19                      ; 831d
	jp c,L8342                  ; 831f
L8322:
	ld a,$00                    ; 8322
	inc a                       ; 8324
	and $03                     ; 8325
	ld (L8322+1),a              ; 8327
	cp $02                      ; 832a
	jp c,L833a                  ; 832c
	ld (ix+2),$22               ; 832f
	ld (ix+6),$ff               ; 8333
	jp L8342                    ; 8337
L833a:
	ld (ix+0),$22               ; 833a
	ld (ix+4),$ff               ; 833e
L8342:
	ld hl,(WRK+$05c)            ; 8342
	ld de,L834e                 ; 8345
	ld bc,$0406                 ; 8348
	jp L836a                    ; 834b
L834e:
	db $ff,$66,$ff,$ff,$22,$22,$22,$22,$22,$05,$22; 834e
L8359:
	db $00,$55,$55,$55,$ff      ; 8359
L835e:
	db $05,$ff,$05,$ff,$22,$ff,$22,$ff; 835e
L8366:
	db $00,$02,$22,$02          ; 8366
L836a:
	ld a,$40                    ; 836a
	sub b                       ; 836c
	ld (L838e+1),a              ; 836d
	push de                     ; 8370
	ld e,h                      ; 8371
	ld d,$00                    ; 8372
	ld h,d                      ; 8374
	ld a,l                      ; 8375
	add a,a                     ; 8376
	add a,a                     ; 8377
	add a,a                     ; 8378
	ld l,a                      ; 8379
	add hl,hl                   ; 837a
	add hl,hl                   ; 837b
	add hl,hl                   ; 837c
	add hl,de                   ; 837d
	ld de,BUF+$000              ; 837e
	add hl,de                   ; 8381
	pop de                      ; 8382
L8383:
	push bc                     ; 8383
L8384:
	ld a,(de)                   ; 8384
	or a                        ; 8385
	jp m,L838a                  ; 8386
	ld (hl),a                   ; 8389
L838a:
	inc de                      ; 838a
	inc l                       ; 838b
	djnz L8384                  ; 838c
L838e:
	ld c,$3c                    ; 838e
	add hl,bc                   ; 8390
	pop bc                      ; 8391
	dec c                       ; 8392
	jp nz,L8383                 ; 8393
	ret                         ; 8396
L8397:
	push de                     ; 8397
	ld e,h                      ; 8398
	ld d,$00                    ; 8399
	ld h,d                      ; 839b
	ld a,l                      ; 839c
	add a,a                     ; 839d
	add a,a                     ; 839e
	add a,a                     ; 839f
	ld l,a                      ; 83a0
	add hl,hl                   ; 83a1
	add hl,hl                   ; 83a2
	add hl,hl                   ; 83a3
	add hl,de                   ; 83a4
	ld de,BUF+$000              ; 83a5
	add hl,de                   ; 83a8
	pop de                      ; 83a9
	ret                         ; 83aa
L83ab:
	ld a,$2b                    ; 83ab
	call La000                  ; 83ad
	ld ix,WRK+$079              ; 83b0
	ld b,$10                    ; 83b4
	ld de,$0018                 ; 83b6
L83b9:
	exx                         ; 83b9
	ld a,(ix+0)                 ; 83ba
	or a                        ; 83bd
	jp z,L83f6                  ; 83be
	ld a,(ix+14)                ; 83c1
	or a                        ; 83c4
	jp z,L83f6                  ; 83c5
	ld a,(ix+2)                 ; 83c8
	cp $34                      ; 83cb
	jp nc,L83f6                 ; 83cd
	ld a,(ix+3)                 ; 83d0
	sra a                       ; 83d3
	ld c,a                      ; 83d5
	ld b,$00                    ; 83d6
	ld hl,L840c                 ; 83d8
	add hl,bc                   ; 83db
	ld b,(hl)                   ; 83dc
	ld a,(ix+15)                ; 83dd
	ld e,(ix+2)                 ; 83e0
	ld d,$00                    ; 83e3
	ld h,d                      ; 83e5
	add a,a                     ; 83e6
	add a,a                     ; 83e7
	add a,a                     ; 83e8
	ld l,a                      ; 83e9
	add hl,hl                   ; 83ea
	add hl,hl                   ; 83eb
	add hl,hl                   ; 83ec
	add hl,de                   ; 83ed
	ld de,BUF+$000              ; 83ee
	add hl,de                   ; 83f1
L83f2:
	ld (hl),e                   ; 83f2
	inc l                       ; 83f3
	djnz L83f2                  ; 83f4
L83f6:
	exx                         ; 83f6
	add ix,de                   ; 83f7
	djnz L83b9                  ; 83f9
	ld hl,(WRK+$05c)            ; 83fb
	ld l,$1e                    ; 83fe
	call L8397                  ; 8400
	xor a                       ; 8403
	ld (hl),a                   ; 8404
	inc l                       ; 8405
	ld (hl),a                   ; 8406
	inc l                       ; 8407
	ld (hl),a                   ; 8408
	inc l                       ; 8409
	ld (hl),a                   ; 840a
	ret                         ; 840b
L840c:
	db $0b,$0a,$09,$08,$07,$06,$05,$04,$03,$02,$01,$01,$01,$01,$01,$01; 840c
	db $01                      ; 841c
L841d:
	ld ix,WRK+$229              ; 841d
	ld b,$06                    ; 8421
	ld de,$0006                 ; 8423
L8426:
	exx                         ; 8426
	ld a,(ix+0)                 ; 8427
	or a                        ; 842a
	jp z,L8448                  ; 842b
	ld a,(ix+3)                 ; 842e
	add a,a                     ; 8431
	ld e,a                      ; 8432
	ld d,$00                    ; 8433
	ld hl,L844e                 ; 8435
	add hl,de                   ; 8438
	ld e,(hl)                   ; 8439
	inc hl                      ; 843a
	ld d,(hl)                   ; 843b
	ld l,(ix+1)                 ; 843c
	ld h,(ix+2)                 ; 843f
	ld bc,$0604                 ; 8442
	call L836a                  ; 8445
L8448:
	exx                         ; 8448
	add ix,de                   ; 8449
	djnz L8426                  ; 844b
	ret                         ; 844d
L844e:
	dw L847e                    ; 844e
	dw L847e                    ; 8450
	dw L847e                    ; 8452
	dw L847e                    ; 8454
	dw L8496                    ; 8456
	dw L8496                    ; 8458
	dw L8496                    ; 845a
	dw L8496                    ; 845c
	dw L84ae                    ; 845e
	dw L84ae                    ; 8460
	dw L84ae                    ; 8462
	dw L84ae                    ; 8464
	dw L84c6                    ; 8466
	dw L84c6                    ; 8468
	dw L84c6                    ; 846a
	dw L84c6                    ; 846c
	dw L84de                    ; 846e
	dw L84de                    ; 8470
	dw L84de                    ; 8472
	dw L84de                    ; 8474
	dw L84de                    ; 8476
	dw L84de                    ; 8478
	dw L84de                    ; 847a
	dw L84de                    ; 847c
L847e:
	db $ff,$76,$76,$76,$76,$ff,$76,$76,$76,$76,$76,$76,$76,$76,$76,$76; 847e
	db $76,$76,$ff,$76,$76,$76,$76,$ff; 848e
L8496:
	db $ff,$76,$76,$76,$ff,$ff,$76,$76,$76,$76,$76,$ff,$76,$76,$76,$76; 8496
	db $76,$ff,$ff,$76,$76,$76,$ff,$ff; 84a6
L84ae:
	db $ff,$ff,$76,$76,$ff,$ff,$ff,$76,$76,$76,$76,$ff,$ff,$ff,$76,$76; 84ae
	db $ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff; 84be
L84c6:
	db $ff,$76,$76,$76,$ff,$ff,$ff,$76,$76,$76,$ff,$ff,$ff,$ff,$ff,$ff; 84c6
	db $ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff; 84d6
L84de:
	db $ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$76,$76,$ff,$ff,$ff,$ff,$ff,$ff; 84de
	db $ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff; 84ee
L84f6:
	ld (L852d+1),sp             ; 84f6
	ld ix,WRK+$038              ; 84fa
	ld a,(WRK+$066)             ; 84fe
	ld e,a                      ; 8501
	ld d,$00                    ; 8502
	add ix,de                   ; 8504
	ld b,$18                    ; 8506
	di                          ; 8508
	ld sp,BUF+$7b4              ; 8509
L850c:
	ld e,(ix+0)                 ; 850c
	ld d,e                      ; 850f
	dec ix                      ; 8510
	push de                     ; 8512
	push de                     ; 8513
	push de                     ; 8514
	push de                     ; 8515
	push de                     ; 8516
	push de                     ; 8517
	push de                     ; 8518
	push de                     ; 8519
	push de                     ; 851a
	push de                     ; 851b
	push de                     ; 851c
	push de                     ; 851d
	push de                     ; 851e
	push de                     ; 851f
	push de                     ; 8520
	push de                     ; 8521
	push de                     ; 8522
	push de                     ; 8523
	push de                     ; 8524
	push de                     ; 8525
	ld hl,$ffe8                 ; 8526
	add hl,sp                   ; 8529
	ld sp,hl                    ; 852a
	djnz L850c                  ; 852b
L852d:
	ld sp,MZW+$0ee              ; 852d
	nop                         ; 8530 patched
	ld hl,WRK+$003              ; 8531
	ld de,WRK+$021              ; 8534
	ld bc,$0014                 ; 8537
	ldir                        ; 853a
	ret                         ; 853c
L853d:
	ld a,(WRK+$062)             ; 853d
	cp $04                      ; 8540
	ret z                       ; 8542
	cp $09                      ; 8543
	ret z                       ; 8545
	cp $0e                      ; 8546
	ret z                       ; 8548
L8549:
	ld a,(WRK+$066)             ; 8549
	ld c,a                      ; 854c
	ld a,$19                    ; 854d
	sub c                       ; 854f
	ld l,a                      ; 8550
	ld h,$0c                    ; 8551
	call L8397                  ; 8553
	ex de,hl                    ; 8556
	ld a,(WRK+$260)             ; 8557
	ld c,a                      ; 855a
	ld b,$00                    ; 855b
	ld hl,VRAM+$500             ; 855d
	add hl,bc                   ; 8560
	push de                     ; 8561
	push hl                     ; 8562
	ldi                         ; 8563
	ldi                         ; 8565
	ldi                         ; 8567
	ldi                         ; 8569
	ldi                         ; 856b
	ldi                         ; 856d
	ldi                         ; 856f
	ldi                         ; 8571
	ldi                         ; 8573
	ldi                         ; 8575
	ldi                         ; 8577
	ldi                         ; 8579
	ldi                         ; 857b
	ldi                         ; 857d
	ldi                         ; 857f
	ldi                         ; 8581
	ldi                         ; 8583
	ldi                         ; 8585
	ldi                         ; 8587
	ldi                         ; 8589
	ldi                         ; 858b
	ldi                         ; 858d
	ldi                         ; 858f
	ldi                         ; 8591
	ldi                         ; 8593
	ldi                         ; 8595
	ldi                         ; 8597
	ldi                         ; 8599
	ldi                         ; 859b
	ldi                         ; 859d
	ldi                         ; 859f
	ldi                         ; 85a1
	ldi                         ; 85a3
	ldi                         ; 85a5
	ldi                         ; 85a7
	ldi                         ; 85a9
	ldi                         ; 85ab
	ldi                         ; 85ad
	ldi                         ; 85af
	ldi                         ; 85b1
	pop hl                      ; 85b3
	ld de,$0050                 ; 85b4
	add hl,de                   ; 85b7
	pop de                      ; 85b8
	ld bc,$0040                 ; 85b9
	ex de,hl                    ; 85bc
	add hl,bc                   ; 85bd
	ex de,hl                    ; 85be
	ldi                         ; 85bf
	ldi                         ; 85c1
	ldi                         ; 85c3
	ldi                         ; 85c5
	ldi                         ; 85c7
	ldi                         ; 85c9
	ldi                         ; 85cb
	ldi                         ; 85cd
	ldi                         ; 85cf
	ldi                         ; 85d1
	ldi                         ; 85d3
	ldi                         ; 85d5
	ldi                         ; 85d7
	ldi                         ; 85d9
	ldi                         ; 85db
	ldi                         ; 85dd
	ldi                         ; 85df
	ldi                         ; 85e1
	ldi                         ; 85e3
	ldi                         ; 85e5
	ldi                         ; 85e7
	ldi                         ; 85e9
	ldi                         ; 85eb
	ldi                         ; 85ed
	ldi                         ; 85ef
	ldi                         ; 85f1
	ldi                         ; 85f3
	ldi                         ; 85f5
	ldi                         ; 85f7
	ldi                         ; 85f9
	ldi                         ; 85fb
	ldi                         ; 85fd
	ldi                         ; 85ff
	ldi                         ; 8601
	ldi                         ; 8603
	ldi                         ; 8605
	ldi                         ; 8607
	ldi                         ; 8609
	ldi                         ; 860b
	ldi                         ; 860d
	ret                         ; 860f
L8610:
	push de                     ; 8610
	push hl                     ; 8611
	ld a,(ix+3)                 ; 8612
	sra a                       ; 8615
	add a,a                     ; 8617
	ld e,a                      ; 8618
	ld d,$00                    ; 8619
	ld hl,L8631                 ; 861b
	add hl,de                   ; 861e
	ld a,(hl)                   ; 861f
	ld (WRK+$05a),a             ; 8620
	ld (L8078+1),a              ; 8623
	inc hl                      ; 8626
	ld a,(hl)                   ; 8627
	ld (WRK+$058),a             ; 8628
	ld (L8069+1),a              ; 862b
	pop hl                      ; 862e
	pop de                      ; 862f
	ret                         ; 8630
L8631:
	db $01,$01,$02,$03,$03,$05,$04,$07,$05,$09,$06,$0b,$07,$0d,$07,$0e; 8631
	db $08,$0f,$08,$10,$09,$11,$09,$12,$0a,$13,$0a,$13,$0b,$14,$0b,$14; 8641
	db $0b,$14,$0b,$14          ; 8651
L8655:
	db $00,$01,$09,$05,$07,$04,$08,$02,$06,$03,$0a,$0a; 8655
L8661:
	db $00,$04,$11,$09,$0c,$05,$10,$07,$0e,$01,$14,$08,$0d,$02,$13,$06; 8661
	db $0f,$03,$12,$0a,$0b,$0a,$0b,$0a,$0b; 8671
L867a:
	ld a,$1f                    ; 867a
	ld (L8686+1),a              ; 867c
L867f:
	ld ix,WRK+$079              ; 867f
	ld b,$10                    ; 8683
L8685:
	push bc                     ; 8685
L8686:
	ld a,$00                    ; 8686
	cp (ix+3)                   ; 8688
	jp nz,L86cb                 ; 868b
	bit 7,(ix+7)                ; 868e
	jp z,L86cb                  ; 8692
	ld a,(ix+0)                 ; 8695
	dec a                       ; 8698
	jp m,L86cb                  ; 8699
	ld l,a                      ; 869c
	ld h,$00                    ; 869d
	add hl,hl                   ; 869f
	add hl,hl                   ; 86a0
	add hl,hl                   ; 86a1
	ld a,(ix+6)                 ; 86a2
	and $03                     ; 86a5
	add a,a                     ; 86a7
	ld e,a                      ; 86a8
	ld d,$00                    ; 86a9
	add hl,de                   ; 86ab
	ld de,L86de                 ; 86ac
	add hl,de                   ; 86af
	ld e,(hl)                   ; 86b0
	inc hl                      ; 86b1
	ld d,(hl)                   ; 86b2
	ld l,(ix+1)                 ; 86b3
	ld h,(ix+2)                 ; 86b6
	call L8610                  ; 86b9
	ld bc,$0b14                 ; 86bc
	ld a,(ix+9)                 ; 86bf
	or a                        ; 86c2
	jp z,L86c8                  ; 86c3
	ld c,$0a                    ; 86c6
L86c8:
	call L8043                  ; 86c8
L86cb:
	ld de,$0018                 ; 86cb
	add ix,de                   ; 86ce
	pop bc                      ; 86d0
	djnz L8685                  ; 86d1
	ld a,(L8686+1)              ; 86d3
	dec a                       ; 86d6
	ld (L8686+1),a              ; 86d7
	jp nz,L867f                 ; 86da
	ret                         ; 86dd
L86de:
	db $00,$00,$00,$00,$00,$00,$00,$00; 86de
	dw L633c                    ; 86e6
	dw L63aa                    ; 86e8
	dw L63aa                    ; 86ea
	dw L633c                    ; 86ec
	dw L4974                    ; 86ee
	dw L4974                    ; 86f0
	dw L4974                    ; 86f2
	dw L4974                    ; 86f4
	dw L49e2                    ; 86f6
	dw L49e2                    ; 86f8
	dw L49e2                    ; 86fa
	dw L49e2                    ; 86fc
	dw L4a50                    ; 86fe
	dw L4a50                    ; 8700
	dw L4a50                    ; 8702
	dw L4a50                    ; 8704
	dw L4abe                    ; 8706
	dw L4abe                    ; 8708
	dw L4abe                    ; 870a
	dw L4abe                    ; 870c
	dw L4b2c                    ; 870e
	dw L4b2c                    ; 8710
	dw L4b2c                    ; 8712
	dw L4b2c                    ; 8714
	db $00,$00,$00,$00,$00,$00,$00,$00; 8716
	dw L4906                    ; 871e
	dw L4898                    ; 8720
	dw L482a                    ; 8722
	dw L47bc                    ; 8724
	dw L6418                    ; 8726
	dw L6418                    ; 8728
	dw L6418                    ; 872a
	dw L6418                    ; 872c
	dw L6f44                    ; 872e
	dw L6ed6                    ; 8730
	dw L6e68                    ; 8732
	dw L6486                    ; 8734
	dw L708e                    ; 8736
	dw L7020                    ; 8738
	dw L6fb2                    ; 873a
	dw L64f4                    ; 873c
	dw L6562                    ; 873e
	dw L6562                    ; 8740
	db $00,$00,$00,$00          ; 8742
	dw L71d8                    ; 8746
	dw L716a                    ; 8748
	dw L70fc                    ; 874a
	dw L65d0                    ; 874c
	dw L663e                    ; 874e
	dw L663e                    ; 8750
	dw L66ac                    ; 8752
	dw L66ac                    ; 8754
	dw L663e                    ; 8756
	dw L663e                    ; 8758
	dw L66ac                    ; 875a
	dw L66ac                    ; 875c
	dw L671a                    ; 875e
	dw L6788                    ; 8760
	dw L6788                    ; 8762
	dw L6788                    ; 8764
	dw L671a                    ; 8766
	dw L6788                    ; 8768
	dw L6788                    ; 876a
	dw L6788                    ; 876c
	dw L67f6                    ; 876e
	dw L67f6                    ; 8770
	dw L67f6                    ; 8772
	dw L67f6                    ; 8774
	dw L7322                    ; 8776
	dw L72b4                    ; 8778
	dw L7246                    ; 877a
	dw L6864                    ; 877c
	dw L746c                    ; 877e
	dw L73fe                    ; 8780
	dw L7390                    ; 8782
	dw L68d2                    ; 8784
	dw L6940                    ; 8786
	dw Lb75c                    ; 8788
	dw L6940                    ; 878a
	dw L6940                    ; 878c
	dw L69ae                    ; 878e
	dw L69ae                    ; 8790
	dw L69ae                    ; 8792
	dw L69ae                    ; 8794
	dw L6a1c                    ; 8796
	dw L6a1c                    ; 8798
	dw L6a1c                    ; 879a
	dw L6a1c                    ; 879c
	dw L6a8a                    ; 879e
	dw L6a8a                    ; 87a0
	dw L6a8a                    ; 87a2
	dw L6a8a                    ; 87a4
	dw L6af8                    ; 87a6
	dw L6af8                    ; 87a8
	dw L6af8                    ; 87aa
	dw L6af8                    ; 87ac
	dw L6d8c                    ; 87ae
	dw L6b66                    ; 87b0
	dw L6c42                    ; 87b2
	dw L6c42                    ; 87b4
	dw L5658                    ; 87b6
	dw L557c                    ; 87b8
	dw L5658                    ; 87ba
	dw L557c                    ; 87bc
	dw L5810                    ; 87be
	dw L5734                    ; 87c0
	dw L5810                    ; 87c2
	dw L5734                    ; 87c4
	dw L58ec                    ; 87c6
	dw L59c8                    ; 87c8
	dw L58c8                    ; 87ca
	dw L58ec                    ; 87cc
	dw L7c96                    ; 87ce
	dw L5b80                    ; 87d0
	dw L5c5c                    ; 87d2
	dw L5d38                    ; 87d4
	dw L5432                    ; 87d6
	dw L54a0                    ; 87d8
	dw L550e                    ; 87da
	dw L550e                    ; 87dc
	dw L4c76                    ; 87de
	dw L4c76                    ; 87e0
	dw L4c76                    ; 87e2
	dw L4c76                    ; 87e4
	dw L52e8                    ; 87e6
	dw L52e8                    ; 87e8
	dw L52e8                    ; 87ea
	dw L52e8                    ; 87ec
	dw L6d1e                    ; 87ee
	dw L6d1e                    ; 87f0
	dw L6d1e                    ; 87f2
	dw L6d1e                    ; 87f4
	dw L4604                    ; 87f6
	dw L4604                    ; 87f8
	db $00,$00,$00,$00          ; 87fa
	dw L5054                    ; 87fe
	dw L50c2                    ; 8800
	dw L5054                    ; 8802
	dw L50c2                    ; 8804
	dw L4d52                    ; 8806
	dw L4d52                    ; 8808
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 880a
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 881a
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 882a
	dw L784a                    ; 8836
	dw L784a                    ; 8838
	dw L784a                    ; 883a
	dw L784a                    ; 883c
	dw L78b8                    ; 883e
	dw L78b8                    ; 8840
	dw L78b8                    ; 8842
	dw L78b8                    ; 8844
L8846:
	ld a,$1f                    ; 8846
	ld (L8852+1),a              ; 8848
L884b:
	ld ix,WRK+$079              ; 884b
	ld b,$10                    ; 884f
L8851:
	push bc                     ; 8851
L8852:
	ld a,$00                    ; 8852
	cp (ix+3)                   ; 8854
	jp nz,L8897                 ; 8857
	bit 7,(ix+7)                ; 885a
	jp z,L8897                  ; 885e
	ld a,(ix+0)                 ; 8861
	dec a                       ; 8864
	jp m,L88aa                  ; 8865
	ld l,a                      ; 8868
	ld h,$00                    ; 8869
	add hl,hl                   ; 886b
	add hl,hl                   ; 886c
	add hl,hl                   ; 886d
	ld a,(ix+6)                 ; 886e
	and $03                     ; 8871
	add a,a                     ; 8873
	ld e,a                      ; 8874
	ld d,$00                    ; 8875
	add hl,de                   ; 8877
	ld de,L88b5                 ; 8878
	add hl,de                   ; 887b
	ld e,(hl)                   ; 887c
	inc hl                      ; 887d
	ld d,(hl)                   ; 887e
	ld l,(ix+1)                 ; 887f
	ld h,(ix+2)                 ; 8882
	call L8610                  ; 8885
	ld bc,$0b14                 ; 8888
	ld a,(ix+9)                 ; 888b
	or a                        ; 888e
	jp z,L8894                  ; 888f
	ld c,$0a                    ; 8892
L8894:
	call L8043                  ; 8894
L8897:
	ld de,$0018                 ; 8897
	add ix,de                   ; 889a
	pop bc                      ; 889c
	djnz L8851                  ; 889d
	ld a,(L8852+1)              ; 889f
	dec a                       ; 88a2
	ld (L8852+1),a              ; 88a3
	jp nz,L884b                 ; 88a6
	ret                         ; 88a9
L88aa:
	ld bc,$00c8                 ; 88aa
L88ad:
	cpi                         ; 88ad
	jp pe,L88ad                 ; 88af
	jp L8897                    ; 88b2
L88b5:
	dw L52e8                    ; 88b5
	db $00,$00,$00,$00,$00,$00  ; 88b7
	dw L5356                    ; 88bd
	dw L53c4                    ; 88bf
	dw L53c4                    ; 88c1
	dw L5356                    ; 88c3
	dw L5e82                    ; 88c5
	db $00,$00,$00,$00,$00,$00  ; 88c7
	dw L75b6                    ; 88cd
	dw L75b6                    ; 88cf
	dw L7548                    ; 88d1
	dw L7548                    ; 88d3
	dw L74da                    ; 88d5
	dw L74da                    ; 88d7
	dw L74da                    ; 88d9
	dw L74da                    ; 88db
	dw L4ce4                    ; 88dd
	db $00,$00,$00,$00,$00,$00  ; 88df
	dw L6260                    ; 88e5
	db $00,$00,$00,$00,$00,$00  ; 88e7
	dw L4000                    ; 88ed
	db $00,$00,$00,$00,$00,$00  ; 88ef
	dw L4604                    ; 88f5
	db $00,$00,$00,$00,$00,$00  ; 88f7
	dw L7624                    ; 88fd
	db $00,$00,$00,$00,$00,$00  ; 88ff
	dw L7692                    ; 8905
	db $00,$00,$00,$00,$00,$00  ; 8907
	dw L7700                    ; 890d
	db $00,$00,$00,$00,$00,$00  ; 890f
	dw L776e                    ; 8915
	db $00,$00,$00,$00,$00,$00  ; 8917
	dw L77dc                    ; 891d
	db $00,$00,$00,$00,$00,$00  ; 891f
	dw L40dc                    ; 8925
	db $00,$00,$00,$00,$00,$00  ; 8927
	dw L4370                    ; 892d
	db $00,$00,$00,$00,$00,$00  ; 892f
	dw L4d52                    ; 8935
	db $00,$00,$00,$00,$00,$00  ; 8937
L893d:
	ld hl,WRK+$047              ; 893d
	ld a,e                      ; 8940
	add a,(hl)                  ; 8941
	cp c                        ; 8942
	ret c                       ; 8943
	inc hl                      ; 8944
	ld a,d                      ; 8945
	add a,(hl)                  ; 8946
	cp b                        ; 8947
	ret c                       ; 8948
	inc hl                      ; 8949
	ld a,c                      ; 894a
	add a,(hl)                  ; 894b
	cp e                        ; 894c
	ret c                       ; 894d
	inc hl                      ; 894e
	ld a,b                      ; 894f
	add a,(hl)                  ; 8950
	cp d                        ; 8951
	ret                         ; 8952
L8953:
	ld hl,$0808                 ; 8953
	ld (WRK+$047),hl            ; 8956
	ld hl,$0710                 ; 8959
	ld (WRK+$049),hl            ; 895c
	ld ix,WRK+$0f1              ; 895f
	ld b,$0b                    ; 8963
	ld de,$0018                 ; 8965
L8968:
	exx                         ; 8968
	ld a,(ix+0)                 ; 8969
	cp $06                      ; 896c
	jp c,L8993                  ; 896e
	ld a,(ix+3)                 ; 8971
	cp $04                      ; 8974
	jp nc,L8993                 ; 8976
	ld de,(WRK+$07a)            ; 8979
	ld c,(ix+1)                 ; 897d
	ld b,(ix+2)                 ; 8980
	call L893d                  ; 8983
	jp c,L8993                  ; 8986
	ld (ix+0),$00               ; 8989
	call L8999                  ; 898d
	call L8b3b                  ; 8990
L8993:
	exx                         ; 8993
	add ix,de                   ; 8994
	djnz L8968                  ; 8996
	ret                         ; 8998
L8999:
	ld (ix+0),$02               ; 8999
	ld (ix+9),$01               ; 899d
	xor a                       ; 89a1
	jp L9600                    ; 89a2
	db $00                      ; 89a5
L89a6:
	dec (ix+3)                  ; 89a6
	dec (ix+3)                  ; 89a9
	ret p                       ; 89ac
L89ad:
	ld (ix+0),$00               ; 89ad
	ret                         ; 89b1
L89b2:
	ld hl,(WRK+$07d)            ; 89b2
	ld (VRAM+$d00),hl           ; 89b5
	ld a,(WRK+$089)             ; 89b8
	dec a                       ; 89bb
	jp z,L89d5                  ; 89bc
	dec a                       ; 89bf
	jp z,L89d5                  ; 89c0
	ld a,(ix+3)                 ; 89c3
	ld (VRAM+$d02),a            ; 89c6
	ld hl,VRAM+$d27             ; 89c9
	ld de,VRAM+$d2a             ; 89cc
	ld bc,$002b                 ; 89cf
	lddr                        ; 89d2
	ret                         ; 89d4
L89d5:
	ld b,$0e                    ; 89d5
	ld hl,VRAM+$d27             ; 89d7
	ld de,VRAM+$d2a             ; 89da
L89dd:
	ld a,(hl)                   ; 89dd
	ld (de),a                   ; 89de
	dec de                      ; 89df
	dec de                      ; 89e0
	dec hl                      ; 89e1
	dec hl                      ; 89e2
	ld a,(hl)                   ; 89e3
	ld (de),a                   ; 89e4
	dec de                      ; 89e5
	dec hl                      ; 89e6
	djnz L89dd                  ; 89e7
	ret                         ; 89e9
L89ea:
	inc (ix+3)                  ; 89ea
	ld a,(ix+3)                 ; 89ed
	cp $1d                      ; 89f0
	jp nc,L89ad                 ; 89f2
L89f5:
	ld a,(ix+17)                ; 89f5
	add a,(ix+4)                ; 89f8
	ld (ix+4),a                 ; 89fb
	cp $0c                      ; 89fe
	jr c,L8a0c                  ; 8a00
	cp $15                      ; 8a02
	jr c,L8a10                  ; 8a04
	ld (ix+17),$fe              ; 8a06
	jr L8a10                    ; 8a0a
L8a0c:
	ld (ix+17),$02              ; 8a0c
L8a10:
	ld a,(ix+18)                ; 8a10
	add a,(ix+5)                ; 8a13
	ld (ix+5),a                 ; 8a16
	cp $10                      ; 8a19
	jr nc,L8a22                 ; 8a1b
	ld (ix+18),$03              ; 8a1d
	ret                         ; 8a21
L8a22:
	cp $25                      ; 8a22
	ret c                       ; 8a24
	ld (ix+18),$fe              ; 8a25
	ret                         ; 8a29
L8a2a:
	ld a,(ix+21)                ; 8a2a
	or a                        ; 8a2d
	jp nz,L8a44                 ; 8a2e
	dec (ix+3)                  ; 8a31
	jp p,L89f5                  ; 8a34
	ld (ix+3),$01               ; 8a37
	inc (ix+21)                 ; 8a3b
	ld a,$01                    ; 8a3e
	ld (WRK+$266),a             ; 8a40
	ret                         ; 8a43
L8a44:
	inc (ix+3)                  ; 8a44
	ld a,(ix+3)                 ; 8a47
	cp $06                      ; 8a4a
	jp c,L89f5                  ; 8a4c
	inc (ix+16)                 ; 8a4f
	ld (ix+6),$00               ; 8a52
	ret                         ; 8a56
L8a57:
	ld a,(WRK+$265)             ; 8a57
	or a                        ; 8a5a
	jp z,L8a6b                  ; 8a5b
	ld (ix+16),$02              ; 8a5e
	ld (ix+20),$7f              ; 8a62
	xor a                       ; 8a66
	ld (WRK+$266),a             ; 8a67
	ret                         ; 8a6a
L8a6b:
	ld a,$07                    ; 8a6b
	call VZ_KBROW               ; 8a6d patched
	ld c,a                      ; 8a73
	ld a,(ix+5)                 ; 8a74
	bit 2,c                     ; 8a77
	jp nz,L8a87                 ; 8a79
	cp $0e                      ; 8a7c
	jp c,L8a87                  ; 8a7e
	dec (ix+5)                  ; 8a81
	dec (ix+5)                  ; 8a84
L8a87:
	bit 3,c                     ; 8a87
	jp nz,L8a97                 ; 8a89
	cp $26                      ; 8a8c
	jp nc,L8a97                 ; 8a8e
	inc (ix+5)                  ; 8a91
	inc (ix+5)                  ; 8a94
L8a97:
	call L8ab4                  ; 8a97
	ld a,(ix+17)                ; 8a9a
	add a,(ix+4)                ; 8a9d
	ld (ix+4),a                 ; 8aa0
	cp $0c                      ; 8aa3
	jr c,L8aaf                  ; 8aa5
	cp $15                      ; 8aa7
	ret c                       ; 8aa9
	ld (ix+17),$fe              ; 8aaa
	ret                         ; 8aae
L8aaf:
	ld (ix+17),$02              ; 8aaf
	ret                         ; 8ab3
L8ab4:
	dec (ix+21)                 ; 8ab4
	ld a,(ix+21)                ; 8ab7
	and $07                     ; 8aba
	ld c,$01                    ; 8abc
	cp $04                      ; 8abe
	jr c,L8ac4                  ; 8ac0
	ld c,$ff                    ; 8ac2
L8ac4:
	ld a,(ix+5)                 ; 8ac4
	add a,c                     ; 8ac7
	ld (ix+5),a                 ; 8ac8
	ret                         ; 8acb
L8acc:
	call L89b2                  ; 8acc
	ld a,(ix+16)                ; 8acf
	dec a                       ; 8ad2
	jp m,L8a2a                  ; 8ad3
	jp z,L8a57                  ; 8ad6
	sub $02                     ; 8ad9
	jp m,L8ae8                  ; 8adb
	jp z,L89ea                  ; 8ade
	dec a                       ; 8ae1
	jp z,L8a2a                  ; 8ae2
	jp L89ea                    ; 8ae5
L8ae8:
	xor a                       ; 8ae8
	ld (WRK+$266),a             ; 8ae9
	dec (ix+20)                 ; 8aec
	jp p,L8a10                  ; 8aef
	ld (ix+16),$03              ; 8af2
	ret                         ; 8af6
L8af7:
	ld a,(ix+16)                ; 8af7
	add a,a                     ; 8afa
	add a,(ix+16)               ; 8afb
	ld e,a                      ; 8afe
	ld d,$00                    ; 8aff
	ld hl,VRAM+$d00             ; 8b01
	add hl,de                   ; 8b04
	ld e,(hl)                   ; 8b05
	inc hl                      ; 8b06
	ld d,(hl)                   ; 8b07
	inc hl                      ; 8b08
	ld a,(hl)                   ; 8b09
	ld (ix+4),e                 ; 8b0a
	ld (ix+5),d                 ; 8b0d
	ld (ix+3),a                 ; 8b10
	ld a,(WRK+$079)             ; 8b13
	or a                        ; 8b16
	ret nz                      ; 8b17
	ld (ix+0),$00               ; 8b18
	ret                         ; 8b1c
L8b1d:
	ld a,(ix+3)                 ; 8b1d
	cp $02                      ; 8b20
	jp nc,L8b2e                 ; 8b22
	dec (ix+16)                 ; 8b25
	ret p                       ; 8b28
	ld (ix+0),$00               ; 8b29
	ret                         ; 8b2d
L8b2e:
	dec (ix+3)                  ; 8b2e
	ret                         ; 8b31
L8b32:
	ld a,(WRK+$089)             ; 8b32
	cp $02                      ; 8b35
	jp z,L8b4f                  ; 8b37
	ret                         ; 8b3a
L8b3b:
	ld a,(WRK+$262)             ; 8b3b
	add a,$01                   ; 8b3e
	daa                         ; 8b40
	ld (WRK+$262),a             ; 8b41
	ld hl,WRK+$263              ; 8b44
	inc (hl)                    ; 8b47
	ret                         ; 8b48
L8b49:
	ld a,$03                    ; 8b49
	ld (WRK+$089),a             ; 8b4b
	ret                         ; 8b4e
L8b4f:
	ld hl,WRK+$264              ; 8b4f
	dec (hl)                    ; 8b52
	ret p                       ; 8b53
	ld (hl),$07                 ; 8b54
	ld a,(WRK+$263)             ; 8b56
	dec a                       ; 8b59
	jp m,L8b49                  ; 8b5a
	ld (WRK+$263),a             ; 8b5d
	ld a,(WRK+$262)             ; 8b60
	sub $01                     ; 8b63
	daa                         ; 8b65
	ld (WRK+$262),a             ; 8b66
	ld de,$5000                 ; 8b69
	jp L8cf8                    ; 8b6c
L8b6f:
	ld a,(WRK+$263)             ; 8b6f
	dec a                       ; 8b72
	ret m                       ; 8b73
	ld ix,BUF+$359              ; 8b74
	ld a,(WRK+$262)             ; 8b78
	and $f0                     ; 8b7b
	jp z,L8b93                  ; 8b7d
	rlca                        ; 8b80
	rlca                        ; 8b81
	rlca                        ; 8b82
	rlca                        ; 8b83
	ld b,a                      ; 8b84
L8b85:
	ld (ix+0),$46               ; 8b85
	ld (ix+64),$02              ; 8b89
	inc ix                      ; 8b8d
	inc ix                      ; 8b8f
	djnz L8b85                  ; 8b91
L8b93:
	ld ix,BUF+$419              ; 8b93
	ld a,(WRK+$262)             ; 8b97
	and $0f                     ; 8b9a
	ret z                       ; 8b9c
	ld b,a                      ; 8b9d
L8b9e:
	ld (ix+0),$64               ; 8b9e
	inc ix                      ; 8ba2
	djnz L8b9e                  ; 8ba4
	ret                         ; 8ba6
L8ba7:
	db $55                      ; 8ba7
L8ba8:
	ld hl,L8ba7                 ; 8ba8
	rlc (hl)                    ; 8bab
	ret c                       ; 8bad
	ld ix,WRK+$079              ; 8bae
	ld b,$10                    ; 8bb2
	ld de,$0018                 ; 8bb4
L8bb7:
	exx                         ; 8bb7
	ld a,(WRK+$068)             ; 8bb8
	cp (ix+13)                  ; 8bbb
	jp c,L8bef                  ; 8bbe
	ld a,(ix+0)                 ; 8bc1
	or a                        ; 8bc4
	jp z,L8bef                  ; 8bc5
	bit 7,(ix+7)                ; 8bc8
	jp nz,L8bd5                 ; 8bcc
	dec (ix+7)                  ; 8bcf
	jp L8bef                    ; 8bd2
L8bd5:
	ld a,(ix+11)                ; 8bd5
	cp $31                      ; 8bd8
	jp nc,L8bef                 ; 8bda
	dec a                       ; 8bdd
	add a,a                     ; 8bde
	ld e,a                      ; 8bdf
	ld d,$00                    ; 8be0
	ld hl,L8c03                 ; 8be2
	add hl,de                   ; 8be5
	ld e,(hl)                   ; 8be6
	inc hl                      ; 8be7
	ld d,(hl)                   ; 8be8
	ex de,hl                    ; 8be9
	ld de,L8bef                 ; 8bea
	push de                     ; 8bed
	jp (hl)                     ; 8bee
L8bef:
	exx                         ; 8bef
	add ix,de                   ; 8bf0
	djnz L8bb7                  ; 8bf2
	ld ix,WRK+$091              ; 8bf4
	ld b,$06                    ; 8bf8
L8bfa:
	ld (ix+6),$00               ; 8bfa
	add ix,de                   ; 8bfe
	djnz L8bfa                  ; 8c00
	ret                         ; 8c02
L8c03:
	dw L8acc                    ; 8c03
	dw L8af7                    ; 8c05
	dw L89a6                    ; 8c07
	dw L8ce6                    ; 8c09
	dw L8b1d                    ; 8c0b
L8c0d:
	ld hl,WRK+$079              ; 8c0d
	ld de,WRK+$07a              ; 8c10
	ld bc,$0180                 ; 8c13
	ld (hl),$00                 ; 8c16
	ldir                        ; 8c18
	ret                         ; 8c1a
L8c1b:
	call L8c0d                  ; 8c1b
	ld de,WRK+$079              ; 8c1e
	ld hl,L8c86                 ; 8c21
	ld bc,$0018                 ; 8c24
	ldir                        ; 8c27
	ld a,$07                    ; 8c29
	ld de,WRK+$091              ; 8c2b
L8c2e:
	ld hl,L8c9e                 ; 8c2e
	ld bc,$0018                 ; 8c31
	ldir                        ; 8c34
	dec a                       ; 8c36
	jr nz,L8c2e                 ; 8c37
	ld ix,WRK+$091              ; 8c39
	ld de,$0018                 ; 8c3d
	ld b,$07                    ; 8c40
L8c42:
	ld a,b                      ; 8c42
	ld (ix+7),a                 ; 8c43
	add ix,de                   ; 8c46
	djnz L8c42                  ; 8c48
	ld (ix-18),$02              ; 8c4a
	ret                         ; 8c4e
L8c4f:
	call L8c0d                  ; 8c4f
	ld de,WRK+$079              ; 8c52
	ld hl,L8cb6                 ; 8c55
	ld bc,$0018                 ; 8c58
	ldir                        ; 8c5b
	ld a,$06                    ; 8c5d
	ld de,WRK+$091              ; 8c5f
L8c62:
	ld hl,L8cce                 ; 8c62
	ld bc,$0018                 ; 8c65
	ldir                        ; 8c68
	dec a                       ; 8c6a
	jr nz,L8c62                 ; 8c6b
	ld ix,WRK+$091              ; 8c6d
	ld de,$0018                 ; 8c71
	ld b,$06                    ; 8c74
L8c76:
	ld a,b                      ; 8c76
	ld (ix+7),a                 ; 8c77
	ld (ix+16),a                ; 8c7a
	add ix,de                   ; 8c7d
	djnz L8c76                  ; 8c7f
	ld (ix-18),$02              ; 8c81
	ret                         ; 8c85
L8c86:
	db $04,$00,$00,$1b,$10,$10,$02,$00,$01,$01,$00,$01,$00,$05,$01,$00; 8c86
	db $04,$02,$02,$00,$00,$00,$00,$00; 8c96
L8c9e:
	db $05,$00,$00,$1b,$10,$10,$01,$02,$01,$01,$00,$01,$00,$05,$01,$00; 8c9e
	db $04,$02,$02,$00,$00,$00,$00,$00; 8cae
L8cb6:
	db $04,$00,$00,$1b,$10,$10,$02,$00,$01,$01,$00,$01,$00,$05,$01,$00; 8cb6
	db $00,$02,$02,$00,$00,$00,$00,$00; 8cc6
L8cce:
	db $05,$00,$00,$1b,$10,$10,$01,$02,$01,$01,$00,$02,$00,$05,$01,$00; 8cce
	db $00,$02,$02,$00,$00,$00,$00,$00; 8cde
L8ce6:
	inc (ix+4)                  ; 8ce6
	inc (ix+4)                  ; 8ce9
	inc (ix+4)                  ; 8cec
	dec (ix+3)                  ; 8cef
	ret p                       ; 8cf2
	ld (ix+0),$00               ; 8cf3
	ret                         ; 8cf7
L8cf8:
	ld a,$15                    ; 8cf8
	jp La000                    ; 8cfa
L8cfd:
	ld a,(ix+3)                 ; 8cfd
	sub (ix+1)                  ; 8d00
	ld c,$00                    ; 8d03
	jp z,L8d15                  ; 8d05
	ld c,$2c                    ; 8d08
	jp nc,L8d15                 ; 8d0a
	ld a,(ix+1)                 ; 8d0d
	sub (ix+3)                  ; 8d10
	ld c,$2d                    ; 8d13
L8d15:
	inc a                       ; 8d15
	ld d,a                      ; 8d16
	ld b,a                      ; 8d17
	ld a,c                      ; 8d18
	ld (L8d86),a                ; 8d19
	ld hl,$0000                 ; 8d1c
	ld c,l                      ; 8d1f
	ld a,(ix+2)                 ; 8d20
	sub (ix+0)                  ; 8d23
	jp z,L8d38                  ; 8d26
	ld hl,$0040                 ; 8d29
	jp nc,L8d38                 ; 8d2c
	ld a,(ix+0)                 ; 8d2f
	sub (ix+2)                  ; 8d32
	ld hl,$ffc0                 ; 8d35
L8d38:
	inc a                       ; 8d38
	ld e,a                      ; 8d39
	ld (L8d6d+1),hl             ; 8d3a
	ld (L8d81+1),hl             ; 8d3d
	ld l,(ix+0)                 ; 8d40
	ld h,(ix+1)                 ; 8d43
	push de                     ; 8d46
	ld e,h                      ; 8d47
	ld d,$00                    ; 8d48
	ld h,d                      ; 8d4a
	add hl,hl                   ; 8d4b
	add hl,hl                   ; 8d4c
	add hl,hl                   ; 8d4d
	add hl,hl                   ; 8d4e
	add hl,hl                   ; 8d4f
	add hl,hl                   ; 8d50
	add hl,de                   ; 8d51
	ld de,BUF+$000              ; 8d52
	add hl,de                   ; 8d55
	pop de                      ; 8d56
L8d57:
	bit 7,(hl)                  ; 8d57
L8d59:
	ld (hl),$00                 ; 8d59
	jp z,L8d60                  ; 8d5b
L8d5e:
	ld (hl),$00                 ; 8d5e
L8d60:
	ld a,c                      ; 8d60
	add a,e                     ; 8d61
	ld c,a                      ; 8d62
L8d63:
	ld a,c                      ; 8d63
	sub d                       ; 8d64
	jp z,L8d7e                  ; 8d65
	jp c,L8d86                  ; 8d68
	ld c,a                      ; 8d6b
	push bc                     ; 8d6c
L8d6d:
	ld bc,$0000                 ; 8d6d
	add hl,bc                   ; 8d70
	pop bc                      ; 8d71
	bit 7,(hl)                  ; 8d72
L8d74:
	ld (hl),$74                 ; 8d74
	jp z,L8d7b                  ; 8d76
L8d79:
	ld (hl),$14                 ; 8d79
L8d7b:
	jp L8d63                    ; 8d7b
L8d7e:
	ld c,$00                    ; 8d7e
	push bc                     ; 8d80
L8d81:
	ld bc,$0000                 ; 8d81
	add hl,bc                   ; 8d84
	pop bc                      ; 8d85
L8d86:
	nop                         ; 8d86
	djnz L8d57                  ; 8d87
	ret                         ; 8d89
L8d8a:
	nop                         ; 8d8a
	call L8e57                  ; 8d8b
	call L8e2e                  ; 8d8e
L8d91:
	ld a,(WRK+$268)             ; 8d91
	ld (L8d59+1),a              ; 8d94
	ld (L8d74+1),a              ; 8d97
	ld a,(WRK+$267)             ; 8d9a
	ld (L8d5e+1),a              ; 8d9d
	ld (L8d79+1),a              ; 8da0
	ld ix,L9f00                 ; 8da3
	ld b,$10                    ; 8da7
	ld de,$0004                 ; 8da9
L8dac:
	exx                         ; 8dac
	call L8cfd                  ; 8dad
	exx                         ; 8db0
	add ix,de                   ; 8db1
	djnz L8dac                  ; 8db3
	ld a,(WRK+$062)             ; 8db5
	cp $04                      ; 8db8
	jp z,L8dc5                  ; 8dba
	cp $09                      ; 8dbd
	jp z,L8dc5                  ; 8dbf
	cp $0e                      ; 8dc2
	ret nz                      ; 8dc4
L8dc5:
	ld b,$10                    ; 8dc5
L8dc7:
	exx                         ; 8dc7
	call L8cfd                  ; 8dc8
	exx                         ; 8dcb
	add ix,de                   ; 8dcc
	djnz L8dc7                  ; 8dce
	ret                         ; 8dd0
L8dd1:
	ld hl,L9f00                 ; 8dd1
	ld de,L9f01                 ; 8dd4
	ld bc,$0084                 ; 8dd7
	ld (hl),$00                 ; 8dda
	ldir                        ; 8ddc
	ld ix,L9f00                 ; 8dde
	ld iy,L8e2a                 ; 8de2
	ld de,$0004                 ; 8de6
	ld c,e                      ; 8de9
L8dea:
	ld b,e                      ; 8dea
L8deb:
	ld a,(iy+0)                 ; 8deb
	add a,b                     ; 8dee
	ld (ix+3),a                 ; 8def
	ld (ix+2),$1e               ; 8df2
	ld (ix+1),$20               ; 8df6
	ld (ix+0),$12               ; 8dfa
	add ix,de                   ; 8dfe
	djnz L8deb                  ; 8e00
	inc iy                      ; 8e02
	dec c                       ; 8e04
	jr nz,L8dea                 ; 8e05
	ld iy,L8e2a                 ; 8e07
	ld c,e                      ; 8e0b
L8e0c:
	ld b,e                      ; 8e0c
L8e0d:
	ld a,(iy+0)                 ; 8e0d
	add a,b                     ; 8e10
	ld (ix+3),a                 ; 8e11
	ld (ix+2),$06               ; 8e14
	ld (ix+1),$20               ; 8e18
	ld (ix+0),$12               ; 8e1c
	add ix,de                   ; 8e20
	djnz L8e0d                  ; 8e22
	inc iy                      ; 8e24
	dec c                       ; 8e26
	jr nz,L8e0c                 ; 8e27
	ret                         ; 8e29
L8e2a:
	db $00,$10,$20,$30          ; 8e2a
L8e2e:
	ld a,(WRK+$066)             ; 8e2e
	ld c,a                      ; 8e31
	ld a,$1b                    ; 8e32
	sub c                       ; 8e34
	ld hl,L9f00                 ; 8e35
	ld b,$10                    ; 8e38
	ld de,$0004                 ; 8e3a
L8e3d:
	ld (hl),a                   ; 8e3d
	add hl,de                   ; 8e3e
	djnz L8e3d                  ; 8e3f
	ld a,(WRK+$04e)             ; 8e41
	ld e,a                      ; 8e44
	ld a,(WRK+$066)             ; 8e45
	ld c,a                      ; 8e48
	ld a,$19                    ; 8e49
	sub c                       ; 8e4b
	sub e                       ; 8e4c
	ld b,$10                    ; 8e4d
	ld de,$0004                 ; 8e4f
L8e52:
	ld (hl),a                   ; 8e52
	add hl,de                   ; 8e53
	djnz L8e52                  ; 8e54
	ret                         ; 8e56
L8e57:
	ld a,(WRK+$05d)             ; 8e57
	sub $0c                     ; 8e5a
	sra a                       ; 8e5c
	sra a                       ; 8e5e
	add a,a                     ; 8e60
	ld e,a                      ; 8e61
	ld d,$00                    ; 8e62
	ld hl,L8e90                 ; 8e64
	add hl,de                   ; 8e67
	ld c,(hl)                   ; 8e68
	inc hl                      ; 8e69
	ld a,(hl)                   ; 8e6a
	ld (L8e77+1),a              ; 8e6b
L8e6e:
	ld hl,L9f03                 ; 8e6e
	ld b,$20                    ; 8e71
	ld de,$0004                 ; 8e73
L8e76:
	ld a,(hl)                   ; 8e76
L8e77:
	add a,$00                   ; 8e77
	ld (hl),a                   ; 8e79
	jp p,L8e82                  ; 8e7a
	ld (hl),$3f                 ; 8e7d
	jp L8e88                    ; 8e7f
L8e82:
	cp $40                      ; 8e82
	jp c,L8e88                  ; 8e84
	ld (hl),d                   ; 8e87
L8e88:
	add hl,de                   ; 8e88
	djnz L8e76                  ; 8e89
	dec c                       ; 8e8b
	jp nz,L8e6e                 ; 8e8c
	ret                         ; 8e8f
L8e90:
	db $03,$01,$02,$01,$02,$01,$01,$01,$01,$00,$01,$00,$01,$ff,$02,$ff; 8e90
	db $02,$ff,$03,$ff,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 8ea0
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 8eb0
	db $ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff; 8ec0
	db $ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff; 8ed0
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 8ee0
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 8ef0
	db $ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 8f00
	db $ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 8f10
	db $ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 8f20
	db $ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 8f30
	db $ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 8f40
	db $ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 8f50
	db $ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 8f60
	db $ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 8f70
	db $00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff; 8f80
	db $00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff; 8f90
	db $00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff; 8fa0
	db $00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff; 8fb0
	db $00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff; 8fc0
	db $00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff; 8fd0
	db $00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff; 8fe0
	db $00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff; 8ff0
La000:
	dec a                       ; a000
	add a,a                     ; a001
	push de                     ; a002
	push hl                     ; a003
	ld e,a                      ; a004
	ld d,$00                    ; a005
	ld hl,La017                 ; a007
	add hl,de                   ; a00a
	ld e,(hl)                   ; a00b
	inc hl                      ; a00c
	ld d,(hl)                   ; a00d
	ld (La014+1),de             ; a00e
	pop hl                      ; a012
	pop de                      ; a013
La014:
	jp Lb116                    ; a014
La017:
	dw Lafdc                    ; a017
	dw Lb327                    ; a019
	dw Lb2bb                    ; a01b
	dw Lb242                    ; a01d
	dw Lb0ce                    ; a01f
	dw Lb186                    ; a021
	dw Lb371                    ; a023
	dw Lb01a                    ; a025
	dw Lb01b                    ; a027
	dw Lb373                    ; a029
	dw Lad3d                    ; a02b
	dw Lb393                    ; a02d
	dw Lb4e6                    ; a02f
	dw Lb243                    ; a031
	dw Lb07c                    ; a033
	dw Lb372                    ; a035
	dw Lb0a9                    ; a037
	dw Laaaf                    ; a039
	dw Laa4d                    ; a03b
	dw Laa4e                    ; a03d
	dw Laa51                    ; a03f
	dw Laab0                    ; a041
	dw Laad8                    ; a043
	dw Lab17                    ; a045
	dw Lab53                    ; a047
	dw Labae                    ; a049
	dw Lac67                    ; a04b
	dw La99b                    ; a04d
	dw La882                    ; a04f
	dw La86b                    ; a051
	dw La081                    ; a053
	dw La091                    ; a055
	dw Laa7a                    ; a057
	dw La349                    ; a059
	dw La35d                    ; a05b
	dw La38d                    ; a05d
	dw La06d                    ; a05f
	dw Lb64d                    ; a061
	dw Lb775                    ; a063
	dw Lb7a9                    ; a065
	dw Lb7aa                    ; a067
	dw Lb7ab                    ; a069
	dw Lb116                    ; a06b
La06d:
	ld hl,L4000                 ; a06d
	ld bc,$3fff                 ; a070
	ld de,$33ff                 ; a073
La076:
	ld a,(hl)                   ; a076
	cp d                        ; a077
	jr nz,La07b                 ; a078
	ld (hl),e                   ; a07a
La07b:
	cpi                         ; a07b
	jp pe,La076                 ; a07d
	ret                         ; a080
La081:
	ld hl,VRAM+$028             ; a081
	ld de,VRAM+$029             ; a084
	ld bc,$03e8                 ; a087
	ld a,(WRK+$3ff)             ; a08a
	ld (hl),a                   ; a08d
	ldir                        ; a08e
	ret                         ; a090
La091:
	ld a,(WRK+$062)             ; a091
	dec a                       ; a094
	add a,a                     ; a095
	ld e,a                      ; a096
	ld d,$00                    ; a097
	ld hl,La0a5                 ; a099
	add hl,de                   ; a09c
	ld e,(hl)                   ; a09d
	inc hl                      ; a09e
	ld d,(hl)                   ; a09f
	ld (WRK+$077),de            ; a0a0
	ret                         ; a0a4
La0a5:
	dw La0c9                    ; a0a5
	dw La0f1                    ; a0a7
	dw La119                    ; a0a9
	dw La141                    ; a0ab
	dw La321                    ; a0ad
	dw La169                    ; a0af
	dw La191                    ; a0b1
	dw La1b9                    ; a0b3
	dw La1e1                    ; a0b5
	dw La209                    ; a0b7
	dw La231                    ; a0b9
	dw La321                    ; a0bb
	dw La259                    ; a0bd
	dw La281                    ; a0bf
	dw La2a9                    ; a0c1
	dw La2d1                    ; a0c3
	dw La2f9                    ; a0c5
	dw La321                    ; a0c7
La0c9:
	db $02,$00,$00,$00,$01,$00,$00,$00,$00,$00,$04,$00,$03,$00,$23,$00; a0c9
	db $00,$00,$00,$00,$06,$00,$00,$00,$05,$06,$00,$00,$23,$00,$00,$00; a0d9
	db $00,$00,$00,$00,$00,$00,$00,$00; a0e9
La0f1:
	db $11,$00,$10,$00,$00,$13,$00,$00,$0f,$00,$1e,$21,$00,$00,$00,$00; a0f1
	db $11,$00,$10,$00,$13,$00,$00,$00,$00,$00,$00,$00,$1d,$20,$00,$00; a101
	db $00,$00,$00,$00,$00,$00,$00,$00; a111
La119:
	db $15,$00,$08,$00,$03,$00,$00,$00,$09,$00,$0a,$00,$00,$00,$15,$00; a119
	db $04,$00,$00,$00,$12,$00,$00,$00,$15,$00,$12,$00,$00,$00,$12,$00; a129
	db $14,$00,$14,$00,$00,$00,$00,$00; a139
La141:
	db $00,$00,$00,$00,$00,$00,$03,$00,$00,$00,$00,$00,$00,$00,$03,$00; a141
	db $00,$00,$00,$00,$00,$00,$08,$00,$00,$00,$00,$00,$00,$00,$05,$06; a151
	db $00,$00,$00,$00,$00,$00,$00,$00; a161
La169:
	db $16,$00,$18,$00,$19,$00,$19,$00,$18,$00,$19,$00,$26,$27,$00,$00; a169
	db $18,$00,$18,$00,$19,$00,$1a,$00,$19,$00,$1a,$00,$00,$00,$16,$27; a179
	db $00,$00,$2a,$00,$00,$00,$00,$00; a189
La191:
	db $17,$00,$0d,$00,$00,$00,$2c,$00,$2c,$00,$00,$00,$0c,$00,$23,$00; a191
	db $00,$00,$00,$00,$26,$27,$00,$00,$0b,$00,$0d,$00,$2d,$00,$26,$00; a1a1
	db $00,$00,$2b,$00,$00,$00,$00,$00; a1b1
La1b9:
	db $1f,$22,$00,$00,$00,$00,$0d,$00,$0d,$00,$00,$00,$27,$2c,$00,$00; a1b9
	db $23,$00,$00,$00,$00,$00,$1d,$20,$0d,$00,$00,$00,$27,$00,$00,$00; a1c9
	db $29,$00,$2f,$00,$00,$00,$00,$00; a1d9
La1e1:
	db $00,$00,$00,$00,$00,$00,$04,$00,$00,$00,$00,$00,$00,$00,$07,$00; a1e1
	db $00,$00,$00,$00,$00,$00,$08,$00,$00,$00,$00,$00,$00,$00,$05,$06; a1f1
	db $00,$00,$00,$00,$00,$00,$00,$00; a201
La209:
	db $00,$00,$1a,$00,$07,$00,$08,$00,$01,$00,$00,$00,$03,$04,$19,$00; a209
	db $1a,$00,$00,$00,$15,$00,$07,$08,$00,$00,$07,$08,$15,$00,$00,$00; a219
	db $1a,$00,$19,$00,$00,$00,$00,$00; a229
La231:
	db $26,$00,$2c,$00,$00,$00,$31,$00,$25,$00,$24,$00,$30,$00,$00,$00; a231
	db $2d,$00,$2a,$2b,$00,$00,$2c,$00,$28,$29,$2e,$00,$32,$00,$2a,$2b; a241
	db $28,$29,$2f,$00,$00,$00,$00,$00; a251
La259:
	db $00,$00,$1c,$00,$1b,$00,$00,$00,$0a,$00,$09,$00,$00,$00,$18,$00; a259
	db $00,$00,$00,$00,$00,$00,$04,$33,$00,$00,$2b,$00,$00,$00,$29,$00; a269
	db $2b,$00,$00,$00,$00,$00,$00,$00; a279
La281:
	db $00,$00,$00,$00,$00,$00,$04,$00,$00,$00,$00,$00,$00,$00,$04,$00; a281
	db $00,$00,$00,$00,$00,$00,$03,$00,$00,$00,$00,$00,$00,$00,$05,$06; a291
	db $00,$00,$00,$00,$00,$00,$00,$00; a2a1
La2a9:
	db $23,$00,$00,$00,$00,$00,$0d,$00,$0d,$00,$00,$00,$2b,$00,$34,$00; a2a9
	db $00,$00,$1d,$20,$29,$00,$00,$00,$1d,$20,$2b,$00,$00,$00,$2b,$00; a2b9
	db $2b,$00,$00,$00,$00,$00,$00,$00; a2c9
La2d1:
	db $27,$00,$26,$00,$31,$00,$2f,$00,$24,$25,$30,$00,$2a,$2b,$2d,$00; a2d1
	db $28,$29,$32,$00,$2c,$00,$2d,$00,$2a,$00,$29,$00,$2b,$00,$2b,$00; a2e1
	db $2a,$2b,$28,$29,$00,$00,$00,$00; a2f1
La2f9:
	db $00,$00,$1f,$22,$00,$00,$0d,$00,$0d,$00,$00,$00,$2b,$00,$00,$00; a2f9
	db $32,$00,$28,$00,$00,$00,$1e,$21,$00,$00,$2b,$00,$2e,$00,$00,$00; a309
	db $28,$00,$00,$00,$00,$00,$00,$00; a319
La321:
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; a321
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; a331
	db $00,$00,$00,$00,$00,$00,$00,$00; a341
La349:
	ld b,$10                    ; a349
	ld de,$0018                 ; a34b
	ld ix,WRK+$079              ; a34e
La352:
	ld a,(ix+0)                 ; a352
	or a                        ; a355
	ret z                       ; a356
	add ix,de                   ; a357
	djnz La352                  ; a359
	scf                         ; a35b
	ret                         ; a35c
La35d:
	dec (ix+3)                  ; a35d
	jp m,Lac44                  ; a360
	bit 0,(ix+9)                ; a363
	jp z,La37f                  ; a367
	ld a,(ix+4)                 ; a36a
	cp $14                      ; a36d
	jp nc,La37f                 ; a36f
	add a,$03                   ; a372
	ld (ix+4),a                 ; a374
	cp $14                      ; a377
	ret c                       ; a379
	ld (ix+4),$14               ; a37a
	ret                         ; a37e
La37f:
	rlc (ix+16)                 ; a37f
	ret c                       ; a383
	dec (ix+6)                  ; a384
	ret p                       ; a387
	ld (ix+0),$00               ; a388
	ret                         ; a38c
La38d:
	ld iy,(WRK+$077)            ; a38d
	call La3a0                  ; a391
	inc iy                      ; a394
	call La3a0                  ; a396
	inc iy                      ; a399
	ld (WRK+$077),iy            ; a39b
	ret                         ; a39f
La3a0:
	ld a,(iy+0)                 ; a3a0
	dec a                       ; a3a3
	ret m                       ; a3a4
	ld e,a                      ; a3a5
	ld d,$00                    ; a3a6
	ld hl,La5c6                 ; a3a8
	add hl,de                   ; a3ab
	ld a,(hl)                   ; a3ac
	ld (La3cb),a                ; a3ad
La3b0:
	call La349                  ; a3b0
	ret c                       ; a3b3
	call La425                  ; a3b4
	call La3ee                  ; a3b7
	call La461                  ; a3ba
	call La3cc                  ; a3bd
	ld a,(La3cb)                ; a3c0
	dec a                       ; a3c3
	ld (La3cb),a                ; a3c4
	jp nz,La3b0                 ; a3c7
	ret                         ; a3ca
La3cb:
	db $00                      ; a3cb
La3cc:
	ld a,(iy+0)                 ; a3cc
	cp $24                      ; a3cf
	ret c                       ; a3d1
	cp $28                      ; a3d2
	ld a,$01                    ; a3d4
	jp c,L9600                  ; a3d6
	ld a,(iy+0)                 ; a3d9
	cp $2b                      ; a3dc
	ld a,$02                    ; a3de
	jp c,L9600                  ; a3e0
	ld a,(iy+0)                 ; a3e3
	cp $2e                      ; a3e6
	ld a,$02                    ; a3e8
	jp c,L9600                  ; a3ea
	ret                         ; a3ed
La3ee:
	ld a,(iy+0)                 ; a3ee
	dec a                       ; a3f1
	add a,a                     ; a3f2
	ld e,a                      ; a3f3
	ld d,$00                    ; a3f4
	ld hl,La643                 ; a3f6
	add hl,de                   ; a3f9
	ld e,(hl)                   ; a3fa
	inc hl                      ; a3fb
	ld d,(hl)                   ; a3fc
	ex de,hl                    ; a3fd
	ld de,La41e                 ; a3fe
	ld b,$07                    ; a401
La403:
	ld a,(de)                   ; a403
	ld (La408+2),a              ; a404
	ld a,(hl)                   ; a407
La408:
	ld (ix+13),a                ; a408
	ld a,(La3cb)                ; a40b
	ld c,a                      ; a40e
	ld a,$03                    ; a40f
	sub c                       ; a411
	add a,a                     ; a412
	add a,a                     ; a413
	add a,a                     ; a414
	dec a                       ; a415
	ld (ix+7),a                 ; a416
	inc de                      ; a419
	inc hl                      ; a41a
	djnz La403                  ; a41b
	ret                         ; a41d
La41e:
	db $03,$04,$05,$06,$0a,$0b,$0d; a41e
La425:
	ld a,(iy+0)                 ; a425
	dec a                       ; a428
	ld e,a                      ; a429
	ld d,$00                    ; a42a
	ld hl,La607                 ; a42c
	add hl,de                   ; a42f
	ld a,(hl)                   ; a430
	ld (ix+0),a                 ; a431
	ld (ix+8),$00               ; a434
	ld a,(iy+0)                 ; a438
	cp $24                      ; a43b
	ld a,$00                    ; a43d
	adc a,$00                   ; a43f
	ld (ix+9),a                 ; a441
	ld (ix+12),$00              ; a444
	ld (ix+14),$01              ; a448
	ld (ix+16),$00              ; a44c
	ld (ix+17),$00              ; a450
	ld (ix+18),$00              ; a454
	ld (ix+19),$00              ; a458
	ld (ix+20),$00              ; a45c
	ret                         ; a460
La461:
	ld a,(iy+0)                 ; a461
	dec a                       ; a464
	add a,a                     ; a465
	ld e,a                      ; a466
	ld d,$00                    ; a467
	ld hl,La472                 ; a469
	add hl,de                   ; a46c
	ld e,(hl)                   ; a46d
	inc hl                      ; a46e
	ld d,(hl)                   ; a46f
	ex de,hl                    ; a470
	jp (hl)                     ; a471
La472:
	dw La520                    ; a472
	dw La533                    ; a474
	dw La533                    ; a476
	dw La533                    ; a478
	dw La533                    ; a47a
	dw La533                    ; a47c
	dw La533                    ; a47e
	dw La533                    ; a480
	dw La533                    ; a482
	dw La533                    ; a484
	dw La533                    ; a486
	dw La533                    ; a488
	dw La533                    ; a48a
	dw La533                    ; a48c
	dw La533                    ; a48e
	dw La533                    ; a490
	dw La533                    ; a492
	dw La546                    ; a494
	dw La55a                    ; a496
	dw La534                    ; a498
	dw La534                    ; a49a
	dw La533                    ; a49c
	dw La533                    ; a49e
	dw La520                    ; a4a0
	dw La533                    ; a4a2
	dw La533                    ; a4a4
	dw La566                    ; a4a6
	dw La586                    ; a4a8
	dw La50c                    ; a4aa
	dw La50c                    ; a4ac
	dw La50c                    ; a4ae
	dw La50c                    ; a4b0
	dw La50c                    ; a4b2
	dw La50c                    ; a4b4
	dw La5a6                    ; a4b6
	dw La533                    ; a4b8
	dw La533                    ; a4ba
	dw La533                    ; a4bc
	dw La533                    ; a4be
	dw La533                    ; a4c0
	dw La533                    ; a4c2
	dw La533                    ; a4c4
	dw La533                    ; a4c6
	dw La533                    ; a4c8
	dw La533                    ; a4ca
	dw La533                    ; a4cc
	dw La533                    ; a4ce
	dw La533                    ; a4d0
	dw La533                    ; a4d2
	dw La5a6                    ; a4d4
	dw La533                    ; a4d6
	dw La533                    ; a4d8
	dw La533                    ; a4da
	dw La533                    ; a4dc
	dw La533                    ; a4de
	dw La533                    ; a4e0
	dw La533                    ; a4e2
	dw La533                    ; a4e4
	dw La533                    ; a4e6
	dw La533                    ; a4e8
	dw La533                    ; a4ea
	dw La533                    ; a4ec
	dw La533                    ; a4ee
	dw La533                    ; a4f0
	dw La533                    ; a4f2
	dw La533                    ; a4f4
	dw La533                    ; a4f6
	dw La533                    ; a4f8
	dw La533                    ; a4fa
	dw La533                    ; a4fc
	dw La533                    ; a4fe
	dw La533                    ; a500
	dw La533                    ; a502
	dw La533                    ; a504
	dw La533                    ; a506
	dw La533                    ; a508
	dw La533                    ; a50a
La50c:
	ld a,(La3cb)                ; a50c
	ld (ix+7),$ff               ; a50f
	dec a                       ; a513
	ret z                       ; a514
	ld (ix+7),$04               ; a515
	dec a                       ; a519
	ret z                       ; a51a
	ld (ix+7),$08               ; a51b
	ret                         ; a51f
La520:
	ld a,(La3cb)                ; a520
	ld (ix+5),$09               ; a523
	dec a                       ; a527
	ret z                       ; a528
	ld (ix+5),$1a               ; a529
	dec a                       ; a52d
	ret z                       ; a52e
	ld (ix+5),$28               ; a52f
La533:
	ret                         ; a533
La534:
	ld a,r                      ; a534
	and $1f                     ; a536
	add a,$0a                   ; a538
	ld (ix+5),a                 ; a53a
	ld a,(La3cb)                ; a53d
	add a,a                     ; a540
	add a,a                     ; a541
	ld (ix+7),a                 ; a542
	ret                         ; a545
La546:
	ld a,(La3cb)                ; a546
	ld (ix+5),$1a               ; a549
	dec a                       ; a54d
	ret z                       ; a54e
	ld (ix+5),$0c               ; a54f
	dec a                       ; a553
	ret z                       ; a554
	ld (ix+5),$26               ; a555
	ret                         ; a559
La55a:
	ld a,(La3cb)                ; a55a
	add a,a                     ; a55d
	add a,a                     ; a55e
	ld c,a                      ; a55f
	add a,a                     ; a560
	add a,c                     ; a561
	ld (ix+7),a                 ; a562
	ret                         ; a565
La566:
	ld a,(La3cb)                ; a566
	ld (ix+7),$ff               ; a569
	ld (ix+4),$14               ; a56d
	ld (ix+5),$28               ; a571
	dec a                       ; a575
	ret z                       ; a576
	ld (ix+5),$3c               ; a577
	dec a                       ; a57b
	ret z                       ; a57c
	ld (ix+4),$0a               ; a57d
	ld (ix+5),$32               ; a581
	ret                         ; a585
La586:
	ld a,(La3cb)                ; a586
	ld (ix+7),$ff               ; a589
	ld (ix+4),$14               ; a58d
	ld (ix+5),$00               ; a591
	dec a                       ; a595
	ret z                       ; a596
	ld (ix+5),$14               ; a597
	dec a                       ; a59b
	ret z                       ; a59c
	ld (ix+4),$0a               ; a59d
	ld (ix+5),$0a               ; a5a1
	ret                         ; a5a5
La5a6:
	ld a,(La3cb)                ; a5a6
	ld (ix+7),$ff               ; a5a9
	ld (ix+4),$0f               ; a5ad
	ld (ix+5),$0e               ; a5b1
	dec a                       ; a5b5
	ret z                       ; a5b6
	ld (ix+5),$26               ; a5b7
	dec a                       ; a5bb
	ret z                       ; a5bc
	ld (ix+4),$03               ; a5bd
	ld (ix+5),$1a               ; a5c1
	ret                         ; a5c5
La5c6:
	db $03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$03; a5c6
	db $03,$03,$04,$07,$07,$03,$03,$03,$03,$03,$03,$03,$01,$02,$03,$01; a5d6
	db $02,$03,$03,$01,$01,$01,$01,$01,$01,$01,$01,$03,$03,$01,$01,$01; a5e6
	db $01,$03,$01,$01,$04,$01,$01,$01,$01,$01,$01,$01,$01,$01,$01,$01; a5f6
	db $01                      ; a606
La607:
	db $0a,$0a,$0a,$0a,$0a,$0a,$0a,$0a,$0a,$0a,$0a,$0a,$0a,$0a,$0b,$0b; a607
	db $0b,$0c,$11,$0d,$0d,$0e,$0e,$0f,$10,$10,$10,$10,$11,$11,$11,$11; a617
	db $11,$11,$12,$13,$13,$13,$13,$14,$14,$14,$14,$15,$15,$16,$16,$16; a627
	db $16,$16,$16,$16,$11,$11,$01,$01,$01,$01,$01,$01; a637
La643:
	dw La6b1                    ; a643
	dw La6b8                    ; a645
	dw La6bf                    ; a647
	dw La6c6                    ; a649
	dw La6cd                    ; a64b
	dw La6d4                    ; a64d
	dw La6db                    ; a64f
	dw La6e2                    ; a651
	dw La6e9                    ; a653
	dw La6f0                    ; a655
	dw La6f7                    ; a657
	dw La6fe                    ; a659
	dw La705                    ; a65b
	dw La70c                    ; a65d
	dw La713                    ; a65f
	dw La71a                    ; a661
	dw La721                    ; a663
	dw La728                    ; a665
	dw La72f                    ; a667
	dw La736                    ; a669
	dw La73d                    ; a66b
	dw La744                    ; a66d
	dw La74b                    ; a66f
	dw La752                    ; a671
	dw La759                    ; a673
	dw La760                    ; a675
	dw La767                    ; a677
	dw La76e                    ; a679
	dw La775                    ; a67b
	dw La77c                    ; a67d
	dw La783                    ; a67f
	dw La78a                    ; a681
	dw La791                    ; a683
	dw La798                    ; a685
	dw La79f                    ; a687
	dw La7a6                    ; a689
	dw La7ad                    ; a68b
	dw La7b4                    ; a68d
	dw La7bb                    ; a68f
	dw La7c2                    ; a691
	dw La7c9                    ; a693
	dw La7d0                    ; a695
	dw La7d7                    ; a697
	dw La7de                    ; a699
	dw La7e5                    ; a69b
	dw La7ec                    ; a69d
	dw La7f3                    ; a69f
	dw La7fa                    ; a6a1
	dw La801                    ; a6a3
	dw La808                    ; a6a5
	dw La80f                    ; a6a7
	dw La816                    ; a6a9
	dw La81d                    ; a6ab
	dw La6b1                    ; a6ad
	dw La6b1                    ; a6af
La6b1:
	db $0e,$14,$20,$00,$09,$28,$03; a6b1
La6b8:
	db $09,$00,$00,$00,$09,$0f,$03; a6b8
La6bf:
	db $02,$10,$03,$00,$09,$10,$03; a6bf
La6c6:
	db $02,$10,$35,$00,$09,$11,$03; a6c6
La6cd:
	db $02,$10,$3f,$00,$09,$12,$03; a6cd
La6d4:
	db $02,$10,$03,$00,$09,$13,$03; a6d4
La6db:
	db $02,$10,$04,$00,$09,$14,$03; a6db
La6e2:
	db $02,$10,$30,$00,$09,$15,$03; a6e2
La6e9:
	db $1b,$14,$0d,$00,$09,$16,$03; a6e9
La6f0:
	db $1b,$14,$31,$00,$09,$17,$03; a6f0
La6f7:
	db $16,$14,$00,$00,$09,$18,$03; a6f7
La6fe:
	db $16,$14,$39,$00,$09,$19,$03; a6fe
La705:
	db $12,$00,$28,$00,$09,$1a,$03; a705
La70c:
	db $02,$10,$00,$00,$09,$29,$03; a70c
La713:
	db $10,$00,$00,$00,$09,$0a,$03; a713
La71a:
	db $06,$03,$00,$00,$09,$0b,$03; a71a
La721:
	db $06,$03,$30,$00,$09,$0c,$03; a721
La728:
	db $1b,$0d,$20,$00,$03,$02,$03; a728
La72f:
	db $1b,$15,$1a,$00,$00,$01,$04; a72f
La736:
	db $1b,$0f,$20,$00,$00,$06,$03; a736
La73d:
	db $1b,$0b,$20,$00,$00,$07,$03; a73d
La744:
	db $1b,$0b,$28,$00,$09,$03,$03; a744
La74b:
	db $13,$0b,$00,$00,$09,$04,$03; a74b
La752:
	db $1b,$0f,$20,$00,$08,$02,$03; a752
La759:
	db $1b,$10,$3c,$00,$07,$0d,$05; a759
La760:
	db $1b,$10,$00,$01,$07,$0e,$05; a760
La767:
	db $1b,$0c,$40,$00,$07,$0d,$05; a767
La76e:
	db $1b,$0c,$00,$01,$07,$0e,$05; a76e
La775:
	db $1b,$0c,$1e,$00,$03,$08,$05; a775
La77c:
	db $1b,$0c,$1e,$00,$03,$08,$05; a77c
La783:
	db $1b,$0c,$1e,$00,$03,$08,$05; a783
La78a:
	db $1b,$0c,$0e,$01,$03,$09,$05; a78a
La791:
	db $1b,$0c,$0e,$01,$03,$09,$05; a791
La798:
	db $1b,$0c,$0e,$01,$03,$09,$05; a798
La79f:
	db $1b,$0b,$20,$03,$09,$05,$03; a79f
La7a6:
	db $1b,$10,$28,$00,$04,$1b,$05; a7a6
La7ad:
	db $1b,$10,$0d,$01,$04,$1c,$05; a7ad
La7b4:
	db $1b,$10,$28,$01,$04,$1d,$05; a7b4
La7bb:
	db $1b,$10,$0d,$00,$04,$1e,$05; a7bb
La7c2:
	db $1b,$10,$28,$01,$05,$1d,$05; a7c2
La7c9:
	db $1b,$10,$0d,$00,$05,$1e,$05; a7c9
La7d0:
	db $1b,$10,$28,$01,$05,$1f,$05; a7d0
La7d7:
	db $1b,$10,$0d,$00,$05,$20,$05; a7d7
La7de:
	db $1b,$10,$05,$00,$06,$21,$03; a7de
La7e5:
	db $1b,$10,$32,$01,$06,$22,$03; a7e5
La7ec:
	db $02,$0a,$05,$03,$07,$23,$03; a7ec
La7f3:
	db $02,$0a,$32,$03,$07,$24,$03; a7f3
La7fa:
	db $1b,$10,$0f,$01,$07,$25,$03; a7fa
La801:
	db $1b,$10,$27,$00,$07,$26,$03; a801
La808:
	db $1b,$0c,$20,$02,$07,$27,$03; a808
La80f:
	db $1b,$10,$05,$00,$07,$25,$03; a80f
La816:
	db $1b,$10,$32,$00,$07,$26,$03; a816
La81d:
	db $1b,$15,$1a,$00,$00,$01,$04,$7d,$fe,$1f,$d0,$7c,$fe,$34,$d0,$cd; a81d
	db $a9,$b0,$c5,$d5,$79,$d9,$21,$29,$b2,$ed,$4b,$58,$cc,$ed,$b1,$d9; a82d
	db $ca,$5e,$a8,$e5,$78,$d9,$21,$1d,$b2,$ed,$4b,$5a,$cc,$ed,$b1,$d9; a83d
	db $ca,$57,$a8,$1a,$b7,$fa,$56,$a8,$77,$23,$13,$10,$e7,$e1,$0e,$40; a84d
	db $09,$d1,$01,$0b,$00,$eb,$09,$eb,$c1,$0d,$c2,$2f,$a8,$c9; a85d
La86b:
	ret                         ; a86b
La86c:
	ld hl,WRK+$047              ; a86c
	ld a,e                      ; a86f
	add a,(hl)                  ; a870
	cp c                        ; a871
	ret c                       ; a872
	inc hl                      ; a873
	ld a,d                      ; a874
	add a,(hl)                  ; a875
	cp b                        ; a876
	ret c                       ; a877
	inc hl                      ; a878
	ld a,c                      ; a879
	add a,(hl)                  ; a87a
	cp e                        ; a87b
	ret c                       ; a87c
	inc hl                      ; a87d
	ld a,b                      ; a87e
	add a,(hl)                  ; a87f
	cp d                        ; a880
	ret                         ; a881
La882:
	ld a,(WRK+$052)             ; a882
	rlca                        ; a885
	ret nc                      ; a886
	xor a                       ; a887
	call VZ_KBROW               ; a888 patched
	bit 4,a                     ; a88e
	ret z                       ; a890
	ld hl,$0000                 ; a891
	ld (WRK+$047),hl            ; a894
	ld a,$06                    ; a897
	ld (WRK+$04a),a             ; a899
	ld hl,(WRK+$05c)            ; a89c
	inc h                       ; a89f
	inc l                       ; a8a0
	inc l                       ; a8a1
	ld (La8d6+1),hl             ; a8a2
	ld ix,WRK+$079              ; a8a5
	ld b,$10                    ; a8a9
	ld de,$0018                 ; a8ab
La8ae:
	exx                         ; a8ae
	ld a,(ix+0)                 ; a8af
	cp $03                      ; a8b2
	jp c,La8ee                  ; a8b4
	cp $28                      ; a8b7
	jp z,La8ee                  ; a8b9
	cp $22                      ; a8bc
	jp z,La8ee                  ; a8be
	ld a,(ix+3)                 ; a8c1
	dec a                       ; a8c4
	jp nz,La8ee                 ; a8c5
	ld a,(ix+9)                 ; a8c8
	or a                        ; a8cb
	ld a,$11                    ; a8cc
	jp z,La8d3                  ; a8ce
	ld a,$05                    ; a8d1
La8d3:
	ld (WRK+$049),a             ; a8d3
La8d6:
	ld de,L2808+1               ; a8d6
	ld c,(ix+1)                 ; a8d9
	ld b,(ix+2)                 ; a8dc
	inc b                       ; a8df
	inc b                       ; a8e0
	inc c                       ; a8e1
	call La86c                  ; a8e2
	jp c,La8ee                  ; a8e5
	ld a,$01                    ; a8e8
	ld (WRK+$04d),a             ; a8ea
	ret                         ; a8ed
La8ee:
	exx                         ; a8ee
	add ix,de                   ; a8ef
	djnz La8ae                  ; a8f1
	ret                         ; a8f3
La8f4:
	ld a,(ix+3)                 ; a8f4
	sra a                       ; a8f7
	ld e,a                      ; a8f9
	ld d,$00                    ; a8fa
	ld hl,La915                 ; a8fc
	add hl,de                   ; a8ff
	ld a,(hl)                   ; a900
	ld (WRK+$04a),a             ; a901
	add a,a                     ; a904
	ld (WRK+$049),a             ; a905
	ld a,(ix+9)                 ; a908
	or a                        ; a90b
	ret z                       ; a90c
	ld a,(WRK+$04a)             ; a90d
	dec a                       ; a910
	ld (WRK+$049),a             ; a911
	ret                         ; a914
La915:
	db $0a,$09,$08,$07,$06,$05,$04,$04,$03,$03,$02,$02,$01,$01,$01,$01; a915
	db $01                      ; a925
La926:
	ld a,(iy+3)                 ; a926
	sra a                       ; a929
	sra a                       ; a92b
	add a,a                     ; a92d
	ld e,a                      ; a92e
	ld d,$00                    ; a92f
	ld hl,La952                 ; a931
	add hl,de                   ; a934
	ld c,(hl)                   ; a935
	inc hl                      ; a936
	ld b,(hl)                   ; a937
	ld (WRK+$047),bc            ; a938
	ld hl,La983                 ; a93c
	add hl,de                   ; a93f
	ld e,(hl)                   ; a940
	inc hl                      ; a941
	ld d,(hl)                   ; a942
	ld a,(iy+1)                 ; a943
	add a,e                     ; a946
	ld (WRK+$043),a             ; a947
	ld a,(iy+2)                 ; a94a
	add a,d                     ; a94d
	ld (WRK+$044),a             ; a94e
	ret                         ; a951
La952:
	db $05,$08,$04,$06,$03,$04,$02,$03,$01,$01,$01,$00,$00,$00,$00,$00; a952
	db $fd,$7e,$03,$cb,$2f,$cb,$2f,$87,$5f,$16,$00,$21,$83,$a9,$19,$5e; a962
	db $23,$56,$fd,$7e,$01,$83,$32,$43,$cc,$fd,$7e,$02,$82,$32,$44,$cc; a972
	db $c9                      ; a982
La983:
	db $00,$fe,$00,$fe,$01,$01,$01,$01,$01,$02,$01,$02,$01,$02,$01,$02; a983
	db $01,$02,$01,$02,$01,$02,$01,$02; a993
La99b:
	ld iy,WRK+$229              ; a99b
	ld b,$06                    ; a99f
La9a1:
	push bc                     ; a9a1
	ld a,(iy+0)                 ; a9a2
	or a                        ; a9a5
	jp z,La9f7                  ; a9a6
	ld ix,WRK+$079              ; a9a9
	ld b,$10                    ; a9ad
	ld de,$0018                 ; a9af
La9b2:
	exx                         ; a9b2
	call Laa30                  ; a9b3
	jp c,La9f2                  ; a9b6
	call La8f4                  ; a9b9
	call La926                  ; a9bc
	ld de,(WRK+$043)            ; a9bf
	ld c,(ix+1)                 ; a9c3
	ld b,(ix+2)                 ; a9c6
	call La86c                  ; a9c9
	jp c,La9f2                  ; a9cc
	ld (iy+0),$00               ; a9cf
	dec (ix+12)                 ; a9d3
	jp p,La9f2                  ; a9d6
	ld a,$03                    ; a9d9
	call L9600                  ; a9db
	ld a,(ix+8)                 ; a9de
	dec a                       ; a9e1
	jp z,La9f2                  ; a9e2
	jp p,Laa00                  ; a9e5
	ld (ix+0),$00               ; a9e8
	call Lab53                  ; a9ec
	call Laa4e                  ; a9ef
La9f2:
	exx                         ; a9f2
	add ix,de                   ; a9f3
	djnz La9b2                  ; a9f5
La9f7:
	ld bc,$0006                 ; a9f7
	add iy,bc                   ; a9fa
	pop bc                      ; a9fc
	djnz La9a1                  ; a9fd
	ret                         ; a9ff
Laa00:
	ld (iy+0),$01               ; aa00
	ld a,(iy+4)                 ; aa04
	or a                        ; aa07
	jp nz,La9f2                 ; aa08
	ld (iy+4),$02               ; aa0b
	ld a,(ix+2)                 ; aa0f
	cp (iy+2)                   ; aa12
	jp c,Laa1c                  ; aa15
	ld (iy+4),$fe               ; aa18
Laa1c:
	ld a,(ix+1)                 ; aa1c
	cp (iy+1)                   ; aa1f
	ld (iy+5),$01               ; aa22
	jp c,La9f2                  ; aa26
	ld (iy+5),$ff               ; aa29
	jp La9f2                    ; aa2d
Laa30:
	ld a,(ix+0)                 ; aa30
	cp $0a                      ; aa33
	ret c                       ; aa35
	bit 7,(ix+7)                ; aa36
	jp z,Laa4b                  ; aa3a
	ld d,(iy+3)                 ; aa3d
	ld b,(ix+3)                 ; aa40
	ld a,d                      ; aa43
	inc a                       ; aa44
	cp b                        ; aa45
	ret c                       ; aa46
	ld a,b                      ; aa47
	inc a                       ; aa48
	cp d                        ; aa49
	ret                         ; aa4a
Laa4b:
	scf                         ; aa4b
	ret                         ; aa4c
Laa4d:
	ret                         ; aa4d
Laa4e:
	ld de,$1000                 ; aa4e
Laa51:
	ld hl,WRK+$06e              ; aa51
	ld a,e                      ; aa54
	add a,(hl)                  ; aa55
	daa                         ; aa56
	ld (hl),a                   ; aa57
	dec hl                      ; aa58
	ld a,d                      ; aa59
	adc a,(hl)                  ; aa5a
	daa                         ; aa5b
	ld (hl),a                   ; aa5c
	dec hl                      ; aa5d
	ld a,$00                    ; aa5e
	adc a,(hl)                  ; aa60
	daa                         ; aa61
	ld (hl),a                   ; aa62
	dec hl                      ; aa63
	ld a,$00                    ; aa64
	adc a,(hl)                  ; aa66
	daa                         ; aa67
	ld (hl),a                   ; aa68
	call Laa9b                  ; aa69
	jp nc,Laa7a                 ; aa6c
	ld hl,WRK+$06b              ; aa6f
	ld de,WRK+$071              ; aa72
	ld bc,$0004                 ; aa75
	ldir                        ; aa78
Laa7a:
	ld hl,WRK+$06b              ; aa7a
	ld de,VRAM+$015             ; aa7d
	call Laa89                  ; aa80
	ld hl,WRK+$071              ; aa83
	ld de,VRAM+$004             ; aa86
Laa89:
	ld a,$20                    ; aa89
	ld b,$04                    ; aa8b
Laa8d:
	rld                         ; aa8d
	ld (de),a                   ; aa8f
	inc de                      ; aa90
	rld                         ; aa91
	ld (de),a                   ; aa93
	inc de                      ; aa94
	rld                         ; aa95
	inc hl                      ; aa97
	djnz Laa8d                  ; aa98
	ret                         ; aa9a
Laa9b:
	ld hl,WRK+$06b              ; aa9b
	ld de,WRK+$071              ; aa9e
	ld b,$04                    ; aaa1
Laaa3:
	ld a,(de)                   ; aaa3
	sub (hl)                    ; aaa4
	ret c                       ; aaa5
	jp nz,Laaad                 ; aaa6
	inc de                      ; aaa9
	inc hl                      ; aaaa
	djnz Laaa3                  ; aaab
Laaad:
	xor a                       ; aaad
	ret                         ; aaae
Laaaf:
	ret                         ; aaaf
Laab0:
	ld a,(WRK+$05c)             ; aab0
	sub $07                     ; aab3
	ld e,a                      ; aab5
	ld d,$00                    ; aab6
	ld hl,Laac1                 ; aab8
	add hl,de                   ; aabb
	ld a,(hl)                   ; aabc
	ld (WRK+$066),a             ; aabd
	ret                         ; aac0
Laac1:
	db $06,$06,$05,$05,$04,$04,$04,$03,$03,$03,$02,$02,$02,$01,$01,$01; aac1
	db $00,$00,$00,$00,$00,$00,$00; aad1
Laad8:
	push de                     ; aad8
	push hl                     ; aad9
	ld a,(ix+3)                 ; aada
	sra a                       ; aadd
	add a,a                     ; aadf
	ld e,a                      ; aae0
	ld d,$00                    ; aae1
	ld hl,Laaf3                 ; aae3
	add hl,de                   ; aae6
	ld a,(hl)                   ; aae7
	ld (WRK+$05a),a             ; aae8
	inc hl                      ; aaeb
	ld a,(hl)                   ; aaec
	ld (WRK+$058),a             ; aaed
	pop hl                      ; aaf0
	pop de                      ; aaf1
	ret                         ; aaf2
Laaf3:
	db $01,$01,$02,$03,$03,$05,$04,$07,$05,$09,$06,$0b,$07,$0d,$07,$0e; aaf3
	db $08,$0f,$08,$10,$09,$11,$09,$12,$0a,$13,$0a,$13,$0b,$14,$0b,$14; ab03
	db $0b,$14,$0b,$14          ; ab13
Lab17:
	ld a,(WRK+$05d)             ; ab17
	sub $0c                     ; ab1a
	sra a                       ; ab1c
	sra a                       ; ab1e
	ld e,a                      ; ab20
	ld d,$00                    ; ab21
	ld hl,Lab49                 ; ab23
	add hl,de                   ; ab26
	ld c,(hl)                   ; ab27
	ld ix,WRK+$079              ; ab28
	ld b,$10                    ; ab2c
	ld de,$0018                 ; ab2e
	ld hl,WRK+$07e              ; ab31
Lab34:
	ld a,(ix+0)                 ; ab34
	cp $17                      ; ab37
	jp c,Lab43                  ; ab39
	ld a,(hl)                   ; ab3c
	add a,c                     ; ab3d
	ld (hl),a                   ; ab3e
	jp p,Lab43                  ; ab3f
	ld (hl),d                   ; ab42
Lab43:
	add hl,de                   ; ab43
	add ix,de                   ; ab44
	djnz Lab34                  ; ab46
	ret                         ; ab48
Lab49:
	db $02,$01,$01,$00,$00,$00,$00,$ff,$ff,$fe; ab49
Lab53:
	push iy                     ; ab53
	call Lac49                  ; ab55
	jp c,Labab                  ; ab58
	ld a,(ix+9)                 ; ab5b
	ld (iy+0),$02               ; ab5e
	ld (iy+9),$01               ; ab62
	or a                        ; ab66
	jp nz,Lab79                 ; ab67
	ld a,r                      ; ab6a
	and $0f                     ; ab6c
	jp nz,Lab79                 ; ab6e
	ld (iy+0),$01               ; ab71
	ld (iy+9),$00               ; ab75
Lab79:
	ld a,(ix+3)                 ; ab79
	ld (iy+3),a                 ; ab7c
	ld a,(ix+4)                 ; ab7f
	ld (iy+4),a                 ; ab82
	ld a,(ix+5)                 ; ab85
	ld (iy+5),a                 ; ab88
	ld (iy+6),$03               ; ab8b
	ld (iy+7),$ff               ; ab8f
	ld (iy+8),$01               ; ab93
	ld (iy+11),$2f              ; ab97
	ld (iy+13),$04              ; ab9b
	ld (iy+14),$01              ; ab9f
	ld (iy+16),$55              ; aba3
	xor a                       ; aba7
	call L9600                  ; aba8
Labab:
	pop iy                      ; abab
	ret                         ; abad
Labae:
	dec (ix+6)                  ; abae
	jp p,Labb8                  ; abb1
	ld (ix+6),$03               ; abb4
Labb8:
	ld a,(ix+3)                 ; abb8
	or a                        ; abbb
	jp z,Lac44                  ; abbc
	jp m,Lac44                  ; abbf
	ld a,(ix+23)                ; abc2
	cp (ix+18)                  ; abc5
	jp c,Labe2                  ; abc8
	call Labf5                  ; abcb
	ld a,(ix+22)                ; abce
	add a,(ix+18)               ; abd1
	ld (ix+22),a                ; abd4
	sub (ix+23)                 ; abd7
	ret c                       ; abda
	ld (ix+22),a                ; abdb
	dec (ix+3)                  ; abde
	ret                         ; abe1
Labe2:
	dec (ix+3)                  ; abe2
	ld a,(ix+22)                ; abe5
	add a,(ix+23)               ; abe8
	ld (ix+22),a                ; abeb
	sub (ix+18)                 ; abee
	ret c                       ; abf1
	ld (ix+22),a                ; abf2
Labf5:
	ld a,(ix+16)                ; abf5
	cp (ix+17)                  ; abf8
	jp c,Lac21                  ; abfb
	ld a,(ix+5)                 ; abfe
	add a,(ix+19)               ; ac01
	ld (ix+5),a                 ; ac04
	ld a,(ix+21)                ; ac07
	add a,(ix+17)               ; ac0a
	ld (ix+21),a                ; ac0d
	sub (ix+16)                 ; ac10
	ret c                       ; ac13
	ld (ix+21),a                ; ac14
	ld a,(ix+4)                 ; ac17
	add a,(ix+20)               ; ac1a
	ld (ix+4),a                 ; ac1d
	ret                         ; ac20
Lac21:
	ld a,(ix+4)                 ; ac21
	add a,(ix+20)               ; ac24
	ld (ix+4),a                 ; ac27
	ld a,(ix+21)                ; ac2a
	add a,(ix+16)               ; ac2d
	ld (ix+21),a                ; ac30
	sub (ix+17)                 ; ac33
	ret c                       ; ac36
	ld (ix+21),a                ; ac37
	ld a,(ix+5)                 ; ac3a
	add a,(ix+19)               ; ac3d
	ld (ix+5),a                 ; ac40
	ret                         ; ac43
Lac44:
	ld (ix+0),$00               ; ac44
	ret                         ; ac48
Lac49:
	ld iy,WRK+$079              ; ac49
	ld b,$10                    ; ac4d
	ld de,$0018                 ; ac4f
Lac52:
	ld a,(iy+0)                 ; ac52
	or a                        ; ac55
	ret z                       ; ac56
	add iy,de                   ; ac57
	djnz Lac52                  ; ac59
	scf                         ; ac5b
	ret                         ; ac5c
Lac5d:
	db $00,$00,$00,$04,$04,$02,$04,$04,$03,$05; ac5d
Lac67:
	call Lac49                  ; ac67
	ret c                       ; ac6a
	ld a,(ix+10)                ; ac6b
	ld (iy+0),a                 ; ac6e
	ld l,(ix+4)                 ; ac71
	ld h,(ix+5)                 ; ac74
	ld (iy+4),l                 ; ac77
	ld (iy+5),h                 ; ac7a
	ld a,(ix+3)                 ; ac7d
	ld (iy+3),a                 ; ac80
	ld (iy+6),$00               ; ac83
	ld (iy+7),$00               ; ac87
	ld (iy+8),$01               ; ac8b
	ld (iy+9),$01               ; ac8f
	ld (iy+11),$30              ; ac93
	ld (iy+14),$01              ; ac97
	ld a,(ix+10)                ; ac9b
	ld e,a                      ; ac9e
	ld d,$00                    ; ac9f
	ld hl,Lac5d                 ; aca1
	add hl,de                   ; aca4
	ld a,(hl)                   ; aca5
	ld (iy+13),a                ; aca6
	ld hl,(WRK+$05c)            ; aca9
	dec l                       ; acac
	dec h                       ; acad
	dec h                       ; acae
	dec h                       ; acaf
	ld a,h                      ; acb0
	sub (ix+5)                  ; acb1
	ld c,$00                    ; acb4
	jp z,Lacc4                  ; acb6
	ld c,$01                    ; acb9
	jp nc,Lacc4                 ; acbb
	ld a,(ix+5)                 ; acbe
	sub h                       ; acc1
	ld c,$ff                    ; acc2
Lacc4:
	ld (iy+16),a                ; acc4
	ld (iy+19),c                ; acc7
	ld a,l                      ; acca
	sub (ix+4)                  ; accb
	ld c,$00                    ; acce
	jp z,Lacde                  ; acd0
	ld c,$01                    ; acd3
	jp nc,Lacde                 ; acd5
	ld a,(ix+4)                 ; acd8
	sub l                       ; acdb
	ld c,$ff                    ; acdc
Lacde:
	ld (iy+17),a                ; acde
	ld (iy+20),c                ; ace1
	ld a,(ix+3)                 ; ace4
	ld (iy+18),a                ; ace7
	ld c,(iy+16)                ; acea
	ld a,c                      ; aced
	sub (iy+17)                 ; acee
	jp nc,Lacf7                 ; acf1
	ld c,(iy+17)                ; acf4
Lacf7:
	ld (iy+23),c                ; acf7
	sra c                       ; acfa
	ld (iy+21),c                ; acfc
	ld c,(iy+23)                ; acff
	ld a,(iy+18)                ; ad02
	cp c                        ; ad05
	jp nc,Lad2a                 ; ad06
	ld c,(iy+18)                ; ad09
	dec (iy+13)                 ; ad0c
	jp p,Lad16                  ; ad0f
	ld (iy+13),$00              ; ad12
Lad16:
	sra c                       ; ad16
	ld (iy+22),c                ; ad18
	ld a,(ix+23)                ; ad1b
	cp $14                      ; ad1e
	ret c                       ; ad20
	dec (iy+13)                 ; ad21
	ret p                       ; ad24
	ld (iy+13),$00              ; ad25
	ret                         ; ad29
Lad2a:
	sra c                       ; ad2a
	ld (iy+22),c                ; ad2c
	inc (iy+13)                 ; ad2f
	ld a,(iy+13)                ; ad32
	cp $06                      ; ad35
	ret c                       ; ad37
	ld (iy+13),$05              ; ad38
	ret                         ; ad3c
Lad3d:
	ld a,(WRK+$062)             ; ad3d
	dec a                       ; ad40
	add a,a                     ; ad41
	ld e,a                      ; ad42
	ld d,$00                    ; ad43
	ld hl,Lad51                 ; ad45
	add hl,de                   ; ad48
	ld e,(hl)                   ; ad49
	inc hl                      ; ad4a
	ld d,(hl)                   ; ad4b
	ld (WRK+$040),de            ; ad4c
	ret                         ; ad50
Lad51:
	dw Lad75                    ; ad51
	dw Lad9e                    ; ad53
	dw Ladc7                    ; ad55
	dw Ladf0                    ; ad57
	dw Lad75                    ; ad59
	dw Lae15                    ; ad5b
	dw Lae3e                    ; ad5d
	dw Lae67                    ; ad5f
	dw Lae90                    ; ad61
	dw Laebb                    ; ad63
	dw Laee4                    ; ad65
	dw Lad75                    ; ad67
	dw Laf0d                    ; ad69
	dw Laf36                    ; ad6b
	dw Laf5f                    ; ad6d
	dw Laf88                    ; ad6f
	dw Lafb1                    ; ad71
	dw Lad75                    ; ad73
Lad75:
	db $12,$00,$12,$0a,$12,$00,$12,$00,$12,$00,$12,$0a,$12,$00,$12,$00; ad75
	db $12,$0a,$12,$00,$12,$01,$12,$01,$12,$01,$12,$01,$12,$01,$12,$01; ad85
	db $12,$01,$12,$01,$00,$00,$00,$00,$ff; ad95
Lad9e:
	db $1e,$0a,$1e,$00,$1e,$0a,$00,$11,$1e,$00,$02,$00,$02,$0a,$02,$00; ad9e
	db $02,$11,$02,$00,$03,$0a,$02,$00,$02,$0a,$1e,$0c,$1e,$11,$03,$0a; adae
	db $03,$00,$03,$00,$00,$00,$00,$00,$ff; adbe
Ladc7:
	db $0d,$00,$0d,$08,$0d,$13,$0d,$14,$0d,$00,$0d,$08,$0d,$13,$0d,$14; adc7
	db $0d,$00,$0d,$08,$0d,$13,$0d,$14,$0d,$00,$0d,$08,$0d,$13,$0d,$14; add7
	db $1d,$00,$1d,$00,$1d,$00,$00,$00,$ff; ade7
Ladf0:
	db $05,$00,$15,$0e,$16,$00,$05,$00,$15,$0f,$16,$00,$05,$00,$15,$0e; adf0
	db $16,$00,$05,$00,$15,$17,$16,$00,$05,$00,$15,$00,$16,$0e,$05,$00; ae00
	db $63,$00,$00,$00,$ff      ; ae10
Lae15:
	db $1f,$0a,$07,$00,$1b,$10,$00,$10,$00,$0a,$07,$00,$07,$00,$07,$0a; ae15
	db $00,$10,$00,$0a,$07,$10,$07,$00,$07,$00,$07,$0a,$1f,$00,$1f,$0a; ae25
	db $1f,$10,$07,$0a,$00,$00,$00,$00,$ff; ae35
Lae3e:
	db $19,$00,$19,$0b,$19,$09,$00,$09,$00,$19,$19,$00,$00,$09,$1c,$0b; ae3e
	db $19,$0b,$19,$09,$00,$19,$0b,$09,$1c,$19,$00,$0b,$1c,$00,$1c,$00; ae4e
	db $1c,$0b,$1c,$19,$00,$00,$00,$00,$ff; ae5e
Lae67:
	db $02,$10,$02,$0c,$02,$11,$02,$0c,$00,$11,$00,$0a,$10,$0c,$03,$00; ae67
	db $03,$00,$03,$10,$03,$10,$03,$0c,$03,$00,$03,$0c,$03,$0c,$03,$00; ae77
	db $03,$10,$03,$10,$00,$00,$00,$00,$ff; ae87
Lae90:
	db $05,$0e,$15,$00,$16,$0f,$05,$00,$15,$0e,$16,$00,$05,$17,$15,$00; ae90
	db $16,$00,$05,$00,$15,$0e,$16,$00,$05,$0f,$15,$00,$16,$0e,$05,$00; aea0
	db $15,$17,$16,$00,$05,$00,$63,$00,$00,$00,$ff; aeb0
Laebb:
	db $0d,$08,$0d,$13,$0d,$14,$0d,$08,$0d,$13,$0d,$14,$0d,$10,$0d,$10; aebb
	db $0d,$08,$0d,$13,$0d,$14,$0d,$08,$0d,$13,$0d,$10,$0d,$10,$00,$08; aecb
	db $00,$14,$00,$15,$00,$00,$00,$00,$ff; aedb
Laee4:
	db $00,$10,$00,$10,$00,$10,$00,$10,$00,$10,$00,$10,$00,$10,$00,$10; aee4
	db $1a,$10,$00,$10,$00,$10,$1a,$10,$1a,$10,$1a,$10,$00,$10,$1a,$10; aef4
	db $00,$10,$1a,$10,$00,$00,$00,$00,$ff; af04
Laf0d:
	db $01,$00,$01,$00,$01,$00,$01,$00,$01,$00,$00,$10,$00,$10,$0a,$00; af0d
	db $00,$00,$15,$00,$15,$00,$15,$00,$15,$0a,$15,$00,$15,$00,$15,$00; af1d
	db $15,$00,$15,$00,$00,$00,$00,$00,$ff; af2d
Laf36:
	db $05,$0e,$15,$0f,$16,$18,$05,$0f,$15,$18,$16,$17,$05,$00,$15,$00; af36
	db $16,$18,$05,$0f,$15,$00,$16,$18,$05,$17,$15,$18,$16,$0f,$05,$0e; af46
	db $15,$00,$16,$00,$63,$00,$00,$00,$ff; af56
Laf5f:
	db $04,$0a,$04,$00,$04,$00,$04,$0a,$00,$1e,$0a,$1e,$04,$00,$04,$00; af5f
	db $02,$00,$02,$00,$02,$0a,$02,$00,$02,$0a,$04,$00,$04,$00,$04,$0a; af6f
	db $04,$00,$04,$00,$00,$00,$00,$00,$ff; af7f
Laf88:
	db $10,$00,$10,$00,$10,$07,$10,$07,$10,$07,$10,$00,$10,$00,$10,$07; af88
	db $10,$07,$10,$07,$00,$00,$10,$07,$10,$07,$00,$07,$10,$07,$10,$07; af98
	db $10,$1f,$10,$1f,$00,$1f,$00,$1f,$ff; afa8
Lafb1:
	db $05,$0e,$05,$00,$05,$00,$05,$00,$05,$00,$05,$0e,$05,$10,$00,$10; afb1
	db $00,$0e,$05,$00,$07,$00,$1f,$0e,$1f,$00,$1f,$00,$1f,$00,$1f,$10; afc1
	db $00,$10,$1b,$10,$1b,$10,$1b,$10,$00,$00,$ff; afd1
Lafdc:
	ld a,$07                    ; afdc
	call VZ_KBROW               ; afde patched
	ld hl,(WRK+$05c)            ; afe4
	ld b,a                      ; afe7
	ld a,l                      ; afe8
	bit 5,b                     ; afe9
	jp nz,Laff4                 ; afeb
	cp $07                      ; afee
	jp z,Laff4                  ; aff0
	dec l                       ; aff3
Laff4:
	bit 4,b                     ; aff4
	jp nz,Lafff                 ; aff6
	cp $19                      ; aff9
	jp z,Lafff                  ; affb
	inc l                       ; affe
Lafff:
	ld a,h                      ; afff
	bit 2,b                     ; b000
	jp nz,Lb00b                 ; b002
	cp $0c                      ; b005
	jp z,Lb00b                  ; b007
	dec h                       ; b00a
Lb00b:
	bit 3,b                     ; b00b
	jp nz,Lb016                 ; b00d
	cp $30                      ; b010
	jp z,Lb016                  ; b012
	inc h                       ; b015
Lb016:
	ld (WRK+$05c),hl            ; b016
	ret                         ; b019
Lb01a:
	ret                         ; b01a
Lb01b:
Lb023:
	jp VZ_FRAME                 ; b01b patched
Lb07c:
	push af
	ld a,MAP_GFX
	out (MAPPORT),a
	pop af
	call Lb07c_b
	push af
	ld a,MAP_NORMAL
	out (MAPPORT),a
	pop af
	ret
Lb07c_b:
	ld a,$40                    ; b07c
	sub b                       ; b07e
	ld (Lb0a0+1),a              ; b07f
	push de                     ; b082
	ld e,h                      ; b083
	ld d,$00                    ; b084
	ld h,d                      ; b086
	ld a,l                      ; b087
	add a,a                     ; b088
	add a,a                     ; b089
	add a,a                     ; b08a
	ld l,a                      ; b08b
	add hl,hl                   ; b08c
	add hl,hl                   ; b08d
	add hl,hl                   ; b08e
	add hl,de                   ; b08f
	ld de,BUF+$000              ; b090
	add hl,de                   ; b093
	pop de                      ; b094
Lb095:
	push bc                     ; b095
Lb096:
	ld a,(de)                   ; b096
	or a                        ; b097
	jp m,Lb09c                  ; b098
	ld (hl),a                   ; b09b
Lb09c:
	inc de                      ; b09c
	inc l                       ; b09d
	djnz Lb096                  ; b09e
Lb0a0:
	ld c,$3b                    ; b0a0
	add hl,bc                   ; b0a2
	pop bc                      ; b0a3
	dec c                       ; b0a4
	jp nz,Lb095                 ; b0a5
	ret                         ; b0a8
Lb0a9:
	push de                     ; b0a9
	ld e,h                      ; b0aa
	ld d,$00                    ; b0ab
	ld h,d                      ; b0ad
	ld a,l                      ; b0ae
	add a,a                     ; b0af
	add a,a                     ; b0b0
	add a,a                     ; b0b1
	ld l,a                      ; b0b2
	add hl,hl                   ; b0b3
	add hl,hl                   ; b0b4
	add hl,hl                   ; b0b5
	add hl,de                   ; b0b6
	ld de,BUF+$000              ; b0b7
	add hl,de                   ; b0ba
	pop de                      ; b0bb
	ret                         ; b0bc
Lb0bd:
	ld d,$00                    ; b0bd
	ld l,d                      ; b0bf
	ld b,$08                    ; b0c0
Lb0c2:
	add hl,hl                   ; b0c2
	jp nc,Lb0c7                 ; b0c3
	add hl,de                   ; b0c6
Lb0c7:
	djnz Lb0c2                  ; b0c7
	add hl,hl                   ; b0c9
	add hl,hl                   ; b0ca
	add hl,hl                   ; b0cb
	add hl,hl                   ; b0cc
	ret                         ; b0cd
Lb0ce:
	ld iy,Lb1f5                 ; b0ce
	ld ix,WRK+$079              ; b0d2
	ld b,$10                    ; b0d6
	ld de,$0018                 ; b0d8
Lb0db:
	exx                         ; b0db
	ld a,(ix+0)                 ; b0dc
	or a                        ; b0df
	jp z,Lb110                  ; b0e0
	ld a,(ix+5)                 ; b0e3
	sub $20                     ; b0e6
	ld h,a                      ; b0e8
	ld a,$00                    ; b0e9
	jp nc,Lb0f6                 ; b0eb
	ld a,$20                    ; b0ee
	sub (ix+5)                  ; b0f0
	ld h,a                      ; b0f3
	ld a,$44                    ; b0f4
Lb0f6:
	ld (Lb109+1),a              ; b0f6
	ld a,(ix+3)                 ; b0f9
	ld (Lb0ff+2),a              ; b0fc
Lb0ff:
	ld a,(iy+29)                ; b0ff
	add a,$03                   ; b102
	ld e,a                      ; b104
	call Lb0bd                  ; b105
	ld a,h                      ; b108
Lb109:
	neg                         ; b109
	add a,$20                   ; b10b
	ld (ix+2),a                 ; b10d
Lb110:
	exx                         ; b110
	add ix,de                   ; b111
	djnz Lb0db                  ; b113
	ret                         ; b115
Lb116:
	ld a,(WRK+$066)             ; b116
	ld c,a                      ; b119
	ld a,$1b                    ; b11a
	sub c                       ; b11c
	ld (Lb156+1),a              ; b11d
	ld c,a                      ; b120
	ld a,$1e                    ; b121
	sub c                       ; b123
	ld (Lb143+1),a              ; b124
	ld iy,Lb1f5                 ; b127
	ld ix,WRK+$229              ; b12b
	ld de,$0006                 ; b12f
	ld b,e                      ; b132
Lb133:
	exx                         ; b133
	ld a,(ix+0)                 ; b134
	or a                        ; b137
	jr z,Lb15f                  ; b138
	ld a,(ix+3)                 ; b13a
	ld (Lb140+2),a              ; b13d
Lb140:
	ld e,(iy+19)                ; b140
Lb143:
	ld h,$09                    ; b143
	ld d,$00                    ; b145
	ld l,d                      ; b147
	ld b,$08                    ; b148
Lb14a:
	add hl,hl                   ; b14a
	jp nc,Lb14f                 ; b14b
	add hl,de                   ; b14e
Lb14f:
	djnz Lb14a                  ; b14f
	add hl,hl                   ; b151
	add hl,hl                   ; b152
	add hl,hl                   ; b153
	add hl,hl                   ; b154
	ld a,h                      ; b155
Lb156:
	add a,$15                   ; b156
	ld l,a                      ; b158
	ld h,(ix+2)                 ; b159
	call Lb165                  ; b15c
Lb15f:
	exx                         ; b15f
	add ix,de                   ; b160
	djnz Lb133                  ; b162
	ret                         ; b164
Lb165:
	call Lb0a9                  ; b165
	ex de,hl                    ; b168
	ld a,(ix+3)                 ; b169
	sra a                       ; b16c
	sra a                       ; b16e
	ld c,a                      ; b170
	ld hl,Lb17c                 ; b171
	add hl,bc                   ; b174
	ld b,(hl)                   ; b175
	xor a                       ; b176
Lb177:
	ld (de),a                   ; b177
	inc de                      ; b178
	djnz Lb177                  ; b179
	ret                         ; b17b
Lb17c:
	db $05,$04,$03,$02,$01,$01,$01,$01,$01,$01; b17c
Lb186:
	ld a,(WRK+$066)             ; b186
	ld c,a                      ; b189
	ld a,$1b                    ; b18a
	sub c                       ; b18c
	ld (Lb1b4+1),a              ; b18d
	ld (Lb1bc+1),a              ; b190
	ld (Lb1da+1),a              ; b193
	ld (Lb1ea+1),a              ; b196
	ld (Lb1e1+1),a              ; b199
	ld iy,Lb1f5                 ; b19c
	ld ix,WRK+$079              ; b1a0
	ld b,$10                    ; b1a4
	ld de,$0018                 ; b1a6
Lb1a9:
	exx                         ; b1a9
	ld a,(ix+0)                 ; b1aa
	or a                        ; b1ad
	jp z,Lb1ef                  ; b1ae
	ld a,(ix+4)                 ; b1b1
Lb1b4:
	sub $15                     ; b1b4
	ld h,a                      ; b1b6
	ld a,$00                    ; b1b7
	jp nc,Lb1c4                 ; b1b9
Lb1bc:
	ld a,$15                    ; b1bc
	sub (ix+4)                  ; b1be
	ld h,a                      ; b1c1
	ld a,$44                    ; b1c2
Lb1c4:
	ld (Lb1d8+1),a              ; b1c4
	ld a,(ix+3)                 ; b1c7
	ld (Lb1cd+2),a              ; b1ca
Lb1cd:
	ld e,(iy+29)                ; b1cd
	ld a,e                      ; b1d0
	ld (Lb1e4+1),a              ; b1d1
	call Lb0bd                  ; b1d4
	ld a,h                      ; b1d7
Lb1d8:
	neg                         ; b1d8
Lb1da:
	add a,$15                   ; b1da
	ld (ix+1),a                 ; b1dc
	ld a,$1e                    ; b1df
Lb1e1:
	sub $15                     ; b1e1
	ld h,a                      ; b1e3
Lb1e4:
	ld e,$01                    ; b1e4
	call Lb0bd                  ; b1e6
	ld a,h                      ; b1e9
Lb1ea:
	add a,$15                   ; b1ea
	ld (ix+15),a                ; b1ec
Lb1ef:
	exx                         ; b1ef
	add ix,de                   ; b1f0
	djnz Lb1a9                  ; b1f2
	ret                         ; b1f4
Lb1f5:
	db $10,$10,$0e,$0e,$0d,$0d,$0b,$0b,$09,$09,$08,$08,$06,$06,$06,$06; b1f5
	db $05,$05,$05,$05,$03,$03,$03,$03,$02,$02,$02,$02,$01,$01,$01,$01; b205
	db $01,$01,$01,$01,$01,$01,$01,$01,$00,$01,$09,$05,$07,$04,$08,$02; b215
	db $06,$03,$0a,$0a,$00,$04,$11,$09,$0c,$05,$10,$07,$0e,$01,$14,$08; b225
	db $0d,$02,$13,$06,$0f,$03,$12,$0a,$0b,$0a,$0b,$0a,$0b; b235
Lb242:
	ret                         ; b242
Lb243:
	ld a,(WRK+$051)             ; b243
	or a                        ; b246
	ret z                       ; b247
	ld a,(WRK+$050)             ; b248
	dec a                       ; b24b
	jp m,Lb27b                  ; b24c
	jp z,Lb26a                  ; b24f
	ld a,(WRK+$04e)             ; b252
	inc a                       ; b255
	ld (WRK+$04e),a             ; b256
	cp $13                      ; b259
	jp c,Lb27b                  ; b25b
	xor a                       ; b25e
	ld (WRK+$050),a             ; b25f
	ld a,$13                    ; b262
	ld (WRK+$04e),a             ; b264
	jp Lb27b                    ; b267
Lb26a:
	ld a,(WRK+$04e)             ; b26a
	dec a                       ; b26d
	ld (WRK+$04e),a             ; b26e
	jp p,Lb27b                  ; b271
	xor a                       ; b274
	ld (WRK+$050),a             ; b275
	ld (WRK+$04e),a             ; b278
Lb27b:
	ld a,(WRK+$002)             ; b27b
	add a,a                     ; b27e
	ld e,a                      ; b27f
	ld d,$00                    ; b280
	ld hl,Lb2af                 ; b282
	add hl,de                   ; b285
	ld e,(hl)                   ; b286
	inc hl                      ; b287
	ld d,(hl)                   ; b288
	ld hl,(WRK+$04e)            ; b289
	inc hl                      ; b28c
	add hl,de                   ; b28d
	ex de,hl                    ; b28e
	ld ix,WRK+$021              ; b28f
	ld b,$14                    ; b293
	ld hl,(WRK+$000)            ; b295
Lb298:
	ld a,(de)                   ; b298
	dec a                       ; b299
	jp m,Lb2a9                  ; b29a
	jp nz,Lb2a3                 ; b29d
	ld (ix+0),h                 ; b2a0
Lb2a3:
	inc de                      ; b2a3
	inc ix                      ; b2a4
	djnz Lb298                  ; b2a6
	ret                         ; b2a8
Lb2a9:
	ld (ix+0),l                 ; b2a9
	jp Lb2a3                    ; b2ac
Lb2af:
	dw Lb625                    ; b2af
	dw Lb5fd                    ; b2b1
	dw Lb5d5                    ; b2b3
	dw Lb5ad                    ; b2b5
	dw Lb585                    ; b2b7
	dw Lb55d                    ; b2b9
Lb2bb:
	ld a,$08                    ; b2bb
	call VZ_KBROW               ; b2bd patched
	bit 0,a                     ; b2c3
	jp z,Lb31d                  ; b2c5
	ld a,$06                    ; b2c8
	call VZ_KBROW               ; b2ca patched
	inc a                       ; b2d0
	jp nz,Lb2d8                 ; b2d1
	ld (Lb2d8+1),a              ; b2d4
	ret                         ; b2d7
Lb2d8:
	ld a,$00                    ; b2d8
	or a                        ; b2da
	jr z,Lb2e6                  ; b2db
Lb2dd:
	ld a,$06                    ; b2dd
	inc a                       ; b2df
	and $07                     ; b2e0
	ld (Lb2dd+1),a              ; b2e2
	ret nz                      ; b2e5
Lb2e6:
	inc a                       ; b2e6
	ld (Lb2d8+1),a              ; b2e7
	ld ix,WRK+$229              ; b2ea
	ld de,$0006                 ; b2ee
	ld b,$06                    ; b2f1
Lb2f3:
	ld a,(ix+0)                 ; b2f3
	or a                        ; b2f6
	jp z,Lb2ff                  ; b2f7
	add ix,de                   ; b2fa
	djnz Lb2f3                  ; b2fc
	ret                         ; b2fe
Lb2ff:
	ld (ix+0),$01               ; b2ff
	ld hl,(WRK+$05c)            ; b303
	dec h                       ; b306
	inc l                       ; b307
	ld (ix+1),l                 ; b308
	ld (ix+2),h                 ; b30b
	ld (ix+3),$01               ; b30e
	ld (ix+4),d                 ; b312
	ld (ix+5),d                 ; b315
	ld a,$04                    ; b318
	jp L9600                    ; b31a
Lb31d:
	ld a,$55                    ; b31d
	rlca                        ; b31f
	ld (Lb31d+1),a              ; b320
	ret c                       ; b323
	jp Lb2e6                    ; b324
Lb327:
	ld ix,WRK+$229              ; b327
	ld de,$0006                 ; b32b
	ld bc,$0614                 ; b32e
	ld hl,$1f34                 ; b331
Lb334:
	bit 0,(ix+0)                ; b334
	jp z,Lb360                  ; b338
	ld a,(ix+4)                 ; b33b
	add a,(ix+5)                ; b33e
	jp z,Lb365                  ; b341
	ld a,(ix+2)                 ; b344
	add a,(ix+4)                ; b347
	ld (ix+2),a                 ; b34a
	cp l                        ; b34d
	jr nc,Lb35d                 ; b34e
	ld a,(ix+1)                 ; b350
	add a,(ix+5)                ; b353
	ld (ix+1),a                 ; b356
	cp h                        ; b359
	jp c,Lb360                  ; b35a
Lb35d:
	ld (ix+0),d                 ; b35d
Lb360:
	add ix,de                   ; b360
	djnz Lb334                  ; b362
	ret                         ; b364
Lb365:
	inc (ix+3)                  ; b365
	ld a,(ix+3)                 ; b368
	cp c                        ; b36b
	jr nc,Lb35d                 ; b36c
	jp Lb360                    ; b36e
Lb371:
	ret                         ; b371
Lb372:
	ret                         ; b372
Lb373:
	xor a                       ; b373
	call VZ_KBROW               ; b374 patched
	bit 6,a                     ; b37a
	ret nz                      ; b37c
	call VZ_BELL                ; b37d patched
Lb380:
	xor a                       ; b380
	call VZ_KBROW               ; b381 patched
	bit 6,a                     ; b387
	jp z,Lb380                  ; b389
Lb38c:
	call VZ_GETKY               ; b38c patched
	or a                        ; b38f
	jr z,Lb38c                  ; b390
	ret                         ; b392
Lb393:
	ld a,(WRK+$062)             ; b393
	dec a                       ; b396
	add a,a                     ; b397
	ld e,a                      ; b398
	ld d,$00                    ; b399
	ld hl,Lb3c2                 ; b39b
	add hl,de                   ; b39e
	ld c,(hl)                   ; b39f
	inc hl                      ; b3a0
	ld b,(hl)                   ; b3a1
	ld (WRK+$000),bc            ; b3a2
	ld hl,Lb3e6                 ; b3a6
	add hl,de                   ; b3a9
	ld e,(hl)                   ; b3aa
	inc hl                      ; b3ab
	ld d,(hl)                   ; b3ac
	ex de,hl                    ; b3ad
	ld de,WRK+$003              ; b3ae
	ld bc,$0014                 ; b3b1
	ldir                        ; b3b4
	ld hl,WRK+$003              ; b3b6
	ld de,WRK+$021              ; b3b9
	ld bc,$0014                 ; b3bc
	ldir                        ; b3bf
	ret                         ; b3c1
Lb3c2:
	db $84,$44,$a4,$06,$73,$f2,$f3,$75,$86,$66,$f7,$43,$94,$15,$a4,$06; b3c2
	db $f7,$74,$84,$44,$45,$94,$f7,$43,$96,$43,$f5,$43,$f1,$75,$77,$f1; b3d2
	db $84,$44,$f3,$75          ; b3e2
Lb3e6:
	dw Lb40a                    ; b3e6
	dw Lb41e                    ; b3e8
	dw Lb432                    ; b3ea
	dw Lb46e                    ; b3ec
	dw Lb446                    ; b3ee
	dw Lb45a                    ; b3f0
	dw Lb46e                    ; b3f2
	dw Lb482                    ; b3f4
	dw Lb46e                    ; b3f6
	dw Lb482                    ; b3f8
	dw Lb496                    ; b3fa
	dw Lb46e                    ; b3fc
	dw Lb4aa                    ; b3fe
	dw Lb46e                    ; b400
	dw Lb4be                    ; b402
	dw Lb4d2                    ; b404
	dw Lb482                    ; b406
	dw Lb46e                    ; b408
Lb40a:
	db $11,$11,$11,$11,$11,$11,$11,$11,$11,$11,$11,$11,$11,$11,$11,$11; b40a
	db $51,$55,$57,$77          ; b41a
Lb41e:
	db $51,$51,$51,$51,$51,$51,$51,$51,$51,$51,$51,$51,$51,$51,$51,$51; b41e
	db $51,$55,$72,$72          ; b42e
Lb432:
	db $72,$72,$72,$72,$72,$72,$73,$43,$73,$72,$73,$43,$73,$72,$73,$43; b432
	db $73,$72,$73,$43          ; b442
Lb446:
	db $11,$11,$11,$11,$11,$11,$11,$11,$11,$11,$11,$11,$11,$11,$11,$11; b446
	db $15,$55,$57,$77          ; b456
Lb45a:
	db $77,$77,$77,$77,$77,$77,$77,$77,$77,$77,$57,$55,$54,$50,$51,$11; b45a
	db $01,$01,$00,$00          ; b46a
Lb46e:
	db $72,$72,$72,$72,$72,$72,$77,$57,$55,$54,$54,$74,$72,$77,$57,$55; b46e
	db $54,$54,$74,$72          ; b47e
Lb482:
	db $04,$04,$04,$44,$44,$44,$44,$04,$04,$04,$44,$44,$44,$04,$04,$44; b482
	db $44,$04,$44,$04          ; b492
Lb496:
	db $77,$77,$77,$77,$77,$77,$77,$77,$77,$77,$77,$77,$77,$74,$74,$44; b496
	db $04,$04,$00,$00          ; b4a6
Lb4aa:
	db $33,$13,$11,$01,$11,$13,$33,$23,$33,$13,$11,$01,$11,$13,$23,$13; b4aa
	db $11,$01,$13,$01          ; b4ba
Lb4be:
	db $43,$16,$74,$74,$43,$16,$74,$74,$43,$16,$74,$74,$43,$16,$74,$74; b4be
	db $43,$16,$74,$74          ; b4ce
Lb4d2:
	db $11,$11,$11,$11,$11,$11,$11,$11,$11,$11,$11,$11,$11,$11,$11,$11; b4d2
	db $11,$51,$55,$75          ; b4e2
Lb4e6:
	ld hl,WRK+$002              ; b4e6
	dec (hl)                    ; b4e9
	jp p,Lb4ef                  ; b4ea
	ld (hl),$05                 ; b4ed
Lb4ef:
	ld a,(hl)                   ; b4ef
	add a,a                     ; b4f0
	ld e,a                      ; b4f1
	ld d,$00                    ; b4f2
	ld hl,Lb515                 ; b4f4
	add hl,de                   ; b4f7
	ld e,(hl)                   ; b4f8
	inc hl                      ; b4f9
	ld d,(hl)                   ; b4fa
	ld ix,WRK+$035              ; b4fb
	ld hl,(WRK+$000)            ; b4ff
	ld b,$0a                    ; b502
Lb504:
	ld (ix+0),l                 ; b504
	ld a,(de)                   ; b507
	or a                        ; b508
	jp z,Lb50f                  ; b509
	ld (ix+0),h                 ; b50c
Lb50f:
	inc de                      ; b50f
	inc ix                      ; b510
	djnz Lb504                  ; b512
	ret                         ; b514
Lb515:
	dw Lb553                    ; b515
	dw Lb549                    ; b517
	dw Lb53f                    ; b519
	dw Lb535                    ; b51b
	dw Lb52b                    ; b51d
	dw Lb521                    ; b51f
Lb521:
	db $01,$00,$01,$01,$00,$00,$01,$01,$01,$00; b521
Lb52b:
	db $01,$00,$00,$01,$01,$00,$00,$01,$01,$01; b52b
Lb535:
	db $00,$01,$00,$01,$01,$00,$00,$00,$01,$01; b535
Lb53f:
	db $00,$01,$00,$00,$01,$01,$00,$00,$00,$01; b53f
Lb549:
	db $00,$01,$01,$00,$00,$01,$01,$00,$00,$00; b549
Lb553:
	db $01,$00,$01,$00,$00,$01,$01,$01,$00,$00; b553
Lb55d:
	db $00,$00,$00,$00,$01,$01,$01,$00,$00,$00,$01,$01,$01,$00,$00,$00; b55d
	db $01,$01,$00,$01,$02,$02,$02,$02,$02,$02,$02,$02,$02,$02,$02,$02; b56d
	db $02,$02,$02,$02,$02,$02,$02,$02; b57d
Lb585:
	db $00,$00,$00,$01,$01,$01,$01,$00,$00,$00,$01,$01,$01,$00,$00,$01; b585
	db $01,$00,$01,$00,$02,$02,$02,$02,$02,$02,$02,$02,$02,$02,$02,$02; b595
	db $02,$02,$02,$02,$02,$02,$02,$02; b5a5
Lb5ad:
	db $00,$01,$01,$01,$01,$00,$00,$00,$00,$01,$01,$01,$00,$00,$01,$01; b5ad
	db $00,$01,$01,$00,$02,$02,$02,$02,$02,$02,$02,$02,$02,$02,$02,$02; b5bd
	db $02,$02,$02,$02,$02,$02,$02,$02; b5cd
Lb5d5:
	db $01,$01,$01,$00,$00,$00,$00,$01,$01,$01,$00,$00,$00,$01,$01,$00; b5d5
	db $01,$01,$00,$00,$02,$02,$02,$02,$02,$02,$02,$02,$02,$02,$02,$02; b5e5
	db $02,$02,$02,$02,$02,$02,$02,$02; b5f5
Lb5fd:
	db $01,$01,$00,$00,$00,$00,$01,$01,$01,$00,$00,$00,$01,$01,$00,$00; b5fd
	db $01,$01,$00,$01,$02,$02,$02,$02,$02,$02,$02,$02,$02,$02,$02,$02; b60d
	db $02,$02,$02,$02,$02,$02,$02,$02; b61d
Lb625:
	db $01,$00,$00,$00,$00,$01,$01,$01,$00,$00,$00,$01,$01,$00,$00,$00; b625
	db $01,$01,$00,$01,$02,$02,$02,$02,$02,$02,$02,$02,$02,$02,$02,$02; b635
	db $02,$02,$02,$02,$02,$02,$02,$02; b645
Lb64d:
	ld hl,WRK+$25f              ; b64d
	bit 7,(hl)                  ; b650
	ret nz                      ; b652
	dec (hl)                    ; b653
	jp m,La081                  ; b654
	ld hl,$0b10                 ; b657
	ld (MZW+$171),hl            ; b65a
	ld a,(WRK+$062)             ; b65d
	dec a                       ; b660
	add a,a                     ; b661
	ld e,a                      ; b662
	ld d,$00                    ; b663
	ld hl,Lb6af                 ; b665
	add hl,de                   ; b668
	ld e,(hl)                   ; b669
	inc hl                      ; b66a
	ld d,(hl)                   ; b66b
	call VZ_MSG                 ; b66c patched
	ld hl,BUF+$45c              ; b66d
	ld de,BUF+$45d              ; b670
	ld bc,$0007                 ; b673
	ld (hl),$70                 ; b676
	ldir                        ; b678
	ld hl,$0910                 ; b67a
	ld (MZW+$171),hl            ; b67d
	ld de,Lb6a7                 ; b680
	call VZ_MSG                 ; b683 patched
	ld hl,BUF+$3dc              ; b684
	ld de,BUF+$3dd              ; b687
	ld bc,$0007                 ; b68a
	ld (hl),$70                 ; b68d
	ldir                        ; b68f
	ld a,(WRK+$064)             ; b691
	ld c,a                      ; b694
	and $10                     ; b695
	jr z,Lb69e                  ; b697
	ld a,$21                    ; b699
	ld (VRAM+$17e),a            ; b69b
Lb69e:
	ld a,c                      ; b69e
	and $0f                     ; b69f
	or $20                      ; b6a1
	ld (VRAM+$17f),a            ; b6a3
	ret                         ; b6a6
Lb6a7:
	db $53,$54,$41,$47,$45,$20,$20,$0d; b6a7
Lb6af:
	dw Lb6d3                    ; b6af
	dw Lb6dc                    ; b6b1
	dw Lb6e5                    ; b6b3
	dw Lb6ee                    ; b6b5
	dw Lb6f7                    ; b6b7
	dw Lb700                    ; b6b9
	dw Lb709                    ; b6bb
	dw Lb712                    ; b6bd
	dw Lb71b                    ; b6bf
	dw Lb724                    ; b6c1
	dw Lb72d                    ; b6c3
	dw Lb736                    ; b6c5
	dw Lb73f                    ; b6c7
	dw Lb748                    ; b6c9
	dw Lb751                    ; b6cb
	dw Lb75a                    ; b6cd
	dw Lb763                    ; b6cf
	dw Lb76c                    ; b6d1
Lb6d3:
	db $20,$20,$4d,$4f,$4f,$54,$20,$20,$0d; b6d3
Lb6dc:
	db $20,$47,$45,$45,$5a,$41,$20,$20,$0d; b6dc
Lb6e5:
	db $20,$20,$41,$4d,$41,$52,$20,$20,$0d; b6e5
Lb6ee:
	db $43,$45,$49,$43,$49,$45,$4c,$20,$0d; b6ee
Lb6f7:
	db $20,$42,$4f,$4e,$55,$53,$20,$20,$0d; b6f7
Lb700:
	db $20,$4f,$4c,$49,$53,$49,$53,$20,$0d; b700
Lb709:
	db $4c,$55,$43,$41,$53,$49,$41,$20,$0d; b709
Lb712:
	db $20,$20,$49,$44,$41,$20,$20,$20,$0d; b712
Lb71b:
	db $20,$20,$52,$45,$56,$49,$20,$20,$0d; b71b
Lb724:
	db $20,$4d,$49,$4e,$49,$41,$20,$20,$0d; b724
Lb72d:
	db $20,$50,$41,$52,$4d,$53,$20,$20,$0d; b72d
Lb736:
	db $20,$42,$4f,$4e,$55,$53,$20,$20,$0d; b736
Lb73f:
	db $20,$44,$52,$41,$49,$4c,$20,$20,$0d; b73f
Lb748:
	db $20,$41,$53,$55,$54,$45,$20,$20,$0d; b748
Lb751:
	db $20,$56,$49,$43,$45,$4c,$20,$20,$0d; b751
Lb75a:
	db $20,$4e                  ; b75a
Lb75c:
	db $41,$54,$55,$52,$41,$20,$0d; b75c
Lb763:
	db $20,$20,$4e,$41,$52,$4b,$20,$20,$0d; b763
Lb76c:
	db $41,$42,$53,$59,$4d,$42,$45,$4c,$0d; b76c
Lb775:
	ld a,(WRK+$062)             ; b775
	dec a                       ; b778
	add a,a                     ; b779
	ld e,a                      ; b77a
	ld d,$00                    ; b77b
	ld hl,Lb7c9                 ; b77d
	add hl,de                   ; b780
	ld e,(hl)                   ; b781
	inc hl                      ; b782
	ld d,(hl)                   ; b783
	push de                     ; b784
	pop ix                      ; b785
	ld iy,VRAM+$500             ; b787
	ld c,$05                    ; b78b
Lb78d:
	push ix                     ; b78d
	ld b,$10                    ; b78f
Lb791:
	ld a,(ix+0)                 ; b791
	ld (iy+0),a                 ; b794
	ld a,(ix+16)                ; b797
	ld (iy+80),a                ; b79a
	inc ix                      ; b79d
	inc iy                      ; b79f
	djnz Lb791                  ; b7a1
	pop ix                      ; b7a3
	dec c                       ; b7a5
	jr nz,Lb78d                 ; b7a6
	ret                         ; b7a8
Lb7a9:
	ret                         ; b7a9
Lb7aa:
	ret                         ; b7aa
Lb7ab:
	ld a,(WRK+$05d)             ; b7ab
	sub $0c                     ; b7ae
	sra a                       ; b7b0
	sra a                       ; b7b2
	ld e,a                      ; b7b4
	ld d,$00                    ; b7b5
	ld hl,Lab49                 ; b7b7
	add hl,de                   ; b7ba
	ld a,(hl)                   ; b7bb
	neg                         ; b7bc
	ld c,a                      ; b7be
	ld a,(WRK+$260)             ; b7bf
	add a,c                     ; b7c2
	and $1f                     ; b7c3
	ld (WRK+$260),a             ; b7c5
	ret                         ; b7c8
Lb7c9:
	dw Lb7ed                    ; b7c9
	dw Lb80d                    ; b7cb
	dw Lb82d                    ; b7cd
	dw Lb84d                    ; b7cf
	dw Lb86d                    ; b7d1
	dw Lb88d                    ; b7d3
	dw Lb8ad                    ; b7d5
	dw Lb8cd                    ; b7d7
	dw Lb8ed                    ; b7d9
	dw Lb90d                    ; b7db
	dw Lb92d                    ; b7dd
	dw Lb84d                    ; b7df
	dw Lb94d                    ; b7e1
	dw Lb84d                    ; b7e3
	dw Lb96d                    ; b7e5
	dw Lb98d                    ; b7e7
	dw Lb9af                    ; b7e9
	dw Lb9cf                    ; b7eb
Lb7ed:
	db $75,$75,$05,$54,$54,$75,$75,$75,$51,$05,$05,$45,$45,$45,$75,$75; b7ed
	db $51,$05,$05,$05,$54,$54,$51,$51,$51,$51,$05,$05,$45,$45,$45,$45; b7fd
Lb80d:
	db $24,$24,$72,$72,$72,$72,$72,$24,$72,$24,$72,$72,$72,$72,$24,$72; b80d
	db $72,$04,$24,$04,$04,$72,$44,$64,$24,$72,$44,$64,$04,$24,$04,$04; b81d
Lb82d:
	db $73,$55,$73,$73,$05,$73,$73,$73,$73,$73,$73,$55,$73,$73,$73,$55; b82d
	db $05,$55,$43,$05,$05,$55,$43,$05,$55,$43,$05,$55,$55,$05,$05,$55; b83d
Lb84d:
	db $76,$24,$24,$66,$66,$77,$77,$76,$76,$76,$76,$24,$66,$66,$76,$76; b84d
	db $24,$24,$24,$24,$66,$66,$77,$77,$72,$72,$24,$24,$24,$66,$66,$72; b85d
Lb86d:
	db $75,$75,$26,$26,$26,$26,$75,$75,$75,$26,$75,$75,$75,$75,$26,$75; b86d
	db $04,$04,$26,$77,$44,$26,$77,$04,$26,$04,$04,$26,$77,$04,$44,$77; b87d
Lb88d:
	db $00,$25,$00,$00,$00,$00,$00,$00,$00,$00,$35,$00,$25,$00,$00,$00; b88d
	db $35,$25,$00,$35,$00,$25,$00,$25,$00,$35,$00,$35,$25,$00,$00,$00; b89d
Lb8ad:
	db $76,$51,$55,$55,$57,$57,$76,$76,$76,$76,$76,$51,$55,$57,$57,$76; b8ad
	db $51,$51,$51,$55,$55,$57,$57,$72,$72,$51,$51,$51,$51,$55,$57,$57; b8bd
Lb8cd:
	db $44,$45,$44,$44,$05,$44,$44,$45,$44,$44,$44,$45,$44,$44,$44,$45; b8cd
	db $05,$45,$04,$05,$05,$45,$04,$05,$45,$04,$05,$45,$45,$05,$05,$45; b8dd
Lb8ed:
	db $76,$33,$73,$73,$23,$76,$76,$76,$33,$33,$76,$76,$31,$33,$76,$76; b8ed
	db $33,$33,$73,$73,$23,$23,$31,$31,$31,$33,$33,$31,$31,$33,$33,$31; b8fd
Lb90d:
	db $04,$24,$24,$66,$66,$77,$77,$04,$04,$04,$04,$24,$66,$66,$04,$04; b90d
	db $24,$24,$24,$24,$66,$66,$77,$77,$04,$04,$24,$24,$24,$66,$66,$76; b91d
Lb92d:
	db $00,$00,$00,$22,$22,$72,$72,$00,$00,$02,$02,$22,$22,$72,$72,$00; b92d
	db $00,$02,$02,$02,$22,$22,$72,$72,$02,$02,$02,$02,$22,$22,$72,$72; b93d
Lb94d:
	db $51,$51,$51,$51,$11,$23,$11,$11,$51,$51,$50,$33,$11,$32,$16,$11; b94d
	db $51,$16,$00,$51,$16,$23,$00,$31,$51,$16,$00,$50,$16,$32,$33,$16; b95d
Lb96d:
	db $74,$74,$24,$66,$76,$74,$74,$74,$74,$74,$74,$24,$66,$76,$74,$74; b96d
	db $04,$04,$04,$66,$76,$04,$04,$66,$04,$04,$04,$04,$04,$76,$04,$04; b97d
Lb98d:
	db $55,$55,$55,$55,$55,$55,$55,$55,$55,$55,$55,$55,$55,$55,$55,$55; b98d
	db $55,$55,$26,$26,$26,$24,$66,$04,$76,$04,$04,$26,$04,$66,$75,$75; b99d
	db $76,$75                  ; b9ad
Lb9af:
	db $44,$24,$24,$66,$66,$77,$77,$44,$44,$44,$44,$24,$66,$66,$44,$44; b9af
	db $24,$24,$24,$24,$66,$66,$77,$77,$00,$00,$24,$24,$24,$66,$66,$00; b9bf
Lb9cf:
	db $45,$52,$45,$26,$66,$66,$76,$76,$45,$52,$45,$45,$26,$66,$76,$45; b9cf
	db $53,$26,$26,$26,$26,$66,$66,$76,$76,$76,$76,$26,$26,$66,$76,$76; b9df
	db $00,$0f,$00,$00,$1a,$00,$2a,$00,$00,$00,$01,$09,$11,$00,$03,$01; b9ef
	db $00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33; b9ff
	db $00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33; ba0f
	db $00,$33,$00,$33,$00,$33,$00,$33,$2b,$00,$93,$11,$00,$33,$00,$33; ba1f
	db $00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33; ba2f
	db $00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33; ba3f
	db $00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33; ba4f
	db $00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33; ba5f
	db $00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33; ba6f
	db $00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33; ba7f
	db $00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33; ba8f
	db $00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33; ba9f
	db $00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33; baaf
	db $00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33; babf
	db $00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33; bacf
	db $00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33; badf
	db $00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33,$00,$33; baef
Lbaff:
	db $00                      ; baff
