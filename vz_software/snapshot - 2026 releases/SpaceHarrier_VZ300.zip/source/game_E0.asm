L1200:
	call VZ_INIT                ; 1200 patched
	ld hl,$0000                 ; 121a
	ld (WRK+$073),hl            ; 121d
	ld hl,$0100                 ; 1220
	ld (WRK+$071),hl            ; 1223
	ld hl,$0000                 ; 1226
	ld (WRK+$06b),hl            ; 1229
	ld (WRK+$06d),hl            ; 122c
	ld a,$5a                    ; 1239
	ld (WRK+$3ff),a             ; 123b
L1244:
L124b:
L1250:
	ld hl,WRK+$000              ; 1250
	ld de,WRK+$001              ; 1253
	ld bc,$02ff                 ; 1256
	ld (hl),l                   ; 1259
	ldir                        ; 125a
	call L16ec                  ; 125c
	call L18a8                  ; 125f
	call L161e                  ; 1262
	call L2189                  ; 1265
L1268:
	call L1658                  ; 1268
	call L1e08                  ; 126b
	call L16e2                  ; 126e
	call L16e7                  ; 1271
	call L1e83                  ; 1274
	call L218e                  ; 1277
	call L228d                  ; 127a
	xor a                       ; 127d
	ld (WRK+$25e),a             ; 127e
	ld (WRK+$25b),a             ; 1281
	ld (L1be8),a                ; 1284
	ld (L1c79),a                ; 1287
	ld (WRK+$266),a             ; 128a
	call L1d21                  ; 128d
	ld a,(WRK+$062)             ; 1290
	cp $12                      ; 1293
	jp z,L1448                  ; 1295
	cp $05                      ; 1298
	jp z,L157b                  ; 129a
	cp $0c                      ; 129d
	jp z,L157b                  ; 129f
L12a2:
	ld sp,MZW+$0f0              ; 12a2
	ld de,$0001                 ; 12a5
	call L1a6a                  ; 12a8
	call L1dae                  ; 12ab
	call L1a74                  ; 12ae
	call L1da4                  ; 12b1
	call L1d90                  ; 12b4
	call L1da4                  ; 12b7
	call L1d90                  ; 12ba
	call L1da4                  ; 12bd
	call L1d90                  ; 12c0
	call L1d9f                  ; 12c3
	call L1e0d                  ; 12c6
	call L1d26                  ; 12c9
	call L1be9                  ; 12cc
	call L1a74                  ; 12cf
	ld a,$06                    ; 12d2
	ld (WRK+$068),a             ; 12d4
L12d7:
	call L1d90                  ; 12d7
	call L1d95                  ; 12da
	call L1a83                  ; 12dd
	call L1d7c                  ; 12e0
	ld a,(WRK+$068)             ; 12e3
	dec a                       ; 12e6
	ld (WRK+$068),a             ; 12e7
	jp p,L12d7                  ; 12ea
	call L1d3f                  ; 12ed
	call L1d35                  ; 12f0
	call L1d3a                  ; 12f3
	call L1a74                  ; 12f6
	call L1d86                  ; 12f9
	call L1e99                  ; 12fc
	call L1d8b                  ; 12ff
	call L1de8                  ; 1302
	call L217e                  ; 1305
	call L1e88                  ; 1308
	call L21c6                  ; 130b
	call L1d70                  ; 130e
	call L1d76                  ; 1311
	call L1d9f                  ; 1314
	call L1da9                  ; 1317
	call L1a79                  ; 131a
	call L1a65                  ; 131d
	call L1e7e                  ; 1320
	call L1d2b                  ; 1323
	call L1dfd                  ; 1326
	ld a,(WRK+$25b)             ; 1329
	or a                        ; 132c
	jp nz,L1336                 ; 132d
	call L1a3c                  ; 1330
	jp nz,L12a2                 ; 1333
L1336:
	call L1dd4                  ; 1336
	ld a,$01                    ; 1339
	ld (WRK+$25e),a             ; 133b
	ld (L1a64),a                ; 133e
L1341:
	ld sp,MZW+$0f0              ; 1341
	ld de,$0001                 ; 1344
	call L1a6a                  ; 1347
	call L1a74                  ; 134a
	call L1d9f                  ; 134d
	call L1da4                  ; 1350
	call L1da4                  ; 1353
	call L1da4                  ; 1356
	call L1d26                  ; 1359
	call L1e0d                  ; 135c
	call L1be9                  ; 135f
	xor a                       ; 1362
	ld (WRK+$25d),a             ; 1363
	ld a,$06                    ; 1366
	ld (WRK+$068),a             ; 1368
L136b:
	call L1d90                  ; 136b
	call L1d95                  ; 136e
	call L1a83                  ; 1371
	call L1dcf                  ; 1374
	ld a,(WRK+$068)             ; 1377
	dec a                       ; 137a
	ld (WRK+$068),a             ; 137b
	jp p,L136b                  ; 137e
	call L1d3f                  ; 1381
	call L1d35                  ; 1384
	call L1d3a                  ; 1387
	call L1a74                  ; 138a
	call L1d9f                  ; 138d
	call L1de8                  ; 1390
	call L217e                  ; 1393
	call L1e94                  ; 1396
	call L1e99                  ; 1399
	call L21c6                  ; 139c
	call L1d70                  ; 139f
	call L1dde                  ; 13a2
	call L1a74                  ; 13a5
	call L1da9                  ; 13a8
	call L1a79                  ; 13ab
	call L1a65                  ; 13ae
	call L1d2b                  ; 13b1
	call L1dfd                  ; 13b4
	call L1dc0                  ; 13b7
	jp z,L13c3                  ; 13ba
	call L1a3c                  ; 13bd
	jp nz,L1341                 ; 13c0
L13c3:
	ld a,$1e                    ; 13c3
	ld (L141f+1),a              ; 13c5
L13c8:
	call VZ_FRAME
	ld bc,$07d0                 ; 13c8
L13cb:
	cpi                         ; 13cb
	jp pe,L13cb                 ; 13cd
	ld sp,MZW+$0f0              ; 13d0
	ld de,$0001                 ; 13d3
	call L1a6a                  ; 13d6
	xor a                       ; 13d9
	ld (WRK+$25d),a             ; 13da
	call L1a74                  ; 13dd
	call L1d9f                  ; 13e0
	call L1da4                  ; 13e3
	call L1da4                  ; 13e6
	call L1da4                  ; 13e9
	call L1d26                  ; 13ec
	call L1e0d                  ; 13ef
	call L1be9                  ; 13f2
	call L1a74                  ; 13f5
	call L1d9f                  ; 13f8
	call L1de8                  ; 13fb
	call L217e                  ; 13fe
	call L1e94                  ; 1401
	call L1e99                  ; 1404
	call L21c6                  ; 1407
	call L1d70                  ; 140a
	call L1a74                  ; 140d
	call L1da9                  ; 1410
	call L1a79                  ; 1413
	call L1a65                  ; 1416
	call L1d2b                  ; 1419
	call L1dfd                  ; 141c
L141f:
	ld a,$00                    ; 141f
	dec a                       ; 1421
	ld (L141f+1),a              ; 1422
	jp nz,L13c8                 ; 1425
	ld a,(WRK+$064)             ; 1428
	add a,$01                   ; 142b
	daa                         ; 142d
	ld (WRK+$064),a             ; 142e
	ld a,(WRK+$062)             ; 1431
	inc a                       ; 1434
	ld (WRK+$062),a             ; 1435
	cp $13                      ; 1438
	jp c,L1268                  ; 143a
	ld a,$01                    ; 143d
	ld (WRK+$062),a             ; 143f
	ld (WRK+$064),a             ; 1442
	jp L1268                    ; 1445
L1448:
	ld hl,L1567                 ; 1448
	ld a,(L217d)                ; 144b
	or a                        ; 144e
	jr z,L1454                  ; 144f
	ld hl,L156f                 ; 1451
L1454:
	ld (L1565),hl               ; 1454
	ld a,(hl)                   ; 1457
	ld (WRK+$25c),a             ; 1458
L145b:
	call L1dd9                  ; 145b
	ld a,$01                    ; 145e
	ld (WRK+$25e),a             ; 1460
	ld (L1a64),a                ; 1463
L1466:
	ld sp,MZW+$0f0              ; 1466
	ld de,$0001                 ; 1469
	call L1a6a                  ; 146c
	call L1a74                  ; 146f
	call L1d9f                  ; 1472
	call L1da4                  ; 1475
	call L1da4                  ; 1478
	call L1da4                  ; 147b
	call L1d26                  ; 147e
	call L1e0d                  ; 1481
	call L1be9                  ; 1484
	xor a                       ; 1487
	ld (WRK+$25d),a             ; 1488
	ld a,$06                    ; 148b
	ld (WRK+$068),a             ; 148d
L1490:
	call L1d90                  ; 1490
	call L1d95                  ; 1493
	call L1a83                  ; 1496
	call L1dcf                  ; 1499
	ld a,(WRK+$068)             ; 149c
	dec a                       ; 149f
	ld (WRK+$068),a             ; 14a0
	jp p,L1490                  ; 14a3
	call L1d3f                  ; 14a6
	call L1d35                  ; 14a9
	call L1d3a                  ; 14ac
	call L1e99                  ; 14af
	call L1a74                  ; 14b2
	call L1d9f                  ; 14b5
	call L1de8                  ; 14b8
	call L217e                  ; 14bb
	call L1e94                  ; 14be
	call L21c6                  ; 14c1
	call L1d70                  ; 14c4
	call L1dde                  ; 14c7
	call L1a79                  ; 14ca
	call L1da9                  ; 14cd
	call L1a79                  ; 14d0
	call L1a65                  ; 14d3
	call L1e7e                  ; 14d6
	call L1d2b                  ; 14d9
	call L1dfd                  ; 14dc
	call L1dc0                  ; 14df
	jp nz,L1466                 ; 14e2
	ld hl,(L1565)               ; 14e5
	inc hl                      ; 14e8
	ld (L1565),hl               ; 14e9
	ld a,(hl)                   ; 14ec
	ld (WRK+$25c),a             ; 14ed
	or a                        ; 14f0
	jp p,L145b                  ; 14f1
	call L1df8                  ; 14f4
	ld sp,MZW+$0f0              ; 14f7
	call L20cd                  ; 14fa
	ld a,$01                    ; 14fd
	ld (L1a64),a                ; 14ff
	call L150e                  ; 1502
	call L20d7                  ; 1505
	call L150e                  ; 1508
	jp L234c                    ; 150b
L150e:
	call L20a0                  ; 150e
	call L1d26                  ; 1511
	call L1e0d                  ; 1514
	call L1be9                  ; 1517
	ld a,$06                    ; 151a
	ld (WRK+$068),a             ; 151c
L151f:
	call L1d3f                  ; 151f
	call L1d35                  ; 1522
	call L1d3a                  ; 1525
	call L20c8                  ; 1528
	ld a,(WRK+$068)             ; 152b
	dec a                       ; 152e
	ld (WRK+$068),a             ; 152f
	jp p,L151f                  ; 1532
	call L1e99                  ; 1535
	call L1de8                  ; 1538
	call L217e                  ; 153b
	call L1e94                  ; 153e
	call L21c6                  ; 1541
	call L1d70                  ; 1544
	call L1e9e                  ; 1547
	call L1a79                  ; 154a
	call L1a65                  ; 154d
	call L1d2b                  ; 1550
	call L1dfd                  ; 1553
	call VZ_FRAME
	ld bc,$08ae                 ; 1556
L1559:
	cpi                         ; 1559
	jp pe,L1559                 ; 155b
	call L1dc0                  ; 155e
	jp nz,L150e                 ; 1561
	ret                         ; 1564
L1565:
	db $00,$00                  ; 1565
L1567:
	db $03,$0e,$01,$02,$0b,$08,$0f,$ff; 1567
L156f:
	db $03,$0e,$01,$02,$0b,$08,$0f,$12,$ff; 156f
L1578:
	db $52,$30,$0d              ; 1578
L157b:
	call L1df8                  ; 157b
	call L20d2                  ; 157e
	ld a,$02                    ; 1581
	ld (L1a64),a                ; 1583
	call L2083                  ; 1586
	xor a                       ; 1589
	ld (WRK+$262),a             ; 158a
	ld (WRK+$263),a             ; 158d
	ld (WRK+$264),a             ; 1590
L1593:
	ld sp,MZW+$0f0              ; 1593
	ld de,$0001                 ; 1596
	call L1a6a                  ; 1599
	ld a,(WRK+$089)             ; 159c
	or a                        ; 159f
	call z,L20a0                ; 15a0
	ld a,(WRK+$089)             ; 15a3
	or a                        ; 15a6
	call z,L20a0                ; 15a7
	call L1e7e                  ; 15aa
	call L1a74                  ; 15ad
	call L1d26                  ; 15b0
	call L1e0d                  ; 15b3
	call L1be9                  ; 15b6
	ld a,$06                    ; 15b9
	ld (WRK+$068),a             ; 15bb
L15be:
	call L1ebc                  ; 15be
	call L20c8                  ; 15c1
	call L1ea3                  ; 15c4
	call L20be                  ; 15c7
	ld a,(WRK+$068)             ; 15ca
	dec a                       ; 15cd
	ld (WRK+$068),a             ; 15ce
	jp p,L15be                  ; 15d1
	call L1d3f                  ; 15d4
	call L1d35                  ; 15d7
	call L1d3a                  ; 15da
	call L1a74                  ; 15dd
	call L1de8                  ; 15e0
	call L217e                  ; 15e3
	call L1e94                  ; 15e6
	call L1e99                  ; 15e9
	call L21c6                  ; 15ec
	call L1d70                  ; 15ef
	call L1e9e                  ; 15f2
	call L1a74                  ; 15f5
	call L1a79                  ; 15f8
	call L1a65                  ; 15fb
	call L20c3                  ; 15fe
	call L1e7e                  ; 1601
	call L1d2b                  ; 1604
	call L1dfd                  ; 1607
	call L1dc0                  ; 160a
	jp z,L13c3                  ; 160d
	call L1a3c                  ; 1610
	jp z,L13c3                  ; 1613
	jp L1593                    ; 1616
L1619:
	ld a,$1f                    ; 1619
	jp La000                    ; 161b
L161e:
	call L1619                  ; 161e
	ld a,$09                    ; 1621
	call VZ_KBROW               ; 1623 patched
	inc a                       ; 1629
	jr z,L163b                  ; 162a
	ld hl,VRAM+$028             ; 162c
	ld de,VRAM+$029             ; 162f
	ld bc,$03c0                 ; 1632
	ld a,(WRK+$3ff)             ; 1635
	ld (hl),a                   ; 1638
	ldir                        ; 1639
L163b:
	ld a,$01                    ; 163b
	ld (WRK+$064),a             ; 163d
	ld (WRK+$062),a             ; 1640
	ld hl,$2010                 ; 1643
	ld (WRK+$05c),hl            ; 1646
	ld a,$07                    ; 1649 patched
	ld (WRK+$06a),a             ; 164b
	ld hl,$0000                 ; 164e
	ld (WRK+$06b),hl            ; 1651
	ld (WRK+$06d),hl            ; 1654
	ret                         ; 1657
L1658:
	ld hl,WRK+$051              ; 1658
	ld (hl),$00                 ; 165b
	ld a,(WRK+$062)             ; 165d
	cp $04                      ; 1660
	jp z,L166f                  ; 1662
	cp $09                      ; 1665
	jp z,L166f                  ; 1667
	cp $0e                      ; 166a
	jp nz,L1676                 ; 166c
L166f:
	ld (hl),$01                 ; 166f
	ld a,$01                    ; 1671
	ld (WRK+$050),a             ; 1673
L1676:
	xor a                       ; 1676
	ld (WRK+$04d),a             ; 1677
	ld hl,WRK+$229              ; 167a
	ld de,WRK+$22a              ; 167d
	ld bc,$0028                 ; 1680
	ld (hl),b                   ; 1683
	ldir                        ; 1684
	ld hl,WRK+$079              ; 1686
	ld de,WRK+$07a              ; 1689
	ld (hl),$00                 ; 168c
	ld bc,$0180                 ; 168e
	ldir                        ; 1691
	ld hl,$000d                 ; 1693
	ld (L21fb),hl               ; 1696
	ld a,(WRK+$062)             ; 1699
	dec a                       ; 169c
	ld c,a                      ; 169d
	ld hl,L16be                 ; 169e
	add hl,bc                   ; 16a1
	ld a,(hl)                   ; 16a2
	ld (WRK+$057),a             ; 16a3
	ld hl,L16d0                 ; 16a6
	add hl,bc                   ; 16a9
	ld a,(hl)                   ; 16aa
	ld (L1a64),a                ; 16ab
	ld a,$14                    ; 16ae
	ld (WRK+$04e),a             ; 16b0
	ld a,$37                    ; 16b3
	ld (WRK+$042),a             ; 16b5
	ld a,$3c                    ; 16b8
	ld (WRK+$25f),a             ; 16ba
	ret                         ; 16bd
L16be:
	db $04,$04,$03,$02,$03,$03,$03,$03,$02,$03,$03,$02,$03,$01,$03,$03; 16be
	db $03,$01                  ; 16ce
L16d0:
	db $00,$00,$01,$01,$00,$01,$01,$01,$02,$02,$02,$00,$02,$02,$02,$02; 16d0
	db $02,$02                  ; 16e0
L16e2:
	ld a,$0b                    ; 16e2
	jp La000                    ; 16e4
L16e7:
	ld a,$20                    ; 16e7
	jp La000                    ; 16e9
L16ec:
	call L1df8                  ; 16ec
	ld hl,L24a6                 ; 16ef
	ld de,WRK+$06b              ; 16f2
	ld bc,$000c                 ; 16f5
	ldir                        ; 16f8
	ld hl,VRAM+$800             ; 16fa
	ld de,VRAM+$801             ; 16fd
	ld bc,$03e8                 ; 1700
	ld (hl),$70                 ; 1703
	ldir                        ; 1705
	ld (MZW+$171),bc            ; 1707
	ld de,L17ec                 ; 170b
	call VZ_MSG                 ; 170e patched
	call L1900                  ; 170f
	ld hl,VRAM+$3c0             ; 1712
	ld de,VRAM+$3c1             ; 1715
	ld bc,$0028                 ; 1718
	ld (hl),b                   ; 171b
	ldir                        ; 171c
	ld hl,$1800                 ; 171e
	ld (MZW+$171),hl            ; 1721
	ld de,L1814                 ; 1724
	call VZ_MSG                 ; 1727 patched
	ld hl,$1818                 ; 1728
	ld (MZW+$171),hl            ; 172b
	ld de,L181d                 ; 172e
	call VZ_MSG                 ; 1731 patched
	ld hl,VRAM+$bc0             ; 1732
	ld de,VRAM+$bc1             ; 1735
	ld bc,$0028                 ; 1738
	ld (hl),$70                 ; 173b
	ldir                        ; 173d
	ld hl,$1410                 ; 173f
	ld (MZW+$171),hl            ; 1742
	ld de,L182b                 ; 1745
	call VZ_MSG                 ; 1748 patched
	ld hl,$2727                 ; 174b
	ld (VRAM+$800),hl           ; 174e
	ld (VRAM+$801),hl           ; 1751
	ld hl,$5757                 ; 1754
	ld (VRAM+$80f),hl           ; 1757
	ld (VRAM+$811),hl           ; 175a
	ld (VRAM+$812),hl           ; 175d
	ld hl,VRAM+$b30             ; 1760
	ld ix,L187c                 ; 1763
	ld c,$04                    ; 1767
	ld de,$001d                 ; 1769
L176c:
	ld b,$0b                    ; 176c
L176e:
	ld a,(ix+0)                 ; 176e
	ld (hl),a                   ; 1771
	inc hl                      ; 1772
	inc ix                      ; 1773
	djnz L176e                  ; 1775
	add hl,de                   ; 1777
	dec c                       ; 1778
	jr nz,L176c                 ; 1779
	call L1a6f                  ; 177b
L177e:
	ld hl,L1958                 ; 177e
	ld de,WRK+$003              ; 1781
	ld bc,$0018                 ; 1784
	ldir                        ; 1787
	ld hl,L1958                 ; 1789
	ld de,WRK+$021              ; 178c
	ld bc,$0018                 ; 178f
	ldir                        ; 1792
	xor a                       ; 1794
	ld (WRK+$066),a             ; 1795
	call L19dd                  ; 1798
	call L1d35                  ; 179b
	call VZ_GETKY               ; 179e patched
L17a1:
	or a                        ; 17a1
	ret nz                      ; 17a2
	call L1d3a                  ; 17a3
	xor a                       ; 17a6
	ld (WRK+$066),a             ; 17a7
	call L1de8                  ; 17aa
	call VZ_GETKY               ; 17ad patched
L17b0:
	or a                        ; 17b0
	ret nz                      ; 17b1
	call L1d76                  ; 17b2
	call L17c2                  ; 17b5
	call L1a28                  ; 17b8
	call VZ_GETKY               ; 17bb patched
L17be:
	or a                        ; 17be
	ret nz                      ; 17bf
	jr L177e                    ; 17c0
L17c2:
	ld a,$fb                    ; 17c2
	rlca                        ; 17c4
	ld (L17c2+1),a              ; 17c5
L17c8:
	ld a,$02                    ; 17c8
	inc a                       ; 17ca
	and $07                     ; 17cb
	ld (L17c8+1),a              ; 17cd
	ld e,a                      ; 17d0
	ld d,$00                    ; 17d1
	ld hl,L17e2                 ; 17d3
	add hl,de                   ; 17d6
	ld a,(hl)                   ; 17d7
	ld (BUF+$42a),a             ; 17d8
	ld (BUF+$469),a             ; 17db
	ld (BUF+$46b),a             ; 17de
	ret                         ; 17e1
L17e2:
	db $00,$02,$02,$22,$22,$22,$02,$02,$00,$00; 17e2
L17ec:
	db $54,$4f,$50,$20,$30,$30,$30,$30,$30,$30,$30,$30,$30,$20,$20,$53; 17ec
	db $43,$4f,$52,$45,$20,$30,$30,$30,$30,$30,$30,$30,$30,$30,$20,$53; 17fc
	db $54,$41,$47,$45,$20,$20,$31,$0d; 180c
L1814:
	db $50,$4c,$41,$59,$45,$52,$20,$37,$0d; 1814
L181d:
	db $28,$43,$29,$20,$53,$45,$47,$41,$20,$31,$39,$38,$35,$0d; 181d
L182b:
	db $f5,$c8,$c9,$f5,$c8,$20,$c8,$e9,$fe,$c8,$e9,$11,$14,$14,$14,$14; 182b
	db $14,$14,$14,$14,$14,$14,$14,$ef,$d7,$c7,$ef,$d7,$c7,$ef,$d7,$c7; 183b
	db $ef,$f0,$11,$14,$14,$14,$14,$14,$14,$14,$14,$14,$14,$14,$c3,$f0; 184b
	db $c7,$ef,$d7,$c7,$c5,$f0,$c7,$ef,$f0,$11,$14,$14,$14,$14,$14,$14; 185b
	db $14,$14,$14,$14,$14,$d7,$d7,$20,$d7,$d7,$20,$d7,$d7,$20,$20,$d7; 186b
	db $0d                      ; 187b
L187c:
	db $50,$50,$50,$50,$50,$00,$50,$50,$50,$50,$50,$10,$10,$00,$10,$10; 187c
	db $00,$10,$10,$00,$10,$10,$50,$50,$00,$50,$50,$00,$50,$50,$50,$50; 188c
	db $50,$50,$50,$00,$50,$50,$00,$50,$50,$00,$00,$50; 189c
L18a8:
	ld a,$c9                    ; 18a8
	ld (L217e),a                ; 18aa
	ld (L1d3f),a                ; 18ad
	ld a,$5a                    ; 18b0
	ld (WRK+$3ff),a             ; 18b2
	xor a                       ; 18b5
	ld (L1d70),a                ; 18b6
	ld (L217d),a                ; 18b9
	ld a,$09                    ; 18bc
	call VZ_KBROW               ; 18be patched
	ld b,a                      ; 18c4
	bit 3,b                     ; 18c5
	jr nz,L18cd                 ; 18c7
	xor a                       ; 18c9
	ld (L217e),a                ; 18ca
L18cd:
	bit 4,b                     ; 18cd
	jr nz,L18d5                 ; 18cf
	xor a                       ; 18d1
	ld (WRK+$3ff),a             ; 18d2
L18d5:
	bit 5,b                     ; 18d5
	jr nz,L18e8                 ; 18d7
	xor a                       ; 18d9
	ld (L1d3f),a                ; 18da
	ld (L217e),a                ; 18dd
	ld a,$c9                    ; 18e0
	ld (L1d70),a                ; 18e2
	ld (L217d),a                ; 18e5
L18e8:
	bit 6,b                     ; 18e8
	jr nz,L18f7                 ; 18ea
	ld a,$c9                    ; 18ec
	ld (L1d70),a                ; 18ee
	ld (L217e),a                ; 18f1
	ld (L217d),a                ; 18f4
L18f7:
	bit 7,b                     ; 18f7
	ret nz                      ; 18f9
	ld a,$43                    ; 18fa
	ld (WRK+$3ff),a             ; 18fc
	ret                         ; 18ff
L1900:
	ld hl,L1958                 ; 1900
	ld de,WRK+$003              ; 1903
	ld bc,$0018                 ; 1906
	ldir                        ; 1909
	ld hl,L1958                 ; 190b
	ld de,WRK+$021              ; 190e
	ld bc,$0018                 ; 1911
	ldir                        ; 1914
	ld hl,WRK+$079              ; 1916
	ld de,WRK+$07a              ; 1919
	ld bc,$0180                 ; 191c
	ld (hl),$00                 ; 191f
	ldir                        ; 1921
	ld a,$0b                    ; 1923
	ld hl,L196f                 ; 1925
	ld de,WRK+$079              ; 1928
L192b:
	ld bc,$000a                 ; 192b
	ldir                        ; 192e
	ld c,$0e                    ; 1930
	ex de,hl                    ; 1932
	add hl,bc                   ; 1933
	ex de,hl                    ; 1934
	dec a                       ; 1935
	jr nz,L192b                 ; 1936
	xor a                       ; 1938
	ld (WRK+$066),a             ; 1939
	ld a,$5a                    ; 193c
	ld (WRK+$3ff),a             ; 193e
	call L1619                  ; 1941
	call L1de8                  ; 1944
	xor a                       ; 1947
	ld (WRK+$066),a             ; 1948
	call L1d35                  ; 194b
	call L1d3a                  ; 194e
	call L1d76                  ; 1951
	call L1d2b                  ; 1954
	ret                         ; 1957
L1958:
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$43,$16,$77,$16,$43,$00; 1958
	db $43,$16,$77,$16,$43,$00,$00; 1968
L196f:
	db $30,$00,$00,$16,$07,$17,$03,$ff,$00,$01,$31,$00,$00,$16,$07,$21; 196f
	db $03,$ff,$00,$01,$17,$00,$00,$01,$0a,$0c,$00,$ff,$00,$00,$13,$00; 197f
	db $00,$01,$0f,$26,$00,$ff,$00,$00,$1f,$00,$00,$01,$0e,$13,$00,$ff; 198f
	db $00,$00,$17,$00,$00,$06,$0a,$0e,$00,$ff,$00,$00,$17,$00,$00,$0a; 199f
	db $0a,$10,$00,$ff,$00,$00,$17,$00,$00,$0e,$0a,$12,$00,$ff,$00,$00; 19af
	db $17,$00,$00,$12,$0a,$14,$00,$ff,$00,$00,$17,$00,$00,$16,$0a,$16; 19bf
	db $00,$ff,$00,$00,$17,$00,$00,$1a,$0a,$18,$00,$ff,$00,$00; 19cf
L19dd:
	ld ix,WRK+$079              ; 19dd
	call L19e8                  ; 19e1
	ld ix,WRK+$091              ; 19e4
L19e8:
	dec (ix+16)                 ; 19e8
	ld a,(ix+16)                ; 19eb
	and $01                     ; 19ee
	ret z                       ; 19f0
	ld a,(ix+3)                 ; 19f1
	dec a                       ; 19f4
	jp z,L1a07                  ; 19f5
	ld (ix+3),a                 ; 19f8
	dec (ix+6)                  ; 19fb
	ld a,(ix+6)                 ; 19fe
	and $03                     ; 1a01
	ld (ix+6),a                 ; 1a03
	ret                         ; 1a06
L1a07:
	ld a,(ix+17)                ; 1a07
	or a                        ; 1a0a
	jr nz,L1a1f                 ; 1a0b
	dec (ix+6)                  ; 1a0d
	ld a,(ix+6)                 ; 1a10
	and $03                     ; 1a13
	ld (ix+6),a                 ; 1a15
	cp $03                      ; 1a18
	ret c                       ; 1a1a
	inc (ix+17)                 ; 1a1b
	ret                         ; 1a1e
L1a1f:
	ld a,(ix+6)                 ; 1a1f
	dec a                       ; 1a22
	ret m                       ; 1a23
	ld (ix+6),a                 ; 1a24
	ret                         ; 1a27
L1a28:
	ld hl,BUF+$1cc              ; 1a28
	ld de,VRAM+$828             ; 1a2b
	ld a,$0d                    ; 1a2e
L1a30:
	ld bc,$0028                 ; 1a30
	ldir                        ; 1a33
	ld c,$18                    ; 1a35
	add hl,bc                   ; 1a37
	dec a                       ; 1a38
	jr nz,L1a30                 ; 1a39
	jp VZ_FRAME                 ; 1a3b patched
L1a3c:
	ld a,$08                    ; 1a3c
	call VZ_KBROW               ; 1a3e patched
	bit 7,a                     ; 1a44
	ret                         ; 1a46
L1a47:
	ld hl,L1a63                 ; 1a47
	dec (hl)                    ; 1a4a
	ret p                       ; 1a4b
	ld (hl),$16                 ; 1a4c
	ld a,(L1a64)                ; 1a4e
	ld c,a                      ; 1a51
	ld a,(L1e10+1)              ; 1a52
	cp c                        ; 1a55
	ret z                       ; 1a56
	jr c,L1a5e                  ; 1a57
	dec a                       ; 1a59
	ld (L1e10+1),a              ; 1a5a
	ret                         ; 1a5d
L1a5e:
	inc a                       ; 1a5e
	ld (L1e10+1),a              ; 1a5f
	ret                         ; 1a62
L1a63:
	db $0c                      ; 1a63
L1a64:
	db $00                      ; 1a64
L1a65:
	ld a,$06                    ; 1a65
	jp L8000                    ; 1a67
L1a6a:
	ld a,$15                    ; 1a6a
	jp La000                    ; 1a6c
L1a6f:
	ld a,$21                    ; 1a6f
	jp La000                    ; 1a71
L1a74:
	ld a,$01                    ; 1a74
	jp La000                    ; 1a76
L1a79:
	ld a,(WRK+$266)             ; 1a79
	or a                        ; 1a7c
	ret nz                      ; 1a7d
	ld a,$03                    ; 1a7e
	jp L8000                    ; 1a80
L1a83:
	ld a,(WRK+$04d)             ; 1a83
	or a                        ; 1a86
	ret z                       ; 1a87
	call VZ_AHHRESET
	ld hl,WRK+$06b              ; 1a88
	ld de,L24a6                 ; 1a8b
	ld bc,$000c                 ; 1a8e
	ldir                        ; 1a91
L1a93:
	call L1d8b                  ; 1a93
	call L1de8                  ; 1a96
	call L217e                  ; 1a99
	call L1e88                  ; 1a9c
	call L21c6                  ; 1a9f
	call L1d70                  ; 1aa2
	ld a,(WRK+$25e)             ; 1aa5
	or a                        ; 1aa8
	jr nz,L1ab0                 ; 1aa9
	call L1d76                  ; 1aab
	jr L1ab3                    ; 1aae
L1ab0:
	call L1dde                  ; 1ab0
L1ab3:
	call L1da9                  ; 1ab3
	ld hl,(WRK+$05c)            ; 1ab6
	ld de,L1b6e                 ; 1ab9
	ld bc,$0503                 ; 1abc
	call L1d30                  ; 1abf
	call L1d3f                  ; 1ac2
	call L1d35                  ; 1ac5
	call L1d3a                  ; 1ac8
	call L1d26                  ; 1acb
	call L1a65                  ; 1ace
	call L1d2b                  ; 1ad1
	call L1dfd                  ; 1ad4
	call VZ_AHH
	ld a,(WRK+$05c)             ; 1ad7
	inc a                       ; 1ada
	ld (WRK+$05c),a             ; 1adb
	cp $1c                      ; 1ade
	jp c,L1a93                  ; 1ae0
	call VZ_FRAME
	ld bc,$7530                 ; 1ae3
L1ae6:
	cpi                         ; 1ae6
	jp pe,L1ae6                 ; 1ae8
	ld hl,WRK+$06a              ; 1aeb
	dec (hl)                    ; 1aee
	jp m,L1b7d                  ; 1aef
L1af2:
	call VZ_BELL                ; 1af2 patched
	call VZ_BELL                ; 1af5 patched
	xor a                       ; 1af8
	ld (WRK+$04d),a             ; 1af9
	ld a,$19                    ; 1afc
	ld (WRK+$05c),a             ; 1afe
	ld a,$3c                    ; 1b01
	ld (WRK+$052),a             ; 1b03
	ld a,$17                    ; 1b06
	ld (WRK+$056),a             ; 1b08
	ld a,$1e                    ; 1b0b
	ld (WRK+$054),a             ; 1b0d
L1b10:
	call L1d26                  ; 1b10
	call L1d8b                  ; 1b13
	call L1de8                  ; 1b16
	call L1d3f                  ; 1b19
	call L1e88                  ; 1b1c
	call L21c6                  ; 1b1f
	call L1d70                  ; 1b22
	call L1d9f                  ; 1b25
	call L1da4                  ; 1b28
	call L1d90                  ; 1b2b
	ld a,(WRK+$25e)             ; 1b2e
	or a                        ; 1b31
	jr nz,L1b39                 ; 1b32
	call L1d76                  ; 1b34
	jr L1b3c                    ; 1b37
L1b39:
	call L1dde                  ; 1b39
L1b3c:
	call L1da4                  ; 1b3c
	call L1d90                  ; 1b3f
	call L1da4                  ; 1b42
	call L1d90                  ; 1b45
	call L1a74                  ; 1b48
	call L1d3f                  ; 1b4b
	call L1d35                  ; 1b4e
	call L1d3a                  ; 1b51
	call L1da9                  ; 1b54
	call L1a79                  ; 1b57
	call L1a65                  ; 1b5a
	call L1d2b                  ; 1b5d
	call L1dfd                  ; 1b60
	call L1a74                  ; 1b63
	ld hl,WRK+$054              ; 1b66
	dec (hl)                    ; 1b69
	jp p,L1b10                  ; 1b6a
	ret                         ; 1b6d
L1b7d:
	ld hl,$0c0f                 ; 1b7d
	ld (MZW+$171),hl            ; 1b80
	ld de,L1bcd                 ; 1b83
	call VZ_MSG                 ; 1b86 patched
	ld hl,VRAM+$9ef             ; 1b87
	ld de,VRAM+$9f0             ; 1b8a
	ld bc,$0008                 ; 1b8d
	ld (hl),$70                 ; 1b90
	ldir                        ; 1b92
	ld a,$07                    ; 1b94
	call VZ_FRAME
	ld bc,$0000                 ; 1b96
L1b99:
	cpi                         ; 1b99
	jp pe,L1b99                 ; 1b9b
	dec a                       ; 1b9e
	jp nz,L1b99                 ; 1b9f
	call L1619                  ; 1ba2
	ld a,$09                    ; 1ba5
	call VZ_KBROW               ; 1ba7 patched
	inc a                       ; 1bad
	jp z,L1250                  ; 1bae
	ld a,$08                    ; 1bb1
	call VZ_KBROW               ; 1bb3 patched
	inc a                       ; 1bb9
	jp z,L1250                  ; 1bba
	ld a,(WRK+$062)             ; 1bbd
	cp $0f                      ; 1bc0
	jp nc,L1250                 ; 1bc2
	ld a,$09                    ; 1bc5
	ld (WRK+$06a),a             ; 1bc7
	jp L1af2                    ; 1bca
L1bcd:
	db $47,$41,$4d,$45,$20,$4f,$56,$45,$52,$0d; 1bcd
L1bd7:
	ld a,$09                    ; 1bd7
	call VZ_KBROW               ; 1bd9 patched
	bit 7,a                     ; 1bdf
	ret nz                      ; 1be1
	ld a,$80                    ; 1be2
	jp L9600                    ; 1be4
L1be7:
	ret                         ; 1be7
L1be8:
	db $00                      ; 1be8
L1be9:
	ld a,(L217e)                ; 1be9
	or a                        ; 1bec
	ret z                       ; 1bed
	ld a,(WRK+$062)             ; 1bee
	dec a                       ; 1bf1
	add a,a                     ; 1bf2
	ld e,a                      ; 1bf3
	ld d,$00                    ; 1bf4
	ld hl,L1bff                 ; 1bf6
	add hl,de                   ; 1bf9
	ld e,(hl)                   ; 1bfa
	inc hl                      ; 1bfb
	ld d,(hl)                   ; 1bfc
	ex de,hl                    ; 1bfd
	jp (hl)                     ; 1bfe
L1bff:
	dw L1be7                    ; 1bff
	dw L1be7                    ; 1c01
	dw L1be7                    ; 1c03
	dw L1c4a                    ; 1c05
	dw L1ce8                    ; 1c07
	dw L1be7                    ; 1c09
	dw L1be7                    ; 1c0b
	dw L1be7                    ; 1c0d
	dw L1c4a                    ; 1c0f
	dw L1be7                    ; 1c11
	dw L1be7                    ; 1c13
	dw L1c23                    ; 1c15
	dw L1be7                    ; 1c17
	dw L1c7a                    ; 1c19
	dw L1be7                    ; 1c1b
	dw L1be7                    ; 1c1d
	dw L1be7                    ; 1c1f
	dw L1c4a                    ; 1c21
L1c23:
	ld hl,L1be8                 ; 1c23
	dec (hl)                    ; 1c26
	ret p                       ; 1c27
	ld (hl),$14                 ; 1c28
L1c2a:
	ld a,$00                    ; 1c2a
	inc a                       ; 1c2c
	and $03                     ; 1c2d
	ld (L1c2a+1),a              ; 1c2f
	add a,a                     ; 1c32
	ld e,a                      ; 1c33
	ld d,$00                    ; 1c34
	ld hl,L1c42                 ; 1c36
	add hl,de                   ; 1c39
	ld e,(hl)                   ; 1c3a
	inc hl                      ; 1c3b
	ld d,(hl)                   ; 1c3c
	ld (WRK+$000),de            ; 1c3d
	ret                         ; 1c41
L1c42:
	db $25,$77,$43,$75,$25,$71,$43,$75; 1c42
L1c4a:
	ld hl,L1be8                 ; 1c4a
	dec (hl)                    ; 1c4d
	ret p                       ; 1c4e
	ld (hl),$14                 ; 1c4f
L1c51:
	ld a,$02                    ; 1c51
	inc a                       ; 1c53
	and $07                     ; 1c54
	ld (L1c51+1),a              ; 1c56
	add a,a                     ; 1c59
	ld e,a                      ; 1c5a
	ld d,$00                    ; 1c5b
	ld hl,L1c69                 ; 1c5d
	add hl,de                   ; 1c60
	ld e,(hl)                   ; 1c61
	inc hl                      ; 1c62
	ld d,(hl)                   ; 1c63
	ld (WRK+$000),de            ; 1c64
	ret                         ; 1c68
L1c69:
	db $73,$75,$72,$25,$73,$43,$72,$25,$73,$75,$72,$74,$73,$77,$72,$74; 1c69
L1c79:
	db $00                      ; 1c79
L1c7a:
	ld hl,L1be8                 ; 1c7a
	dec (hl)                    ; 1c7d
	ret p                       ; 1c7e
	ld (hl),$14                 ; 1c7f
	ld a,(L1c79)                ; 1c81
	inc a                       ; 1c84
	ld (L1c79),a                ; 1c85
	cp $1c                      ; 1c88
	jp c,L1c95                  ; 1c8a
	ld a,$1c                    ; 1c8d
	ld (L1c79),a                ; 1c8f
	jp L1c2a                    ; 1c92
L1c95:
	cp $08                      ; 1c95
	jp c,L1ca6                  ; 1c97
	cp $14                      ; 1c9a
	jp nc,L1cb6                 ; 1c9c
	ld hl,$0100                 ; 1c9f
	ld (WRK+$000),hl            ; 1ca2
	ret                         ; 1ca5
L1ca6:
	add a,a                     ; 1ca6
	ld e,a                      ; 1ca7
	ld d,$00                    ; 1ca8
	ld hl,L1cc8                 ; 1caa
	add hl,de                   ; 1cad
	ld e,(hl)                   ; 1cae
	inc hl                      ; 1caf
	ld d,(hl)                   ; 1cb0
	ld (WRK+$000),de            ; 1cb1
	ret                         ; 1cb5
L1cb6:
	sub $14                     ; 1cb6
	add a,a                     ; 1cb8
	ld e,a                      ; 1cb9
	ld d,$00                    ; 1cba
	ld hl,L1cd8                 ; 1cbc
	add hl,de                   ; 1cbf
	ld e,(hl)                   ; 1cc0
	inc hl                      ; 1cc1
	ld d,(hl)                   ; 1cc2
	ld (WRK+$000),de            ; 1cc3
	ret                         ; 1cc7
L1cc8:
	db $17,$77,$25,$75,$16,$71,$43,$51,$11,$50,$01,$14,$00,$01,$00,$11; 1cc8
L1cd8:
	db $00,$01,$00,$11,$01,$14,$11,$50,$43,$51,$16,$71,$25,$75,$17,$77; 1cd8
L1ce8:
	ld hl,L1be8                 ; 1ce8
	dec (hl)                    ; 1ceb
	ret p                       ; 1cec
	ld (hl),$14                 ; 1ced
	ld a,(L1c79)                ; 1cef
	inc a                       ; 1cf2
	ld (L1c79),a                ; 1cf3
	add a,a                     ; 1cf6
	ld e,a                      ; 1cf7
	ld d,$00                    ; 1cf8
	ld hl,L1d0f                 ; 1cfa
	add hl,de                   ; 1cfd
	ld e,(hl)                   ; 1cfe
	inc hl                      ; 1cff
	ld d,(hl)                   ; 1d00
	ld (WRK+$000),de            ; 1d01
	cp $0a                      ; 1d05
	ret c                       ; 1d07
	ld hl,$0444                 ; 1d08
	ld (WRK+$000),hl            ; 1d0b
	ret                         ; 1d0e
L1d0f:
	db $06,$66,$06,$66,$06,$66,$06,$64,$24,$44,$04,$44,$04,$44,$04,$44; 1d0f
	db $04,$44                  ; 1d1f
L1d21:
	ld a,$05                    ; 1d21
	jp L8000                    ; 1d23
L1d26:
	ld a,$16                    ; 1d26
	jp La000                    ; 1d28
L1d2b:
	ld a,$09                    ; 1d2b
	jp La000                    ; 1d2d
L1d30:
	ld a,$0f                    ; 1d30
	jp La000                    ; 1d32
L1d35:
	ld a,$05                    ; 1d35
	jp La000                    ; 1d37
L1d3a:
	ld a,$06                    ; 1d3a
	call La000                  ; 1d3c
L1d3f:
	ret                         ; 1d3f
	ld a,$06                    ; 1d40
	ld (WRK+$066),a             ; 1d42
	ret                         ; 1d45
	ld a,$17                    ; 1d46
	jp La000                    ; 1d48
L1d4b:
	db $00,$01,$09,$05,$07,$04,$08,$02,$06,$03,$0a,$0a; 1d4b
L1d57:
	db $00,$04,$11,$09,$0c,$05,$10,$07,$0e,$01,$14,$08,$0d,$02,$13,$06; 1d57
	db $0f,$03,$12,$0a,$0b,$0a,$0b,$0a,$0b; 1d67
L1d70:
	nop                         ; 1d70
	ld a,$01                    ; 1d71
	jp L8000                    ; 1d73
L1d76:
	ld a,$07                    ; 1d76
	jp L8000                    ; 1d78
	db $aa                      ; 1d7b
L1d7c:
	ld a,$01                    ; 1d7c
	jp L2500                    ; 1d7e
	ld a,$22                    ; 1d81
	jp La000                    ; 1d83
L1d86:
	ld a,$18                    ; 1d86
	jp La000                    ; 1d88
L1d8b:
	ld a,$0e                    ; 1d8b
	jp La000                    ; 1d8d
L1d90:
	ld a,$1c                    ; 1d90
	jp La000                    ; 1d92
L1d95:
	ld a,$1d                    ; 1d95
	jp La000                    ; 1d97
	ld a,$19                    ; 1d9a
	jp La000                    ; 1d9c
L1d9f:
	ld a,$03                    ; 1d9f
	jp La000                    ; 1da1
L1da4:
	ld a,$02                    ; 1da4
	jp La000                    ; 1da6
L1da9:
	ld a,$02                    ; 1da9
	jp L8000                    ; 1dab
L1dae:
	jp L9c00                    ; 1dae
	ld a,$04                    ; 1db1
	jp L2500                    ; 1db3
	ld a,$1a                    ; 1db6
	jp La000                    ; 1db8
	ld a,$23                    ; 1dbb
	jp La000                    ; 1dbd
L1dc0:
	ld hl,WRK+$079              ; 1dc0
	ld de,$0018                 ; 1dc3
	ld b,$10                    ; 1dc6
	xor a                       ; 1dc8
L1dc9:
	add a,(hl)                  ; 1dc9
	add hl,de                   ; 1dca
	djnz L1dc9                  ; 1dcb
	or a                        ; 1dcd
	ret                         ; 1dce
L1dcf:
	ld a,$02                    ; 1dcf
	jp L2500                    ; 1dd1
L1dd4:
	ld a,$05                    ; 1dd4
	jp L2500                    ; 1dd6
L1dd9:
	ld a,$06                    ; 1dd9
	jp L2500                    ; 1ddb
L1dde:
	ld a,$0a                    ; 1dde
	jp L8000                    ; 1de0
	ld a,$1b                    ; 1de3
	jp La000                    ; 1de5
L1de8:
	ld a,$04                    ; 1de8
	jp L8000                    ; 1dea
L1ded:
	ld a,$09                    ; 1ded
	call VZ_KBROW               ; 1def patched
	bit 6,a                     ; 1df5
	ret nz                      ; 1df7
L1df8:
	ld a,$82                    ; 1df8
	jp L9600                    ; 1dfa
L1dfd:
	call L1bd7                  ; 1dfd
	call L1ded                  ; 1e00
	ld a,$0a                    ; 1e03
	jp La000                    ; 1e05
L1e08:
	ld a,$0c                    ; 1e08
	jp La000                    ; 1e0a
L1e0d:
	call L1a47                  ; 1e0d
L1e10:
	ld a,$00                    ; 1e10
	ld (L1e1a+1),a              ; 1e12
L1e15:
	ld a,$0d                    ; 1e15
	call La000                  ; 1e17
L1e1a:
	ld a,$ff                    ; 1e1a
	dec a                       ; 1e1c
	ld (L1e1a+1),a              ; 1e1d
	jp p,L1e15                  ; 1e20
	ret                         ; 1e23
	ld a,l                      ; 1e24
	cp $1f                      ; 1e25
	ret nc                      ; 1e27
	ld a,h                      ; 1e28
	cp $34                      ; 1e29
	ret nc                      ; 1e2b
	push de                     ; 1e2c
	ld e,h                      ; 1e2d
	ld d,$00                    ; 1e2e
	ld h,d                      ; 1e30
	add hl,hl                   ; 1e31
	add hl,hl                   ; 1e32
	add hl,hl                   ; 1e33
	add hl,hl                   ; 1e34
	add hl,hl                   ; 1e35
	add hl,hl                   ; 1e36
	add hl,de                   ; 1e37
	ld de,BUF+$000              ; 1e38
	add hl,de                   ; 1e3b
	pop de                      ; 1e3c
L1e3d:
	push bc                     ; 1e3d
	push de                     ; 1e3e
	ld a,c                      ; 1e3f
	exx                         ; 1e40
	ld hl,L1d57                 ; 1e41
	ld bc,(WRK+$058)            ; 1e44
	cpir                        ; 1e48
	exx                         ; 1e4a
	jp z,L1e6c                  ; 1e4b
	push hl                     ; 1e4e
L1e4f:
	ld a,b                      ; 1e4f
	exx                         ; 1e50
	ld hl,L1d4b                 ; 1e51
	ld bc,(WRK+$05a)            ; 1e54
	cpir                        ; 1e58
	exx                         ; 1e5a
	jp z,L1e65                  ; 1e5b
	ld a,(de)                   ; 1e5e
	or a                        ; 1e5f
	jp m,L1e64                  ; 1e60
	ld (hl),a                   ; 1e63
L1e64:
	inc hl                      ; 1e64
L1e65:
	inc de                      ; 1e65
	djnz L1e4f                  ; 1e66
	pop hl                      ; 1e68
	ld c,$40                    ; 1e69
	add hl,bc                   ; 1e6b
L1e6c:
	pop de                      ; 1e6c
	ld bc,$000b                 ; 1e6d
	ex de,hl                    ; 1e70
	add hl,bc                   ; 1e71
	ex de,hl                    ; 1e72
	pop bc                      ; 1e73
	dec c                       ; 1e74
	jp nz,L1e3d                 ; 1e75
	ret                         ; 1e78
	ld a,$24                    ; 1e79
	jp La000                    ; 1e7b
L1e7e:
	ld a,$26                    ; 1e7e
	jp La000                    ; 1e80
L1e83:
	ld a,$27                    ; 1e83
	jp La000                    ; 1e85
L1e88:
	ld a,(WRK+$062)             ; 1e88
	cp $04                      ; 1e8b
	ret z                       ; 1e8d
	cp $09                      ; 1e8e
	ret z                       ; 1e90
	cp $0e                      ; 1e91
	ret z                       ; 1e93
L1e94:
	ld a,$09                    ; 1e94
	jp L8000                    ; 1e96
L1e99:
	ld a,$2a                    ; 1e99
	jp La000                    ; 1e9b
L1e9e:
	ld a,$0e                    ; 1e9e
	jp L8000                    ; 1ea0
L1ea3:
	ld a,$0f                    ; 1ea3
	jp L8000                    ; 1ea5
L1ea8:
	ld iy,WRK+$0f1              ; 1ea8
	ld b,$0b                    ; 1eac
	ld de,$0018                 ; 1eae
L1eb1:
	ld a,(iy+0)                 ; 1eb1
	or a                        ; 1eb4
	ret z                       ; 1eb5
	add iy,de                   ; 1eb6
	djnz L1eb1                  ; 1eb8
	scf                         ; 1eba
	ret                         ; 1ebb
L1ebc:
	ld a,(WRK+$265)             ; 1ebc
	or a                        ; 1ebf
	ret nz                      ; 1ec0
	ld a,(WRK+$089)             ; 1ec1
	or a                        ; 1ec4
	ret z                       ; 1ec5
	ld hl,L209a                 ; 1ec6
	dec (hl)                    ; 1ec9
	ret p                       ; 1eca
	ld (hl),$12                 ; 1ecb
	ld hl,(WRK+$040)            ; 1ecd
	inc hl                      ; 1ed0
	ld (WRK+$040),hl            ; 1ed1
	ld ix,(WRK+$040)            ; 1ed4
	ld a,(ix+0)                 ; 1ed8
	or a                        ; 1edb
	jp p,L1ee5                  ; 1edc
	ld a,$01                    ; 1edf
	ld (WRK+$265),a             ; 1ee1
	ret                         ; 1ee4
L1ee5:
	call L1ea8                  ; 1ee5
	ret c                       ; 1ee8
	ld a,(ix+0)                 ; 1ee9
	dec a                       ; 1eec
	add a,a                     ; 1eed
	ld e,a                      ; 1eee
	ld d,$00                    ; 1eef
	ld hl,L1f0e                 ; 1ef1
	add hl,de                   ; 1ef4
	ld e,(hl)                   ; 1ef5
	inc hl                      ; 1ef6
	ld d,(hl)                   ; 1ef7
	ex de,hl                    ; 1ef8
	push iy                     ; 1ef9
	pop de                      ; 1efb
	ld bc,$000f                 ; 1efc
	ldir                        ; 1eff
	ld a,r                      ; 1f01
	and $0f                     ; 1f03
	sub $07                     ; 1f05
	add a,(iy+5)                ; 1f07
	ld (iy+5),a                 ; 1f0a
	ret                         ; 1f0d
L1f0e:
	dw L1f24                    ; 1f0e
	dw L1f34                    ; 1f10
	dw L1f44                    ; 1f12
	dw L1f54                    ; 1f14
	dw L1f64                    ; 1f16
	dw L1f74                    ; 1f18
	dw L1f84                    ; 1f1a
	dw L1f94                    ; 1f1c
	dw L1fa4                    ; 1f1e
	dw L1fb4                    ; 1f20
	dw L1fc4                    ; 1f22
L1f24:
	db $06,$00,$00,$1d,$15,$14,$00,$00,$00,$01,$00,$03,$00,$01,$01,$00; 1f24
L1f34:
	db $07,$00,$00,$1d,$15,$14,$00,$00,$00,$01,$00,$03,$00,$01,$01,$00; 1f34
L1f44:
	db $08,$00,$00,$1d,$0b,$14,$00,$00,$00,$00,$00,$03,$00,$01,$01,$00; 1f44
L1f54:
	db $09,$00,$00,$1d,$0b,$14,$00,$00,$00,$00,$00,$03,$00,$01,$01,$00; 1f54
L1f64:
	db $06,$00,$00,$1d,$15,$28,$00,$00,$00,$01,$00,$03,$00,$01,$01,$00; 1f64
L1f74:
	db $07,$00,$00,$1d,$15,$28,$00,$00,$00,$01,$00,$03,$00,$01,$01,$00; 1f74
L1f84:
	db $08,$00,$00,$1d,$0b,$28,$00,$00,$00,$00,$00,$03,$00,$01,$01,$00; 1f84
L1f94:
	db $09,$00,$00,$1d,$0b,$28,$00,$00,$00,$00,$00,$03,$00,$01,$01,$00; 1f94
L1fa4:
	db $0f,$00,$00,$1d,$0b,$14,$00,$00,$00,$00,$00,$03,$00,$01,$01,$00; 1fa4
L1fb4:
	db $10,$00,$00,$1d,$0b,$28,$00,$00,$00,$00,$00,$03,$00,$01,$01,$00; 1fb4
L1fc4:
	db $06,$00,$00,$1d,$15,$14,$00,$00,$00,$01,$00,$03,$00,$01,$01,$00; 1fc4
L1fd4:
	db $09,$09,$09,$09,$09,$09,$09,$09,$09,$09,$09,$09,$0a,$0a,$0a,$0a; 1fd4
	db $0a,$0a,$0a,$0a,$0a,$0a,$0a,$0a,$0a,$0a,$03,$03,$03,$03,$01,$03; 1fe4
	db $03,$03,$01,$03,$03,$03,$05,$05,$07,$07,$07,$07,$05,$07,$07,$07; 1ff4
	db $07,$07,$03,$03,$03,$03,$01,$03,$03,$03,$01,$03,$03,$03,$05,$05; 2004
	db $07,$07,$07,$07,$05,$07,$07,$07,$07,$07,$ff; 2014
L201f:
	db $04,$04,$04,$04,$02,$02,$04,$04,$02,$04,$04,$04,$08,$08,$08,$06; 201f
	db $08,$08,$08,$08,$08,$08,$08,$08,$0b,$0b,$02,$0b,$02,$02,$0b,$0b; 202f
	db $02,$02,$0b,$02,$0b,$0b,$02,$0b,$02,$02,$0b,$0b,$02,$02,$0b,$02; 203f
	db $04,$04,$02,$04,$02,$04,$04,$04,$04,$02,$04,$04,$08,$08,$08,$06; 204f
	db $08,$08,$08,$08,$08,$08,$08,$08,$04,$04,$02,$04,$02,$04,$04,$04; 205f
	db $04,$02,$04,$04,$08,$08,$08,$08,$08,$08,$08,$08,$08,$08,$08,$08; 206f
	db $08,$08,$08,$ff          ; 207f
L2083:
	xor a                       ; 2083
	ld (WRK+$265),a             ; 2084
	ld hl,L1fd4                 ; 2087
	ld (WRK+$040),hl            ; 208a
	ld a,(WRK+$062)             ; 208d
	cp $07                      ; 2090
	ret c                       ; 2092
	ld hl,L201f                 ; 2093
	ld (WRK+$040),hl            ; 2096
	ret                         ; 2099
L209a:
	db $12,$3e,$13,$c3,$00,$80  ; 209a
L20a0:
	call L20a3                  ; 20a0
L20a3:
	ld hl,(WRK+$05c)            ; 20a3
	ld a,h                      ; 20a6
	cp $1b                      ; 20a7
	jr z,L20b0                  ; 20a9
	inc h                       ; 20ab
	jr c,L20b0                  ; 20ac
	dec h                       ; 20ae
	dec h                       ; 20af
L20b0:
	ld a,l                      ; 20b0
	cp $19                      ; 20b1
	jr z,L20ba                  ; 20b3
	inc l                       ; 20b5
	jr c,L20ba                  ; 20b6
	dec l                       ; 20b8
	dec l                       ; 20b9
L20ba:
	ld (WRK+$05c),hl            ; 20ba
	ret                         ; 20bd
L20be:
	ld a,$15                    ; 20be
	jp L8000                    ; 20c0
L20c3:
	ld a,$14                    ; 20c3
	jp L8000                    ; 20c5
L20c8:
	ld a,$10                    ; 20c8
	jp L8000                    ; 20ca
L20cd:
	ld a,$11                    ; 20cd
	jp L8000                    ; 20cf
L20d2:
	ld a,$16                    ; 20d2
	jp L8000                    ; 20d4
L20d7:
	ld hl,L20e3                 ; 20d7
	ld de,WRK+$079              ; 20da
	ld bc,$0090                 ; 20dd
	ldir                        ; 20e0
	ret                         ; 20e2
L20e3:
	db $0a,$00,$00,$1e,$08,$11,$00,$00,$00,$01,$00,$05,$00,$02,$00,$00; 20e3
	db $78,$00,$00,$00,$00,$00,$00,$00,$0b,$00,$00,$1e,$08,$1b,$00,$00; 20f3
	db $00,$01,$00,$05,$00,$02,$00,$00,$78,$00,$00,$00,$00,$00,$00,$00; 2103
	db $0c,$00,$00,$1e,$08,$27,$00,$00,$00,$01,$00,$05,$00,$02,$00,$00; 2113
	db $78,$00,$00,$00,$00,$00,$00,$00,$0c,$00,$00,$1e,$14,$11,$00,$00; 2123
	db $00,$01,$00,$05,$00,$02,$00,$00,$78,$00,$00,$00,$00,$00,$00,$00; 2133
	db $0d,$00,$00,$1e,$14,$1b,$00,$00,$00,$01,$00,$05,$00,$02,$00,$00; 2143
	db $78,$00,$00,$00,$00,$00,$00,$00,$0e,$00,$00,$1e,$14,$27,$00,$00; 2153
	db $00,$01,$00,$05,$00,$02,$00,$00,$78,$00,$00,$00,$00,$00,$00,$00; 2163
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 2173
L217d:
	db $00                      ; 217d
L217e:
	ret                         ; 217e
	ld a,$0b                    ; 217f
	call L8000                  ; 2181
	ld a,$0c                    ; 2184
	jp L8000                    ; 2186
L2189:
	ld a,$0d                    ; 2189
	jp L8000                    ; 218b
L218e:
	ld a,(WRK+$062)             ; 218e
	dec a                       ; 2191
	add a,a                     ; 2192
	ld e,a                      ; 2193
	ld d,$00                    ; 2194
	ld hl,L21a2                 ; 2196
	add hl,de                   ; 2199
	ld e,(hl)                   ; 219a
	inc hl                      ; 219b
	ld d,(hl)                   ; 219c
	ld (WRK+$267),de            ; 219d
	ret                         ; 21a1
L21a2:
	db $94,$54,$a4,$66,$e3,$53,$f2,$55,$a4,$26,$f0,$25,$d5,$05,$a4,$66; 21a2
	db $e1,$56,$94,$54,$85,$55,$f0,$25,$f0,$25,$f7,$25,$d5,$25,$d1,$75; 21b2
	db $94,$54,$d3,$55          ; 21c2
L21c6:
	call L2208                  ; 21c6
	ld a,(WRK+$062)             ; 21c9
	cp $06                      ; 21cc
	ret nz                      ; 21ce
	ld a,(WRK+$05d)             ; 21cf
	sub $0c                     ; 21d2
	sra a                       ; 21d4
	sra a                       ; 21d6
	ld e,a                      ; 21d8
	ld d,$00                    ; 21d9
	ld hl,L21fd                 ; 21db
	add hl,de                   ; 21de
	ld a,(hl)                   ; 21df
	ld hl,(L21fb)               ; 21e0
	add a,h                     ; 21e3
	and $3f                     ; 21e4
	ld h,a                      ; 21e6
	ld a,(WRK+$066)             ; 21e7
	ld c,a                      ; 21ea
	ld a,$0f                    ; 21eb
	sub c                       ; 21ed
	ld l,a                      ; 21ee
	ld (L21fb),hl               ; 21ef
	ld de,Lbb00                 ; 21f2
	ld bc,$1008                 ; 21f5
	jp L1d30                    ; 21f8
L21fb:
	db $0d,$00                  ; 21fb
L21fd:
	db $02,$01,$01,$00,$00,$00,$00,$ff,$ff,$fe; 21fd
L2207:
	db $74                      ; 2207
L2208:
	ld a,(WRK+$05d)             ; 2208
	sub $0c                     ; 220b
	sra a                       ; 220d
	sra a                       ; 220f
	ld e,a                      ; 2211
	ld d,$00                    ; 2212
	ld hl,L224b                 ; 2214
	add hl,de                   ; 2217
	ld c,(hl)                   ; 2218
	ld a,(L224a)                ; 2219
	add a,c                     ; 221c
	and $0f                     ; 221d
	ld (L224a),a                ; 221f
	ld e,a                      ; 2222
	ld d,$00                    ; 2223
	ld hl,L2255                 ; 2225
	add hl,de                   ; 2228
	ex de,hl                    ; 2229
	ld a,(WRK+$066)             ; 222a
	ld c,a                      ; 222d
	ld a,$1a                    ; 222e
	sub c                       ; 2230
	ld l,a                      ; 2231
	ld h,$0c                    ; 2232
	ld a,$11                    ; 2234
	call La000                  ; 2236
	ld a,(L2207)                ; 2239
	ld c,a                      ; 223c
	ld b,$28                    ; 223d
L223f:
	ld a,(de)                   ; 223f
	or a                        ; 2240
	jp z,L2245                  ; 2241
	ld (hl),c                   ; 2244
L2245:
	inc de                      ; 2245
	inc l                       ; 2246
	djnz L223f                  ; 2247
	ret                         ; 2249
L224a:
	db $0d                      ; 224a
L224b:
	db $fd,$fe,$fe,$ff,$00,$00,$01,$02,$02,$03; 224b
L2255:
	db $01,$01,$01,$00,$00,$00,$01,$00,$01,$01,$00,$00,$00,$01,$00,$00; 2255
	db $01,$01,$01,$00,$00,$00,$01,$00,$01,$01,$00,$00,$00,$01,$00,$00; 2265
	db $01,$01,$01,$00,$00,$00,$01,$00,$01,$01,$00,$00,$00,$01,$00,$00; 2275
	db $01,$01,$01,$00,$00,$00,$01,$00; 2285
L228d:
	ld a,(WRK+$062)             ; 228d
	dec a                       ; 2290
	ld e,a                      ; 2291
	ld d,$00                    ; 2292
	ld hl,L229d                 ; 2294
	add hl,de                   ; 2297
	ld a,(hl)                   ; 2298
	ld (L2207),a                ; 2299
	ret                         ; 229c
L229d:
	db $74,$26,$31,$04,$46,$16,$71,$46,$11,$65,$16,$06,$55,$46,$44,$44; 229d
	db $56,$25                  ; 22ad
L22af:
	ld ix,WRK+$269              ; 22af
	ld b,$08                    ; 22b3
L22b5:
	push bc                     ; 22b5
	ld a,(ix+0)                 ; 22b6
	or a                        ; 22b9
	jr z,L22d0                  ; 22ba
	ld b,$0b                    ; 22bc
	ld c,(ix+3)                 ; 22be
	ld l,(ix+1)                 ; 22c1
	ld h,(ix+2)                 ; 22c4
	ld e,(ix+4)                 ; 22c7
	ld d,(ix+5)                 ; 22ca
	call L1d30                  ; 22cd
L22d0:
	pop bc                      ; 22d0
	ld de,$0006                 ; 22d1
	add ix,de                   ; 22d4
	djnz L22b5                  ; 22d6
	ret                         ; 22d8
L22d9:
	ld ix,WRK+$269              ; 22d9
	ld b,$08                    ; 22dd
	ld de,$0006                 ; 22df
L22e2:
	ld a,(ix+0)                 ; 22e2
	or a                        ; 22e5
	jp z,L22f2                  ; 22e6
	dec (ix+2)                  ; 22e9
	jp p,L22f2                  ; 22ec
	ld (ix+0),d                 ; 22ef
L22f2:
	add ix,de                   ; 22f2
	djnz L22e2                  ; 22f4
	ret                         ; 22f6
L22f7:
	ld ix,WRK+$269              ; 22f7
	ld de,$0006                 ; 22fb
	ld b,$08                    ; 22fe
L2300:
	ld a,(ix+0)                 ; 2300
	or a                        ; 2303
	ret z                       ; 2304
	add ix,de                   ; 2305
	djnz L2300                  ; 2307
	scf                         ; 2309
	ret                         ; 230a
L230b:
	call L22f7                  ; 230b
	ret c                       ; 230e
	ld (ix+0),$01               ; 230f
	ld (ix+1),$0d               ; 2313
	ld (ix+2),$34               ; 2317
	ld hl,(L2424)               ; 231b
	ld (ix+4),l                 ; 231e
	ld (ix+5),h                 ; 2321
	ld (ix+3),$0a               ; 2324
	ld a,(iy+0)                 ; 2328
	cp $09                      ; 232b
	jp z,L2347                  ; 232d
	ld de,$006e                 ; 2330
	or a                        ; 2333
	jp z,L2342                  ; 2334
	ld (ix+3),$14               ; 2337
	ld de,$00dc                 ; 233b
	ld (ix+1),$0a               ; 233e
L2342:
	add hl,de                   ; 2342
	ld (L2424),hl               ; 2343
	ret                         ; 2346
L2347:
	ld (ix+0),$00               ; 2347
	ret                         ; 234b
L234c:
	ld hl,L4000                 ; 234c
	ld (L2424),hl               ; 234f
	ld hl,L2426                 ; 2352
	ld (L24a4),hl               ; 2355
	ld hl,WRK+$269              ; 2358
	ld de,WRK+$26a              ; 235b
	ld bc,$0030                 ; 235e
	ld (hl),b                   ; 2361
	ldir                        ; 2362
L2364:
	ld b,$0c                    ; 2364
L2366:
	push bc                     ; 2366
	call L1dfd                  ; 2367
	call L1e0d                  ; 236a
	call L1de8                  ; 236d
	call L1a74                  ; 2370
	call L1d26                  ; 2373
	call L1e94                  ; 2376
	nop                         ; 2379
	nop                         ; 237a
	nop                         ; 237b
	call L217e                  ; 237c
	call L22d9                  ; 237f
	call L22af                  ; 2382
	call L1a65                  ; 2385
	call L1d2b                  ; 2388
	call L1a3c                  ; 238b
	jp z,L1250                  ; 238e
	pop bc                      ; 2391
	djnz L2366                  ; 2392
	ld iy,(L24a4)               ; 2394
	call L230b                  ; 2398
	inc iy                      ; 239b
	ld (L24a4),iy               ; 239d
	ld a,(iy+0)                 ; 23a1
	or a                        ; 23a4
	jp p,L2364                  ; 23a5
	ld hl,$0c07                 ; 23a8
	ld (MZW+$171),hl            ; 23ab
	ld de,L23ee                 ; 23ae
	call VZ_MSG                 ; 23b1 patched
	ld hl,$0e07                 ; 23b2
	ld (MZW+$171),hl            ; 23b5
	ld de,L2409                 ; 23b8
	call VZ_MSG                 ; 23bb patched
	ld hl,VRAM+$9e7             ; 23bc
	ld de,VRAM+$9e8             ; 23bf
	ld bc,$0019                 ; 23c2
	ld (hl),$70                 ; 23c5
	ldir                        ; 23c7
	ld hl,VRAM+$a37             ; 23c9
	ld de,VRAM+$a38             ; 23cc
	ld bc,$0019                 ; 23cf
	ld (hl),$70                 ; 23d2
	ldir                        ; 23d4
	di                          ; 23d6
	call VZ_BELL                ; 23d7 patched
	call VZ_FRAME
	ld a,$14                    ; 23da
L23dc:
	cpi                         ; 23dc
	jp pe,L23dc                 ; 23de
	dec a                       ; 23e1
	jr nz,L23dc                 ; 23e2
	nop                         ; 23e4 patched
	call VZ_BELL                ; 23e5 patched
	call VZ_BELL                ; 23e8 patched
	jp L1250                    ; 23eb
L23ee:
	db $31,$39,$38,$38,$20,$50,$52,$4f,$47,$52,$41,$4d,$20,$42,$59,$20; 23ee
	db $4b,$2e,$46,$55,$52,$55,$48,$41,$54,$41,$0d; 23fe
L2409:
	db $47,$41,$4d,$45,$20,$43,$48,$45,$43,$4b,$45,$44,$20,$42,$59,$20; 2409
	db $48,$2e,$4d,$49,$59,$41,$55,$43,$48,$49,$0d; 2419
L2424:
	db $00,$00                  ; 2424
L2426:
	db $01,$01,$01,$01,$01,$01,$01,$01,$01,$00,$00,$00,$00,$00,$00,$00; 2426
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 2436
	db $00,$01,$00,$00,$00,$00,$00,$00,$01,$01,$01,$01,$01,$01,$01,$01; 2446
	db $01,$01,$00,$01,$01,$01,$01,$00,$00,$00,$00,$00,$00,$00,$00,$00; 2456
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$01,$01,$00; 2466
	db $01,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 2476
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 2486
	db $01,$01,$00,$00,$01,$09,$09,$09,$09,$09,$09,$09,$09,$ff; 2496
L24a4:
	db $00,$00                  ; 24a4
L24a6:
	db $00,$00,$23,$19,$00,$00,$00,$29,$20,$43,$00,$00,$00,$00,$00,$00; 24a6
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$ff,$ff,$ff,$ff,$ff,$ff; 24b6
	db $ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff; 24c6
	db $ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$00,$00,$00,$00,$00,$00; 24d6
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 24e6
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 24f6
L2500:
	dec a                       ; 2500
	push de                     ; 2501
	push hl                     ; 2502
	add a,a                     ; 2503
	ld e,a                      ; 2504
	ld d,$00                    ; 2505
	ld hl,L2517                 ; 2507
	add hl,de                   ; 250a
	ld e,(hl)                   ; 250b
	inc hl                      ; 250c
	ld d,(hl)                   ; 250d
	ld (L2514+1),de             ; 250e
	pop hl                      ; 2512
	pop de                      ; 2513
L2514:
	jp L2524                    ; 2514
L2517:
	dw L2524                    ; 2517
	dw L36dd                    ; 2519
	dw L3eb5                    ; 251b
	dw L260a                    ; 251d
	dw L37a2                    ; 251f
	dw L37b1                    ; 2521
L2523:
	db $aa                      ; 2523
L2524:
	ld hl,L2523                 ; 2524
	rlc (hl)                    ; 2527
	ret c                       ; 2529
	ld ix,WRK+$079              ; 252a
	ld b,$10                    ; 252e
	ld de,$0018                 ; 2530
L2533:
	exx                         ; 2533
	ld a,(WRK+$068)             ; 2534
	cp (ix+13)                  ; 2537
	jp c,L256b                  ; 253a
	ld a,(ix+0)                 ; 253d
	or a                        ; 2540
	jp z,L256b                  ; 2541
	bit 7,(ix+7)                ; 2544
	jp nz,L2551                 ; 2548
	dec (ix+7)                  ; 254b
	jp L256b                    ; 254e
L2551:
	ld a,(ix+11)                ; 2551
	cp $31                      ; 2554
	jp nc,L256b                 ; 2556
	dec a                       ; 2559
	add a,a                     ; 255a
	ld e,a                      ; 255b
	ld d,$00                    ; 255c
	ld hl,L2571                 ; 255e
	add hl,de                   ; 2561
	ld e,(hl)                   ; 2562
	inc hl                      ; 2563
	ld d,(hl)                   ; 2564
	ex de,hl                    ; 2565
	ld de,L256b                 ; 2566
	push de                     ; 2569
	jp (hl)                     ; 256a
L256b:
	exx                         ; 256b
	add ix,de                   ; 256c
	djnz L2533                  ; 256e
	ret                         ; 2570
L2571:
	dw L282a                    ; 2571
	dw L2847                    ; 2573
	dw L28ba                    ; 2575
	dw L2c03                    ; 2577
	dw L2f86                    ; 2579
	dw L2901                    ; 257b
	dw L2937                    ; 257d
	dw L2edf                    ; 257f
	dw L2edf                    ; 2581
	dw L2b1c                    ; 2583
	dw L29f6                    ; 2585
	dw L2a5f                    ; 2587
	dw L2866                    ; 2589
	dw L288c                    ; 258b
	dw L27b8                    ; 258d
	dw L27ee                    ; 258f
	dw L2813                    ; 2591
	dw L2cb8                    ; 2593
	dw L2cfe                    ; 2595
	dw L2ace                    ; 2597
	dw L2ace                    ; 2599
	dw L2af5                    ; 259b
	dw L2af5                    ; 259d
	dw L2b9d                    ; 259f
	dw L2b9d                    ; 25a1
	dw L2c44                    ; 25a3
	dw L29ba                    ; 25a5
	dw L29e0                    ; 25a7
	dw L2d4e                    ; 25a9
	dw L2da2                    ; 25ab
	dw L2f3c                    ; 25ad
	dw L2f76                    ; 25af
	dw L2dda                    ; 25b1
	dw L2e3c                    ; 25b3
	dw L2958                    ; 25b5
	dw L2991                    ; 25b7
	dw L2bc8                    ; 25b9
	dw L2bc8                    ; 25bb
	dw L27a4                    ; 25bd
	dw L2b6b                    ; 25bf
	dw L302e                    ; 25c1
	dw L3094                    ; 25c3
	dw L305f                    ; 25c5
	dw L3094                    ; 25c7
	dw L3094                    ; 25c9
	dw L2755                    ; 25cb
	dw L2750                    ; 25cd
	dw L274b                    ; 25cf
	dw L2750                    ; 25d1
	dw L2750                    ; 25d3
	dw L2750                    ; 25d5
	dw L2750                    ; 25d7
	dw L2750                    ; 25d9
	dw L2750                    ; 25db
L25dd:
	ld a,$22                    ; 25dd
	jp La000                    ; 25df
	ld a,$18                    ; 25e2
	jp La000                    ; 25e4
	ld a,$0e                    ; 25e7
	jp La000                    ; 25e9
	ld a,$1c                    ; 25ec
	jp La000                    ; 25ee
	ld a,$1d                    ; 25f1
	jp La000                    ; 25f3
	ld a,$19                    ; 25f6
	jp La000                    ; 25f8
	ld a,$03                    ; 25fb
	jp La000                    ; 25fd
	ld a,$02                    ; 2600
	jp La000                    ; 2602
	ld a,$07                    ; 2605
	jp La000                    ; 2607
L260a:
	ld hl,WRK+$042              ; 260a
	dec (hl)                    ; 260d
	ret p                       ; 260e
	ld (hl),$05                 ; 260f
	ld hl,WRK+$03f              ; 2611
	dec (hl)                    ; 2614
	jp m,L261f                  ; 2615
	ld iy,(WRK+$040)            ; 2618
	jp L263e                    ; 261c
L261f:
	ld (hl),$04                 ; 261f
	call L3ebb                  ; 2621
	ld hl,(WRK+$040)            ; 2624
	ld iy,(WRK+$040)            ; 2627
	inc hl                      ; 262b
	inc hl                      ; 262c
	ld (WRK+$040),hl            ; 262d
	ld a,(iy+0)                 ; 2630
	cp $63                      ; 2633
	jp nz,L263e                 ; 2635
	ld a,$02                    ; 2638
	ld (WRK+$050),a             ; 263a
	ret                         ; 263d
L263e:
	call L25dd                  ; 263e
	ret c                       ; 2641
	ld a,(iy+0)                 ; 2642
	or a                        ; 2645
	jp p,L264f                  ; 2646
	ld a,$01                    ; 2649
	ld (WRK+$25b),a             ; 264b
	ret                         ; 264e
L264f:
	dec a                       ; 264f
	ret m                       ; 2650
	cp $1a                      ; 2651
	ret nc                      ; 2653
	call L2663                  ; 2654
	call L25dd                  ; 2657
	ret c                       ; 265a
	ld a,(iy+1)                 ; 265b
	dec a                       ; 265e
	ret m                       ; 265f
	cp $1a                      ; 2660
	ret nc                      ; 2662
L2663:
	ld e,a                      ; 2663
	add a,$17                   ; 2664
	ld (ix+0),a                 ; 2666
	ld d,$00                    ; 2669
	ld a,e                      ; 266b
	add a,a                     ; 266c
	ld e,a                      ; 266d
	ld hl,L26da                 ; 266e
	add hl,de                   ; 2671
	ld e,(hl)                   ; 2672
	inc hl                      ; 2673
	ld d,(hl)                   ; 2674
	ex de,hl                    ; 2675
	push ix                     ; 2676
	pop de                      ; 2678
	inc de                      ; 2679
	inc de                      ; 267a
	inc de                      ; 267b
	inc de                      ; 267c
	ld bc,$0009                 ; 267d
	ldir                        ; 2680
	ld (ix+3),$1f               ; 2682
L2686:
	ld a,$00                    ; 2686
	inc a                       ; 2688
	and $0f                     ; 2689
	ld (L2686+1),a              ; 268b
	ld e,a                      ; 268e
	ld d,$00                    ; 268f
	ld hl,L26c7                 ; 2691
	add hl,de                   ; 2694
	ld a,(hl)                   ; 2695
	ld (ix+5),a                 ; 2696
	ld a,(WRK+$057)             ; 2699
	ld (ix+13),a                ; 269c
	ld a,(ix+0)                 ; 269f
	sub $17                     ; 26a2
	ld e,a                      ; 26a4
	ld hl,L26ae                 ; 26a5
	add hl,de                   ; 26a8
	ld a,(hl)                   ; 26a9
	ld (ix+14),a                ; 26aa
	ret                         ; 26ad
L26ae:
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$01,$00,$00,$00,$01,$00,$00; 26ae
	db $00,$00,$00,$00,$00,$00,$01,$01,$01; 26be
L26c7:
	db $1e,$3c,$28,$0a,$14,$00,$32,$18,$08,$2a,$23,$0f,$01,$3b,$2f,$13; 26c7
	db $00,$00,$00              ; 26d7
L26da:
	dw L270c                    ; 26da
	dw L270c                    ; 26dc
	dw L2715                    ; 26de
	dw L2715                    ; 26e0
	dw L2715                    ; 26e2
	dw L2715                    ; 26e4
	dw L2715                    ; 26e6
	dw L2715                    ; 26e8
	dw L271e                    ; 26ea
	dw L2727                    ; 26ec
	dw L2730                    ; 26ee
	dw L2730                    ; 26f0
	dw L2730                    ; 26f2
	dw L2739                    ; 26f4
	dw L2742                    ; 26f6
	dw L2730                    ; 26f8
	dw L2730                    ; 26fa
	dw L2730                    ; 26fc
	dw L2715                    ; 26fe
	dw L2715                    ; 2700
	dw L2715                    ; 2702
	dw L2715                    ; 2704
	dw L2742                    ; 2706
	dw L2739                    ; 2708
	dw L2727                    ; 270a
L270c:
	db $0b,$00,$00,$ff,$00,$00,$00,$2e,$00; 270c
L2715:
	db $0b,$00,$00,$ff,$02,$00,$00,$2e,$00; 2715
L271e:
	db $0f,$00,$00,$ff,$00,$00,$00,$2e,$00; 271e
L2727:
	db $07,$00,$00,$ff,$00,$01,$00,$2e,$00; 2727
L2730:
	db $15,$00,$00,$ff,$00,$01,$00,$2e,$00; 2730
L2739:
	db $0b,$00,$00,$ff,$02,$01,$00,$2e,$00; 2739
L2742:
	db $15,$00,$00,$ff,$02,$01,$00,$2e,$00; 2742
L274b:
	ld a,$1a                    ; 274b
	jp La000                    ; 274d
L2750:
	ld a,$23                    ; 2750
	jp La000                    ; 2752
L2755:
	ld a,(WRK+$062)             ; 2755
	cp $0f                      ; 2758
	jr z,L276d                  ; 275a
	ld a,(ix+6)                 ; 275c
	xor $01                     ; 275f
	ld (ix+6),a                 ; 2761
L2764:
	dec (ix+3)                  ; 2764
	ret p                       ; 2767
	ld (ix+0),$00               ; 2768
	ret                         ; 276c
L276d:
	ld a,(ix+0)                 ; 276d
	cp $20                      ; 2770
	jp nz,L2764                 ; 2772
	dec (ix+3)                  ; 2775
	jp m,L27e9                  ; 2778
	dec (ix+16)                 ; 277b
	ld a,(ix+16)                ; 277e
	and $1f                     ; 2781
	cp $10                      ; 2783
	jr c,L2793                  ; 2785
	dec (ix+4)                  ; 2787
	dec (ix+4)                  ; 278a
	ret p                       ; 278d
	ld (ix+4),$00               ; 278e
	ret                         ; 2792
L2793:
	inc (ix+4)                  ; 2793
	inc (ix+4)                  ; 2796
	ld a,(ix+4)                 ; 2799
	cp $13                      ; 279c
	ret c                       ; 279e
	ld (ix+4),$13               ; 279f
	ret                         ; 27a3
L27a4:
	ld a,(ix+3)                 ; 27a4
	cp $0c                      ; 27a7
	call z,L3eb6                ; 27a9
	dec (ix+3)                  ; 27ac
	jp m,L27e9                  ; 27af
	ld a,(ix+3)                 ; 27b2
	cp $0a                      ; 27b5
	ret nz                      ; 27b7
L27b8:
	ld a,(ix+16)                ; 27b8
	or a                        ; 27bb
	jp nz,L27cc                 ; 27bc
	inc (ix+5)                  ; 27bf
	ld a,(ix+5)                 ; 27c2
	cp $28                      ; 27c5
	ret c                       ; 27c7
	inc (ix+16)                 ; 27c8
	ret                         ; 27cb
L27cc:
	dec (ix+17)                 ; 27cc
	bit 0,(ix+17)               ; 27cf
	jp z,L27e2                  ; 27d3
	inc (ix+4)                  ; 27d6
	inc (ix+4)                  ; 27d9
	dec (ix+3)                  ; 27dc
	jp m,L27e9                  ; 27df
L27e2:
	dec (ix+5)                  ; 27e2
	dec (ix+5)                  ; 27e5
	ret p                       ; 27e8
L27e9:
	ld (ix+0),$00               ; 27e9
	ret                         ; 27ed
L27ee:
	inc (ix+5)                  ; 27ee
	inc (ix+5)                  ; 27f1
	ld a,(ix+5)                 ; 27f4
	cp $3e                      ; 27f7
	jp c,L2802                  ; 27f9
	dec (ix+5)                  ; 27fc
	dec (ix+5)                  ; 27ff
L2802:
	inc (ix+3)                  ; 2802
	ld a,(ix+3)                 ; 2805
L2808:
	cp $1e                      ; 2808
	jp nc,L27e9                 ; 280a
	cp $0c                      ; 280d
	ret nz                      ; 280f
	jp L3eb6                    ; 2810
L2813:
	dec (ix+5)                  ; 2813
	dec (ix+5)                  ; 2816
	ld a,(ix+5)                 ; 2819
	cp $03                      ; 281c
	jp nc,L2827                 ; 281e
	inc (ix+5)                  ; 2821
	inc (ix+5)                  ; 2824
L2827:
	jp L2802                    ; 2827
L282a:
	ld a,(ix+16)                ; 282a
	or a                        ; 282d
	jp z,L283a                  ; 282e
	dec (ix+4)                  ; 2831
	ret p                       ; 2834
	ld (ix+0),$00               ; 2835
	ret                         ; 2839
L283a:
	dec (ix+3)                  ; 283a
	ld a,(ix+3)                 ; 283d
	cp $04                      ; 2840
	ret nc                      ; 2842
	inc (ix+16)                 ; 2843
	ret                         ; 2846
L2847:
	ld a,(ix+16)                ; 2847
	or a                        ; 284a
	jp z,L2857                  ; 284b
	dec (ix+4)                  ; 284e
	ret p                       ; 2851
	ld (ix+0),$00               ; 2852
	ret                         ; 2856
L2857:
	dec (ix+3)                  ; 2857
	ld a,(ix+3)                 ; 285a
	cp $08                      ; 285d
	ret nc                      ; 285f
	inc (ix+16)                 ; 2860
	jp L3eb6                    ; 2863
L2866:
	ld a,(ix+3)                 ; 2866
	cp $03                      ; 2869
	jp c,L2876                  ; 286b
	dec (ix+3)                  ; 286e
	cp $0b                      ; 2871
	jp z,L3eb6                  ; 2873
L2876:
	dec (ix+17)                 ; 2876
	bit 0,(ix+17)               ; 2879
	jp z,L2883                  ; 287d
	dec (ix+5)                  ; 2880
L2883:
	dec (ix+5)                  ; 2883
	ret p                       ; 2886
	ld (ix+0),$00               ; 2887
	ret                         ; 288b
L288c:
	ld a,(ix+3)                 ; 288c
	cp $03                      ; 288f
	jp c,L289f                  ; 2891
	dec (ix+3)                  ; 2894
	ld a,(ix+3)                 ; 2897
	cp $0b                      ; 289a
	jp z,L3eb6                  ; 289c
L289f:
	dec (ix+17)                 ; 289f
	bit 0,(ix+17)               ; 28a2
	jp z,L28ac                  ; 28a6
	inc (ix+5)                  ; 28a9
L28ac:
	inc (ix+5)                  ; 28ac
	ld a,(ix+5)                 ; 28af
	cp $32                      ; 28b2
	ret c                       ; 28b4
	ld (ix+0),$00               ; 28b5
	ret                         ; 28b9
L28ba:
	ld a,(ix+16)                ; 28ba
	dec a                       ; 28bd
	jp m,L28ee                  ; 28be
	jp z,L28db                  ; 28c1
	dec (ix+3)                  ; 28c4
	jp m,L27e9                  ; 28c7
	inc (ix+5)                  ; 28ca
	inc (ix+5)                  ; 28cd
	ld a,(ix+5)                 ; 28d0
	cp $3c                      ; 28d3
	ret c                       ; 28d5
	ld (ix+0),$00               ; 28d6
	ret                         ; 28da
L28db:
	dec (ix+5)                  ; 28db
	dec (ix+5)                  ; 28de
	ld a,(ix+5)                 ; 28e1
	cp $05                      ; 28e4
	ret nc                      ; 28e6
	ld (ix+16),$02              ; 28e7
	jp L3eb6                    ; 28eb
L28ee:
	inc (ix+5)                  ; 28ee
	dec (ix+3)                  ; 28f1
	ld a,(ix+3)                 ; 28f4
	cp $0a                      ; 28f7
	ret nc                      ; 28f9
	ld (ix+16),$01              ; 28fa
	jp L3eb6                    ; 28fe
L2901:
	dec (ix+3)                  ; 2901
	jp m,L27e9                  ; 2904
	ld a,(ix+3)                 ; 2907
	cp $06                      ; 290a
	jp c,L291c                  ; 290c
	dec (ix+16)                 ; 290f
	ld a,(ix+16)                ; 2912
	and $0f                     ; 2915
	cp $08                      ; 2917
	jp nc,L2927                 ; 2919
L291c:
	dec (ix+4)                  ; 291c
	dec (ix+4)                  ; 291f
	ret p                       ; 2922
	inc (ix+4)                  ; 2923
	ret                         ; 2926
L2927:
	inc (ix+4)                  ; 2927
	inc (ix+4)                  ; 292a
	ld a,(ix+4)                 ; 292d
	cp $11                      ; 2930
	ret c                       ; 2932
	dec (ix+4)                  ; 2933
	ret                         ; 2936
L2937:
	dec (ix+3)                  ; 2937
	jp m,L27e9                  ; 293a
	dec (ix+16)                 ; 293d
	ld a,(ix+16)                ; 2940
	and $0f                     ; 2943
	cp $08                      ; 2945
	jp nc,L2951                 ; 2947
	dec (ix+5)                  ; 294a
	dec (ix+5)                  ; 294d
	ret                         ; 2950
L2951:
	inc (ix+5)                  ; 2951
	inc (ix+5)                  ; 2954
	ret                         ; 2957
L2958:
	ld a,(ix+16)                ; 2958
	dec a                       ; 295b
	jp m,L2975                  ; 295c
	jp z,L296e                  ; 295f
L2962:
	inc (ix+3)                  ; 2962
	ld a,(ix+3)                 ; 2965
	cp $1e                      ; 2968
	jp nc,L27e9                 ; 296a
	ret                         ; 296d
L296e:
	ld (ix+16),$02              ; 296e
	jp L3eb6                    ; 2972
L2975:
	inc (ix+5)                  ; 2975
	inc (ix+5)                  ; 2978
	ld a,(ix+5)                 ; 297b
	and $07                     ; 297e
	jp nz,L2986                 ; 2980
	inc (ix+3)                  ; 2983
L2986:
	ld a,(ix+5)                 ; 2986
	cp $28                      ; 2989
	ret c                       ; 298b
	ld (ix+16),$01              ; 298c
	ret                         ; 2990
L2991:
	ld a,(ix+16)                ; 2991
	dec a                       ; 2994
	jp m,L299e                  ; 2995
	jp nz,L2962                 ; 2998
	jp z,L296e                  ; 299b
L299e:
	dec (ix+5)                  ; 299e
	dec (ix+5)                  ; 29a1
	ld a,(ix+5)                 ; 29a4
	and $07                     ; 29a7
	jp nz,L29af                 ; 29a9
	inc (ix+3)                  ; 29ac
L29af:
	ld a,(ix+5)                 ; 29af
	cp $11                      ; 29b2
	ret nc                      ; 29b4
	ld (ix+16),$01              ; 29b5
	ret                         ; 29b9
L29ba:
	ld a,(ix+16)                ; 29ba
	or a                        ; 29bd
	jp nz,L29d1                 ; 29be
L29c1:
	dec (ix+3)                  ; 29c1
	ld a,(ix+3)                 ; 29c4
	cp $0a                      ; 29c7
	ret nc                      ; 29c9
	ld (ix+16),$01              ; 29ca
	jp L3eb6                    ; 29ce
L29d1:
	dec (ix+5)                  ; 29d1
	dec (ix+5)                  ; 29d4
	dec (ix+3)                  ; 29d7
	ret p                       ; 29da
	ld (ix+0),$00               ; 29db
	ret                         ; 29df
L29e0:
	ld a,(ix+16)                ; 29e0
	or a                        ; 29e3
	jp z,L29c1                  ; 29e4
	inc (ix+5)                  ; 29e7
	inc (ix+5)                  ; 29ea
	dec (ix+3)                  ; 29ed
	ret p                       ; 29f0
	ld (ix+0),$00               ; 29f1
	ret                         ; 29f5
L29f6:
	ld a,(ix+16)                ; 29f6
	dec a                       ; 29f9
	jp m,L2a39                  ; 29fa
	jp z,L2a12                  ; 29fd
	dec (ix+5)                  ; 2a00
	jp m,L27e9                  ; 2a03
	inc (ix+3)                  ; 2a06
	ld a,(ix+3)                 ; 2a09
	cp $1f                      ; 2a0c
	ret c                       ; 2a0e
	jp L27e9                    ; 2a0f
L2a12:
	inc (ix+5)                  ; 2a12
	dec (ix+17)                 ; 2a15
	bit 0,(ix+17)               ; 2a18
	jp z,L2a22                  ; 2a1c
	inc (ix+3)                  ; 2a1f
L2a22:
	dec (ix+4)                  ; 2a22
	jp p,L2a2c                  ; 2a25
	ld (ix+4),$00               ; 2a28
L2a2c:
	ld a,(ix+5)                 ; 2a2c
	cp $35                      ; 2a2f
	ret c                       ; 2a31
	ld (ix+16),$02              ; 2a32
	jp L3eb6                    ; 2a36
L2a39:
	inc (ix+5)                  ; 2a39
	dec (ix+17)                 ; 2a3c
	bit 0,(ix+17)               ; 2a3f
	jp z,L2a51                  ; 2a43
	ld a,(ix+3)                 ; 2a46
	cp $03                      ; 2a49
	jp c,L2a51                  ; 2a4b
	dec (ix+3)                  ; 2a4e
L2a51:
	inc (ix+4)                  ; 2a51
	ld a,(ix+4)                 ; 2a54
	cp $17                      ; 2a57
	ret c                       ; 2a59
	ld (ix+16),$01              ; 2a5a
	ret                         ; 2a5e
L2a5f:
	ld a,(ix+16)                ; 2a5f
	dec a                       ; 2a62
	jp m,L2aa8                  ; 2a63
	jp z,L2a80                  ; 2a66
	inc (ix+5)                  ; 2a69
	ld a,(ix+5)                 ; 2a6c
	cp $40                      ; 2a6f
	jp nc,L27e9                 ; 2a71
	inc (ix+3)                  ; 2a74
	ld a,(ix+3)                 ; 2a77
	cp $1f                      ; 2a7a
	ret c                       ; 2a7c
	jp L27e9                    ; 2a7d
L2a80:
	dec (ix+5)                  ; 2a80
	ld a,(ix+5)                 ; 2a83
	cp $0b                      ; 2a86
	jp nc,L2a92                 ; 2a88
	ld (ix+16),$02              ; 2a8b
	jp L3eb6                    ; 2a8f
L2a92:
	dec (ix+17)                 ; 2a92
	bit 0,(ix+17)               ; 2a95
	jp z,L2a9f                  ; 2a99
	inc (ix+3)                  ; 2a9c
L2a9f:
	dec (ix+4)                  ; 2a9f
	ret p                       ; 2aa2
	ld (ix+4),$00               ; 2aa3
	ret                         ; 2aa7
L2aa8:
	dec (ix+5)                  ; 2aa8
	dec (ix+17)                 ; 2aab
	bit 0,(ix+17)               ; 2aae
	jp z,L2ac0                  ; 2ab2
	ld a,(ix+3)                 ; 2ab5
	cp $03                      ; 2ab8
	jp c,L2ac0                  ; 2aba
	dec (ix+3)                  ; 2abd
L2ac0:
	inc (ix+4)                  ; 2ac0
	ld a,(ix+4)                 ; 2ac3
	cp $17                      ; 2ac6
	ret c                       ; 2ac8
	ld (ix+16),$01              ; 2ac9
	ret                         ; 2acd
L2ace:
	inc (ix+3)                  ; 2ace
	ld a,(ix+3)                 ; 2ad1
	cp $1f                      ; 2ad4
	jp nc,L27e9                 ; 2ad6
	cp $04                      ; 2ad9
	ret c                       ; 2adb
	cp $0d                      ; 2adc
	jp z,L3eb6                  ; 2ade
	ret nc                      ; 2ae1
	cp $08                      ; 2ae2
	jp c,L2aee                  ; 2ae4
	inc (ix+4)                  ; 2ae7
	inc (ix+4)                  ; 2aea
	ret                         ; 2aed
L2aee:
	dec (ix+4)                  ; 2aee
	dec (ix+4)                  ; 2af1
	ret                         ; 2af4
L2af5:
	dec (ix+3)                  ; 2af5
	jp m,L27e9                  ; 2af8
	ld a,(ix+3)                 ; 2afb
	cp $12                      ; 2afe
	ret nc                      ; 2b00
	cp $0c                      ; 2b01
	jp z,L3eb6                  ; 2b03
	jp nc,L2b15                 ; 2b06
	cp $06                      ; 2b09
	jp c,L2b15                  ; 2b0b
	inc (ix+4)                  ; 2b0e
	inc (ix+4)                  ; 2b11
	ret                         ; 2b14
L2b15:
	dec (ix+4)                  ; 2b15
	dec (ix+4)                  ; 2b18
	ret                         ; 2b1b
L2b1c:
	ld a,(ix+16)                ; 2b1c
	dec a                       ; 2b1f
	jp m,L2b5a                  ; 2b20
	jp z,L2b36                  ; 2b23
	dec (ix+3)                  ; 2b26
	jp m,L27e9                  ; 2b29
	dec (ix+5)                  ; 2b2c
	dec (ix+5)                  ; 2b2f
	dec (ix+4)                  ; 2b32
	ret                         ; 2b35
L2b36:
	dec (ix+17)                 ; 2b36
	bit 0,(ix+17)               ; 2b39
	jp z,L2b43                  ; 2b3d
	dec (ix+3)                  ; 2b40
L2b43:
	inc (ix+4)                  ; 2b43
	inc (ix+4)                  ; 2b46
	dec (ix+5)                  ; 2b49
	dec (ix+5)                  ; 2b4c
	ld a,(ix+4)                 ; 2b4f
	cp $12                      ; 2b52
	ret c                       ; 2b54
	ld (ix+16),$02              ; 2b55
	ret                         ; 2b59
L2b5a:
	inc (ix+5)                  ; 2b5a
	inc (ix+5)                  ; 2b5d
	ld a,(ix+5)                 ; 2b60
	cp $32                      ; 2b63
	ret c                       ; 2b65
	ld (ix+16),$01              ; 2b66
	ret                         ; 2b6a
L2b6b:
	ld a,(ix+16)                ; 2b6b
	dec a                       ; 2b6e
	jp m,L2b8f                  ; 2b6f
	jp z,L2b7e                  ; 2b72
	dec (ix+3)                  ; 2b75
	ret p                       ; 2b78
	ld (ix+0),$00               ; 2b79
	ret                         ; 2b7d
L2b7e:
	inc (ix+4)                  ; 2b7e
	inc (ix+4)                  ; 2b81
	ld a,(ix+4)                 ; 2b84
	cp $14                      ; 2b87
	ret c                       ; 2b89
	ld (ix+16),$02              ; 2b8a
	ret                         ; 2b8e
L2b8f:
	dec (ix+4)                  ; 2b8f
	ret p                       ; 2b92
	inc (ix+4)                  ; 2b93
	ld (ix+16),$01              ; 2b96
	jp L3eb6                    ; 2b9a
L2b9d:
	ld a,(ix+5)                 ; 2b9d
	cp $1a                      ; 2ba0
	jp z,L2bb1                  ; 2ba2
	jp c,L2bae                  ; 2ba5
	dec (ix+5)                  ; 2ba8
	jp L2bb1                    ; 2bab
L2bae:
	inc (ix+5)                  ; 2bae
L2bb1:
	dec (ix+17)                 ; 2bb1
	bit 0,(ix+17)               ; 2bb4
	ret z                       ; 2bb8
	dec (ix+3)                  ; 2bb9
	jp m,L27e9                  ; 2bbc
	ld a,(ix+3)                 ; 2bbf
	cp $14                      ; 2bc2
	ret nz                      ; 2bc4
	jp L3eb6                    ; 2bc5
L2bc8:
	ld a,(ix+16)                ; 2bc8
	dec a                       ; 2bcb
	jp m,L2bf3                  ; 2bcc
	jp z,L2be0                  ; 2bcf
	inc (ix+3)                  ; 2bd2
	ld a,(ix+3)                 ; 2bd5
	cp $1e                      ; 2bd8
	ret c                       ; 2bda
	ld (ix+0),$00               ; 2bdb
	ret                         ; 2bdf
L2be0:
	dec (ix+4)                  ; 2be0
	dec (ix+4)                  ; 2be3
	ld a,(ix+4)                 ; 2be6
	cp $07                      ; 2be9
	ret nc                      ; 2beb
	ld (ix+16),$02              ; 2bec
	jp L3eb6                    ; 2bf0
L2bf3:
	dec (ix+3)                  ; 2bf3
	ld a,(ix+3)                 ; 2bf6
	cp $09                      ; 2bf9
	ret nc                      ; 2bfb
	ld (ix+16),$01              ; 2bfc
	jp L3eb6                    ; 2c00
L2c03:
	ld a,(ix+16)                ; 2c03
	dec a                       ; 2c06
	jp m,L2c1c                  ; 2c07
	jp z,L2c2d                  ; 2c0a
	inc (ix+5)                  ; 2c0d
	inc (ix+5)                  ; 2c10
	ld a,(ix+5)                 ; 2c13
	cp $3c                      ; 2c16
	ret c                       ; 2c18
	jp L27e9                    ; 2c19
L2c1c:
	inc (ix+5)                  ; 2c1c
	inc (ix+5)                  ; 2c1f
	ld a,(ix+5)                 ; 2c22
	cp $28                      ; 2c25
	ret c                       ; 2c27
	ld (ix+16),$01              ; 2c28
	ret                         ; 2c2c
L2c2d:
	dec (ix+5)                  ; 2c2d
	jp m,L2c3c                  ; 2c30
	dec (ix+3)                  ; 2c33
	ld a,(ix+3)                 ; 2c36
	cp $03                      ; 2c39
	ret nc                      ; 2c3b
L2c3c:
	inc (ix+5)                  ; 2c3c
	ld (ix+16),$02              ; 2c3f
	ret                         ; 2c43
L2c44:
	ld a,(ix+16)                ; 2c44
	dec a                       ; 2c47
	jp m,L2c80                  ; 2c48
	jp z,L2c90                  ; 2c4b
	sub $02                     ; 2c4e
	jp m,L2c9f                  ; 2c50
	jp z,L2c73                  ; 2c53
	sub $02                     ; 2c56
	jp m,L2c80                  ; 2c58
	jp z,L2c90                  ; 2c5b
	sub $02                     ; 2c5e
	jp m,L2caa                  ; 2c60
	jp z,L2c73                  ; 2c63
	dec a                       ; 2c66
	jp z,L2c80                  ; 2c67
	dec (ix+3)                  ; 2c6a
	ret p                       ; 2c6d
	ld (ix+0),$00               ; 2c6e
	ret                         ; 2c72
L2c73:
	dec (ix+4)                  ; 2c73
	ret p                       ; 2c76
	inc (ix+4)                  ; 2c77
	inc (ix+16)                 ; 2c7a
	jp L3eb6                    ; 2c7d
L2c80:
	inc (ix+4)                  ; 2c80
	inc (ix+4)                  ; 2c83
	ld a,(ix+4)                 ; 2c86
	cp $14                      ; 2c89
	ret c                       ; 2c8b
	inc (ix+16)                 ; 2c8c
	ret                         ; 2c8f
L2c90:
	dec (ix+3)                  ; 2c90
	dec (ix+17)                 ; 2c93
	ret p                       ; 2c96
	ld (ix+17),$06              ; 2c97
	inc (ix+16)                 ; 2c9b
	ret                         ; 2c9e
L2c9f:
	dec (ix+5)                  ; 2c9f
	ret p                       ; 2ca2
	inc (ix+5)                  ; 2ca3
	inc (ix+16)                 ; 2ca6
	ret                         ; 2ca9
L2caa:
	inc (ix+5)                  ; 2caa
	ld a,(ix+5)                 ; 2cad
	cp $1a                      ; 2cb0
	ret c                       ; 2cb2
	ld (ix+16),$07              ; 2cb3
	ret                         ; 2cb7
L2cb8:
	ld a,(ix+16)                ; 2cb8
	dec a                       ; 2cbb
	jp m,L2cd2                  ; 2cbc
	jp z,L2ced                  ; 2cbf
	dec (ix+3)                  ; 2cc2
	jp m,L27e9                  ; 2cc5
	dec (ix+5)                  ; 2cc8
	dec (ix+5)                  ; 2ccb
	jp m,L27e9                  ; 2cce
	ret                         ; 2cd1
L2cd2:
	dec (ix+5)                  ; 2cd2
	dec (ix+5)                  ; 2cd5
	jp p,L2cdf                  ; 2cd8
	ld (ix+5),$00               ; 2cdb
L2cdf:
	inc (ix+3)                  ; 2cdf
	ld a,(ix+3)                 ; 2ce2
	cp $0f                      ; 2ce5
	ret c                       ; 2ce7
	ld (ix+16),$01              ; 2ce8
	ret                         ; 2cec
L2ced:
	inc (ix+5)                  ; 2ced
	inc (ix+5)                  ; 2cf0
	ld a,(ix+5)                 ; 2cf3
	cp $38                      ; 2cf6
	ret c                       ; 2cf8
	ld (ix+16),$02              ; 2cf9
	ret                         ; 2cfd
L2cfe:
	ld a,(ix+16)                ; 2cfe
	dec a                       ; 2d01
	jp m,L2d15                  ; 2d02
	jp z,L2d35                  ; 2d05
	dec (ix+3)                  ; 2d08
	jp m,L27e9                  ; 2d0b
	inc (ix+5)                  ; 2d0e
	inc (ix+5)                  ; 2d11
	ret                         ; 2d14
L2d15:
	inc (ix+5)                  ; 2d15
	inc (ix+5)                  ; 2d18
	ld a,(ix+5)                 ; 2d1b
	cp $3c                      ; 2d1e
	jp c,L2d27                  ; 2d20
	ld (ix+5),$3c               ; 2d23
L2d27:
	inc (ix+3)                  ; 2d27
	ld a,(ix+3)                 ; 2d2a
	cp $0f                      ; 2d2d
	ret c                       ; 2d2f
	ld (ix+16),$01              ; 2d30
	ret                         ; 2d34
L2d35:
	dec (ix+5)                  ; 2d35
	dec (ix+5)                  ; 2d38
	ret p                       ; 2d3b
	ld (ix+5),$00               ; 2d3c
	ld (ix+16),$02              ; 2d40
	ret                         ; 2d44
	dec (ix+17)                 ; 2d45
	ret p                       ; 2d48
	ld (ix+17),$07              ; 2d49
	ret                         ; 2d4d
L2d4e:
	ld a,(ix+16)                ; 2d4e
	dec a                       ; 2d51
	jp m,L2d6f                  ; 2d52
	jp z,L2d9a                  ; 2d55
	dec a                       ; 2d58
	jp z,L2d83                  ; 2d59
	dec a                       ; 2d5c
	jp z,L2d9a                  ; 2d5d
	inc (ix+5)                  ; 2d60
	inc (ix+5)                  ; 2d63
	dec (ix+3)                  ; 2d66
	ret p                       ; 2d69
	ld (ix+0),$00               ; 2d6a
	ret                         ; 2d6e
L2d6f:
	dec (ix+3)                  ; 2d6f
	ld a,(ix+3)                 ; 2d72
	cp $0f                      ; 2d75
	ret nc                      ; 2d77
	ld (ix+16),$01              ; 2d78
	ld (ix+17),$08              ; 2d7c
	jp L3eb6                    ; 2d80
L2d83:
	dec (ix+5)                  ; 2d83
	dec (ix+5)                  ; 2d86
	ld a,(ix+5)                 ; 2d89
	cp $06                      ; 2d8c
	ret nc                      ; 2d8e
	ld (ix+16),$03              ; 2d8f
	ld (ix+17),$08              ; 2d93
	jp L3eb6                    ; 2d97
L2d9a:
	dec (ix+17)                 ; 2d9a
	ret p                       ; 2d9d
	inc (ix+16)                 ; 2d9e
	ret                         ; 2da1
L2da2:
	ld a,(ix+16)                ; 2da2
	dec a                       ; 2da5
	jp m,L2d6f                  ; 2da6
	jp z,L2d9a                  ; 2da9
	dec a                       ; 2dac
	jp z,L2dc3                  ; 2dad
	dec a                       ; 2db0
	jp z,L2d9a                  ; 2db1
	dec (ix+5)                  ; 2db4
	dec (ix+5)                  ; 2db7
	dec (ix+3)                  ; 2dba
	ret p                       ; 2dbd
	ld (ix+0),$00               ; 2dbe
	ret                         ; 2dc2
L2dc3:
	inc (ix+5)                  ; 2dc3
	inc (ix+5)                  ; 2dc6
	ld a,(ix+5)                 ; 2dc9
	cp $2d                      ; 2dcc
	ret c                       ; 2dce
	ld (ix+16),$03              ; 2dcf
	ld (ix+17),$08              ; 2dd3
	jp L3eb6                    ; 2dd7
L2dda:
	ld a,(ix+16)                ; 2dda
	dec a                       ; 2ddd
	jp m,L2dfe                  ; 2dde
	jp z,L2e0b                  ; 2de1
	sub $02                     ; 2de4
	jp m,L2e19                  ; 2de6
	jp z,L2e26                  ; 2de9
	sub $02                     ; 2dec
	jp m,L2e0b                  ; 2dee
	jp z,L2e19                  ; 2df1
	dec (ix+3)                  ; 2df4
	jp m,L27e9                  ; 2df7
	dec (ix+5)                  ; 2dfa
	ret                         ; 2dfd
L2dfe:
	dec (ix+3)                  ; 2dfe
	ld a,(ix+3)                 ; 2e01
	cp $0f                      ; 2e04
	ret nc                      ; 2e06
	inc (ix+16)                 ; 2e07
	ret                         ; 2e0a
L2e0b:
	dec (ix+4)                  ; 2e0b
	ret p                       ; 2e0e
	ld (ix+4),$00               ; 2e0f
	inc (ix+16)                 ; 2e13
	jp L3eb6                    ; 2e16
L2e19:
	inc (ix+4)                  ; 2e19
	ld a,(ix+4)                 ; 2e1c
	cp $0f                      ; 2e1f
	ret c                       ; 2e21
	inc (ix+16)                 ; 2e22
	ret                         ; 2e25
L2e26:
	inc (ix+5)                  ; 2e26
	inc (ix+5)                  ; 2e29
	inc (ix+5)                  ; 2e2c
	dec (ix+3)                  ; 2e2f
	ld a,(ix+3)                 ; 2e32
	cp $08                      ; 2e35
	ret nc                      ; 2e37
	inc (ix+16)                 ; 2e38
	ret                         ; 2e3b
L2e3c:
	ld a,(ix+16)                ; 2e3c
	dec a                       ; 2e3f
	jp m,L2dfe                  ; 2e40
	jp z,L2e0b                  ; 2e43
	sub $02                     ; 2e46
	jp m,L2e19                  ; 2e48
	jp z,L2e60                  ; 2e4b
	sub $02                     ; 2e4e
	jp m,L2e0b                  ; 2e50
	jp z,L2e19                  ; 2e53
	dec (ix+3)                  ; 2e56
	jp m,L27e9                  ; 2e59
	inc (ix+5)                  ; 2e5c
	ret                         ; 2e5f
L2e60:
	dec (ix+5)                  ; 2e60
	dec (ix+5)                  ; 2e63
	dec (ix+5)                  ; 2e66
	dec (ix+3)                  ; 2e69
	ld a,(ix+3)                 ; 2e6c
	cp $08                      ; 2e6f
	ret nc                      ; 2e71
	inc (ix+16)                 ; 2e72
	ret                         ; 2e75
L2e76:
	and $1f                     ; 2e76
	add a,a                     ; 2e78
	ld e,a                      ; 2e79
	ld d,$00                    ; 2e7a
	ld hl,L2e84                 ; 2e7c
	add hl,de                   ; 2e7f
	ld e,(hl)                   ; 2e80
	inc hl                      ; 2e81
	ld d,(hl)                   ; 2e82
	ret                         ; 2e83
L2e84:
	db $f9,$00,$fa,$01,$fb,$02,$fc,$03,$fd,$04,$fe,$05,$ff,$06,$00,$07; 2e84
	db $01,$06,$02,$05,$03,$04,$04,$03,$05,$02,$06,$01,$07,$00,$07,$00; 2e94
	db $07,$00,$06,$ff,$05,$fe,$04,$fd,$03,$fc,$02,$fb,$01,$fa,$00,$f9; 2ea4
	db $ff,$fa,$fe,$fb,$fd,$fc,$fc,$fd,$fb,$fe,$fa,$ff,$f9,$00,$f9,$00; 2eb4
	db $00,$00,$00,$00,$00,$00,$00,$00; 2ec4
L2ecc:
	ld a,(ix+17)                ; 2ecc
	call L2e76                  ; 2ecf
	ld a,d                      ; 2ed2
	add a,$16                   ; 2ed3
	ld (ix+5),a                 ; 2ed5
	ld a,e                      ; 2ed8
	add a,$07                   ; 2ed9
	ld (ix+4),a                 ; 2edb
	ret                         ; 2ede
L2edf:
	ld (ix+8),$00               ; 2edf
	ld (ix+12),$00              ; 2ee3
	ld a,(ix+16)                ; 2ee7
	dec a                       ; 2eea
	jp m,L2f19                  ; 2eeb
	jp nz,L2f0b                 ; 2eee
	call L2ecc                  ; 2ef1
	inc (ix+19)                 ; 2ef4
	ld a,(ix+19)                ; 2ef7
	and $07                     ; 2efa
	jp z,L3eb6                  ; 2efc
	inc (ix+17)                 ; 2eff
	dec (ix+20)                 ; 2f02
	ret p                       ; 2f05
	ld (ix+16),$02              ; 2f06
	ret                         ; 2f0a
L2f0b:
	inc (ix+3)                  ; 2f0b
	ld a,(ix+3)                 ; 2f0e
	cp $1f                      ; 2f11
	ret c                       ; 2f13
	ld (ix+0),$00               ; 2f14
	ret                         ; 2f18
L2f19:
	dec (ix+3)                  ; 2f19
	ld a,(ix+3)                 ; 2f1c
	cp $0c                      ; 2f1f
	ret nc                      ; 2f21
	ld (ix+16),$01              ; 2f22
	ld (ix+19),$00              ; 2f26
	ld (ix+20),$20              ; 2f2a
	ld (ix+17),$18              ; 2f2e
	ld a,(ix+6)                 ; 2f32
	or a                        ; 2f35
	ret nz                      ; 2f36
	ld (ix+17),$08              ; 2f37
	ret                         ; 2f3b
L2f3c:
	call L2d4e                  ; 2f3c
	ld a,(ix+16)                ; 2f3f
	sub $02                     ; 2f42
	jp z,L2f4c                  ; 2f44
	ld (ix+4),$10               ; 2f47
	ret                         ; 2f4b
L2f4c:
	dec (ix+20)                 ; 2f4c
	ld a,(ix+20)                ; 2f4f
	and $0f                     ; 2f52
	cp $08                      ; 2f54
	jp c,L2f65                  ; 2f56
	dec (ix+4)                  ; 2f59
	dec (ix+4)                  ; 2f5c
	ret p                       ; 2f5f
	ld (ix+4),$00               ; 2f60
	ret                         ; 2f64
L2f65:
	inc (ix+4)                  ; 2f65
	inc (ix+4)                  ; 2f68
	ld a,(ix+4)                 ; 2f6b
	cp $10                      ; 2f6e
	ret c                       ; 2f70
	ld (ix+4),$10               ; 2f71
	ret                         ; 2f75
L2f76:
	call L2da2                  ; 2f76
	ld a,(ix+16)                ; 2f79
	sub $02                     ; 2f7c
	jp z,L2f4c                  ; 2f7e
	ld (ix+4),$10               ; 2f81
	ret                         ; 2f85
L2f86:
	ld (ix+12),$00              ; 2f86
	ld a,(ix+16)                ; 2f8a
	add a,a                     ; 2f8d
	ld e,a                      ; 2f8e
	ld d,$00                    ; 2f8f
	ld hl,L2f9a                 ; 2f91
	add hl,de                   ; 2f94
	ld e,(hl)                   ; 2f95
	inc hl                      ; 2f96
	ld d,(hl)                   ; 2f97
	ex de,hl                    ; 2f98
	jp (hl)                     ; 2f99
L2f9a:
	dw L2fff                    ; 2f9a
	dw L2fba                    ; 2f9c
	dw L2fcb                    ; 2f9e
	dw L2ff7                    ; 2fa0
	dw L2fdd                    ; 2fa2
	dw L2ff7                    ; 2fa4
	dw L2fba                    ; 2fa6
	dw L2fcb                    ; 2fa8
	dw L2ff7                    ; 2faa
	dw L2fdd                    ; 2fac
	dw L2ff7                    ; 2fae
	dw L2fba                    ; 2fb0
	dw L2fcb                    ; 2fb2
	dw L2ff7                    ; 2fb4
	dw L2fdd                    ; 2fb6
	dw L3020                    ; 2fb8
L2fba:
	rlc (ix+18)                 ; 2fba
	ret c                       ; 2fbe
	dec (ix+6)                  ; 2fbf
	ret nz                      ; 2fc2
	inc (ix+16)                 ; 2fc3
	ld (ix+17),$04              ; 2fc6
	ret                         ; 2fca
L2fcb:
	ld (ix+8),$00               ; 2fcb
	dec (ix+17)                 ; 2fcf
	ret p                       ; 2fd2
	inc (ix+16)                 ; 2fd3
	ld (ix+17),$0b              ; 2fd6
	jp L3eb6                    ; 2fda
L2fdd:
	ld (ix+8),$02               ; 2fdd
	rlc (ix+18)                 ; 2fe1
	ret c                       ; 2fe5
	inc (ix+6)                  ; 2fe6
	ld a,(ix+6)                 ; 2fe9
	cp $03                      ; 2fec
	ret c                       ; 2fee
	inc (ix+16)                 ; 2fef
	ld (ix+17),$10              ; 2ff2
	ret                         ; 2ff6
L2ff7:
	dec (ix+17)                 ; 2ff7
	ret p                       ; 2ffa
	inc (ix+16)                 ; 2ffb
	ret                         ; 2ffe
L2fff:
	ld (ix+8),$02               ; 2fff
	ld c,$08                    ; 3003
	ld a,(WRK+$062)             ; 3005
	cp $07                      ; 3008
	jp c,L300f                  ; 300a
	ld c,$06                    ; 300d
L300f:
	dec (ix+3)                  ; 300f
	ld a,(ix+3)                 ; 3012
	cp c                        ; 3015
	ret nc                      ; 3016
	ld (ix+18),$ee              ; 3017
	ld (ix+16),$01              ; 301b
	ret                         ; 301f
L3020:
	inc (ix+3)                  ; 3020
	ld a,(ix+3)                 ; 3023
	cp $1f                      ; 3026
	ret c                       ; 3028
	ld (ix+0),$00               ; 3029
	ret                         ; 302d
L302e:
	ld a,(ix+16)                ; 302e
	dec a                       ; 3031
	jp m,L3042                  ; 3032
	jp z,L3052                  ; 3035
	inc (ix+5)                  ; 3038
	dec (ix+3)                  ; 303b
	ret p                       ; 303e
	jp L27e9                    ; 303f
L3042:
	inc (ix+5)                  ; 3042
	inc (ix+3)                  ; 3045
	ld a,(ix+3)                 ; 3048
	cp $10                      ; 304b
	ret c                       ; 304d
	inc (ix+16)                 ; 304e
	ret                         ; 3051
L3052:
	dec (ix+5)                  ; 3052
	ld a,(ix+5)                 ; 3055
	cp $08                      ; 3058
	ret nc                      ; 305a
	inc (ix+16)                 ; 305b
	ret                         ; 305e
L305f:
	ld a,(ix+16)                ; 305f
	or a                        ; 3062
	jp z,L306f                  ; 3063
	dec (ix+4)                  ; 3066
	ret p                       ; 3069
	ld (ix+0),$00               ; 306a
	ret                         ; 306e
L306f:
	dec (ix+3)                  ; 306f
	dec (ix+3)                  ; 3072
	ld a,(ix+3)                 ; 3075
	cp $04                      ; 3078
	jp nc,L3083                 ; 307a
	inc (ix+16)                 ; 307d
	jp L3eb6                    ; 3080
L3083:
	ld a,(ix+5)                 ; 3083
	cp $1a                      ; 3086
	ret z                       ; 3088
	jp c,L3090                  ; 3089
	dec (ix+5)                  ; 308c
	ret                         ; 308f
L3090:
	inc (ix+5)                  ; 3090
	ret                         ; 3093
L3094:
	ret                         ; 3094
L3095:
	ld b,$08                    ; 3095
	ld de,$0018                 ; 3097
	ld iy,WRK+$079              ; 309a
	ld hl,WRK+$085              ; 309e
	jp L30bc                    ; 30a1
L30a4:
	ld b,$04                    ; 30a4
	ld de,$0018                 ; 30a6
	ld iy,WRK+$079              ; 30a9
	ld hl,WRK+$085              ; 30ad
	call L30bc                  ; 30b0
	ld b,$04                    ; 30b3
	ld iy,WRK+$0d9              ; 30b5
	ld hl,WRK+$0e5              ; 30b9
L30bc:
	ld a,(iy+0)                 ; 30bc
	cp $0b                      ; 30bf
	jr z,L30d3                  ; 30c1
	cp $0e                      ; 30c3
	jr z,L30d3                  ; 30c5
	cp $14                      ; 30c7
	jr z,L30d3                  ; 30c9
	cp $15                      ; 30cb
	jr z,L30d3                  ; 30cd
	cp $0c                      ; 30cf
	jr nz,L30d9                 ; 30d1
L30d3:
	ld a,(hl)                   ; 30d3
	sra a                       ; 30d4
	ld (iy+6),a                 ; 30d6
L30d9:
	add iy,de                   ; 30d9
	djnz L30bc                  ; 30db
	ld a,$01                    ; 30dd
	ld (WRK+$25d),a             ; 30df
	ret                         ; 30e2
L30e3:
	ld c,$15                    ; 30e3
	jr L30e9                    ; 30e5
L30e7:
	ld c,$0c                    ; 30e7
L30e9:
	ld b,$07                    ; 30e9
	ld iy,WRK+$079              ; 30eb
	ld a,(iy+0)                 ; 30ef
	or a                        ; 30f2
	ret nz                      ; 30f3
	ld iy,WRK+$091              ; 30f4
L30f8:
	ld de,$0018                 ; 30f8
	ld a,(iy+0)                 ; 30fb
	or a                        ; 30fe
	jp z,L311e                  ; 30ff
	cp $02                      ; 3102
	jp z,L311e                  ; 3104
	cp c                        ; 3107
	jp nz,L311e                 ; 3108
	ld a,$05                    ; 310b
	sub b                       ; 310d
	add a,a                     ; 310e
	ld (iy+7),a                 ; 310f
	ld (iy+0),$02               ; 3112
	ld (iy+11),$2f              ; 3116
	ld (iy+6),$03               ; 311a
L311e:
	add iy,de                   ; 311e
	djnz L30f8                  ; 3120
	ret                         ; 3122
L3123:
	ld iy,WRK+$079              ; 3123
	call L312e                  ; 3127
	ld iy,WRK+$0d9              ; 312a
L312e:
	ld a,(iy+0)                 ; 312e
	cp $0e                      ; 3131
	ret z                       ; 3133
	cp $14                      ; 3134
	ret z                       ; 3136
	ld de,$0018                 ; 3137
	ld b,$04                    ; 313a
L313c:
	ld a,(iy+0)                 ; 313c
	cp $0c                      ; 313f
	jr z,L3147                  ; 3141
	cp $15                      ; 3143
	jr nz,L315a                 ; 3145
L3147:
	ld (iy+0),$02               ; 3147
	ld (iy+11),$2f              ; 314b
	ld (iy+6),$03               ; 314f
	ld a,$03                    ; 3153
	sub b                       ; 3155
	add a,a                     ; 3156
	ld (iy+7),a                 ; 3157
L315a:
	add iy,de                   ; 315a
	djnz L313c                  ; 315c
	ret                         ; 315e
L315f:
	ld iy,WRK+$079              ; 315f
	call L316a                  ; 3163
	ld iy,WRK+$0d9              ; 3166
L316a:
	ld a,(iy+0)                 ; 316a
	cp $2c                      ; 316d
	ret z                       ; 316f
	ld de,$0018                 ; 3170
	ld b,$04                    ; 3173
L3175:
	ld a,(iy+0)                 ; 3175
	cp $2d                      ; 3178
	jr nz,L318f                 ; 317a
	ld (iy+0),$02               ; 317c
	ld (iy+11),$2f              ; 3180
	ld (iy+6),$03               ; 3184
	ld a,$03                    ; 3188
	sub b                       ; 318a
	add a,a                     ; 318b
	ld (iy+7),a                 ; 318c
L318f:
	add iy,de                   ; 318f
	djnz L3175                  ; 3191
	ret                         ; 3193
L3194:
	ld (ix+12),$00              ; 3194
	ld a,(ix+16)                ; 3198
	dec a                       ; 319b
	jp m,L31bc                  ; 319c
	jp z,L31d1                  ; 319f
	sub $02                     ; 31a2
	jp m,L31e4                  ; 31a4
	jp z,L31f8                  ; 31a7
	dec a                       ; 31aa
	jp z,L31e4                  ; 31ab
	inc (ix+3)                  ; 31ae
	ld a,(ix+3)                 ; 31b1
	cp $1f                      ; 31b4
	ret c                       ; 31b6
	ld (ix+0),$00               ; 31b7
	ret                         ; 31bb
L31bc:
	ld (ix+8),$02               ; 31bc
	dec (ix+3)                  ; 31c0
	ld a,(ix+3)                 ; 31c3
	cp $04                      ; 31c6
	ret nc                      ; 31c8
	inc (ix+16)                 ; 31c9
	ld (ix+17),$14              ; 31cc
	ret                         ; 31d0
L31d1:
	dec (ix+17)                 ; 31d1
	ret p                       ; 31d4
	inc (ix+3)                  ; 31d5
	ld a,(ix+3)                 ; 31d8
	cp $0d                      ; 31db
	ret c                       ; 31dd
	inc (ix+16)                 ; 31de
	jp L3eb6                    ; 31e1
L31e4:
	call L320d                  ; 31e4
	dec (ix+5)                  ; 31e7
	dec (ix+5)                  ; 31ea
	ret p                       ; 31ed
	ld (ix+5),$00               ; 31ee
	inc (ix+16)                 ; 31f2
	jp L3eb6                    ; 31f5
L31f8:
	call L320d                  ; 31f8
	inc (ix+5)                  ; 31fb
	inc (ix+5)                  ; 31fe
	ld a,(ix+5)                 ; 3201
	cp $3c                      ; 3204
	ret c                       ; 3206
	inc (ix+16)                 ; 3207
	jp L3eb6                    ; 320a
L320d:
	ld (ix+12),$00              ; 320d
	dec (ix+22)                 ; 3211
	ld a,(ix+22)                ; 3214
	and $07                     ; 3217
	ld (ix+8),$02               ; 3219
	ld (ix+6),$00               ; 321d
	cp $04                      ; 3221
	ret c                       ; 3223
	ld (ix+8),$00               ; 3224
	ld (ix+6),$01               ; 3228
	ret                         ; 322c
L322d:
	ld a,(WRK+$25c)             ; 322d
	cp $01                      ; 3230
	jr nz,L3239                 ; 3232
	call L30e7                  ; 3234
	jr L323c                    ; 3237
L3239:
	call L30e3                  ; 3239
L323c:
	ld a,(WRK+$25d)             ; 323c
	or a                        ; 323f
	call z,L3095                ; 3240
	dec (ix+20)                 ; 3243
	ld a,(ix+20)                ; 3246
	and $01                     ; 3249
	jr z,L3268                  ; 324b
	ld a,(ix+16)                ; 324d
	add a,(ix+3)                ; 3250
	ld (ix+3),a                 ; 3253
	cp $1e                      ; 3256
	jp nc,L3260                 ; 3258
	cp $03                      ; 325b
	jp nc,L3268                 ; 325d
L3260:
	ld a,(ix+16)                ; 3260
	neg                         ; 3263
	ld (ix+16),a                ; 3265
L3268:
	dec (ix+18)                 ; 3268
	ld a,(ix+18)                ; 326b
	and $0f                     ; 326e
	cp $08                      ; 3270
	ld a,$02                    ; 3272
	jp c,L3279                  ; 3274
	ld a,$fe                    ; 3277
L3279:
	add a,(ix+5)                ; 3279
	ld (ix+5),a                 ; 327c
	ld a,(ix+17)                ; 327f
	add a,(ix+4)                ; 3282
	add a,(ix+17)               ; 3285
	ld (ix+4),a                 ; 3288
	jp p,L3299                  ; 328b
	ld (ix+4),$00               ; 328e
	ld (ix+17),$01              ; 3292
	jp L32a2                    ; 3296
L3299:
	cp $14                      ; 3299
	jp c,L32a2                  ; 329b
	ld (ix+17),$ff              ; 329e
L32a2:
	ld a,(ix+19)                ; 32a2
	or a                        ; 32a5
	ret z                       ; 32a6
	ld a,(ix+16)                ; 32a7
	or a                        ; 32aa
	ret p                       ; 32ab
	ld a,(ix+3)                 ; 32ac
	cp $14                      ; 32af
	jp z,L3eb6                  ; 32b1
	cp $0a                      ; 32b4
	jp z,L3eb6                  ; 32b6
	ret                         ; 32b9
L32ba:
	ld a,(ix+19)                ; 32ba
	or a                        ; 32bd
	ret z                       ; 32be
	push ix                     ; 32bf
	pop iy                      ; 32c1
	ld b,$04                    ; 32c3
	ld de,$0018                 ; 32c5
L32c8:
	ld a,(iy+11)                ; 32c8
	cp $12                      ; 32cb
	jp nz,L32d8                 ; 32cd
	ld a,(iy+16)                ; 32d0
	neg                         ; 32d3
	ld (iy+16),a                ; 32d5
L32d8:
	add iy,de                   ; 32d8
	djnz L32c8                  ; 32da
	ret                         ; 32dc
L32dd:
	call L3123                  ; 32dd
	ld a,(WRK+$25d)             ; 32e0
	or a                        ; 32e3
	call z,L30a4                ; 32e4
	dec (ix+20)                 ; 32e7
	bit 0,(ix+20)               ; 32ea
	ret z                       ; 32ee
	ld a,(ix+3)                 ; 32ef
	add a,(ix+16)               ; 32f2
	ld (ix+3),a                 ; 32f5
	cp $1c                      ; 32f8
	jp nc,L3302                 ; 32fa
	cp $03                      ; 32fd
	jp nc,L3305                 ; 32ff
L3302:
	call L32ba                  ; 3302
L3305:
	dec (ix+17)                 ; 3305
	ld a,(ix+17)                ; 3308
	and $0f                     ; 330b
	cp $08                      ; 330d
	ld a,$01                    ; 330f
	jp c,L3316                  ; 3311
	ld a,$ff                    ; 3314
L3316:
	add a,(ix+4)                ; 3316
	ld (ix+4),a                 ; 3319
	jp L32a2                    ; 331c
L331f:
	ld a,(ix+16)                ; 331f
	add a,a                     ; 3322
	ld e,a                      ; 3323
	ld d,$00                    ; 3324
	ld hl,L332f                 ; 3326
	add hl,de                   ; 3329
	ld e,(hl)                   ; 332a
	inc hl                      ; 332b
	ld d,(hl)                   ; 332c
	ex de,hl                    ; 332d
	jp (hl)                     ; 332e
L332f:
	dw L3343                    ; 332f
	dw L3366                    ; 3331
	dw L3386                    ; 3333
	dw L3366                    ; 3335
	dw L3386                    ; 3337
	dw L3366                    ; 3339
	dw L3386                    ; 333b
	dw L3366                    ; 333d
	dw L3386                    ; 333f
	dw L3358                    ; 3341
L3343:
	ld (ix+8),$02               ; 3343
	dec (ix+3)                  ; 3347
	ld a,(ix+3)                 ; 334a
	cp $08                      ; 334d
	ret nc                      ; 334f
	inc (ix+16)                 ; 3350
	ld (ix+17),$0a              ; 3353
	ret                         ; 3357
L3358:
	inc (ix+3)                  ; 3358
	ld a,(ix+3)                 ; 335b
	cp $1e                      ; 335e
	ret c                       ; 3360
	ld (ix+0),$00               ; 3361
	ret                         ; 3365
L3366:
	ld (ix+3),$07               ; 3366
	ld (ix+6),$00               ; 336a
	ld (ix+8),$00               ; 336e
	inc (ix+4)                  ; 3372
	inc (ix+5)                  ; 3375
	dec (ix+17)                 ; 3378
	ret p                       ; 337b
	inc (ix+16)                 ; 337c
	ld (ix+17),$0a              ; 337f
	jp L3eb6                    ; 3383
L3386:
	ld (ix+3),$0a               ; 3386
	ld (ix+6),$03               ; 338a
	ld (ix+8),$02               ; 338e
	dec (ix+4)                  ; 3392
	dec (ix+5)                  ; 3395
	dec (ix+17)                 ; 3398
	ret p                       ; 339b
	inc (ix+16)                 ; 339c
	ld (ix+17),$0a              ; 339f
	ret                         ; 33a3
L33a4:
	ld a,(ix+16)                ; 33a4
	add a,a                     ; 33a7
	ld e,a                      ; 33a8
	ld d,$00                    ; 33a9
	ld hl,L33b4                 ; 33ab
	add hl,de                   ; 33ae
	ld e,(hl)                   ; 33af
	inc hl                      ; 33b0
	ld d,(hl)                   ; 33b1
	ex de,hl                    ; 33b2
	jp (hl)                     ; 33b3
L33b4:
	dw L3343                    ; 33b4
	dw L33c8                    ; 33b6
	dw L33e8                    ; 33b8
	dw L33c8                    ; 33ba
	dw L33e8                    ; 33bc
	dw L33c8                    ; 33be
	dw L33e8                    ; 33c0
	dw L33c8                    ; 33c2
	dw L33e8                    ; 33c4
	dw L3358                    ; 33c6
L33c8:
	ld (ix+3),$07               ; 33c8
	ld (ix+6),$00               ; 33cc
	ld (ix+8),$00               ; 33d0
	inc (ix+4)                  ; 33d4
	dec (ix+5)                  ; 33d7
	dec (ix+17)                 ; 33da
	ret p                       ; 33dd
	inc (ix+16)                 ; 33de
	ld (ix+17),$0a              ; 33e1
	jp L3eb6                    ; 33e5
L33e8:
	ld (ix+3),$0a               ; 33e8
	ld (ix+6),$03               ; 33ec
	ld (ix+8),$02               ; 33f0
	dec (ix+4)                  ; 33f4
	inc (ix+5)                  ; 33f7
	dec (ix+17)                 ; 33fa
	ret p                       ; 33fd
	inc (ix+16)                 ; 33fe
	ld (ix+17),$0a              ; 3401
	ret                         ; 3405
L3406:
	ld a,(ix+16)                ; 3406
	dec a                       ; 3409
	jp m,L341e                  ; 340a
	jp z,L3434                  ; 340d
	inc (ix+3)                  ; 3410
	ld a,(ix+3)                 ; 3413
	cp $1b                      ; 3416
	ret c                       ; 3418
	ld (ix+0),$00               ; 3419
	ret                         ; 341d
L341e:
	dec (ix+3)                  ; 341e
	ld a,(ix+3)                 ; 3421
	cp $08                      ; 3424
	ret nc                      ; 3426
	ld (ix+16),$01              ; 3427
	ld (ix+18),$00              ; 342b
	ld (ix+19),$7f              ; 342f
	ret                         ; 3433
L3434:
	dec (ix+19)                 ; 3434
	jp p,L343f                  ; 3437
	ld (ix+16),$02              ; 343a
	ret                         ; 343e
L343f:
	inc (ix+17)                 ; 343f
	ld a,(ix+17)                ; 3442
	call L2e76                  ; 3445
	sla d                       ; 3448
	sla e                       ; 344a
	ld a,$20                    ; 344c
	add a,d                     ; 344e
	ld (ix+5),a                 ; 344f
	ld a,$0e                    ; 3452
	add a,e                     ; 3454
	ld (ix+4),a                 ; 3455
	dec (ix+18)                 ; 3458
	ld a,(ix+18)                ; 345b
	and $1f                     ; 345e
	ld (ix+8),$02               ; 3460
	ld (ix+6),$03               ; 3464
	cp $10                      ; 3468
	ret nc                      ; 346a
	ld (ix+8),$00               ; 346b
	ld (ix+6),$00               ; 346f
	cp $07                      ; 3473
	ret nz                      ; 3475
	jp L3eb6                    ; 3476
L3479:
	ld hl,WRK+$091              ; 3479
	ld de,$0018                 ; 347c
	ld b,$08                    ; 347f
	xor a                       ; 3481
L3482:
	add a,(hl)                  ; 3482
	add hl,de                   ; 3483
	djnz L3482                  ; 3484
	or a                        ; 3486
	ret                         ; 3487
L3488:
	db $00                      ; 3488
L3489:
	db $00                      ; 3489
L348a:
	db $00                      ; 348a
L348b:
	ld a,(ix+3)                 ; 348b
	ld (L3488),a                ; 348e
	ld l,(ix+4)                 ; 3491
	ld h,(ix+5)                 ; 3494
	ld (L3489),hl               ; 3497
	ret                         ; 349a
L349b:
	ld a,(ix+3)                 ; 349b
	cp $0c                      ; 349e
	jr c,L34a7                  ; 34a0
	and $07                     ; 34a2
	call z,L3eb6                ; 34a4
L34a7:
	call L348b                  ; 34a7
	call L3479                  ; 34aa
	ld (ix+8),$00               ; 34ad
	jr z,L34b7                  ; 34b1
	ld (ix+8),$02               ; 34b3
L34b7:
	ld a,(ix+16)                ; 34b7
	dec a                       ; 34ba
	jp m,L34d3                  ; 34bb
	jp z,L34e0                  ; 34be
	dec a                       ; 34c1
	jp z,L34ed                  ; 34c2
	inc (ix+3)                  ; 34c5
	ld a,(ix+3)                 ; 34c8
	cp $1b                      ; 34cb
	ret c                       ; 34cd
	ld (ix+16),$00              ; 34ce
	ret                         ; 34d2
L34d3:
	inc (ix+5)                  ; 34d3
	ld a,(ix+5)                 ; 34d6
	cp $28                      ; 34d9
	ret c                       ; 34db
	inc (ix+16)                 ; 34dc
	ret                         ; 34df
L34e0:
	dec (ix+3)                  ; 34e0
	ld a,(ix+3)                 ; 34e3
	cp $08                      ; 34e6
	ret nc                      ; 34e8
	inc (ix+16)                 ; 34e9
	ret                         ; 34ec
L34ed:
	dec (ix+5)                  ; 34ed
	ld a,(ix+5)                 ; 34f0
	cp $0c                      ; 34f3
	ret nc                      ; 34f5
	inc (ix+16)                 ; 34f6
	ret                         ; 34f9
L34fa:
	ld a,(ix+16)                ; 34fa
	call L2e76                  ; 34fd
	ld a,(L3489)                ; 3500
	ld (ix+4),a                 ; 3503
	sra e                       ; 3506
	sla d                       ; 3508
	ld a,(L3488)                ; 350a
	add a,e                     ; 350d
	ld (ix+3),a                 ; 350e
	ld a,(L348a)                ; 3511
	add a,d                     ; 3514
	ld (ix+5),a                 ; 3515
	dec (ix+16)                 ; 3518
	ret                         ; 351b
L351c:
	ld a,(WRK+$079)             ; 351c
	cp $1b                      ; 351f
	jr z,L3528                  ; 3521
	ld (ix+0),$00               ; 3523
	ret                         ; 3527
L3528:
	ld a,(ix+16)                ; 3528
	or a                        ; 352b
	jp nz,L353c                 ; 352c
L352f:
	dec (ix+3)                  ; 352f
	ld a,(ix+3)                 ; 3532
	cp $07                      ; 3535
	ret nc                      ; 3537
	inc (ix+16)                 ; 3538
	ret                         ; 353b
L353c:
	dec (ix+17)                 ; 353c
	ld a,(ix+17)                ; 353f
	and $0f                     ; 3542
	ret nz                      ; 3544
	jp L3eb6                    ; 3545
L3548:
	ld a,r                      ; 3548
	and $1f                     ; 354a
	add a,$0c                   ; 354c
	ld (L3e48),a                ; 354e
	dec (ix+22)                 ; 3551
	ld a,(ix+22)                ; 3554
	and $03                     ; 3557
	jr z,L3581                  ; 3559
	call L3d70                  ; 355b
	jr c,L3581                  ; 355e
	push iy                     ; 3560
	pop de                      ; 3562
	ld hl,L3e43                 ; 3563
	ld bc,$0012                 ; 3566
	ldir                        ; 3569
	ld a,(ix+12)                ; 356b
	cp $0e                      ; 356e
	jr nc,L3581                 ; 3570
	ld a,r                      ; 3572
	and $01                     ; 3574
	jr z,L3581                  ; 3576
	ld a,r                      ; 3578
	and $07                     ; 357a
	add a,$07                   ; 357c
	ld (iy+4),a                 ; 357e
L3581:
	ld (ix+8),$00               ; 3581
	ld (ix+6),$01               ; 3585
	ld a,(ix+12)                ; 3589
	sra a                       ; 358c
	sra a                       ; 358e
	sra a                       ; 3590
	ld (ix+6),a                 ; 3592
	ld a,(ix+16)                ; 3595
	or a                        ; 3598
	ret nz                      ; 3599
	jp L352f                    ; 359a
L359d:
	ld a,(ix+16)                ; 359d
	dec a                       ; 35a0
	jp m,L35b9                  ; 35a1
	jp z,L35c8                  ; 35a4
	dec a                       ; 35a7
	jp z,L35b9                  ; 35a8
	inc (ix+3)                  ; 35ab
	ld a,(ix+3)                 ; 35ae
	cp $1f                      ; 35b1
	ret c                       ; 35b3
	ld (ix+0),$00               ; 35b4
	ret                         ; 35b8
L35b9:
	dec (ix+3)                  ; 35b9
	ld a,(ix+3)                 ; 35bc
	cp $08                      ; 35bf
	ret nc                      ; 35c1
	inc (ix+16)                 ; 35c2
	jp L3eb6                    ; 35c5
L35c8:
	inc (ix+3)                  ; 35c8
	ld a,(ix+3)                 ; 35cb
	cp $1e                      ; 35ce
	ret c                       ; 35d0
	inc (ix+16)                 ; 35d1
	ret                         ; 35d4
L35d5:
	call L348b                  ; 35d5
	ld a,(ix+16)                ; 35d8
	or a                        ; 35db
	jp nz,L35ec                 ; 35dc
	dec (ix+3)                  ; 35df
	ld a,(ix+3)                 ; 35e2
	cp $10                      ; 35e5
	ret nc                      ; 35e7
	inc (ix+16)                 ; 35e8
	ret                         ; 35eb
L35ec:
	dec (ix+22)                 ; 35ec
	ld a,(ix+22)                ; 35ef
	and $1f                     ; 35f2
	ret nz                      ; 35f4
	jp L3eb6                    ; 35f5
L35f8:
	db $fe                      ; 35f8
L35f9:
	ld a,(WRK+$079)             ; 35f9
	cp $0d                      ; 35fc
	jp z,L3617                  ; 35fe
	ld a,(WRK+$25d)             ; 3601
	or a                        ; 3604
	jp nz,L3617                 ; 3605
	ld hl,L35f8                 ; 3608
	rlc (hl)                    ; 360b
	jp c,L3617                  ; 360d
	ld (WRK+$25d),a             ; 3610
	ld hl,L3488                 ; 3613
	dec (hl)                    ; 3616
L3617:
	inc (ix+16)                 ; 3617
	ld a,(ix+16)                ; 361a
	call L2e76                  ; 361d
	inc (ix+17)                 ; 3620
	ld a,(ix+17)                ; 3623
	and $3f                     ; 3626
	cp $20                      ; 3628
	jp nc,L3632                 ; 362a
	sla d                       ; 362d
	jp L3634                    ; 362f
L3632:
	sra e                       ; 3632
L3634:
	ld a,(L348a)                ; 3634
	add a,d                     ; 3637
	ld (ix+5),a                 ; 3638
	ld a,(L3488)                ; 363b
	add a,e                     ; 363e
	ld (ix+3),a                 ; 363f
	jp m,L27e9                  ; 3642
	ret                         ; 3645
L3646:
	ld a,(ix+16)                ; 3646
	dec a                       ; 3649
	jp m,L3659                  ; 364a
	jp z,L3674                  ; 364d
	dec (ix+4)                  ; 3650
	ret p                       ; 3653
	ld (ix+0),$00               ; 3654
	ret                         ; 3658
L3659:
	dec (ix+3)                  ; 3659
	ld a,(ix+3)                 ; 365c
	cp $03                      ; 365f
	ret nc                      ; 3661
	inc (ix+16)                 ; 3662
	ld (ix+17),$5a              ; 3665
	ld (ix+22),$aa              ; 3669
	ld hl,L3e57                 ; 366d
	ld (L3db7),hl               ; 3670
	ret                         ; 3673
L3674:
	ld a,(ix+0)                 ; 3674
	cp $19                      ; 3677
	call z,L3d85                ; 3679
	rlc (ix+22)                 ; 367c
	ret c                       ; 3680
	dec (ix+17)                 ; 3681
	ret p                       ; 3684
	inc (ix+16)                 ; 3685
	ret                         ; 3688
L3689:
	call L315f                  ; 3689
	ld a,(ix+0)                 ; 368c
	cp $2c                      ; 368f
	jp nz,L36a4                 ; 3691
	ld a,(ix+3)                 ; 3694
	cp $07                      ; 3697
	call z,L3eb6                ; 3699
	ld a,(ix+3)                 ; 369c
	cp $0f                      ; 369f
	call z,L3eb6                ; 36a1
L36a4:
	ld a,(ix+16)                ; 36a4
	add a,(ix+3)                ; 36a7
	ld (ix+3),a                 ; 36aa
	cp $1b                      ; 36ad
	jr nc,L36b6                 ; 36af
	cp $03                      ; 36b1
	jp nc,L36be                 ; 36b3
L36b6:
	ld a,(ix+16)                ; 36b6
	neg                         ; 36b9
	ld (ix+16),a                ; 36bb
L36be:
	inc (ix+17)                 ; 36be
	ld a,(ix+17)                ; 36c1
	and $1f                     ; 36c4
	ld (ix+17),a                ; 36c6
	call L2e76                  ; 36c9
	sla d                       ; 36cc
	sla e                       ; 36ce
	ld a,$1a                    ; 36d0
	add a,d                     ; 36d2
	ld (ix+5),a                 ; 36d3
	ld a,$0f                    ; 36d6
	add a,e                     ; 36d8
	ld (ix+4),a                 ; 36d9
	ret                         ; 36dc
L36dd:
	ld hl,L2523                 ; 36dd
	rlc (hl)                    ; 36e0
	ret c                       ; 36e2
	ld ix,WRK+$079              ; 36e3
	ld b,$10                    ; 36e7
	ld de,$0018                 ; 36e9
L36ec:
	exx                         ; 36ec
	ld a,(WRK+$068)             ; 36ed
	cp (ix+13)                  ; 36f0
	jp c,L3724                  ; 36f3
	ld a,(ix+0)                 ; 36f6
	or a                        ; 36f9
	jp z,L3724                  ; 36fa
	bit 7,(ix+7)                ; 36fd
	jp nz,L370a                 ; 3701
	dec (ix+7)                  ; 3704
	jp L3724                    ; 3707
L370a:
	ld a,(ix+11)                ; 370a
	cp $31                      ; 370d
	jp nc,L3724                 ; 370f
	dec a                       ; 3712
	add a,a                     ; 3713
	ld e,a                      ; 3714
	ld d,$00                    ; 3715
	ld hl,L372a                 ; 3717
	add hl,de                   ; 371a
	ld e,(hl)                   ; 371b
	inc hl                      ; 371c
	ld d,(hl)                   ; 371d
	ex de,hl                    ; 371e
	ld de,L3724                 ; 371f
	push de                     ; 3722
	jp (hl)                     ; 3723
L3724:
	exx                         ; 3724
	add ix,de                   ; 3725
	djnz L36ec                  ; 3727
	ret                         ; 3729
L372a:
	dw L322d                    ; 372a
	dw L322d                    ; 372c
	dw L35d5                    ; 372e
	dw L35f9                    ; 3730
	dw L32dd                    ; 3732
	dw L32dd                    ; 3734
	dw L2f3c                    ; 3736
	dw L331f                    ; 3738
	dw L33a4                    ; 373a
	dw L3406                    ; 373c
	dw L3406                    ; 373e
	dw L349b                    ; 3740
	dw L34fa                    ; 3742
	dw L27a4                    ; 3744
	dw L3194                    ; 3746
	dw L331f                    ; 3748
	dw L33a4                    ; 374a
	dw L32dd                    ; 374c
	dw L32dd                    ; 374e
	dw L359d                    ; 3750
	dw L349b                    ; 3752
	dw L34fa                    ; 3754
	dw L322d                    ; 3756
	dw L322d                    ; 3758
	dw L2da2                    ; 375a
	dw L2da2                    ; 375c
	dw L2da2                    ; 375e
	dw L3646                    ; 3760
	dw L3646                    ; 3762
	dw L3646                    ; 3764
	dw L351c                    ; 3766
	dw L351c                    ; 3768
	dw L3548                    ; 376a
	dw L2755                    ; 376c
	dw L2f3c                    ; 376e
	dw L2f76                    ; 3770
	dw L2755                    ; 3772
	dw L288c                    ; 3774
	dw L2866                    ; 3776
	dw L2d4e                    ; 3778
	dw L2da2                    ; 377a
	dw L3689                    ; 377c
	dw $0001                    ; 377e
	dw $0001                    ; 3780
	dw $0001                    ; 3782
	dw L2755                    ; 3784
	dw L2750                    ; 3786
	dw L274b                    ; 3788
L378a:
	db $01,$02,$03,$04,$05,$06,$07,$08,$09,$0a,$0b,$0c,$0d,$0e,$0f,$10; 378a
	db $11,$12,$01,$01,$01,$01,$01,$0b; 379a
L37a2:
	ld a,(WRK+$062)             ; 37a2
	dec a                       ; 37a5
	ld e,a                      ; 37a6
	ld d,$00                    ; 37a7
	ld hl,L378a                 ; 37a9
	add hl,de                   ; 37ac
	ld a,(hl)                   ; 37ad
	ld (WRK+$25c),a             ; 37ae
L37b1:
	ld hl,WRK+$079              ; 37b1
	ld de,WRK+$07a              ; 37b4
	ld bc,$0180                 ; 37b7
	ld (hl),$00                 ; 37ba
	ldir                        ; 37bc
	ld a,(WRK+$25c)             ; 37be
	dec a                       ; 37c1
	ret m                       ; 37c2
	add a,a                     ; 37c3
	ld e,a                      ; 37c4
	ld d,$00                    ; 37c5
	ld hl,L37d0                 ; 37c7
	add hl,de                   ; 37ca
	ld e,(hl)                   ; 37cb
	inc hl                      ; 37cc
	ld d,(hl)                   ; 37cd
	ex de,hl                    ; 37ce
	jp (hl)                     ; 37cf
L37d0:
	dw L37f5                    ; 37d0
	dw L3ba0                    ; 37d2
	dw L3c28                    ; 37d4
	dw L3b30                    ; 37d6
	dw L37f4                    ; 37d8
	dw L3993                    ; 37da
	dw L3ac3                    ; 37dc
	dw L390f                    ; 37de
	dw L38b8                    ; 37e0
	dw L3a01                    ; 37e2
	dw L3cc2                    ; 37e4
	dw L37f4                    ; 37e6
	dw L385f                    ; 37e8
	dw L396e                    ; 37ea
	dw L383e                    ; 37ec
	dw L3a6f                    ; 37ee
	dw L3a12                    ; 37f0
	dw L3ce3                    ; 37f2
L37f4:
	ret                         ; 37f4
