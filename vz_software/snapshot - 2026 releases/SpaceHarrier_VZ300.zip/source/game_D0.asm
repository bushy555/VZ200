L37f5:
	ld a,$08                    ; 37f5
	ld de,WRK+$079              ; 37f7
L37fa:
	ld hl,L382a                 ; 37fa
	ld bc,$0014                 ; 37fd
	ldir                        ; 3800
	ld c,$04                    ; 3802
	ex de,hl                    ; 3804
	add hl,bc                   ; 3805
	ex de,hl                    ; 3806
	dec a                       ; 3807
	jp nz,L37fa                 ; 3808
	ld a,$01                    ; 380b
	ld (WRK+$08c),a             ; 380d
	xor a                       ; 3810
	ld (WRK+$081),a             ; 3811
	ld a,$0b                    ; 3814
	ld (WRK+$079),a             ; 3816
	ld de,$0018                 ; 3819
	ld hl,WRK+$080              ; 381c
	ld b,$08                    ; 381f
L3821:
	ld a,$07                    ; 3821
	sub b                       ; 3823
	add a,a                     ; 3824
	ld (hl),a                   ; 3825
	add hl,de                   ; 3826
	djnz L3821                  ; 3827
	ret                         ; 3829
L382a:
	db $0c,$00,$00,$1b,$09,$1a,$00,$00,$02,$01,$03,$01,$07,$04,$01,$00; 382a
	db $ff,$01,$07,$00          ; 383a
L383e:
	call L37f5                  ; 383e
	ld ix,WRK+$079              ; 3841
	ld de,$0018                 ; 3845
	ld b,$08                    ; 3848
	ld hl,L3857                 ; 384a
L384d:
	ld a,(hl)                   ; 384d
	ld (ix+0),a                 ; 384e
	inc hl                      ; 3851
	add ix,de                   ; 3852
	djnz L384d                  ; 3854
	ret                         ; 3856
L3857:
	db $14,$15,$15,$15,$15,$15,$15,$15; 3857
L385f:
	ld ix,WRK+$079              ; 385f
	ld hl,L38a6                 ; 3863
	ld b,$09                    ; 3866
	ld de,$0018                 ; 3868
L386b:
	ld (ix+0),$0a               ; 386b
	ld (ix+3),$1e               ; 386f
	ld (ix+6),$00               ; 3873
	ld (ix+7),$00               ; 3877
	ld (ix+8),$00               ; 387b
	ld (ix+9),$01               ; 387f
	ld (ix+10),$09              ; 3883
	ld (ix+11),$14              ; 3887
	ld (ix+12),$00              ; 388b
	ld (ix+13),$04              ; 388f
	ld (ix+14),$01              ; 3893
	ld a,(hl)                   ; 3897
	ld (ix+4),a                 ; 3898
	inc hl                      ; 389b
	ld a,(hl)                   ; 389c
	ld (ix+5),a                 ; 389d
	inc hl                      ; 38a0
	add ix,de                   ; 38a1
	djnz L386b                  ; 38a3
	ret                         ; 38a5
L38a6:
	db $00,$0e,$00,$1a,$00,$26,$0a,$0e,$0a,$1a,$0a,$26,$14,$0e,$14,$1a; 38a6
	db $14,$26                  ; 38b6
L38b8:
	ld hl,L38e2                 ; 38b8
	ld ix,WRK+$079              ; 38bb
	ld de,WRK+$079              ; 38bf
	ld bc,$000f                 ; 38c2
	ldir                        ; 38c5
	ld de,WRK+$091              ; 38c7
	ld c,$0f                    ; 38ca
	ldir                        ; 38cc
	ld de,WRK+$0a9              ; 38ce
	ld c,$0f                    ; 38d1
	ldir                        ; 38d3
	ld (ix+16),$00              ; 38d5
	ld (ix+40),$00              ; 38d9
	ld (ix+64),$00              ; 38dd
	ret                         ; 38e1
L38e2:
	db $1f,$00,$00,$1b,$07,$10,$02,$00,$00,$00,$07,$0e,$00,$03,$01,$1f; 38e2
	db $00,$00,$1b,$07,$26,$02,$00,$00,$00,$07,$0e,$00,$03,$01,$1f,$00; 38f2
	db $00,$1b,$10,$1a,$00,$13,$02,$00,$07,$0f,$00,$05,$01; 3902
L390f:
	ld hl,L395d                 ; 390f
	ld de,WRK+$079              ; 3912
	ld bc,$0011                 ; 3915
	ldir                        ; 3918
	ld de,WRK+$091              ; 391a
	ld a,$08                    ; 391d
L391f:
	ld hl,L394e                 ; 391f
	ld bc,$000f                 ; 3922
	ldir                        ; 3925
	ld c,$09                    ; 3927
	ex de,hl                    ; 3929
	add hl,bc                   ; 392a
	ex de,hl                    ; 392b
	dec a                       ; 392c
	jp nz,L391f                 ; 392d
	ld ix,WRK+$091              ; 3930
	ld hl,L3946                 ; 3934
	ld b,$08                    ; 3937
	ld de,$0018                 ; 3939
L393c:
	ld a,(hl)                   ; 393c
	ld (ix+16),a                ; 393d
	inc hl                      ; 3940
	add ix,de                   ; 3941
	djnz L393c                  ; 3943
	ret                         ; 3945
L3946:
	db $00,$03,$07,$0b,$0f,$13,$17,$1b; 3946
L394e:
	db $21,$00,$00,$00,$00,$00,$00,$ff,$00,$01,$03,$0d,$00,$04,$01; 394e
L395d:
	db $13,$00,$00,$1b,$09,$1a,$00,$ff,$00,$01,$03,$0c,$04,$04,$01,$00; 395d
	db $00                      ; 396d
L396e:
	call L390f                  ; 396e
	ld hl,L3987                 ; 3971
	ld de,$0018                 ; 3974
	ld b,$09                    ; 3977
	ld ix,WRK+$079              ; 3979
L397d:
	ld a,(hl)                   ; 397d
	ld (ix+0),a                 ; 397e
	inc hl                      ; 3981
	add ix,de                   ; 3982
	djnz L397d                  ; 3984
	ret                         ; 3986
L3987:
	db $0d,$23,$23,$23,$23,$23,$23,$23,$23,$23,$23,$23; 3987
L3993:
	ld a,$03                    ; 3993
	ld de,WRK+$079              ; 3995
L3998:
	ld hl,L39df                 ; 3998
	ld bc,$0011                 ; 399b
	ldir                        ; 399e
	push hl                     ; 39a0
	ld hl,$0007                 ; 39a1
	add hl,de                   ; 39a4
	ex de,hl                    ; 39a5
	pop hl                      ; 39a6
	dec a                       ; 39a7
	jp nz,L3998                 ; 39a8
	ld a,$03                    ; 39ab
	ld de,WRK+$0c1              ; 39ad
L39b0:
	ld hl,L39f0                 ; 39b0
	ld bc,$0011                 ; 39b3
	ldir                        ; 39b6
	ld c,$07                    ; 39b8
	ex de,hl                    ; 39ba
	add hl,bc                   ; 39bb
	ex de,hl                    ; 39bc
	dec a                       ; 39bd
	jp nz,L39b0                 ; 39be
	ld iy,WRK+$079              ; 39c1
	ld ix,WRK+$0d9              ; 39c5
	ld b,$04                    ; 39c9
	ld de,$0018                 ; 39cb
L39ce:
	ld a,b                      ; 39ce
	add a,a                     ; 39cf
	add a,a                     ; 39d0
	add a,a                     ; 39d1
	ld (iy+7),a                 ; 39d2
	ld (ix+7),a                 ; 39d5
	add ix,de                   ; 39d8
	add iy,de                   ; 39da
	djnz L39ce                  ; 39dc
	ret                         ; 39de
L39df:
	db $0f,$00,$00,$1a,$00,$0f,$00,$00,$00,$01,$09,$10,$00,$03,$01,$00; 39df
	db $00                      ; 39ef
L39f0:
	db $0f,$00,$00,$1a,$00,$2a,$00,$00,$00,$01,$09,$11,$00,$03,$01,$00; 39f0
	db $00                      ; 3a00
L3a01:
	call L3993                  ; 3a01
	ld hl,WRK+$079              ; 3a04
	ld de,$0018                 ; 3a07
	ld b,$06                    ; 3a0a
L3a0c:
	ld (hl),$20                 ; 3a0c
	add hl,de                   ; 3a0e
	djnz L3a0c                  ; 3a0f
	ret                         ; 3a11
L3a12:
	ld hl,L3a1e                 ; 3a12
	ld de,WRK+$079              ; 3a15
	ld bc,$0048                 ; 3a18
	ldir                        ; 3a1b
	ret                         ; 3a1d
L3a1e:
	db $1b,$00,$00,$1b,$07,$1a,$00,$00,$00,$00,$00,$21,$1e,$04,$01,$00; 3a1e
	db $00,$00,$00,$00,$00,$00,$00,$00,$16,$00,$00,$1b,$0f,$10,$00,$00; 3a2e
	db $01,$01,$03,$1f,$00,$04,$01,$00,$00,$00,$00,$00,$00,$00,$00,$00; 3a3e
	db $17,$00,$00,$1b,$0f,$27,$00,$00,$01,$01,$03,$1f,$00,$04,$01,$00; 3a4e
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 3a5e
	db $00                      ; 3a6e
L3a6f:
	ld hl,L3a7b                 ; 3a6f
	ld de,WRK+$079              ; 3a72
	ld bc,$0048                 ; 3a75
	ldir                        ; 3a78
	ret                         ; 3a7a
L3a7b:
	db $18,$00,$00,$1b,$05,$11,$00,$00,$02,$01,$00,$1c,$00,$04,$01,$00; 3a7b
	db $00,$00,$00,$00,$00,$00,$00,$00,$19,$00,$00,$1b,$05,$1a,$00,$00; 3a8b
	db $02,$01,$00,$1d,$00,$04,$01,$00,$00,$00,$00,$00,$00,$00,$00,$00; 3a9b
	db $1a,$00,$00,$1b,$05,$23,$00,$00,$02,$01,$00,$1e,$00,$04,$01,$00; 3aab
	db $00,$00,$00,$00,$00,$00,$00,$00; 3abb
L3ac3:
	ld de,WRK+$079              ; 3ac3
	ld a,$03                    ; 3ac6
L3ac8:
	ld hl,L3b0c                 ; 3ac8
	ld bc,$0012                 ; 3acb
	ldir                        ; 3ace
	ld c,$06                    ; 3ad0
	ex de,hl                    ; 3ad2
	add hl,bc                   ; 3ad3
	ex de,hl                    ; 3ad4
	dec a                       ; 3ad5
	jp nz,L3ac8                 ; 3ad6
	ld de,WRK+$0c1              ; 3ad9
	ld a,$03                    ; 3adc
L3ade:
	ld hl,L3b1e                 ; 3ade
	ld bc,$0012                 ; 3ae1
	ldir                        ; 3ae4
	ld c,$06                    ; 3ae6
	ex de,hl                    ; 3ae8
	add hl,bc                   ; 3ae9
	ex de,hl                    ; 3aea
	dec a                       ; 3aeb
	jp nz,L3ade                 ; 3aec
	ld ix,WRK+$079              ; 3aef
	ld iy,WRK+$0c1              ; 3af3
	ld de,$0018                 ; 3af7
	ld b,$03                    ; 3afa
L3afc:
	ld a,b                      ; 3afc
	add a,a                     ; 3afd
	add a,a                     ; 3afe
	ld (ix+7),a                 ; 3aff
	ld (iy+7),a                 ; 3b02
	add ix,de                   ; 3b05
	add iy,de                   ; 3b07
	djnz L3afc                  ; 3b09
	ret                         ; 3b0b
L3b0c:
	db $11,$00,$00,$1b,$00,$20,$03,$00,$02,$01,$09,$0a,$00,$05,$01,$00; 3b0c
	db $00,$00                  ; 3b1c
L3b1e:
	db $11,$00,$00,$1b,$1c,$20,$03,$00,$02,$01,$09,$0a,$00,$05,$01,$00; 3b1e
	db $00,$0f                  ; 3b2e
L3b30:
	ld de,WRK+$079              ; 3b30
	ld a,$03                    ; 3b33
L3b35:
	ld hl,L3b7a                 ; 3b35
	ld bc,$0013                 ; 3b38
	ldir                        ; 3b3b
	ld c,$05                    ; 3b3d
	ex de,hl                    ; 3b3f
	add hl,bc                   ; 3b40
	ex de,hl                    ; 3b41
	dec a                       ; 3b42
	jp nz,L3b35                 ; 3b43
	ld de,WRK+$0c1              ; 3b46
	ld a,$03                    ; 3b49
L3b4b:
	ld hl,L3b8d                 ; 3b4b
	ld bc,$0013                 ; 3b4e
	ldir                        ; 3b51
	ld c,$05                    ; 3b53
	ex de,hl                    ; 3b55
	add hl,bc                   ; 3b56
	ex de,hl                    ; 3b57
	dec a                       ; 3b58
	jp nz,L3b4b                 ; 3b59
	ld ix,WRK+$079              ; 3b5c
	ld iy,WRK+$0c1              ; 3b60
	ld de,$0018                 ; 3b64
	ld b,$03                    ; 3b67
L3b69:
	ld a,b                      ; 3b69
	add a,a                     ; 3b6a
	add a,a                     ; 3b6b
	add a,a                     ; 3b6c
	ld (ix+7),a                 ; 3b6d
	ld (iy+7),a                 ; 3b70
	add ix,de                   ; 3b73
	add iy,de                   ; 3b75
	djnz L3b69                  ; 3b77
	ret                         ; 3b79
L3b7a:
	db $1c,$00,$00,$1b,$10,$0d,$01,$00,$00,$00,$04,$24,$00,$05,$01,$00; 3b7a
	db $00,$00,$00              ; 3b8a
L3b8d:
	db $1c,$00,$00,$1b,$10,$28,$00,$00,$00,$00,$04,$23,$00,$05,$01,$00; 3b8d
	db $00,$00,$00              ; 3b9d
L3ba0:
	ld hl,L3be1                 ; 3ba0
	ld de,WRK+$079              ; 3ba3
	ld bc,$0018                 ; 3ba6
	ldir                        ; 3ba9
	ld de,WRK+$091              ; 3bab
	ld a,$08                    ; 3bae
L3bb0:
	ld hl,L3bfb                 ; 3bb0
	ld bc,$0010                 ; 3bb3
	ldir                        ; 3bb6
	ld c,$08                    ; 3bb8
	ex de,hl                    ; 3bba
	add hl,bc                   ; 3bbb
	ex de,hl                    ; 3bbc
	dec a                       ; 3bbd
	jp nz,L3bb0                 ; 3bbe
	ld ix,WRK+$091              ; 3bc1
	ld b,$08                    ; 3bc5
	ld de,$0018                 ; 3bc7
	ld hl,L3c0c                 ; 3bca
L3bcd:
	ld a,(hl)                   ; 3bcd
	ld (ix+4),a                 ; 3bce
	inc hl                      ; 3bd1
	ld a,(hl)                   ; 3bd2
	ld (ix+5),a                 ; 3bd3
	inc hl                      ; 3bd6
	ld a,(hl)                   ; 3bd7
	ld (ix+16),a                ; 3bd8
	inc hl                      ; 3bdb
	add ix,de                   ; 3bdc
	djnz L3bcd                  ; 3bde
	ret                         ; 3be0
L3be1:
	db $0d,$00,$00,$1b,$0a,$1a,$00,$00,$00,$01,$03,$03,$00,$04,$01,$00; 3be1
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 3bf1
L3bfb:
	db $22,$00,$00,$1b,$00,$00,$00,$00,$00,$01,$00,$04,$00,$04,$01,$00; 3bfb
	db $00                      ; 3c0b
L3c0c:
	db $00,$14,$0c,$00,$20,$1b,$0a,$00,$00,$0a,$0f,$07,$0a,$23,$07,$0a; 3c0c
	db $32,$18,$11,$14,$04,$11,$20,$13,$00,$00,$00,$00; 3c1c
L3c28:
	ld a,$04                    ; 3c28
	ld de,WRK+$079              ; 3c2a
L3c2d:
	ld hl,L3c86                 ; 3c2d
	ld bc,$0014                 ; 3c30
	ldir                        ; 3c33
	ld c,$04                    ; 3c35
	ex de,hl                    ; 3c37
	add hl,bc                   ; 3c38
	ex de,hl                    ; 3c39
	dec a                       ; 3c3a
	jp nz,L3c2d                 ; 3c3b
	ld a,$04                    ; 3c3e
	ld de,WRK+$0d9              ; 3c40
L3c43:
	ld hl,L3c9c                 ; 3c43
	ld bc,$0014                 ; 3c46
	ldir                        ; 3c49
	ld c,$04                    ; 3c4b
	ex de,hl                    ; 3c4d
	add hl,bc                   ; 3c4e
	ex de,hl                    ; 3c4f
	dec a                       ; 3c50
	jp nz,L3c43                 ; 3c51
	ld ix,WRK+$079              ; 3c54
	ld de,$0018                 ; 3c58
	ld b,$08                    ; 3c5b
	ld hl,L3cb2                 ; 3c5d
L3c60:
	ld a,(hl)                   ; 3c60
	ld (ix+5),a                 ; 3c61
	inc hl                      ; 3c64
	ld a,(hl)                   ; 3c65
	ld (ix+7),a                 ; 3c66
	inc hl                      ; 3c69
	add ix,de                   ; 3c6a
	djnz L3c60                  ; 3c6c
	ld a,$01                    ; 3c6e
	ld (WRK+$08c),a             ; 3c70
	ld (WRK+$0ec),a             ; 3c73
	ld a,$0e                    ; 3c76
	ld (WRK+$079),a             ; 3c78
	ld (WRK+$0d9),a             ; 3c7b
	xor a                       ; 3c7e
	ld (WRK+$081),a             ; 3c7f
	ld (WRK+$0e1),a             ; 3c82
	ret                         ; 3c85
L3c86:
	db $0c,$00,$00,$19,$10,$00,$00,$00,$02,$01,$03,$12,$07,$04,$01,$00; 3c86
	db $ff,$00,$00,$00,$00,$00  ; 3c96
L3c9c:
	db $0c,$00,$00,$19,$10,$00,$00,$00,$02,$01,$03,$12,$07,$04,$01,$00; 3c9c
	db $ff,$03,$00,$00,$00,$00  ; 3cac
L3cb2:
	db $0e,$00,$11,$02,$15,$04,$17,$08,$29,$00,$26,$02,$23,$04,$20,$08; 3cb2
L3cc2:
	call L3c28                  ; 3cc2
	ld ix,WRK+$079              ; 3cc5
	ld hl,L3cdb                 ; 3cc9
	ld de,$0018                 ; 3ccc
	ld b,$08                    ; 3ccf
L3cd1:
	ld a,(hl)                   ; 3cd1
	ld (ix+0),a                 ; 3cd2
	inc hl                      ; 3cd5
	add ix,de                   ; 3cd6
	djnz L3cd1                  ; 3cd8
	ret                         ; 3cda
L3cdb:
	db $14,$15,$15,$15,$14,$15,$15,$15; 3cdb
L3ce3:
	ld a,$04                    ; 3ce3
	ld de,WRK+$079              ; 3ce5
L3ce8:
	ld hl,L3d2c                 ; 3ce8
	ld bc,$0018                 ; 3ceb
	ldir                        ; 3cee
	dec a                       ; 3cf0
	jr nz,L3ce8                 ; 3cf1
	ld de,WRK+$0d9              ; 3cf3
	ld a,$04                    ; 3cf6
L3cf8:
	ld hl,L3d4e                 ; 3cf8
	ld bc,$0018                 ; 3cfb
	ldir                        ; 3cfe
	dec a                       ; 3d00
	jr nz,L3cf8                 ; 3d01
	ld hl,WRK+$080              ; 3d03
	ld iy,WRK+$0d9              ; 3d06
	ld b,$04                    ; 3d0a
	ld de,$0018                 ; 3d0c
L3d0f:
	ld a,$04                    ; 3d0f
	sub b                       ; 3d11
	add a,a                     ; 3d12
	ld (hl),a                   ; 3d13
	ld (iy+7),a                 ; 3d14
	add iy,de                   ; 3d17
	add hl,de                   ; 3d19
	djnz L3d0f                  ; 3d1a
	ld a,$2c                    ; 3d1c
	ld (WRK+$079),a             ; 3d1e
	ld (WRK+$0d9),a             ; 3d21
	xor a                       ; 3d24
	ld (WRK+$081),a             ; 3d25
	ld (WRK+$0e1),a             ; 3d28
	ret                         ; 3d2b
L3d2c:
	db $2d,$00,$00,$19,$01,$1a,$00,$00,$02,$01,$03,$2a,$07,$02,$01,$00; 3d2c
	db $ff,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 3d3c
	db $00,$00                  ; 3d4c
L3d4e:
	db $2d,$00,$00,$19,$12,$30,$00,$00,$02,$01,$03,$2a,$07,$02,$01,$00; 3d4e
	db $ff,$10,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 3d5e
	db $00,$00                  ; 3d6e
L3d70:
	ld iy,WRK+$079              ; 3d70
	ld de,$0018                 ; 3d74
	ld b,$0d                    ; 3d77
L3d79:
	ld a,(iy+0)                 ; 3d79
	or a                        ; 3d7c
	ret z                       ; 3d7d
	add iy,de                   ; 3d7e
	djnz L3d79                  ; 3d80
	scf                         ; 3d82
	ret                         ; 3d83
L3d84:
	db $ee                      ; 3d84
L3d85:
	ld hl,L3d84                 ; 3d85
	rlc (hl)                    ; 3d88
	ret c                       ; 3d8a
	call L3d70                  ; 3d8b
	ret c                       ; 3d8e
	ld hl,(L3db7)               ; 3d8f
	ld a,(hl)                   ; 3d92
	inc hl                      ; 3d93
	ld (L3db7),hl               ; 3d94
	dec a                       ; 3d97
	ret m                       ; 3d98
	add a,a                     ; 3d99
	ld e,a                      ; 3d9a
	ld d,$00                    ; 3d9b
	ld hl,L3db9                 ; 3d9d
	add hl,de                   ; 3da0
	ld e,(hl)                   ; 3da1
	inc hl                      ; 3da2
	ld d,(hl)                   ; 3da3
	ex de,hl                    ; 3da4
	push iy                     ; 3da5
	pop de                      ; 3da7
	ld bc,$0013                 ; 3da8
	ldir                        ; 3dab
	ld a,r                      ; 3dad
	and $1f                     ; 3daf
	add a,$0d                   ; 3db1
	ld (L3dca),a                ; 3db3
	ret                         ; 3db6
L3db7:
	db $00,$00                  ; 3db7
L3db9:
	dw L3dc5                    ; 3db9
	dw L3dda                    ; 3dbb
	dw L3def                    ; 3dbd
	dw L3e04                    ; 3dbf
	dw L3e19                    ; 3dc1
	dw L3e2e                    ; 3dc3
L3dc5:
	db $24,$00,$00,$1b,$0b      ; 3dc5
L3dca:
	db $21,$00,$00,$02,$00,$00,$25,$00,$02,$00,$00,$00,$00,$00,$00,$00; 3dca
L3dda:
	db $25,$00,$00,$1b,$0b,$00,$01,$00,$00,$01,$00,$26,$00,$04,$01,$00; 3dda
	db $00,$00,$00,$00,$00      ; 3dea
L3def:
	db $25,$00,$00,$1b,$0b,$40,$00,$00,$00,$01,$00,$27,$00,$04,$01,$00; 3def
	db $00,$00,$00,$00,$00      ; 3dff
L3e04:
	db $1d,$00,$00,$1b,$10,$0a,$01,$00,$00,$00,$00,$29,$00,$05,$00,$00; 3e04
	db $00,$00,$00,$00,$00      ; 3e14
L3e19:
	db $1c,$00,$00,$1b,$10,$32,$00,$00,$00,$00,$00,$28,$00,$05,$00,$00; 3e19
	db $00,$00,$00,$00,$00      ; 3e29
L3e2e:
	db $1e,$00,$00,$1b,$10,$0a,$00,$00,$00,$00,$00,$29,$00,$05,$00,$00; 3e2e
	db $00,$00,$00,$00,$00      ; 3e3e
L3e43:
	db $26,$00,$00,$1b,$15      ; 3e43
L3e48:
	db $20,$00,$00,$00,$01,$00,$2e,$00,$02,$01,$00,$00,$00,$00,$00; 3e48
L3e57:
	db $00,$00,$00,$00,$00,$00,$01,$02,$02,$02,$00,$01,$01,$00,$04,$01; 3e57
	db $05,$01,$06,$01,$01,$00,$03,$03,$03,$00,$01,$01,$01,$01,$00,$01; 3e67
	db $00,$01,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 3e77
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 3e87
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 3e97
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 3ea7
L3eb5:
	ret                         ; 3eb5
L3eb6:
	ld a,$1b                    ; 3eb6
	jp La000                    ; 3eb8
L3ebb:
	ld a,$24                    ; 3ebb
	jp La000                    ; 3ebd
	db $ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff; 3ec0
	db $ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff; 3ed0
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 3ee0
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 3ef0
	db $ff,$2d,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff; 3f00
	db $ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff; 3f10
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 3f20
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 3f30
	db $ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff; 3f40
	db $ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff; 3f50
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 3f60
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 3f70
	db $ff,$53,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff; 3f80
	db $ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff; 3f90
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 3fa0
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 3fb0
	db $ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff; 3fc0
	db $ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff; 3fd0
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 3fe0
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 3ff0
L9000:
	di                          ; 9000
	push af                     ; 9001
	push bc                     ; 9002
	push de                     ; 9003
	push hl                     ; 9004
	push ix                     ; 9005
	push iy                     ; 9007
	call L90ea                  ; 9009
	call L949a                  ; 900c
	call L90ba                  ; 900f
L9012:
	ld hl,$e007                 ; 9012
	ld (hl),$b0                 ; 9015
	ld (hl),$74                 ; 9017
	dec l                       ; 9019
	ld (hl),$02                 ; 901a
	ld (hl),$00                 ; 901c
	dec l                       ; 901e
L901f:
	ld (hl),$05                 ; 901f
L9021:
	ld (hl),$00                 ; 9021
	pop iy                      ; 9023
	pop ix                      ; 9025
	pop hl                      ; 9027
	pop de                      ; 9028
	pop bc                      ; 9029
	pop af                      ; 902a
	nop                         ; 902b patched
	ret                         ; 902c
L902d:
	db $03                      ; 902d
L902e:
	db $a9,$00,$97,$00,$1d,$01,$fe,$00,$e2,$00,$d5,$00,$be,$00; 902e
L903c:
	db $a0,$00,$8e,$00,$0d,$01,$ef,$00,$d5,$00,$c9,$00,$b3,$00; 903c
L904a:
	db $b3,$00,$a0,$00,$8e,$00,$0d,$01,$ef,$00,$d5,$00,$c9,$00; 904a
L9058:
	ld iy,L9513                 ; 9058
	ld a,(iy+0)                 ; 905c
	or a                        ; 905f
	jr z,L9077                  ; 9060
L9062:
	ld a,(iy+14)                ; 9062
	or a                        ; 9065
	jr nz,L906c                 ; 9066
	ld ($e008),a                ; 9068
	ret                         ; 906b
L906c:
	ld a,(iy+13)                ; 906c
	ld ($e008),a                ; 906f
	ld (iy+13),$01              ; 9072
	ret                         ; 9076
L9077:
	ld iy,L953b                 ; 9077
	ld a,(iy+0)                 ; 907b
	or a                        ; 907e
	jr nz,L9062                 ; 907f
	ld iy,L9563                 ; 9081
	ld a,(iy+0)                 ; 9085
	or a                        ; 9088
	jr nz,L9062                 ; 9089
	ld ($e008),a                ; 908b
	ret                         ; 908e
	ld a,(L9331)                ; 908f
	or a                        ; 9092
	ret z                       ; 9093
	ld iy,L9513                 ; 9094
	call L90a6                  ; 9098
	ld iy,L953b                 ; 909b
	call L90a6                  ; 909f
	ld iy,L9563                 ; 90a2
L90a6:
	ld l,(iy+3)                 ; 90a6
	ld h,(iy+4)                 ; 90a9
	ld e,(iy+1)                 ; 90ac
	ld d,(iy+2)                 ; 90af
	add hl,de                   ; 90b2
	ld (iy+1),l                 ; 90b3
	ld (iy+2),h                 ; 90b6
	ret                         ; 90b9
L90ba:
	ld a,(L9513)                ; 90ba
	or a                        ; 90bd
	jp z,L91b7                  ; 90be
	ld iy,L9513                 ; 90c1
	call L90d6                  ; 90c5
	ld e,(iy+1)                 ; 90c8
	ld d,(iy+2)                 ; 90cb
	ld hl,$e004                 ; 90ce
	ld (hl),e                   ; 90d1
	ld (hl),d                   ; 90d2
	jp L9058                    ; 90d3
L90d6:
	ld e,(iy+5)                 ; 90d6
	ld d,(iy+6)                 ; 90d9
	ld l,(iy+1)                 ; 90dc
	ld h,(iy+2)                 ; 90df
	add hl,de                   ; 90e2
	ld (iy+1),l                 ; 90e3
	ld (iy+2),h                 ; 90e6
	ret                         ; 90e9
L90ea:
	ld iy,L9513                 ; 90ea
	call L90fc                  ; 90ee
	ld iy,L953b                 ; 90f1
	call L90fc                  ; 90f5
	ld iy,L9563                 ; 90f8
L90fc:
	ld a,(iy+0)                 ; 90fc
	or a                        ; 90ff
	ret z                       ; 9100
	dec (iy+8)                  ; 9101
	ret p                       ; 9104
	ld l,(iy+21)                ; 9105
	ld h,(iy+22)                ; 9108
	push hl                     ; 910b
	pop ix                      ; 910c
L910e:
	ld a,(ix+0)                 ; 910e
	cp $5e                      ; 9111
	jr nc,L9119                 ; 9113
	sub $21                     ; 9115
	jr nc,L911d                 ; 9117
L9119:
	inc ix                      ; 9119
	jr L910e                    ; 911b
L911d:
	add a,a                     ; 911d
	ld e,a                      ; 911e
	ld d,$00                    ; 911f
	ld hl,L912b                 ; 9121
	add hl,de                   ; 9124
	ld e,(hl)                   ; 9125
	inc hl                      ; 9126
	ld d,(hl)                   ; 9127
	ex de,hl                    ; 9128
	jp (hl)                     ; 9129
L912a:
	ret                         ; 912a
L912b:
	dw L912a                    ; 912b
	dw L912a                    ; 912d
	dw L92e6                    ; 912f
	dw L912a                    ; 9131
	dw L912a                    ; 9133
	dw L9270                    ; 9135
	dw L912a                    ; 9137
	dw L9332                    ; 9139
	dw L9340                    ; 913b
	dw L912a                    ; 913d
	dw L927b                    ; 913f
	dw L912a                    ; 9141
	dw L9281                    ; 9143
	dw L9287                    ; 9145
	dw L928d                    ; 9147
	dw L93bf                    ; 9149
	dw L93bf                    ; 914b
	dw L93bf                    ; 914d
	dw L93bf                    ; 914f
	dw L93bf                    ; 9151
	dw L93bf                    ; 9153
	dw L93bf                    ; 9155
	dw L93bf                    ; 9157
	dw L93bf                    ; 9159
	dw L93bf                    ; 915b
	dw L92c6                    ; 915d
	dw L92cb                    ; 915f
	dw L93b3                    ; 9161
	dw L912a                    ; 9163
	dw L93a0                    ; 9165
	dw L912a                    ; 9167
	dw L912a                    ; 9169
	dw L93cc                    ; 916b
	dw L93cc                    ; 916d
	dw L93cc                    ; 916f
	dw L93cc                    ; 9171
	dw L93cc                    ; 9173
	dw L93cc                    ; 9175
	dw L93cc                    ; 9177
	dw L934c                    ; 9179
	dw L930c                    ; 917b
	dw L9364                    ; 917d
	dw L92d0                    ; 917f
	dw L92db                    ; 9181
	dw L9250                    ; 9183
	dw L912a                    ; 9185
	dw L92a3                    ; 9187
	dw L912a                    ; 9189
	dw L912a                    ; 918b
	dw L9453                    ; 918d
	dw L92ed                    ; 918f
	dw L92ae                    ; 9191
	dw L92ba                    ; 9193
	dw L912a                    ; 9195
	dw L912a                    ; 9197
	dw L9462                    ; 9199
	dw L947e                    ; 919b
	dw L9322                    ; 919d
	dw L9376                    ; 919f
	dw L9298                    ; 91a1
	dw L938e                    ; 91a3
	db $2a,$91,$2a,$91,$2a,$91,$2a,$91; 91a5
L91ad:
	push ix                     ; 91ad
	pop hl                      ; 91af
	ld (iy+21),l                ; 91b0
	ld (iy+22),h                ; 91b3
	ret                         ; 91b6
L91b7:
	ld iy,L953b                 ; 91b7
	call L90d6                  ; 91bb
	ld iy,L9563                 ; 91be
	call L90d6                  ; 91c2
	ld a,(L902d)                ; 91c5
	add a,a                     ; 91c8
	ld e,a                      ; 91c9
	ld d,$00                    ; 91ca
	ld hl,L91d9                 ; 91cc
	add hl,de                   ; 91cf
	ld e,(hl)                   ; 91d0
	inc hl                      ; 91d1
	ld d,(hl)                   ; 91d2
	ex de,hl                    ; 91d3
	ld de,L9058                 ; 91d4
	push de                     ; 91d7
	jp (hl)                     ; 91d8
L91d9:
	dw L91ed                    ; 91d9
	dw L91f7                    ; 91db
	dw L9201                    ; 91dd
	dw L9215                    ; 91df
	dw L921b                    ; 91e1
	dw L923d                    ; 91e3
	dw L912a                    ; 91e5
	dw L912a                    ; 91e7
	dw L912a                    ; 91e9
	dw L912a                    ; 91eb
L91ed:
	ld de,(L9564)               ; 91ed
	ld hl,$e004                 ; 91f1
	ld (hl),e                   ; 91f4
	ld (hl),d                   ; 91f5
	ret                         ; 91f6
L91f7:
	ld de,(L953c)               ; 91f7
	ld hl,$e004                 ; 91fb
	ld (hl),e                   ; 91fe
	ld (hl),d                   ; 91ff
	ret                         ; 9200
L9201:
	ld a,(L9549)                ; 9201
	ld de,(L953c)               ; 9204
	or a                        ; 9208
	jr z,L920f                  ; 9209
	ld de,(L9564)               ; 920b
L920f:
	ld hl,$e004                 ; 920f
	ld (hl),e                   ; 9212
	ld (hl),d                   ; 9213
	ret                         ; 9214
L9215:
	ld iy,L9563                 ; 9215
	jr L921f                    ; 9219
L921b:
	ld iy,L953b                 ; 921b
L921f:
	ld a,(iy+29)                ; 921f
	xor $01                     ; 9222
	ld (iy+29),a                ; 9224
	ld e,(iy+1)                 ; 9227
	ld d,(iy+2)                 ; 922a
	jr z,L9237                  ; 922d
	ld l,(iy+3)                 ; 922f
	ld h,(iy+4)                 ; 9232
	add hl,de                   ; 9235
	ex de,hl                    ; 9236
L9237:
	ld hl,$e004                 ; 9237
	ld (hl),e                   ; 923a
	ld (hl),d                   ; 923b
	ret                         ; 923c
L923d:
	ld a,$00                    ; 923d
	xor $01                     ; 923f
	ld (L923d+1),a              ; 9241
	jp z,L91f7                  ; 9244
	jp L91ed                    ; 9247
L924a:
	ret                         ; 924a
	ld a,(ix+32)                ; 924b
	jr L9256                    ; 924e
L9250:
	ld a,(ix+1)                 ; 9250
	ld (ix+32),a                ; 9253
L9256:
	and $03                     ; 9256
	add a,a                     ; 9258
	ld e,a                      ; 9259
	ld d,$00                    ; 925a
	ld hl,L94fb                 ; 925c
	add hl,de                   ; 925f
	ld e,(hl)                   ; 9260
	inc hl                      ; 9261
	ld d,(hl)                   ; 9262
	ld (iy+30),e                ; 9263
	ld (iy+31),d                ; 9266
	inc ix                      ; 9269
	inc ix                      ; 926b
	jp L910e                    ; 926d
L9270:
	ld a,(ix+1)                 ; 9270
	and $07                     ; 9273
	ld (L902d),a                ; 9275
	jp L931b                    ; 9278
L927b:
	dec (iy+7)                  ; 927b
	jp L931d                    ; 927e
L9281:
	inc (iy+7)                  ; 9281
	jp L931d                    ; 9284
L9287:
	inc (iy+8)                  ; 9287
	jp L931d                    ; 928a
L928d:
	ld (iy+11),$00              ; 928d
	ld (iy+13),$00              ; 9291
	jp L931d                    ; 9295
L9298:
	ld (iy+11),$01              ; 9298
	ld (iy+13),$01              ; 929c
	jp L931d                    ; 92a0
L92a3:
	ld a,(ix+1)                 ; 92a3
	and $07                     ; 92a6
	ld (iy+7),a                 ; 92a8
	jp L931b                    ; 92ab
L92ae:
	call L94c9                  ; 92ae
	ld (L901f+1),a              ; 92b1
	ld (iy+15),a                ; 92b4
	jp L9319                    ; 92b7
L92ba:
	call L94c9                  ; 92ba
	ld (L9021+1),a              ; 92bd
	ld (iy+16),a                ; 92c0
	jp L9319                    ; 92c3
L92c6:
	xor a                       ; 92c6
	ld (L9513),a                ; 92c7
	ret                         ; 92ca
L92cb:
	ld (iy+0),$00               ; 92cb
	ret                         ; 92cf
L92d0:
	ld a,(ix+1)                 ; 92d0
	sub $30                     ; 92d3
	ld (iy+9),a                 ; 92d5
	jp L931b                    ; 92d8
L92db:
	ld a,(ix+1)                 ; 92db
	sub $30                     ; 92de
	ld (iy+10),a                ; 92e0
	jp L931b                    ; 92e3
L92e6:
	ld (iy+12),$01              ; 92e6
	jp L931d                    ; 92ea
L92ed:
	call L94dc                  ; 92ed
	ld (iy+1),l                 ; 92f0
	ld (iy+2),h                 ; 92f3
	ld a,(iy+10)                ; 92f6
	add a,(iy+9)                ; 92f9
	ld (iy+8),a                 ; 92fc
	inc ix                      ; 92ff
	inc ix                      ; 9301
	inc ix                      ; 9303
	inc ix                      ; 9305
	inc ix                      ; 9307
	jp L91ad                    ; 9309
L930c:
	call L94dc                  ; 930c
	ld (iy+3),l                 ; 930f
	ld (iy+4),h                 ; 9312
L9315:
	inc ix                      ; 9315
	inc ix                      ; 9317
L9319:
	inc ix                      ; 9319
L931b:
	inc ix                      ; 931b
L931d:
	inc ix                      ; 931d
	jp L910e                    ; 931f
L9322:
	ld a,(ix+1)                 ; 9322
	and $01                     ; 9325
	ld (L9331),a                ; 9327
	inc ix                      ; 932a
	inc ix                      ; 932c
	jp L910e                    ; 932e
L9331:
	db $00                      ; 9331
L9332:
	inc ix                      ; 9332
	push ix                     ; 9334
	pop hl                      ; 9336
	ld (iy+19),l                ; 9337
	ld (iy+20),h                ; 933a
	jp L910e                    ; 933d
L9340:
	ld l,(iy+19)                ; 9340
	ld h,(iy+20)                ; 9343
	push hl                     ; 9346
	pop ix                      ; 9347
	jp L910e                    ; 9349
L934c:
	ld a,(ix+1)                 ; 934c
	sub $30                     ; 934f
	ld (iy+23),a                ; 9351
	inc ix                      ; 9354
	inc ix                      ; 9356
	push ix                     ; 9358
	pop hl                      ; 935a
	ld (iy+24),l                ; 935b
	ld (iy+25),h                ; 935e
	jp L910e                    ; 9361
L9364:
	ld l,(iy+24)                ; 9364
	ld h,(iy+25)                ; 9367
	dec (iy+23)                 ; 936a
	jp m,L931d                  ; 936d
	push hl                     ; 9370
	pop ix                      ; 9371
	jp L910e                    ; 9373
L9376:
	ld a,(ix+1)                 ; 9376
	sub $30                     ; 9379
	ld (iy+26),a                ; 937b
	inc ix                      ; 937e
	inc ix                      ; 9380
	push ix                     ; 9382
	pop hl                      ; 9384
	ld (iy+27),l                ; 9385
	ld (iy+28),h                ; 9388
	jp L910e                    ; 938b
L938e:
	ld l,(iy+27)                ; 938e
	ld h,(iy+28)                ; 9391
	dec (iy+26)                 ; 9394
	jp m,L931d                  ; 9397
	push hl                     ; 939a
	pop ix                      ; 939b
	jp L910e                    ; 939d
L93a0:
	call L94dc                  ; 93a0
	ld a,h                      ; 93a3
	cpl                         ; 93a4
	ld h,a                      ; 93a5
	ld a,l                      ; 93a6
	cpl                         ; 93a7
	ld l,a                      ; 93a8
	inc hl                      ; 93a9
	ld (iy+5),l                 ; 93aa
	ld (iy+6),h                 ; 93ad
	jp L9315                    ; 93b0
L93b3:
	call L94dc                  ; 93b3
	ld (iy+5),l                 ; 93b6
	ld (iy+6),h                 ; 93b9
	jp L9315                    ; 93bc
L93bf:
	ld a,(ix+0)                 ; 93bf
	sub $30                     ; 93c2
	ld (iy+8),a                 ; 93c4
	inc ix                      ; 93c7
	jp L91ad                    ; 93c9
L93cc:
	ld a,(ix+0)                 ; 93cc
	sub $41                     ; 93cf
	ld e,a                      ; 93d1
	ld d,$00                    ; 93d2
	ld hl,L94ed                 ; 93d4
	add hl,de                   ; 93d7
	ld a,(hl)                   ; 93d8
	xor (iy+17)                 ; 93d9
	ld hl,L903c                 ; 93dc
	jr nz,L93fd                 ; 93df
	ld a,(iy+12)                ; 93e1
	or a                        ; 93e4
	jr nz,L93fd                 ; 93e5
	ld hl,L94f4                 ; 93e7
	add hl,de                   ; 93ea
	ld a,(hl)                   ; 93eb
	xor (iy+12)                 ; 93ec
	ld hl,L904a                 ; 93ef
	jr nz,L93fd                 ; 93f2
	ld a,(iy+17)                ; 93f4
	or a                        ; 93f7
	jr nz,L93fd                 ; 93f8
	ld hl,L902e                 ; 93fa
L93fd:
	ld a,(ix+0)                 ; 93fd
	sub $41                     ; 9400
	add a,a                     ; 9402
	ld e,a                      ; 9403
	ld d,$00                    ; 9404
	add hl,de                   ; 9406
	ld e,(hl)                   ; 9407
	inc hl                      ; 9408
	ld d,(hl)                   ; 9409
	ex de,hl                    ; 940a
	ld b,(iy+7)                 ; 940b
	inc b                       ; 940e
L940f:
	add hl,hl                   ; 940f
	djnz L940f                  ; 9410
	ld (iy+1),l                 ; 9412
	ld (iy+2),h                 ; 9415
	ld (iy+12),$00              ; 9418
	ld (iy+14),$01              ; 941c
	ld a,(iy+11)                ; 9420
	ld (iy+13),a                ; 9423
	ld (iy+17),$00              ; 9426
	call L924a                  ; 942a
L942d:
	ld a,(ix+1)                 ; 942d
	cp $3a                      ; 9430
	jr nc,L9445                 ; 9432
	sub $30                     ; 9434
	jr c,L9445                  ; 9436
	add a,(iy+9)                ; 9438
	ld (iy+8),a                 ; 943b
	inc ix                      ; 943e
	inc ix                      ; 9440
	jp L91ad                    ; 9442
L9445:
	ld a,(iy+10)                ; 9445
	add a,(iy+9)                ; 9448
	ld (iy+8),a                 ; 944b
	inc ix                      ; 944e
	jp L91ad                    ; 9450
L9453:
	ld (iy+1),$01               ; 9453
	ld (iy+2),$00               ; 9457
	ld (iy+14),$00              ; 945b
	jp L942d                    ; 945f
L9462:
	ld hl,L94ed                 ; 9462
	push ix                     ; 9465
	ld b,$07                    ; 9467
L9469:
	ld a,(ix+1)                 ; 9469
	and $01                     ; 946c
	ld (hl),a                   ; 946e
	inc hl                      ; 946f
	inc ix                      ; 9470
	djnz L9469                  ; 9472
	pop ix                      ; 9474
	ld de,$0008                 ; 9476
	add ix,de                   ; 9479
	jp L910e                    ; 947b
L947e:
	ld hl,L94f4                 ; 947e
	push ix                     ; 9481
	ld b,$07                    ; 9483
L9485:
	ld a,(ix+1)                 ; 9485
	and $01                     ; 9488
	ld (hl),a                   ; 948a
	inc hl                      ; 948b
	inc ix                      ; 948c
	djnz L9485                  ; 948e
	pop ix                      ; 9490
	ld de,$0008                 ; 9492
	add ix,de                   ; 9495
	jp L910e                    ; 9497
L949a:
	ld a,(L9513)                ; 949a
	or a                        ; 949d
	ld de,(L9522)               ; 949e
	jr nz,L94b2                 ; 94a2
	ld de,(L954a)               ; 94a4
	ld a,(L953b)                ; 94a8
	or a                        ; 94ab
	jr nz,L94b2                 ; 94ac
	ld de,(L9572)               ; 94ae
L94b2:
	ld ix,L901f                 ; 94b2
	ld (ix+1),e                 ; 94b6
	ld (ix+3),d                 ; 94b9
	ret                         ; 94bc
L94bd:
	cp $41                      ; 94bd
	jr nc,L94c4                 ; 94bf
	sub $30                     ; 94c1
	ret                         ; 94c3
L94c4:
	sub $41                     ; 94c4
	add a,$0a                   ; 94c6
	ret                         ; 94c8
L94c9:
	ld a,(ix+1)                 ; 94c9
	call L94bd                  ; 94cc
	rlca                        ; 94cf
	rlca                        ; 94d0
	rlca                        ; 94d1
	rlca                        ; 94d2
	ld c,a                      ; 94d3
	ld a,(ix+2)                 ; 94d4
	call L94bd                  ; 94d7
	or c                        ; 94da
	ret                         ; 94db
L94dc:
	call L94c9                  ; 94dc
	push ix                     ; 94df
	ld h,a                      ; 94e1
	inc ix                      ; 94e2
	inc ix                      ; 94e4
	call L94c9                  ; 94e6
	ld l,a                      ; 94e9
	pop ix                      ; 94ea
	ret                         ; 94ec
L94ed:
	db $00,$00,$00,$00,$00,$00,$00; 94ed
L94f4:
	db $00,$00,$00,$00,$00,$00,$00; 94f4
L94fb:
	dw L9503                    ; 94fb
	dw L9509                    ; 94fd
	dw L9509                    ; 94ff
	dw L9509                    ; 9501
L9503:
	db $00,$00,$00,$00,$7f,$7f  ; 9503
L9509:
	db $f4,$ff,$f9,$ff,$fe,$ff,$00,$00,$7f,$7f; 9509
L9513:
	db $00,$d0,$11,$00,$00,$00,$00,$03,$ff,$00,$00,$01,$00,$01,$01; 9513
L9522:
	db $20,$00,$00,$00,$00,$00,$78,$97,$00,$00,$00,$00,$00,$00,$00,$03; 9522
	db $95,$00,$00,$00,$00,$00,$00,$00,$00; 9532
L953b:
	db $00                      ; 953b
L953c:
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 953c
L9549:
	db $00                      ; 9549
L954a:
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00; 954a
	db $00,$00,$00,$00,$00,$00,$00,$00,$00; 955a
L9563:
	db $00                      ; 9563
L9564:
	db $00,$00,$00,$00,$00,$00,$00,$ff,$00,$00,$00,$00,$00,$00; 9564
L9572:
	db $05,$00,$00,$00,$00,$00,$b7,$96,$00,$00,$00,$00,$00,$00,$01,$00; 9572
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$39,$3a,$31,$30,$0d,$20,$44; 9582
	db $42,$20,$30,$3a,$35,$3a,$31,$3a,$30,$3a,$30,$3a,$31,$35,$0d,$53; 9592
	db $54,$44,$4f,$4d,$0d,$20,$4c,$44,$20,$44,$45,$2c,$54,$45,$4b,$49; 95a2
	db $42,$46,$0d,$20,$4c,$44,$20,$41,$2c,$33,$0d,$53,$54,$44,$41,$0d; 95b2
	db $20,$4c,$44,$20,$48,$4c,$2c,$44,$4f,$4d,$31,$0d,$20,$4c,$44,$20; 95c2
	db $42,$43,$2c,$31,$39,$0d,$20,$4c,$44,$49,$52,$0d,$20,$4c,$44,$20; 95d2
	db $43,$2c,$32,$34,$2d,$31,$39,$0d,$20,$45,$58,$20,$44,$45,$2c,$48; 95e2
	db $4c,$0d,$20,$41,$44,$44,$20,$48,$4c,$2c,$42,$43,$0d,$20; 95f2
L9600:
	jp VZ_TUNE                  ; 9600 patched
	push ix                     ; 9605
	push iy                     ; 9607
	ld iy,L9513                 ; 9609
	ld de,L9672                 ; 960d
	or a                        ; 9610
	jp p,L961b                  ; 9611
	ld iy,L9563                 ; 9614
	ld de,L967c                 ; 9618
L961b:
	and $7f                     ; 961b
	add a,a                     ; 961d
	ld l,a                      ; 961e
	ld h,$00                    ; 961f
	add hl,de                   ; 9621
	ld e,(hl)                   ; 9622
	inc hl                      ; 9623
	ld d,(hl)                   ; 9624
	ld (iy+21),e                ; 9625
	ld (iy+22),d                ; 9628
	ld (iy+0),$01               ; 962b
	ld (iy+1),$00               ; 962f
	ld (iy+2),$00               ; 9633
	ld (iy+3),$00               ; 9637
	ld (iy+4),$00               ; 963b
	ld (iy+5),$00               ; 963f
	ld (iy+6),$00               ; 9643
	ld (iy+8),$00               ; 9647
	ld (iy+14),$00              ; 964b
	ld (iy+15),$05              ; 964f
	ld (iy+16),$00              ; 9653
	ld (iy+29),$00              ; 9657
	xor a                       ; 965b
	ld (L9021+1),a              ; 965c
	ld a,$05                    ; 965f
	ld (L901f+1),a              ; 9661
	ld a,$c3                    ; 9664
	ld (MZW+$038),a             ; 9666
	ld hl,L9000                 ; 9669
	ld (MZW+$039),hl            ; 966c
	jp L9012                    ; 966f
L9672:
	dw L9684                    ; 9672
	dw L96b8                    ; 9674
	dw L96dd                    ; 9676
	dw L9715                    ; 9678
	dw L975a                    ; 967a
L967c:
	dw L9779                    ; 967c
	dw L991d                    ; 967e
	dw L96b7                    ; 9680
	dw L975a                    ; 9682
L9684:
	db $49,$46,$46,$45,$32,$26,$33,$4d,$30,$54,$32,$30,$55,$30,$30,$5c; 9684
	db $4f,$33,$4c,$31,$47,$23,$42,$45,$23,$46,$44,$43,$44,$2d,$42,$2b; 9694
	db $43,$2d,$41,$2b,$44,$2d,$47,$30,$43,$2d,$46,$42,$45,$47,$43,$46; 96a4
	db $41,$44,$43              ; 96b4
L96b7:
	db $3b                      ; 96b7
L96b8:
	db $26,$33,$4d,$30,$54,$34,$30,$55,$30,$30,$5c,$49,$30,$30,$43,$43; 96b8
	db $4f,$33,$4c,$31,$43,$44,$43,$44,$46,$47,$46,$47,$2b,$43,$44,$43; 96c8
	db $44,$45,$30,$47,$3b      ; 96d8
L96dd:
	db $26,$33,$4d,$30,$54,$34,$30,$55,$30,$30,$5c,$49,$30,$30,$44,$44; 96dd
	db $4f,$32,$4c,$30,$23,$42,$42,$23,$41,$41,$23,$47,$47,$23,$46,$46; 96ed
	db $45,$23,$44,$44,$23,$43,$43,$2d,$23,$42,$42,$23,$41,$41,$23,$47; 96fd
	db $47,$23,$46,$46,$45,$44,$43,$3b; 970d
L9715:
	db $26,$33,$54,$31,$30,$55,$30,$30,$5c,$4f,$31,$4c,$32,$3e,$30,$30; 9715
	db $31,$30,$43,$47,$46,$23,$44,$43,$23,$46,$47,$42,$2b,$43,$53,$30; 9725
	db $31,$37,$37,$23,$44,$2d,$3b,$41,$46,$42,$2b,$43,$46,$42,$53,$30; 9735
	db $32,$45,$30,$53,$30,$31,$37,$37,$53,$30,$37,$34,$34,$46,$30,$53; 9745
	db $30,$32,$32,$32,$3b      ; 9755
L975a:
	db $26,$33,$54,$32,$30,$55,$30,$30,$5c,$4c,$30,$4f,$33,$42,$23,$41; 975a
	db $41,$23,$47,$47,$23,$46,$46,$45,$23,$44,$44,$23,$43,$43,$3b; 976a
L9779:
	db $26,$33,$54,$45,$30,$55,$30,$30,$49,$30,$30,$31,$32,$28,$5b,$32; 9779
	db $4f,$32,$4c,$35,$48,$32,$46,$36,$45,$33,$45,$37,$37,$2d,$47,$41; 9789
	db $2b,$46,$36,$45,$33,$45,$37,$37,$52,$46,$36,$45,$33,$45,$37,$37; 9799
	db $44,$45,$46,$39,$23,$47,$36,$47,$36,$46,$4a,$45,$39,$35,$2d,$45; 97a9
	db $47,$2b,$44,$23,$43,$38,$2d,$23,$41,$41,$37,$41,$32,$47,$32,$46; 97b9
	db $32,$45,$46,$33,$44,$33,$37,$44,$36,$44,$33,$45,$33,$46,$33,$33; 97c9
	db $47,$33,$41,$38,$23,$47,$2b,$46,$37,$44,$37,$45,$39,$35,$2d,$45; 97d9
	db $47,$2b,$44,$23,$43,$39,$33,$45,$33,$43,$33,$23,$41,$33,$41,$33; 97e9
	db $47,$33,$46,$33,$45,$33,$44,$38,$45,$46,$32,$45,$32,$46,$32,$47; 97f9
	db $32,$46,$32,$47,$32,$41,$37,$47,$33,$2b,$47,$33,$37,$4c,$31,$41; 9809
	db $23,$41,$42,$2b,$43,$44,$23,$44,$45,$5d,$4c,$33,$48,$32,$4f,$32; 9819
	db $41,$41,$47,$41,$52,$37,$52,$35,$52,$33,$41,$42,$2b,$43,$36,$4a; 9829
	db $4f,$32,$42,$42,$41,$42,$52,$37,$52,$35,$52,$33,$42,$2b,$43,$44; 9839
	db $36,$2d,$41,$41,$47,$41,$52,$37,$52,$39,$4f,$31,$43,$43,$2d,$42; 9849
	db $2b,$43,$52,$37,$52,$33,$43,$44,$45,$47,$45,$44,$43,$43,$43,$2d; 9859
	db $42,$2b,$43,$52,$37,$52,$33,$47,$2d,$41,$2b,$43,$45,$2d,$41,$2b; 9869
	db $43,$44,$2d,$42,$42,$41,$42,$52,$37,$4f,$31,$43,$35,$2d,$42,$35; 9879
	db $2b,$43,$35,$2d,$41,$41,$47,$41,$52,$37,$52,$39,$4c,$33,$48,$32; 9889
	db $4f,$32,$41,$41,$47,$41,$52,$37,$52,$35,$52,$33,$41,$42,$2b,$43; 9899
	db $36,$4a,$4f,$32,$42,$42,$41,$42,$52,$37,$52,$35,$52,$33,$42,$2b; 98a9
	db $43,$44,$36,$2d,$41,$41,$47,$41,$52,$37,$52,$39,$4f,$31,$43,$43; 98b9
	db $2d,$42,$2b,$43,$52,$37,$52,$33,$43,$44,$45,$47,$45,$44,$43,$43; 98c9
	db $43,$2d,$42,$2b,$43,$52,$37,$52,$33,$47,$2d,$41,$2b,$43,$45,$2d; 98d9
	db $41,$2b,$43,$44,$2d,$42,$42,$41,$42,$52,$37,$4f,$31,$43,$35,$2d; 98e9
	db $42,$35,$2b,$43,$35,$2d,$41,$41,$47,$41,$52,$37,$52,$33,$49,$30; 98f9
	db $30,$30,$30,$4f,$30,$46,$46,$52,$33,$47,$47,$33,$35,$49,$30,$30; 9909
	db $31,$32,$29,$3b          ; 9919
L991d:
	db $26,$33,$54,$38,$30,$55,$30,$30,$5c,$49,$30,$30,$30,$39,$4c,$30; 991d
	db $4f,$31,$28,$43,$36,$52,$30,$44,$35,$53,$30,$34,$38,$34,$44,$35; 992d
	db $53,$30,$34,$38,$34,$44,$35,$53,$30,$34,$38,$34,$44,$35,$53,$30; 993d
	db $34,$38,$34,$44,$35,$53,$30,$34,$41,$34,$43,$36,$52,$30,$43,$36; 994d
	db $46,$37,$44,$36,$53,$30,$34,$41,$41,$52,$30,$29,$0d,$49,$44,$41; 995d
	db $54,$41,$0d,$20,$44,$42,$20,$30,$3a,$32,$30,$3a,$31,$32,$3a,$30; 996d
	db $3a,$33,$32,$3a,$32,$37,$0d,$20,$44,$42,$20,$31,$30,$3a,$30,$3a; 997d
	db $30,$3a,$31,$30,$3a,$31,$35,$3a,$37,$0d,$20,$44,$42,$20,$31,$30; 998d
	db $3a,$33,$35,$3a,$37,$3a,$31,$30,$3a,$35,$30,$3a,$32,$34,$0d,$20; 999d
	db $44,$42,$20,$31,$37,$3a,$32,$30,$3a,$34,$3a,$31,$37,$3a,$33,$32; 99ad
	db $3a,$31,$39,$0d,$20,$44,$53,$20,$34,$0d,$53,$54,$47,$4f,$44,$41; 99bd
	db $4e,$49,$0d,$20,$4c,$44,$20,$41,$2c,$34,$0d,$20,$4c,$44,$20,$44; 99cd
	db $45,$2c,$54,$45,$4b,$49,$42,$46,$0d,$23,$4f,$44,$41,$0d,$20,$4c; 99dd
	db $44,$20,$48,$4c,$2c,$47,$44,$54,$42,$4c,$0d,$20,$4c,$44,$20,$42; 99ed
	db $43,$2c,$32,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff; 99fd
	db $00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff; 9a0d
	db $00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff; 9a1d
	db $00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff; 9a2d
	db $00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff; 9a3d
	db $00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff; 9a4d
	db $00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff; 9a5d
	db $00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff; 9a6d
	db $00,$ff,$2b,$00,$93,$11,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 9a7d
	db $ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 9a8d
	db $ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 9a9d
	db $ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 9aad
	db $ff,$00,$ef,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 9abd
	db $ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 9acd
	db $ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 9add
	db $ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 9aed
	db $ff,$00,$ff,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff; 9afd
	db $00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff; 9b0d
	db $00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff; 9b1d
	db $00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff; 9b2d
	db $00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff; 9b3d
	db $00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff; 9b4d
	db $00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$2b,$00,$93,$11; 9b5d
	db $00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff; 9b6d
	db $00,$ff,$00,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 9b7d
	db $ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 9b8d
	db $ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 9b9d
	db $ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 9bad
	db $ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 9bbd
	db $ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 9bcd
	db $ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 9bdd
	db $ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 9bed
	db $ff,$00,$ff              ; 9bfd
L9c00:
	ld hl,WRK+$042              ; 9c00
	dec (hl)                    ; 9c03
	ret p                       ; 9c04
	ld (hl),$05                 ; 9c05
	ld hl,WRK+$03f              ; 9c07
	dec (hl)                    ; 9c0a
	jp m,L9c15                  ; 9c0b
	ld iy,(WRK+$040)            ; 9c0e
	jp L9c36                    ; 9c12
L9c15:
	ld (hl),$04                 ; 9c15
	ld a,$24                    ; 9c17
	call La000                  ; 9c19
	ld hl,(WRK+$040)            ; 9c1c
	ld iy,(WRK+$040)            ; 9c1f
	inc hl                      ; 9c23
	inc hl                      ; 9c24
	ld (WRK+$040),hl            ; 9c25
	ld a,(iy+0)                 ; 9c28
	cp $63                      ; 9c2b
	jp nz,L9c36                 ; 9c2d
	ld a,$02                    ; 9c30
	ld (WRK+$050),a             ; 9c32
	ret                         ; 9c35
L9c36:
	call L9d6d                  ; 9c36
	ret c                       ; 9c39
	ld a,(iy+0)                 ; 9c3a
	or a                        ; 9c3d
	jp p,L9c47                  ; 9c3e
	ld a,$01                    ; 9c41
	ld (WRK+$25b),a             ; 9c43
	ret                         ; 9c46
L9c47:
	dec a                       ; 9c47
	ret m                       ; 9c48
	cp $20                      ; 9c49
	ret nc                      ; 9c4b
	ld c,$01                    ; 9c4c
	call L9c5d                  ; 9c4e
	call L9d6d                  ; 9c51
	ret c                       ; 9c54
	ld a,(iy+1)                 ; 9c55
	dec a                       ; 9c58
	ret m                       ; 9c59
	cp $20                      ; 9c5a
	ret nc                      ; 9c5c
L9c5d:
	ld e,a                      ; 9c5d
	add a,$17                   ; 9c5e
	ld (ix+0),a                 ; 9c60
	ld d,$00                    ; 9c63
	ld a,e                      ; 9c65
	add a,a                     ; 9c66
	ld e,a                      ; 9c67
	ld hl,L9cf0                 ; 9c68
	add hl,de                   ; 9c6b
	ld e,(hl)                   ; 9c6c
	inc hl                      ; 9c6d
	ld d,(hl)                   ; 9c6e
	ex de,hl                    ; 9c6f
	ld a,c                      ; 9c70
	or a                        ; 9c71
	ld a,$ff                    ; 9c72
	jp z,L9c79                  ; 9c74
	ld a,$04                    ; 9c77
L9c79:
	ld (L9cb3+1),a              ; 9c79
	push ix                     ; 9c7c
	pop de                      ; 9c7e
	inc de                      ; 9c7f
	inc de                      ; 9c80
	inc de                      ; 9c81
	inc de                      ; 9c82
	ld bc,$0009                 ; 9c83
	ldir                        ; 9c86
	ld (ix+3),$1f               ; 9c88
L9c8c:
	ld a,$08                    ; 9c8c
	inc a                       ; 9c8e
	and $0f                     ; 9c8f
	ld (L9c8c+1),a              ; 9c91
	ld e,a                      ; 9c94
	ld d,$00                    ; 9c95
	ld hl,L9cdd                 ; 9c97
	add hl,de                   ; 9c9a
	ld a,(hl)                   ; 9c9b
	ld (ix+5),a                 ; 9c9c
	ld a,(WRK+$057)             ; 9c9f
	ld (ix+13),a                ; 9ca2
	ld a,(ix+0)                 ; 9ca5
	sub $17                     ; 9ca8
	ld e,a                      ; 9caa
	ld hl,L9cc0                 ; 9cab
	add hl,de                   ; 9cae
	ld a,(hl)                   ; 9caf
	ld (ix+14),a                ; 9cb0
L9cb3:
	ld a,$ff                    ; 9cb3
	ld (ix+7),a                 ; 9cb5
	push iy                     ; 9cb8
	call L9d87                  ; 9cba
	pop iy                      ; 9cbd
	ret                         ; 9cbf
L9cc0:
	db $00,$00,$00,$00,$00,$00,$00,$00,$00,$01,$00,$00,$00,$01,$00,$00; 9cc0
	db $00,$00,$00,$00,$00,$00,$01,$01,$01,$00,$00,$00,$00; 9cd0
L9cdd:
	db $1e,$3c,$28,$0a,$14,$00,$32,$18,$08,$2a,$23,$0f,$01,$3b,$2f,$13; 9cdd
	db $00,$00,$00              ; 9ced
L9cf0:
	dw L9d2e                    ; 9cf0
	dw L9d2e                    ; 9cf2
	dw L9d37                    ; 9cf4
	dw L9d37                    ; 9cf6
	dw L9d37                    ; 9cf8
	dw L9d37                    ; 9cfa
	dw L9d37                    ; 9cfc
	dw L9d37                    ; 9cfe
	dw L9d40                    ; 9d00
	dw L9d49                    ; 9d02
	dw L9d52                    ; 9d04
	dw L9d52                    ; 9d06
	dw L9d52                    ; 9d08
	dw L9d5b                    ; 9d0a
	dw L9d64                    ; 9d0c
	dw L9d52                    ; 9d0e
	dw L9d52                    ; 9d10
	dw L9d52                    ; 9d12
	dw L9d37                    ; 9d14
	dw L9d37                    ; 9d16
	dw L9d37                    ; 9d18
	dw L9d37                    ; 9d1a
	dw L9d64                    ; 9d1c
	dw L9d5b                    ; 9d1e
	dw L9d49                    ; 9d20
	dw L9d37                    ; 9d22
	dw L9d37                    ; 9d24
	dw L9d37                    ; 9d26
	dw L9d52                    ; 9d28
	dw L9d52                    ; 9d2a
	dw L9d37                    ; 9d2c
L9d2e:
	db $0b,$00,$00,$ff,$00,$00,$00,$2e,$00; 9d2e
L9d37:
	db $0b,$00,$00,$ff,$02,$00,$00,$2e,$00; 9d37
L9d40:
	db $0f,$00,$00,$ff,$00,$00,$00,$2e,$00; 9d40
L9d49:
	db $07,$00,$00,$ff,$00,$01,$00,$2e,$00; 9d49
L9d52:
	db $15,$00,$00,$ff,$00,$01,$00,$2e,$00; 9d52
L9d5b:
	db $0b,$00,$00,$ff,$02,$01,$00,$2e,$00; 9d5b
L9d64:
	db $15,$00,$00,$ff,$02,$01,$00,$2e,$00; 9d64
L9d6d:
	push bc                     ; 9d6d
	push de                     ; 9d6e
	ld ix,WRK+$079              ; 9d6f
	ld de,$0018                 ; 9d73
	ld b,$10                    ; 9d76
L9d78:
	ld a,(ix+0)                 ; 9d78
	or a                        ; 9d7b
	jp z,L9d84                  ; 9d7c
	add ix,de                   ; 9d7f
	djnz L9d78                  ; 9d81
	scf                         ; 9d83
L9d84:
	pop de                      ; 9d84
	pop bc                      ; 9d85
	ret                         ; 9d86
L9d87:
	ld (MZW+$010),ix            ; 9d87
	ld a,(ix+0)                 ; 9d8b
	sub $17                     ; 9d8e
	cp $20                      ; 9d90
	ret nc                      ; 9d92
	add a,a                     ; 9d93
	ld e,a                      ; 9d94
	ld d,$00                    ; 9d95
	ld hl,L9da1                 ; 9d97
	add hl,de                   ; 9d9a
	ld e,(hl)                   ; 9d9b
	inc hl                      ; 9d9c
	ld d,(hl)                   ; 9d9d
	ex de,hl                    ; 9d9e
	jp (hl)                     ; 9d9f
L9da0:
	ret                         ; 9da0
L9da1:
	dw L9da0                    ; 9da1
	dw L9da0                    ; 9da3
	dw L9da0                    ; 9da5
	dw L9da0                    ; 9da7
	dw L9da0                    ; 9da9
	dw L9da0                    ; 9dab
	dw L9da0                    ; 9dad
	dw L9da0                    ; 9daf
	dw L9da0                    ; 9db1
	dw L9da0                    ; 9db3
	dw L9da0                    ; 9db5
	dw L9da0                    ; 9db7
	dw L9da0                    ; 9db9
	dw L9df3                    ; 9dbb
	dw L9df3                    ; 9dbd
	dw L9da0                    ; 9dbf
	dw L9da0                    ; 9dc1
	dw L9da0                    ; 9dc3
	dw L9da0                    ; 9dc5
	dw L9da0                    ; 9dc7
	dw L9da0                    ; 9dc9
	dw L9da0                    ; 9dcb
	dw L9df3                    ; 9dcd
	dw L9df3                    ; 9dcf
	dw L9da0                    ; 9dd1
	dw L9e26                    ; 9dd3
	dw L9e2d                    ; 9dd5
	dw L9ddf                    ; 9dd7
	dw L9de4                    ; 9dd9
	dw L9de9                    ; 9ddb
	dw L9dee                    ; 9ddd
L9ddf:
	ld (ix+0),$32               ; 9ddf
	ret                         ; 9de3
L9de4:
	ld (ix+0),$33               ; 9de4
	ret                         ; 9de8
L9de9:
	ld (ix+0),$34               ; 9de9
	ret                         ; 9ded
L9dee:
	ld (ix+0),$35               ; 9dee
	ret                         ; 9df2
L9df3:
	ld b,$01                    ; 9df3
	ld (ix+7),$ff               ; 9df5
L9df9:
	push bc                     ; 9df9
	call L9d6d                  ; 9dfa
	jp c,L9e24                  ; 9dfd
	push ix                     ; 9e00
	pop de                      ; 9e02
	ld hl,(MZW+$010)            ; 9e03
	ld bc,$0018                 ; 9e06
	ldir                        ; 9e09
	ld a,r                      ; 9e0b
	and $0f                     ; 9e0d
	sub $07                     ; 9e0f
	add a,(ix+5)                ; 9e11
	ld (ix+5),a                 ; 9e14
	ld a,r                      ; 9e17
	and $0f                     ; 9e19
	add a,$05                   ; 9e1b
	ld (ix+7),a                 ; 9e1d
	pop bc                      ; 9e20
	djnz L9df9                  ; 9e21
	ret                         ; 9e23
L9e24:
	pop bc                      ; 9e24
	ret                         ; 9e25
L9e26:
	ld (ix+0),$1c               ; 9e26
	jp L9e31                    ; 9e2a
L9e2d:
	ld (ix+0),$35               ; 9e2d
L9e31:
	ld a,$1e                    ; 9e31
	ld (WRK+$042),a             ; 9e33
	xor a                       ; 9e36
	ld (WRK+$03f),a             ; 9e37
	ld b,$02                    ; 9e3a
	ld (ix+7),$ff               ; 9e3c
	ld iy,L9e67                 ; 9e40
L9e44:
	push bc                     ; 9e44
	call L9d6d                  ; 9e45
	jp c,L9e65                  ; 9e48
	push ix                     ; 9e4b
	pop de                      ; 9e4d
	ld hl,(MZW+$010)            ; 9e4e
	ld bc,$0018                 ; 9e51
	ldir                        ; 9e54
	ld a,(iy+0)                 ; 9e56
	inc iy                      ; 9e59
	add a,(ix+5)                ; 9e5b
	ld (ix+5),a                 ; 9e5e
	pop bc                      ; 9e61
	djnz L9e44                  ; 9e62
	ret                         ; 9e64
L9e65:
	pop bc                      ; 9e65
	ret                         ; 9e66
L9e67:
	db $0b,$16,$21,$2c,$41,$33,$0d,$20,$4c,$44,$20,$41,$2c,$34,$34,$0d; 9e67
	db $20,$4c,$44,$20,$28,$54,$45,$4b,$49,$42,$46,$29,$2c,$41,$0d,$20; 9e77
	db $4c,$44,$20,$28,$32,$34,$2a,$34,$2b,$54,$45,$4b,$49,$42,$46,$29; 9e87
	db $2c,$41,$0d,$20,$58,$4f,$52,$20,$41,$0d,$20,$4c,$44,$20,$28,$38; 9e97
	db $2b,$54,$45,$4b,$49,$42,$46,$29,$2c,$41,$0d,$20,$4c,$44,$20,$28; 9ea7
	db $32,$34,$2a,$34,$2b,$38,$2b,$54,$45,$4b,$49,$42,$46,$29,$2c,$41; 9eb7
	db $0d,$20,$52,$45,$54,$0d,$48,$41,$54,$42,$4c,$31,$0d,$20,$44,$42; 9ec7
	db $20,$34,$35,$3a,$30,$3a,$30,$3a,$32,$35,$3a,$31,$3a,$32,$36,$3a; 9ed7
	db $30,$3a,$30,$0d,$20,$44,$42,$20,$32,$3a,$31,$3a,$33,$3a,$34,$32; 9ee7
	db $3a,$37,$3a,$32,$3a,$31,$3a,$30,$0d; 9ef7
L9f00:
	db $12                      ; 9f00
L9f01:
	db $20,$1e                  ; 9f01
L9f03:
	db $04,$12,$20,$1e,$03,$12,$20,$1e,$02,$12,$20,$1e,$01,$12,$20,$1e; 9f03
	db $14,$12,$20,$1e,$13,$12,$20,$1e,$12,$12,$20,$1e,$11,$12,$20,$1e; 9f13
	db $24,$12,$20,$1e,$23,$12,$20,$1e,$22,$12,$20,$1e,$21,$12,$20,$1e; 9f23
	db $34,$12,$20,$1e,$33,$12,$20,$1e,$32,$12,$20,$1e,$31,$12,$20,$06; 9f33
	db $04,$12,$20,$06,$03,$12,$20,$06,$02,$12,$20,$06,$01,$12,$20,$06; 9f43
	db $14,$12,$20,$06,$13,$12,$20,$06,$12,$12,$20,$06,$11,$12,$20,$06; 9f53
	db $24,$12,$20,$06,$23,$12,$20,$06,$22,$12,$20,$06,$21,$12,$20,$06; 9f63
	db $34,$12,$20,$06,$33,$12,$20,$06,$32,$12,$20,$06,$31,$00,$00,$00; 9f73
	db $00,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 9f83
	db $ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 9f93
	db $ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 9fa3
	db $ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 9fb3
	db $ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 9fc3
	db $ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 9fd3
	db $ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00; 9fe3
	db $ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff,$00,$ff; 9ff3
