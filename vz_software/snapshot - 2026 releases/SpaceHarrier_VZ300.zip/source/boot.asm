
	DEVICE NONE
	OUTPUT "boot.bin"
	org $7B00
boot:
	di
	ld sp,$7AF0
	ld a,1
	out ($3a),a            ; BennVenn: VZ300 memory mode
	xor a
	ld ($6800),a           ; mode(0), speaker off
	ld a,%001
	out ($37),a            ; DOS window -> RAM bank 0
	ld hl,BLOB_D0
	ld de,$4000
	call dzx0_standard     ; 1. platform layer + misc code -> D0
	ld a,%101
	out ($37),a            ; expansion window -> bank 1
	ld hl,BLOB_GFX
	ld de,$B800
	call dzx0_standard     ; 2. sprite graphics -> E1
	ld a,%011
	out ($37),a            ; DOS window -> RAM bank 1 (scratch), E bank 0
	ld hl,BLOB_F
	ld de,$4000
	ld bc,F_LEN
	ldir                   ; 3. park the fixed-RAM blob and phase 4 in D1
	ld hl,P4_SRC
	ld de,P4_DEST
	ld bc,P4_LEN
	ldir
	ld hl,BLOB_E0
	ld de,$B800
	call dzx0_standard     ; 4. main game code -> E0 (in place)
	jp P4_DEST
; -----------------------------------------------------------------------------
; ZX0 decoder by Einar Saukas & Urusergi
; "Standard" version (68 bytes only)
; -----------------------------------------------------------------------------
; Parameters:
;   HL: source address (compressed data)
;   DE: destination address (decompressing)
; -----------------------------------------------------------------------------

dzx0_standard:
        ld      bc, $ffff               ; preserve default offset 1
        push    bc
        inc     bc
        ld      a, $80
dzx0s_literals:
        call    dzx0s_elias             ; obtain length
        ldir                            ; copy literals
        add     a, a                    ; copy from last offset or new offset?
        jr      c, dzx0s_new_offset
        call    dzx0s_elias             ; obtain length
dzx0s_copy:
        ex      (sp), hl                ; preserve source, restore offset
        push    hl                      ; preserve offset
        add     hl, de                  ; calculate destination - offset
        ldir                            ; copy from offset
        pop     hl                      ; restore offset
        ex      (sp), hl                ; preserve offset, restore source
        add     a, a                    ; copy from literals or new offset?
        jr      nc, dzx0s_literals
dzx0s_new_offset:
        pop     bc                      ; discard last offset
        ld      c, $fe                  ; prepare negative offset
        call    dzx0s_elias_loop        ; obtain offset MSB
        inc     c
        ret     z                       ; check end marker
        ld      b, c
        ld      c, (hl)                 ; obtain offset LSB
        inc     hl
        rr      b                       ; last offset bit becomes first length bit
        rr      c
        push    bc                      ; preserve new offset
        ld      bc, 1                   ; obtain length
        call    nc, dzx0s_elias_backtrack
        inc     bc
        jr      dzx0s_copy
dzx0s_elias:
        inc     c                       ; interlaced Elias gamma coding
dzx0s_elias_loop:
        add     a, a
        jr      nz, dzx0s_elias_skip
        ld      a, (hl)                 ; load another group of 8 bits
        inc     hl
        rla
dzx0s_elias_skip:
        ret     c
dzx0s_elias_backtrack:
        add     a, a
        rl      c
        rl      b
        jr      dzx0s_elias_loop
; -----------------------------------------------------------------------------

P4_SRC:
	DISP P4_DEST
p4:
	ld hl,$4000
	ld de,$7B00
	call p4_dzx0           ; 5. fixed RAM code (overwrites this loader)
	jp GAME_GO
p4_dzx0:

        ld      bc, $ffff               ; preserve default offset 1
        push    bc
        inc     bc
        ld      a, $80
p4z_literals:
        call    p4z_elias             ; obtain length
        ldir                            ; copy literals
        add     a, a                    ; copy from last offset or new offset?
        jr      c, p4z_new_offset
        call    p4z_elias             ; obtain length
p4z_copy:
        ex      (sp), hl                ; preserve source, restore offset
        push    hl                      ; preserve offset
        add     hl, de                  ; calculate destination - offset
        ldir                            ; copy from offset
        pop     hl                      ; restore offset
        ex      (sp), hl                ; preserve offset, restore source
        add     a, a                    ; copy from literals or new offset?
        jr      nc, p4z_literals
p4z_new_offset:
        pop     bc                      ; discard last offset
        ld      c, $fe                  ; prepare negative offset
        call    p4z_elias_loop        ; obtain offset MSB
        inc     c
        ret     z                       ; check end marker
        ld      b, c
        ld      c, (hl)                 ; obtain offset LSB
        inc     hl
        rr      b                       ; last offset bit becomes first length bit
        rr      c
        push    bc                      ; preserve new offset
        ld      bc, 1                   ; obtain length
        call    nc, p4z_elias_backtrack
        inc     bc
        jr      p4z_copy
p4z_elias:
        inc     c                       ; interlaced Elias gamma coding
p4z_elias_loop:
        add     a, a
        jr      nz, p4z_elias_skip
        ld      a, (hl)                 ; load another group of 8 bits
        inc     hl
        rla
p4z_elias_skip:
        ret     c
p4z_elias_backtrack:
        add     a, a
        rl      c
        rl      b
        jr      p4z_elias_loop
; -----------------------------------------------------------------------------

	ENT
P4_LEN equ $-P4_SRC
BOOT_END:
	OUTEND
P4_DEST equ $6000
F_LEN equ 6036
BLOB_D0 equ $a94c
BLOB_GFX equ $7be0
BLOB_E0 equ $cb9e
BLOB_F equ $91b8
GAME_GO equ $7b00
