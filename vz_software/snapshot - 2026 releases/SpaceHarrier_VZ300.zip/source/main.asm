

; Space Harrier VZ300 port - main build file
	DEVICE NONE
	OUTPUT "F.bin"
	org $7B00
F_START:
GAME_GO:
	ld a,MAP_NORMAL
	out (MAPPORT),a
	ld sp,MZW+$f0
	jp L1200
	include "game_F.asm"
F_CODE_END:
	OUTEND
MZW:	ds $180
BUF:	ds $c00
GENBUF:	ds 112
VZBUF:	ds 512
F_END:
	ASSERT F_END <= $B800

	OUTPUT "E0.bin"
	org $B800
E0_START:
	include "game_E0.asm"
	include "../vzextra.asm"
E0_CODE_END:
	OUTEND
VRAM_SIZE equ $d60
VRAM:	ds VRAM_SIZE
WRK:	ds $400
E0_END:
	ASSERT E0_END <= $10000

	OUTPUT "D0.bin"
	org $4000
D0_START:
	include "../vzlayer.asm"
	include "game_D0.asm"
D0_END:
	OUTEND
	ASSERT D0_END <= $6800

	OUTPUT "E1.bin"
	org $B800
E1_START:
	include "game_E1.asm"
E1_END:
	OUTEND
	ASSERT E1_END <= $10000
