; ===========================================================================
; VZ300 platform layer for the Space Harrier port
; (runs in D0 = BennVenn DOS-window RAM bank 0, $4000-$67FF)
; ===========================================================================

VZVID       equ $7000
VZLATCH     equ $6800
MAPPORT     equ $37
MAP_NORMAL  equ %00000001       ; DOS window = RAM bank 0, E window = bank 0
MAP_GFX     equ %00000101       ; E window = bank 1 (sprite graphics)
LATCH_BASE  equ $10             ; mode(0), CSS 1 (buff/dark red text), speaker idle

; --------------------------------------------------------------------------
; ATTRMAP must be page aligned: MZ attribute -> VZ semigraphic byte for a
; uniform cell  ($80 | colour<<4 | mask ; mask $F full, $9 checker, $0 off)
; --------------------------------------------------------------------------
            align 256
ATTRMAP:    include "attrmap.inc"       ; 4 pages: 25% black stipple varies by cell
; MZ display code -> VZ character ($FF = not printable)
D2VZ:       include "d2vz.inc"
; ASCII -> MZ display code (for the monitor MSG replacement), $20..$5F
A2D:        include "a2d.inc"

; --------------------------------------------------------------------------
; VZ_BLIT - drop-in replacement for the MZ scaling sprite blitter ($8043).
; Same inputs: L = row, H = column, DE = sprite (11 bytes per row),
; B = width, C = height.  The original searched its row/column skip tables
; with CPIR for every pixel; here a rank lookup decides it once per sprite.
; Runs with the graphics bank mapped, so it lives outside the E window.
; --------------------------------------------------------------------------
VZ_BLIT:
            ld a,l
            cp $1f
            ret nc
            ld a,h
            cp $34
            ret nc
            push de
            ld e,h
            ld d,0
            ld h,d
            ld a,l
            add a,a
            add a,a
            add a,a
            ld l,a
            add hl,hl
            add hl,hl
            add hl,hl
            add hl,de
            ld de,BUF
            add hl,de
            pop de
            push iy
            ; build a straight-line routine for one sprite row: one unit per
            ; drawn column   ld a,(iy+n) / or a / jp m,skip / ld (hl),a / skip: inc l
            push hl
            push de
            push bc
            ld a,(L8078+1)          ; columns dropped at this scale
            ld c,a
            ld hl,(gen_key)         ; same width and scale as last time?
            ld a,b
            cp l
            jr nz,.regen
            ld a,c
            cp h
            jr z,.gdone
.regen:     ld l,b
            ld h,c
            ld (gen_key),hl
            ld a,c
            ld (.nc+1),a
            ld hl,GENBUF
            ld e,0                  ; source column offset
.g:         ld a,b
            push hl
            ld hl,RANKC
            add a,l
            ld l,a
            ld a,(hl)
            pop hl
.nc:        cp 0
            jr c,.gskip
            ld (hl),$fd
            inc hl
            ld (hl),$7e
            inc hl
            ld (hl),e
            inc hl
            ld (hl),$b7
            inc hl
            ld (hl),$fa
            inc hl
            push de
            ld d,h
            ld a,l
            add a,3                 ; -> the "inc l" of this unit
            ld e,a
            jr nc,1f
            inc d
1:          ld (hl),e
            inc hl
            ld (hl),d
            inc hl
            pop de
            ld (hl),$77
            inc hl
            ld (hl),$2c
            inc hl
.gskip:     inc e
            djnz .g
            ld (hl),$c9
.gdone:     pop bc
            pop de
            pop hl
            ld a,(L8069+1)          ; rows dropped at this scale
            ld (.nr+1),a
            ld a,c
            exx
            ld hl,RANKR             ; HL' walks the row ranks C .. 1
            add a,l
            ld l,a
            exx
.row:       exx
            ld a,(hl)
            dec hl
            exx
.nr:        cp 0
            jr c,.skiprow
            push hl
            push de
            pop iy
            call GENBUF
            pop hl
            ld a,$40
            add a,l
            ld l,a
            jr nc,.skiprow
            inc h
.skiprow:   ld a,11
            add a,e
            ld e,a
            jr nc,1f
            inc d
1:          dec c
            jp nz,.row
            pop iy
            ret
            align 64
RANKR:      include "rankr.inc"     ; 32 entries
RANKC:      include "rankc.inc"     ; 32 entries

; --------------------------------------------------------------------------
; VZ_SPRITES - replaces the MZ sprite pass at $809C.  The original scanned
; all 16 objects once for every depth 31..1 (496 checks per frame); this
; makes one pass, sorts the visible objects by depth (far first, stable)
; and calls the original drawing code for each.
; --------------------------------------------------------------------------
VZ_SPRITES:
        IFDEF DEBUG_SPR
            ld hl,BUF
            ld de,$F000
            ld bc,$c00
            ldir
            call ORIGSPR
            call bufsum
            ld (sumA),hl
            ld hl,$F000
            ld de,BUF
            ld bc,$c00
            ldir
            call SPR_REAL
            call bufsum
            ld de,(sumA)
            or a
            sbc hl,de
            ret z
            ld hl,(dbgerr)
            inc hl
            ld (dbgerr),hl
            ret
bufsum:     ld hl,0
            ld de,BUF
            ld bc,$c00
.bs:        ld a,(de)
            add a,l
            ld l,a
            jr nc,1f
            inc h
1:          add hl,hl
            jr nc,2f
            inc l
2:          inc de
            dec bc
            ld a,b
            or c
            jr nz,.bs
            ret
sumA:       dw 0
dbgerr:     dw 0
ORIGSPR:    ld a,$1f
            ld (.od),a
.dl:        ld ix,WRK+$79
            ld b,16
.ol:        push bc
            ld a,(.od)
            cp (ix+3)
            jr nz,.n
            bit 7,(ix+7)
            jr z,.n
            ld a,(ix+0)
            dec a
            jp m,.n
            call L80be
.n:         ld de,24
            add ix,de
            pop bc
            djnz .ol
            ld hl,.od
            dec (hl)
            jr nz,.dl
            ret
.od:        db 0
SPR_REAL:
        ENDIF
            ld ix,WRK+$79
            ld b,16
            ld hl,SPRLIST
            ld c,0
.scan:      ld a,(ix+3)
            or a
            jr z,.next
            cp 32
            jr nc,.next
            bit 7,(ix+7)
            jr z,.next
            ld a,(ix+0)
            or a
            jr z,.next
            cp $81
            jr nc,.next
            ; append (depth, ix) and bubble it towards the front
            ld a,(ix+3)
            ld (hl),a
            inc hl
            push ix
            pop de
            ld (hl),e
            inc hl
            ld (hl),d
            inc hl
            inc c
            push hl
            push bc
            dec hl
            dec hl
            dec hl                  ; HL -> new entry
            dec c
            jr z,.ins_done
.ins:       push hl
            dec hl
            dec hl
            dec hl                  ; previous entry
            ld a,(hl)
            pop de                  ; DE -> current entry
            push hl
            ex de,hl
            cp (hl)                 ; previous depth - current depth
            pop de                  ; DE -> previous
            jr nc,.ins_done         ; previous >= current: stop
            ; swap 3 bytes (HL current, DE previous)
            ld b,3
.sw:        ld a,(de)
            push af
            ld a,(hl)
            ld (de),a
            pop af
            ld (hl),a
            inc hl
            inc de
            djnz .sw
            ld hl,-3
            add hl,de               ; HL -> previous slot (now holds the new entry)
            dec c
            jr nz,.ins
.ins_done:  pop bc
            pop hl
.next:      ld de,24
            add ix,de
            djnz .scan
            ; draw in order
            ld a,c
            or a
            ret z
            ld hl,SPRLIST
.draw:      push bc
            inc hl
            ld e,(hl)
            inc hl
            ld d,(hl)
            inc hl
            push hl
            push de
            pop ix
            ld a,(ix+0)
            dec a
            call L80be
            pop hl
            pop bc
            dec c
            jr nz,.draw
            ret
SPRLIST:    ds 16*3

; --------------------------------------------------------------------------
; VZ_INIT - replaces the MZ-700 monitor/bank setup at the game entry
; --------------------------------------------------------------------------
VZ_INIT:
            di
            ld a,LATCH_BASE
            ld (VZLATCH),a
            ld (latch_shadow),a
            ld hl,VZVID
            ld de,VZVID+1
            ld bc,511
            ld (hl),$80
            ldir
            ; clear the MZ VRAM shadow
            ld hl,VRAM
            ld de,VRAM+1
            ld bc,VRAM_SIZE-1
            ld (hl),0
            ldir
            ret

latch_shadow: db 0
txtdirty:   db 1
txtfound:   db 0

; --------------------------------------------------------------------------
; VZ_KBROW - emulates  ld ($e000),a : ld a,($e001)
; in : A = MZ-700 keyboard row (0-9)
; out: A = MZ-700 style column bits (active low).  Other registers kept.
; Keys: Q up  A down  M left  , right   SPACE or . fire   (or joystick 1)
;       P pause   CTRL+- break   SHIFT shift   1-5 = F1-F5
; --------------------------------------------------------------------------
VZ_KBROW:
            push bc
            ld c,a
            ld b,$ff
            cp 7
            jp z,.r7
            cp 6
            jp z,.r6
            cp 8
            jp z,.r8
            cp 9
            jp z,.r9
            or a
            jp z,.r0
.done:      ld a,b
            pop bc
            ret
.r7:        call joyread            ; A = joystick bits (1=pressed)
            ld c,a
            ld a,($68fe)            ; X0: Q = bit4
            bit 4,a
            jr nz,1f
            set 0,c
1:          ld a,($68fd)            ; X1: A = bit4
            bit 4,a
            jr nz,1f
            set 1,c
1:          ld a,($68ef)            ; X4: M bit5, comma bit3
            bit 5,a
            jr nz,1f
            set 2,c
1:          bit 3,a
            jr nz,1f
            set 3,c
1:          bit 0,c
            jr z,1f
            res 5,b                 ; up
1:          bit 1,c
            jr z,1f
            res 4,b                 ; down
1:          bit 2,c
            jr z,1f
            res 2,b                 ; left
1:          bit 3,c
            jp z,.done
            res 3,b                 ; right
            jp .done
.r6:        call joyread
            bit 4,a
            jr nz,.fire
            ld a,($68ef)            ; X4: SPACE bit4, '.' bit1
            and %00010010
            cp %00010010
            jp z,.done
.fire:      res 4,b
            jp .done
.r8:        ld a,($68fb)            ; X2: SHIFT bit2
            bit 2,a
            jr nz,1f
            res 0,b
1:          ld a,($68fd)            ; X1: CTRL bit2
            bit 2,a
            jp nz,.done
            ld a,($68df)            ; X5: '-' bit2
            bit 2,a
            jp nz,.done
            res 7,b                 ; BREAK
            jp .done
.r9:        ld a,($68f7)            ; X3: 1=b4 2=b1 3=b3 4=b5 5=b0
            bit 4,a
            jr nz,1f
            res 7,b
1:          bit 1,a
            jr nz,1f
            res 6,b
1:          bit 3,a
            jr nz,1f
            res 5,b
1:          bit 5,a
            jr nz,1f
            res 4,b
1:          bit 0,a
            jp nz,.done
            res 3,b
            jp .done
.r0:        ld a,($68bf)            ; X6: P bit4 -> GRAPH (pause)
            bit 4,a
            jp nz,.done
            res 6,b
            jp .done

; joystick 1 -> A bits (1 = pressed): 0 up 1 down 2 left 3 right 4 fire

; --------------------------------------------------------------------------
; VZ_GETKY - monitor GETKY: A = nonzero if any key / fire is down, else 0.
; Also refreshes the VZ screen (the game polls this while showing static
; screens such as the title).
; --------------------------------------------------------------------------
VZ_GETKY:
            push hl
            ld hl,2
            add hl,sp
            ld a,(hl)
            inc hl
            ld h,(hl)
            ld l,a                  ; HL = caller's return address
            ld a,1
            push de
            ld de,L17a1
            or a
            sbc hl,de
            add hl,de
            jr z,.tm
            ld de,L17b0
            or a
            sbc hl,de
            add hl,de
            jr z,.tm
            ld de,L17be
            or a
            sbc hl,de
            jr z,.tm1
            xor a
            jr .tm
.tm1:       ld a,1
.tm:        pop de
            pop hl
            ld (titlemode),a
            call VZ_FRAME
            ld a,(titlemode)
            or a
            jr z,.plain
            call TITLE_MUSIC        ; plays a slice of the theme, A=1 on a key
            or a
            jr nz,.key
            ret
.plain:     call anykey
            ld a,0
            ret z
.key:       xor a
            ld (titlemode),a
            ld a,$0d
            ret

; --------------------------------------------------------------------------
; VZ_MSG - monitor MSG/MSGX: print the CR terminated ASCII string at DE at
; the cursor (MZW+$171 = X, MZW+$172 = Y) into the MZ VRAM shadow.
; --------------------------------------------------------------------------
VZ_MSG:
            push af
            push bc
            push de
            push hl
            ld a,1
            ld (txtdirty),a
.lp:        ld a,(de)
            inc de
            cp $0d
            jr z,.end
            push de
            ld c,a
            ; HL = VRAM + Y*40 + X
            ld a,(MZW+$172)
            ld l,a
            ld h,0
            add hl,hl
            add hl,hl
            add hl,hl               ; *8
            ld d,h
            ld e,l
            add hl,hl
            add hl,hl               ; *32
            add hl,de               ; *40
            ld a,(MZW+$171)
            ld e,a
            ld d,0
            add hl,de
            ld de,VRAM
            add hl,de
            ld a,c
            sub $20
            jr c,.ctl
            cp $40
            jr nc,.ctl
            ld e,a
            ld d,0
            push hl
            ld hl,A2D
            add hl,de
            ld a,(hl)
            pop hl
            ld (hl),a
.ctl:       ld a,(MZW+$171)
            inc a
            cp 40
            jr c,1f
            ld a,(MZW+$172)
            inc a
            ld (MZW+$172),a
            xor a
1:          ld (MZW+$171),a
            pop de
            jr .lp
.end:       pop hl
            pop de
            pop bc
            pop af
            ret

; --------------------------------------------------------------------------
; VZ_BELL - monitor BELL: show the screen, then a short beep
; --------------------------------------------------------------------------
VZ_BELL:
            call VZ_FRAME
            push af
            push bc
            push de
            ld de,$4020             ; D = period, E = cycles count
            ld b,120
            call tone
            pop de
            pop bc
            pop af
            ret

; tone: B = number of half periods, D = delay per half period
tone:       ld a,(latch_shadow)
            or $01                  ; speaker bits 0/5 must differ to drive the cone
.t1:        xor $21
            ld (VZLATCH),a
            ld c,d
.t2:        dec c
            jr nz,.t2
            djnz .t1
            ld a,(latch_shadow)
            ld (VZLATCH),a
            ret

; --------------------------------------------------------------------------
; VZ_TUNE - replaces the MZ interrupt-driven sound engine entry ($9600).
; A = tune number.  Plays a short effect.  All registers preserved.
; --------------------------------------------------------------------------
VZ_TUNE:
            push af
            push bc
            push de
            push hl
            bit 7,a
            jr nz,.out              ; music channel: not during play on the VZ
            cp 4
            jr z,.shot
            cp 3
            jr z,.boom
            or a
            jr z,.hit
            ld d,70                 ; 1,2: rising chirp
.up:        ld b,8
            call tone
            ld a,d
            sub 6
            ld d,a
            cp 16
            jr nc,.up
            jr .out
.shot:      ld d,30                 ; shot: falling "pew" ~3 kHz down to ~1 kHz
.sh1:       ld b,5
            call tone
            ld a,d
            add a,6
            ld d,a
            cp 96
            jr c,.sh1
            jr .out
.hit:       ld d,50                 ; explosion spawn: low falling blip
.ht1:       ld b,4
            call tone
            ld a,d
            add a,24
            ld d,a
            cp 190
            jr c,.ht1
            jr .out
.boom:      ld hl,(noise)           ; ~20 ms of noise
            ld bc,640
            ld a,(latch_shadow)
            ld e,a
.bm1:       add hl,hl               ; 16-bit LFSR
            jr nc,1f
            ld a,l
            xor $2d
            ld l,a
1:          ld a,l
            and $21
            xor e
            ld (VZLATCH),a
            ld a,c
            and 7
            add a,4
2:          dec a
            jr nz,2b
            dec bc
            ld a,b
            or c
            jr nz,.bm1
            ld (noise),hl
            ld a,e
            ld (VZLATCH),a
.out:       pop hl
            pop de
            pop bc
            pop af
            ret
noise:      dw $ace1

; --------------------------------------------------------------------------
; VZ_FRAME - convert the MZ-700 screen (shadow VRAM) to the VZ display.
;   row 0      : status line in text
;   rows 1-15  : 64x30 semigraphics from MZ rows 1-24
;   then text found in MZ rows 1-24 is overlaid as VZ characters
; All registers (including alternates and IX/IY) preserved.
; --------------------------------------------------------------------------
VZ_FRAME:
            push af
            push bc
            push de
            push hl
            push ix
            push iy
            exx
            push bc
            push de
            push hl
            exx
            ex af,af'
            push af
            ex af,af'
            ld a,(titlemode)
            or a
            jr z,.mz
            call title_draw         ; VZ title picture instead of the MZ one
            jr .tx
.mz:        ld hl,VZVID             ; no text to overlay: convert straight to
            ld a,(txtdirty)         ; the screen, skipping the off-screen copy
            or a
            jr z,1f
            ld hl,VZBUF
1:          ld (cbase),hl
            call conv_playfield
            ld a,(txtdirty)
            or a
            jr z,.done
.tx:        call conv_hud
            ld a,(txtdirty)
            or a
            call nz,conv_text
            call present
            jr .out
.done:      ld hl,VZVID
            ld (hudbase),hl
            call conv_hud
            ld hl,VZBUF
            ld (hudbase),hl
.out:
            ex af,af'
            pop af
            ex af,af'
            exx
            pop hl
            pop de
            pop bc
            exx
            pop iy
            pop ix
            pop hl
            pop de
            pop bc
            pop af
            ret

; ---- copy the finished picture to the screen during vertical blank ------
present:
.go:        ld hl,VZBUF
            ld de,VZVID
            ld bc,512
            ldir
            ret

; ---- two-sample cell combiner -------------------------------------------
; in : B = code of the upper sample, A = code of the lower sample (different)
; out: A = VZ byte.  Upper half follows B, lower half follows A.
cmb2:       ld c,a
            bit 7,b
            jr z,.tx                ; upper is a text block (dark red)
            ld a,b
            and $0c
            jr z,.topoff            ; upper sample black
            bit 7,c
            jr z,.tx
            ld a,c
            and $03
            jr z,.botoff            ; lower sample black
            ld a,b
            xor c
            and $70
            jr nz,.two              ; two colours: upper colour fills the cell
            ld a,c                  ; same colour, different shading
            and $03
            ld c,a
            ld a,b
            and $fc
            or c
            ret
.two:       ld a,b
            or $03
            ret
.botoff:    ld a,b
            and $fc
            ret
.topoff:    bit 7,c
            jr z,.tx2
            ld a,c
            and $f3
            ret
.tx2:       ld a,c
            ret
.tx:        ld a,b
            ret

; ---- cell combiner -------------------------------------------------------
; in : B,C,D,E = ATTRMAP codes of the TL,TR,BL,BR samples, H = ATTRMAP page
; out: A = VZ semigraphic byte
cell:       ld a,b
            cp c
            jr nz,cslow
            cp d
            jr nz,cslow
            cp e
            ret z
cslow:      ld a,b
            and c
            and d
            and e
            and $0f
            cp $0f
            jr nz,cmix
            ld a,b                  ; every pixel lit: majority colour, full cell
            cp c
            ret z
            cp d
            ret z
            cp e
            ret z
            ld a,c
            cp d
            ret z
            cp e
            ret z
            ld a,d
            cp e
            ret z
            ld a,b
            ret
cmix:       push hl
            ; turn each sample into colour ($00-$70) or $FF when its pixel is off
            ld a,b
            bit 3,a
            ld a,$ff
            jr z,1f
            ld a,b
            and $70
1:          ld b,a
            ld a,c
            bit 2,a
            ld a,$ff
            jr z,1f
            ld a,c
            and $70
1:          ld c,a
            ld a,d
            bit 1,a
            ld a,$ff
            jr z,1f
            ld a,d
            and $70
1:          ld d,a
            ld a,e
            bit 0,a
            ld a,$ff
            jr z,1f
            ld a,e
            and $70
1:          ld e,a
            ; majority colour
            ld a,b
            cp $ff
            jr z,.tu
            cp c
            jr z,.got
            cp d
            jr z,.got
            cp e
            jr z,.got
.tu:        ld a,c
            cp $ff
            jr z,.tv
            cp d
            jr z,.got
            cp e
            jr z,.got
.tv:        ld a,d
            cp $ff
            jr z,.first
            cp e
            jr z,.got
.first:     ld a,b
            cp $ff
            jr nz,.got
            ld a,c
            cp $ff
            jr nz,.got
            ld a,d
            cp $ff
            jr nz,.got
            ld a,e
            cp $ff
            jr nz,.got
            pop hl
            ld a,$80                ; all pixels off
            ret
.got:       ld h,a                  ; H = colour
            ld a,b
            or c
            or d
            or e
            jp p,.full              ; no $FF -> every pixel lit: fill the cell
            ld l,$80
            ld a,b
            cp h
            jr nz,1f
            set 3,l
1:          ld a,c
            cp h
            jr nz,1f
            set 2,l
1:          ld a,d
            cp h
            jr nz,1f
            set 1,l
1:          ld a,e
            cp h
            jr nz,1f
            set 0,l
1:          ld a,l
            or h
            pop hl
            ret
.full:      ld a,h
            or $8f
            pop hl
            ret

; ---- playfield ------------------------------------------------------------
            include "conv.inc"

; ---- status line ------------------------------------------------------------
; HUDMAP: 32 entries; <$80 = MZ row 0 column, $80+ = literal VZ char,
;         $FE/$FD = lives digits from MZ row 24 (cols 1,2), $FC = lives icon
conv_hud:
            ld hl,HUDMAP
            ld de,(hudbase)
            ld b,32
            ; lives shown?  (MZ row 24 col 1 is '=')
            ld a,(VRAM+24*40+1)
            cp $2b
            ld a,0
            jr nz,1f
            inc a
1:          ld (lives_on),a
.lp:        ld a,(hl)
            inc hl
            cp $fc
            jr nc,.lives
            bit 7,a
            jr nz,.lit
            push hl
            ld l,a
            ld h,0
            push de
            ld de,VRAM
            add hl,de
            ld a,(hl)
            ld l,a
            ld h,0
            ld de,D2VZ
            add hl,de
            ld a,(hl)
            pop de
            pop hl
            cp $ff
            jr nz,.put
            ld a,$20
            jr .put
.lit:       and $7f
.put:       ld (de),a
            inc de
            djnz .lp
            ret
.lives:     ld c,a
            ld a,(lives_on)
            or a
            ld a,$20
            jr z,.put
            ld a,c
            cp $fc
            ld a,$b3                ; icon: red semigraphic figure
            jr z,.put
            push hl
            push de
            ld hl,VRAM+24*40+1
            ld a,c
            cp $fe
            jr z,1f
            inc hl
1:          ld l,(hl)
            ld h,0
            ld de,D2VZ
            add hl,de
            ld a,(hl)
            pop de
            pop hl
            cp $ff
            jr nz,.put
            ld a,$20
            jr .put
lives_on:   db 0
hudbase:    dw VZBUF
gen_key:    dw $ffff
cbase:      dw VZBUF

HUDMAP:     db $80+'H'-$40+$40, $80+'I'-$40+$40     ; inverse "HI"
            db 4,5,6,7,8,9,10,11,12
            db $80+$20
            db $80+'S'-$40+$40, $80+'C'-$40+$40     ; inverse "SC"
            db 21,22,23,24,25,26,27,28,29
            db $80+$20
            db $80+'S'-$40+$40, $80+'T'-$40+$40     ; inverse "ST"
            db 37,38
            db $80+$20
            db $fc,$fe,$ff

; ---- title logo -----------------------------------------------------------
; When the MZ title sign has finished zooming in, replace it with a sign
; drawn for the VZ's 64x32 resolution.
conv_logo:
            ; find the full-size MZ sign: "SPACE" letter row (42 42 42 06 at
            ; cols 14-17) with the "HARRIER" letter row (72 at col 14) 3 below
            ld ix,VRAM+$800+2*40
            ld c,2
.find:      ld a,(ix+14)
            cp $42
            jr nz,.next
            ld a,(ix+15)
            cp $42
            jr nz,.next
            ld a,(ix+16)
            cp $42
            jr nz,.next
            ld a,(ix+17)
            cp $06
            jr nz,.next
            push ix
            pop hl
            ld de,3*40+14
            add hl,de
            ld a,(hl)
            cp $72
            jr z,.found
.next:      ld de,40
            add ix,de
            inc c
            ld a,c
            cp 12
            jr c,.find
            ret
.found:     ; sign top = MZ row c-2 -> VZ text row address from TXROW
            ld a,c
            sub 3
            add a,a
            ld e,a
            ld d,0
            ld hl,TXROW
            add hl,de
            ld e,(hl)
            inc hl
            ld d,(hl)
            ld hl,9
            add hl,de
            ex de,hl                ; DE = destination
            ld hl,VZBUF+32*10+9     ; keep the sign above row 10
            or a
            sbc hl,de
            ret c
            ld hl,LOGO
            ld b,6
.row:       push bc
            ld b,18
.cell:      ; only replace cells that show the sign itself (black, yellow,
            ; orange or buff); anything else is a character in front of it
            ld a,(de)
            cp $80
            jr z,.put
            bit 7,a
            jr z,.keep
            and $70
            cp $10
            jr z,.put
            cp $70
            jr z,.put
            cp $40
            jr nz,.keep
.put:       ld a,(hl)
            ld (de),a
.keep:      inc hl
            inc de
            djnz .cell
            ex de,hl
            ld bc,32-18
            add hl,bc
            ex de,hl
            pop bc
            djnz .row
            ret
LOGO:       include "logo.inc"

; ---- text overlay ---------------------------------------------------------
; Runs of printable characters in MZ rows 1-24 are copied 1:1 onto the VZ
; screen at the matching row, centred on the same relative position.
conv_text:
            xor a
            ld (txtfound),a
            call .scan
            ld a,(txtfound)         ; nothing on screen: stop scanning until
            ld (txtdirty),a         ; the next message is printed
            ret
.scan:      ld a,(WRK+$3ff)         ; current "pixel" character
            ld (pixch),a
            ld ix,VRAM+40           ; MZ row 1
            ld iy,TXROW             ; VZ row address per MZ row
            ld c,1                  ; MZ row number
.row:       ld b,0                  ; column
.col:       ld a,b
            cp 40
            jr nc,.nextrow
            ; lives indicator area (row 24 col 0-2) is shown in the status line
            ld a,c
            cp 24
            jr nz,1f
            ld a,b
            cp 3
            jr nc,1f
            ld a,(lives_on)
            or a
            jr nz,.skip
1:          call .getch             ; A = char at column B, HL = D2VZ entry
            ld a,(pixch)
            cp e
            jr z,.skip
            ld a,e
            or a
            jr z,.skip              ; spaces never start a run
            ld a,(hl)
            cp $ff
            jr z,.skip
            ; start of a run at column B: find its end (last printable char)
            ld a,b
            ld (runst),a
            ld (runend),a
            xor a
            ld (spcnt),a
.ext:       inc b
            ld a,b
            cp 40
            jr nc,.emit
            call .getch
            ld a,(pixch)
            cp e
            jr z,.emit
            ld a,(hl)
            cp $ff
            jr z,.emit
            ld a,e
            or a
            jr nz,.nsp
            ld a,(spcnt)            ; space: may be inside the run (max 2)
            inc a
            ld (spcnt),a
            cp 3
            jr nc,.emit
            jr .ext
.nsp:       xor a
            ld (spcnt),a
            ld a,b
            ld (runend),a
            jr .ext
.emit:      call emitrun
            ld a,(runend)
            ld b,a
.skip:      inc b
            jr .col
.nextrow:   ld de,40
            add ix,de
            inc iy
            inc iy
            inc c
            ld a,c
            cp 25
            jr c,.row
            ret
; E = char at column B of current row, HL -> D2VZ[E]
.getch:     push ix
            pop hl
            ld e,b
            ld d,0
            add hl,de
            ld e,(hl)
            ld hl,D2VZ
            add hl,de
            ret

; emit the run [runst, runend] of the row at IX to the VZ row at (IY)
emitrun:    push bc
            ld a,1
            ld (txtfound),a
            ld a,(runend)
            ld hl,runst
            sub (hl)
            inc a                   ; length
            cp 33
            jr c,1f
            ld a,32
1:          ld (runlen),a
            ; centre: vx = round((2*start+len)*0.4) - len/2
            ld a,(runst)
            add a,a
            ld hl,runlen
            add a,(hl)
            ld e,a
            ld d,0
            ld hl,CENTAB
            add hl,de
            ld a,(runlen)
            srl a
            ld d,a
            ld a,(hl)
            sub d
            jr nc,1f
            xor a
1:          ld d,a                  ; vx
            ld a,(runlen)
            add a,d
            cp 33
            jr c,1f
            ld a,32
            ld hl,runlen
            sub (hl)
            ld d,a
1:          ; destination = (IY) + vx
            ld l,(iy+0)
            ld h,(iy+1)
            ld e,d
            ld d,0
            add hl,de
            ex de,hl                ; DE = VZ address
            ; source = IX + runst
            push ix
            pop hl
            ld a,(runst)
            ld c,a
            ld b,0
            add hl,bc
            ld a,(runlen)
            ld b,a
.lp:        push bc
            ld c,(hl)               ; display code
            push hl
            ld bc,$800
            add hl,bc
            ld a,(hl)               ; attribute
            and 7
            ld a,0
            jr nz,1f
            ld a,$40                ; dark background -> inverse
1:          ld (invflag),a
            pop hl
            pop bc
            push bc
            push hl
            ld l,(hl)
            ld h,0
            ld bc,D2VZ
            add hl,bc
            ld a,(hl)
            cp $ff
            jr nz,1f
            ld a,$20
1:          ld hl,invflag
            or (hl)
            ld (de),a
            pop hl
            pop bc
            inc hl
            inc de
            djnz .lp
            pop bc
            ret

pixch:      db 0
spcnt:      db 0
runst:      db 0
runend:     db 0
runlen:     db 0
invflag:    db 0
CENTAB:     include "centab.inc"
TXROW:      include "txrow.inc"
