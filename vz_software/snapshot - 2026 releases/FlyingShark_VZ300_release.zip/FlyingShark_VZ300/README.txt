FLYING SHARK  -  VZ300 conversion (from the ZX Spectrum version, Firebird/Graftgold 1987)
=====================================================================================

FILE
  FLYSHARK.VZ   load from the BennVenn SD loader (machine code, 27.4K, loads at $7AE9)

REQUIREMENTS
  VZ300 with the BennVenn SD loader + 128K RAM expansion (uses DOS RAM $4000-$67FF
  and expansion RAM $B800-$FFFF). Reset to return to the DOS.

CONTROLS
  Keyboard      Q up   A down   O left   P right
                SPACE or M fire
                B or N  bomb      (holding fire no longer drops a bomb)
                H pause / resume (fire also resumes)
                CTRL+Q  quit to title
  Joysticks     Both VZ joysticks work at the same time: directions + fire,
                ARM button = bomb. Default map: J1 directions $2C, J2 directions
                $29; bit 4 of $2E = J1 fire, $2D = J1 arm, $2B = J2 fire,
                $27 = J2 arm (standard VZ joystick ports).
                On the title screen: J = joystick on/off, C = joystick set-up
                (push each direction / press fire / press arm when prompted,
                SPACE skips an item and keeps its current setting).
  Title         1 / 2 = one or two players (alternating), fire = start
  Attract       title (with music) -> high scores -> DEMO. The demo plays about
                35 s of a stage (stages 1-4 in turn) with the computer flying.
                Fire during the demo starts a game; any other key/direction
                returns to the title.

WHAT'S IN IT
  * The original Spectrum game engine runs unchanged: enemy waves, collision,
    scoring, 4 stages (jungle airfield, sea/fleet, islands & harbour, city) and
    the stage loop.
  * Replaced with VZ code: screen renderer (mode(1) 128x64, 4 colours), sprite
    blitter, side panels, input, sound output, title / hiscore / game-over /
    name-entry screens, start-of-stage banner.
  * Artwork: every background tile was re-done for 4x3 VZ pixels with a colour
    scheme chosen by what the tile is (jungle green/yellow, sea blue/green with
    the original flowing animation, runway blue, buildings/ships red/yellow).
    Dithered textures stay dithered; busy cobbles were toned back. Key sprites
    (your plane, enemy planes, bullets) were hand drawn for the VZ; the rest
    were converted with ink levels and transparency.
  * Scaling: 2:1 horizontally, 8:3 vertically. The playfield shows 64 of the
    72 rows; the view eases up/down with your plane so it is always visible.
  * Music and sound: the original beeper title tune, stage-clear and hiscore
    jingles and all in-game effects play through the VZ speaker.
  * Speed matches the Spectrum (game logic at 16.7 frames/sec, 3 VZ frames per
    game frame; rendering is split across the three frames).

NOTES / KNOWN LIMITS
  * Only one colour set (CSS0) in play; the bomb blast flashes the palette.
  * Hiscores are kept until reset (no save).
  * Tested in an emulator model of the VZ300 + BennVenn hardware, not yet on a
    real machine.  Two real-hardware assumptions to watch:
      - the field-sync interrupt is level-held; the code waits for the sync
        level to change before re-enabling interrupts (polarity independent).
      - joystick ports read $FF when nothing is pressed (auto-detect; J toggles).

SOURCE
  flyshark_src.zip : sjasmplus sources (src/), build tools (tools/build.py etc),
  emulator test harnesses (emu/), NOTES.md (reverse-engineering notes).
