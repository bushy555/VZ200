;=============================================================================
; Deferred interrupt re-enable (see VZ_IRQ in vz_hw.asm)
;=============================================================================
irq_off:        DB 0            ; 1 = frame handled, interrupts held off until FS high

;-----------------------------------------------------------------------------
; vz_ckpt - called from frequently run code (the engine's hot loops, the
; renderer, key reads).  If the interrupt routine left interrupts off and
; the field sync has ended, switch them back on.  Preserves all registers.
;-----------------------------------------------------------------------------
vz_ckpt:
        PUSH AF
        LD A,(irq_off)
        OR A
        JR NZ,.c
        POP AF
        RET
.c:     LD A,(VZ_LATCH)
        RLA
        JR NC,.x                        ; FS still low
        XOR A
        LD (irq_off),A
        EI
.x:     POP AF
        RET

; vz_irq_resume - make sure interrupts are back on (waits for FS high)
vz_irq_resume:
        LD A,(irq_off)
        OR A
        RET Z
.w:     LD A,(VZ_LATCH)
        RLA
        JR NC,.w
        XOR A
        LD (irq_off),A
        EI
        RET

