;=============================================================================
; The Sentinel - VZ300 port layer
;
; Target: Dick Smith VZ300 + BennVenn SD loader with 128K RAM.
;
; The original ZX Spectrum game (Geoff Crammond / Firebird 1987) is reassembled
; from the generated source in build/gen/.  The game engine runs unchanged at
; its original addresses, apart from the block $6800-$7806 which collides with
; the VZ I/O latch and video RAM and is assembled at $4800-$5806 (the BennVenn
; DOS-area RAM).  This file then overlays the hardware-dependent routines
; (screen, keyboard, sound, interrupts) with VZ-native versions.
;
; Memory map (VZ):
;   $0000-$3FFF  VZ BASIC ROM (not used after boot)
;   $4000-$47FF  new VZ code (BennVenn DOS RAM, bank 0)
;   $4800-$5806  relocated game block (Spectrum $6800-$7806)
;   $5807-$5DFF  new VZ code / tables
;   $5E00-$67FF  game variables, landscape map etc (same addresses as Spectrum)
;   $6800-$6FFF  VZ keyboard / output latch
;   $7000-$77FF  VZ video RAM (128x64 4-colour mode)
;   $7807-$FFFF  game code and data (same addresses as Spectrum)
;=============================================================================

VZ_LATCH        EQU $6800       ; write: output latch, read: keyboard
VZ_VRAM         EQU $7000
LATCH_GFX       EQU %00001000   ; bit 3 = graphics mode (A/G)
LATCH_CSS       EQU %00010000   ; bit 4 = colour set select
SPK_ON          EQU %00000001   ; speaker drive bits (push-pull on bits 0/5)
SPK_OFF         EQU %00100000

        INCLUDE "vz_patches.asm"
        INCLUDE "vz_hw.asm"
        INCLUDE "vz_gfx.asm"
        INCLUDE "vz_fast.asm"
        ASSERT $ <= $4600

;-----------------------------------------------------------------------------
; second code area: $5807-$5DFF (BennVenn DOS RAM, above the relocated block)
;-----------------------------------------------------------------------------
        ORG $5807
        INCLUDE "vz_scroll.asm"
        INCLUDE "vz_sights.asm"
        INCLUDE "vz_scheme.asm"
        INCLUDE "vz_glyph.asm"
        ASSERT $ <= $5E00

;-----------------------------------------------------------------------------
; third code area: $6600-$67FF (vacated by the relocated block)
;-----------------------------------------------------------------------------
        ORG $6600
        INCLUDE "vz_sound.asm"
        INCLUDE "vz_div.asm"
        ASSERT $ <= $6800

;-----------------------------------------------------------------------------
; fourth code area: $C33C-$C4FF (Spectrum start-up data and debug code that
; are no longer needed).  $C500-$C5FF must keep its original bytes: the
; anti-cracker secret code stash at $C500+ is checked against them.
;-----------------------------------------------------------------------------
        ORG $C33C
        INCLUDE "vz_text.asm"
        INCLUDE "vz_gameover.asm"
        ASSERT $ <= $C500

;-----------------------------------------------------------------------------
; fifth code area: $BFB7-$C13B (the Spectrum sights drawing code, replaced)
;-----------------------------------------------------------------------------
        ORG $BFB7
        INCLUDE "vz_fx.asm"
        INCLUDE "vz_musicif.asm"
        ASSERT $ <= $C10A               ; $C10A holds the JP VZ_RemoveSights patch

;-----------------------------------------------------------------------------
; sixth code area: $B558-$B643 (body of the Spectrum pan-down scroll, replaced)
;-----------------------------------------------------------------------------
        ORG $B558
        INCLUDE "vz_code.asm"
        INCLUDE "vz_textplot.asm"
        ASSERT $ <= $B644

;-----------------------------------------------------------------------------
; seventh code area: $9955-$9A5E (body of the Spectrum DrawPolygonLines;
; $9953/4 and $9A5F.. are still written by the game and are left alone)
;-----------------------------------------------------------------------------
        ORG $9955
        INCLUDE "vz_hud.asm"
        INCLUDE "vz_musicsel.asm"
        ASSERT $ <= $9A5F

;-----------------------------------------------------------------------------
; eighth code area: $B442-$B4B0 (body of the Spectrum pan-left scroll, replaced;
; outside the DOS window, so it can switch the RAM bank there)
;-----------------------------------------------------------------------------
        ORG $B442
        INCLUDE "vz_remap.asm"
        ASSERT $ <= $B4B1

;-----------------------------------------------------------------------------
; ninth code area: $C166-$C252 (the Spectrum one-time start-up code after the
; JP VZ_Init patch at $C163; $C253/4 holds the saved stack pointer)
;-----------------------------------------------------------------------------
        ORG $C166
        INCLUDE "vz_tape.asm"
        ASSERT $ <= $C253

;-----------------------------------------------------------------------------
; tenth code area: $B4B4-$B522 (body of the Spectrum pan-right scroll, replaced)
;-----------------------------------------------------------------------------
        ORG $B4B4
        INCLUDE "vz_sentries.asm"
        ASSERT $ <= $B523

;-----------------------------------------------------------------------------
; eleventh code area: $B526-$B554 (rest of the Spectrum pan-up scroll, replaced)
;-----------------------------------------------------------------------------
        ORG $B526
        INCLUDE "vz_irqck.asm"
        ASSERT $ <= $B555

;-----------------------------------------------------------------------------
; twelfth code area: $9CD4-$9D08 (the original GetRowVisibility ray-march loop,
; replaced by vz_rowvis)
;-----------------------------------------------------------------------------
        ORG $9CD4
        INCLUDE "vz_ckrows.asm"
        ASSERT $ <= $9D09

;-----------------------------------------------------------------------------
; thirteenth code area: $9AA0-$9B9B (rest of the Spectrum DrawPolygonLines;
; the operand bytes $9A5F/$9A64/$9A99/$9A9D just below are still written by
; ConfigureBuffer and read by the VZ renderer)
;-----------------------------------------------------------------------------
        ORG $9AA0
        INCLUDE "vz_decay.asm"
        ASSERT $ <= $9AEB

;-----------------------------------------------------------------------------
; keyboard tables, in the freed Spectrum FillScreen / DrawPolygonLines bodies
; ($9896/7 and $9953/4 are pointers the game still writes, so they are skipped)
;-----------------------------------------------------------------------------
        ORG $9898
        INCLUDE "vz_keydata1.asm"
        ASSERT $ <= $98FD
        ORG $9900
        INCLUDE "vz_keydata2.asm"
        ASSERT $ <= $9953
        ORG $9A65
        INCLUDE "vz_keydata3.asm"
        ASSERT $ <= $9A99

;-----------------------------------------------------------------------------
; fourteenth / fifteenth code areas: the Spectrum's random-dots routine
; ($B9F3, replaced by VZ_RandomDots).  $BA47-$BA49 stay: the game-over code
; patches a JP there, which VZ_RandomDots checks.
;-----------------------------------------------------------------------------
        ORG $BA4A
        INCLUDE "vz_gameover2.asm"
        ASSERT $ <= $BADA
        ORG $B9F6
        INCLUDE "vz_fx2.asm"
        ASSERT $ <= $BA47
