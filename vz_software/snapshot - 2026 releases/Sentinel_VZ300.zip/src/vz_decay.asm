;=============================================================================
; vz_decay_end - replaces the end of DecayScreenToBlack ($BB72): the random
; pixel decay leaves a few pixels behind, so finish by clearing the view to
; the "paper" colour, as the Spectrum's screen ends up.
;=============================================================================
vz_decay_end:
        LD HL,$98ED                     ; as the original
        LD ($9953),HL
        LD A,C_BLU*$55
        CALL vz_mapcol
        LD HL,$7080                     ; view rows 4-63
        LD DE,$7081
        LD BC,$077F
        LD (HL),A
        LDIR
        LD B,0
        LD D,B
        RET

; patched in at $BADB (CALL $B138 in ShowGameOverScreen): note how the game
; ended - A is the decay count, $05 from a hyperspace without enough
; energy, $1E when absorbed
vz_go_note:
        LD (go_kind),A
        JP $B138
go_kind: DB $1E
