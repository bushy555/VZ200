;=============================================================================
; Sound.  The Spectrum beeper (port $FE bit 4) becomes the VZ speaker, driven
; push-pull through latch bits 0 and 5.  The latch also selects the video
; mode and colour set, so every write combines the speaker bits with the
; current mode (snd_on / snd_off, kept up to date by VZ_SetLatch).
; Routines are copied from the original with the port writes replaced; loop
; timings are otherwise unchanged (the VZ Z80 runs at 3.547MHz vs 3.5MHz).
;=============================================================================

SON     MACRO
        LD A,(snd_on)
        LD (VZ_LATCH),A
        ENDM
SOFF    MACRO
        LD A,(snd_off)
        LD (VZ_LATCH),A
        ENDM

; VZ_SetLatch: A = mode/colour-set bits (LATCH_GFX / LATCH_CSS)
VZ_SetLatch:
        LD (vz_latch),A
        LD (VZ_LATCH),A
        PUSH AF
        OR SPK_ON
        LD (snd_on),A
        POP AF
        PUSH AF
        OR SPK_OFF
        LD (snd_off),A
        POP AF
        RET

snd_on:  DB LATCH_GFX|SPK_ON
snd_off: DB LATCH_GFX|SPK_OFF

;--- $FD00: noise burst (uses the Spectrum ROM's first bytes as delays)
vz_sfx_fd00:
        LD HL,spec_rom0
        LD D,$01
        LD E,$46
.l:     SON
        LD B,D
.d1:    DJNZ .d1
        SOFF
        LD B,E
.d2:    DJNZ .d2
        LD B,(HL)
.d3:    DJNZ .d3
        LD B,(HL)
        INC HL
.d4:    DJNZ .d4
        INC D
        DEC E
        JP NZ,.l
        RET
spec_rom0:                              ; ZX Spectrum ROM $0000-$0045
        DB $F3,$AF,$11,$FF,$FF,$C3,$CB,$11,$2A,$5D,$5C,$22,$5F,$5C,$18,$43
        DB $C3,$F2,$15,$FF,$FF,$FF,$FF,$FF,$2A,$5D,$5C,$7E,$CD,$7D,$00,$D0
        DB $CD,$74,$00,$18,$F7,$FF,$FF,$FF,$C3,$5B,$33,$FF,$FF,$FF,$FF,$FF
        DB $C5,$2A,$61,$5C,$E5,$C3,$9E,$16,$F5,$E5,$2A,$78,$5C,$23,$22,$78
        DB $5C,$7C,$B5,$20,$03,$FD

;--- $FD21: three long beeps
vz_sfx_fd21:
        LD D,$03
.l:     SON
        LD BC,$1B58
.d1:    DEC BC
        LD A,B
        OR C
        JP NZ,.d1
        SOFF
        LD BC,$1B58
.d2:    DEC BC
        LD A,B
        OR C
        JP NZ,.d2
        DEC D
        JP NZ,.l
        RET

;--- $FD41/$FD42: falling sweep
vz_sfx_fd41:
        DI
vz_sfx_fd42:
        LD D,$1F
.l1:    LD C,$05
.l2:    SON
        LD B,D
.d1:    DJNZ .d1
        SOFF
        LD A,$20
        SUB D
        LD B,A
.d2:    DJNZ .d2
        LD B,$50
.d3:    DJNZ .d3
        DEC C
        JP NZ,.l2
        DEC D
        JP NZ,.l1
        RET

;--- $8D6B: scanner static
vz_sfx_scanner:
        LD A,($8D87)
        ADD A,$02
        LD ($8D87),A
        OR A
        JP P,.p
        NEG
.p:     ADD A,$0A
        LD B,A
        LD A,(snd_on)
        LD C,A
        LD A,(snd_off)
        XOR C
        LD C,A                          ; C = on ^ off
        LD A,(snd_off)
.l:     LD (VZ_LATCH),A
        NOP
        NOP
        NOP
        XOR C
        DJNZ .l
        RET

;--- tune player inner loop (was $E6F8-$E762); the outer player at $E600
; writes note pitches/durations into the operands marked vt_*
vz_tune_inner:
        LD B,$80
        CALL vt_loop
        CALL vt_loop
vt_loop:
        DEC D
        JP NZ,vt_v2
vt_d:   LD D,$FE
        SON
vt_don: LD A,$01
.a1:    DEC A
        JP NZ,.a1
        SOFF
vt_doff: LD A,$1F
.a2:    DEC A
        JP NZ,.a2
vt_v2:    DEC E
        JP NZ,vt_v3
vt_e:   LD E,$FF
        SON
vt_eon: LD A,$1F
.b1:    DEC A
        JP NZ,.b1
        SOFF
vt_eoff: LD A,$01
.b2:    DEC A
        JP NZ,.b2
vt_v3:    DEC H
        JP NZ,vt_v4
vt_h:   LD H,$71
        SON
vt_hon: LD A,$01
.c1:    DEC A
        JP NZ,.c1
        SOFF
vt_hoff: LD A,$0E
.c2:    DEC A
        JP NZ,.c2
vt_v4:    DEC L
        JP NZ,vt_v5
vt_l:   LD L,$AA
        SON
vt_lon: LD A,$01
.d1:    DEC A
        JP NZ,.d1
        SOFF
vt_loff: LD A,$15
.d2:    DEC A
        JP NZ,.d2
vt_v5:    DEC B
        JP NZ,vt_loop
        RET
