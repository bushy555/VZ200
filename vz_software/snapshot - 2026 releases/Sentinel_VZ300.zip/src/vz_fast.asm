;=============================================================================
; Speed-ups for the two hottest pieces of the original engine.  Both produce
; exactly the same results (memory and registers) as the code they replace;
; they are just written for speed.
;=============================================================================

;-----------------------------------------------------------------------------
; vz_rowvis - replaces the ray-march loop of GetRowVisibility at $9CD1-$9D08
; (about a third of all drawing time).  Each step adds the ray's deltas to
; three accumulators held in memory:
;   X ($6590/1)   += dX ($6597/8)
;   Z ($6594/5)   += dZ ($659D/E)
;   Y ($6535,$6592/3) += dY ($6599,$659A/B)   (24 bits)
; and stops when the ray's height drops below the tile altitude at
; (Z high, X high).  Here the accumulators live in IX, IY and C:HL and the
; deltas are patched into the loop as immediates: ~145 instead of ~310
; T-states per step.  B = step count on entry, as the original.
;-----------------------------------------------------------------------------
vz_rowvis:
        PUSH IX
        PUSH IY
        LD HL,($6597)
        LD (rv_dx+1),HL
        LD HL,($659D)
        LD (rv_dz+1),HL
        LD A,($6599)
        LD (rv_dyl+1),A
        LD HL,($659A)
        LD (rv_dyh+1),HL
        LD IX,($6590)
        LD IY,($6594)
        LD A,($6535)
        LD C,A
        LD HL,($6592)
rv_loop:
rv_dx:  LD DE,0
        ADD IX,DE                       ; X += dX
rv_dz:  LD DE,0
        ADD IY,DE                       ; Z += dZ
        LD A,C
rv_dyl: ADD A,0
        LD C,A                          ; Y low byte
rv_dyh: LD DE,0
        ADC HL,DE                       ; Y high word, with carry
        LD D,IYH
        LD E,IXH                        ; DE -> altitude of tile (Z hi, X hi)
        LD A,H
        EX DE,HL
        CP (HL)                         ; ray below the tile?
        EX DE,HL
        JR C,.out                       ; hit: B >= 1
        DJNZ rv_loop                    ; ran out of steps (visible): B = 0
.out:   CALL vz_ckpt
        LD A,C                          ; write the accumulators back
        LD ($6535),A
        LD ($6592),HL
        LD ($6590),IX
        LD ($6594),IY
        LD DE,(rv_dyh+1)                ; registers as the original leaves them
        LD C,IYH
        LD A,IXH
        LD L,A
        LD A,H
        LD H,C
        POP IY
        POP IX
        INC B
        DEC B
        JP Z,$9D09
        JP $9D0E

