
;=============================================================================
; vz_remap - recolour the view by the permutation in sc_perm.  The work is
; done in the BennVenn spare bank (bk_remap in the music module, with a
; 256-byte lookup table there), so this must sit outside $4000-$67FF.
; Interrupt state is preserved (it is also called from the IRQ colour keys).
;=============================================================================
vz_remap:
        LD HL,(sc_perm)                 ; read while bank 0 is mapped
        LD DE,(sc_perm+2)
        LD A,I                          ; interrupts on?  (read twice: the
        JP PE,.on                       ; NMOS Z80 can report "off" if an
        LD A,I                          ; interrupt arrives during LD A,I)
.on:    PUSH AF                         ; P/V = IFF2
        DI
        LD A,3                          ; DOS area: RAM bank 1
        OUT ($37),A
        LD ($4008),HL
        LD ($400A),DE
        CALL $4005
        LD A,1                          ; back to bank 0
        OUT ($37),A
        POP AF
        RET PO
        EI
        RET

;-----------------------------------------------------------------------------
; vz_tint - HL -> parameter block (in this area, outside the DOS window):
; colour map (4 bytes: new value for green, yellow, blue, red), first row,
; rows, first column, columns.  Applies the map to that part of video RAM
; through the spare bank's lookup table (bk_tint).
;-----------------------------------------------------------------------------
vz_tint:
        LD A,I
        JP PE,.on
        LD A,I
.on:    PUSH AF
        DI
        LD A,3
        OUT ($37),A
        LD DE,$4008                     ; bk_perm
        LD BC,4
        LDIR
        LD DE,$400F                     ; bk_tpar
        LD C,4
        LDIR
        CALL $400C
        LD A,1
        OUT ($37),A
        POP AF
        RET PO
        EI
        RET



