;=============================================================================
; Glyph renderer (moved out of area A4 so $C500-$C5FF keeps its original bytes)
;=============================================================================
; vz_glyph: draw character A at VZ pixel (tx_x), top row (tx_row), colour
; byte (tx_col), on a blue cell 5 wide x 7 tall
vz_glyph:
        PUSH AF
        LD A,(tx_col)                   ; colours for the current scheme
        CALL vz_mapcol
        LD (gl_fg),A
        LD A,C_BLU*$55
        CALL vz_mapcol
        LD (gl_bg),A
        POP AF
        AND $7F
        CP $20
        RET C
        CP $60
        JR C,.ok
        SUB $20                         ; lower case -> upper case
.ok:    SUB $20
        LD L,A
        LD H,0
        LD D,H
        LD E,L
        ADD HL,HL
        ADD HL,HL
        ADD HL,DE                       ; * 5
        LD DE,vz_font
        ADD HL,DE
        PUSH HL
        POP IX                          ; IX -> glyph
        LD A,(tx_row)
        PUSH AF
        DEC A
        LD (tx_row),A
        LD B,7
.r:     PUSH BC
        LD A,7
        SUB B
        DEC A                           ; glyph row -1..5
        LD E,0
        JP M,.blank
        CP 5
        JR NC,.blank
        LD E,A
        LD D,0
        PUSH IX
        POP HL
        ADD HL,DE
        LD E,(HL)                       ; 3 bits, bit 2 = left
.blank: LD A,(tx_x)
        DEC A
        LD C,A                          ; start one pixel left (cell margin)
        LD D,5
        SLA E                           ; align: bit 4 = first glyph pixel
.px:    PUSH DE
        LD A,E
        AND $10                         ; pixel bit for this column
        LD A,(gl_bg)
        JR Z,.bg
        LD A,(gl_fg)
.bg:    LD (tx_pix),A
        CALL tx_plot
        POP DE
        SLA E
        INC C
        DEC D
        JR NZ,.px
        LD A,(tx_row)
        INC A
        LD (tx_row),A
        POP BC
        DJNZ .r
        POP AF
        LD (tx_row),A
        RET

gl_fg:  DB 0
gl_bg:  DB 0
