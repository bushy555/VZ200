; Spectrum keyboard rows -> VZ (row address low byte, mask)
spec_keymap:
        DB $FB,$04, $FB,$10, $FB,$02, $FB,$08, $FB,$20  ; CAPS(=SHIFT) Z X C V
        DB $FD,$10, $FD,$02, $FD,$08, $FD,$20, $FD,$01  ; A S D F G
        DB $FE,$10, $FE,$02, $FE,$08, $FE,$20, $FE,$01  ; Q W E R T
        DB $F7,$10, $F7,$02, $F7,$08, $F7,$20, $F7,$01  ; 1 2 3 4 5
        DB $DF,$10, $DF,$02, $DF,$08, $DF,$20, $DF,$01  ; 0 9 8 7 6
        DB $BF,$10, $BF,$02, $BF,$08, $BF,$20, $BF,$01  ; P O I U Y
        DB $BF,$04, $7F,$02, $7F,$08, $7F,$20, $7F,$01  ; ENTER L K J H
        DB $EF,$10, $FD,$04, $EF,$20, $EF,$01, $FB,$01  ; SPACE SYM(=CTRL) M N B

