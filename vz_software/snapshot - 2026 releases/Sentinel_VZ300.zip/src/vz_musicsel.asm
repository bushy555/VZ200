;-----------------------------------------------------------------------------
; vz_music_sel - called from VZ_WaitKey once the keys are released.  The
; return address two levels up says which screen is waiting:
;   $7FE8 / $8057  title screen        -> a title theme (two take turns),
;                                         looped until a key
;   $B1D9          landscape preview   -> one of four short motifs
; Respects the game's sound on/off (Z): $BC47 is RET when sound is off.
;-----------------------------------------------------------------------------
vz_music_sel:
        PUSH HL
        PUSH DE
        CALL .sel
        POP DE
        POP HL
        RET
.sel:   LD A,($BC47)
        CP $C9
        RET Z
        LD HL,10                        ; skip .sel, DE, HL, VZ_WaitKey, $B907
        ADD HL,SP
        LD E,(HL)
        INC HL
        LD D,(HL)                       ; DE = who called the key wait
        LD HL,$7FE8
        OR A
        SBC HL,DE
        JR Z,.title
        LD HL,$8057
        OR A
        SBC HL,DE
        JR Z,.title
        LD HL,$B1D9
        OR A
        SBC HL,DE
        RET NZ
        LD A,($B9A0)                    ; preview: motif by landscape colour
        AND 3
        INC A
        JP vz_music
.title: LD A,(ms_alt)                   ; the two title themes take turns
        XOR 5
        LD (ms_alt),A
.loop:  CALL vz_music
        RET C                           ; a key: stop
        LD A,(ms_alt)                   ; tune ended: play it again
        JR .loop
ms_alt: DB 5

