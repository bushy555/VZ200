;=============================================================================
; Patches to the original game code (overlaid with ORG on the generated
; source).  Each patch notes the original Spectrum behaviour it replaces.
;=============================================================================

; --- start-up / restart (Spectrum: build screen tables, IM 2, clear screen)
        ORG $C163
        JP VZ_Init

; --- graphics core
        ORG $98FD                       ; DrawPolygonLines
        JP VZ_DrawPolygonLines
        ORG $9874                       ; FillScreen
        JP VZ_FillScreen

; --- keyboard
        ORG $C2A8                       ; key test (key number in A)
        JP VZ_KeyTest
        ORG $C255                       ; wait for a key press
        JP VZ_WaitKey
        ORG $C263                       ; read key character
        JP VZ_ReadKey
        ORG $BDAF                       ; IRQ: X/C/V colour keys (row CAPS-V)
        CALL VZ_SpecIN_FE
        NOP
        ORG $BDD4                       ; IRQ: Z sound on/off
        CALL VZ_SpecIN_FE
        NOP
        ORG $C305                       ; IRQ: SAVE SCREEN$ (keys E+V) -> VZ cassette
        JP vz_savescr

; --- ROM data read: the music routine reads the Spectrum ROM byte at $0070
        ORG $B11F
        LD A,$E1
        NOP

; --- sound: beeper routines replaced by VZ speaker versions
        ORG $FD00
        JP vz_sfx_fd00
        ORG $FD21
        JP vz_sfx_fd21
        ORG $FD41                       ; DI (kept), then the shared body
        DI
        ORG $FD42
        JP vz_sfx_fd42
        ORG $8D6B                       ; scanner static
        JP vz_sfx_scanner
        ; tune player: inner loop moved to vz_tune_inner, operands redirected
TUNEREF MACRO addr, op, target
        ORG addr
        IF op == 0
        LD A,(target)
        ELSE
        LD (target),A
        ENDIF
        ENDM
        ORG $E611
        CALL vz_tune_inner
        TUNEREF $E61A,0,vt_don+1
        TUNEREF $E621,1,vt_don+1
        TUNEREF $E624,0,vt_doff+1
        TUNEREF $E628,1,vt_doff+1
        TUNEREF $E62B,0,vt_eon+1
        TUNEREF $E632,1,vt_eon+1
        TUNEREF $E635,0,vt_eoff+1
        TUNEREF $E639,1,vt_eoff+1
        TUNEREF $E63C,0,vt_hon+1
        TUNEREF $E643,1,vt_hon+1
        TUNEREF $E646,0,vt_hoff+1
        TUNEREF $E64A,1,vt_hoff+1
        TUNEREF $E64D,0,vt_lon+1
        TUNEREF $E654,1,vt_lon+1
        TUNEREF $E657,0,vt_loff+1
        TUNEREF $E65B,1,vt_loff+1
        TUNEREF $E683,1,vt_d+1
        TUNEREF $E68C,1,vt_don+1
        TUNEREF $E691,1,vt_doff+1
        TUNEREF $E69E,1,vt_e+1
        TUNEREF $E6A7,1,vt_eon+1
        TUNEREF $E6AC,1,vt_eoff+1
        TUNEREF $E6B9,1,vt_h+1
        TUNEREF $E6C2,1,vt_hon+1
        TUNEREF $E6C7,1,vt_hoff+1
        TUNEREF $E6D4,1,vt_l+1
        TUNEREF $E6DD,1,vt_lon+1
        TUNEREF $E6E2,1,vt_loff+1

; --- screen output stubs (TODO: VZ versions)
        ORG $8D55                       ; scanner box (Spectrum $4216)
        JP VZ_ScannerFill
        ORG $BD57                       ; DrawIcon
        JP VZ_DrawIcon
        ORG $873A                       ; screen dissolve effects
        JP VZ_Dissolve873A
        ORG $873F
        JP VZ_Dissolve873F
        ORG $8A3C                       ; draw text glyph
        RET
        ORG $805E                       ; set text attributes + pattern table
        LD B,0                          ; (the attribute loop leaves B = 0)
        LD HL,$98ED
        LD ($9953),HL
        RET
        ORG $B957                       ; SetColourPalette
        LD ($B956),A
        JP VZ_SetPalette
        ORG $B975
        LD BC,0
        LD D,B
        RET
        ORG $B97D
        LD BC,0
        LD D,B
        RET
        ORG $B9EC
        LD B,0
        LD D,B
        RET
        ORG $B9F3                       ; object (de)materialise dots
        JP VZ_RandomDots
        ORG $B4B1                       ; scroll view: pan right
        JP VZ_PanRight
        ORG $B43F                       ; pan left
        JP VZ_PanLeft
        ORG $B523                       ; pan up
        JP VZ_PanUp
        ORG $B555                       ; pan down
        JP VZ_PanDown
        ORG $B3F9                       ; (debug: decrements attribute $5800)
        RET
        ORG $BFB4                       ; draw sights
        JP VZ_DrawSights
        ORG $C10A                       ; remove sights
        JP VZ_RemoveSights
        ORG $B3B4                       ; attribute rows for status texts
        LD B,0
        RET
        ORG $B3BF
        LD B,0
        RET
        ORG $BC09                       ; copy buffer area to screen
        JP VZ_ShowBufferRect
        ORG $895E                       ; PrintCharacter: render glyph on the VZ
        JP VZ_PrintChar
        ORG $AF87                       ; secret code: also print it as text
        JP vz_cc_start
        ORG $AFA9
        CALL vz_codecap

; --- colour keys (IRQ): C / V step the view colour, X restores the
; landscape's own; the VZ re-colours the view with a different scheme
        ORG $B996
        JP vz_scheme_key
        ORG $B99E
        JR $B996

; --- preview "n SENTRIES" caption (wrote straight to Spectrum screen $5085)
        ORG $8AE4
        JP vz_sentries

; --- engine speed-ups (vz_fast.asm): same results, faster code
        ORG $9CD1                       ; GetRowVisibility ray-march loop
        JP vz_rowvis
        ORG $93BC                       ; GetAngleFromCoords division
        JP vz_div
        ORG $9D64                       ; GetTileAltitudes: per-row checkpoint
        CALL vz_gta_row
        ORG $9D7C                       ; GetTileAltitudes smoothing: per-row checkpoint
        CALL vz_sm_row
        NOP
        ORG $9B0B
        CALL vz_grv
        ORG $9B1A
        CALL vz_grv
        ORG $A8F0
        CALL vz_tpe
        ORG $AB88
        CALL vz_tpe
        ORG $ABD4
        CALL vz_tpe
        ORG $B0D6
        CALL vz_poll_60eb
        JR NZ,$B0D6
        NOP
        NOP
        ORG $B2F5
        CALL vz_poll_c151
        JP P,$B2F5
        NOP

; --- title / entry-code screen: mark its pattern set as $98E5 (instead of
; $98E9, shared with the game-over view) so the VZ renderer can draw the
; title letters with plain faces; the Spectrum pattern tables themselves
; are not used by the VZ renderer
        ORG $AE0D
        LD HL,$98E5

; --- sights: the Spectrum pans the view down when the sights go below
; ySights = $20 (screen line 172, character row 21).  The VZ shows character
; rows 1-20 only, so pan when they go below $28 (line 164) instead; the
; sights then never move into the three rows the VZ doesn't show.
        ORG $BF83
        DB $28

; --- game over: finish the decays cleanly and add a game-over screen
        ORG $BB72                       ; end of DecayScreenToBlack
        JP vz_decay_end
        ORG $BB51                       ; end of ShowGameOverScreen
        JP vz_gameover
        ORG $BADB                       ; ShowGameOverScreen: note the cause
        CALL vz_go_note
