;=============================================================================
; Interrupt checkpoints inserted into GetTileAltitudes
;=============================================================================

; checkpoint once per row in GetTileAltitudes (patched in at $9D64)
vz_gta_row:
        CALL vz_ckpt
        LD HL,$6571
        RET

; checkpoint once per row in the tile smoothing loop (patched in at $9D7C)
vz_sm_row:
        CALL vz_ckpt
        LD L,$1E
        LD E,$3E
        RET

; checkpoint before each GetRowVisibility row ($9B0B, $9B1A)
vz_grv: CALL vz_ckpt
        JP $9B9C

; checkpoint before each TracePolygonEdge ($A8F0, $AB88, $ABD4)
vz_tpe: CALL vz_ckpt
        JP $A975

; polling loops that wait for the interrupt routine: checkpoint inside them
vz_poll_60eb:                           ; $B0D6: wait until ($60EB) = 3
        CALL vz_ckpt
        LD A,($60EB)
        CP $03
        RET
vz_poll_c151:                           ; $B2F5: wait until bit 7 of ($C151)
        CALL vz_ckpt
        LD A,($C151)
        AND A
        RET
