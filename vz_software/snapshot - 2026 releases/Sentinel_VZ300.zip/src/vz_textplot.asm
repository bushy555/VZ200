;=============================================================================
; text pixel plotting helpers
;=============================================================================
; plot pixel C on row (tx_row) in colour byte (tx_pix)
tx_plot:
        LD A,C
        CP 128
        RET NC
        LD A,(tx_row)
        CP 64
        RET NC
        CALL vzrow_addr
        LD A,C
        RRA
        RRA
        AND $1F
        LD E,A
        LD D,0
        ADD HL,DE
        LD A,C
        AND 3
        LD DE,pmask
        ADD A,E
        LD E,A
        JR NC,.p
        INC D
.p:     LD A,(DE)
        LD B,A
        CPL
        AND (HL)
        LD E,A
        LD A,(tx_pix)
        AND B
        OR E
        LD (HL),A
        RET

; vzrow_addr: A = VZ screen row (0..63) -> HL = address of its column 0,
; going through the view row table so that drawing while the view is hidden
; (see VZ_SetPalette) goes to the shadow copy
vzrow_addr:
        SUB 4
        JR NC,.view
        ADD A,4
        LD L,A
        LD H,0
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        LD DE,VZ_VRAM
        ADD HL,DE
        RET
.view:  LD E,0                          ; E = sub-row, A = view row index
.d3:    CP 3
        JR C,.q
        SUB 3
        INC E
        JR .d3
.q:     LD D,A                          ; D = sub-row (0..2), E = index
        LD A,E
        ADD A,A
        LD L,A
        LD H,0
        PUSH DE
        LD DE,vz_rowtab
        ADD HL,DE
        POP DE
        LD A,(HL)
        INC HL
        LD H,(HL)
        LD L,A
        DEC HL                          ; column 0
        LD A,D
        RRCA
        RRCA
        RRCA                            ; sub * 32
        ADD A,L
        LD L,A
        RET NC
        INC H
        RET
