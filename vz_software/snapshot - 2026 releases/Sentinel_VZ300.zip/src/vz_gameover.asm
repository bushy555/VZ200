;-----------------------------------------------------------------------------
; vz_bank1 - call routine HL in the spare RAM bank (DOS-area bank 1) with the
; 6-byte parameter block bk_par copied to $4016 there first.  Must sit
; outside $4000-$67FF.  Interrupt state is preserved.
;-----------------------------------------------------------------------------
vz_bank1:
        LD (.e+1),HL
        LD A,I
        JP PE,.on
        LD A,I
.on:    PUSH AF
        DI
        LD A,3
        OUT ($37),A
        LD HL,bk_par
        LD DE,$4016
        LD BC,6
        LDIR
.e:     CALL 0
        LD A,1
        OUT ($37),A
        POP AF
        RET PO
        EI
        RET
bk_par: DS 6                            ; paper, ink, font (2), sound, kind
