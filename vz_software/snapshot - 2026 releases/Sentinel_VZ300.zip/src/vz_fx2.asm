;=============================================================================
; More screen-effect helpers (fifteenth code area)
;=============================================================================

;-----------------------------------------------------------------------------
; vz_cls - fill the whole screen with the background (sky) colour
;-----------------------------------------------------------------------------
sp_last: DB 0                           ; last visible palette mode
vz_cls:
        LD A,C_BLU*$55
        CALL vz_mapcol
        LD HL,VZ_VRAM
        LD DE,VZ_VRAM+1
        LD BC,$7FF
        LD (HL),A
        LDIR
        RET

; the original per-pixel click ($8B2E-$8B4D) with the VZ speaker
dz_click:
        LD A,($8B2E)
        CP $C3                          ; silenced (JP $87A9 patched in)
        RET Z
        LD A,($8B32)
        DEC A
        LD ($8B32),A
        RET NZ
        LD A,($8738)
        LD B,A
        AND $7F
        INC A
        LD ($8B32),A
        LD A,(snd_off)
        LD (VZ_LATCH),A
.d:     DJNZ .d
        LD A,(snd_on)
        LD (VZ_LATCH),A
        RET

