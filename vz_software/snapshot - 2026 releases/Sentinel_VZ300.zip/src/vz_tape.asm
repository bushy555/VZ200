;=============================================================================
; SAVE SCREEN to cassette.  The Spectrum version saves the screen with the ROM
; tape routine when E and V are held together (checked by the interrupt
; routine via $C305).  The VZ version writes the 2K video RAM to the cassette
; port as a standard VZ machine-code file ("SENTSCRn", type $F1, $7000-$77FF),
; in the format the VZ ROM's CLOAD reads:
;
;   255 x $80 leader, 5 x $FE sync, type $F1, name + $00, short silent gap,
;   start (lo,hi), end+1 (lo,hi), data, 16-bit checksum (sum of the address
;   bytes and data, lo,hi), $00 guard byte.
;
; Each bit starts with a short cycle; a 1 adds two more short cycles, a 0 one
; long cycle.  Short half cycle ~ 290us, i.e. about 600 baud.  Bits are sent
; MSB first.  The cassette output is latch bits 1 and 2, driven together.
;
; The save takes about 30 seconds; the game is frozen meanwhile (we are inside
; the frame interrupt), as on the Spectrum.  The name's digit increments after
; each save.  Reload with:  MODE(1):CLOAD  (or a monitor/BLOAD).
;=============================================================================

TP_SHORT        EQU 73          ; DJNZ loops for ~1020 T-states (290us @ 3.547MHz)
TP_LONG         EQU 151         ; ~2040 T-states

vz_savescr:
        LD A,($68FE)                    ; row X0: E = bit 3 (active low)
        AND $08
        RET NZ
        LD A,($68FB)                    ; row X2: V = bit 5
        AND $20
        RET NZ
        LD E,255                        ; 255 x $80 leader
.lead:  LD A,$80
        CALL tp_byte
        DEC E
        JR NZ,.lead
        LD E,5
.sync:  LD A,$FE
        CALL tp_byte
        DEC E
        JR NZ,.sync
        LD A,$F1                        ; machine-code file
        CALL tp_byte
        LD HL,tp_name
.name:  LD A,(HL)
        PUSH HL
        CALL tp_byte
        POP HL
        LD A,(HL)
        INC HL
        OR A
        JR NZ,.name
        LD E,4                          ; gap (~4.6ms of silence)
.gap:   CALL tp_ll
        DEC E
        JR NZ,.gap
        LD HL,0
        LD (tp_sum),HL
        LD HL,VZ_VRAM                   ; start address
        LD A,L
        CALL tp_bsum
        LD A,H
        CALL tp_bsum
        LD A,L                          ; end address (exclusive) = $7800
        CALL tp_bsum
        LD A,H
        ADD A,8
        CALL tp_bsum
.data:  LD A,(HL)
        CALL tp_bsum
        INC HL
        LD A,H
        CP (VZ_VRAM>>8)+8
        JR NZ,.data
        LD HL,(tp_sum)
        LD A,L
        CALL tp_byte
        LD A,H
        CALL tp_byte
        XOR A                           ; guard byte
        CALL tp_byte
        CALL tp_sl                      ; leave the output low
        LD HL,tp_name+7                 ; next file name
        INC (HL)
        LD A,(HL)
        CP '9'+1
        JR C,.nx
        LD (HL),'0'
.nx:    LD A,(vz_latch)
        LD (VZ_LATCH),A
        RET

; byte A, adding it to the checksum
tp_bsum:
        PUSH HL
        PUSH AF
        LD HL,(tp_sum)
        ADD A,L
        LD L,A
        JR NC,.c
        INC H
.c:     LD (tp_sum),HL
        POP AF
        POP HL
        ; fall through

; byte A, MSB first
tp_byte:
        PUSH DE
        LD C,A
        LD D,8
.l:     RLC C
        JR NC,.z
        CALL tp_sh                      ; 1: three short cycles
        CALL tp_sl
        CALL tp_sh
        CALL tp_sl
        CALL tp_sh
        CALL tp_sl
        JR .n
.z:     CALL tp_sh                      ; 0: one short, one long cycle
        CALL tp_sl
        CALL tp_lh
        CALL tp_ll
.n:     DEC D
        JR NZ,.l
        POP DE
        RET

tp_sh:  LD B,TP_SHORT
        JR tp_hi
tp_lh:  LD B,TP_LONG
tp_hi:  LD A,(vz_latch)
        OR %00000110
        JR tp_out
tp_sl:  LD B,TP_SHORT
        JR tp_lo
tp_ll:  LD B,TP_LONG
tp_lo:  LD A,(vz_latch)
        AND %11111001
tp_out: LD (VZ_LATCH),A
.d:     DJNZ .d
        RET

tp_name: DB "SENTSCR0",0
tp_sum:  DW 0
