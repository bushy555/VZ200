; characters for VZ rows X0..X7, bits 5..0
vz_keychars:
        DB "RQE", 0, "WT"               ; X0
        DB "FAD", $7F, "SG"             ; X1 (CTRL = delete)
        DB "VZC", $7F, "XB"             ; X2 (SHIFT = delete)
        DB "413", 0, "25"               ; X3
        DB "M ,", 0, ".N"               ; X4
        DB "708", "-", "96"             ; X5
        DB "UPI", 13, "OY"              ; X6
        DB "J:K", 0, "LH"               ; X7

