;=============================================================================
; VZ native graphics for The Sentinel  (128 x 64, 4 colours, MC6847 CG2)
;
; Screen layout:
;   VZ rows 0-3     : status row (Spectrum character row 0: energy icons,
;                     scanner)
;   VZ rows 4-63    : 3D view.  Spectrum view character row i+1 (i = 0..19)
;                     is shown at VZ rows 4+3i .. 6+3i; Spectrum pixel lines
;                     1, 4 and 6 of each character row are sampled.  View
;                     rows 20-22 (the bottom 24 Spectrum lines) are cropped.
;   Each Spectrum byte column (8 pixels) is one VZ byte (4 pixels), so the
;   original column-based panning maps exactly onto the VZ screen.
;
; Logical colours (as the BBC/Spectrum engine uses them):
;   0 = blue (sky, edges, odd flat tiles), 1 = "black" (shaded slopes),
;   2 = "white" (lit slopes), 3 = landscape colour (even flat tiles)
; These are mapped to VZ 2-bit pixel patterns via pal_pat (two bytes per
; logical colour: even row, odd row), allowing two-colour dithers.
;=============================================================================

; VZ colour numbers in CSS 0
C_GRN   EQU 0
C_YEL   EQU 1
C_BLU   EQU 2
C_RED   EQU 3
SOLID   MACRO c
        DB c*$55, c*$55
        ENDM
CHECK   MACRO a, b
        DB (a<<6)|(b<<4)|(a<<2)|b, (b<<6)|(a<<4)|(b<<2)|a
        ENDM

        ; continue in the first code area ($4000-$47FF)

;-----------------------------------------------------------------------------
VZ_GfxInit:
        RET

VZ_ClearScreen:
        LD HL,VZ_VRAM
        LD DE,VZ_VRAM+1
        LD BC,$07FF
        LD (HL),C_BLU*$55
        LDIR
        RET

;-----------------------------------------------------------------------------
; VZ_DrawPolygonLines - replaces DrawPolygonLines at $98FD.
;
; Arguments (as the original):
;   ($6506) yPolygonTop, ($6504) yPolygonBottom  (polygon y, upwards)
;   $FB00+y / $FC00+y  left / right x of each polygon line
;   ($6519) polygon colours: bits 2-3 fill, bits 0-1 edge
;   ($607A) bit 7 set = blend edges into the fill colour (distant objects)
;   ($6555) 0 = draw on screen, 25 = draw into the screen buffer
;   window set up by ConfigureBuffer in the self-modified operands of the
;   original routine: xmin at $9A5F, width at $9A64, xmax at $9A99
;-----------------------------------------------------------------------------
VZ_DrawPolygonLines:
        CALL vz_ckpt
        PUSH IX
        LD A,($6506)                    ; mid line test: facing away?
        LD HL,$6504
        ADD A,(HL)
        RRA
        LD L,A
        LD H,$FC
        LD A,(HL)
        DEC H
        CP (HL)
        JP C,dp_exit
        ; colours
        LD A,($6519)
        LD C,A
        RRA
        RRA
        AND 3
        LD B,A                          ; B = fill colour
        LD A,($607A)
        OR A
        LD A,B
        JP M,.blend
        LD A,C
        AND 3
.blend: CALL vz_dp_cols                 ; A = edge colour, B = fill colour
        ; window
        LD A,($9A5F)
        LD (dp_xmin),A
        LD A,($9A64)
        LD (dp_width),A
        LD A,($9A99)
        LD (dp_xmax),A
        LD A,($6506)
        LD (dp_y),A
        LD HL,$6504
        CP (HL)
        JP C,dp_exit
dp_line:
        ; screen line s = $EF - y; most Spectrum lines are not sampled, so
        ; test that first
        LD A,(dp_y)
        CPL
        ADD A,$F0                       ; $EF - y
        LD E,A
        AND 7
        LD HL,sublut
        ADD A,L
        LD L,A
        JR NC,.s1
        INC H
.s1:    LD A,(HL)
        CP $FF
        JP Z,.skip                      ; this Spectrum line is not sampled
        LD D,A                          ; D = sub-row 0..2
        LD A,(dp_y)
        LD L,A
        LD H,$FC
        LD C,(HL)                       ; C = right x
        DEC H
        LD A,C
        CP (HL)
        JP C,dp_exit                    ; right < left: polygon finished
        LD B,(HL)                       ; B = left x
        LD A,E
        RRA
        RRA
        RRA
        AND $1F
        LD HL,$6555
        ADD A,(HL)                      ; row table index
        CP 50
        JP NC,dp_exit
        LD E,A
        ; parity for dithering: screen rows (index < 25) are one further down
        CP 25
        ADC A,D                         ; carry set if index < 25
        AND 1
        LD A,(dp_pat0)
        JR Z,.p0
        LD A,(dp_pat1)
.p0:    LD (dp_pat),A
        ; row address = rowtab[E] + D*32
        LD A,E
        ADD A,A
        LD L,A
        LD H,0
        LD IX,vz_rowtab
        EX DE,HL                        ; DE = index*2, H = sub-row
        ADD IX,DE
        LD A,H                          ; sub-row * 32
        RRCA
        RRCA
        RRCA
        LD E,A
        LD L,(IX+0)
        LD H,(IX+1)
        LD D,0
        ADD HL,DE
        LD (dp_row),HL
        ; --- right end
        LD A,(dp_xmin)
        LD E,A
        LD A,C
        SUB E
        JP C,dp_next                    ; right edge left of window: skip line
        LD HL,dp_width
        CP (HL)
        JR C,.rin
        LD A,(HL)                       ; clamp to window: no right edge pixel
        DEC A
        SRL A
        LD (dp_vr),A
        XOR A
        LD (dp_redge),A
        JR .left
.rin:   SRL A
        LD (dp_vr),A
        LD A,(dp_rok)                   ; 0 for the preview: left edges only
        LD (dp_redge),A
.left:  ; --- left end
        LD A,(dp_xmax)
        LD D,A
        LD A,B
        CP D
        JR C,.lok
        LD A,(dp_xmin)                  ; xmax may wrap past 255 (screen: 248)
        CP D
        JP C,dp_next                    ; left beyond window
.lok:   LD A,B
        SUB E
        JR NC,.lin
        XOR A
        LD (dp_vl),A
        LD (dp_ledge),A
        JR .draw
.lin:   SRL A
        LD (dp_vl),A
        LD A,1
        LD (dp_ledge),A
.draw:  CALL vz_span
dp_line.skip:                           ; unsampled line: still end the polygon
        LD A,(dp_y)                     ; at the first line with right < left
        LD L,A
        LD H,$FC
        LD A,(HL)
        DEC H
        CP (HL)
        JP C,dp_exit
dp_next:
        LD HL,dp_y
        LD A,(HL)
        DEC (HL)
        LD HL,$6504
        CP (HL)
        JP Z,dp_exit
        AND $0F                         ; every 16 lines: interrupt checkpoint
        CALL Z,vz_ckpt
        JP dp_line
dp_exit:
        POP IX
        LD B,0
        LD D,B
        RET

; sample lines 1,4,6 of each Spectrum character row
sublut: DB $FF,0,$FF,$FF,1,$FF,2,$FF

;-----------------------------------------------------------------------------
; vz_span: fill VZ pixels dp_vl..dp_vr on row dp_row with dp_pat, then draw
; edge pixels in dp_edge colour where dp_ledge / dp_redge are set.
;-----------------------------------------------------------------------------
vz_span:
        LD A,(dp_vl)
        LD B,A
        LD A,(dp_vr)
        CP B
        RET C
        LD C,A                          ; C = vr, B = vl
        LD HL,(dp_row)
        LD A,B
        RRA
        RRA
        AND $3F
        LD E,A                          ; E = left byte
        LD A,C
        RRA
        RRA
        AND $3F
        SUB E                           ; A = number of bytes - 1
        LD D,0
        ADD HL,DE                       ; HL -> left byte
        PUSH HL
        LD D,A
        LD A,B
        AND 3
        LD E,A
        PUSH HL
        LD HL,lmask
        ADD A,L
        LD L,A
        JR NC,.m1
        INC H
.m1:    LD A,(HL)                       ; left mask
        POP HL
        LD E,A
        LD A,D
        OR A
        JR NZ,.multi
        ; single byte: mask = lmask & rmask
        PUSH HL
        LD A,C
        AND 3
        LD HL,rmask
        ADD A,L
        LD L,A
        JR NC,.m2
        INC H
.m2:    LD A,(HL)
        POP HL
        AND E
        CALL .plot
        JR .edges
.multi: LD A,E
        CALL .plot                      ; left partial byte
        INC HL
        DEC D
        JR Z,.last
        LD A,(dp_pat)
.mid:   LD (HL),A
        INC HL
        DEC D
        JR NZ,.mid
.last:  PUSH HL
        LD A,C
        AND 3
        LD HL,rmask
        ADD A,L
        LD L,A
        JR NC,.m3
        INC H
.m3:    LD A,(HL)
        POP HL
        CALL .plot
.edges: POP HL                          ; HL -> left byte
        LD A,(dp_edge)
        LD (dp_pat),A                   ; (pattern no longer needed)
        LD A,(dp_ledge)
        OR A
        JR Z,.noled
        LD A,B
        AND 3
        CALL .pix
.noled: LD A,(dp_redge)
        OR A
        RET Z
        LD A,C
        RRA
        RRA
        AND $3F
        LD E,A
        LD A,B
        RRA
        RRA
        AND $3F
        LD D,A
        LD A,E
        SUB D
        LD E,A
        LD D,0
        ADD HL,DE
        LD A,C
        AND 3
        ; fall into .pix
.pix:   PUSH HL
        LD HL,pmask
        ADD A,L
        LD L,A
        JR NC,.m4
        INC H
.m4:    LD A,(HL)
        POP HL
        ; fall into .plot
.plot:  ; (HL) = (HL) & ~A | dp_pat & A
        PUSH BC
        LD B,A
        CPL
        AND (HL)
        LD C,A
        LD A,(dp_pat)
        AND B
        OR C
        LD (HL),A
        POP BC
        RET

lmask:  DB $FF,$3F,$0F,$03
rmask:  DB $C0,$F0,$FC,$FF
pmask:  DB $C0,$30,$0C,$03

dp_y:     DB 0
dp_xmin:  DB 0
dp_width: DB 0
dp_xmax:  DB 0
dp_vl:    DB 0
dp_vr:    DB 0
dp_ledge: DB 0
dp_redge: DB 0
dp_rok:   DB 1
dp_pat0:  DB 0
dp_pat1:  DB 0
dp_pat:   DB 0
dp_edge:  DB 0
dp_row:   DW 0

;-----------------------------------------------------------------------------
; VZ_FillScreen - replaces FillScreen at $9874.
;   A = first row table index (0 = screen, 25 = buffer), E = rows (24 -> 23),
;   C = width in BBC columns (Spectrum columns = 3C/4), ($604C) = background
;-----------------------------------------------------------------------------
VZ_FillScreen:
        CALL vz_ckpt
        LD (fs_row),A
        LD A,E
        CP $18
        JR C,.e
        DEC A
.e:     LD (fs_rows),A
        LD A,C
        RRCA
        LD L,A
        RRCA
        ADD A,L
        AND $3F
        LD (fs_cols),A
        LD A,($604C)
        AND 3
        ADD A,A
        LD E,A
        LD D,0
        LD HL,bg_pat
        ADD HL,DE
        LD A,(HL)
        LD (fs_p0),A
        INC HL
        LD A,(HL)
        LD (fs_p1),A
.row:   LD A,(fs_row)
        CP 50
        JR NC,.done
        ADD A,A
        LD E,A
        LD D,0
        LD HL,vz_rowtab
        ADD HL,DE
        LD E,(HL)
        INC HL
        LD D,(HL)
        LD A,(fs_row)
        CP 25
        CCF
        SBC A,0                         ; screen rows: parity one further down
        LD B,3
.sub:   PUSH BC
        PUSH DE
        INC A                           ; parity = row + sub (+1 for screen)
        PUSH AF
        AND 1
        LD A,(fs_p0)
        JR Z,.p
        LD A,(fs_p1)
.p:     LD H,D
        LD L,E
        LD (HL),A
        LD A,(fs_cols)
        DEC A
        JR Z,.one
        LD C,A
        LD B,0
        INC DE
        LDIR
.one:   POP AF
        POP DE
        LD HL,32
        ADD HL,DE
        EX DE,HL
        POP BC
        DJNZ .sub
        LD HL,fs_row
        INC (HL)
        LD HL,fs_rows
        DEC (HL)
        JR NZ,.row
.done:  LD B,0
        LD D,B
        RET

fs_row:  DB 0
fs_rows: DB 0
fs_cols: DB 0
fs_p0:   DB 0
fs_p1:   DB 0

;-----------------------------------------------------------------------------
; palettes
;-----------------------------------------------------------------------------
; Off-screen memory lives in the free upper part ($40-$FF) of the pages used
; by the original screen buffer; the lower part of each page is the tile
; altitude workspace of GetTileAltitudes.
VZ_HIDDEN EQU $D640                     ; screen view rows 21..23 (3 x 96 bytes)
vz_dummy  EQU $D7A0                     ; scratch row for anything below row 23

pal_ptr: DW pal_game

; pattern sets for the screens the Spectrum draws with its other pattern
; tables (built by sc_tables from the scheme's colours E, D, L, F):
;   pal_title   game-over view ($98E9): two colours, E paper and L ink
;   pal_letters title letters / entry code ($98E5): three colours, no D
;   pal_prev    landscape preview ($98ED): tiles in L and F, slopes as
;               dithers, edges in D on the E background
; The game view itself ($98F1) and the title's statue use the full scheme.
pal_title: DS 10                        ; 4 x (even, odd row), edge colour
pal_letters: DS 10
pal_prev:  DS 10

; vz_dp_cols - set dp_edge, dp_pat0/1 for edge colour A and fill colour B,
; choosing the pattern set the game selects through ($9953) as the Spectrum
; does: $98F1 game view (the full VZ colour scheme), $98E9 / $98ED two-colour
vz_dp_cols:
        LD C,A
        LD A,1
        LD (dp_rok),A
        LD A,($9953)
        LD HL,pal_game
        CP $F1                          ; the game view
        JR Z,.game
        LD HL,pal_title
        CP $E9                          ; game over
        JR Z,.two
        CP $E5                          ; title / entry code (see $AE0D patch):
        JR NZ,.prev                     ; letters (left of x = $D0) with plain
        PUSH HL                         ; faces for legibility, the statue
        LD A,($6506)                    ; with the Spectrum's dithers
        LD HL,$6504
        ADD A,(HL)
        RRA
        LD L,A
        LD H,$FC
        LD A,(HL)                       ; right x of the middle line
        POP HL
        CP $D0
        LD HL,pal_game                  ; the statue: the full scheme
        JR NC,.game
        LD HL,pal_letters
        JR .two
.prev:  XOR A                           ; $98ED: landscape preview, with
        LD (dp_rok),A                   ; thin (left-side) edges
        LD HL,pal_prev
.two:   LD A,C                          ; edge: as the Spectrum, a line in
        CP B                            ; the set's edge colour where the edge
        LD A,B                          ; colour differs from the fill, else
        JR Z,.ef                        ; the fill's pattern
        LD A,4
.ef:    ADD A,A
        LD E,A
        LD D,0
        PUSH HL
        ADD HL,DE
        LD A,(HL)
        POP HL
        JR .edge
.game:  LD A,C                          ; edge: colour number -> solid byte
        LD E,A
        ADD A,A
        ADD A,A
        OR E
        LD E,A
        ADD A,A
        ADD A,A
        ADD A,A
        ADD A,A
        OR E
.edge:  LD (dp_edge),A
        LD A,B
        ADD A,A
        LD E,A
        LD D,0
        ADD HL,DE
        LD A,(HL)
        LD (dp_pat0),A
        INC HL
        LD A,(HL)
        LD (dp_pat1),A
        RET

pal_game:                               ; logical colour 0..3, even/odd rows
        SOLID C_BLU                     ; 0 blue: edges, odd flat tiles
        CHECK C_RED, C_BLU              ; 1 dark slopes: red/blue dither
        CHECK C_YEL, C_GRN              ; 2 lit slopes: yellow/green dither
        SOLID C_GRN                     ; 3 even flat tiles

; background types for FillScreen (see BBC FillScreen):
;   0 = sky (blue/black rows), 1 = solid blue, 2 = dither blue/colour 3,
;   3 = solid black
bg_pat:
        DB C_BLU*$55, C_RED*$55         ; 0 sky: alternate blue / red rows
        SOLID C_BLU
        CHECK C_BLU, C_GRN
        SOLID C_BLU

;-----------------------------------------------------------------------------
; Row address table: index 0..24 = screen view rows (char rows 1..25),
; 25..49 = screen buffer rows.  Entries point at byte column 1.
;-----------------------------------------------------------------------------
vz_rowtab:
        DUP 20, i
        DW VZ_VRAM + (4 + 3*i)*32 + 1   ; screen rows 1..20 (visible)
        EDUP
        DW VZ_HIDDEN + 1                ; screen rows 21..23 (kept off-screen)
        DW VZ_HIDDEN + $60 + 1
        DW VZ_HIDDEN + $100 + 1
        DW vz_dummy + 1
        DW vz_dummy + 1
        DUP 25, j                       ; screen buffer rows 1..25
        DW $C640 + ((j+1)/2)*256 + ((j+1)%2)*$60 + 1
        EDUP

        ASSERT $ <= $4600
