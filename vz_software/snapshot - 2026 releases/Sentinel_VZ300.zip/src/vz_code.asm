;=============================================================================
; Secret entry code legibility: the code is shown as large 3D digits, which
; are hard to read at 128x64, so the digits are also printed as text when the
; screen is revealed.
;=============================================================================
vz_cc_start:                            ; replaces the first instruction at $AF87
        LD HL,cc_buf
        LD (cc_ptr),HL
        LD A,$80
        LD ($6060),A
        JP $AF8C

vz_codecap:                             ; replaces CALL $AF56 at $AFA9
        PUSH HL
        LD HL,(cc_ptr)
        LD (HL),A
        INC HL
        LD (cc_ptr),HL
        POP HL
        PUSH AF
        LD A,1
        LD (cc_pending),A
        POP AF
        JP $AF56

; called from VZ_SetPalette when the screen is revealed
vz_cc_print:
        LD A,(cc_pending)
        OR A
        RET Z
        XOR A
        LD (cc_pending),A
        LD A,44
        LD (tx_x),A
        LD A,49
        LD (tx_row),A
        LD A,C_YEL*$55
        LD (tx_col),A
        LD HL,cc_buf
        LD B,4
.l:     PUSH BC
        LD A,(HL)
        PUSH HL
        PUSH AF
        RRCA
        RRCA
        RRCA
        RRCA
        CALL .digit
        POP AF
        CALL .digit
        POP HL
        INC HL
        POP BC
        DJNZ .l
        RET
.digit: AND $0F
        ADD A,'0'
        PUSH IX
        CALL vz_glyph
        POP IX
        LD A,(tx_x)
        ADD A,5
        LD (tx_x),A
        RET

cc_pending: DB 0
cc_ptr:     DW cc_buf
cc_buf:     DS 4
