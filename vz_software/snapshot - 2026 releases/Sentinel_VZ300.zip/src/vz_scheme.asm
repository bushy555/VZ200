;=============================================================================
; Colour schemes.  The Spectrum colours the landscape view through the
; attribute ink at $BEA2: each landscape gets a colour from the table at
; $B9A1 (green, yellow, red, magenta, white, cyan...), and the C / V keys step
; through the colours while X restores the landscape's own.
;
; The VZ equivalent is a "scheme": an assignment of the four VZ colours to the
; four roles the renderer uses, plus the colour set (CSS):
;   E = edges, odd flat tiles, sky        (BBC logical colour 0)
;   D = dark half of the shaded-slope dither (BBC 1, "black")
;   L = light half of the lit-slope dither  (BBC 2, "white")
;   F = landscape colour, even flat tiles   (BBC 3)
; Slopes are two-colour checkerboard dithers: shaded = D/E, lit = L/F.
;
; Every scheme is a permutation of the four colour codes, so switching scheme
; re-colours what is already drawn by permuting pixel values in place (view
; rows of the screen, the off-screen shadow and the screen buffer).  The HUD
; rows 0-3 are left alone.
;=============================================================================

; scheme table, indexed by Spectrum ink colour 0-7: E, D, L, F, CSS
; (CSS 0 codes: 0 green 1 yellow 2 blue 3 red; CSS 1: 0 buff 1 cyan
;  2 magenta 3 orange)
vz_schemes:
        DB 3,2,1,0, 1                   ; 0 black   -> orange / magenta, cyan / buff
        DB 3,2,0,1, 0                   ; 1 blue    -> red sky, yellow land
        DB 2,0,1,3, 0                   ; 2 red     -> blue / green, yellow / red
        DB 1,2,0,3, 1                   ; 3 magenta -> cyan sky, orange land
        DB 2,3,1,0, 0                   ; 4 green   -> blue / red, yellow / green
        DB 2,3,0,1, 1                   ; 5 cyan    -> magenta / orange, buff / cyan
        DB 2,3,0,1, 0                   ; 6 yellow  -> blue / red, green / yellow
        DB 2,3,1,0, 1                   ; 7 white   -> magenta / orange, cyan / buff

sc_cur:  DB 4                           ; scheme currently on screen
sc_perm: DS 4                           ; old colour code -> new colour code

; vz_scheme_key: from the colour keys (A = new attribute)
vz_scheme_key:
        LD A,($BEA2)
        CALL vz_scheme_ink
        LD B,0
        LD D,B
        RET

; vz_scheme_mode: pick the scheme for palette mode ($B956) and apply it
vz_scheme_mode:
        LD A,($B956)
        CP $83                          ; game view: the landscape's colour
        JR NZ,.m1
        LD A,($BEA2)
        JR vz_scheme_ink
.m1:    CP $87                          ; title: green
        LD A,4
        JR Z,vz_scheme_ink
        LD A,($B956)
        CP $46                          ; preview: as the original, set the
        JR NZ,.m2                       ; landscape's colour ($B989), show
        LD D,0                          ; the preview in the title's scheme
        CALL $B989                      ; (yellow on blue)
        LD A,4
        JR vz_scheme_ink
.m2:    LD A,($B956)                    ; others ($05): their ink
        ; fall through

; vz_scheme_ink: A = ink colour (bits 0-2)
vz_scheme_ink:
        AND 7
        LD HL,sc_cur
        CP (HL)
        RET Z
        LD C,(HL)                       ; C = old scheme
        LD (HL),A
        CALL sc_addr                    ; DE -> new scheme
        PUSH DE
        LD A,C
        CALL sc_addr                    ; DE -> old scheme
        POP HL                          ; HL -> new
        ; perm[old[r]] = new[r]
        LD B,4
.p:     LD A,(DE)
        PUSH HL
        LD HL,sc_perm
        ADD A,L
        LD L,A
        JR NC,.p1
        INC H
.p1:    EX (SP),HL
        LD A,(HL)
        EX (SP),HL
        LD (HL),A
        POP HL
        INC HL
        INC DE
        DJNZ .p
        CALL vz_remap                   ; recolour the view (bank-1 lookup table)
        CALL sc_tables
        CALL vz_border
        LD B,0
        LD D,B
        RET

; DE = vz_schemes + 5*A
sc_addr:
        LD E,A
        ADD A,A
        ADD A,A
        ADD A,E
        LD E,A
        LD D,0
        PUSH HL
        LD HL,vz_schemes
        ADD HL,DE
        EX DE,HL
        POP HL
        RET

; build the fill patterns, border colour and colour set for scheme sc_cur
sc_tables:
        PUSH IX
        LD A,(sc_cur)
        CALL sc_addr
        PUSH DE
        POP IX                          ; IX -> E, D, L, F, CSS
        LD A,(IX+0)
        CALL sc_solid
        LD (pal_game),DE                ; logical 0: E
        LD (bg_pat+2),DE                ; background 1: E
        LD (bg_pat+6),DE                ; background 3 ("black"): E
        LD A,E
        LD (border_col),A
        LD (bg_pat),A                   ; sky: rows of E ...
        LD A,(IX+1)
        CALL sc_solid
        LD A,E
        LD (bg_pat+1),A                 ; ... and D
        LD A,(IX+1)
        LD C,(IX+0)
        CALL sc_check
        LD (pal_game+2),DE              ; logical 1: D/E dither
        LD A,(IX+2)
        LD C,(IX+3)
        CALL sc_check
        LD (pal_game+4),DE              ; logical 2: L/F dither
        LD A,(IX+3)
        CALL sc_solid
        LD (pal_game+6),DE              ; logical 3: F
        LD A,(IX+0)
        LD C,(IX+3)
        CALL sc_check
        LD (bg_pat+4),DE                ; background 2: E/F dither
        ; other pattern sets (see vz_gfx.asm)
        LD A,(IX+0)                     ; E
        CALL sc_solid
        LD (pal_title),DE
        LD (pal_letters),DE
        LD A,(IX+1)                     ; D
        CALL sc_solid
        LD A,E
        LD (pal_prev+8),A               ; preview edges
        LD A,(IX+2)                     ; L
        CALL sc_solid
        LD (pal_title+6),DE
        LD (pal_letters+6),DE
        LD (pal_prev),DE
        LD A,E
        LD (pal_title+8),A
        LD A,(IX+3)                     ; F
        CALL sc_solid
        LD (pal_prev+6),DE
        LD A,E
        LD (pal_letters+8),A
        LD A,(IX+2)                     ; L/E dither
        LD C,(IX+0)
        CALL sc_check
        LD (pal_title+2),DE
        LD (pal_title+4),DE
        LD A,(IX+3)                     ; F/E dither
        LD C,(IX+0)
        CALL sc_check
        LD (pal_letters+2),DE
        LD (pal_prev+2),DE
        LD A,(IX+2)                     ; L/F dither
        LD C,(IX+3)
        CALL sc_check
        LD (pal_letters+4),DE
        LD (pal_prev+4),DE
        LD A,(IX+4)
        POP IX
        OR A
        LD A,LATCH_GFX
        JR Z,.c0
        OR LATCH_CSS
.c0:    JP VZ_SetLatch

; DE = solid pattern of colour A (both rows)
sc_solid:
        AND 3
        LD E,A
        ADD A,A
        ADD A,A
        OR E
        LD E,A
        ADD A,A
        ADD A,A
        ADD A,A
        ADD A,A
        OR E
        LD E,A
        LD D,A
        RET

; DE = checkerboard of colours A (first pixel, even row) and C
sc_check:
        AND 3
        RRCA
        RRCA
        LD E,A                          ; a in bits 7-6
        LD A,C
        AND 3
        RRCA
        RRCA
        RRCA
        RRCA                            ; c in bits 5-4
        OR E
        LD E,A
        RRCA
        RRCA
        RRCA
        RRCA
        OR E                            ; a c a c
        LD E,A
        RRCA
        RRCA                            ; c a c a
        LD D,A
        RET

;-----------------------------------------------------------------------------
; vz_mapcol - A = solid colour byte as designed for the default (green)
; scheme; returns the byte for the same role in the current scheme, so text
; and effects drawn into the view stay consistent when the view is
; re-coloured.  Preserves BC, DE, HL.
;-----------------------------------------------------------------------------
vz_mapcol:
        PUSH DE
        PUSH HL
        AND 3
        LD HL,mc_role
        ADD A,L
        LD L,A
        JR NC,.a
        INC H
.a:     LD L,(HL)                       ; role: 0 E, 1 D, 2 L, 3 F
        LD A,(sc_cur)
        CALL sc_addr                    ; DE -> E, D, L, F (keeps HL)
        LD A,L
        ADD A,E
        LD E,A
        JR NC,.b
        INC D
.b:     LD A,(DE)
        AND 3
        LD E,A                          ; colour -> solid byte
        ADD A,A
        ADD A,A
        OR E
        LD E,A
        ADD A,A
        ADD A,A
        ADD A,A
        ADD A,A
        OR E
        POP HL
        POP DE
        RET
mc_role: DB 3, 2, 0, 1                  ; green=F, yellow=L, blue=E, red=D
