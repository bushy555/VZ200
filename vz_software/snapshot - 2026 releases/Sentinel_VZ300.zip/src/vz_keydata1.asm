; key table indexed by (game key number - $24): VZ row address, mask
KEYTAB_N        EQU 34
vz_keytab:
        DB $7F,$0A      ; $24 up    : L or K
        DB $FF,$00      ; $25
        DB $BF,$10      ; $26 pause : P
        DB $EF,$28      ; $27 down  : M or ,
        DB $FF,$00      ; $28
        DB $FF,$00      ; $29
        DB $BF,$20      ; $2A U-turn: U
        DB $FF,$00      ; $2B
        DB $7F,$01      ; $2C hyperspace: H
        DB $FF,$00      ; $2D
        DB $BF,$04      ; $2E unpause: RETURN
        DB $EF,$10      ; $2F sights: SPACE
        DB $FF,$00      ; $30
        DB $FF,$00      ; $31
        DB $FE,$20      ; $32 robot : R
        DB $FE,$01      ; $33 tree  : T
        DB $FF,$00      ; $34
        DB $FF,$00      ; $35
        DB $FB,$01      ; $36 boulder: B
        DB $FF,$00      ; $37
        DB $FF,$00      ; $38
        DB $FF,$00      ; $39
        DB $FF,$00      ; $3A
        DB $FF,$00      ; $3B
        DB $FD,$02      ; $3C left  : S
        DB $FD,$08      ; $3D right : D
        DB $FF,$00      ; $3E
        DB $FF,$00      ; $3F
        DB $FF,$00      ; $40
        DB $FF,$00      ; $41
        DB $FF,$00      ; $42
        DB $FE,$10      ; $43 transfer: Q
        DB $FF,$00      ; $44
        DB $FD,$10      ; $45 absorb: A

; joystick merge: key index, joystick bit
vz_joykeys:
        DB $24-$24, $01 ; up
        DB $27-$24, $02 ; down
        DB $3C-$24, $04 ; left
        DB $3D-$24, $08 ; right
        DB $2F-$24, $10 ; fire = sights

