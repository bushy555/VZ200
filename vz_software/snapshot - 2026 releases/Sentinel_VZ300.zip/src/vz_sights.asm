;=============================================================================
; Sights (crosshair).  The game's targeting works purely from xSights/ySights
; ($60C6/$60C7) through GetSightsVector + FollowGazeVector, so only the
; drawing is replaced.  The Spectrum sprite is centred on screen pixel
; (1.5*x + 8, $C7 - y + 5); the VZ crosshair is centred on the VZ pixel that
; covers that point, drawn in the inverse of the background colour.
;=============================================================================

; VZ_DrawSights - replaces DrawSights at $BFB4
VZ_DrawSights:
        LD A,($60D7)
        OR A
        JP M,.out
        LD A,($B341)
        OR A
        JR NZ,.out
        CALL VZ_RemoveSights
        LD A,($60C6)
        AND 1
        LD ($60CC),A
        LD A,($60C9)
        OR A
        JR NZ,.out
        ; VZ x = (1.5*x + 8) / 2
        LD A,($60C6)
        LD E,A
        SRL E
        ADD A,E
        ADD A,8
        SRL A
        LD (sg_x),A
        ; screen line = $C7 - y + 5 -> VZ row
        LD A,($60C7)
        LD E,A
        LD A,$CC
        SUB E
        CALL line_to_row
        LD (sg_row),A
        LD HL,sg_save
        LD (sg_ptr),HL
        XOR A
        LD (sg_n),A
        ; horizontal arm
        LD A,(sg_x)
        SUB 3
        LD C,A
        LD B,3
.h1:    LD A,(sg_row)
        CALL sg_plot
        INC C
        DJNZ .h1
        INC C
        LD B,3
.h2:    LD A,(sg_row)
        CALL sg_plot
        INC C
        DJNZ .h2
        ; vertical arm
        LD A,(sg_x)
        LD C,A
        LD A,(sg_row)
        DEC A
        CALL sg_plot
        LD A,(sg_row)
        INC A
        CALL sg_plot
        LD A,(sg_n)
        LD ($60C9),A
        LD A,1
        LD ($C13C),A
.out:   LD B,0
        LD D,B
        RET

; VZ_RemoveSights - replaces RemoveSights at $C10A
VZ_RemoveSights:
        LD A,($60C9)
        OR A
        RET Z
        LD A,(sg_n)                     ; restore in reverse order
        LD B,A
        LD HL,(sg_ptr)
.l:     DEC HL
        LD A,(HL)                       ; value
        DEC HL
        LD D,(HL)
        DEC HL
        LD E,(HL)
        LD (DE),A
        DJNZ .l
        XOR A
        LD ($60C9),A
        LD ($C13C),A
        LD (sg_n),A
        RET

; A = absolute Spectrum screen line (0..191) -> A = VZ row
line_to_row:
        LD E,A
        AND 7
        LD HL,lsub
        ADD A,L
        LD L,A
        JR NC,.n
        INC H
.n:     LD D,(HL)
        LD A,E
        RRCA
        RRCA
        RRCA
        AND $1F                         ; character row r
        LD E,A
        ADD A,A
        ADD A,E                         ; 3r
        INC A
        ADD A,D                         ; 3r + 1 + sub
        RET
lsub:   DB 0,0,0,1,1,1,2,2

; sg_plot: invert VZ pixel C (x) on row A, saving the byte first
sg_plot:
        CP 4                            ; keep inside the view (rows 4..63)
        RET C
        CP 64
        RET NC
        PUSH BC
        LD L,A
        LD H,0
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL                       ; row * 32
        LD A,C
        RRA
        RRA
        AND $1F
        LD E,A
        LD D,VZ_VRAM>>8
        ADD HL,DE                       ; HL -> byte
        ; save (addr, value)
        LD DE,(sg_ptr)
        LD A,L
        LD (DE),A
        INC DE
        LD A,H
        LD (DE),A
        INC DE
        LD A,(HL)
        LD (DE),A
        INC DE
        LD (sg_ptr),DE
        LD A,(sg_n)
        INC A
        LD (sg_n),A
        ; invert the pixel
        LD A,C
        AND 3
        LD DE,pmask
        ADD A,E
        LD E,A
        JR NC,.p
        INC D
.p:     LD A,(DE)
        XOR (HL)
        LD (HL),A
        POP BC
        RET

sg_x:    DB 0
sg_row:  DB 0
sg_n:    DB 0
sg_ptr:  DW sg_save
sg_save: DS 3*10
