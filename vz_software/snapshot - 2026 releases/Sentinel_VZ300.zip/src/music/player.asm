;=============================================================================
; Music bank player.  This module is assembled on its own at $4000 and lives in
; the BennVenn DOS-area RAM bank 1, which the game itself never maps.  The
; main program (vz_music in vz_musicif.asm) switches the bank in with
; interrupts off, calls mus_play, and switches back.
;
; It is the same four-voice engine as the game's own tune player ($E600 with
; the inner loop at vz_tune_inner): every "event" starts a note on the next of
; the four voices in turn; each note is a pulse train whose pulse width decays
; every few ticks, so the last four notes ring on as a fading chord.  A tick
; is 640 passes of the voice loop (~14 ms).
;
; Tune format: envelope rate (ticks per decay step), then (pitch, delay)
; pairs.  pitch = voice period in loop passes (higher = lower note), 0 = rest,
; $FF = end.  delay = ticks until the next event (1-255).  A resting voice
; keeps running silently (its "speaker on" writes use the speaker-off value),
; so the loop speed, and with it the tuning, doesn't depend on how many
; voices are sounding.
;
; mus_play: A = tune number.  Returns carry set if a key (or joystick fire)
; was pressed, which stops the tune at once.
;=============================================================================
        ORG $4000
        JP mus_play                     ; $4000
mus_son:  DB $09                        ; $4003 latch values for speaker on /
mus_soff: DB $28                        ; $4004 off, set by the caller
        JP bk_remap                     ; $4005 view recolouring (see below)
bk_perm:  DS 4                          ; $4008 its pixel permutation / map
        JP bk_tint                      ; $400C tint part of the screen
bk_tpar:  DS 4                          ; $400F first row, rows, first column,
                                        ;       columns (video RAM)
        JP bk_gameover                  ; $4013 game-over screen
go_paper: DB 0                          ; $4016 colour bytes
go_ink:   DB 0                          ; $4017
go_font:  DW 0                          ; $4018 the game's 3x5 font
go_sound: DB 0                          ; $401A 0 = sound off
go_kind:  DB 0                          ; $401B how the game ended (decay count:
                                        ;       $05 hyperspace, $1E absorbed)

mus_play:
        ADD A,A
        LD L,A
        LD H,0
        LD DE,mus_tunes
        ADD HL,DE
        LD E,(HL)
        INC HL
        LD D,(HL)
        PUSH DE
        POP IX
        LD A,(IX+0)
        LD (mp_rate),A
        LD (mp_env),A
        INC IX
        LD C,3                          ; all four voices start resting
.init:  XOR A
        CALL mp_setvoice
        DEC C
        JP P,.init
        LD A,3
        LD (mp_voice),A
        LD A,1
        LD (mp_delay),A
        LD D,A
        LD E,A
        LD H,A
        LD L,A
.next:  LD A,(mp_delay)
        DEC A
        LD (mp_delay),A
        JR NZ,.tick
        ; --- next event: note on the next voice
        LD A,(mp_voice)
        INC A
        AND 3
        LD (mp_voice),A
        LD C,A
        LD A,(IX+0)
        INC IX
        CP $FF
        JR Z,.end
        CALL mp_setvoice
        LD A,(IX+0)
        INC IX
        LD (mp_delay),A
        ; --- one tick of sound
.tick:  LD B,$80
        CALL mp_loop
        CALL mp_loop
        CALL mp_loop
        ; key or fire stops the music
        LD A,($6800)                    ; all keyboard rows
        AND $3F
        CP $3F
        JR NZ,.key
        IN A,($2C)                      ; joystick 1 fire, if the stick is
        CPL                             ; there (up+down together means an
        AND $03                         ; empty port)
        CP $03
        JR Z,.nj1
        IN A,($2E)
        AND $10
        JR Z,.key
.nj1:   IN A,($29)                      ; joystick 2 fire, likewise
        CPL
        AND $03
        CP $03
        JR Z,.nojoy
        IN A,($2B)
        AND $10
        JR Z,.key
.nojoy:
        ; envelope: every mp_rate ticks narrow each voice's pulses
        LD A,(mp_env)
        DEC A
        LD (mp_env),A
        JR NZ,.next
        LD A,(mp_rate)
        LD (mp_env),A
        PUSH HL
        LD HL,va_on+1
        CALL mp_decay
        LD HL,vb_on+1
        CALL mp_decay
        LD HL,vc_on+1
        CALL mp_decay
        LD HL,vd_on+1
        CALL mp_decay
        POP HL
        JP .next
.key:   LD A,(mus_soff)
        LD ($6800),A
        SCF
        RET
.end:   LD A,(mus_soff)
        LD ($6800),A
        OR A
        RET

; mp_setvoice: voice C (0-3), pitch A (0 = rest).  Sets the voice's period,
; pulse width (period / 8), off time 1 and sound source, and restarts its
; counter (D, E, H or L) so the note begins on the next pass.
mp_setvoice:
        PUSH IY
        PUSH BC
        LD IY,mus_son
        OR A
        JR NZ,.np
        LD IY,mus_soff                  ; rest: silent, but same timing
        LD A,100
.np:    LD B,A                          ; B = period
        RRCA
        RRCA
        RRCA
        AND $1F                         ; pulse width
        JR NZ,.w
        INC A
.w:     PUSH AF
        LD A,C
        OR A
        JR NZ,.v1
        LD A,B
        LD (va_per+1),A
        POP AF
        LD (va_on+1),A
        LD (va_src+1),IY
        LD A,1
        LD (va_off+1),A
        POP BC
        LD D,A
        POP IY
        RET
.v1:    DEC A
        JR NZ,.v2
        LD A,B
        LD (vb_per+1),A
        POP AF
        LD (vb_on+1),A
        LD (vb_src+1),IY
        LD A,1
        LD (vb_off+1),A
        POP BC
        LD E,A
        POP IY
        RET
.v2:    DEC A
        JR NZ,.v3
        LD A,B
        LD (vc_per+1),A
        POP AF
        LD (vc_on+1),A
        LD (vc_src+1),IY
        LD A,1
        LD (vc_off+1),A
        POP BC
        LD H,A
        POP IY
        RET
.v3:    LD A,B
        LD (vd_per+1),A
        POP AF
        LD (vd_on+1),A
        LD (vd_src+1),IY
        LD A,1
        LD (vd_off+1),A
        POP BC
        LD L,A
        POP IY
        RET

; HL -> a voice's pulse width operand; its off-time operand is vx_offdist on
mp_decay:
        LD A,(HL)
        CP 2
        RET C                           ; already at the minimum
        DEC (HL)
        LD A,L
        ADD A,vx_offdist
        LD L,A
        JR NC,.c
        INC H
.c:     INC (HL)
        RET

; four voices; counters in D, E, H, L; B passes
mp_loop:
        DEC D
        JP NZ,mpv2
va_per: LD D,$FE
va_on:  LD C,$01
va_src: LD A,(mus_son)
        LD ($6800),A
mpa1:   DEC C
        JP NZ,mpa1
        LD A,(mus_soff)
        LD ($6800),A
va_off: LD A,$1F
mpa2:   DEC A
        JP NZ,mpa2
mpv2:   DEC E
        JP NZ,mpv3
vb_per: LD E,$FE
vb_on:  LD C,$01
vb_src: LD A,(mus_son)
        LD ($6800),A
mpb1:   DEC C
        JP NZ,mpb1
        LD A,(mus_soff)
        LD ($6800),A
vb_off: LD A,$1F
mpb2:   DEC A
        JP NZ,mpb2
mpv3:   DEC H
        JP NZ,mpv4
vc_per: LD H,$FE
vc_on:  LD C,$01
vc_src: LD A,(mus_son)
        LD ($6800),A
mpc1:   DEC C
        JP NZ,mpc1
        LD A,(mus_soff)
        LD ($6800),A
vc_off: LD A,$1F
mpc2:   DEC A
        JP NZ,mpc2
mpv4:   DEC L
        JP NZ,mpv5
vd_per: LD L,$FE
vd_on:  LD C,$01
vd_src: LD A,(mus_son)
        LD ($6800),A
mpd1:   DEC C
        JP NZ,mpd1
        LD A,(mus_soff)
        LD ($6800),A
vd_off: LD A,$1F
mpd2:   DEC A
        JP NZ,mpd2
mpv5:   DEC B
        JP NZ,mp_loop
        RET

vx_offdist EQU va_off - va_on
        ASSERT vb_off - vb_on == vx_offdist
        ASSERT vc_off - vc_on == vx_offdist
        ASSERT vd_off - vd_on == vx_offdist

mp_rate:  DB 4
mp_env:   DB 4
mp_delay: DB 1
mp_voice: DB 3

;-----------------------------------------------------------------------------
; bk_remap - recolour the view by the pixel permutation in bk_perm, through
; a 256-byte lookup table built at $6700 in this bank.  Called by vz_remap
; (main program) with this bank mapped and interrupts off.  Covers:
;   video RAM rows 4-63 ($7080-$77FF)
;   screen buffer rows: pages $C7-$D3, offsets $40-$FF
;   off-screen hidden rows: pages $D6-$D7, offsets $40-$FF
;   shadow view rows: pages $D8-$E1, offsets $40-$FF
; About 0.3M T-states, against 1.6M for a pixel-by-pixel version.
;-----------------------------------------------------------------------------
BK_LUT  EQU $6700
bk_remap:
        CALL bk_lut
        LD D,BK_LUT>>8
        LD HL,$7080                     ; video RAM rows 4-63
        LD BC,$0880                     ; 1920 bytes: 128 + 7 x 256
        JP bk_rest

; bk_lut: LUT[b] = bk_perm applied to each 2-bit pixel of b
bk_lut:
        LD HL,BK_LUT
.lut:   LD B,4                          ; LUT[b]: each 2-bit pixel of b mapped
        LD C,L
        LD E,0
.px:    RLC C
        RLC C
        LD A,C
        AND 3
        PUSH HL
        LD HL,bk_perm
        ADD A,L
        LD L,A
        LD A,(HL)
        POP HL
        SLA E
        SLA E
        OR E
        LD E,A
        DJNZ .px
        LD (HL),E
        INC L
        JR NZ,.lut
        RET

bk_rest:
.vr:    LD E,(HL)
        LD A,(DE)
        LD (HL),A
        INC HL
        DEC C
        JR NZ,.vr
        DJNZ .vr
        LD H,$C7
        LD B,13
        CALL .pages
        LD H,$D6
        LD B,2
        CALL .pages
        LD H,$D8
        LD B,10
.pages: LD L,$40
.pb:    LD E,(HL)
        LD A,(DE)
        LD (HL),A
        INC L
        JR NZ,.pb
        INC H
        DJNZ .pages
        RET
        ASSERT ((bk_perm & $FF) <= $FC) ; bk_perm+3 in the same page

;-----------------------------------------------------------------------------
; bk_tint - apply the colour map in bk_perm to a rectangle of video RAM:
; rows bk_tpar+0 .. +rows-1, byte columns bk_tpar+2 .. +columns-1.  Used to
; give the title and preview screens the Spectrum's two-colour look.
;-----------------------------------------------------------------------------
bk_tint:
        CALL bk_lut
        LD A,(bk_tpar)                  ; HL = $7000 + row*32 + column
        LD L,A
        LD H,0
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        LD A,(bk_tpar+2)
        ADD A,L
        LD L,A
        LD A,H
        ADC A,$70
        LD H,A
        LD D,BK_LUT>>8
        LD A,(bk_tpar+1)
        LD C,A                          ; rows
.row:   PUSH HL
        LD A,(bk_tpar+3)
        LD B,A                          ; columns
.col:   LD E,(HL)
        LD A,(DE)
        LD (HL),A
        INC HL
        DJNZ .col
        POP HL
        LD DE,32
        ADD HL,DE
        LD D,BK_LUT>>8
        DEC C
        JR NZ,.row
        RET

;-----------------------------------------------------------------------------
; bk_gameover - the game-over screen: "GAME OVER" in large letters and a
; line of small text on the (already cleared) view, then the game-over tune.
; Returns carry set if a key ended it early.
;-----------------------------------------------------------------------------
TUNE_GAMEOVER EQU 6
bk_gameover:
        LD HL,go_big
        LD BC,(19<<8)|28                ; B = row, C = x
        LD E,2
        CALL bk_text
        LD HL,go_small                  ; absorbed
        LD BC,(37<<8)|9
        LD DE,go_small2
        LD IX,(46<<8)|29
        LD A,(go_kind)
        CP $05
        JR NZ,.k
        LD HL,go_hyper                  ; hyperspace with too little energy
        LD BC,(37<<8)|21
        LD DE,go_hyper2
        LD IX,(46<<8)|31
.k:     PUSH DE
        LD E,1
        CALL bk_text
        POP HL
        PUSH IX
        POP BC
        LD E,1
        CALL bk_text
        LD A,(go_sound)
        OR A
        RET Z
        LD A,TUNE_GAMEOVER
        JP mus_play

go_big:    DB "GAME OVER",0
go_small:  DB "YOU HAVE BEEN ABSORBED",0
go_hyper:  DB "NOT ENOUGH ENERGY",0
go_hyper2: DB "TO HYPERSPACE",0

go_small2: DB "THE SENTINEL WINS",0

; bk_text: string HL at x C, row B, scale E (1 or 2)
bk_text:
.ch:    LD A,(HL)
        OR A
        RET Z
        INC HL
        PUSH HL
        PUSH BC
        PUSH DE
        CALL bk_glyph
        POP DE
        POP BC
        POP HL
        LD A,E                          ; advance: 5 (small) or 8 (large)
        DEC A
        LD A,5
        JR Z,.a
        LD A,8
.a:     ADD A,C
        LD C,A
        JR .ch

; bk_glyph: character A at x C, row B, scale E
bk_glyph:
        SUB $20
        RET C
        LD L,A
        LD H,0
        PUSH DE
        LD D,H
        LD E,L
        ADD HL,HL
        ADD HL,HL
        ADD HL,DE                       ; * 5
        LD DE,(go_font)
        ADD HL,DE
        POP DE
        LD D,5                          ; font rows
.row:   PUSH BC
        LD A,(HL)
        RLCA                            ; bit 2 (left pixel) -> bit 7
        RLCA
        RLCA
        RLCA
        RLCA
        PUSH HL
        LD L,3                          ; columns
.col:   RLA
        JR NC,.nx
        PUSH AF
        CALL bk_block
        POP AF
.nx:    PUSH AF
        LD A,C
        ADD A,E
        LD C,A
        POP AF
        DEC L
        JR NZ,.col
        POP HL
        INC HL
        POP BC
        LD A,B
        ADD A,E
        LD B,A
        DEC D
        JR NZ,.row
        RET

; bk_block: E x E block of ink at x C, row B
bk_block:
        PUSH BC
        PUSH DE
        PUSH HL
        LD D,E
.by:    PUSH BC
        LD H,E
.bx:    CALL bk_pset
        INC C
        DEC H
        JR NZ,.bx
        POP BC
        INC B
        DEC D
        JR NZ,.by
        POP HL
        POP DE
        POP BC
        RET

; bk_pset: pixel at x C, row B in ink (video RAM)
bk_pset:
        PUSH HL
        PUSH DE
        LD L,B
        LD H,0
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        LD A,C
        RRA
        RRA
        AND $1F
        OR L
        LD L,A
        LD A,H
        ADD A,$70
        LD H,A                          ; HL = $7000 + row*32 + x/4
        LD A,C
        AND 3
        LD E,$C0                        ; pixel mask
        JR Z,.m
.sh:    SRL E
        SRL E
        DEC A
        JR NZ,.sh
.m:     LD A,(go_ink)
        AND E
        LD D,A
        LD A,E
        CPL
        AND (HL)
        OR D
        LD (HL),A
        POP DE
        POP HL
        RET

mus_tunes:
        INCLUDE "tunes.asm"
