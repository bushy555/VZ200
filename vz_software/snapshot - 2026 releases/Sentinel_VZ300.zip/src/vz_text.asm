;=============================================================================
; Text.  The original prints characters through PrintCharacter ($87DA), which
; handles control codes and the text cursor, then renders 8x8 glyphs shifted
; to 6.4-pixel steps.  The VZ version keeps the cursor logic and replaces the
; glyph rendering with a 3x5 VZ font.
;
; Cursor: x = ($8AB6) in 0..39 (two units per character), y = ($8AB7).
; The game prints on three lines: y < 4 (top), 4..9 (second), >= 10 (bottom).
;=============================================================================

; entry from $895E with A = character (also in $8ABC); returns via $8A02
VZ_PrintChar:
        PUSH IX
        ; VZ x = 16 * cursor x / 5  (= half the Spectrum pixel position)
        LD A,($8AB6)
        LD L,A
        LD H,0
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        LD C,0
        LD DE,5
.div:   OR A
        SBC HL,DE
        JR C,.dd
        INC C
        JR .div
.dd:    LD A,C
        ADD A,4                         ; the Spectrum view starts at column 1
        LD (tx_x),A
        ; line
        LD A,($8AB7)
        LD B,5                          ; top line: VZ row 5
        LD C,C_YEL*$55
        CP 4
        JR C,.row
        LD B,12                         ; second line: VZ row 12
        LD C,C_GRN*$55
        CP 10
        JR C,.row
        LD B,57                         ; bottom line: VZ row 57
        LD C,C_YEL*$55
.row:   LD A,C
        LD (tx_col),A
        LD A,B
        LD (tx_row),A
        LD A,($8ABC)
        CALL vz_glyph
        POP IX
        JP $8A02

tx_x:   DB 0
tx_row: DB 0
tx_col: DB 0
tx_pix: DB 0


; 3x5 font, ASCII $20-$5F, bit 2 = left pixel
vz_font:
        DB 0,0,0,0,0                    ; space
        DB 2,2,2,0,2                    ; !
        DB 5,5,0,0,0                    ; "
        DB 5,7,5,7,5                    ; #
        DB 7,6,7,3,7                    ; $
        DB 5,1,2,4,5                    ; %
        DB 2,5,2,5,3                    ; &
        DB 2,2,0,0,0                    ; '
        DB 1,2,2,2,1                    ; (
        DB 4,2,2,2,4                    ; )
        DB 0,5,2,5,0                    ; *
        DB 0,2,7,2,0                    ; +
        DB 0,0,0,2,4                    ; ,
        DB 0,0,7,0,0                    ; -
        DB 0,0,0,0,2                    ; .
        DB 1,1,2,4,4                    ; /
        DB 7,5,5,5,7                    ; 0
        DB 2,6,2,2,7                    ; 1
        DB 7,1,7,4,7                    ; 2
        DB 7,1,3,1,7                    ; 3
        DB 5,5,7,1,1                    ; 4
        DB 7,4,7,1,7                    ; 5
        DB 7,4,7,5,7                    ; 6
        DB 7,1,1,2,2                    ; 7
        DB 7,5,7,5,7                    ; 8
        DB 7,5,7,1,7                    ; 9
        DB 0,2,0,2,0                    ; :
        DB 0,2,0,2,4                    ; ;
        DB 1,2,4,2,1                    ; <
        DB 0,7,0,7,0                    ; =
        DB 4,2,1,2,4                    ; >
        DB 7,1,3,0,2                    ; ?
        DB 7,5,5,4,7                    ; @
        DB 2,5,7,5,5                    ; A
        DB 6,5,6,5,6                    ; B
        DB 3,4,4,4,3                    ; C
        DB 6,5,5,5,6                    ; D
        DB 7,4,6,4,7                    ; E
        DB 7,4,6,4,4                    ; F
        DB 3,4,5,5,3                    ; G
        DB 5,5,7,5,5                    ; H
        DB 7,2,2,2,7                    ; I
        DB 1,1,1,5,2                    ; J
        DB 5,5,6,5,5                    ; K
        DB 4,4,4,4,7                    ; L
        DB 5,7,7,5,5                    ; M
        DB 6,5,5,5,5                    ; N
        DB 2,5,5,5,2                    ; O
        DB 6,5,6,4,4                    ; P
        DB 2,5,5,6,3                    ; Q
        DB 6,5,6,5,5                    ; R
        DB 3,4,2,1,6                    ; S
        DB 7,2,2,2,2                    ; T
        DB 5,5,5,5,7                    ; U
        DB 5,5,5,5,2                    ; V
        DB 5,5,7,7,5                    ; W
        DB 5,5,2,5,5                    ; X
        DB 5,5,2,2,2                    ; Y
        DB 7,1,2,4,7                    ; Z
        DB 3,2,2,2,3                    ; [
        DB 4,4,2,1,1                    ; backslash
        DB 6,2,2,2,6                    ; ]
        DB 2,5,0,0,0                    ; ^
        DB 0,0,0,0,7                    ; _

