;-----------------------------------------------------------------------------
; vz_gameover - replaces the end of ShowGameOverScreen ($BB51): after the
; screen has decayed, show a game-over screen (drawn by the spare-bank
; module: "GAME OVER" and two lines of text) and play the game-over tune.
;-----------------------------------------------------------------------------
vz_gameover:
        LD HL,$98ED                     ; as the original
        LD ($9953),HL
        LD A,C_YEL*$55
        CALL vz_mapcol
        LD (bk_par+1),A                 ; ink
        LD HL,vz_font
        LD (bk_par+2),HL
        LD A,($BC47)                    ; sound off when this is RET ($C9)
        SUB $C9
        LD (bk_par+4),A
        LD A,(go_kind)
        LD (bk_par+5),A
        CALL vz_irq_resume
        LD HL,$4013                     ; bk_gameover
        CALL vz_bank1
        LD B,0
        LD D,B
        RET
