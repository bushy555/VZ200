;=============================================================================
; Extra music, played from the BennVenn spare RAM bank.
;
; The music player and its tunes (src/music/) live in DOS-area RAM bank 1
; ($4000-$67FF with port $37 bit 1 set), put there by the boot loader.  The
; game never maps that bank, so it costs no game memory.  vz_music must sit
; outside $4000-$67FF: it switches bank 1 in (interrupts off - the IRQ
; handler lives in bank 0), calls the player, and switches back.
;=============================================================================
MUS_ENTRY       EQU $4000
MUS_SON         EQU $4003
MUS_SOFF        EQU $4004

; vz_music: A = tune number; returns carry set if stopped by a key
vz_music:
        PUSH BC
        PUSH DE
        PUSH HL
        PUSH IX
        PUSH IY
        LD C,A
        CALL vz_irq_resume              ; interrupts are on here: known state
        DI
        LD A,(snd_on)                   ; speaker values for the current mode
        LD B,A
        LD A,(snd_off)
        LD E,A
        LD A,3                          ; DOS area: RAM bank 1
        OUT ($37),A
        LD A,B
        LD (MUS_SON),A
        LD A,E
        LD (MUS_SOFF),A
        LD A,C
        CALL MUS_ENTRY
        LD A,1                          ; back to bank 0 (carry kept)
        OUT ($37),A
        EI
        POP IY
        POP IX
        POP HL
        POP DE
        POP BC
        RET
