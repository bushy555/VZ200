;-----------------------------------------------------------------------------
; vz_div - replaces the 16-iteration division loop of GetAngleFromCoords at
; $93BC-$93CE: (HL:0) / DE, quotient in A:C.  The rest of the routine only
; uses A and bits 7-6 of C (then restores BC), so only the first 10 quotient
; bits are computed, unrolled.  The carry into each doubling of HL is always
; 0 in the original (it comes from the empty top of A), so ADC HL,HL is
; ADD HL,HL here; the HL sequence is identical.  Quotient bits are collected
; inverted (carry = "did not fit") and complemented at the end.
;-----------------------------------------------------------------------------
DIVSTEP MACRO
        ADD HL,HL
        SBC HL,DE
        JR NC,$+3
        ADD HL,DE                       ; restore (sets carry again)
        RLA
        ENDM
vz_div:
        DIVSTEP
        DIVSTEP
        DIVSTEP
        DIVSTEP
        DIVSTEP
        DIVSTEP
        DIVSTEP
        DIVSTEP
        CPL
        LD B,A                          ; quotient bits 15-8
        XOR A
        DIVSTEP
        DIVSTEP
        CPL
        RRCA
        RRCA
        AND $C0
        LD C,A                          ; quotient bits 7-6 in C bits 7-6
        LD A,B
        LD B,0                          ; as the original after DJNZ
        LD D,B
        LD E,A
        CALL vz_ckpt
        JP $93CF
