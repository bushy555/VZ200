;=============================================================================
; Screen effects
;=============================================================================

;-----------------------------------------------------------------------------
; VZ_Dissolve873A / VZ_Dissolve873F - replace the pixel dissolve at $873A
; (ClearScreen: random pixels set) and $873F (DecayScreenToBlack and the
; interrupt-driven decay when the player is being absorbed: random pixels
; cleared).  64 random pixels per call, using the game's own random number
; generator at $8719.  Each cleared pixel also runs the original click logic
; ($8B2E: a JP when silenced, otherwise the click code at $8B31).
;-----------------------------------------------------------------------------
VZ_Dissolve873A:
        LD A,(vz_blanked)               ; screen hidden: the Spectrum's dots
        LD (dz_skip),A                  ; are invisible (ink = paper)
        LD A,C_RED*$55                  ; "ink" (dark role)
        JR vz_dissolve0
VZ_Dissolve873F:
        LD HL,dz_skip
        LD (HL),0
        LD A,C_BLU*$55                  ; "paper" (edge/sky role)
vz_dissolve0:
        CALL vz_mapcol
        LD (dz_col),A
        LD A,$40
        LD (dz_n),A
.l:     CALL $8719                      ; A = H = random
        LD A,H
        RRCA
        RRCA
        RRCA
        AND 3
        LD E,A                          ; pixel 0..3 from bits 3-4
        LD A,H
        AND $07
        OR VZ_VRAM>>8                   ; $70-$77: anywhere on screen
        LD H,A
        CP VZ_VRAM>>8
        JR NZ,.v
        SET 7,L                         ; keep out of the status rows 0-3
.v:     LD A,E
        PUSH HL
        LD HL,pmask
        ADD A,L
        LD L,A
        JR NC,.m
        INC H
.m:     LD B,(HL)                       ; pixel mask
        POP HL
        LD A,B
        CPL
        AND (HL)
        LD C,A
        LD A,(dz_col)
        AND B
        OR C
        LD C,A
        LD A,(dz_skip)
        OR A
        JR NZ,.k
        LD (HL),C
.k:
        CALL dz_click
        LD HL,dz_n
        DEC (HL)
        JR NZ,.l
        LD B,0
        LD D,B
        RET

dz_col: DB 0
dz_n:   DB 0
dz_skip: DB 0

;-----------------------------------------------------------------------------
; VZ_RandomDots - replaces $B9F3: the object materialise/dematerialise
; effect.  Random two-pixel groups of the object's rectangle are copied from
; the screen buffer to the screen with a click each, ($7DBF) passes of 56
; dots, as the original.  Rectangle: columns ($6062)+1 .. +($6069).
;-----------------------------------------------------------------------------
VZ_RandomDots:
        LD A,$38
        LD ($60D2),A
.dot:   CALL $8719                      ; random H, L
        LD A,($6069)
        OR A
        JP Z,.done
        LD C,A
        LD A,L
.mod:   CP C                            ; column within width
        JR C,.col
        SUB C
        JR .mod
.col:   LD E,A
        LD A,H
        AND $3F
.mod2:  CP 69                           ; view row 0..68 (23 rows x 3)
        JR C,.row
        SUB 69
        JR .mod2
.row:   ; A = view sub-row index -> char row 1..23, sub 0..2
        LD D,0
.d3:    CP 3
        JR C,.q
        SUB 3
        INC D
        JR .d3
.q:     PUSH AF                         ; sub-row
        LD A,D
        INC A
        PUSH DE
        CALL buf_row                    ; HL = buffer row
        POP DE
        PUSH HL
        LD A,D
        INC A
        CALL scr_row                    ; HL = screen row
        POP BC                          ; BC = buffer row
        POP AF
        RRCA
        RRCA
        RRCA                            ; sub * 32
        ADD A,E                         ; + column
        INC A                           ; (column 1 based)
        PUSH AF
        ADD A,C
        LD C,A
        JR NC,.b1
        INC B
.b1:    LD A,($6062)
        LD D,A
        POP AF
        ADD A,D
        ADD A,L
        LD L,A
        JR NC,.b2
        INC H
.b2:    ; copy a random two-pixel group from buffer (BC) to screen (HL)
        LD A,R
        AND 1
        LD A,$F0
        JR Z,.mk
        LD A,$0F
.mk:    LD D,A
        LD A,(BC)
        AND D
        LD E,A
        LD A,D
        CPL
        AND (HL)
        OR E
        LD (HL),A
        ; click (the game-over sequence patches $BA47 to a JP: no click)
        LD A,($BA47)
        CP $C3
        JR Z,.nc
        LD A,(snd_off)
        LD (VZ_LATCH),A
        LD B,$20
.c1:    DJNZ .c1
        LD A,(snd_on)
        LD (VZ_LATCH),A
        LD B,$20
.c2:    DJNZ .c2
.nc:    LD A,($601E)                    ; abort as the original
        OR A
        JP M,.done
        LD HL,$60D2
        DEC (HL)
        JP NZ,.dot
        LD (HL),$38
        LD HL,$7DBF
        DEC (HL)
        JP NZ,.dot
        CALL VZ_ShowBufferRect          ; random dots can miss a few: finish
.done:  LD B,0
        LD D,B
        RET
