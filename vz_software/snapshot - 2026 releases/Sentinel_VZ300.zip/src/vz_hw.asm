;=============================================================================
; VZ hardware layer: start-up, interrupts, keyboard, joystick, sound
;=============================================================================

        ORG $4000

;-----------------------------------------------------------------------------
; VZ_Init - entered from the boot loader once the image is in place.
; Replaces the Spectrum start-up code at $C163 (which built Spectrum screen
; tables, set up IM 2 and cleared the Spectrum screen).
;-----------------------------------------------------------------------------
VZ_Init:
        DI
        LD SP,$FFE0
        LD A,1                          ; keep BennVenn DOS area as RAM bank 0
        OUT ($37),A
        LD A,LATCH_GFX
        CALL VZ_SetLatch
        CALL VZ_ClearScreen
        ; IM 2 vector table: 257 bytes of $FD at $FE00, JP at $FDFD.  This does
        ; not depend on the value on the data bus during interrupt acknowledge.
        LD HL,$FE00
        LD DE,$FE01
        LD BC,$0100
        LD (HL),$FD
        LDIR
        LD A,$C3
        LD ($FDFD),A
        LD HL,VZ_IRQ
        LD ($FDFE),HL
        LD A,$FE
        LD I,A
        IM 2
        LD ($C253),SP                   ; as the original start-up code
        CALL VZ_GfxInit
        CALL sc_tables                  ; build the pattern sets for scheme 4
        EI
        LD B,0                          ; the game expects B = D = 0
        LD D,0
        JP $7FCE                        ; main title loop

;-----------------------------------------------------------------------------
; VZ_IRQ - 50Hz field sync interrupt (IM 2).
; Same as the original handler at $BD7E, but before re-enabling interrupts it
; waits for the MC6847 field sync to end, because on the VZ the INT line stays
; low for the whole of FS (unlike the Spectrum's short ULA pulse).
;-----------------------------------------------------------------------------
POPALL  MACRO
        POP HL
        POP DE
        POP BC
        POP AF
        EXX
        EX AF,AF'
        POP HL
        POP DE
        POP BC
        POP AF
        ENDM

VZ_IRQ:
        PUSH AF
        PUSH BC
        PUSH DE
        PUSH HL
        EXX
        EX AF,AF'
        PUSH AF
        PUSH BC
        PUSH DE
        PUSH HL
        LD A,(irq_off)                  ; still the frame we already handled?
        OR A
        JR NZ,.wait                     ; (only if something re-enabled early)
        CALL $BD98                      ; the game's interrupt routine
        LD HL,irq_count
        INC (HL)
        LD A,(vz_blanked)               ; while a view is drawn off-screen,
        OR A                            ; don't wait out the field sync here:
        JR Z,.wait                      ; return with interrupts off and let
        LD A,(VZ_LATCH)                 ; vz_ckpt switch them back on once FS
        RLA                             ; has gone high (frees ~16% of the CPU)
        JR C,.done
        LD A,1
        LD (irq_off),A
        POPALL
        RET                             ; (no EI)
.wait:  LD BC,$0C00                     ; timeout guard (~37K T-states)
.fs:    LD A,(VZ_LATCH)
        RLA                             ; bit 7 = FS (1 = not in sync)
        JR C,.done
        DEC BC
        LD A,B
        OR C
        JR NZ,.fs
.done:  XOR A
        LD (irq_off),A
        POPALL
        EI
        RET
irq_count:      DB 0

vz_latch:       DB LATCH_GFX            ; shadow of the output latch (mode/CSS)

;-----------------------------------------------------------------------------
; Keyboard.
;
; VZ_KeyTest replaces the Spectrum key test at $C2A8.  A = game key number.
; Returns NZ (A <> 0) if the key is pressed.  Joystick 1 is merged in.
;-----------------------------------------------------------------------------
VZ_KeyTest:
        CALL vz_ckpt
        SUB $24
        JR C,.special
        CP KEYTAB_N
        JR NC,.none
        PUSH HL
        PUSH BC
        LD B,A                          ; B = key index
        ADD A,A
        LD C,A
        PUSH BC
        LD B,0
        LD HL,vz_keytab
        ADD HL,BC
        POP BC
        LD A,(HL)                       ; VZ row address low byte
        INC HL
        LD C,(HL)                       ; key mask (bits 0-5)
        LD L,A
        LD H,$68
        LD A,(HL)
        CPL
        AND C
        AND $3F
        JR NZ,.yes
        ; joystick (only if it is in use at all)
        CALL VZ_ReadJoy
        OR A
        JR Z,.no
        LD HL,vz_joykeys
        LD C,5
.j:     LD A,(HL)
        INC HL
        CP B
        JR Z,.jhit
        INC HL
        DEC C
        JR NZ,.j
        JR .no
.jhit:  LD C,(HL)
        CALL VZ_ReadJoy
        AND C
        JR NZ,.yes
.no:    XOR A
        POP BC
        POP HL
        RET
.yes:   LD A,$FF
        OR A
        POP BC
        POP HL
        RET
.none:  XOR A
        RET
.special:
        ; key numbers below $24 are BREAK on the Spectrum (CAPS+SPACE).  Only
        ; $0D (quit game) is used; VZ = CTRL + SPACE.
        ADD A,$24
        CP $0D
        JR NZ,.none
        LD A,($68FD)                    ; CTRL = row X1 bit 2
        CPL
        AND $04
        RET Z
        LD A,($68EF)                    ; SPACE = row X4 bit 4
        CPL
        AND $10
        RET

; VZ_ReadJoy: returns A = joystick state, active high: bit0 up, bit1 down,
; bit2 left, bit3 right, bit4 fire - joystick 1 and joystick 2 combined, so
; either can be used.  On the user's interface the directions only read
; correctly with an arm-select line low as well: joystick 1 on port $2C,
; joystick 2 on port $29; fire on the standard ports $2E and $2B.  A stick
; reading "up and down" or "left and right" at once is taken as not there
; (an empty port reads as 0), so no joystick at all also works.
VZ_ReadJoy:
        PUSH BC
        IN A,($2C)                      ; joystick 1
        LD B,A
        IN A,($2E)
        CALL .stick
        LD C,A
        IN A,($29)                      ; joystick 2
        LD B,A
        IN A,($2B)
        CALL .stick
        OR C
        POP BC
        RET
; B = directions port, A = fire port (both active low) -> A = state or 0
.stick: CPL
        AND $10
        PUSH AF
        LD A,B
        CPL
        AND $0F
        LD B,A
        AND $03                         ; up + down, or left + right: absent
        CP $03
        JR Z,.none
        LD A,B
        AND $0C
        CP $0C
        JR Z,.none
        POP AF
        OR B
        RET
.none:  POP AF
        XOR A
        RET

;-----------------------------------------------------------------------------
; VZ_SpecIN_xx - emulate Spectrum "LD A,row : IN A,($FE)" on the VZ keyboard.
; Returns Spectrum-format bits (0-4 active low, bits 5-7 set).
;-----------------------------------------------------------------------------
; row $FE (CAPS Z X C V) is read twice per interrupt: all five keys are on
; VZ row X2, so map that row's bits directly
VZ_SpecIN_FE:
        PUSH BC
        LD A,($68FB)
        LD C,A
        LD B,$FF
        BIT 2,C                         ; SHIFT -> CAPS
        JR NZ,.k1
        RES 0,B
.k1:    BIT 4,C                         ; Z
        JR NZ,.k2
        RES 1,B
.k2:    BIT 1,C                         ; X
        JR NZ,.k3
        RES 2,B
.k3:    BIT 3,C                         ; C
        JR NZ,.k4
        RES 3,B
.k4:    BIT 5,C                         ; V
        JR NZ,.k5
        RES 4,B
.k5:    LD A,B
        POP BC
        RET
VZ_SpecIN_F7:   LD A,$F7
                JR VZ_SpecIN
VZ_SpecIN_FB:   LD A,$FB
                JR VZ_SpecIN
VZ_SpecIN_00:   XOR A
VZ_SpecIN:
        PUSH BC
        PUSH DE
        PUSH HL
        LD D,A                          ; row select (0 bit = selected)
        LD E,$FF                        ; result (active low)
        LD HL,spec_keymap
        LD B,8
.row:   RRC D
        JR C,.skip
        PUSH BC
        LD B,5
        LD C,$01                        ; result bit
.key:   PUSH HL
        LD A,(HL)                       ; VZ row address low byte
        INC HL
        PUSH BC
        LD C,(HL)                       ; mask
        LD L,A
        LD H,$68
        LD A,(HL)
        AND C
        POP BC
        POP HL
        JR NZ,.up
        LD A,C
        CPL
        AND E
        LD E,A
.up:    INC HL
        INC HL
        RLC C
        DJNZ .key
        POP BC
        JR .next
.skip:  LD A,10
        ADD A,L
        LD L,A
        JR NC,.next
        INC H
.next:  DJNZ .row
        LD A,E
        OR $E0
        POP HL
        POP DE
        POP BC
        RET

;-----------------------------------------------------------------------------
; VZ_ReadKey - replaces $C263.  Scan the keyboard; if a key is pressed return
; carry set and A = its character (A-Z, 0-9, space, 13 = RETURN, $7F = delete
; (CTRL or SHIFT)).  Otherwise carry clear, A = 0.
;-----------------------------------------------------------------------------
VZ_ReadKey:
        CALL vz_ckpt
        PUSH BC
        PUSH DE
        PUSH HL
        LD HL,vz_keychars
        LD E,$FE                        ; row address low byte
.row:   LD D,$68
        LD A,(DE)
        CPL
        AND $3F
        JR Z,.nextrow
        LD B,6
        LD C,$20
.bit:   LD D,A
        AND C
        JR NZ,.found
        LD A,D
        INC HL
        SRL C
        DJNZ .bit
        JR .cont
.found: LD A,(HL)
        OR A
        JR Z,.nokey                     ; unmapped key
        SCF
        JR .out
.nextrow:
        LD A,L
        ADD A,6
        LD L,A
        JR NC,.cont
        INC H
.cont:  RLC E
        LD A,E
        CP $FE
        JR NZ,.row
.nokey: XOR A
.out:   POP HL
        POP DE
        POP BC
        RET

; VZ_WaitKey - replaces $C255: wait for all keys released, then for a key
VZ_WaitKey:
        CALL vz_ckpt
        CALL VZ_ReadKey
        JR C,VZ_WaitKey
        CALL vz_music_sel               ; title / preview music (until a key)
.w:     CALL VZ_ReadKey
        JR NC,.w
        RET

;-----------------------------------------------------------------------------
; Sound.  The Spectrum toggles bit 4 of port $FE; on the VZ the speaker is
; driven push-pull by latch bits 0 and 5, and the latch also holds the video
; mode bits, so the current mode is taken from the vz_latch shadow.
;
; VZ_SpkOn / VZ_SpkOff: set speaker high/low (preserve all but A)
;-----------------------------------------------------------------------------
VZ_SpkOn:
        LD A,(vz_latch)
        OR SPK_ON
        LD (VZ_LATCH),A
        RET
VZ_SpkOff:
        LD A,(vz_latch)
        OR SPK_OFF
        LD (VZ_LATCH),A
        RET

; VZ_OutFE: A = value the Spectrum would have written to port $FE
VZ_OutFE:
        AND $10
        JR Z,VZ_SpkOff
        JR VZ_SpkOn
