;=============================================================================
; Status row (VZ rows 0-3): energy icons and scanner
;=============================================================================

; pixel helpers for icon definitions: P c0,c1,c2,c3 -> one VZ byte
P       MACRO c0, c1, c2, c3
        DB (c0<<6)|(c1<<4)|(c2<<2)|c3
        ENDM
_G EQU C_GRN
_Y EQU C_YEL
_B EQU C_BLU
_R EQU C_RED

; VZ_DrawIcon - replaces DrawIcon at $BD57: draw icon A in column ($6005) of
; the status row and advance the column.  Preserves AF.
VZ_DrawIcon:
        PUSH AF
        PUSH BC
        PUSH DE
        PUSH HL
        AND $0F
        ADD A,A
        ADD A,A
        LD E,A
        LD D,0
        LD HL,vz_icons
        ADD HL,DE
        EX DE,HL
        LD A,($6005)                    ; column + 1, as the Spectrum's
        INC A                           ; DrawIcon ($4001 + column)
        AND $1F
        LD L,A
        LD H,VZ_VRAM>>8
        LD BC,32
        LD A,(DE)
        LD (HL),A
        INC DE
        ADD HL,BC
        LD A,(DE)
        LD (HL),A
        INC DE
        ADD HL,BC
        LD A,(DE)
        LD (HL),A
        INC DE
        ADD HL,BC
        LD A,(DE)
        LD (HL),A
        LD HL,$6005
        INC (HL)
        POP HL
        POP DE
        POP BC
        POP AF
        RET

vz_icons:
        P _B,_B,_B,_B : P _B,_B,_B,_B : P _B,_B,_B,_B : P _B,_B,_B,_B   ; 0 blank
        P _B,_G,_G,_B : P _G,_G,_G,_G : P _B,_G,_G,_B : P _B,_G,_B,_G   ; 1 robot (3)
        P _B,_G,_B,_B : P _G,_G,_G,_B : P _G,_G,_G,_B : P _B,_R,_B,_B   ; 2 tree (1)
        P _B,_B,_B,_B : P _B,_B,_B,_B : P _B,_B,_B,_B : P _B,_B,_B,_B   ; 3 (tree, 2nd half)
        P _B,_R,_R,_B : P _R,_R,_R,_R : P _R,_R,_R,_R : P _B,_R,_R,_B   ; 4 boulder (2)
        P _B,_B,_B,_B : P _B,_B,_B,_B : P _B,_B,_B,_B : P _B,_B,_B,_B   ; 5 (boulder, 2nd half)
        P _B,_Y,_Y,_B : P _Y,_Y,_Y,_Y : P _B,_Y,_Y,_B : P _B,_Y,_B,_Y   ; 6 gold robot (15)
        P _B,_B,_B,_Y : P _B,_B,_B,_Y : P _B,_B,_B,_Y : P _B,_B,_B,_Y   ; 7 scanner left
        P _Y,_Y,_Y,_Y : P _B,_B,_B,_B : P _B,_B,_B,_B : P _Y,_Y,_Y,_Y   ; 8 scanner middle
        P _Y,_B,_B,_B : P _Y,_B,_B,_B : P _Y,_B,_B,_B : P _Y,_B,_B,_B   ; 9 scanner right
        DS 6*4, C_BLU*$55                                                ; 10-15 unused

; VZ_ScannerFill - replaces the copier at $8D55.  DE = Spectrum screen address
; ($4216 or $421A: scanner halves), HL = source of 4 lines x 4 bytes (stride 4).
; VZ: 4 bytes on rows 1 and 2, colours = source bits XOR blue (so 0 = blue
; background, $FF = solid yellow, random bytes = coloured static).
VZ_ScannerFill:
        LD A,E
        AND $1F
        LD E,A
        LD D,(VZ_VRAM+32)>>8            ; row 1
        LD A,(VZ_VRAM+32)&$FF
        ADD A,E
        LD E,A
        CALL .line
        LD A,E
        ADD A,32-4
        LD E,A
        INC HL                          ; skip source line 1
        INC HL
        INC HL
        INC HL
        CALL .line
        INC HL                          ; skip source line 3
        INC HL
        INC HL
        INC HL
        LD B,0
        LD D,B
        RET
.line:  LD B,4
.b:     LD A,H                          ; the Spectrum's static is read from
        CP $40                          ; its ROM: on the VZ make our own
        LD A,(HL)                       ; noise there instead
        JR NC,.st
        LD A,(sc_seed)
        RLCA
        LD C,A
        LD A,R
        XOR C
        LD (sc_seed),A
.st:    XOR C_BLU*$55
        LD (DE),A
        INC HL
        INC DE
        DJNZ .b
        RET
sc_seed: DB $5A
