;=============================================================================
; Preview: "n SENTRIES" caption.  The original ($8AC0) clears a strip of the
; Spectrum screen at $5085 and renders the string at $8B1A there; on the VZ
; that address is inside the relocated game block, so the strip is replaced
; by VZ text just above "PRESS ANY KEY".
;=============================================================================
vz_sentries:                            ; JP from $8AE4
        LD HL,$8B1A
        LD C,0                          ; string length
.n:     LD A,(HL)
        OR A
        JR Z,.x
        INC HL
        INC C
        JR .n
.x:     LD A,C                          ; centre: x = 64 - 5n/2
        ADD A,A
        ADD A,A
        ADD A,C
        SRL A
        NEG
        ADD A,64
        LD (tx_x),A
        LD A,49
        LD (tx_row),A
        LD A,C_YEL*$55
        LD (tx_col),A
        LD HL,$8B1A
.l:     LD A,(HL)
        OR A
        JR Z,.done
        PUSH HL
        PUSH IX
        CALL vz_glyph
        POP IX
        POP HL
        LD A,(tx_x)
        ADD A,5
        LD (tx_x),A
        INC HL
        JR .l
.done:  LD B,0
        LD D,B
        RET
