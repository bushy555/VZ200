;=============================================================================
; Panning (replaces the Spectrum scroll routines called by ScrollPlayerView)
;
; The Spectrum pans left/right one byte column (8 pixels) per step, taking
; the new column from the 12-column screen buffer, and up/down one character
; row per step by sliding a window over a tall buffer image (the newly drawn
; 8-row strip plus a copy of the old view).  One Spectrum byte column is one
; VZ byte and one character row is three VZ rows, so the VZ versions follow
; the original step-for-step.
;
; Screen rows 1..23 are the view rows; 1..20 are in video RAM, 21..23 are
; kept off-screen (VZ_HIDDEN) so that panning down reveals the correct
; content.  Buffer rows 1..31 are in the VBUF chunks.
;=============================================================================

; HL = address of column 0 of screen view row A (1..23)
scr_row:
        DEC A
        ADD A,A
        LD L,A
        LD H,0
        PUSH DE
        LD DE,vz_rowtab
        ADD HL,DE
        POP DE
        LD A,(HL)
        INC HL
        LD H,(HL)
        LD L,A
        DEC HL
        RET

; HL = address of column 0 of buffer row A (0..31)
buf_row:
        LD H,A
        SRL H
        LD L,$40
        AND 1
        JR Z,.e
        LD L,$A0
.e:     LD A,H
        ADD A,$C6
        LD H,A
        RET

; copy view columns 1..30 of a 3-sub-row character row from HL to DE
copy_row:
        PUSH BC
        INC HL
        INC DE
        LD A,3
.s:     LD BC,30
        LDIR
        LD BC,2
        ADD HL,BC
        EX DE,HL
        ADD HL,BC
        EX DE,HL
        DEC A
        JR NZ,.s
        POP BC
        RET

; copy screen rows -> buffer rows: B = count, C = first screen row, E = first buffer row
scr_to_buf:
.l:     PUSH BC
        PUSH DE
        LD A,E
        CALL buf_row
        PUSH HL
        LD A,C
        CALL scr_row
        POP DE
        CALL copy_row
        POP DE
        POP BC
        INC C
        INC E
        DJNZ .l
        RET

; copy buffer rows -> screen rows: B = count, E = first buffer row, C = first screen row
buf_to_scr:
.l:     PUSH BC
        PUSH DE
        LD A,C
        CALL scr_row
        PUSH HL
        LD A,E
        CALL buf_row
        POP DE
        CALL copy_row
        POP DE
        POP BC
        INC C
        INC E
        DJNZ .l
        RET

; buffer rows -> buffer rows: B = count, E = first source row, C = first dest row
buf_to_buf:
.l:     PUSH BC
        PUSH DE
        LD A,C
        CALL buf_row
        PUSH HL
        LD A,E
        CALL buf_row
        POP DE
        CALL copy_row
        POP DE
        POP BC
        INC C
        INC E
        DJNZ .l
        RET

;-----------------------------------------------------------------------------
VZ_PanUp:                               ; replaces $B523 (pan up, dir 2)
        LD A,($60C1)
        CP 7
        JR NZ,.step
        LD B,22                         ; screen rows 1..22 -> buffer rows 9..30
        LD C,1
        LD E,9
        CALL scr_to_buf
.step:  LD A,($60C1)
        INC A
        LD E,A                          ; buffer rows c+1 .. c+23
        LD C,1
        LD B,23
        CALL buf_to_scr
        LD B,0
        LD D,B
        RET

VZ_PanDown:                             ; replaces $B555 (pan down, dir 3)
        LD A,($60C1)
        CP 7
        JR NZ,.step
        LD B,8                          ; new strip: buffer rows 1..8 -> 24..31
        LD E,1
        LD C,24
        CALL buf_to_buf
        LD B,23                         ; screen rows 1..23 -> buffer rows 1..23
        LD C,1
        LD E,1
        CALL scr_to_buf
.step:  LD A,($60C1)
        LD B,A
        LD A,9
        SUB B
        LD E,A                          ; buffer rows 9-c .. 9-c+22
        LD C,1
        LD B,23
        CALL buf_to_scr
        LD B,0
        LD D,B
        RET

VZ_PanRight:                            ; replaces $B4B1 (pan right, dir 0)
        LD A,($60C1)
        LD B,A
        LD A,11
        SUB B
        LD (ps_col),A
        LD C,1                          ; screen row
.row:   LD A,C
        CALL scr_row
        PUSH HL
        LD A,C
        CALL buf_row
        LD A,(ps_col)
        INC A
        ADD A,L
        LD L,A
        EX DE,HL                        ; DE = buffer source byte (sub-row 0)
        POP HL                          ; HL = screen row col 0
        LD B,3
.sub:   PUSH BC
        PUSH DE
        PUSH HL
        LD D,H
        LD E,L
        INC DE                          ; DE = col 1
        INC HL
        INC HL                          ; HL = col 2
        LD BC,29
        LDIR                            ; cols 2..30 -> 1..29, DE -> col 30
        POP HL
        EX (SP),HL                      ; HL = source
        LD A,(HL)
        LD (DE),A                       ; col 30 = new column
        LD BC,32
        ADD HL,BC
        EX DE,HL                        ; DE = next source
        POP HL
        ADD HL,BC                       ; next screen sub-row
        POP BC
        DJNZ .sub
        INC C
        LD A,C
        CP 24
        JR NZ,.row
        CALL vz_border
        LD B,0
        LD D,B
        RET

VZ_PanLeft:                             ; replaces $B43F (pan left, dir 1)
        LD A,($60C1)
        LD (ps_col),A
        LD C,1
.row:   LD A,C
        CALL scr_row
        PUSH HL
        LD A,C
        CALL buf_row
        LD A,(ps_col)
        INC A
        ADD A,L
        LD L,A
        EX DE,HL
        POP HL
        LD B,3
.sub:   PUSH BC
        PUSH DE
        PUSH HL
        LD BC,30
        ADD HL,BC                       ; HL = col 30
        LD D,H
        LD E,L
        DEC HL                          ; HL = col 29
        LD BC,29
        LDDR                            ; cols 29..1 -> 30..2, DE -> col 1
        POP HL
        EX (SP),HL                      ; HL = source
        LD A,(HL)
        LD (DE),A                       ; col 1 = new column
        LD BC,32
        ADD HL,BC
        EX DE,HL
        POP HL
        ADD HL,BC
        POP BC
        DJNZ .sub
        INC C
        LD A,C
        CP 24
        JR NZ,.row
        CALL vz_border
        LD B,0
        LD D,B
        RET

ps_col: DB 0

; vz_border: paint view columns 0 and 31 (outside the Spectrum view) solid
vz_border:
        LD HL,VZ_VRAM + 4*32
        LD DE,31
        LD B,60
        LD A,(border_col)
.l:     LD (HL),A
        ADD HL,DE
        LD (HL),A
        INC HL
        DJNZ .l
        RET
border_col: DB C_BLU*$55

;-----------------------------------------------------------------------------
; VZ_ShowBufferRect - replaces $BC09: copy columns ($6062)+1 .. +($6069) of
; the screen buffer onto the screen for all view rows (used after an object
; is redrawn in the buffer by DrawUpdatedObject)
;-----------------------------------------------------------------------------
VZ_ShowBufferRect:
        LD A,($6069)
        OR A
        JR Z,.out
        LD C,1
.row:   PUSH BC
        LD A,C
        CALL scr_row
        PUSH HL
        LD A,C
        CALL buf_row
        POP DE
        INC HL                          ; buffer source from column 1
        LD A,($6062)
        INC A
        ADD A,E
        LD E,A
        JR NC,.c
        INC D                           ; DE = screen column 1 + ($6062)
.c:
        LD A,3
.sub:   PUSH AF
        PUSH HL
        PUSH DE
        LD A,($6069)
        LD C,A
        LD B,0
        LDIR
        POP DE
        POP HL
        LD BC,32
        ADD HL,BC
        EX DE,HL
        ADD HL,BC
        EX DE,HL
        POP AF
        DEC A
        JR NZ,.sub
        POP BC
        INC C
        LD A,C
        CP 24
        JR NZ,.row
.out:   LD B,0
        LD D,B
        RET

;-----------------------------------------------------------------------------
; VZ_SetPalette - replaces SetColourPalette at $B957 (mode already stored at
; $B956).  The original hides the view while it is being drawn by setting
; ink = paper in the attributes (mode 2) and shows it with the next mode.
; The VZ cannot change colours on the fly, so in mode 2 the view rows are
; redirected to an off-screen shadow copy which is copied to video RAM when
; the next (visible) mode is selected - the view then appears instantly.
;-----------------------------------------------------------------------------
VZ_SetPalette:
        CP 2
        JR NZ,.show
        LD A,(vz_blanked)
        OR A
        JR NZ,.done
        INC A
        LD (vz_blanked),A
        LD A,(sp_last)                  ; leaving the title / code entry: blank
        CP $87                          ; the screen at once, as the Spectrum's
        CALL Z,vz_cls                   ; blue-on-blue attributes do
        LD HL,shadow_tab
        LD DE,vz_rowtab
        LD BC,40
        LDIR
        JR .done
.show:  LD (sp_last),A
        CALL vz_scheme_mode            ; colour scheme for this mode
        LD A,(vz_blanked)
        OR A
        JR Z,.done
        XOR A
        LD (vz_blanked),A
        LD HL,vram_tab                  ; restore the row table
        LD DE,vz_rowtab
        LD BC,40
        LDIR
        LD C,0                          ; copy shadow rows to the screen
.cp:    PUSH BC
        LD A,C
        ADD A,A
        LD L,A
        LD H,0
        LD DE,shadow_tab
        ADD HL,DE
        LD A,(HL)
        INC HL
        LD H,(HL)
        LD L,A                          ; HL = shadow row (column 1)
        PUSH HL
        LD A,C
        ADD A,A
        LD L,A
        LD H,0
        LD DE,vram_tab
        ADD HL,DE
        LD E,(HL)
        INC HL
        LD D,(HL)                       ; DE = screen row (column 1)
        POP HL
        LD A,3
.sub:   LD BC,30
        LDIR
        LD BC,2
        ADD HL,BC
        EX DE,HL
        ADD HL,BC
        EX DE,HL
        DEC A
        JR NZ,.sub
        POP BC
        INC C
        LD A,C
        CP 20
        JR NZ,.cp
        CALL vz_border
        CALL vz_cc_print
.done:  CALL vz_irq_resume
         LD B,0
        LD D,B
        RET

vz_blanked: DB 0

vram_tab:
        DUP 20, i
        DW VZ_VRAM + (4 + 3*i)*32 + 1
        EDUP
shadow_tab:                             ; 20 rows of 96 bytes in pages $D8-$E1
        DUP 20, i
        DW $D840 + (i/2)*256 + (i%2)*$60 + 1
        EDUP
