import sys
SKIP=[(0xBD7E,0xBE80),(0,0x5E00),(0x6600,0x6800),(0xFD00,0x10000),(0xC255,0xC500),(0xBFB4,0xC13C),(0x8D00,0x8DA0),(0xBC00,0xBD7E),
      (0x9955,0x9A5F),(0xB442,0xB4B1),(0xB558,0xB644),(0x98FD,0x9B9C),(0x9874,0x98FD),(0x8719,0x8760),(0x8950,0x8AC0),(0xB3C6,0xB644),(0xB957,0xBA80),(0xE600,0xE800)]
def load(f):
    out=[]
    for l in open(f):
        pc=int(l[:4],16)
        if any(s<=pc<e for s,e in SKIP): continue
        if out and out[-1]==pc: continue
        out.append(pc)
    return out
a=load(sys.argv[1]); b=load(sys.argv[2])
i=0;j=0
while i<len(a) and j<len(b):
    if a[i]==b[j]: i+=1;j+=1; continue
    print(i,'zx',' '.join('%04X'%x for x in a[i-20:i+15])); print(j,'vz',' '.join('%04X'%x for x in b[j-20:j+15])); break
print(len(a),len(b))
