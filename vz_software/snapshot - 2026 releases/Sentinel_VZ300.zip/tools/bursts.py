import sys, collections
f=sys.argv[1]; clk=float(sys.argv[2])
ev=[tuple(map(int,l.split())) for l in open(f)]
if not ev: print('empty'); sys.exit()
t0=ev[0][0]
bs=[];cur=[ev[0][0]]
for (a,_) in ev[1:]:
    if a-cur[-1]>clk*0.05: bs.append(cur);cur=[a]
    else: cur.append(a)
bs.append(cur)
for b in bs:
    d=[(y-x)/clk*1e6 for x,y in zip(b,b[1:])]
    med=sorted(d)[len(d)//2] if d else 0
    print('t=%6.2fs dur=%5.3fs n=%5d median half=%6.0fus'%((b[0]-t0)/clk,(b[-1]-b[0])/clk,len(b),med))
