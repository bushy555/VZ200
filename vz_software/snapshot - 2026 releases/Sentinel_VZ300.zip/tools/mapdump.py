import sys
m=open(sys.argv[1],'rb').read()
def addr(x,z): return (0x6100 + ((x&3)<<8)) | ((x<<3)&0xe0) | z
pl=m[0x650B]&0x3f
print('player obj',pl,'x',m[0xF800+pl],'y',m[0xF840+pl],'z',m[0xF880+pl],'yaw',hex(m[0xF8C0+pl]),'type',m[0xFAC0+pl], 'energy',m[0x600A])
types={0:'robot',1:'sentry',2:'tree',3:'boulder',4:'meanie',5:'sentinel',6:'pedestal'}
for i in range(64):
    t=m[0xFAC0+i]
    if m[0x5E00+i]&0x80 and False: continue
    if t<8 and (m[0xF800+i] or m[0xF880+i]):
        print(i,types.get(t,t),'x',m[0xF800+i],'y',m[0xF840+i],'z',m[0xF880+i],'yaw',hex(m[0xF8C0+i]),'under',hex(m[0x5E00+i]))
print('    '+''.join('%3d'%x for x in range(32)))
for z in range(31,-1,-1):
    row=[]
    for x in range(32):
        e=m[addr(x,z)]
        if e>=0xC0: row.append(' O%d'%(e&0x3f) if (e&0x3f)<10 else 'O%d'%(e&0x3f))
        else: row.append('%2X%s'%(e>>4, '.' if (e&15)==0 else chr(ord('a')+(e&15)-1)))
    print('%3d '%z+''.join(row))
