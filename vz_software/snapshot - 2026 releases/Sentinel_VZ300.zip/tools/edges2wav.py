"""Convert a speaker edge log (time_us level) to a 22.05 kHz WAV."""
import sys, wave, struct
ev=[(float(a),int(b)) for a,b in (l.split() for l in open(sys.argv[1]) if l.strip())]
rate=22050; end=ev[-1][0]/1e6+0.3
n=int(end*rate); out=bytearray(n)
# box-filter: average level per sample
lv=0; i=0
import math
acc=[0.0]*n
for k,(t,l) in enumerate(ev):
    pass
# integrate exactly
cur=0; tprev=0.0
for t,l in ev+[(end*1e6,0)]:
    t0=tprev/1e6; t1=t/1e6
    s0=int(t0*rate); s1=int(t1*rate)
    if cur:
        if s0==s1:
            if s0<n: acc[s0]+= (t1-t0)*rate
        else:
            if s0<n: acc[s0]+=(s0+1-t0*rate)
            for s in range(s0+1,min(s1,n)): acc[s]+=1
            if s1<n: acc[s1]+=(t1*rate-s1)
    cur=l; tprev=t
for s in range(n): out[s]=int(128+100*(acc[s]-0.5)) & 255
w=wave.open(sys.argv[2],'wb'); w.setnchannels(1); w.setsampwidth(1); w.setframerate(rate); w.writeframes(bytes(out)); w.close()
print(sys.argv[2], '%.1f s'%end)
