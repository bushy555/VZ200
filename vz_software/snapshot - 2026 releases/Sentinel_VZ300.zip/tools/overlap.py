"""Report addresses written by more than one line of the port's own source
(patches and new code), from the sjasmplus listing."""
import re, sys, collections
lst = open(sys.argv[1] if len(sys.argv) > 1 else 'main.lst').read().split('\n')
cur = None; owners = collections.defaultdict(list)
for l in lst:
    m = re.match(r'# file opened: (.*)', l)
    if m: cur = m.group(1); continue
    m = re.match(r'\s*(\d+)\+*\s*([0-9A-F]{4})((?: [0-9A-F]{2})+)', l)
    if m and cur and 'gen/' not in cur and 'seg_' not in cur:
        a = int(m.group(2), 16)
        for k in range(len(m.group(3).split())):
            owners[a + k].append('%s:%s' % (cur.split('/')[-1], m.group(1)))
bad = {a: o for a, o in owners.items() if len(set(o)) > 1}
for a in sorted(bad)[:40]: print('%04X' % a, bad[a])
print('overlapping bytes:', len(bad))
