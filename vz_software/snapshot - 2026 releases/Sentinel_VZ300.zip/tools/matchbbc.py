#!/usr/bin/env python3
"""Match Spectrum Sentinel routines to BBC routines by variable access sequences."""
import sys, json, re, bisect, difflib
sys.path.insert(0, '/home/claude/sentinel/tools')
from z80dis import disasm

sym = json.load(open('/home/claude/sentinel/dis/bbcsym.json'))
src = open('/home/claude/sentinel/tools/bbcsentinel/1-source-files/main-sources/the-sentinel-source.asm').read().split('\n')

# ---- BBC routines: sequences of variable addresses
bbc = {}
cur = None
order = []
for l in src:
    m = re.match(r'^\.([A-Za-z]\w*)\s*$', l)
    if m:
        name = m.group(1)
        if name[0].isupper() and name in sym and 0x0D00 <= sym[name] < 0x7000:
            # treat as a routine only if code follows (heuristic: uppercase)
            cur = name; bbc.setdefault(cur, []); order.append(cur)
        continue
    m = re.match(r'^\s+(LDA|STA|LDX|STX|LDY|STY|ADC|SBC|AND|ORA|EOR|CMP|CPX|CPY|INC|DEC|ASL|LSR|ROL|ROR|BIT|JSR|JMP)\s+#?\(?([A-Za-z]\w*)', l)
    if m and cur:
        op, s = m.group(1), m.group(2)
        if '#' in l.split(op, 1)[1].split('\\')[0][:3]:
            continue
        if s in sym:
            a = sym[s]
            if op in ('JSR', 'JMP'):
                bbc[cur].append('J:' + s)
            elif a < 0x0D00 or 0x3E80 <= a < 0x3F00 or 0x5A00 <= a < 0x5C00:
                bbc[cur].append('%04X' % a)

def zx2bbc(a):
    if 0x6500 <= a < 0x6600: return a - 0x6500
    if 0x6000 <= a < 0x6100: return a - 0x6000 + 0x0C00
    if 0x5E00 <= a < 0x5F00: return a - 0x5E00 + 0x0100
    if 0xF800 <= a < 0xF900: return a - 0xF800 + 0x0900
    if 0xFB00 <= a < 0xFC00: return a - 0xFB00 + 0x5A00
    if 0xFC00 <= a < 0xFD00: return a - 0xFC00 + 0x5B00
    if 0x7380 <= a < 0x7400: return a - 0x7380 + 0x3E80
    if 0x6100 <= a < 0x6500: return a - 0x6100 + 0x0400
    return None

mem = open('/home/claude/sentinel/orig/title.mem', 'rb').read()
an = json.load(open('/home/claude/sentinel/dis/analysis.json'))
calls = sorted(c for c in an['calls'] if c >= 0x7600)
code = sorted(an['code'])
zx = {}
for i, r in enumerate(calls):
    end = calls[i + 1] if i + 1 < len(calls) else 0xC600
    seq = []
    for a in code:
        if r <= a < end:
            n, t, info = disasm(mem, a)
            if info['kind'] == 'call' and info['target'] is not None:
                seq.append('C:%04X' % info['target'])
            elif info['imm16'] is not None and info['mem16'] or (info['imm16'] is not None and 'LD HL' in t):
                b = zx2bbc(info['imm16'])
                if b is not None:
                    seq.append('%04X' % b)
    zx[r] = seq

res = {}
for r, seq in zx.items():
    s1 = [x for x in seq if not x.startswith('C:')]
    if len(s1) < 3:
        continue
    best = []
    for name, bs in bbc.items():
        b1 = [x for x in bs if not x.startswith('J:')]
        if len(b1) < 2: continue
        sm = difflib.SequenceMatcher(None, s1, b1, autojunk=False)
        sc = sm.ratio()
        best.append((sc, name))
    best.sort(reverse=True)
    res['%04X' % r] = best[:3]
    print('%04X %-28s %.2f  (%s %.2f, %s %.2f)  n=%d' % (r, best[0][1], best[0][0], best[1][1], best[1][0], best[2][1], best[2][0], len(s1)))
json.dump(res, open('/home/claude/sentinel/dis/bbcmatch.json', 'w'))
