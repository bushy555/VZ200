#!/bin/sh
# profframes.sh FROM N : profile N frames starting at absolute frame FROM in the bench session
python3 - $1 $2 <<'P'
import sys
L=open('bench.txt').read().split('\n')
i=[k for k,l in enumerate(L) if l.startswith('prof on')][0]
f0=int(sys.argv[1]); n=int(sys.argv[2])
open('pf.txt','w').write('\n'.join(L[:i]+['tap SPACE 10','run %d'%(f0-2501),'prof on','run %d'%n,'prof pf.prof'])+'\n')
P
../tools/vzemu/vzemu ../build/SENTINEL.VZ pf.txt >/dev/null 2>&1
python3 ../tools/profsum.py pf.prof vz 8
