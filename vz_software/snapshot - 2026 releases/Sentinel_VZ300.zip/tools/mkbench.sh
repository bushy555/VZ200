#!/bin/sh
# bench: from pressing SPACE on the 0000 preview until the game view is shown
# (watch: SetPalette entry/exit, IRQ ticks)
S=../build/main.sym
SP=$(grep "^VZ_SetPalette:" $S | sed 's/.*0x0000//')
SD=$(grep "^VZ_SetPalette.done:" $S | sed 's/.*0x0000//')
(head -n -3 vstart.txt; echo "run 1500"; echo "prof on"; echo "watch $SP"; echo "watch $SD"; echo "watch BD98 3000"; echo "tap SPACE 10"; echo "run 500"; echo "prof $1"; echo "dump $1.mem"; echo "run 3"; echo "shot $1.ppm") > bench.txt
../tools/vzemu/vzemu ../build/SENTINEL.VZ bench.txt 2>&1 | grep "stop\|^W" | cut -c1-40
