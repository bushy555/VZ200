"""Aggregate a vzemu/zxemu profile (8-byte cycle counts per PC) by routine."""
import sys, struct, re, json, bisect, os
R=os.path.dirname(os.path.abspath(__file__))+'/..'
prof=struct.unpack('<65536Q',open(sys.argv[1],'rb').read())
reloc = len(sys.argv)>2 and sys.argv[2]=='vz'
names={}
for l in open(R+'/dis/bbcmatch.txt'):
    p=l.split()
    if len(p)>=2 and re.match(r'^[0-9A-F]{4}$',p[0]):
        a=int(p[0],16)
        if reloc and 0x6600<=a<0x7807: a-=0x2000
        names[a]=p[1]
an=json.load(open(R+'/dis/analysis.json'))
for c in an['calls']:
    a=int(c,16) if isinstance(c,str) else c
    if reloc and 0x6600<=a<0x7807: a-=0x2000
    names.setdefault(a,'sub_%04X'%a)
if reloc:
    for l in open(R+'/build/main.sym'):
        m=re.match(r'([A-Za-z_][\w]*): EQU 0x0000([0-9A-F]{4})',l)
        if m and '.' not in m.group(1) and not m.group(1).startswith('L'):
            names[int(m.group(2),16)]=m.group(1)
starts=sorted(names)
tot=sum(prof); agg={}
for pc,c in enumerate(prof):
    if not c: continue
    i=bisect.bisect_right(starts,pc)-1
    k=names[starts[i]] if i>=0 else '?'
    agg[k]=agg.get(k,0)+c
print('total %.1fM T'%(tot/1e6))
for k,v in sorted(agg.items(),key=lambda x:-x[1])[:int(sys.argv[3]) if len(sys.argv)>3 else 30]:
    print('%-28s %6.2f%% %8.2fM'%(k,100*v/tot,v/1e6))
