import sys
from PIL import Image
for f in sys.argv[1:]:
    im=Image.open(f); im=im.resize((im.width*2,im.height*2),Image.NEAREST); im.save(f.rsplit('.',1)[0]+'.png')
