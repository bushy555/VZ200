// Minimal scripted ZX Spectrum 48K emulator for reverse-engineering.
// Usage: zxemu <stateprefix> <script>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../z80c/z80.h"

static uint8_t mem[65536];
static uint8_t cov[65536];
static unsigned long long prof[65536]; static int profiling;      // executed-opcode coverage
static uint8_t rdmap[65536];    // read map (data)
static uint8_t wrmap[65536];    // write map
static uint8_t keys[8];         // keyboard rows, bit=1 pressed
static int border;
static unsigned long long total_t;
static FILE *beepf;
static int lastbeep = -1;
static int kempston;
static unsigned long long frame;
static int tracing; static FILE *tracef;
static unsigned long instr_count;

static uint16_t curpc; static uint32_t pcread[65536], pcwrite[65536]; static uint16_t wmin[65536], wmax[65536];
static int region(uint16_t a) {
  if (a < 0x4000) return 0; if (a < 0x5800) return 1; if (a < 0x5B00) return 2; if (a < 0x5E00) return 3;
  if (a < 0x6800) return 4; if (a < 0x7800) return 5; if (a < 0xC600) return 6; if (a < 0xDD00) return 7;
  if (a < 0xEA00) return 8; if (a < 0xF800) return 9; if (a < 0xFC00) return 10; return 11; }
static uint8_t dread[65536];
static uint8_t rb(void *u, uint16_t a) { rdmap[a] = 1; if ((uint16_t)(a - curpc) > 3) dread[a] = 1; pcread[curpc] |= 1u << region(a); return mem[a]; }
static void wb(void *u, uint16_t a, uint8_t v) { pcwrite[curpc] |= 1u << region(a); if (a < 0xFF00) { if (!wmin[curpc] || a < wmin[curpc]) wmin[curpc] = a; if (a > wmax[curpc]) wmax[curpc] = a; } if (a >= 0x4000) { mem[a] = v; wrmap[a] = 1; } }
static uint8_t pin(z80 *z, uint16_t port) {
  if ((port & 1) == 0) {
    uint8_t r = 0x1f; uint8_t hi = port >> 8;
    for (int i = 0; i < 8; i++) if (!(hi & (1 << i))) r &= ~keys[i];
    return r | 0xa0;
  }
  if ((port & 0xff) == 0x1f) return kempston;
  return 0xff;
}
static void pout(z80 *z, uint16_t port, uint8_t v) {
  if ((port & 1) == 0) {
    border = v & 7;
    int b = (v >> 4) & 1;
    if (beepf && b != lastbeep) { fprintf(beepf, "%llu %d\n", total_t + z->cyc, b); }
    lastbeep = b;
  }
}

static const char *keynames[8][5] = {
  {"CAPS","Z","X","C","V"}, {"A","S","D","F","G"}, {"Q","W","E","R","T"}, {"1","2","3","4","5"},
  {"0","9","8","7","6"}, {"P","O","I","U","Y"}, {"ENTER","L","K","J","H"}, {"SPACE","SYM","M","N","B"}};
static int setkey(const char *n, int down) {
  for (int r = 0; r < 8; r++) for (int c = 0; c < 5; c++) if (!strcmp(n, keynames[r][c])) {
    if (down) keys[r] |= 1 << c; else keys[r] &= ~(1 << c); return 1; }
  fprintf(stderr, "bad key %s\n", n); return 0;
}

static z80 cpu;
static void load(const char *pre) {
  char fn[512]; snprintf(fn, sizeof fn, "%s.mem", pre);
  FILE *f = fopen(fn, "rb"); fread(mem, 1, 65536, f); fclose(f);
  snprintf(fn, sizeof fn, "%s.regs", pre);
  f = fopen(fn, "r"); char buf[1024]; fgets(buf, sizeof buf, f); fclose(f);
  char *p = strtok(buf, " \n");
  while (p) {
    char k[16]; int v; sscanf(p, "%15[^=]=%d", k, &v);
#define R16(n, H, L) if (!strcmp(k, n)) { cpu.H = v >> 8; cpu.L = v & 0xff; }
    R16("bc", b, c) R16("de", d, e) R16("hl", h, l) R16("bc2", b_, c_) R16("de2", d_, e_) R16("hl2", h_, l_)
    if (!strcmp(k, "af")) { cpu.a = v >> 8; uint8_t f = v; cpu.sf = f>>7&1; cpu.zf=f>>6&1; cpu.yf=f>>5&1; cpu.hf=f>>4&1; cpu.xf=f>>3&1; cpu.pf=f>>2&1; cpu.nf=f>>1&1; cpu.cf=f&1; }
    if (!strcmp(k, "af2")) { cpu.a_ = v >> 8; cpu.f_ = v & 0xff; }
    if (!strcmp(k, "ix")) cpu.ix = v; if (!strcmp(k, "iy")) cpu.iy = v; if (!strcmp(k, "sp")) cpu.sp = v; if (!strcmp(k, "pc")) cpu.pc = v;
    if (!strcmp(k, "i")) cpu.i = v; if (!strcmp(k, "r")) cpu.r = v; if (!strcmp(k, "iff")) cpu.iff1 = cpu.iff2 = v;
    if (!strcmp(k, "im")) cpu.interrupt_mode = v; if (!strcmp(k, "border")) border = v;
    p = strtok(NULL, " \n");
  }
}
static uint8_t getf(void) { return cpu.sf<<7|cpu.zf<<6|cpu.yf<<5|cpu.hf<<4|cpu.xf<<3|cpu.pf<<2|cpu.nf<<1|cpu.cf; }
static void save(const char *pre) {
  char fn[512]; snprintf(fn, sizeof fn, "%s.mem", pre);
  FILE *f = fopen(fn, "wb"); fwrite(mem, 1, 65536, f); fclose(f);
  snprintf(fn, sizeof fn, "%s.regs", pre); f = fopen(fn, "w");
  fprintf(f, "af=%d bc=%d de=%d hl=%d af2=%d bc2=%d de2=%d hl2=%d ix=%d iy=%d sp=%d pc=%d i=%d r=%d iff=%d im=%d border=%d\n",
    cpu.a<<8|getf(), cpu.b<<8|cpu.c, cpu.d<<8|cpu.e, cpu.h<<8|cpu.l, cpu.a_<<8|cpu.f_, cpu.b_<<8|cpu.c_, cpu.d_<<8|cpu.e_, cpu.h_<<8|cpu.l_,
    cpu.ix, cpu.iy, cpu.sp, cpu.pc, cpu.i, cpu.r, cpu.iff1, cpu.interrupt_mode, border);
  fclose(f);
}
static void shot(const char *fn) {
  static const uint8_t pal[16][3] = {{0,0,0},{0,0,205},{205,0,0},{205,0,205},{0,205,0},{0,205,205},{205,205,0},{205,205,205},
    {0,0,0},{0,0,255},{255,0,0},{255,0,255},{0,255,0},{0,255,255},{255,255,0},{255,255,255}};
  FILE *f = fopen(fn, "wb"); fprintf(f, "P6 256 192 255\n");
  for (int y = 0; y < 192; y++) for (int x = 0; x < 256; x++) {
    int a = 0x4000 | ((y & 0xc0) << 5) | ((y & 7) << 8) | ((y & 0x38) << 2) | (x >> 3);
    int at = mem[0x5800 + (y >> 3) * 32 + (x >> 3)];
    int bit = (mem[a] >> (7 - (x & 7))) & 1;
    int ink = (at & 7) | ((at & 64) >> 3), pap = ((at >> 3) & 7) | ((at & 64) >> 3);
    const uint8_t *c = pal[bit ? ink : pap]; fwrite(c, 1, 3, f);
  }
  fclose(f);
}
static unsigned long long brk_hits; static int brk_addr = -1; static int stop_at = -1;
static int watch[16]; static int nwatch; static int watchlimit = 50; static int wm[32]; static int nwm;
static uint8_t getf(void);

static void run_frames(int n) {
  for (int i = 0; i < n; i++) {
    if (cpu.iff1) z80_gen_int(&cpu, 0xff);
    unsigned long start = cpu.cyc;
    while (cpu.cyc - start < 69888) {
      cov[cpu.pc] = 1;
      if (cpu.pc == brk_addr) brk_hits++;
      for (int w = 0; w < nwatch; w++) if (cpu.pc == watch[w] && watchlimit > 0) { watchlimit--;
        printf("W %04X f%llu A=%02X F=%02X BC=%02X%02X DE=%02X%02X HL=%02X%02X IX=%04X IY=%04X SP=%04X [SP]=%04X\n", cpu.pc, frame, cpu.a, getf(), cpu.b, cpu.c, cpu.d, cpu.e, cpu.h, cpu.l, cpu.ix, cpu.iy, cpu.sp, mem[cpu.sp]|(mem[(cpu.sp+1)&0xffff]<<8)); printf(" (HL)=%02X", mem[cpu.h<<8|cpu.l]); for (int q = 0; q < nwm; q++) printf("  [%04X]=%02X", wm[q], mem[wm[q]]); printf("\n"); }
      if (tracing && tracef) fprintf(tracef, "%04X\n", cpu.pc);
      if (cpu.pc == stop_at) { fprintf(stderr, "stop at %04X frame %llu\n", stop_at, frame); stop_at = -1; return; }
      { unsigned long c0 = cpu.cyc; uint16_t pc0 = cpu.pc; curpc = pc0; z80_step(&cpu); if (profiling) prof[pc0] += cpu.cyc - c0; } instr_count++;
    }
    total_t += cpu.cyc - start; cpu.cyc = 0; frame++;
  }
}

int main(int argc, char **argv) {
  z80_init(&cpu);
  cpu.read_byte = rb; cpu.write_byte = wb; cpu.port_in = pin; cpu.port_out = pout;
  load(argv[1]);
  FILE *s = fopen(argv[2], "r"); char line[512];
  while (fgets(line, sizeof line, s)) {
    char cmd[64], a1[256] = "", a2[256] = ""; int n = sscanf(line, "%63s %255s %255s", cmd, a1, a2);
    if (n < 1 || cmd[0] == '#') continue;
    if (!strcmp(cmd, "run")) run_frames(atoi(a1));
    else if (!strcmp(cmd, "press")) setkey(a1, 1);
    else if (!strcmp(cmd, "release")) setkey(a1, 0);
    else if (!strcmp(cmd, "tap")) { setkey(a1, 1); run_frames(a2[0] ? atoi(a2) : 3); setkey(a1, 0); run_frames(3); }
    else if (!strcmp(cmd, "kemp")) kempston = strtol(a1, 0, 0);
    else if (!strcmp(cmd, "shot")) shot(a1);
    else if (!strcmp(cmd, "save")) save(a1);
    else if (!strcmp(cmd, "dread")) { FILE *o = fopen(a1, "wb"); fwrite(dread, 1, 65536, o); fclose(o); }
    else if (!strcmp(cmd, "load")) { z80_init(&cpu); cpu.read_byte = rb; cpu.write_byte = wb; cpu.port_in = pin; cpu.port_out = pout; load(a1); memset(keys, 0, 8); }
    else if (!strcmp(cmd, "peek")) { int a = strtol(a1, 0, 16), n = a2[0] ? atoi(a2) : 1; printf("P %04X:", a); for (int i = 0; i < n; i++) printf(" %02X", mem[(a + i) & 0xffff]); printf("\n"); }
    else if (!strcmp(cmd, "beep")) beepf = fopen(a1, "w");
    else if (!strcmp(cmd, "brk")) { brk_addr = strtol(a1, 0, 16); brk_hits = 0; }
    else if (!strcmp(cmd, "watch")) { watch[nwatch++] = strtol(a1, 0, 16); if (a2[0]) watchlimit = atoi(a2); }
    else if (!strcmp(cmd, "unwatch")) nwatch = 0;
    else if (!strcmp(cmd, "wmem")) wm[nwm++] = strtol(a1, 0, 16);
    else if (!strcmp(cmd, "prof")) { if (!strcmp(a1, "on")) { profiling = 1; memset(prof, 0, sizeof prof); } else { profiling = 0; FILE *f = fopen(a1, "wb"); fwrite(prof, 8, 65536, f); fclose(f); } }
    else if (!strcmp(cmd, "pcrw")) { FILE *f = fopen(a1, "wb"); fwrite(pcread, 4, 65536, f); fwrite(pcwrite, 4, 65536, f); fwrite(wmin, 2, 65536, f); fwrite(wmax, 2, 65536, f); fclose(f); }
    else if (!strcmp(cmd, "hits")) printf("hits %04X = %llu\n", brk_addr, brk_hits);
    else if (!strcmp(cmd, "stopat")) { stop_at = strtol(a1, 0, 16); }
    else if (!strcmp(cmd, "trace")) { if (!strcmp(a1, "off")) { tracing = 0; if (tracef) fclose(tracef); tracef = 0; } else { tracef = fopen(a1, "w"); tracing = 1; } }
    else if (!strcmp(cmd, "regs")) printf("frame %llu PC=%04X SP=%04X AF=%02X%02X BC=%02X%02X DE=%02X%02X HL=%02X%02X IX=%04X IY=%04X IM=%d IFF=%d\n",
        frame, cpu.pc, cpu.sp, cpu.a, getf(), cpu.b, cpu.c, cpu.d, cpu.e, cpu.h, cpu.l, cpu.ix, cpu.iy, cpu.interrupt_mode, cpu.iff1);
    else if (!strcmp(cmd, "cov")) { FILE *f = fopen(a1, "wb"); fwrite(cov, 1, 65536, f); fclose(f);
        if (a2[0]) { f = fopen(a2, "wb"); for (int i = 0; i < 65536; i++) { uint8_t v = rdmap[i] | (wrmap[i] << 1); fputc(v, f); } fclose(f); } }
    else if (!strcmp(cmd, "poke")) mem[strtol(a1, 0, 16)] = strtol(a2, 0, 16);
    else if (!strcmp(cmd, "print")) printf("%s", line + 6);
    else fprintf(stderr, "?? %s\n", cmd);
  }
  if (beepf) fclose(beepf);
  printf("frames=%llu instrs=%lu\n", frame, instr_count);
  return 0;
}
