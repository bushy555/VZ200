import sys
sys.path.insert(0,'/home/claude/sentinel/tools/skoolkit')
from skoolkit.snapshot import Snapshot
s=Snapshot.get(sys.argv[1])
rom=open('/home/claude/sentinel/tools/skoolkit/skoolkit/resources/48.rom','rb').read()
mem=rom+bytes(s.ram(-1))[-49152:]
assert len(mem)==65536
open(sys.argv[2]+'.mem','wb').write(mem)
r=dict(af=(s.a<<8)|s.f, bc=s.bc, de=s.de, hl=s.hl, af2=(s.a2<<8)|s.f2, bc2=s.bc2, de2=s.de2, hl2=s.hl2,
       ix=s.ix, iy=s.iy, sp=s.sp, pc=s.pc, i=s.i, r=s.r, iff=s.iff1, im=s.im, border=s.border)
open(sys.argv[2]+'.regs','w').write(' '.join('%s=%d'%kv for kv in r.items())+'\n')
print(r)
