// Call a sound routine in a memory image and log speaker edges (time in us).
// usage: sndtest zx|vz mem.bin addr A BC DE HL [maxcycles]
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../z80c/z80.h"
static uint8_t mem[65536]; static int vz; static z80 cpu; static int last = -1; static double clk;
static uint8_t rb(void *u, uint16_t a) { if (vz && a >= 0x6800 && a < 0x7000) return 0xFF; return mem[a]; }
static void edge(int lv) { if (lv != last) { printf("%.1f %d\n", cpu.cyc / clk * 1e6, lv); last = lv; } }
static void wb(void *u, uint16_t a, uint8_t v) {
  if (vz && a >= 0x6800 && a < 0x7000) { edge(v & 1); return; }
  if (a >= 0x4000 || vz) mem[a] = v; }
static uint8_t pin(z80 *z, uint16_t p) { return 0xFF; }
static void pout(z80 *z, uint16_t p, uint8_t v) { if (!vz && (p & 1) == 0) edge((v >> 4) & 1); }
int main(int c, char **v) {
  vz = !strcmp(v[1], "vz"); clk = vz ? 3546900.0 : 3500000.0;
  FILE *f = fopen(v[2], "rb"); fread(mem, 1, 65536, f); fclose(f);
  z80_init(&cpu); cpu.read_byte = rb; cpu.write_byte = wb; cpu.port_in = pin; cpu.port_out = pout;
  unsigned a = strtol(v[4], 0, 16), bc = strtol(v[5], 0, 16), de = strtol(v[6], 0, 16), hl = strtol(v[7], 0, 16);
  unsigned long maxc = c > 8 ? atol(v[8]) : 50000000;
  for (int i = 9; i < c; i++) { unsigned pa, pv; sscanf(v[i], "%x:%x", &pa, &pv); mem[pa] = pv; }
  cpu.a = a; cpu.b = bc >> 8; cpu.c = bc; cpu.d = de >> 8; cpu.e = de; cpu.h = hl >> 8; cpu.l = hl;
  cpu.sp = 0xFF00; mem[0xFF00] = 0x00; mem[0xFF01] = 0x00;  // return to $0000 -> stop
  cpu.pc = strtol(v[3], 0, 16);
  while (cpu.pc != 0 && cpu.cyc < maxc) z80_step(&cpu);
  fprintf(stderr, "end pc=%04X cyc=%lu (%.1f ms)\n", cpu.pc, cpu.cyc, cpu.cyc / clk * 1e3);
}
