#!/usr/bin/env python3
"""Minimal TZX / CDT block extractor. Dumps each data block to outdir."""
import sys, os, struct

def parse(path, outdir):
    d = open(path, 'rb').read()
    assert d[:7] in (b'ZXTape!',), d[:8]
    p = 10
    n = 0
    os.makedirs(outdir, exist_ok=True)
    while p < len(d):
        bid = d[p]; p += 1
        data = None
        info = ''
        if bid == 0x10:
            pause, ln = struct.unpack_from('<HH', d, p); p += 4
            data = d[p:p+ln]; p += ln
            info = f'std pause={pause}'
        elif bid == 0x11:
            pilot, s1, s2, z, o, pl, lb, used, pause = struct.unpack_from('<HHHHHHHBH', d, p)
            ln = d[p+15] | (d[p+16] << 8) | (d[p+17] << 16)
            p += 18
            data = d[p:p+ln]; p += ln
            info = f'turbo pilot={pilot} s1={s1} s2={s2} z={z} o={o} pl={pl} used={used} pause={pause}'
        elif bid == 0x12:
            p += 4; info = 'pure tone'
        elif bid == 0x13:
            c = d[p]; p += 1 + 2*c; info = 'pulses'
        elif bid == 0x14:
            z, o, used, pause = struct.unpack_from('<HHBH', d, p)
            ln = d[p+7] | (d[p+8] << 8) | (d[p+9] << 16)
            p += 10
            data = d[p:p+ln]; p += ln
            info = f'pure data z={z} o={o}'
        elif bid == 0x15:
            ln = d[p+5] | (d[p+6] << 8) | (d[p+7] << 16); p += 8 + ln; info = 'direct rec'
        elif bid == 0x20:
            p += 2; info = 'pause'
        elif bid == 0x21:
            l = d[p]; info = 'group ' + d[p+1:p+1+l].decode('latin1'); p += 1 + l
        elif bid == 0x22:
            info = 'group end'
        elif bid == 0x24:
            p += 2; info = 'loop start'
        elif bid == 0x25:
            info = 'loop end'
        elif bid == 0x30:
            l = d[p]; info = 'text ' + d[p+1:p+1+l].decode('latin1'); p += 1 + l
        elif bid == 0x31:
            l = d[p+1]; info = 'msg'; p += 2 + l
        elif bid == 0x32:
            ln = struct.unpack_from('<H', d, p)[0]
            blk = d[p+2:p+2+ln]; p += 2 + ln
            cnt = blk[0]; q = 1; s = []
            for i in range(cnt):
                t, l = blk[q], blk[q+1]; s.append(blk[q+2:q+2+l].decode('latin1')); q += 2 + l
            info = 'archive ' + ' | '.join(s)
        elif bid == 0x33:
            c = d[p]; p += 1 + 3*c; info = 'hwtype'
        elif bid == 0x35:
            ln = struct.unpack_from('<I', d, p+16)[0]; p += 20 + ln; info = 'custom'
        elif bid == 0x5A:
            p += 9
        else:
            print('unknown block', hex(bid), 'at', p); break
        if data is not None:
            fn = os.path.join(outdir, f'blk{n:02d}.bin')
            open(fn, 'wb').write(data)
            print(f'{n:02d} id={bid:02x} len={len(data)} flag={data[0]:02x} {info}')
            n += 1
        else:
            print(f'   id={bid:02x} {info}')

if __name__ == '__main__':
    parse(sys.argv[1], sys.argv[2])
