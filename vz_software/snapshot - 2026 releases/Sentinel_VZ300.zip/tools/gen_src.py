#!/usr/bin/env python3
"""Generate reassemblable sjasmplus source for The Sentinel (ZX Spectrum)
memory image $5B00-$FFFF.

usage: gen_src.py mem analysis.json outdir [reloc]
  reloc: if given, the $6800-$77FF block is assembled at $4800.
Each output line keeps the original address in a comment.
"""
import sys, json, os, bisect
sys.path.insert(0, os.path.dirname(__file__))
from z80dis import disasm

LO = 0x5B00
BLK_LO, BLK_HI, BLK_NEW = 0x6600, 0x7807, 0x4600

# 8-bit immediates that are really high bytes of addresses (manual review)
IMM8_HIGH = {0x8974: 0x7400, 0x9976: 0x6F00}
# data tables holding high bytes of addresses inside the block
HI_TABLES = [(0x69C0, 0x6A60)]
# immediates in the block range that are NOT addresses (manual review)
NOT_ADDR16 = set()


def main():
    mem = open(sys.argv[1], 'rb').read()
    an = json.load(open(sys.argv[2]))
    outdir = sys.argv[3]
    reloc = len(sys.argv) > 4
    os.makedirs(outdir, exist_ok=True)
    CODE_RANGES = [(0x7600, 0xC5AA), (0xE600, 0xE800), (0xFD00, 0xFE00)]  # C5AA+ is read as data by the anti-cracker stash
    codestarts = set(a for a in an['code'] if any(s <= a < e for s, e in CODE_RANGES))
    insn = {}
    covered = bytearray(65536)
    for a in sorted(codestarts):
        n, t, i = disasm(mem, a)
        insn[a] = (n, i)
        for k in range(n):
            covered[a + k] = 1
    # --- collect label targets
    targets = set()
    for a, (n, i) in insn.items():
        if i['target'] is not None and i['kind'] != 'rst':
            targets.add(i['target'])
        if i['imm16'] is not None and LO <= i['imm16'] <= 0xFFFF and a not in NOT_ADDR16:
            targets.add(i['imm16'])
    for a, v in IMM8_HIGH.items():
        targets.add(v)
    # --- determine line starts: code instructions + data chunks (split at targets)
    lines = []   # (addr, kind, length)
    a = LO
    while a < 0x10000:
        if a in codestarts:
            n = insn[a][0]
            lines.append((a, 'c', n))
            a += n
        else:
            st = a
            a += 1
            while a < 0x10000 and a not in codestarts and not covered[a] and a not in targets and a - st < 8 \
                    and not (a == BLK_LO or a == BLK_HI):
                a += 1
            lines.append((st, 'd', a - st))
    starts = [l[0] for l in lines]
    startset = set(starts)

    def labexpr(v):
        """Symbolic expression for address v."""
        if v < LO or v > 0xFFFF:
            return '$%04X' % v
        i = bisect.bisect_right(starts, v) - 1
        base = starts[i]
        if base == v:
            return 'L%04X' % v
        return 'L%04X+%d' % (base, v - base)

    used_labels = set()
    for v in targets:
        if LO <= v <= 0xFFFF:
            used_labels.add(labexpr(v).split('+')[0])

    def emit_line(f, a, kind, n):
        lab = 'L%04X' % a
        pre = (lab + ':') if lab in used_labels else ''
        if kind == 'c':
            nn, txt, info = disasm(mem, a, labexpr)
            if a in IMM8_HIGH:
                v = IMM8_HIGH[a]
                txt = txt.rsplit(',', 1)[0] + ',HIGH ' + labexpr(v) if ',' in txt else txt.split(' ')[0] + ' HIGH ' + labexpr(v)
            if a in NOT_ADDR16 and info['imm16'] is not None:
                nn, txt, info = disasm(mem, a)
            txt = txt.replace('SLL ', 'SLI ').replace("AF,AF'", 'AF,AF')
            f.write('%-8s %-28s ; %04X %s\n' % (pre, txt, a, ' '.join('%02X' % mem[a + k] for k in range(n))))
        else:
            def db(addr):
                b = mem[addr]
                if reloc and any(s <= addr < e for s, e in HI_TABLES) and (BLK_LO >> 8) <= b <= (BLK_HI >> 8):
                    return '$%02X-$%02X' % (b, (BLK_LO - BLK_NEW) >> 8)
                return '$%02X' % b
            f.write('%-8s %-28s ; %04X\n' % (pre, 'DB ' + ','.join(db(x) for x in range(a, a + n)), a))

    segs = [('seg_5b00.asm', LO, BLK_LO, LO), ('seg_6600.asm', BLK_LO, BLK_HI, BLK_NEW if reloc else BLK_LO),
            ('seg_7807.asm', BLK_HI, 0x10000, BLK_HI)]
    for fn, s, e, org in segs:
        with open(os.path.join(outdir, fn), 'w') as f:
            f.write('; The Sentinel - ZX Spectrum memory image %04X-%04X (generated)\n' % (s, e - 1))
            f.write(' ORG $%04X\n' % org)
            for (a, kind, n) in lines:
                if s <= a < e:
                    emit_line(f, a, kind, n)
    with open(os.path.join(outdir, 'sentinel.asm'), 'w') as f:
        f.write(' DEVICE NOSLOT64K\n')
        for fn, s, e, org in segs:
            f.write(' INCLUDE "%s"\n' % fn)
        f.write(' SAVEBIN "sentinel_5b00.bin",$5B00,$%04X\n' % (BLK_LO - 0x5B00))
        f.write(' SAVEBIN "sentinel_blk.bin",$%04X,$%04X\n' % (BLK_NEW if reloc else BLK_LO, BLK_HI-BLK_LO))
        f.write(' SAVEBIN "sentinel_7800.bin",$%04X,$%04X\n' % (BLK_HI, 0x10000-BLK_HI))
    print('lines', len(lines), 'labels', len(used_labels))


if __name__ == '__main__':
    main()
