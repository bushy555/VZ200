#!/usr/bin/env python3
"""Compact Z80 disassembler.

disasm(mem, addr) -> (length, text, info)
info: dict with keys
  'kind': 'jp','jr','call','ret','rst','djnz','jpind','halt',None
  'cond': True if conditional
  'target': branch target (int) or None
  'imm16': 16-bit immediate operand (int) or None (for LD rr,nn / LD (nn) etc)
  'imm16_off': offset of imm16 within instruction
  'mem16': True if imm16 is an address reference (LD A,(nn) etc)
  'imm8': 8-bit immediate or None, 'imm8_off'
"""

R = ['B', 'C', 'D', 'E', 'H', 'L', '(HL)', 'A']
RP = ['BC', 'DE', 'HL', 'SP']
RP2 = ['BC', 'DE', 'HL', 'AF']
CC = ['NZ', 'Z', 'NC', 'C', 'PO', 'PE', 'P', 'M']
ALU = ['ADD A,', 'ADC A,', 'SUB ', 'SBC A,', 'AND ', 'XOR ', 'OR ', 'CP ']
ROT = ['RLC', 'RRC', 'RL', 'RR', 'SLA', 'SRA', 'SLL', 'SRL']


def h8(v):
    return '$%02X' % (v & 0xFF)


def h16(v):
    return '$%04X' % (v & 0xFFFF)


def sd(v):
    return v - 256 if v >= 128 else v


def disasm(mem, a, lab=None):
    """lab: optional function(addr)->str for symbolic addresses."""
    L = lab or h16
    def rd(o):
        return mem[(a + o) & 0xFFFF]
    def rw(o):
        return rd(o) | (rd(o + 1) << 8)
    info = {'kind': None, 'cond': False, 'target': None, 'imm16': None, 'imm16_off': None,
            'mem16': False, 'imm8': None, 'imm8_off': None}
    op = rd(0)
    if op in (0xDD, 0xFD):
        xr = 'IX' if op == 0xDD else 'IY'
        op2 = rd(1)
        if op2 == 0xCB:
            d = sd(rd(2)); op3 = rd(3)
            x, y, z = op3 >> 6, (op3 >> 3) & 7, op3 & 7
            m = '(%s%+d)' % (xr, d)
            if x == 0:
                t = '%s %s' % (ROT[y], m)
            elif x == 1:
                t = 'BIT %d,%s' % (y, m)
            elif x == 2:
                t = 'RES %d,%s' % (y, m)
            else:
                t = 'SET %d,%s' % (y, m)
            if x != 1 and z != 6:
                t += ',' + R[z]
            return 4, t, info
        # Disassemble op2 as unprefixed with HL->xr substitution
        ln, t, inf = disasm_main(mem, (a + 1) & 0xFFFF, L, xr)
        if t is None:
            return 1, 'DEFB ' + h8(op), info
        for k in ('imm16_off', 'imm8_off'):
            if inf[k] is not None:
                inf[k] += 1
        return ln + 1, t, inf
    ln, t, inf = disasm_main(mem, a, L, None)
    return ln, t, inf


def disasm_main(mem, a, L, xr):
    def rd(o):
        return mem[(a + o) & 0xFFFF]
    def rw(o):
        return rd(o) | (rd(o + 1) << 8)
    info = {'kind': None, 'cond': False, 'target': None, 'imm16': None, 'imm16_off': None,
            'mem16': False, 'imm8': None, 'imm8_off': None}
    op = rd(0)
    x, y, z = op >> 6, (op >> 3) & 7, op & 7
    p, q = y >> 1, y & 1
    disp_len = 0
    def reg(i):
        nonlocal disp_len
        if xr is None:
            return R[i]
        if i == 6:
            disp_len = 1
            return '(%s%+d)' % (xr, sd(rd(1)))
        if i == 4:
            return xr + 'H'
        if i == 5:
            return xr + 'L'
        return R[i]
    def regp(i):
        if xr is not None and i == 2:
            return xr
        return RP[i]
    def regp2(i):
        if xr is not None and i == 2:
            return xr
        return RP2[i]
    hl = xr or 'HL'
    if op == 0xED:
        if xr is not None:
            return 1, None, info
        return disasm_ed(mem, a, L)
    if op == 0xCB:
        if xr is not None:
            return 1, None, info
        o = rd(1); x2, y2, z2 = o >> 6, (o >> 3) & 7, o & 7
        if x2 == 0:
            return 2, '%s %s' % (ROT[y2], R[z2]), info
        return 2, '%s %d,%s' % (['', 'BIT', 'RES', 'SET'][x2], y2, R[z2]), info
    if x == 0:
        if z == 0:
            if y == 0:
                return 1, 'NOP', info
            if y == 1:
                return 1, "EX AF,AF'", info
            tgt = (a + 2 + sd(rd(1))) & 0xFFFF
            info['target'] = tgt
            if y == 2:
                info['kind'] = 'djnz'; info['cond'] = True
                return 2, 'DJNZ ' + L(tgt), info
            info['kind'] = 'jr'
            if y == 3:
                return 2, 'JR ' + L(tgt), info
            info['cond'] = True
            return 2, 'JR %s,%s' % (CC[y - 4], L(tgt)), info
        if z == 1:
            if q == 0:
                v = rw(1); info['imm16'] = v; info['imm16_off'] = 1
                return 3, 'LD %s,%s' % (regp(p), L(v)), info
            return 1, 'ADD %s,%s' % (hl, regp(p)), info
        if z == 2:
            if p < 2:
                rr = ['(BC)', '(DE)'][p]
                return 1, ('LD %s,A' % rr) if q == 0 else ('LD A,%s' % rr), info
            v = rw(1); info['imm16'] = v; info['imm16_off'] = 1; info['mem16'] = True
            if p == 2:
                return 3, ('LD (%s),%s' % (L(v), hl)) if q == 0 else ('LD %s,(%s)' % (hl, L(v))), info
            return 3, ('LD (%s),A' % L(v)) if q == 0 else ('LD A,(%s)' % L(v)), info
        if z == 3:
            return 1, ('INC ' if q == 0 else 'DEC ') + regp(p), info
        if z == 4:
            r = reg(y); return 1 + disp_len, 'INC ' + r, info
        if z == 5:
            r = reg(y); return 1 + disp_len, 'DEC ' + r, info
        if z == 6:
            r = reg(y)
            n = rd(1 + disp_len); info['imm8'] = n; info['imm8_off'] = 1 + disp_len
            return 2 + disp_len, 'LD %s,%s' % (r, h8(n)), info
        return 1, ['RLCA', 'RRCA', 'RLA', 'RRA', 'DAA', 'CPL', 'SCF', 'CCF'][y], info
    if x == 1:
        if op == 0x76:
            info['kind'] = 'halt'
            return 1, 'HALT', info
        # with index: LD r,(IX+d) uses plain r for the other operand
        if xr is not None and (y == 6 or z == 6):
            if y == 6:
                d = '(%s%+d)' % (xr, sd(rd(1)))
                return 2, 'LD %s,%s' % (d, R[z]), info
            d = '(%s%+d)' % (xr, sd(rd(1)))
            return 2, 'LD %s,%s' % (R[y], d), info
        return 1, 'LD %s,%s' % (reg(y), reg(z)), info
    if x == 2:
        r = reg(z)
        return 1 + disp_len, ALU[y] + r, info
    # x == 3
    if z == 0:
        info['kind'] = 'ret'; info['cond'] = True
        return 1, 'RET ' + CC[y], info
    if z == 1:
        if q == 0:
            return 1, 'POP ' + regp2(p), info
        if p == 0:
            info['kind'] = 'ret'
            return 1, 'RET', info
        if p == 1:
            return 1, 'EXX', info
        if p == 2:
            info['kind'] = 'jpind'
            return 1, 'JP (%s)' % hl, info
        return 1, 'LD SP,' + hl, info
    if z == 2:
        v = rw(1); info['kind'] = 'jp'; info['cond'] = True; info['target'] = v
        info['imm16'] = v; info['imm16_off'] = 1
        return 3, 'JP %s,%s' % (CC[y], L(v)), info
    if z == 3:
        if y == 0:
            v = rw(1); info['kind'] = 'jp'; info['target'] = v; info['imm16'] = v; info['imm16_off'] = 1
            return 3, 'JP ' + L(v), info
        if y == 2:
            n = rd(1); info['imm8'] = n; info['imm8_off'] = 1
            return 2, 'OUT (%s),A' % h8(n), info
        if y == 3:
            n = rd(1); info['imm8'] = n; info['imm8_off'] = 1
            return 2, 'IN A,(%s)' % h8(n), info
        return 1, ['', '', '', '', 'EX (SP),' + hl, 'EX DE,HL', 'DI', 'EI'][y], info
    if z == 4:
        v = rw(1); info['kind'] = 'call'; info['cond'] = True; info['target'] = v
        info['imm16'] = v; info['imm16_off'] = 1
        return 3, 'CALL %s,%s' % (CC[y], L(v)), info
    if z == 5:
        if q == 0:
            return 1, 'PUSH ' + regp2(p), info
        if p == 0:
            v = rw(1); info['kind'] = 'call'; info['target'] = v; info['imm16'] = v; info['imm16_off'] = 1
            return 3, 'CALL ' + L(v), info
        return 1, None, info  # DD/ED/FD handled elsewhere
    if z == 6:
        n = rd(1); info['imm8'] = n; info['imm8_off'] = 1
        return 2, ALU[y] + h8(n), info
    info['kind'] = 'rst'; info['target'] = y * 8
    return 1, 'RST %s' % h8(y * 8), info


def disasm_ed(mem, a, L):
    def rd(o):
        return mem[(a + o) & 0xFFFF]
    def rw(o):
        return rd(o) | (rd(o + 1) << 8)
    info = {'kind': None, 'cond': False, 'target': None, 'imm16': None, 'imm16_off': None,
            'mem16': False, 'imm8': None, 'imm8_off': None}
    op = rd(1)
    x, y, z = op >> 6, (op >> 3) & 7, op & 7
    p, q = y >> 1, y & 1
    if x == 1:
        if z == 0:
            return 2, ('IN %s,(C)' % R[y]) if y != 6 else 'IN F,(C)', info
        if z == 1:
            return 2, ('OUT (C),%s' % R[y]) if y != 6 else 'OUT (C),0', info
        if z == 2:
            return 2, ('SBC HL,' if q == 0 else 'ADC HL,') + RP[p], info
        if z == 3:
            v = rw(2); info['imm16'] = v; info['imm16_off'] = 2; info['mem16'] = True
            return 4, ('LD (%s),%s' % (L(v), RP[p])) if q == 0 else ('LD %s,(%s)' % (RP[p], L(v))), info
        if z == 4:
            return 2, 'NEG', info
        if z == 5:
            info['kind'] = 'ret'
            return 2, 'RETI' if y == 1 else 'RETN', info
        if z == 6:
            return 2, 'IM %s' % ['0', '0', '1', '2', '0', '0', '1', '2'][y], info
        return 2, ['LD I,A', 'LD R,A', 'LD A,I', 'LD A,R', 'RRD', 'RLD', 'NOP', 'NOP'][y], info
    if x == 2 and z <= 3 and y >= 4:
        return 2, [['LDI', 'CPI', 'INI', 'OUTI'], ['LDD', 'CPD', 'IND', 'OUTD'],
                   ['LDIR', 'CPIR', 'INIR', 'OTIR'], ['LDDR', 'CPDR', 'INDR', 'OTDR']][y - 4][z], info
    return 2, 'DEFB $ED,%s' % h8(op), info


if __name__ == '__main__':
    import sys
    mem = open(sys.argv[1], 'rb').read()
    s = int(sys.argv[2], 16); e = int(sys.argv[3], 16)
    while s < e:
        n, t, inf = disasm(mem, s)
        print('%04X  %-12s %s' % (s, ' '.join('%02X' % mem[(s + i) & 0xFFFF] for i in range(n)), t))
        s += n
