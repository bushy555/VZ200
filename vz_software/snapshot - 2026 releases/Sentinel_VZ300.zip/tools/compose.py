#!/usr/bin/env python3
"""Compose the extra music for the VZ port of The Sentinel.

Writes the tune data for the music-bank player (src/music/player.asm):
  envelope rate, then (pitch, delay) pairs, pitch 0 = rest, $FF = end.
The player starts each note on the next of four voices in turn, so the last
four notes always ring on together as a decaying chord - arpeggios become
chords, as in the game's own tunes.

All music here is original, written for this port.

usage: compose.py out.asm [listing.txt]
"""
import sys, math

K = 44000.0          # voice period (loop passes) x frequency, measured
NOTES = {'C': 0, 'C#': 1, 'Db': 1, 'D': 2, 'D#': 3, 'Eb': 3, 'E': 4, 'F': 5, 'F#': 6,
         'Gb': 6, 'G': 7, 'G#': 8, 'Ab': 8, 'A': 9, 'A#': 10, 'Bb': 10, 'B': 11}


def freq(n):
    """'A4' -> Hz"""
    name, octave = n[:-1], int(n[-1])
    semis = NOTES[name] + 12 * (octave + 1) - 69
    return 440.0 * 2 ** (semis / 12)


def period(n):
    p = round(K / freq(n))
    assert 2 <= p <= 254, (n, p)
    return p


class Tune:
    """Events on a tick grid.  add(time, note) - notes at the same time are
    spread one tick apart (the player can only start one note per event)."""

    def __init__(self, name, env=4, step=8):
        self.name, self.env, self.step = name, env, step
        self.ev = []          # (tick, note or None for rest)
        self.t = 0            # cursor in steps

    def at(self, step, *notes):
        for n in notes:
            self.ev.append((step * self.step, n))

    def seq(self, text, start=None):
        """Space-separated tokens, one per step: a note, a chord a+b+c,
        '.' to hold (nothing new), 'r' to silence all four voices."""
        if start is not None:
            self.t = start
        for tok in text.split():
            if tok != '.':
                notes = [None] * 4 if tok == 'r' else tok.split('+')
                self.at(self.t, *notes)
            self.t += 1
        return self

    def compile(self, end_steps=0):
        ev = sorted(self.ev, key=lambda e: e[0])
        # spread simultaneous notes one tick apart
        out, last = [], -1
        for t, n in ev:
            t = max(t, last + 1)
            out.append([t, n])
            last = t
        end = max(self.t * self.step, out[-1][0] + 1) + end_steps * self.step
        data = [self.env]
        for i, (t, n) in enumerate(out):
            nxt = out[i + 1][0] if i + 1 < len(out) else end
            d = nxt - t
            while d > 255:              # split long gaps with a quiet filler
                data += [period(n) if n else 0, 255]
                d -= 255
            data += [period(n) if n else 0, d]
        data.append(0xFF)
        self.ticks = end
        return data


# --------------------------------------------------------------------------
# Title theme: "The Watcher".  D minor, slow arpeggios that build into a
# chord on every bar (each new note rings on until its voice is reused),
# a middle section with a melody over a slow bass, and the scanning
# "ping" of the Sentinel.  About 45 seconds, looped while the title shows.
# --------------------------------------------------------------------------
def title():
    t = Tune('title', env=5, step=9)
    arp = {  # one bar of 16ths per chord: root fifth octave third, ...
        'Dm': 'D4 A4 D5 F5 A4 D5 F4 A4  D4 A4 D5 F5 E5 D5 A4 F4',
        'Bb': 'Bb3 F4 Bb4 D5 F4 Bb4 D4 F4  Bb3 F4 Bb4 D5 C5 Bb4 F4 D4',
        'Gm': 'G3 D4 G4 Bb4 D4 G4 Bb3 D4  G3 D4 G4 Bb4 A4 G4 D4 Bb3',
        'A':  'A3 E4 A4 C#5 E4 A4 C#4 E4  A3 E4 A4 C#5 E5 C#5 A4 E4',
        'Asus': 'A3 E4 A4 D5 E4 A4 D4 E4  A3 E4 A4 C#5 E4 A4 C#4 E4',
        'F':  'F3 C4 F4 A4 C4 F4 A3 C4  F3 C4 F4 A4 G4 F4 C4 A3',
        'C':  'C4 G4 C5 E5 G4 C5 E4 G4  C4 G4 C5 E5 D5 C5 G4 E4',
    }
    # intro: the Sentinel's ping, alone
    t.seq('A5 . . . . . . . r . . . . . . .  A5 . . . . . . . r . . . . . . .')
    t.seq('D4 . . . A4 . . . D5 . . . A4 . . .  D4 . . . A4 . . . D5 . . . E5 . . .')
    # A: arpeggios
    for ch in ['Dm', 'Dm', 'Bb', 'Bb', 'Gm', 'Gm', 'Asus', 'A']:
        t.seq(arp[ch])
    # B: melody over a slow bass (bass on beats 1 and 3, melody between)
    mel = [
        ('A3+D4', 'A4 . . . . . F4 . E4 . D4 . E4 . F4 .'),
        ('D4+A3', 'E4 . . . . . . . D4 . . . . . . .'),
        ('Bb3+F4', 'D5 . . . . . C5 . Bb4 . A4 . G4 . A4 .'),
        ('Bb3+D4', 'F4 . . . . . . . . . . . . . . .'),
        ('G3+D4', 'G4 . . . Bb4 . . . A4 . G4 . F4 . E4 .'),
        ('G3+Bb3', 'D4 . . . . . . . E4 . . . F4 . . .'),
        ('A3+E4', 'E4 . . . C#5 . . . A4 . . . G4 . . .'),
        ('A3+C#4', 'A4 . . . . . . . . . . . . . . .'),
    ]
    for bass, line in mel:
        s = t.t
        b1, b2 = bass.split('+')
        t.at(s, b1)
        t.at(s + 8, b2)
        t.seq(line)
    # C: the arpeggios again, lifted to F and C, then home
    for ch in ['F', 'C', 'Dm', 'Bb', 'Gm', 'A', 'Dm', 'Dm']:
        t.seq(arp[ch])
    # coda: the ping fades out over a low D
    t.seq('D4+A4 . . . . . . . A5 . . . . . . .  r . . . . . . . A5 . . . . . . .')
    t.seq('r . . . . . . . . . . . . . . .')
    return t


# --------------------------------------------------------------------------
# Second title theme: "Ten Thousand Landscapes".  A minor, a driving
# ostinato under a long-breathed tune; played on alternate visits to the
# title screen.  About 25 seconds.
# --------------------------------------------------------------------------
def title2():
    t = Tune('title2', env=3, step=7)
    ost = {  # one bar of 8 steps: low pulse with the fifth and octave
        'Am': 'A3 A3 E4 A3 A4 A3 E4 G4',
        'F':  'F3 F3 C4 F3 F4 F3 C4 E4',
        'C':  'C4 C4 G4 C4 C5 C4 G4 B4',
        'G':  'G3 G3 D4 G3 G4 G3 D4 F#4',
        'E':  'E4 E4 B4 E4 E5 E4 B4 G#4',
        'Dm': 'D4 D4 A4 D4 D5 D4 A4 C5',
    }
    prog = ['Am', 'Am', 'F', 'F', 'C', 'C', 'G', 'E']
    for ch in prog:
        t.seq(ost[ch])
    # the tune enters: melody notes land on the beat, between the ostinato
    melody = [
        ('Am', 'E5 . . . . . D5 .'), ('Am', 'C5 . . . B4 . A4 .'),
        ('F', 'C5 . . . . . A4 .'), ('F', 'F4 . . . . . . .'),
        ('C', 'G4 . . . C5 . E5 .'), ('C', 'G5 . . . E5 . C5 .'),
        ('G', 'D5 . . . B4 . G4 .'), ('E', 'G#4 . . . B4 . E5 .'),
        ('Am', 'A5 . . . . . G5 .'), ('Am', 'E5 . . . . . C5 .'),
        ('Dm', 'D5 . . . F5 . A5 .'), ('Dm', 'F5 . . . . . D5 .'),
        ('F', 'C5 . . . A4 . F4 .'), ('G', 'B4 . . . D5 . G5 .'),
        ('E', 'G#5 . . . E5 . B4 .'), ('E', 'E5 . . . . . . .'),
    ]
    for ch, line in melody:
        s = t.t
        o = ost[ch].split()
        # thin the ostinato to its bass pulses so the tune can ring
        t.seq(' '.join(x if i in (0, 3, 5) else '.' for i, x in enumerate(o)), start=s)
        t.seq(line, start=s)
    for ch in ['Am', 'F', 'G', 'E', 'Am', 'Am']:
        t.seq(ost[ch])
    t.seq('A3+E4+A4 . . . . . . .  r . . . . . . .')
    return t


# --------------------------------------------------------------------------
# Landscape preview motifs: four short pieces, picked by the landscape's
# colour (so the same landscape always gets the same one).
# --------------------------------------------------------------------------
def preview(i):
    t = Tune('preview%d' % i, env=6, step=10)
    if i == 0:      # rising fourths, an open question
        t.seq('D4 . G4 . C5 . F5 . . . . . E5 . . . D5 . . . . . . .  A4+D5 . . . . . . . r . . .')
    elif i == 1:    # falling minor arpeggio
        t.seq('A5 . F5 . D5 . A4 . F4 . D4 . . . E4 . F4 . . . . .  D4+A4 . . . . . . . r . . .')
    elif i == 2:    # the heartbeat
        t.seq('D4 D4 . . . . D4 D4 . . . . D4 D4 . . A5 . . . . . . .  F5 . . . . . . . r . . .')
    else:           # chromatic creep
        t.seq('D4 . Eb4 . D4 . C#4 . D4 . . . A4 . Bb4 . A4 . G#4 . A4 . . .  D5+A4 . . . . . . . r . . .')
    return t


# --------------------------------------------------------------------------
# Game over: a slow fall to the low D, the Sentinel's ping fading above it.
# --------------------------------------------------------------------------
def gameover():
    t = Tune('gameover', env=7, step=12)
    t.seq('A4 . F4 . D4 . . . C#4 . . . D4+A3 . . . . . . .  A5 . . . . . . .  r . . .')
    return t


def main():
    tunes = [title()] + [preview(i) for i in range(4)] + [title2(), gameover()]
    lines = ['; generated by tools/compose.py - do not edit', '        DW ' + ', '.join(
        'tune_%s' % t.name for t in tunes)]
    report = []
    for t in tunes:
        data = t.compile()
        lines.append('tune_%s:' % t.name)
        for k in range(0, len(data), 16):
            lines.append('        DB ' + ','.join('$%02X' % b for b in data[k:k + 16]))
        report.append('%-10s %5d bytes  %5.1f s' % (t.name, len(data), t.ticks * 0.0144))
    open(sys.argv[1], 'w').write('\n'.join(lines) + '\n')
    print('\n'.join(report))


if __name__ == '__main__':
    main()
