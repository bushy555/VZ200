// Scripted VZ300 + BennVenn SD loader (128K) emulator for testing the Sentinel port.
// usage: vzemu file.vz script.txt
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../z80c/z80.h"

#define CPU_HZ 3546894
#define LINES 312
#define CYC_PER_FRAME 70938
#define CYC_PER_LINE (CYC_PER_FRAME / LINES)   // ~227
#define FS_LINE 241                             // FS falls (INT) at this physical line
#define ACTIVE_FIRST 50                         // first active display line

static uint8_t mem[65536];          // base map (ROM area + internal RAM)
static uint8_t dosram[2][0x2800];   // $4000-$67FF RAM banks
static uint8_t expram[2][0x8000];   // expansion banks (offset & $7FFF)
static uint8_t vram[0x800];
static uint8_t mapper;              // port $37
static uint8_t latch;               // $6800 latch
static uint8_t keys[8];             // VZ matrix rows, bit set = pressed
static uint8_t joy = 0xff, joy2 = 0xff;  // joystick bits active low (1: $2C/$2E, 2: $29/$2B)
static z80 cpu;
static unsigned long long frame, tframe; static long fcyc; // cycle within frame
static int trap_block = 0; static int trap_lo = -1, trap_hi = -1; // allowed PC range for I/O/VRAM access
static int allowed[32][2]; static int nallowed;
static long errors;
static int wtr[16][2]; static int nwtr; static int wtrap_on; static int wl_lo=-1, wl_hi=-1, wl_n=0;
static uint8_t cov[65536];
static FILE *sndf; static int lastspk = -1; static FILE *tapef; static int lasttape = -1;
// per-scanline mode record
static uint8_t line_latch[LINES];

static int pc_allowed(uint16_t pc) {
  for (int i = 0; i < nallowed; i++) if (pc >= allowed[i][0] && pc < allowed[i][1]) return 1;
  return 0;
}
static uint16_t curpc;
static void trap(const char *what, uint16_t a) {
  if (errors < 40) fprintf(stderr, "TRAP %s addr=%04X pc=%04X frame=%llu\n", what, a, curpc, frame);
  errors++;
}
static int cur_line(void) { return (int)((fcyc / CYC_PER_LINE) + FS_LINE) % LINES; }
static int fs_low(void) { int l = cur_line(); return l >= FS_LINE; }

static uint8_t rb(void *u, uint16_t a) {
  if (a < 0x4000) { if (!pc_allowed(curpc) && trap_block) trap("ROM read", a); return mem[a]; }
  if (a < 0x6800) { if (mapper & 1) return dosram[(mapper >> 1) & 1][a - 0x4000]; return 0xff; }
  if (a < 0x7000) {
    if (trap_block && !pc_allowed(curpc)) trap("IO read", a);
    uint8_t r = 0x3f;
    for (int i = 0; i < 8; i++) if (!(a & (1 << i))) r &= ~keys[i];
    r |= 0x40;           // cassette idle
    if (!fs_low()) r |= 0x80;
    return r;
  }
  if (a < 0x7800) { if (trap_block && !pc_allowed(curpc)) trap("VRAM read", a); return vram[a - 0x7000]; }
  if (a < 0xB800) return mem[a];
  return expram[(mapper >> 2) & 1][a & 0x7fff];
}
static uint8_t wmap[65536];
static void wb(void *u, uint16_t a, uint8_t v) {
  wmap[a] = 1;
  if (a < 0x4000) { return; }  // writes to ROM are harmless (the game does a few)
  if (a >= wl_lo && a < wl_hi && wl_n < 30) { wl_n++; fprintf(stderr, "WLOG %04X=%02X pc=%04X frame=%llu\n", a, v, curpc, frame); }
  if (a < 0x6800) {
    for (int i = 0; i < nwtr && wtrap_on; i++) if (a >= wtr[i][0] && a < wtr[i][1] && !pc_allowed(curpc)) trap("protected write", a);
    if (mapper & 1) dosram[(mapper >> 1) & 1][a - 0x4000] = v; else trap("DOSROM write", a); return; }
  if (a < 0x7000) {
    if (trap_block && !pc_allowed(curpc)) trap("IO write", a);
    latch = v;
    int l = cur_line(); for (int i = l; i < LINES; i++) line_latch[i] = v; // from this line on
    int spk = (v & 1) | ((v >> 4) & 2);
    if (sndf && spk != lastspk) fprintf(sndf, "%llu %d\n", tframe + fcyc, spk);
    lastspk = spk;
    { int t = (v >> 2) & 1; if (tapef && t != lasttape) fprintf(tapef, "%llu %d\n", tframe + fcyc, t); lasttape = t; }
    return;
  }
  if (a < 0x7800) { if (trap_block && !pc_allowed(curpc)) trap("VRAM write", a); vram[a - 0x7000] = v; return; }
  if (a < 0xB800) { mem[a] = v; return; }
  expram[(mapper >> 2) & 1][a & 0x7fff] = v;
}
static uint8_t pin(z80 *z, uint16_t port) {
  uint8_t p = port & 0xff;
  if (p == 0x2c || p == 0x2e) return joy;
  if (p == 0x29 || p == 0x2b) return joy2;
  if (p >= 0x20 && p <= 0x2f) return joy & joy2;
  return 0xff;
}
static void pout(z80 *z, uint16_t port, uint8_t v) {
  uint8_t p = port & 0xff;
  if (p == 0x37) mapper = v;
}

static const char *keynames[8][6] = {
  {"T", "W", "", "E", "Q", "R"}, {"G", "S", "CTRL", "D", "A", "F"}, {"B", "X", "SHIFT", "C", "Z", "V"},
  {"5", "2", "", "3", "1", "4"}, {"N", ".", "", ",", "SPACE", "M"}, {"6", "9", "-", "8", "0", "7"},
  {"Y", "O", "RETURN", "I", "P", "U"}, {"H", "L", "'", "K", ":", "J"}};
static int setkey(const char *n, int d) {
  for (int r = 0; r < 8; r++) for (int c = 0; c < 6; c++) if (keynames[r][c][0] && !strcmp(n, keynames[r][c])) {
    if (d) keys[r] |= 1 << c; else keys[r] &= ~(1 << c); return 1; }
  fprintf(stderr, "bad key %s\n", n); return 0;
}

// --- video
static const uint8_t pal_g[2][4][3] = {
  {{0x07, 0xff, 0x00}, {0xff, 0xff, 0x00}, {0x3b, 0x08, 0xff}, {0xcc, 0x00, 0x3b}},   // green yellow blue red
  {{0xff, 0xff, 0xff}, {0x07, 0xe3, 0x99}, {0xff, 0x1c, 0xff}, {0xff, 0x81, 0x00}}};  // buff cyan magenta orange
static const uint8_t sg_cols[8][3] = {{0x07,0xff,0x00},{0xff,0xff,0x00},{0x3b,0x08,0xff},{0xcc,0x00,0x3b},
  {0xff,0xff,0xff},{0x07,0xe3,0x99},{0xff,0x1c,0xff},{0xff,0x81,0x00}};
static uint8_t font[64][12];
static void shot(const char *fn) {
  // 256 x 192 output (each VZ graphics pixel = 2x3)
  FILE *f = fopen(fn, "wb"); fprintf(f, "P6 256 192 255\n");
  for (int y = 0; y < 192; y++) {
    uint8_t lt = line_latch[(ACTIVE_FIRST + y) % LINES];
    int gfx = (lt >> 3) & 1, css = (lt >> 4) & 1;
    for (int x = 0; x < 256; x++) {
      uint8_t c[3];
      if (gfx) {
        uint8_t b = vram[(y / 3) * 32 + (x >> 3)];
        int px = (b >> (6 - 2 * ((x >> 1) & 3))) & 3;
        memcpy(c, pal_g[css][px], 3);
      } else {
        uint8_t ch = vram[(y / 12) * 32 + (x >> 3)];
        int ry = y % 12;
        if (ch & 0x80) { // semigraphics 4 colours 8
          int col = (ch >> 4) & 7;
          int q = ((ry < 6) ? 2 : 0) + (((x & 7) < 4) ? 1 : 0);
          int bit = (ch >> q) & 1;
          if (bit) memcpy(c, sg_cols[col], 3); else { c[0] = c[1] = c[2] = 0; }
        } else {
          int code = ch & 0x3f, inv = (ch >> 6) & 1;
          int bit = (ry >= 3 && ry < 10) ? (font[code][ry - 3] >> (7 - (x & 7))) & 1 : 0;
          bit ^= inv;
          if (css) { if (bit) { c[0]=0xff;c[1]=0xc4;c[2]=0x18; } else { c[0]=0x40;c[1]=0x10;c[2]=0; } }
          else { if (bit) { c[0]=0x07;c[1]=0xff;c[2]=0; } else { c[0]=0;c[1]=0x40;c[2]=0; } }
        }
      }
      fwrite(c, 1, 3, f);
    }
  }
  fclose(f);
}

static FILE *tracef; static long tracen;
static int stop_at = -1; static int watch[16], nwatch, watchlimit = 50;
static uint8_t getf(void) { return cpu.sf<<7|cpu.zf<<6|cpu.yf<<5|cpu.hf<<4|cpu.xf<<3|cpu.pf<<2|cpu.nf<<1|cpu.cf; }
static unsigned long long prof[65536]; static int profiling;
static int int_taken_this_frame;

static void run_frames(int n) {
  for (int i = 0; i < n; i++) {
    int_taken_this_frame = 0;
    for (int l = 0; l < LINES; l++) line_latch[l] = latch;
    fcyc = 0;
    while (fcyc < CYC_PER_FRAME) {
      // level-triggered INT while FS low
      if (!int_taken_this_frame && fs_low() && cpu.iff1 && !cpu.iff_delay) { z80_gen_int(&cpu, 0xff); int_taken_this_frame = 1; }
      curpc = cpu.pc; cov[cpu.pc] = 1;
      if (tracef && tracen > 0) { tracen--; fprintf(tracef, "%04X A=%02X BC=%02X%02X DE=%02X%02X HL=%02X%02X SP=%04X\n", cpu.pc, cpu.a, cpu.b, cpu.c, cpu.d, cpu.e, cpu.h, cpu.l, cpu.sp); }
      if (cpu.pc == stop_at) { fprintf(stderr, "stop at %04X frame %llu\n", stop_at, frame); stop_at = -1; return; }
      for (int w = 0; w < nwatch; w++) if (cpu.pc == watch[w] && watchlimit > 0) { watchlimit--;
        printf("W %04X f%llu A=%02X F=%02X BC=%02X%02X DE=%02X%02X HL=%02X%02X IX=%04X IY=%04X SP=%04X\n", cpu.pc, frame, cpu.a, getf(), cpu.b, cpu.c, cpu.d, cpu.e, cpu.h, cpu.l, cpu.ix, cpu.iy, cpu.sp); }
      if (cpu.pc < 0x4000 && errors < 40) { fprintf(stderr, "EXEC in ROM pc=%04X frame %llu\n", cpu.pc, frame); errors++; }
      unsigned long c0 = cpu.cyc;
      z80_step(&cpu);
      long d = cpu.cyc - c0; fcyc += d; if (profiling) prof[curpc] += d;
    }
    tframe += CYC_PER_FRAME; frame++;
  }
}

static void loadfont(void) {
  // simple 5x7 font for A-Z, digits etc (6847 internal approximation) - only for screenshots
  static const char *glyphs = NULL; (void)glyphs;
  for (int i = 0; i < 64; i++) for (int r = 0; r < 7; r++) font[i][r] = 0;
  FILE *f = fopen("/home/claude/sentinel/tools/vzemu/font6847.bin", "rb");
  if (f) { for (int i = 0; i < 64; i++) fread(font[i], 1, 7, f); fclose(f); }
}

int main(int argc, char **argv) {
  z80_init(&cpu);
  cpu.read_byte = rb; cpu.write_byte = wb; cpu.port_in = pin; cpu.port_out = pout;
  memset(mem, 0xff, 0x4000); mem[0] = 0xf3;
  loadfont();
  FILE *f = fopen(argv[1], "rb"); uint8_t hdr[24]; fread(hdr, 1, 24, f);
  uint16_t start = hdr[22] | (hdr[23] << 8);
  static uint8_t buf[65536]; size_t n = fread(buf, 1, sizeof buf, f); fclose(f);
  for (size_t i = 0; i < n; i++) wb(0, start + i, buf[i]);
  fprintf(stderr, "loaded %zu bytes at %04X type %02X\n", n, start, hdr[21]);
  cpu.pc = start; cpu.sp = 0x7a00; cpu.iff1 = cpu.iff2 = 1; cpu.interrupt_mode = 1;
  latch = 0; nallowed = 0;
  FILE *s = fopen(argv[2], "r"); char line[512];
  while (fgets(line, sizeof line, s)) {
    char cmd[64], a1[256] = "", a2[256] = ""; int k = sscanf(line, "%63s %255s %255s", cmd, a1, a2);
    if (k < 1 || cmd[0] == '#') continue;
    if (!strcmp(cmd, "run")) run_frames(atoi(a1));
    else if (!strcmp(cmd, "press")) setkey(a1, 1);
    else if (!strcmp(cmd, "release")) setkey(a1, 0);
    else if (!strcmp(cmd, "tap")) { setkey(a1, 1); run_frames(a2[0] ? atoi(a2) : 3); setkey(a1, 0); run_frames(3); }
    else if (!strcmp(cmd, "joy")) joy = strtol(a1, 0, 0);
    else if (!strcmp(cmd, "joy2")) joy2 = strtol(a1, 0, 0);
    else if (!strcmp(cmd, "shot")) shot(a1);
    else if (!strcmp(cmd, "allow")) { allowed[nallowed][0] = strtol(a1, 0, 16); allowed[nallowed][1] = strtol(a2, 0, 16); nallowed++; }
    else if (!strcmp(cmd, "notrap")) trap_block = 0;
    else if (!strcmp(cmd, "wlog")) { wl_lo = strtol(a1, 0, 16); wl_hi = strtol(a2, 0, 16); wl_n = 0; }
    else if (!strcmp(cmd, "trace")) { tracef = fopen(a1, "w"); tracen = atol(a2); }
    else if (!strcmp(cmd, "trapon")) { trap_block = 1; wtrap_on = 1; }
    else if (!strcmp(cmd, "wtrap")) { wtr[nwtr][0] = strtol(a1, 0, 16); wtr[nwtr][1] = strtol(a2, 0, 16); nwtr++; }
    else if (!strcmp(cmd, "sound")) sndf = fopen(a1, "w");
    else if (!strcmp(cmd, "tape")) tapef = fopen(a1, "w");
    else if (!strcmp(cmd, "wmap")) { FILE *o = fopen(a1, "wb"); fwrite(wmap, 1, 65536, o); fclose(o); }
    else if (!strcmp(cmd, "wmapclear")) memset(wmap, 0, sizeof wmap);
    else if (!strcmp(cmd, "stopat")) stop_at = strtol(a1, 0, 16);
    else if (!strcmp(cmd, "watch")) { watch[nwatch++] = strtol(a1, 0, 16); if (a2[0]) watchlimit = atoi(a2); }
    else if (!strcmp(cmd, "prof")) { if (!strcmp(a1, "on")) { profiling = 1; memset(prof, 0, sizeof prof); } else { profiling = 0; FILE *o = fopen(a1, "wb"); fwrite(prof, 8, 65536, o); fclose(o); } }
    else if (!strcmp(cmd, "regs")) printf("frame %llu PC=%04X SP=%04X AF=%02X%02X BC=%02X%02X DE=%02X%02X HL=%02X%02X IX=%04X IY=%04X IM=%d IFF=%d map=%02X latch=%02X\n",
        frame, cpu.pc, cpu.sp, cpu.a, getf(), cpu.b, cpu.c, cpu.d, cpu.e, cpu.h, cpu.l, cpu.ix, cpu.iy, cpu.interrupt_mode, cpu.iff1, mapper, latch);
    else if (!strcmp(cmd, "dump")) { // dump flat 64K view of current mapping
      FILE *o = fopen(a1, "wb"); for (int a = 0; a < 65536; a++) { uint16_t sp = curpc; curpc = 0; int tb = trap_block; trap_block = 0; fputc(rb(0, a), o); trap_block = tb; curpc = sp; } fclose(o); }
    else if (!strcmp(cmd, "cov")) { FILE *o = fopen(a1, "wb"); fwrite(cov, 1, 65536, o); fclose(o); }
    else if (!strcmp(cmd, "poke")) wb(0, strtol(a1, 0, 16), strtol(a2, 0, 16));
    else if (!strcmp(cmd, "print")) printf("%s", line + 6);
    else fprintf(stderr, "?? %s\n", cmd);
  }
  if (sndf) fclose(sndf);
  if (tapef) fclose(tapef);
  printf("frames=%llu errors=%ld\n", frame, errors);
  return errors ? 1 : 0;
}
