#!/usr/bin/env python3
"""Build SENTINEL.VZ for a VZ300 with BennVenn SD loader + 128K RAM.

Steps:
 1. generate reassemblable source of the Spectrum image (block $6800-$7806 relocated to $4800)
 2. assemble with the VZ port layer (src/*.asm) -> 64K image
 3. compress regions with ZX0 and wrap with a boot stub into a .VZ file
"""
import os, sys, subprocess, struct, re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
T = ROOT + '/tools'
B = ROOT + '/build'
SJ = T + '/sjasmplus/sjasmplus'
ZX0 = T + '/zx0/zx0'


def run(cmd, **kw):
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True, **kw)
    if r.returncode != 0:
        print(r.stdout[-3000:], r.stderr[-3000:])
        sys.exit('FAILED: ' + cmd)
    return r.stdout


def zx0(data, name, back=False):
    p = B + '/' + name
    open(p, 'wb').write(data)
    if os.path.exists(p + '.zx0'):
        os.remove(p + '.zx0')
    out = run('%s %s -f %s' % (ZX0, '-b' if back else '', p))
    m = re.search(r'delta (\d+)', out)
    return open(p + '.zx0', 'rb').read(), int(m.group(1)) if m else 0


def main():
    os.makedirs(B + '/gen', exist_ok=True)
    run('python3 %s/gen_src.py %s/orig/base.mem %s/dis/analysis.json %s/gen reloc' % (T, ROOT, ROOT, B))
    main_asm = '''
 DEVICE NOSLOT64K
 INCLUDE "gen/seg_5b00.asm"
 INCLUDE "gen/seg_6600.asm"
 INCLUDE "gen/seg_7807.asm"
 INCLUDE "../src/vz_port.asm"
 SAVEBIN "image.bin",$4000,$C000
'''
    open(B + '/main.asm', 'w').write(main_asm)
    # music bank (BennVenn DOS-area RAM bank 1): player + generated tunes
    os.makedirs(B + '/music', exist_ok=True)
    run('python3 %s/compose.py %s/music/tunes.asm' % (T, B))
    open(B + '/music/m.asm', 'w').write(' DEVICE NOSLOT64K\n INCLUDE "%s/src/music/player.asm"\n'
                                       ' SAVEBIN "music.bin",$4000,$-$4000\n' % ROOT)
    run('cd %s/music && %s --nologo --inc=. m.asm' % (B, SJ))
    music = open(B + '/music/music.bin', 'rb').read()
    assert len(music) <= 0x2800, 'music bank overflow'

    out = run('cd %s && %s --nologo --sym=main.sym --lst=main.lst main.asm' % (B, SJ))
    ov = run('python3 %s/overlap.py %s/main.lst' % (T, B))
    if not ov.strip().endswith('overlapping bytes: 0'):
        sys.exit('FAILED: port code overlaps itself:\n' + ov)
    sym = {}
    for l in open(B + '/main.sym'):
        m = re.match(r'(\S+): EQU 0x([0-9A-F]+)', l)
        if m:
            sym[m.group(1)] = int(m.group(2), 16)
    img = bytearray(0x4000) + bytearray(open(B + '/image.bin', 'rb').read())
    open(B + '/image64.bin', 'wb').write(img)
    entry = sym['VZ_Init']
    # ---- regions
    dos, _ = zx0(bytes(img[0x4000:0x6800]), 'r_dos.bin')
    mus, _ = zx0(music, 'r_mus.bin')
    fd, _ = zx0(bytes(img[0xFD00:0xFE00]), 'r_fd.bin')
    MAIN_LO, MAIN_HI = 0x7807, 0xE800
    mainc, delta = zx0(bytes(img[MAIN_LO:MAIN_HI]), 'r_main.bin')
    # boot stub source, assembled twice (first to know its size)
    def boot(load, a_dos, a_fd, a_main, a_mus=0):
        return '''
 DEVICE NOSLOT64K
 ORG $%04X
start:
 DI
 LD SP,$7800
 LD HL,reloc
 LD DE,$7000
 LD BC,reloc_end-reloc
 LDIR
 JP $7000
reloc:
 DISP $7000
 LD A,3
 OUT ($37),A          ; BennVenn: DOS area -> RAM bank 1: the music bank
 LD HL,$%04X
 LD DE,$4000
 CALL dzx0_standard
 LD A,1
 OUT ($37),A          ; BennVenn: DOS area -> RAM bank 0, expansion bank 0
 LD HL,$%04X
 LD DE,$4000
 CALL dzx0_standard
 LD HL,$%04X
 LD DE,$FD00
 CALL dzx0_standard
 LD HL,$%04X
 LD DE,$%04X
 CALL dzx0_standard
 LD HL,$E800          ; clear runtime buffers $E800-$FCFF
 LD DE,$E801
 LD BC,$14FF
 LD (HL),0
 LDIR
 JP $%04X
 INCLUDE "%s/zx0/z80/dzx0_standard.asm"
 ENT
reloc_end:
 SAVEBIN "boot.bin",start,reloc_end-start
''' % (load, a_mus, a_dos, a_fd, a_main, MAIN_LO, entry, T)
    open(B + '/boot.asm', 'w').write(boot(0x8000, 0, 0, 0))
    run('cd %s && %s --nologo boot.asm' % (B, SJ))
    bsize = len(open(B + '/boot.bin', 'rb').read())
    total = bsize + len(mus) + len(dos) + len(fd) + len(mainc)
    end = MAIN_HI + delta + 2           # file must end at least delta bytes past the main region
    load = end - total
    a_mus = load + bsize
    a_dos = a_mus + len(mus)
    a_fd = a_dos + len(dos)
    a_main = a_fd + len(fd)
    assert load >= 0x7AE9, 'file too big: load at %04X' % load
    assert a_main + len(mainc) == end
    open(B + '/boot.asm', 'w').write(boot(load, a_dos, a_fd, a_main, a_mus))
    run('cd %s && %s --nologo boot.asm' % (B, SJ))
    stub = open(B + '/boot.bin', 'rb').read()
    assert len(stub) == bsize
    body = stub + mus + dos + fd + mainc
    hdr = b'VZF0' + b'SENTINEL'.ljust(16, b'\0') + b'\0' + bytes([0xF1]) + struct.pack('<H', load)
    name = sys.argv[1] if len(sys.argv) > 1 else 'SENTINEL.VZ'
    open(B + '/' + name, 'wb').write(hdr + body)
    print('VZ file %s: load $%04X-$%04X (%d bytes), entry %04X, main delta %d' % (name, load, end - 1, len(body), entry, delta))
    print('compressed: music %d (raw %d) dos %d fd %d main %d (raw %d)' % (len(mus), len(music), len(dos), len(fd), len(mainc), MAIN_HI - MAIN_LO))


if __name__ == '__main__':
    main()
