import re,collections,sys
L=open(sys.argv[1]).read().split('\n')
fr=[int(re.search(r' f(\d+)',l).group(1)) for l in L if l.startswith('W BD98')]
c=collections.Counter(fr)
st=[int(re.search(r' f(\d+)',l).group(1)) for l in L if re.match(r'W [0-9A-F]{4} ',l) and not l.startswith('W BD98')]
print('mode2..reveal',st, 'frames',st[1]-st[0])
missing=[f for f in range(st[0],st[1]) if c[f]==0]
print('frames without IRQ:',len(missing),missing, ' doubles:',[f for f in c if c[f]>1])
