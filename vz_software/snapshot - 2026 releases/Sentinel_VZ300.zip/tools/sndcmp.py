import subprocess, sys
T='../tools/sndtest/sndtest'
def run(m, mem, addr, regs, pokes=[]):
    out=subprocess.run([T,m,mem,addr]+regs+['80000000']+pokes,capture_output=True,text=True)
    ev=[(float(a),int(b)) for a,b in (l.split() for l in out.stdout.split('\n') if l)]
    return ev, out.stderr.strip()
def summ(ev):
    if len(ev)<2: return 'edges=%d'%len(ev)
    d=[b[0]-a[0] for a,b in zip(ev,ev[1:])]
    return 'edges=%d span=%.1fms mean half=%.1fus'%(len(ev),(ev[-1][0]-ev[0][0])/1000,sum(d)/len(d))
def cmp(name, addr, regs, pokes=[]):
    z,ze=run('zx','init0.mem',addr,regs,pokes); v,ve=run('vz','vzmem.bin',addr,regs,pokes)
    print('%-10s ZX %s | %s'%(name,summ(z),ze)); print('%-10s VZ %s | %s'%('',summ(v),ve))
    # compare the edge time sequences (normalised)
    n=min(len(z),len(v))
    if n>2:
        err=max(abs((z[i][0]-z[0][0])-(v[i][0]-v[0][0])) for i in range(n))
        print('           max timing drift over %d edges: %.1fus (%.2f%% of span)'%(n,err,100*err/max(1,z[n-1][0]-z[0][0])))
cmp('FD00','FD00',['00','0000','0000','0000'])
cmp('FD21','FD21',['00','0000','0000','0000'])
cmp('FD41','FD41',['00','0000','0000','0000'])
cmp('FD42','FD42',['00','0000','0000','0000'])
for i,p in enumerate([(0x66,0xE7),(0x7E,0xE7),(0x93,0xE7),(0xA8,0xE7),(0xB1,0xE7)]):
    cmp('tune%d'%i,'E600',['00','0000','0000','0000'],['E602:%02X'%p[0],'E603:%02X'%p[1]])
