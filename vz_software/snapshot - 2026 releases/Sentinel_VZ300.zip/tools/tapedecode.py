"""Decode a VZ cassette output log (T-state, level) into the VZ tape byte stream."""
import sys
CLK=3546900
ev=[tuple(map(int,l.split())) for l in open(sys.argv[1])]
halves=[((b[0]-a[0])/CLK*1e6,a[1]) for a,b in zip(ev,ev[1:])]
print('halves',len(halves),'min %.0f max %.0f us'%(min(h for h,_ in halves),max(h for h,_ in halves)))
S=lambda h:h<435
bits=[];i=0
while i+3<len(halves):
    h=halves
    if h[i][1]==1 and S(h[i][0]) and S(h[i+1][0]):
        if not S(h[i+2][0]) and h[i+2][1]==1: bits.append(0); i+=4; continue
        if i+5<len(h) and all(S(h[i+k][0]) for k in range(2,6)): bits.append(1); i+=6; continue
    i+=1
def bytes_at(off): 
    return [int(''.join(map(str,bits[k:k+8])),2) for k in range(off,len(bits)-7,8)]
# find leader alignment: $80 bytes followed by $FE
for off in range(8):
    bs=bytes_at(off)
    if bs.count(0x80)>200: break
print('bits',len(bits),'align',off)
k=0
while bs[k]==0x80: k+=1
print('leader',k,'sync',bs[k:k+5])
k+=5
print('type %02X'%bs[k]); k+=1
name=[]
while bs[k]: name.append(chr(bs[k])); k+=1
k+=1
print('name',''.join(name))
st=bs[k]|bs[k+1]<<8; en=bs[k+2]|bs[k+3]<<8
print('start %04X end %04X'%(st,en))
data=bs[k+4:k+4+en-st]
ck=bs[k+4+en-st]|bs[k+5+en-st]<<8
calc=(sum(bs[k:k+4])+sum(data))&0xFFFF
print('len',len(data),'cksum %04X calc %04X'%(ck,calc), 'OK' if ck==calc else 'BAD')
if len(sys.argv)>2: open(sys.argv[2],'wb').write(bytes(data))
