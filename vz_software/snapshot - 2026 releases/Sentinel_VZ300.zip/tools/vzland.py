"""Write a vzemu script that starts landscape N with its code; extra lines appended."""
import sys, subprocess, os
D=os.path.dirname(os.path.abspath(__file__))
n=sys.argv[1]; out=sys.argv[2]; extra=sys.argv[3:]
code=subprocess.check_output([D+'/getcode.sh',n]).decode().strip() if n!='0000' else ''
L=open(D+'/../run/vbase.txt').read().splitlines()
L+=['run 800','tap SPACE 5','run 100']+['tap %s 4'%c for c in n]+['tap RETURN 4','run 100']
if code: L+=['tap %s 4'%c for c in code]+['tap RETURN 4']
L+=['run 800','shot %s_prev.ppm'%out,'tap SPACE 10','run 900','shot %s_game.ppm'%out]+extra
open(out+'.txt','w').write('\n'.join(L)+'\n')
