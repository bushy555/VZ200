#!/usr/bin/env python3
"""Recursive-descent analysis of the Sentinel memory image.

Produces:
  analysis.json : code map, labels, routine starts, xrefs
  listing.txt   : human-readable listing
"""
import sys, json
sys.path.insert(0, '/home/claude/sentinel/tools')
from z80dis import disasm

LO, HI = 0x5B00, 0x10000


def analyse(mem, seeds, extra_data=()):
    code = bytearray(65536)      # 1 = first byte of instruction, 2 = continuation
    insn = {}                    # addr -> (len, text, info)
    labels = {}                  # addr -> kind
    calls = set()
    xrefs = {}                   # target -> set(src)
    todo = list(seeds)
    dataset = set()
    for a, b in extra_data:
        dataset.update(range(a, b))
    while todo:
        a = todo.pop()
        while LO <= a < HI and not code[a] and a not in dataset:
            n, t, info = disasm(mem, a)
            if t is None:
                break
            # stop if overlapping existing code
            if any(code[(a + i) & 0xFFFF] for i in range(1, n)):
                break
            code[a] = 1
            for i in range(1, n):
                code[(a + i) & 0xFFFF] = 2
            insn[a] = (n, t, info)
            k = info['kind']
            tg = info['target']
            if tg is not None:
                xrefs.setdefault(tg, set()).add(a)
                if k == 'call' or k == 'rst':
                    calls.add(tg)
                labels.setdefault(tg, k)
                if LO <= tg < HI:
                    todo.append(tg)
            if k in ('jp', 'jr', 'ret') and not info['cond']:
                break
            if k == 'jpind':
                break
            a = (a + n) & 0xFFFF
    return code, insn, labels, calls, xrefs


def main():
    mem = open(sys.argv[1], 'rb').read()
    seeds = []
    for f in sys.argv[2].split(','):
        d = open(f, 'rb').read()
        seeds += [a for a in range(LO, HI) if d[a] & 1]
    code, insn, labels, calls, xrefs = analyse(mem, seeds)
    out = {'code': [a for a in range(65536) if code[a] == 1],
           'calls': sorted(calls), 'labels': {str(k): v for k, v in labels.items()}}
    json.dump(out, open('analysis.json', 'w'))
    with open('listing.txt', 'w') as f:
        a = LO
        while a < HI:
            if code[a] == 1:
                n, t, info = insn[a]
                if a in calls:
                    f.write('\n; ---- routine %04X ----\n' % a)
                lab = 'L%04X:' % a if a in labels else ''
                f.write('%-7s %04X  %-12s %s\n' % (lab, a, ' '.join('%02X' % mem[a + i] for i in range(n)), t))
                a += n
            else:
                st = a
                while a < HI and code[a] == 0 and a - st < 8:
                    a += 1
                    if a in labels:
                        break
                lab = 'L%04X:' % st if st in labels else ''
                f.write('%-7s %04X  %-24s DEFB %s\n' % (lab, st, '', ','.join('$%02X' % b for b in mem[st:a])))
    print('code bytes', sum(1 for a in range(LO, HI) if code[a]), 'routines', len(calls))


if __name__ == '__main__':
    main()
