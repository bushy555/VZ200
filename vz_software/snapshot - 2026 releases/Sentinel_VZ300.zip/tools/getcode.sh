#!/bin/sh
# usage: getcode.sh NNNN  -> prints the 8-digit entry code (Spectrum original)
N=$1; D=$(dirname $0)
S=$(mktemp)
{ echo "run 10"; echo "tap 1 5"; echo "run 1000"; echo "tap SPACE 5"; echo "run 100"
  for c in $(echo $N | sed 's/./& /g'); do echo "tap $c 4"; done; echo "tap ENTER 4"; echo "run 100"
  for c in 1 1 1 1 1 1 1 1; do echo "tap $c 4"; done; echo "tap ENTER 4"; echo "watch 85A5 200"; echo "run 900"; } > $S
$D/zxemu/zxemu $D/../orig/title $S 2>&1 | grep "^W 85A5" | tail -5 | head -4 | awk '{print $4}' | sed 's/A=//' | tr -d '\n'; echo
rm $S
