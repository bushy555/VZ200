# The Sentinel for the Dick Smith VZ300

This is a conversion of Geoff Crammond's *The Sentinel* (Firebird, 1987) from the ZX Spectrum version to the VZ300 with the BennVenn SD loader and 128K RAM. The original Z80 game engine runs unchanged: the landscape generator, all 10,000 landscapes and their entry codes, energy, enemy AI, and the visibility and targeting maths. (Two of its hottest loops have been rewritten for speed; they give exactly the same results.) Everything that touches hardware has been replaced with VZ-native code: screen, keyboard, joystick, speaker, interrupts and cassette. The port also adds new music, kept in the BennVenn's spare RAM bank.

Load **`SENTINEL.VZ`** from the SD card. It is a type `$F1` machine-code file and starts by itself.

## Controls

| Key | Action |
|---|---|
| S / D | look left / right (moves the sights when they are on) |
| L or K / M or , | look up / down |
| SPACE | sights on / off |
| A | absorb |
| Q | transfer into robot |
| R / T / B | create robot / tree / boulder |
| H | hyperspace |
| U | U-turn |
| P / RETURN | pause / unpause |
| Z | sound on / off |
| C / V / X | previous / next view colour scheme / restore the landscape's own |
| E + V together | save the screen to cassette |
| any key / fire | stops the title or preview music (and continues as usual) |
| CTRL + SPACE | quit to the title screen (Spectrum BREAK) |
| 0-9, RETURN, CTRL or SHIFT (delete) | landscape number and entry code |

**Joysticks** (your interface): either joystick works, or both, or none. Directions look or move the sights, and fire toggles the sights. Joystick 1 directions are read on port `$2C` and fire on `$2E`; joystick 2 directions on `$29` and fire on `$2B`. These are the ports that work on your interface. An empty port can read as all directions pressed at once, which a real stick can't do, so that reading is taken to mean "no joystick".

**Entry codes.** The Spectrum codes differ from the BBC ones, so codes from BBC code lists are rejected (the Spectrum original rejects them too). Landscape 0000 needs no code. `tools/getcode.sh NNNN` prints the code for any landscape by running the original game in the test emulator. For example, 0007 is 57977812 and 0042 is 00544319.

## Graphics

- **Mode.** The game uses VZ mode(1) at 128×64 in 4 colours. One Spectrum byte column becomes one VZ byte (4 pixels), so the original column-based panning maps exactly onto the VZ. Of each 8-line Spectrum character row, three lines are sampled: 1, 4 and 6.
- **Layout.** VZ rows 0-3 are the status bar (icons, scanner, energy). Rows 4-63 are the view, which shows Spectrum character rows 1-20.
- **The three hidden rows.** Spectrum rows 21-23 are still drawn off-screen, because panning down scrolls them into view. The sights, however, now never enter them: the Spectrum pans the view down when the sights pass its bottom edge (row 21-22), and the VZ version pans once they pass the bottom of the VZ screen instead.
- **Status bar.** Icons and the scanner frame start one column in, as on the Spectrum, so the scanner's static sits inside its frame. Energy is shown by the icons on the left. The framed box on the right is the **scanner**, not an energy bar. It is empty (background colour) unless something is looking at you. When a sentry or the Sentinel scans you it fills with flickering static, half or fully filled depending on how much of you it can see. The Spectrum makes its static by reading bytes of its ROM. On the VZ that would have shown whatever the VZ ROM happens to hold, so the port generates its own four-colour noise there.
- **Renderer.** A new VZ polygon-span filler replaces the Spectrum `DrawPolygonLines` and `FillScreen`. The four logical BBC colours become solid colours or two-colour checkerboard dithers:
  - edges / odd flat tiles: solid
  - shaded slopes: dark dither
  - lit slopes: light dither
  - even flat tiles: the landscape colour
- **Colour schemes.** Like the original, each landscape picks a colour from a table. On the VZ each colour selects one of 8 schemes, and 4 of them use the second colour set (buff / cyan / magenta / orange). The C, V and X keys step through the schemes the same way the Spectrum colour keys do. A scheme change re-colours the screen instantly by permuting pixel values in place, so nothing is redrawn.
- **Title, preview and other screens.** The Spectrum selects one of three sets of fill patterns: one for the game view, one for the landscape preview, and one for the title, the entry-code display and the game-over view. The VZ renderer follows the same switch:
  - **Game view:** the four-colour schemes.
  - **Title:** the statue keeps the full scheme. "THE SENTINEL" leaves out red (yellow faces, green shading, blue background) so the letters read clearly.
  - **Landscape preview:** the tiles are a chequerboard of yellow and green, the polygon edges are thin red lines, and the background is blue.
  - **Game-over view:** two colours.
- **Hidden drawing.** The Spectrum hides the view while it is drawn by setting ink equal to paper. The VZ draws into an off-screen shadow copy instead and shows the whole view at once. During play the old view stays up until the new one is ready. When you leave the title screen after entering a landscape number, the screen goes blank straight away, just as the Spectrum's does. It stays blank while the landscape is generated (about 8 seconds, the same as the original), and then the preview appears.
- **Text.** Text uses a 3×5 font. The entry code shown at the end of a landscape is also printed as plain digits, because the large 3D digits are hard to read at this resolution.

## Speed

A new view is drawn about 1.55 times as fast as in the first VZ build, and about 20% faster than the Spectrum original: 233 frames from the start of drawing to the finished view for the first view of landscape 0000, against about 362 before and 289 on the Spectrum. Four changes made the difference:

| Change | What it does | Share of drawing time saved |
|---|---|---|
| Ray-march loop of GetRowVisibility (`$9CD1`) | The three ray accumulators live in IX, IY and C:HL and the ray's deltas are patched into the loop, so a step costs ~145 instead of ~310 T-states | ~13% |
| Division in GetAngleFromCoords (`$93BC`) | Unrolled, and only the 10 quotient bits the routine uses are computed | ~6% |
| No field-sync wait while drawing | While a view is drawn off-screen, the interrupt routine returns with interrupts still off instead of busy-waiting for the field sync to end; checkpoints in the hot code switch them back on once it has. Game timing is kept: the interrupt still runs once per frame | ~16% |
| Faster recolouring | Switching colour scheme at the reveal now goes through a lookup table in the BennVenn spare bank | 10 → 4 frames when the scheme changes |

Smaller savings come from faster keyboard reads in the interrupt routine.

The two engine rewrites were checked by drawing the same view with and without them: the game's variables, the screen and the off-screen buffers came out byte-identical. In a 230-frame draw, the interrupt routine still ran on all but one or two frames.

### Status line: why it is graphics, not a text-mode split

I looked into an interrupt-driven mode switch to get a 9-colour text/semigraphics status line. The VZ only exposes the frame-sync signal, with no line counter, so the CPU would have to busy-wait from frame sync to the end of the status line on every frame. That is about 30,000 T-states per frame, roughly 42% of the CPU, in a game that is already render-bound. The status line is therefore drawn in mode(1) graphics.

## Sound

The Spectrum beeper routines were transplanted with their delay loops unchanged. Port `$FE` writes became speaker writes to the VZ latch: bits 0 and 5, driven push-pull, merged with the current mode and colour-set bits. Each routine was checked edge by edge against the original (`tools/sndcmp.py`):

| Routines | Edges | Timing |
|---|---|---|
| All 5 tunes | identical edge count | pitch within 0.8% (VZ is slightly slower) |
| Effects `$FD00`, `$FD21`, `$FD41`, `$FD42` | identical | within 1.3% |
| Scanner static | identical | within 3.6% |

## Music

The port adds new music, all original and written for this conversion in the style of the game's own tunes:

| Tune | When | Length |
|---|---|---|
| Title theme 1, "The Watcher" (D minor) | title screen, odd visits | ~64 s, looped |
| Title theme 2, "Ten Thousand Landscapes" (A minor) | title screen, even visits | ~26 s, looped |
| Game over | game-over screen | ~5 s |
| Four preview motifs | landscape preview; the landscape's colour picks one, so a landscape always gets the same motif | ~5 s each |

Any key (or joystick fire) stops the music at once and does its usual job. The music respects the game's sound switch (Z). `docs/music/` has WAV renderings of each piece, made by running the player in the test harness.

The music uses the same four-voice engine as the game's own tunes, so it sounds the same. Each new note starts on the next voice in turn, as a pulse train whose width decays every few ticks, so the last four notes ring on as a fading chord. One change: a resting voice keeps running silently, so the tuning doesn't drift with the number of voices sounding. The tunes are written in `tools/compose.py`, which compiles them to the player's (pitch, delay) format.

**Where it lives.** The player and the tunes sit in the BennVenn's DOS-area RAM **bank 1** (`$4000-$67FF` with port `$37` bit 1 set). The game never maps that bank, so the music takes no game memory. The boot loader unpacks the music there. To play a tune, `vz_music` switches bank 1 in with interrupts off, calls the player, and switches back. Interrupts must be off because the IRQ handler lives in bank 0.

## Game over

When you are absorbed, or hyperspace without enough energy, the original plays a sequence:

1. The screen decays.
2. The enemy appears close up, materialising out of random dots.
3. It decays away again.

On the VZ, the random dots and the decays used to leave stray pixels behind, which is what you saw. The materialise now finishes the object off cleanly, and each decay ends on a clear screen.

The sequence then ends on a new **game-over screen**: "GAME OVER" in large letters, with "YOU HAVE BEEN ABSORBED / THE SENTINEL WINS" or "NOT ENOUGH ENERGY / TO HYPERSPACE" below it, and a short game-over tune. A key skips it. The screen is drawn by the spare-bank module, as is the tune.

## Save screen → cassette

The only save feature in the original is SAVE SCREEN$ (E+V together). On the VZ it writes the 2K video RAM to the cassette port as a standard VZ machine-code file. The name is `SENTSCR0`, and the digit counts up with each save. The file is in the ROM's CLOAD format:

- leader: 255 × `$80`
- sync: 5 × `$FE`
- type `$F1`
- name, then a short gap
- start, end, data
- 16-bit checksum
- guard byte

Bit timing is the usual ~600 baud: one short cycle followed by either two more short cycles (a 1) or one long cycle (a 0). The game freezes for about 30 s while saving, as on the Spectrum. To view a saved screen: `MODE(1)` then `CLOAD` (it loads to `$7000`). The emulator tests decode the recorded signal and check the checksum and the data (`tools/tapedecode.py`).

## Memory map (VZ300, BennVenn in VZ300 mode)

| Range | Contents |
|---|---|
| `$0000-$3FFF` | VZ ROM (only used to boot) |
| `$4000-$45FF` | **A1** new code: init, IRQ, keyboard / joystick, renderer, row tables, ray-march loop, glyph renderer (BennVenn DOS RAM bank 0, port `$37` bit 0 = 1) |
| `$4600-$5806` | Spectrum `$6600-$7806`, relocated by −`$2000` (collides with VZ I/O and VRAM). Internal address references are fixed up by the source generator |
| `$5807-$5DFF` | **A2** new code: panning, sights, colour schemes, music selection |
| `$5E00-$65FF` | game variables, landscape map, object tables (Spectrum addresses) |
| `$6600-$67FF` | **A3** new code: sound, fast division |
| `$6800-$6FFF` | VZ latch (write) / keyboard (read) |
| `$7000-$77FF` | VZ video RAM |
| `$7807-$FFFF` | game code and data at their Spectrum addresses. `$B800+` is BennVenn expansion bank 0 |
| inside the game | dead Spectrum code reused for new code, all checked to have no outside references or data reads |

Reused dead Spectrum code:

| Area | Address | Original Spectrum code | New contents |
|---|---|---|---|
| A4 | `$C33C-$C4FF` | start-up tables | print character, font |
| A5 | `$BFB7-$C109` | sights | screen effects (dissolve, materialise dots), music call (`$C10A` keeps the JP to the sights code) |
| A6 | `$B558-$B643` | pan down | code display, text plot |
| A7 | `$9955-$9A5E` | polygon filler | status-bar icons and scanner |
| A8 | `$B442-$B4B0` | pan left | recolouring call into the spare bank |
| A9 | `$C166-$C252` | one-time init | cassette saver |
| A10 | `$B4B4-$B522` | pan right | preview "n SENTRIES" caption |
| A11 | `$B526-$B554` | pan up | interrupt checkpoints |
| A12 | `$9CD4-$9D08` | GetRowVisibility ray-march loop (now `vz_rowvis`) | checkpoints for the engine's row loops and polling loops |
| — | `$9898-$98FC`, `$9900-$9952`, `$9A65-$9A98` | FillScreen / DrawPolygonLines bodies | keyboard tables (`$9896/7`, `$9953/4`, `$9A5F`, `$9A64`, `$9A99` and `$9A9D` are left alone, because the game still writes them) |

The music and recolouring code (`vz_music` in A5, `vz_remap` in A8) has to sit outside `$4000-$67FF`, because it switches that window to the other bank.

**BennVenn spare bank (DOS-area RAM bank 1):**

| Range | Contents |
|---|---|
| `$4000-$401B` | entry points and parameters: play tune, recolour, tint, game-over screen |
| `$401C-…` | music player, recolouring and tint routines, game-over screen, tune data (about 2.2K in all) |
| `$6700-$67FF` | recolouring lookup table |
| rest (~8K) | free |

Expansion bank 1 (`$B800-$FFFF` with port `$37` bit 2 set) is not used.

Other memory used:

- **Off-screen.** View shadow rows live in the free upper part of pages `$D8-$E1` (the lower part is the tile-altitude workspace). Hidden view rows are at `$D640`.
- **IM 2.** The vector table at `$FE00` is filled with `$FD`, and the jump to `VZ_IRQ` sits at `$FDFD`. Stack top is `$FFE0`.
- **`$C500-$C5FF` must keep its original bytes.** The anti-cracker check reads the secret-code stash there.

**Loading.** The `.VZ` file is about 21 KB, loads at `$954D-$E804`, and starts at a boot stub. The stub copies itself into video RAM and ZX0-decompresses four blocks: first the music bank into DOS RAM bank 1 (`OUT ($37),3`), then, with bank 0 mapped (`OUT ($37),1`), `$4000-$67FF`, `$FD00-$FDFF` and an in-place `$7807-$E7FF`. Finally it clears `$E800-$FCFF` and jumps to `VZ_Init`.

## Hardware notes

- **RAM.** Needs the BennVenn 128K in VZ300 mode. The expansion bank must be mapped at `$B800-$FFFF` (expansion bank 0), and the DOS area `$4000-$67FF` must be switchable to RAM: bank 0 for the game (port `$37` = 1), bank 1 for music and recolouring (port `$37` = 3). Nothing else about the SD loader is used once the game is running.
- **Interrupts.** The game runs in IM 2, with its own table, so the value on the data bus does not matter. The VZ frame-sync interrupt is level-triggered, so it must not be re-enabled while FS is still low. During normal play the handler waits for FS to go high (with a timeout), which costs about 16% of the CPU. While a view is drawn off-screen it doesn't wait. It returns with interrupts off, and `vz_ckpt` switches them back on from the hot code once FS is high. See Speed.
- **Keyboard and joystick.** The keyboard is read directly from `$68xx`. The joystick uses the ports listed under Controls. Nothing goes through the ROM.
- **Speaker and cassette.** The speaker is latch bits 0 and 5, and cassette out is bits 1 and 2, driven together. The latch shadow is kept in `vz_latch` so the mode and colour-set bits are always preserved.

## Building

You need Python 3, [sjasmplus](https://github.com/z00m128/sjasmplus) 1.24 and [ZX0](https://github.com/einar-saukas/ZX0), built into `tools/sjasmplus/sjasmplus` and `tools/zx0/zx0`, with ZX0's `z80/dzx0_standard.asm` in place. Then:

```
python3 tools/build.py          # -> build/SENTINEL.VZ
```

`build.py` does the following:

1. Runs `tools/gen_src.py` to regenerate sjasmplus source of the Spectrum image from `orig/base.mem` plus the disassembly analysis `dis/analysis.json`.
2. Assembles it with the port layer `src/vz_port.asm`, which overlays the patches in `src/vz_patches.asm` and includes the new modules.
3. Compresses the result and wraps it in the boot stub.

`orig/base.mem` is the Spectrum memory just after the game's own start-up code ran, with its screen buffers zeroed. It was taken from your tape by simulating the Bleepload loader (SkoolKit `tap2sna.py`) and running the game's initialisation. Reassembling the generated source without the port layer reproduces the original byte for byte.

### Source modules (`src/`)

| File | Contents |
|---|---|
| `vz_port.asm` | top level: equates, code-area placement |
| `vz_patches.asm` | every patch to the original, each commented with what it replaces |
| `vz_hw.asm` | init, IRQ, keyboard, joystick, Spectrum keyboard emulation for the IRQ code |
| `vz_gfx.asm` | polygon span renderer, background fill, palettes, row tables |
| `vz_scroll.asm` | panning, buffer→screen copies, hidden drawing and reveal |
| `vz_sights.asm` | sights |
| `vz_hud.asm` | status-bar icons and scanner |
| `vz_text.asm`, `vz_glyph.asm`, `vz_textplot.asm` | text |
| `vz_code.asm` | entry-code digits |
| `vz_sentries.asm` | preview caption |
| `vz_fx.asm` | dissolves, materialise dots |
| `vz_sound.asm` | speaker versions of the beeper routines |
| `vz_scheme.asm` | colour schemes |
| `vz_tape.asm` | cassette save |
| `vz_fast.asm`, `vz_div.asm` | engine speed-ups (ray march, division) |
| `vz_irqck.asm`, `vz_ckrows.asm` | interrupt checkpoints |
| `vz_musicif.asm`, `vz_musicsel.asm` | music: bank switching, which tune for which screen |
| `vz_remap.asm` | recolouring call into the spare bank |
| `vz_keydata*.asm` | keyboard tables |
| `music/player.asm` | the spare-bank module: music player, tunes (generated by `tools/compose.py`), recolouring |

### Test tools (`tools/`)

- **`vzemu/`**: a VZ300 + BennVenn test emulator driven by scripts. It traps on I/O, video or protected-memory access by unexpected code and logs speaker and cassette output.
- **`zxemu/`**: a Spectrum test emulator for side-by-side comparison with the original.
- **`sndtest/`**, **`sndcmp.py`**: per-routine sound comparison.
- **`tracediff.py`**: control-flow comparison between the two machines.
- **`getcode.sh`**: entry codes.
- **`vzland.py`**: start any landscape in the VZ emulator.
- **`mkbench.sh`**, **`profsum.py`**, **`ticks.py`**: drawing benchmark, profile by routine, and a check that no interrupt ticks are lost.
- **`compose.py`**, **`edges2wav.py`**: the music source, and WAV rendering of the speaker output.

## Known limitations

- **Panning.** Panning still pays the 16% field-sync wait, because the shortcut is only used while a whole view is drawn off-screen. The engine speed-ups help panning too.
- **Music while waiting.** The title and preview music run with interrupts off. A key stops it at once, but on the title the colour keys and Z are just "any key" while it plays, as they were on the Spectrum's title screen.
- **Resolution.** At 128×64, small or distant objects get only a few pixels, and the bottom 3 Spectrum character rows of the view are not shown. They are still drawn off-screen, because panning down needs them.
- **Real-hardware check needed.** The colours and the frame-sync timing were tested in an emulator modelled on MAME. Details of the 6847's colour set and the FS timing on your machine may differ slightly.
- **Joystick.** Fire only toggles the sights. Absorb, create and the other actions need the keyboard.
- **Screen-save filename.** The name counter restarts at `SENTSCR0` each time the game is loaded.
