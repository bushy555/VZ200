; =============================================================================
;  PAC-MAN clone for the VZ200 / VZ300   (Z80 assembler, MODE(1) graphics)
;
;  * MODE(1): 128x64 pixels, 4 colours, 2 bits/pixel, 4 pixels per byte.
;    The maze is a 32 x 14 grid of 4x4 pixel tiles = exactly 1 byte wide.
;  * Colour set 0:  0 = green (background)  1 = yellow  2 = blue  3 = red
;  * Keys:  Q = up   A = down   O = left   P = right   (Z / X also = left/right)
;  * Includes a 5-entry HIGH SCORE TABLE with 3-letter name entry.
;
;  Load address 0x8000, needs the 16K RAM expansion (or a VZ300).
;  Load with  CLOAD / BLOAD "PACMAN"   (or load the .VZ in an emulator).
; =============================================================================

        ORG     0x8000

VRAM    EQU     0x7000          ; video RAM (2K)
LATCH   EQU     0x6800          ; write: output latch / read: keyboard matrix
GMODE   EQU     0x08            ; latch value: AG=1 -> MODE(1), colour set 0
SPKON   EQU     0x29            ; GMODE + both speaker bits
MAZEW   EQU     32
MAZEH   EQU     14
NGH     EQU     4               ; number of ghosts
GSIZE   EQU     5               ; ghost record: x,y,dir,wait,frightened
FPT     EQU     6               ; video frames per game tick (speed of game)
KEYN    EQU     6               ; entries in key table
PENX0   EQU     14              ; ghost pen box (x0, width, y0, height)
PENW    EQU     4
PENY0   EQU     5
PENH    EQU     2
DOORX   EQU     15              ; ghosts head for (DOORX, DOORY-1) to leave
DOORY   EQU     5
HOMEX   EQU     15              ; eaten ghosts are sent here
HOMEY   EQU     6
PACX0   EQU     15              ; pac-man start tile
PACY0   EQU     8

; ---------------------------------------------------------------- RAM layout
        RAMORG  (CODEEND+255)&0xFF00
        VAR     MAZE,448        ; working copy of the maze (256-byte aligned)
        VAR     SEED
        VAR     TICK
        VAR     PX
        VAR     PY
        VAR     PDIR
        VAR     PNEXT
        VAR     FRIGHT
        VAR     SCORE,2
        VAR     HISHOW,2
        VAR     LIVES
        VAR     LEVEL
        VAR     DOTS
        VAR     GMASK
        VAR     GVAL,2
        VAR     WAKA
        VAR     TXTMASK
        VAR     GIDX
        VAR     GP,2
        VAR     CX
        VAR     CY
        VAR     CD
        VAR     CF
        VAR     TX
        VAR     TY
        VAR     BEST
        VAR     BDIR
        VAR     CAND
        VAR     RNDM
        VAR     DK
        VAR     ENTRY,2
        VAR     NPOS
        VAR     NI
        VAR     LASTK
        VAR     HOLD
        VAR     GHOSTS,NGH*GSIZE
        VAR     NUMBUF,9
        VAR     LINEBUF,16

; =============================================================================
;  Entry point
; =============================================================================
START:  DI
        LD      SP,0x8000
        LD      A,GMODE
        LD      (LATCH),A               ; switch VDG to MODE(1)
        LD      A,R
        OR      1
        LD      (SEED),A
MAIN:   CALL    TitleScreen
        CALL    PlayGame
        CALL    HiScoreEntry
        JR      MAIN

; =============================================================================
;  Title screen with high score table
; =============================================================================
TitleScreen:
        CALL    ClearScreen
        LD      HL,TitleList
        CALL    PrintList
        CALL    DrawHiTable
        CALL    WaitNoKey
.w:     LD      HL,SEED
        INC     (HL)
        CALL    AnyKey
        JR      Z,.w
        RET

TitleList:
        DB      12,0,0xFF,"PAC-MAN",0
        DB      6,1,0xAA,"VZ200 CLONE - MODE 1",0
        DB      10,2,0x55,"HIGH SCORES",0
        DB      9,8,0xAA,"Q A  O P  TO MOVE",0
        DB      9,9,0xFF,"PRESS ANY KEY",0
        DB      0xFF

; draw the 5 table rows at text rows 3..7
DrawHiTable:
        LD      HL,HISCORE
        LD      B,5
        LD      C,3
.row:   PUSH    BC
        PUSH    HL
        LD      DE,LINEBUF
        LD      A,10
        LD      (DE),A                  ; column
        INC     DE
        LD      A,C
        LD      (DE),A                  ; text row
        INC     DE
        CP      3
        LD      A,0x55                  ; yellow...
        JR      NZ,.m
        LD      A,0xFF                  ; ...but the top score is red
.m:     LD      (DE),A
        INC     DE
        LD      A,C
        ADD     A,'1'-3                 ; rank digit
        LD      (DE),A
        INC     DE
        LD      A,' '
        LD      (DE),A
        INC     DE
        LDI                             ; 3 name letters
        LDI
        LDI
        LD      A,' '
        LD      (DE),A
        INC     DE
        PUSH    DE
        LD      E,(HL)
        INC     HL
        LD      D,(HL)
        EX      DE,HL                   ; HL = score
        CALL    Num5
        POP     DE
        LD      HL,NUMBUF+3
        LD      BC,5
        LDIR
        XOR     A
        LD      (DE),A
        LD      HL,LINEBUF
        CALL    PrintStr
        POP     HL
        LD      DE,5
        ADD     HL,DE
        POP     BC
        INC     C
        DJNZ    .row
        RET

; =============================================================================
;  Game
; =============================================================================
PlayGame:
        LD      HL,0
        LD      (SCORE),HL
        LD      A,3
        LD      (LIVES),A
        LD      A,1
        LD      (LEVEL),A
        LD      HL,(HISCORE+3)          ; best score so far
        LD      (HISHOW),HL
        CALL    ResetActors
.newlevel:
        CALL    InitLevel
.newround:
        CALL    EraseActors
        CALL    ResetActors
        CALL    Ready
.tick:  LD      B,FPT
        CALL    WaitFrames
        CALL    ReadKeys
        CALL    EraseActors
        LD      HL,TICK
        INC     (HL)
        CALL    MovePac
        CALL    EatTile
        CALL    CheckColl
        OR      A
        JR      NZ,.die
        CALL    FrightTimer
        CALL    MoveGhosts
        CALL    CheckColl
        OR      A
        JR      NZ,.die
        CALL    DrawActors
        LD      A,(DOTS)
        OR      A
        JR      NZ,.tick
        CALL    LevelDone
        LD      HL,LEVEL
        INC     (HL)
        JR      .newlevel
.die:   CALL    DrawActors
        CALL    DeathAnim
        LD      HL,LIVES
        DEC     (HL)
        CALL    DrawLives
        LD      A,(LIVES)
        OR      A
        JR      NZ,.newround
        JP      GameOver

Ready:  LD      HL,ReadyStr
        CALL    PrintStr
        LD      B,5
.j:     PUSH    BC
        LD      A,B
        ADD     A,A
        ADD     A,A
        ADD     A,A
        ADD     A,30
        LD      B,A
        LD      C,40
        CALL    Beep
        POP     BC
        DJNZ    .j
        LD      B,40
        CALL    WaitFrames
        CALL    RedrawMaze
        JP      DrawActors

ReadyStr:
        DB      13,7,0xFF,"READY!",0

GameOver:
        LD      HL,GameOverStr
        CALL    PrintStr
        LD      B,100
        JP      WaitFrames

GameOverStr:
        DB      11,7,0xFF,"GAME OVER",0

LevelDone:
        XOR     A
        LD      (DK),A
.l:     LD      A,(DK)
        ADD     A,A
        ADD     A,A
        LD      B,A
        LD      A,80
        SUB     B
        LD      B,A
        LD      C,25
        CALL    Beep
        LD      HL,DK
        INC     (HL)
        LD      A,(HL)
        CP      8
        JR      NZ,.l
        LD      B,25
        JP      WaitFrames

; ---------------------------------------------------------------- set up a level
InitLevel:
        LD      HL,MAZEROM
        LD      DE,MAZE
        LD      BC,MAZEW*MAZEH
        LDIR
        LD      HL,MAZE                 ; count dots + pellets
        LD      BC,MAZEW*MAZEH
        LD      D,0
.c:     LD      A,(HL)
        CP      '.'
        JR      Z,.y
        CP      'o'
        JR      NZ,.n
.y:     INC     D
.n:     INC     HL
        DEC     BC
        LD      A,B
        OR      C
        JR      NZ,.c
        LD      A,D
        LD      (DOTS),A
        LD      A,(LEVEL)               ; ghost speed: slower ghosts early on
        DEC     A
        CP      2
        JR      C,.s
        LD      A,2
.s:     LD      E,A
        LD      D,0
        LD      HL,GMTAB
        ADD     HL,DE
        LD      A,(HL)
        LD      (GMASK),A
        CALL    ClearScreen
        CALL    RedrawMaze
        JP      DrawStatus

ResetActors:
        LD      A,PACX0
        LD      (PX),A
        LD      A,PACY0
        LD      (PY),A
        LD      A,2
        LD      (PDIR),A
        LD      (PNEXT),A
        XOR     A
        LD      (FRIGHT),A
        LD      HL,GHINIT
        LD      DE,GHOSTS
        LD      BC,NGH*GSIZE
        LDIR
        RET

; ---------------------------------------------------------------- pac-man
; try to move pac-man one tile in direction A. Z = success
PacTry: LD      E,A
        LD      D,0
        LD      HL,DXT
        ADD     HL,DE
        LD      A,(PX)
        ADD     A,(HL)
        AND     31
        LD      B,A
        LD      HL,DYT
        ADD     HL,DE
        LD      A,(PY)
        ADD     A,(HL)
        LD      C,A
        PUSH    DE
        LD      E,0                     ; 0 = pac-man (blocked by the ghost door)
        CALL    CanMove
        POP     DE
        OR      A
        RET     NZ
        LD      A,B
        LD      (PX),A
        LD      A,C
        LD      (PY),A
        LD      A,E
        LD      (PDIR),A
        XOR     A
        RET

MovePac:
        LD      A,(PNEXT)
        CALL    PacTry
        RET     Z
        LD      A,(PDIR)
        JR      PacTry

; eat whatever is on pac-man's tile
EatTile:
        LD      A,(PX)
        LD      B,A
        LD      A,(PY)
        LD      C,A
        CALL    MazePtr
        LD      A,(HL)
        CP      '.'
        JR      Z,.dot
        CP      'o'
        RET     NZ
        LD      (HL),' '                ; power pellet
        LD      HL,50
        CALL    AddScore
        LD      HL,DOTS
        DEC     (HL)
        CALL    StartFright
        LD      B,35
        LD      C,40
        JP      Beep
.dot:   LD      (HL),' '
        LD      HL,10
        CALL    AddScore
        LD      HL,DOTS
        DEC     (HL)
        LD      A,(WAKA)
        XOR     1
        LD      (WAKA),A
        LD      B,80
        JR      Z,.b
        LD      B,55
.b:     LD      C,12
        JP      Beep

StartFright:
        LD      A,(LEVEL)
        DEC     A
        CP      5
        JR      C,.o
        LD      A,5
.o:     LD      E,A
        LD      D,0
        LD      HL,FRTAB
        ADD     HL,DE
        LD      A,(HL)
        LD      (FRIGHT),A
        LD      HL,GHOSTS+4
        LD      B,NGH
        LD      DE,GSIZE
.f:     LD      (HL),1
        ADD     HL,DE
        DJNZ    .f
        LD      HL,200
        LD      (GVAL),HL
        RET

FrightTimer:
        LD      A,(FRIGHT)
        OR      A
        RET     Z
        DEC     A
        LD      (FRIGHT),A
        RET     NZ
        LD      HL,GHOSTS+4
        LD      B,NGH
        LD      DE,GSIZE
.c:     LD      (HL),0
        ADD     HL,DE
        DJNZ    .c
        RET

; ---------------------------------------------------------------- collisions
; returns A<>0 if pac-man was caught; frightened ghosts that are touched get eaten
CheckColl:
        LD      HL,GHOSTS
        LD      B,NGH
.l:     LD      A,(PX)
        CP      (HL)
        JR      NZ,.nx
        INC     HL
        LD      A,(PY)
        CP      (HL)
        DEC     HL
        JR      NZ,.nx
        PUSH    HL
        LD      DE,4
        ADD     HL,DE
        LD      A,(HL)
        POP     HL
        OR      A
        JR      Z,.dead
        PUSH    BC
        PUSH    HL
        CALL    EatGhost
        POP     HL
        POP     BC
.nx:    LD      DE,GSIZE
        ADD     HL,DE
        DJNZ    .l
        XOR     A
        RET
.dead:  LD      A,1
        RET

EatGhost:                               ; HL -> ghost record
        LD      (HL),HOMEX
        INC     HL
        LD      (HL),HOMEY
        INC     HL
        LD      (HL),0
        INC     HL
        LD      (HL),8
        INC     HL
        LD      (HL),0
        LD      HL,(GVAL)
        PUSH    HL
        ADD     HL,HL
        LD      (GVAL),HL
        POP     HL
        CALL    AddScore
        LD      B,25
        LD      C,10
        CALL    Beep
        LD      B,18
        LD      C,14
        JP      Beep

DeathAnim:
        XOR     A
        LD      (DK),A
.l:     LD      A,(PX)
        LD      B,A
        LD      A,(PY)
        LD      C,A
        LD      A,(DK)
        AND     1
        JR      Z,.show
        CALL    DrawTile
        JR      .snd
.show:  LD      DE,PACGFX+16
        CALL    DrawSprite
.snd:   LD      A,(DK)
        ADD     A,A
        ADD     A,A
        ADD     A,40
        LD      B,A
        LD      C,25
        CALL    Beep
        LD      B,2
        CALL    WaitFrames
        LD      HL,DK
        INC     (HL)
        LD      A,(HL)
        CP      14
        JR      NZ,.l
        RET

; ---------------------------------------------------------------- ghosts
MoveGhosts:
        LD      HL,GHOSTS
        XOR     A
        LD      (GIDX),A
.l:     PUSH    HL
        CALL    MoveGhost
        POP     HL
        LD      DE,GSIZE
        ADD     HL,DE
        LD      A,(GIDX)
        INC     A
        LD      (GIDX),A
        CP      NGH
        JR      NZ,.l
        RET

MoveGhost:                              ; HL -> ghost record
        LD      (GP),HL
        INC     HL
        INC     HL
        INC     HL                      ; -> wait counter
        LD      A,(HL)
        OR      A
        JR      Z,.go
        DEC     (HL)
        RET
.go:    INC     HL                      ; -> frightened flag
        LD      A,(HL)
        OR      A
        JR      Z,.norm
        LD      A,(TICK)                ; frightened ghosts move at half speed
        AND     1
        RET     NZ
        JR      .mv
.norm:  LD      A,(TICK)
        LD      B,A
        LD      A,(GMASK)
        LD      C,A
        AND     B
        CP      C
        RET     Z                       ; skip some ticks -> ghosts slower than pac
.mv:    CALL    ChooseDir
        LD      B,A
        LD      E,A
        LD      D,0
        LD      HL,DXT
        ADD     HL,DE
        LD      A,(HL)
        LD      HL,(GP)
        ADD     A,(HL)
        AND     31
        LD      (HL),A                  ; new x
        INC     HL
        PUSH    HL
        LD      HL,DYT
        ADD     HL,DE
        LD      A,(HL)
        POP     HL
        ADD     A,(HL)
        LD      (HL),A                  ; new y
        INC     HL
        LD      (HL),B                  ; new direction
        RET

; pick a direction for the ghost at (GP): returns A = 0..3
ChooseDir:
        LD      HL,(GP)
        LD      A,(HL)
        LD      (CX),A
        INC     HL
        LD      A,(HL)
        LD      (CY),A
        INC     HL
        LD      A,(HL)
        LD      (CD),A
        INC     HL
        INC     HL
        LD      A,(HL)
        LD      (CF),A
        LD      A,(CX)                  ; inside the pen? then aim for the exit
        SUB     PENX0
        CP      PENW
        JR      NC,.nopen
        LD      A,(CY)
        SUB     PENY0
        CP      PENH
        JR      NC,.nopen
        LD      A,DOORX
        LD      (TX),A
        LD      A,DOORY-1
        LD      (TY),A
        XOR     A
        LD      (RNDM),A
        JR      .eval
.nopen: LD      A,(CF)
        OR      A
        JR      Z,.chase
        LD      A,1                     ; frightened: wander randomly
        LD      (RNDM),A
        JR      .eval
.chase: XOR     A
        LD      (RNDM),A
        CALL    Target
.eval:  LD      A,0xFF
        LD      (BEST),A
        LD      A,(CD)
        XOR     1
        LD      (BDIR),A                ; default = turn round (dead end)
        XOR     A
        LD      (CAND),A
.dl:    LD      A,(CD)
        XOR     1
        LD      B,A
        LD      A,(CAND)
        CP      B
        JR      Z,.next                 ; ghosts never reverse voluntarily
        LD      E,A
        LD      D,0
        LD      HL,DXT
        ADD     HL,DE
        LD      A,(CX)
        ADD     A,(HL)
        AND     31
        LD      B,A
        LD      HL,DYT
        ADD     HL,DE
        LD      A,(CY)
        ADD     A,(HL)
        LD      C,A
        LD      E,1                     ; 1 = ghost (may use the door)
        CALL    CanMove
        OR      A
        JR      NZ,.next
        LD      A,(RNDM)
        OR      A
        JR      Z,.dist
        CALL    Rand
        AND     0x7F
        JR      .cmp
.dist:  LD      A,(TX)
        LD      D,A
        LD      A,(TY)
        LD      E,A
        CALL    Dist
.cmp:   LD      HL,BEST
        CP      (HL)
        JR      NC,.next
        LD      (HL),A
        LD      A,(CAND)
        LD      (BDIR),A
.next:  LD      A,(CAND)
        INC     A
        LD      (CAND),A
        CP      4
        JR      NZ,.dl
        LD      A,(BDIR)
        RET

; set (TX,TY) according to ghost personality (GIDX)
Target: LD      A,(GIDX)
        OR      A
        JR      Z,.pac                  ; 0: chase pac-man directly
        CP      1
        JR      Z,.ahead                ; 1: aim 4 tiles ahead of pac-man
        CP      2
        JR      Z,.mirror               ; 2: aim opposite pac-man
        LD      A,(CX)                  ; 3: chase when far, run to corner when near
        LD      B,A
        LD      A,(CY)
        LD      C,A
        LD      A,(PX)
        LD      D,A
        LD      A,(PY)
        LD      E,A
        CALL    Dist
        CP      9
        JR      NC,.pac
        LD      A,1
        LD      (TX),A
        LD      A,12
        LD      (TY),A
        RET
.pac:   LD      A,(PX)
        LD      (TX),A
        LD      A,(PY)
        LD      (TY),A
        RET
.mirror:
        LD      A,31
        LD      HL,PX
        SUB     (HL)
        LD      (TX),A
        LD      A,13
        LD      HL,PY
        SUB     (HL)
        LD      (TY),A
        RET
.ahead: LD      A,(PDIR)
        LD      E,A
        LD      D,0
        LD      HL,DXT
        ADD     HL,DE
        LD      A,(HL)
        ADD     A,A
        ADD     A,A
        LD      HL,PX
        ADD     A,(HL)
        LD      B,31
        CALL    Clamp
        LD      (TX),A
        LD      HL,DYT
        ADD     HL,DE
        LD      A,(HL)
        ADD     A,A
        ADD     A,A
        LD      HL,PY
        ADD     A,(HL)
        LD      B,13
        CALL    Clamp
        LD      (TY),A
        RET

Clamp:  BIT     7,A                     ; clamp signed A into 0..B
        JR      NZ,.neg
        CP      B
        RET     Z
        RET     C
        LD      A,B
        RET
.neg:   XOR     A
        RET

; manhattan distance (B,C)-(D,E) -> A      (clobbers H)
Dist:   LD      A,B
        SUB     D
        JR      NC,.a
        NEG
.a:     LD      H,A
        LD      A,C
        SUB     E
        JR      NC,.b
        NEG
.b:     ADD     A,H
        RET

; ---------------------------------------------------------------- maze helpers
; B=x C=y -> HL = address in MAZE   (MAZE is 256-byte aligned)
MazePtr:
        LD      A,C
        RRCA
        RRCA
        RRCA
        LD      L,A
        AND     0x1F
        ADD     A,MAZE>>8
        LD      H,A
        LD      A,L
        AND     0xE0
        ADD     A,B
        LD      L,A
        RET

; B=x C=y -> HL = video RAM address of tile top-left (tile row 0..1 is the status line)
ScrPtr: LD      A,C
        ADD     A,2
        LD      L,A
        SRL     A
        ADD     A,0x70
        LD      H,A
        LD      A,L
        RRCA
        AND     0x80
        ADD     A,B
        LD      L,A
        RET

; can a creature step onto tile (B,C)?  E=0 pac-man, E=1 ghost.  A=0 free, A<>0 blocked
CanMove:
        PUSH    HL
        PUSH    DE
        CALL    MazePtr
        LD      A,(HL)
        POP     DE
        POP     HL
        CP      '#'
        JR      Z,.blk
        CP      '-'
        JR      NZ,.free
        LD      A,E
        OR      A
        JR      Z,.blk
.free:  XOR     A
        RET
.blk:   LD      A,1
        RET

; draw the maze tile at (B,C) - registers preserved
DrawTile:
        PUSH    BC
        PUSH    DE
        PUSH    HL
        CALL    MazePtr
        LD      A,(HL)
        LD      DE,G_BLANK
        CP      '#'
        JR      NZ,.t1
        LD      DE,G_WALL
        JR      .go
.t1:    CP      '.'
        JR      NZ,.t2
        LD      DE,G_DOT
        JR      .go
.t2:    CP      'o'
        JR      NZ,.t3
        LD      DE,G_PELLET
        JR      .go
.t3:    CP      '-'
        JR      NZ,.go
        LD      DE,G_DOOR
.go:    CALL    ScrPtr
        CALL    DrawGfx
        POP     HL
        POP     DE
        POP     BC
        RET

; draw 4-row graphic at DE onto video address HL
DrawGfx:
        LD      B,4
.r:     LD      A,(DE)
        INC     DE
        LD      (HL),A
        LD      A,L
        ADD     A,32
        LD      L,A
        JR      NC,.n
        INC     H
.n:     DJNZ    .r
        RET

DrawSprite:                             ; B=x C=y DE=graphic
        CALL    ScrPtr
        JR      DrawGfx

RedrawMaze:
        LD      C,0
.y:     LD      B,0
.x:     CALL    DrawTile
        INC     B
        LD      A,B
        CP      MAZEW
        JR      NZ,.x
        INC     C
        LD      A,C
        CP      MAZEH
        JR      NZ,.y
        RET

; ---------------------------------------------------------------- actors on screen
EraseActors:
        LD      A,(PX)
        LD      B,A
        LD      A,(PY)
        LD      C,A
        CALL    DrawTile
        LD      HL,GHOSTS
        LD      D,NGH
.l:     LD      B,(HL)
        INC     HL
        LD      C,(HL)
        CALL    DrawTile
        LD      BC,GSIZE-1
        ADD     HL,BC
        DEC     D
        JR      NZ,.l
        RET

DrawActors:
        LD      A,(TICK)                ; pac-man: mouth open / closed
        AND     1
        LD      DE,PACGFX+16
        JR      NZ,.dp
        LD      A,(PDIR)
        ADD     A,A
        ADD     A,A
        LD      E,A
        LD      D,0
        LD      HL,PACGFX
        ADD     HL,DE
        EX      DE,HL
.dp:    LD      A,(PX)
        LD      B,A
        LD      A,(PY)
        LD      C,A
        CALL    DrawSprite
        LD      HL,GHOSTS
        LD      A,NGH
.gl:    PUSH    AF
        PUSH    HL
        LD      B,(HL)
        INC     HL
        LD      C,(HL)
        INC     HL
        INC     HL
        INC     HL
        LD      A,(HL)                  ; frightened flag
        OR      A
        JR      NZ,.sc
        LD      A,(TICK)
        AND     1
        JR      .gi
.sc:    LD      A,(FRIGHT)
        CP      24
        JR      NC,.s2
        AND     2                       ; flash when time is nearly up
        JR      Z,.s2
        LD      A,3
        JR      .gi
.s2:    LD      A,2
.gi:    ADD     A,A
        ADD     A,A
        LD      E,A
        LD      D,0
        LD      HL,GHGFX
        ADD     HL,DE
        EX      DE,HL
        CALL    DrawSprite
        POP     HL
        LD      DE,GSIZE
        ADD     HL,DE
        POP     AF
        DEC     A
        JR      NZ,.gl
        RET

; ---------------------------------------------------------------- score / status line
; HL = points to add
AddScore:
        LD      DE,(SCORE)
        ADD     HL,DE
        JR      NC,.ok
        LD      HL,0xFFFF
.ok:    LD      (SCORE),HL
        LD      DE,(HISHOW)
        OR      A
        SBC     HL,DE
        JR      C,.nohi
        LD      HL,(SCORE)
        LD      (HISHOW),HL
.nohi:  JP      DrawScore

DrawStatus:
        LD      HL,StatusList
        CALL    PrintList
        CALL    DrawScore
        CALL    DrawLevel
        JP      DrawLives

StatusList:
        DB      0,0,0xFF,"SCORE",0
        DB      13,0,0xFF,"HI",0
        DB      23,0,0xFF,"L",0
        DB      0xFF

DrawScore:
        LD      HL,(SCORE)
        CALL    Num5
        LD      B,6
        LD      C,0
        LD      A,0x55
        CALL    DrawNum5
        LD      HL,(HISHOW)
        CALL    Num5
        LD      B,16
        LD      C,0
        LD      A,0x55
        JP      DrawNum5

DrawLevel:
        LD      A,(LEVEL)
        LD      L,A
        LD      H,0
        CALL    Num5
        LD      HL,NUMBUF+3
        LD      (HL),24
        INC     HL
        LD      (HL),0
        INC     HL
        LD      (HL),0x55
        LD      HL,NUMBUF+3
        JP      PrintStr

DrawLives:                              ; one icon per spare life, max 5
        LD      HL,VRAM+32+27
        LD      B,5
        LD      A,(LIVES)
        DEC     A
        LD      C,A
.l:     PUSH    BC
        PUSH    HL
        LD      A,C
        OR      A
        LD      DE,G_BLANK
        JR      Z,.d
        LD      DE,PACGFX+12
.d:     CALL    DrawGfx
        POP     HL
        INC     HL
        POP     BC
        LD      A,C
        OR      A
        JR      Z,.nd
        DEC     C
.nd:    DJNZ    .l
        RET

; ---------------------------------------------------------------- text engine
; Font: 3x5 glyphs, one byte per pixel row, already in MODE(1) format (colour 3).
; A cell is 4 pixels = 1 byte wide, text rows are 6 pixels high (10 per screen).

; A = ASCII char, HL = video address -> draws glyph (colour = TXTMASK), HL+1
PutCh:  PUSH    BC
        PUSH    DE
        PUSH    HL
        SUB     0x20
        LD      L,A
        LD      H,0
        LD      D,H
        LD      E,L
        ADD     HL,HL
        ADD     HL,HL
        ADD     HL,DE                   ; *5
        LD      DE,FONT
        ADD     HL,DE
        EX      DE,HL                   ; DE -> glyph
        POP     HL
        PUSH    HL
        LD      B,5
.r:     LD      A,(DE)
        INC     DE
        LD      C,A
        LD      A,(TXTMASK)
        AND     C
        LD      (HL),A
        LD      A,L
        ADD     A,32
        LD      L,A
        JR      NC,.n
        INC     H
.n:     DJNZ    .r
        POP     HL
        INC     HL
        POP     DE
        POP     BC
        RET

; HL -> record: col, textrow, colour-mask, "text", 0 .  returns DE -> next byte
PrintStr:
        LD      B,(HL)
        INC     HL
        LD      C,(HL)
        INC     HL
        LD      A,(HL)
        LD      (TXTMASK),A
        INC     HL
        PUSH    HL
        LD      L,C
        LD      H,0
        LD      D,H
        LD      E,L
        ADD     HL,HL
        ADD     HL,DE                   ; row*3
        ADD     HL,HL
        ADD     HL,HL
        ADD     HL,HL
        ADD     HL,HL
        ADD     HL,HL
        ADD     HL,HL                   ; *64 -> row*192
        LD      E,B
        LD      D,0
        ADD     HL,DE
        LD      DE,VRAM
        ADD     HL,DE
        POP     DE
.l:     LD      A,(DE)
        INC     DE
        OR      A
        RET     Z
        CALL    PutCh
        JR      .l

PrintList:                              ; list of records ended by 0xFF
        LD      A,(HL)
        CP      0xFF
        RET     Z
        CALL    PrintStr
        EX      DE,HL
        JR      PrintList

; HL = value -> 5 ASCII digits at NUMBUF+3, terminator at NUMBUF+8
Num5:   LD      DE,NUMBUF+3
        LD      BC,10000
        CALL    .dig
        LD      BC,1000
        CALL    .dig
        LD      BC,100
        CALL    .dig
        LD      BC,10
        CALL    .dig
        LD      A,L
        ADD     A,'0'
        LD      (DE),A
        INC     DE
        XOR     A
        LD      (DE),A
        RET
.dig:   LD      A,'0'-1
.s:     INC     A
        OR      A
        SBC     HL,BC
        JR      NC,.s
        ADD     HL,BC
        LD      (DE),A
        INC     DE
        RET

; print the digits made by Num5 at column B, text row C, colour mask A
DrawNum5:
        LD      HL,NUMBUF
        LD      (HL),B
        INC     HL
        LD      (HL),C
        INC     HL
        LD      (HL),A
        LD      HL,NUMBUF
        JP      PrintStr

ClearScreen:
        LD      HL,VRAM
        LD      DE,VRAM+1
        LD      BC,2047
        LD      (HL),0
        LDIR
        RET

; ---------------------------------------------------------------- input / timing / sound
; sets PNEXT to the last direction key found down
ReadKeys:
        LD      HL,KeyTab
        LD      B,KEYN
.l:     LD      E,(HL)                  ; low byte of matrix address
        INC     HL
        LD      D,(HL)                  ; bit mask
        INC     HL
        LD      C,(HL)                  ; direction
        INC     HL
        PUSH    HL
        LD      H,0x68
        LD      L,E
        LD      A,(HL)
        AND     D
        POP     HL
        JR      NZ,.no                  ; key matrix is active low
        LD      A,C
        LD      (PNEXT),A
.no:    DJNZ    .l
        RET

KeyTab: DB      0xFE,0x10,0             ; Q  up
        DB      0xFD,0x10,1             ; A  down
        DB      0xBF,0x02,2             ; O  left
        DB      0xBF,0x10,3             ; P  right
        DB      0xFB,0x10,2             ; Z  left
        DB      0xFB,0x02,3             ; X  right

AnyKey: LD      A,(LATCH)               ; reads all 8 keyboard rows at once
        OR      0xC0
        CP      0xFF
        RET                             ; Z = no key down

WaitNoKey:
        CALL    AnyKey
        JR      NZ,WaitNoKey
        RET

; wait for one video frame using the vertical-sync bit (bit 7 of the keyboard
; port), with time-outs so it still runs where that bit is not emulated
WaitFrame:
        LD      DE,3000
.a:     LD      A,(LATCH)
        RLA
        JR      C,.b
        DEC     DE
        LD      A,D
        OR      E
        JR      NZ,.a
.b:     LD      DE,3000
.c:     LD      A,(LATCH)
        RLA
        JR      NC,.d
        DEC     DE
        LD      A,D
        OR      E
        JR      NZ,.c
.d:     RET

WaitFrames:                             ; B frames
.l:     PUSH    BC
        CALL    WaitFrame
        POP     BC
        DJNZ    .l
        RET

; square wave: B = half period (bigger = lower), C = number of cycles
Beep:   LD      E,B
.cy:    LD      A,SPKON
        LD      (LATCH),A
        LD      D,E
.h1:    DEC     D
        JR      NZ,.h1
        LD      A,GMODE
        LD      (LATCH),A
        LD      D,E
.h2:    DEC     D
        JR      NZ,.h2
        DEC     C
        JR      NZ,.cy
        RET

; pseudo random number -> A  (clobbers B)
Rand:   LD      A,(SEED)
        LD      B,A
        ADD     A,A
        ADD     A,A
        ADD     A,B
        INC     A
        LD      (SEED),A
        LD      B,A
        LD      A,R
        XOR     B
        RET

; =============================================================================
;  High score table
; =============================================================================
; called after a game: if SCORE earns a place, insert it and let the player
; type a name
HiScoreEntry:
        LD      HL,(SCORE)
        LD      A,H
        OR      L
        RET     Z
        LD      HL,HISCORE
        LD      B,0
.f:     PUSH    HL
        LD      DE,3
        ADD     HL,DE
        LD      E,(HL)
        INC     HL
        LD      D,(HL)
        LD      HL,(SCORE)
        OR      A
        SBC     HL,DE                   ; score - entry
        POP     HL
        JR      C,.next
        JR      NZ,.found               ; strictly better
.next:  LD      DE,5
        ADD     HL,DE
        INC     B
        LD      A,B
        CP      5
        JR      NZ,.f
        RET                             ; did not make the table
.found: LD      (ENTRY),HL
        LD      A,4
        SUB     B
        JR      Z,.ins                  ; goes in last place: nothing to move
        LD      C,A                     ; move (4-rank) entries down one place
        ADD     A,A
        ADD     A,A
        ADD     A,C
        LD      C,A
        LD      B,0
        LD      HL,HISCORE+19
        LD      DE,HISCORE+24
        LDDR
.ins:   LD      HL,(ENTRY)
        LD      (HL),'A'
        INC     HL
        LD      (HL),'A'
        INC     HL
        LD      (HL),'A'
        INC     HL
        LD      DE,(SCORE)
        LD      (HL),E
        INC     HL
        LD      (HL),D

NameEntry:
        CALL    ClearScreen
        LD      HL,NameList
        CALL    PrintList
        LD      HL,(SCORE)
        CALL    Num5
        LD      B,15
        LD      C,2
        LD      A,0x55
        CALL    DrawNum5
        XOR     A
        LD      (NPOS),A
        LD      (HOLD),A
        LD      A,0xFF
        LD      (LASTK),A
        CALL    WaitNoKey
.poll:  CALL    DrawName
        LD      B,3
        CALL    WaitFrames
        LD      A,0xFF
        LD      (PNEXT),A
        CALL    ReadKeys
        LD      A,(PNEXT)
        CP      0xFF
        JR      NZ,.pressed
        LD      (LASTK),A               ; nothing down: re-arm
        XOR     A
        LD      (HOLD),A
        JR      .poll
.pressed:
        LD      B,A
        LD      A,(LASTK)
        CP      B
        JR      NZ,.act                 ; fresh key press
        LD      HL,HOLD                 ; held: auto-repeat up/down only
        INC     (HL)
        LD      A,(HL)
        CP      6
        JR      C,.poll
        LD      A,B
        CP      2
        JR      NC,.poll
        LD      A,4
        LD      (HOLD),A
.act:   LD      A,B
        LD      (LASTK),A
        LD      HL,(ENTRY)
        LD      A,(NPOS)
        LD      E,A
        LD      D,0
        ADD     HL,DE                   ; HL -> letter being edited
        LD      A,B
        OR      A
        JR      Z,.up
        DEC     A
        JR      Z,.dn
        DEC     A
        JR      Z,.left
        LD      A,(NPOS)                ; right: accept letter
        INC     A
        LD      (NPOS),A
        CP      3
        JR      NZ,.poll
        CALL    DrawName
        LD      B,40
        JP      WaitFrames
.left:  LD      A,(NPOS)
        OR      A
        JR      Z,.poll
        DEC     A
        LD      (NPOS),A
        JR      .poll
.up:    LD      A,(HL)
        INC     A
        CP      'Z'+1
        JR      NZ,.u2
        LD      A,'A'
.u2:    LD      (HL),A
        JR      .poll
.dn:    LD      A,(HL)
        DEC     A
        CP      'A'-1
        JR      NZ,.d2
        LD      A,'Z'
.d2:    LD      (HL),A
        JP      .poll

NameList:
        DB      8,0,0xFF,"NEW HIGH SCORE!",0
        DB      9,2,0x55,"SCORE",0
        DB      8,6,0xAA,"ENTER YOUR NAME",0
        DB      7,8,0xAA,"Q A LETTER  P NEXT",0
        DB      13,9,0xAA,"O BACK",0
        DB      0xFF

DrawName:
        XOR     A
        LD      (NI),A
.l:     LD      A,(NPOS)
        LD      B,A
        LD      A,(NI)
        CP      B
        LD      A,0xFF                  ; active letter red, others yellow
        JR      Z,.m
        LD      A,0x55
.m:     LD      (TXTMASK),A
        LD      A,(NI)
        LD      E,A
        LD      D,0
        LD      HL,(ENTRY)
        ADD     HL,DE
        LD      C,(HL)                  ; the letter
        LD      A,E
        ADD     A,A
        ADD     A,13
        LD      L,A
        LD      H,0
        LD      DE,VRAM+4*192
        ADD     HL,DE
        LD      A,C
        CALL    PutCh
        LD      A,(NI)
        INC     A
        LD      (NI),A
        CP      3
        JR      NZ,.l
        RET

; =============================================================================
;  Data
; =============================================================================
; 5 entries: 3 letters + 16-bit score (little endian)
HISCORE:
        DB      "PAC"
        DW      5000
        DB      "MAN"
        DW      4000
        DB      "VZ2"
        DW      3000
        DB      "ZED"
        DW      2000
        DB      "ABC"
        DW      1000

DXT:    DB      0,0,0xFF,1              ; direction 0=up 1=down 2=left 3=right
DYT:    DB      0xFF,1,0,0
FRTAB:  DB      110,90,70,55,40,30      ; frightened time (ticks) per level
GMTAB:  DB      3,7,15                  ; ghost slow-down mask per level

; ghost start records: x, y, dir, wait, frightened
GHINIT: DB      15,4,2,0,0
        DB      14,6,0,12,0
        DB      17,6,0,30,0
        DB      16,6,0,50,0

; 4x4 pixel graphics, 2 bits per pixel: 0=green 1=yellow 2=blue 3=red
G_BLANK:  DB    0x00,0x00,0x00,0x00
G_WALL:   DB    0xAA,0xAA,0xAA,0xAA
G_DOT:    DB    0x00,0x14,0x14,0x00
G_PELLET: DB    0x3C,0xFF,0xFF,0x3C
G_DOOR:   DB    0x00,0xFF,0xFF,0x00

PACGFX: DB      0x41,0x55,0x55,0x14     ; up
        DB      0x14,0x55,0x55,0x41     ; down
        DB      0x14,0x05,0x05,0x14     ; left
        DB      0x14,0x50,0x50,0x14     ; right
        DB      0x14,0x55,0x55,0x14     ; closed mouth

GHGFX:  DB      0x3C,0xD7,0xFF,0xCC     ; ghost, feet frame 0
        DB      0x3C,0xD7,0xFF,0x33     ; ghost, feet frame 1
        DB      0x28,0x96,0xAA,0x88     ; frightened (blue)
        DB      0x14,0x7D,0x55,0x44     ; frightened, flashing

; maze, 32 x 14:  # wall  . dot  o power pellet  - ghost door
MAZEROM:
        DB "################################"
        DB "#o............................o#"
        DB "#.####.##################.####.#"
        DB "#.####.##################.####.#"
        DB "#..............  ..............#"
        DB "#.####.####.###--###.####.####.#"
        DB " ......####.##    ##.####...... "
        DB "#.####.####.########.####.####.#"
        DB "#..............  ..............#"
        DB "#.####.####.########.####.####.#"
        DB "#......####.########.####......#"
        DB "#.####.####.########.####.####.#"
        DB "#o............................o#"
        DB "################################"

; font for ASCII 0x20..0x5A, 5 bytes per glyph
FONT:
        DB 0x00,0x00,0x00,0x00,0x00          ; ' '
        DB 0x30,0x30,0x30,0x00,0x30          ; '!'
        DB 0x00,0x00,0x00,0x00,0x00          ; 'dq'
        DB 0x00,0x00,0x00,0x00,0x00          ; '#'
        DB 0x00,0x00,0x00,0x00,0x00          ; '$'
        DB 0x00,0x00,0x00,0x00,0x00          ; '%'
        DB 0x00,0x00,0x00,0x00,0x00          ; '&'
        DB 0x00,0x00,0x00,0x00,0x00          ; '''
        DB 0x00,0x00,0x00,0x00,0x00          ; '('
        DB 0x00,0x00,0x00,0x00,0x00          ; ')'
        DB 0x00,0x00,0x00,0x00,0x00          ; '*'
        DB 0x00,0x00,0x00,0x00,0x00          ; '+'
        DB 0x00,0x00,0x00,0x00,0x00          ; ','
        DB 0x00,0x00,0xFC,0x00,0x00          ; '-'
        DB 0x00,0x00,0x00,0x00,0x30          ; '.'
        DB 0x0C,0x0C,0x30,0xC0,0xC0          ; '/'
        DB 0xFC,0xCC,0xCC,0xCC,0xFC          ; '0'
        DB 0x30,0xF0,0x30,0x30,0xFC          ; '1'
        DB 0xFC,0x0C,0xFC,0xC0,0xFC          ; '2'
        DB 0xFC,0x0C,0xFC,0x0C,0xFC          ; '3'
        DB 0xCC,0xCC,0xFC,0x0C,0x0C          ; '4'
        DB 0xFC,0xC0,0xFC,0x0C,0xFC          ; '5'
        DB 0xFC,0xC0,0xFC,0xCC,0xFC          ; '6'
        DB 0xFC,0x0C,0x0C,0x0C,0x0C          ; '7'
        DB 0xFC,0xCC,0xFC,0xCC,0xFC          ; '8'
        DB 0xFC,0xCC,0xFC,0x0C,0xFC          ; '9'
        DB 0x00,0x30,0x00,0x30,0x00          ; ':'
        DB 0x00,0x00,0x00,0x00,0x00          ; ';'
        DB 0x00,0x00,0x00,0x00,0x00          ; '<'
        DB 0x00,0x00,0x00,0x00,0x00          ; '='
        DB 0x00,0x00,0x00,0x00,0x00          ; '>'
        DB 0x00,0x00,0x00,0x00,0x00          ; '?'
        DB 0x00,0x00,0x00,0x00,0x00          ; '@'
        DB 0x30,0xCC,0xFC,0xCC,0xCC          ; 'A'
        DB 0xF0,0xCC,0xF0,0xCC,0xF0          ; 'B'
        DB 0x3C,0xC0,0xC0,0xC0,0x3C          ; 'C'
        DB 0xF0,0xCC,0xCC,0xCC,0xF0          ; 'D'
        DB 0xFC,0xC0,0xF0,0xC0,0xFC          ; 'E'
        DB 0xFC,0xC0,0xF0,0xC0,0xC0          ; 'F'
        DB 0x3C,0xC0,0xCC,0xCC,0x3C          ; 'G'
        DB 0xCC,0xCC,0xFC,0xCC,0xCC          ; 'H'
        DB 0xFC,0x30,0x30,0x30,0xFC          ; 'I'
        DB 0x0C,0x0C,0x0C,0xCC,0x30          ; 'J'
        DB 0xCC,0xCC,0xF0,0xCC,0xCC          ; 'K'
        DB 0xC0,0xC0,0xC0,0xC0,0xFC          ; 'L'
        DB 0xCC,0xFC,0xFC,0xCC,0xCC          ; 'M'
        DB 0xF0,0xCC,0xCC,0xCC,0xCC          ; 'N'
        DB 0x30,0xCC,0xCC,0xCC,0x30          ; 'O'
        DB 0xF0,0xCC,0xF0,0xC0,0xC0          ; 'P'
        DB 0x30,0xCC,0xCC,0xFC,0x3C          ; 'Q'
        DB 0xF0,0xCC,0xF0,0xCC,0xCC          ; 'R'
        DB 0x3C,0xC0,0x30,0x0C,0xF0          ; 'S'
        DB 0xFC,0x30,0x30,0x30,0x30          ; 'T'
        DB 0xCC,0xCC,0xCC,0xCC,0xFC          ; 'U'
        DB 0xCC,0xCC,0xCC,0xCC,0x30          ; 'V'
        DB 0xCC,0xCC,0xFC,0xFC,0xCC          ; 'W'
        DB 0xCC,0xCC,0x30,0xCC,0xCC          ; 'X'
        DB 0xCC,0xCC,0x30,0x30,0x30          ; 'Y'
        DB 0xFC,0x0C,0x30,0xC0,0xFC          ; 'Z'

CODEEND:
        END
