NEBULUS - VZ300 conversion of the ZX Spectrum version
(J M Phillips / Hewson 1987)
=====================================================

Hardware: VZ300 + BennVenn SD loader with the 128K RAM expansion.
File:     NEBULUS.VZ  (single 23.7 KB file, no extra .DAT files needed)
          Load it from the SD card like any other .VZ program.

The original Spectrum game code runs unchanged; its system layer
(screen, sprites, tower blitter, text, keyboard, beeper) is replaced
with VZ routines. Game speed matches the Spectrum (~14.7 game frames/s).

TITLE SCREEN
  1 / 2      one or two players
  3 / 4      sound on / no sound
  FIRE       start (keyboard or either joystick)

ATTRACT MODE
  The brick towers either side of the title screen rotate while the
  title music plays. When the tune has played through (about 50 s) a
  demonstration game starts ("DEMO" blinks under the timer): Pogo
  climbs the whole of the Tower of Eyes, enters the exit door, the
  tower sinks into the sea, the bonus is tallied and the submarine
  carries him to the Realm of Robots. Then it returns to the title.
  Press any key or fire at any time to stop the demo. Your 1/2 player
  and sound choices are kept.

IN GAME
  Q / A      up (enter doors, use lifts) / down
  O / P      left / right (walk round the tower)
  SPACE or M fire (jump / snowball)
  CTRL+Q     quit to title
  Joystick 1 and joystick 2 both work, either arm button is fire.

DISPLAY
  Game: mode(1) 128x64, 4 colours, double-buffered and presented
  straight after the field sync, so no flicker or tearing.
  The Spectrum's checkerboard brick texture is kept as a red/yellow
  dither (an orange textured wall) instead of being scaled to mush.
  Each tower has its own scheme:
    1 Eyes, 5 Broken Path    - orange dithered bricks, yellow ledges
    2 Robots, 6 Swimmers     - yellow bricks, red ledges
    3 Tricks, 7 Nasty One    - orange dithered bricks, red ledges
    4 Slippery, 8 Doom       - red bricks, yellow ledges
  Text screens: mode(0) with a colour semigraphic NEBULUS logo,
  red/orange brick tower pillars, sea strips and a status panel.

SOUND
  Title/intermission music and all in-game effects (tones, sweeps,
  noise bursts) are converted to the VZ speaker, with loop timings
  matched to the Spectrum so pitch and tempo are unchanged.

HOW THE DEMO WAS MADE
  The game logic is deterministic, so the demo is just a recorded
  input stream (192 bytes, run-length coded) fed into the input
  routine. The route was found by an automated search in a VZ300
  emulator (snapshot/explore from every new height and rotation,
  keeping the shortest path that completes the tower) and verified to
  replay identically from power-on and after previous games.

CONTENTS
  NEBULUS.VZ                 the game - copy to the BennVenn SD card
  README.txt                 this file
  screenshots/               13 screen captures (768x576, 4:3)
  Nebulus_VZ300_source.zip   sources and build tools

SOURCE
  Nebulus_VZ300_source.zip - sjasmplus sources (src/), build tools
  (tools/build.py runs the whole pipeline: prep -> tables -> assemble
  -> ZX0 compress -> loader stub -> .VZ). Needs the original
  Spectrum 48K memory image (mem48.bin, from the tape) to rebuild.
