"""Phase 1: build every VZ graphic from the Spectrum data (2:1 across, 8:3 down)."""
import collections, glob, pickle, struct
from vzconv import *

EMU = '/home/claude/emu'
mir8 = [int('{:08b}'.format(i)[::-1], 2) for i in range(256)]

# ---------------------------------------------------------------- islands / tiles
def island_block(k):
    return open(f'{EMU}/tb{6 + 2 * k:02d}.bin', 'rb').read()


def island_chars(k):
    b = island_block(k)
    L = struct.unpack('<6H', b[0:12])
    g = b[0x91:0x91 + L[0]]
    return [list(g[i * 8:i * 8 + 8]) for i in range(len(g) // 8)], list(b[0x10:0x90]), b[0x90]


def char_rows(chars, c):
    rows = chars[c & 0x7f] if (c & 0x7f) < len(chars) else [0] * 8
    return [mir8[r] for r in rows] if c & 0x80 else list(rows)


def usage(k):
    """base char usage + attrs seen per island from the capture logs"""
    cnt = collections.Counter(); attrs = collections.defaultdict(collections.Counter)
    for f in glob.glob(f'{EMU}/cap/h{k}[0-3].txt'):
        cur = []
        for l in open(f):
            p = l.split(); pc = p[2]
            if pc == 'edb5':
                cur.append(int(p[3], 16))
            elif pc == 'ed9f':
                a = int(p[4][:2], 16)
                for c in cur:
                    cnt[c] += 1; attrs[c][a] += 1
                cur = []
            elif pc in ('eda7', 'ee25'):
                pass
    return cnt, attrs


def round_usage(k):
    res = []
    for f in sorted(glob.glob(f'{EMU}/cap/h{k}[0-3].txt')):
        c = collections.Counter()
        for l in open(f):
            p = l.split()
            if p[2] == 'edb5':
                c[int(p[3], 16)] += 1
        res.append(c)
    return res


SAMPLINGS = [(r, ox) for r in ((0, 3, 5), (1, 3, 6), (1, 4, 6), (2, 4, 7), (0, 3, 6), (1, 4, 7), (0, 2, 5), (2, 5, 7)) for ox in (0, 1)]


def sample_texture(rows, ink, paper, default):
    """pick the sampling that keeps the most two-colour detail for this tile (island default on ties)"""
    def bits(rs, ox):
        return [[(rows[ry] >> (7 - (2 * X + ox))) & 1 for X in range(4)] for ry in rs]
    def score(b):
        n = sum(map(sum, b))
        # balance, plus a bonus for structure (rows that differ from each other)
        return min(n, 12 - n) * 2 + len({tuple(r) for r in b})
    cands = [default] + [s for s in SAMPLINGS if s != default]
    best = max(cands, key=lambda s: (score(bits(*s)), s == default))
    return [[ink if v else paper for v in r] for r in bits(*best)]


def best_sampling(I):
    """one sampling phase per island, chosen so textured blocks keep the most two-colour detail"""
    tex = [c for c in I.cnt if (c & 0x7f) >= I.thr and (c & 0x7f) < len(I.chars) and 0.2 <= tile_density(char_rows(I.chars, c)) <= 0.9]
    best = None
    for rs, ox in SAMPLINGS:
        sc = 0
        for c in tex:
            rows = char_rows(I.chars, c)
            bits = [(rows[ry] >> (7 - (2 * X + ox))) & 1 for ry in rs for X in range(4)]
            n = sum(bits)
            sc += I.cnt[c] * min(n, 12 - n)
        if best is None or sc > best[0]:
            best = (sc, (rs, ox))
    return best[1]


def busy_set(k, I):
    """background wall chars: non-solid, textured, and mostly surrounded by other textured background"""
    tex = lambda c: (c & 0x7f) < I.thr and (c & 0x7f) < len(I.chars) and tile_density(char_rows(I.chars, c)) >= 0.12
    emb = collections.Counter(); n = collections.Counter()
    for f in sorted(glob.glob(f'{EMU}/cap/h{k}[0-3].txt')):
        grid = {}
        for l in open(f):
            p = l.split()
            if p[2] != 'edb5':
                continue
            c = int(p[3], 16); de = int(p[5], 16)
            grid[de] = c
            if not tex(c):
                continue
            n[c] += 1
            nb = [grid.get(de - 1), grid.get((de - 256) & 0xffff), grid.get((de - 257) & 0xffff)]
            if all(x is not None and tex(x) for x in nb):
                emb[c] += 1
    res = {c for c in n if n[c] >= 20 and emb[c] / n[c] >= 0.6}
    for rc in round_usage(k):
        tot = sum(rc.values()) or 1
        res |= {c for c, m in rc.items() if tex(c) and m / tot >= 0.02}
    res -= set(range(0x0a, 0x18))            # markers, goal sign and capsules are never toned
    res |= BUSY_EXTRA.get(k, set())
    return res


BUSY_EXTRA = {4: set(range(0x32, 0x36))}   # Doh's room wall pieces that are individually rare


DIGITS = {}


def digit_glyphs():
    """Spectrum height-marker digits: island 1 chars 0b,0c,0d are 1,2,3"""
    chars, _, _ = island_chars(0)
    return {1: chars[0x0b], 2: chars[0x0c], 3: chars[0x0d]}


def ham(a, b):
    return sum(bin(x ^ y).count('1') for x, y in zip(a, b))


class Island:
    def __init__(self, k):
        self.k = k
        self.chars, self.attr, self.thr = island_chars(k)
        self.cnt, self.attrs = usage(k)
        self.bgset = busy_set(k, self)
        self.sampling = best_sampling(self)
        # every island: char 0a = goal 'G', 0b-0d = height markers 1,2,3
        self.digits = {0x0a: 'G', 0x0b: 1, 0x0c: 2, 0x0d: 3}

    def kind(self, c):
        if (c & 0x7f) in self.digits:
            return 'digit'
        if (c & 0x7f) >= self.thr:
            return 'solid'
        if c in self.bgset or (c ^ 0x80) in self.bgset:
            return 'busy'
        return 'deco'

    def tile(self, c, attr=None):
        """VZ 4x3 colour pixels for base char c with Spectrum attribute attr"""
        if attr is None:
            attr = self.attrs[c].most_common(1)[0][0] if self.attrs[c] else self.attr[c & 0x7f]
        rows = char_rows(self.chars, c)
        ink = CM[attr & 7]; paper = CM[(attr >> 3) & 7]
        if ink == paper:
            ink = {BLUE: YELLOW, YELLOW: RED, RED: YELLOW, GREEN: YELLOW}[paper]
        kind = self.kind(c)
        dens = tile_density(rows)
        if kind == 'solid' and 0.2 <= dens <= 0.9:
            # textured platform block: show the Spectrum texture at its own pixel size
            # (point-sampled, one VZ pixel per Spectrum pixel) so bricks and rubble stay visible
            px = sample_texture(rows, ink, paper, self.sampling)
        else:
            px = tile_vz2(rows, ink, paper)
        if kind == 'busy':
            col = RED if ink == YELLOW else ink
            px = tone(px, col if paper == BLUE else RED, BLUE)
        elif kind == 'deco' and ink == YELLOW and paper == BLUE and (attr & 7) == 7 and tile_density(rows) >= 0.3:
            px = cloud(rows, px)
        return px


CLOUD_DITHER = [[YELLOW, GREEN, YELLOW, GREEN], [GREEN, YELLOW, GREEN, YELLOW], [YELLOW] * 4]


def cloud(rows, px):
    """soft yellow/green dither inside clouds; solid yellow rim"""
    def ink(x, y):
        if x < 0 or x > 7 or y < 0 or y > 7:   # outside the char: continue the nearest edge
            x = min(7, max(0, x)); y = min(7, max(0, y))
        return (rows[y] >> (7 - x)) & 1
    out = [list(r) for r in px]
    for Y in range(3):
        for X in range(4):
            if px[Y][X] != YELLOW:
                continue
            y0 = int(Y * 8 / 3) - 1; y1 = int((Y + 1) * 8 / 3 + 0.99) + 1
            inner = all(ink(x, y) for y in range(y0, y1) for x in range(2 * X - 1, 2 * X + 3))
            if inner:
                out[Y][X] = CLOUD_DITHER[Y][X]
    return out


# ---------------------------------------------------------------- overlays (rainbows, items)
RB_T = [[0, 1, 2, 3, 4, 0], [5, 15, 6, 7, 16, 8], [9, 10, 0, 0, 11, 12], [17, 13, 0, 0, 14, 18]]
RB_COL = [RED, YELLOW, GREEN]


def rainbow_colour(t, gx, gy):
    """outer->inner: red, yellow, blue, green; solid bands with hard borders like the Spectrum"""
    k = max(0, min(3, int(t * 4)))
    return (RED, YELLOW, BLUE, GREEN)[k]


def rainbow_arch(m):
    """48x32 Spectrum arch -> band mask + per pixel depth (0 outer .. 1 inner)"""
    P = [[0] * 48 for _ in range(32)]
    for r, row in enumerate(RB_T):
        for c, ch in enumerate(row):
            if ch:
                for y in range(8):
                    b = m[0xf700 + (ch - 1) * 8 + y]
                    for x in range(8):
                        P[r * 8 + y][c * 8 + x] = (b >> (7 - x)) & 1
    band = [[0] * 48 for _ in range(32)]
    for x in range(48):
        ys = [y for y in range(32) if P[y][x]]
        if ys:
            for y in range(min(ys), max(ys) + 1):
                band[y][x] = 1
    # outside = above the band (plus beyond the left/right edges); hollow = below the band
    outer = []; hollow = []
    for x in range(48):
        ys = [y for y in range(32) if band[y][x]]
        if not ys:
            continue
        outer += [(x, y) for y in range(min(ys))] + [(x, -1)]
        hollow += [(x, y) for y in range(max(ys) + 1, 32)]
    outer += [(-1, y) for y in range(32)] + [(48, y) for y in range(32)]
    depth = [[0.0] * 48 for _ in range(32)]
    for y in range(32):
        for x in range(48):
            if band[y][x]:
                do = min((x - a) ** 2 + (y - b) ** 2 for a, b in outer) ** 0.5
                di = min((x - a) ** 2 + (y - b) ** 2 for a, b in hollow) ** 0.5 if hollow else 9
                depth[y][x] = do / (do + di)
    return band, depth


# VZ rainbow drawn by hand: a round arch like the Spectrum's (circle of radius 24 Spectrum pixels) with four
# concentric bands, outer red .. inner green, reaching the bottom line. Left half; the right mirrors it.
# The empty corners (lines 0-2, columns 0-3) and the hollow (lines 6-11, columns 8-15) are the cells the
# Spectrum engine never draws for a rainbow.
RB_ART = [
    "..........rr",
    "......rrrryy",
    "....rrryyybb",
    "...rryybbbgg",
    "..rryybbgg..",
    ".rryybgg....",
    ".rrybbg.....",
    "rrybbg......",
    "rrybbg......",
    "rrybbg......",
    "rrybbg......",
    "rrybbg......",
]


def rainbow_chars(m):
    """VZ 4x3 pixels for each rainbow char 1..18 (opaque + masked use the same)"""
    band, depth = rainbow_arch(m)
    col = {'r': RED, 'y': YELLOW, 'b': BLUE, 'g': GREEN, '.': -1}
    full = [[col[ch] for ch in row + row[::-1]] for row in RB_ART]
    res = {}
    for r, row in enumerate(RB_T):
        for c, ch in enumerate(row):
            if ch:
                res[ch] = [[full[r * 3 + Y][c * 4 + X] for X in range(4)] for Y in range(3)]
            else:
                assert all(full[r * 3 + Y][c * 4 + X] < 0 for X in range(4) for Y in range(3))
    return res, band, depth


ITEM_GROUPS = list(range(0x17, 0xf0, 4))


def item_vz(m, first, attr):
    """2x2 overlay char group (16x16 line art) -> VZ 8x6: dense ink = item colour, thin lines = accent"""
    ink = [[0] * 16 for _ in range(16)]
    for i, (dx, dy) in enumerate(((0, 0), (8, 0), (0, 8), (8, 8))):
        a = 0xf700 + (first + i - 1) * 8
        for y in range(8):
            b = m[a + y]
            for x in range(8):
                ink[dy + y][dx + x] = (b >> (7 - x)) & 1
    A = CM[attr & 7]
    if A == BLUE:
        A = YELLOW
    B = RED if A != RED else YELLOW
    px = []
    for Y in range(6):
        row = []
        for X in range(8):
            tot = ik = 0.0; n = 0
            for x, y, w in cover(2 * X, 2 * X + 2, Y * 8 / 3, (Y + 1) * 8 / 3):
                tot += w; ik += w * ink[y][x]; n += ink[y][x]
            f = ik / tot
            row.append(A if f >= 0.35 else (B if n >= 1 else -1))
        px.append(row)
    return px, ink


# ---------------------------------------------------------------- sprites
SPR_SCHEME = {None: (YELLOW, RED), 0: (YELLOW, RED), 1: (YELLOW, GREEN), 2: (YELLOW, RED), 3: (YELLOW, RED),
              4: (YELLOW, RED), 5: (YELLOW, RED), 6: (GREEN, YELLOW)}


def bub_like(img):
    return len(img[0]) >= 22


def sprite_conv(isl, img, boss=False):
    mask = [list(r) for r in img[0]]; ink = [list(r) for r in img[1]]
    A, C = SPR_SCHEME[isl]
    if len(mask) >= 36:     # bosses: big line-art, keep them light
        return sprite_vz2(mask, ink, A=A, B=C, C=BLUE, mode='v3', k=0.6, hi=0.5, lo=0.18)
    px = sprite_vz2(mask, ink, A=A, B=C, C=C, mode='v2', k=0.9)
    if isl is None and len(mask) >= 22:          # the player: green hair, red clothes
        H = len(px); cut = max(1, int(H * 0.38))
        px = [[(GREEN if (c == RED and y < cut) else c) for c in r] for y, r in enumerate(px)]
    return px
