# Hand-tuned VZ player frames (9x8, facing right), drawn from the Spectrum originals.
# G green hair, Y skin/yellow, R red clothes, B blue detail, . transparent
BUB = [
["..GGGGG..",".GGGGGGG.",".GGYYYBY.",".GYYYYYY.","..YYYYY..",".RRRRRRR.",".YRRRRRY.","..RR.RR.."],
["..GGGGG..",".GGGGGGG.",".GGYYYBY.",".GYYYYYY.","..YYYYY..","..RRRRRY.",".YRRRRR..","..RR..RR."],
["..GGGGG..",".GGGGGGG.",".GGYYYBY.",".GYYYYYY.","..YYYYY..","..RRRRR..","..YRRRY..","...RRR..."],
["..GGGGG..",".GGGGGGG.",".GGYYYBY.",".GYYYYYY.","..YYYYY..",".YRRRRR..","..RRRRRY.",".RR..RR.."],
["..GGGGG..",".GGGGGGG.",".GGYYYBY.",".GYYYYYY.","..YYYYYYY","..RRRRR..","..RRRRR..","..RR.RR.."],
[".G.GGG.G.",".GGGGGGG.",".GYBYBYG.",".GYYYYYG.","..YYRYY..",".YRRRRRY.","..RRRRR..","..RR.RR.."],
["....Y.Y..",".....Y...",".........","..GGG....",".GGGYYY..",".GGYYYRR.","..YYRRRRY","...RRRRR."],
]
CODE={'G':0,'Y':1,'B':2,'R':3,'.':-1}
def frames():
    return [[[CODE[c] for c in row] for row in f] for f in BUB]
