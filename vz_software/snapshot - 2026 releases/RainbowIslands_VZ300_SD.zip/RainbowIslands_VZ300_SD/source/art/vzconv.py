"""Phase 1 converters: Spectrum 1bpp art -> VZ300 mode(1) CSS0, 2:1 across, 8:3 down.
VZ colours (CSS0): 0 green, 1 yellow, 2 blue, 3 red.  -1 = transparent."""
from PIL import Image

VZPAL = [(0, 224, 0), (224, 224, 0), (0, 0, 224), (224, 0, 0)]
SPAL = [(0, 0, 0), (0, 0, 205), (205, 0, 0), (205, 0, 205), (0, 205, 0), (0, 205, 205), (205, 205, 0), (205, 205, 205)]
GREEN, YELLOW, BLUE, RED = 0, 1, 2, 3
# Spectrum colour -> VZ colour
CM = {0: BLUE, 1: BLUE, 2: RED, 3: RED, 4: GREEN, 5: GREEN, 6: YELLOW, 7: YELLOW}


def cover(x0, x1, y0, y1):
    """source pixels overlapping a VZ pixel with overlap weights"""
    out = []
    for y in range(int(y0), int(y1 + 0.9999)):
        oy = min(y + 1, y1) - max(y, y0)
        if oy <= 0:
            continue
        for x in range(int(x0), int(x1 + 0.9999)):
            ox = min(x + 1, x1) - max(x, x0)
            if ox > 0:
                out.append((x, y, ox * oy))
    return out


def vz_rows(h, phase=0):
    """number of VZ lines a Spectrum object of height h covers (8:3)"""
    return (3 * (h + phase) + 7) // 8


def sprite_vz(mask, ink, A=YELLOW, B=RED, C=BLUE, phase=0):
    """mask/ink: lists of rows (1 = opaque / ink). Returns VZ pixel rows (-1 transparent).
    A = main ink colour, B = secondary colour for isolated detail, C = opaque paper (fill)."""
    H = len(mask); W = len(mask[0])
    VW = (W + 1) // 2; VH = vz_rows(H, phase)
    out = []
    for Y in range(VH):
        y0 = Y * 8 / 3 - phase; y1 = (Y + 1) * 8 / 3 - phase
        row = []
        for X in range(VW):
            tot = op = ik = 0.0; nik = 0
            for x, y, wgt in cover(2 * X, 2 * X + 2, y0, y1):
                if 0 <= y < H and 0 <= x < W:
                    tot += wgt
                    o = mask[y][x] or ink[y][x]
                    op += wgt * o
                    if ink[y][x]:
                        ik += wgt; nik += 1
                else:
                    tot += wgt
            area = 2 * 8 / 3
            if op < 0.38 * area:
                row.append(-1)
            elif ik >= 0.30 * area or nik >= 2:
                row.append(A)
            elif nik == 1:
                row.append(B)
            else:
                row.append(C)
        out.append(row)
    return out


def tile_vz(rows, ink, paper, thr=0.42):
    """8x8 char (list of 8 bytes) -> 4x3 VZ colours, area weighted"""
    out = []
    for Y in range(3):
        y0 = Y * 8 / 3; y1 = (Y + 1) * 8 / 3
        line = []
        for X in range(4):
            tot = ik = 0.0
            for x, y, wgt in cover(2 * X, 2 * X + 2, y0, y1):
                tot += wgt; ik += wgt * ((rows[y] >> (7 - x)) & 1)
            line.append(ink if ik / tot >= thr else paper)
        out.append(line)
    return out


def tile_density(rows):
    return sum(bin(b).count('1') for b in rows) / 64


def tone(px, colour=RED, bg=BLUE):
    """busy background wall: keep its structure as a sparse checkerboard"""
    return [[(colour if (c != bg and (x + y) % 2 == 0) else bg) for x, c in enumerate(r)] for y, r in enumerate(px)]


def soften_cloud(px, edge=YELLOW, fill=(YELLOW, GREEN), bg=BLUE, row0=0):
    """yellow cloud interiors dithered yellow/green; edges stay yellow"""
    H = len(px); W = len(px[0]); out = []
    for y in range(H):
        r = []
        for x in range(W):
            c = px[y][x]
            if c == edge:
                nb = [px[yy][xx] for yy, xx in ((y - 1, x), (y + 1, x), (y, x - 1), (y, x + 1)) if 0 <= yy < H and 0 <= xx < W]
                interior = len(nb) == 4 and all(n != bg for n in nb)
                if interior:
                    c = fill[(x + y + row0) % 2]
            r.append(c)
        out.append(r)
    return out


def img_vz(px, sx=4, sy=6, bg=(40, 40, 40)):
    H = len(px); W = len(px[0]) if H else 0
    im = Image.new('RGB', (max(1, W * sx), max(1, H * sy)), bg)
    for y, r in enumerate(px):
        for x, c in enumerate(r):
            if c >= 0:
                im.paste(VZPAL[c], (x * sx, y * sy, (x + 1) * sx, (y + 1) * sy))
    return im


def img_spec_sprite(mask, ink, s=2, inkc=(230, 230, 230), paper=(0, 0, 150), bg=(40, 40, 40)):
    H = len(mask); W = len(mask[0])
    im = Image.new('RGB', (W * s, H * s), bg)
    for y in range(H):
        for x in range(W):
            c = inkc if ink[y][x] else (paper if mask[y][x] else None)
            if c:
                im.paste(c, (x * s, y * s, (x + 1) * s, (y + 1) * s))
    return im


def sprite_fields(mask, ink, phase=0):
    """per VZ pixel: (opaque fraction, ink fraction of opaque area)"""
    H = len(mask); W = len(mask[0])
    VW = (W + 1) // 2; VH = vz_rows(H, phase)
    O = []; I = []
    for Y in range(VH):
        y0 = Y * 8 / 3 - phase; y1 = (Y + 1) * 8 / 3 - phase
        orow = []; irow = []
        for X in range(VW):
            tot = op = ik = 0.0
            for x, y, wgt in cover(2 * X, 2 * X + 2, y0, y1):
                tot += wgt
                if 0 <= y < H and 0 <= x < W:
                    o = mask[y][x] or ink[y][x]
                    op += wgt * o; ik += wgt * ink[y][x]
            orow.append(op / tot); irow.append(ik / op if op else 0)
        O.append(orow); I.append(irow)
    return O, I


def sprite_vz2(mask, ink, A=YELLOW, B=RED, C=BLUE, mode='v3', k=0.9, hi=0.62, lo=0.30, othr=0.40, phase=0):
    O, I = sprite_fields(mask, ink, phase)
    H = len(O); W = len(O[0]); out = []
    for y in range(H):
        row = []
        for x in range(W):
            if O[y][x] < othr:
                row.append(-1); continue
            f = I[y][x]
            nb = [I[yy][xx] for yy in (y - 1, y, y + 1) for xx in (x - 1, x, x + 1)
                  if 0 <= yy < H and 0 <= xx < W and O[yy][xx] >= othr]
            mean = sum(nb) / len(nb)
            if mode == 'v1':
                c = A if f >= 0.55 else (B if f >= 0.25 else C)
            elif mode == 'v2':
                g = f + k * (f - mean)
                c = A if g >= 0.5 else C
            else:
                g = f + k * (f - mean)
                c = A if g >= hi else (B if g >= lo else C)
            row.append(c)
        out.append(row)
    return out


def tile_fields(rows):
    F = []
    for Y in range(3):
        y0 = Y * 8 / 3; y1 = (Y + 1) * 8 / 3; line = []
        for X in range(4):
            tot = ik = 0.0
            for x, y, wgt in cover(2 * X, 2 * X + 2, y0, y1):
                tot += wgt; ik += wgt * ((rows[y] >> (7 - x)) & 1)
            line.append(ik / tot)
        F.append(line)
    return F


def tile_vz2(rows, ink, paper, k=0.8, wrap=True):
    """contrast-enhanced 4x3: thin lines survive as the minority colour"""
    F = tile_fields(rows)
    out = []
    for y in range(3):
        line = []
        for x in range(4):
            nb = []
            for yy in (y - 1, y, y + 1):
                for xx in (x - 1, x, x + 1):
                    if wrap:
                        nb.append(F[yy % 3][xx % 4])
                    elif 0 <= yy < 3 and 0 <= xx < 4:
                        nb.append(F[yy][xx])
            mean = sum(nb) / len(nb)
            g = F[y][x] + k * (F[y][x] - mean)
            line.append(ink if g >= 0.5 else paper)
        out.append(line)
    return out
