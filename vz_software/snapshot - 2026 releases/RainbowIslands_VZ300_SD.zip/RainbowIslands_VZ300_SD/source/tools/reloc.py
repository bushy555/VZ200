"""Relocate Spectrum 6800-77FF by offset D; returns patched 64K image and the patch list."""
import pickle,sys
sys.path.insert(0,'/home/claude/tools')
from z80dis import dis
LO,HI=0x6791,0x7800
code,w16,hi8=pickle.load(open('/home/claude/p2/refs2.pkl','rb'))
def valid(a): return 0x5b00<=a<0x97c0 or a>=0xb800
# 8-bit page operands (curated: these compute addresses in the 71xx-77xx buffers)
W16_SKIP={0x639c}   # data list misread as code
HI8_SKIP={0x8031,0xeef9,0xef0a,0x5f30,0xcbbc,0xcbf2,0xeb26}
# data words holding addresses inside the block (curated, verified dynamically)
DATA16=[0x63a4,0x63a6,0x63a8,0x63aa]
def patches():
    P=[]
    for a,t in w16:
        if not valid(a) or a in W16_SKIP: continue
        l,tt,ref=code[a]
        P.append(('w16',a,l,ref[1]))
    for a,t in hi8:
        if not valid(a) or a in HI8_SKIP: continue
        P.append(('hi8',a,code[a][0],None))
    for a in DATA16: P.append(('d16',a,2,None))
    return P
def relocate(img,D,extra16=(),extra8=(),stub=None):
    m=bytearray(img)
    blk=bytes(img[LO:HI])
    P=patches()+[('d16',a,2,None) for a in extra16]+[('d8',a,1,None) for a in extra8]
    done=[]
    for kind,a,l,val in P:
        if kind=='w16':
            ins=img[a:a+l]
            for i in range(l-1):
                if ins[i]|ins[i+1]<<8==val:
                    off=a+i; break
            else: raise Exception('no operand %04x'%a)
            nv=val+D; m[off]=nv&255; m[off+1]=nv>>8; done.append(off)
        elif kind=='hi8':
            off=a+l-1; m[off]=(img[off]+(D>>8))&255; done.append(off)
        elif kind=='d16':
            v=img[a]|img[a+1]<<8; assert LO<=v<HI,(hex(a),hex(v))
            v+=D; m[a]=v&255; m[a+1]=v>>8; done.append(a)
        elif kind=='d8':
            m[a]=(img[a]+(D>>8))&255; done.append(a)
    # move block: patched bytes inside the block move with it
    moved=bytes(m[LO:HI])
    for i in range(LO,HI): m[i]=0
    for i,b in enumerate(moved): m[(LO+D+i)&0xffff]=b
    if stub is not None:
        # e4e0 leaves HL = boss-energy pointer (6B5B); df79 then uses HL as coordinates.
        # Give it back its original numeric value so collision behaves exactly as on the Spectrum.
        rh=(0x6b+(D>>8))&255
        code=[0xcd,0xe0,0xe4, 0xf5, 0x7c, 0xfe,rh, 0x20,6, 0x7d, 0xfe,0x5b, 0x20,2, 0x26,0x6b, 0xf1, 0xc9]
        for i,b in enumerate(code): m[stub+i]=b
        m[0xdf39]=stub&255; m[0xdf3a]=stub>>8          # call e4e0 -> call stub
        m[0xdf91]=stub&255; m[0xdf92]=stub>>8          # jp e4e0 -> jp stub
        done.append(stub)
    return bytes(m),done
