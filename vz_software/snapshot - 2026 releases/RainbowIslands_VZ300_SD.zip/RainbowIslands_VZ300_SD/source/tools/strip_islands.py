import struct,subprocess,os,collections
ISL={'cv01':0,'cv11':1,'cv21':2,'cv31':3,'cv41':4,'cv51':5,'cv61':6}
def zx0(data,name):
    p='/tmp/claude-0/z_%s.bin'%name; open(p,'wb').write(bytes(data))
    subprocess.run(['zx0','-f',p,p+'.zx0'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    return os.path.getsize(p+'.zx0')
def strip(k,n):
    blk=bytearray(open('/home/claude/emu/tb%02d.bin'%(6+2*k),'rb').read())
    ini=struct.unpack('<65536H',open('/home/claude/p2/rm/%s_init.bin'%n,'rb').read())
    L=[blk[2*i]|blk[2*i+1]<<8 for i in range(6)]
    s0=0x91; secend=s0+sum(L)
    for i in range(s0,s0+L[0]): blk[i]=0
    why=collections.Counter()
    for i in range(secend,len(blk)):
        a=0x97c0+i
        if a<0x9f00: why['overlap-kept']+=1; continue
        if ini[a] in (0x6f31,0): blk[i]=0; why['zero']+=1
        else: why['%04x'%ini[a]]+=1
    return blk,L,why
if __name__=='__main__':
    tot=0
    for n,k in ISL.items():
        blk,L,why=strip(k,n)
        orig=zx0(open('/home/claude/emu/tb%02d.bin'%(6+2*k),'rb').read(),'o%d'%k); z=zx0(blk,'s%d'%k); tot+=z
        print(k,'orig zx0',orig,'stripped',z,dict(why))
    print('total',tot)
