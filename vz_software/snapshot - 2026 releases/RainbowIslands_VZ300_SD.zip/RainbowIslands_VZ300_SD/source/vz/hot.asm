; =====================================================================================
;  Rainbow Islands VZ300 - "hot" code in DOS RAM bank 1 (4000-4790), always mapped.
;  These routines replace only the Spectrum's hardware-dependent and screen-drawing
;  routines. All game logic is the original Spectrum code (see build.py patch list).
; =====================================================================================
        INCLUDE "defs.inc"
        INCLUDE "filedefs.inc"
        INCLUDE "ex0syms.inc"
B1_DISPLAY  equ 0xb800
B1_INSTALL  equ 0xb803
B1_LOADISL  equ 0xb806
B1_TITLE    equ 0xb809
B1_PORTRAIT equ 0xb80c
B1_ENDPIC   equ 0xb80f
B1_MUSIC    equ 0xb812
B1_PREPLOAD equ 0xb815
TICKS       equ 2           ; interrupts counted between game frames (+1 missed while it runs)

        org 0x4000
; ---- entry from the loader stub -----------------------------------------------------
vzboot: di
        ld sp,0xfdfd
        ld a,MAP_E0
        out (MAPPORT),a
        ld a,LATCH_M1
        ld (latchv),a
        ld (LATCH),a
        ld hl,VRAM              ; blue screen while the engine starts
        ld de,VRAM+1
        ld bc,0x7ff
        ld (hl),0xaa
        ldir
        call detect_joy
        xor a
        ld (V_128K),a           ; 48K machine: no AY, no paging
        call SP_MIRROR          ; original init: bit-mirror table F500
        call SP_MULTAB          ; original init: table at FD00
        ld hl,0xb800            ; IM2 vector table, as the original
        ld de,0xb801
        ld (hl),0xfd
        ld bc,0x0100
        ldir
        ld a,0xc3
        ld (0xfdfd),a
        ld hl,vzint
        ld (0xfdfe),hl
        ld a,0xb8
        ld i,a
        im 2
        ld a,0xff
        ld (LASTTOP),a
        ld (V_ISLAND),a         ; nothing loaded yet: first round loads island 1
        ld hl,TEXTGRID
        ld de,TEXTGRID+1
        ld (hl),' '
        ld bc,767
        ldir
        ld ix,SP_HUDTXT
        call SP_5F47            ; "1UP  HI SCORE" as the original boot did
        jp SP_MAIN

; ---- 50Hz interrupt (6847 FS, level) -> original game frame every few fields -------------
vzint:  push af
.w:     ld a,(LATCH)            ; wait for the end of field sync: one count per field
        rla
        jr nc,.w
        ld a,(vzticks)
        inc a
        cp TICKS
        jr nc,.run
        ld (vzticks),a
        pop af
        ei
        ret
.run:   xor a
        ld (vzticks),a
        pop af
        jp SP_FRAME             ; original handler; ends with EI : RET

; ---- title: the original title loop (5C92) with its first page replaced by the VZ screen ----
vz_title:
        ld a,MAP_E1             ; the title tune (8000) was overwritten by island data: put it back
        out (MAPPORT),a
        call B1_MUSIC
        ld a,MAP_E0
        out (MAPPORT),a
        xor a
        ld (0x5c8f),a           ; and let the title play it again
        ld a,(V_CREDITS)        ; one credit waiting, so fire starts a game
        or a                    ; (RETURN adds more, as ENTER did)
        jr nz,$+7
        ld a,1
        ld (V_CREDITS),a
        call SP_5C92            ; credits, hi-score table, music, coin and start: all original
        jp mode1                ; back to the game screen

vz_titlepage:                   ; replaces "ld ix,6124 / ld bc,010F / call 5CDE" at 5CB1
        ld a,MAP_E1
        out (MAPPORT),a
        call B1_TITLE           ; compose the animation frames, show frame 0
        ld a,MAP_E0
        out (MAPPORT),a
        ld a,0xfd               ; the frames used the island's RAM: reload it later
        ld (V_ISLAND),a
        ld a,(latchv)
        and 0xff-LATCH_M1
        ld (latchv),a
        ld (LATCH),a
        xor a
        ld (tunits),a
        inc a
        ld (tmode),a            ; the music and the waits now animate the logo
        ld bc,0x010f
        jp SP_5CEA              ; the original wait: coin, start, timeout

mode1:  ; leave the MODE(0) title: blue screen, HUD scores redrawn, full playfield redraw
        push af
        ld a,(latchv)
        and LATCH_M1
        jr nz,.x
        push bc
        push de
        push hl
        xor a
        ld (tmode),a            ; title animation off
        ld a,(latchv)
        or LATCH_M1
        ld (latchv),a
        ld (LATCH),a
        ld hl,VRAM
        ld de,VRAM+1
        ld bc,0x7ff
        ld (hl),0xaa
        ldir
        ld a,0xff
        ld (LASTTOP),a
        ld hl,(V_TXTCOL)        ; HUD row 1 (scores) from the text grid
        push hl
        ld hl,0x0100
.h:     ld (V_TXTCOL),hl
        push hl
        call txtad
        ld a,(hl)
        cp ' '
        call nz,scrglyph
        pop hl
        inc l
        bit 5,l
        jr z,.h
        pop hl
        ld (V_TXTCOL),hl
        pop hl
        pop de
        pop bc
.x:     pop af
        ret

; ---- island intro (5DDF): the original names the island; add its boss, then its pause ----
vz_islintro:
        ld a,(V_ISLAND)
        ld (v_isl),a
        ld a,MAP_E1
        out (MAPPORT),a
        call B1_PORTRAIT
        ld a,MAP_E0
        out (MAPPORT),a
        ld a,3
        jp SP_5BCC

; ---- ending (block 7 at 97C0, code A130): its screen routines, VZ versions -------------
vz_endpic:                      ; A66C: the big rainbow picture
        call vz_cls_play
        ld a,MAP_E1
        out (MAPPORT),a
        call B1_ENDPIC
        ld a,MAP_E0
        out (MAPPORT),a
        ret
vz_endfade:                     ; A601: fade out and clear
        ld bc,0x6000
        call SP_5BC6
        jp vz_cls_play

; ---- new game: the original set-up, then this file's first island ----------------------
vz_newgame:
        call SP_6375
        ld a,FIRSTISL*4
        ld (V_ROUND),a
        ret

; ---- title music (8000): the Spectrum's beeper toggles, to the VZ speaker -----------------
vzspk:  xor 0x10                ; replaces "xor 10h / out (FEh),a"
vzspkw: push af
        and 0x10
        ld a,(latchv)
        jr z,.lo
        or 0x20
        jr .w
.lo:    or 0x01
.w:     ld (LATCH),a
        pop af
        ret
vzspkoff:                       ; replaces "xor a / out (FEh),a"
        xor a
        jr vzspkw

; ---- round set-up: original 63B0, then the VZ tables for the island --------------------
vz_round:
        call SP_63B0
vz_install:
        ld a,(V_ISLAND)
        ld (v_isl),a
        ld a,MAP_E1
        out (MAPPORT),a
        call B1_INSTALL
        ld a,MAP_E0
        out (MAPPORT),a
        ret

; ---- island loader (replaces the tape loader at 6FFA): A = island 0..6, 7 = ending ---------
; Like the Spectrum loading an island from tape, the VZ loads it from the SD card:
; file RISLANDn.DAT (VZ art + packed island block) or RIENDING.DAT.
vz_island:
        ld (v_isl),a
        cp 7                    ; the ending overwrites the island data:
        jr nz,.n                ; make the next game load its island again
        ld a,0xfd
        ld (V_ISLAND),a
.n:     ld a,i                  ; interrupts off while the DOS works
        push af
        di
.try:   ld a,MAP_E1
        out (MAPPORT),a
        call B1_PREPLOAD        ; loader + file name + destinations -> VRAM
        ld a,MAP_E0             ; (the return address must go on the engine's stack)
        out (MAPPORT),a
        call LDR                ; read the file (DOS ROM in while it runs)
        or a                    ; (no push/pop here: the stack is in the banked area)
        jr nz,.err
        ld a,MAP_E1
        out (MAPPORT),a
        call B1_LOADISL         ; unpack the art and the island block
        ld a,MAP_E0
        out (MAPPORT),a
        call scrback
        pop af
        ret po
        ei
        ret
.err:   ld a,MAP_E0
        out (MAPPORT),a
        call scrback
        call SP_5DF3            ; clear the play area
        ld ix,sderrtxt
        call SP_5F47
.w1:    call vzinput            ; fire to try again
        and 0x18
        jr nz,.w1
.w2:    call vzinput
        and 0x18
        jr z,.w2
        jr .try
sderrtxt:
        db 0xc2,0x46, 0xc1,5,8, "CAN'T READ THE SD CARD"
        db 0xc2,0x47, 0xc1,3,11, "RISLAND1-7.DAT, RIENDING.DAT"
        db 0xc1,4,13, "MUST BE NEXT TO RAINBOW.VZ"
        db 0xc2,0x45, 0xc1,5,17, "FIRE TO TRY AGAIN"
        db 0xc0

scrback: ; the loader used VRAM: blue screen, scores, full redraw next frame
        ld a,(latchv)
        and 0xff-LATCH_M1       ; (mode1 redraws when it sees MODE(0))
        ld (latchv),a
        jp mode1

; ---- display (replaces E5E3) ------------------------------------------------------------
vz_display:
        ld a,(V_BE8E)
        ld (v_be8e),a
        ld a,(V_BE7E)
        ld (v_be7e),a
        ld a,(V_ISLAND)
        ld (v_isl),a
        ld a,(0xe5e2)           ; water line (the original display drew the rising water)
        ld (v_water),a
        ld a,MAP_E1
        out (MAPPORT),a
        call B1_DISPLAY
        ld a,MAP_E0
        out (MAPPORT),a
        xor a
        ld (SPRCNT),a
        ld (vzticks),a          ; next game frame after two more fields
        ret

; ---- input (replaces B90E key/joystick reading) -> A: b0 R, b1 L, b2 D, b3 U, b4 FIRE ----
vzinput:
        ld c,0
        ld a,(0x68fb)           ; V Z C SHIFT X B
        bit 4,a
        jr nz,$+4
        set 1,c                 ; Z = left
        bit 1,a
        jr nz,$+4
        set 0,c                 ; X = right
        ld a,(0x68ef)           ; M SPACE , . N
        bit 5,a
        jr nz,$+4
        set 3,c                 ; M = jump
        bit 4,a
        jr nz,$+4
        set 4,c                 ; SPACE = rainbow
        bit 3,a
        jr nz,$+4
        set 1,c                 ; , = left
        bit 1,a
        jr nz,$+4
        set 0,c                 ; . = right
        ld a,(0x68fe)           ; Q
        bit 4,a
        jr nz,$+4
        set 3,c
        ld a,(0x68fd)           ; A = down
        bit 4,a
        jr nz,$+4
        set 2,c
        ld a,(joyok)
        or a
        jr z,.nojoy
        in a,(0x2c)             ; J1 directions (arm-select line low)
        ld b,a
        in a,(0x29)             ; J2 directions
        and b
        ld b,a
        and 0x0c
        jr z,.nodir             ; left+right together = no interface noise
        bit 0,b
        jr nz,$+4
        set 3,c
        bit 1,b
        jr nz,$+4
        set 2,c
        bit 2,b
        jr nz,$+4
        set 1,c
        bit 3,b
        jr nz,$+4
        set 0,c
.nodir: in a,(0x2e)             ; fire
        ld b,a
        in a,(0x2b)
        and b
        bit 4,a
        jr nz,$+4
        set 4,c
        in a,(0x2d)             ; arm buttons = jump
        ld b,a
        in a,(0x27)
        and b
        bit 4,a
        jr nz,$+4
        set 3,c
.nojoy: ld a,c
        ret

detect_joy:
        ld b,8
        ld c,0
.l:     in a,(0x2c)
        and 0x0f
        call .bad
        in a,(0x29)
        and 0x0f
        call .bad
        djnz .l
        ld a,c
        or a
        ld a,1
        jr z,.ok
        xor a
.ok:    ld (joyok),a
        ret
.bad:   ld e,a
        and 0x0c
        jr z,.b1
        ld a,e
        and 0x03
        ret nz
.b1:    inc c
        ret

; ---- Spectrum keyboard rows used outside play: P pause, Q quit, S sound, ENTER coin ----
vzkey_df: ld a,0xdf
        jr vzkey
vzkey_fb: ld a,0xfb
        jr vzkey
vzkey_fd: ld a,0xfd
        jr vzkey
vzkey_bf: ld a,0xbf
        jr vzkey
vzkey_all:
        ld a,(0x6800)           ; every VZ row at once
        or 0xc0
        cp 0xff
        ld a,0xff
        ret z
        ld a,0xfe               ; something pressed
        ret
vzkey:  push bc
        push hl
        ld c,a                  ; Spectrum row select (active low)
        ld b,0xff               ; result
        ld hl,keymap
.k:     ld a,(hl)
        or a
        jr z,.done
        and c                   ; row selected? (bit low in C)
        inc hl
        jr nz,.n1
        push hl
        ld a,(hl)               ; VZ row address low byte
        ld l,a
        ld h,0x68
        ld a,(hl)
        pop hl
        inc hl
        and (hl)                ; VZ key bit
        jr nz,.n2
        inc hl
        ld a,(hl)               ; Spectrum bit to clear
        cpl
        and b
        ld b,a
        inc hl
        jr .k
.n1:    inc hl
.n2:    inc hl
        inc hl
        jr .k
.done:  ld a,b
        pop hl
        pop bc
        ret
keymap: ; Spectrum row bit, VZ row address, VZ bit, Spectrum key bit
        db 0x20, 0xbf, 0x10, 0x01   ; P      (DF row) <- VZ P
        db 0x04, 0xfe, 0x10, 0x01   ; Q      (FB row) <- VZ Q
        db 0x02, 0xfd, 0x02, 0x02   ; S      (FD row) <- VZ S
        db 0x40, 0xbf, 0x04, 0x01   ; ENTER  (BF row) <- VZ RETURN
        db 0

; ---- beeper (replaces F1D0-F1DF: 8 cycles of a square wave, half period H) -----------
vzbeep: ld a,(latchv)
        or 0x20
        ld (LATCH),a
        ld b,h
.d1:    djnz .d1
        ld a,(latchv)
        or 0x01
        ld (LATCH),a
        ld b,h
.d2:    djnz .d2
        dec l
        jr nz,vzbeep
        jp SP_F1E0

; ---- tile leaves: the engine's own cell drawing, redirected to VZ tiles ----------------
; in: A = char, DE = Spectrum back-buffer cell (9F00 + row*256 + col); out: DE kept, JP (IY)
cellad: ; HL = VZBUF + row*96 + col  (uses A); marks the row dirty
        ld a,d
        sub 0x9f
        ld l,a
        ld h,high DIRTY
        ld (hl),h
        add a,a
        add a,low rowtab
        ld l,a
        ld h,high rowtab
        ld a,(hl)
        inc l
        ld h,(hl)
        add a,e                 ; col (0..31) - E bits 5-7 are always 0 at a leaf
        ld l,a
        ret nc
        inc h
        ret
vz_leaf_base:
        push bc
        ld l,a
        ld h,0
        ld b,h
        ld c,l
        add hl,hl
        add hl,bc
        ld bc,BASETAB
        add hl,bc
        jr leafcopy
vz_leaf_ovl:
        push bc
        ld l,a
        ld h,0
        ld b,h
        ld c,l
        add hl,hl
        add hl,bc
        ld bc,OVLTAB
        add hl,bc
leafcopy:
        push hl
        call cellad
        pop bc                  ; BC = 3 tile bytes
        ld a,(bc)
        ld (hl),a
        inc bc
        ld a,l
        add a,32
        ld l,a
        jr nc,$+3
        inc h
        ld a,(bc)
        ld (hl),a
        inc bc
        ld a,l
        add a,32
        ld l,a
        jr nc,$+3
        inc h
        ld a,(bc)
        ld (hl),a
        pop bc
        jp (iy)
vz_leaf_mask:
        push bc
        ld l,a
        ld h,0
        add hl,hl
        ld b,h
        ld c,l
        add hl,hl
        add hl,bc               ; *6
        ld bc,MASKTAB
        add hl,bc
        push hl
        call cellad
        pop bc                  ; BC -> gfx0,mask0,gfx1,mask1,gfx2,mask2
        call .one
        call .one
        call .one
        pop bc
        jp (iy)
.one:   inc bc
        ld a,(bc)               ; mask
        and (hl)
        dec bc
        push hl
        ld h,b
        ld l,c
        or (hl)                 ; gfx
        pop hl
        ld (hl),a
        inc bc
        inc bc
        ld a,l
        add a,32
        ld l,a
        ret nc
        inc h
        ret

; ---- sprites: note what the engine draws this frame (hook at D4D8, DE = graphic) -------
vz_sprhook:
        push af
        push hl
        push de
        ld a,(SPRCNT)
        cp NSPR
        jr nc,.full
        inc a
        ld (SPRCNT),a
        dec a
        add a,a
        add a,a
        add a,low SPRLIST
        ld l,a
        ld h,high SPRLIST
        ld (hl),e
        inc l
        ld (hl),d
        inc l
        push ix
        pop de
        ld (hl),e
        inc l
        ld (hl),d
.full:  pop de
        pop hl
        pop af
        exx                     ; as the original at D4D8 ...
        ret                     ; ... but skip building Spectrum screen records (VZ draws its own)

; ---- text: the engine prints into a 32x24 text grid, drawn by the VZ display -----------
vz_print:                       ; replaces 608F: A = character
        push hl
        push de
        call txtad
        ld (hl),a
        call scrglyph
        ld hl,V_TXTCOL
        inc (hl)
        pop de
        pop hl
        ret
vz_printbig:                    ; replaces 60B0 (double size): keep the character
        push hl
        push de
        call txtad
        ld (hl),a
        call scrglyph
        ld hl,V_TXTCOL
        inc (hl)
        inc (hl)
        pop de
        pop hl
        ret
txtad:  push af                 ; HL = TEXTGRID + row*32 + column
        ld hl,(V_TXTCOL)        ; L = column, H = row
        ld a,h
        cp 24
        jr c,.ok
        ld a,23
.ok:    rrca
        rrca
        rrca
        ld d,a
        and 0xe0
        add a,l
        ld l,a
        ld a,d
        and 0x03
        add a,high TEXTGRID
        ld h,a
        pop af
        ret
vz_cls_play:                    ; replaces 5DF6: rows 2-21, plus the hi-score area
        call mode1
        push hl
        push de
        push bc
        ld hl,TEXTGRID+64
        ld bc,640
        call fillsp
        call clshi
        ld hl,VRAM+6*32         ; and the playfield on the VZ screen
        ld (hl),0xaa
        ld de,VRAM+6*32+1
        ld bc,58*32-1
        ldir
        ld a,0xff
        ld (LASTTOP),a
        pop bc
        pop de
        pop hl
        ret
vz_cls_bottom:                  ; replaces 5E14: rows 22-23
        push hl
        push de
        push bc
        ld hl,TEXTGRID+704
        ld bc,64
        call fillsp
        pop bc
        pop de
        pop hl
        ret
vz_cls_hi:                      ; replaces 5E0B: rows 0-1, columns 8-23
        push hl
        push de
        push bc
        call clshi
        pop bc
        pop de
        pop hl
        ret
clshi:  ld hl,TEXTGRID+8
        ld bc,16
        call fillsp
        ld hl,TEXTGRID+40
        ld bc,16
fillsp: ld (hl),' '
        dec bc
        ld a,b
        or c
        ret z
        ld d,h
        ld e,l
        inc de
        ldir
        ret

; draw character A (text grid position V_TXTCOL) on the VZ screen: row 1 -> HUD line 1,
; rows 2-21 -> playfield lines 6..59, others not shown. Preserves A.
scrglyph:
        push af
        push bc
        push de
        push hl
        ld e,a
        ld hl,(V_TXTCOL)        ; L column, H row
        ld a,h
        cp 1
        ld a,1
        jr z,.ln
        ld a,h
        cp 2
        jr c,.x
        cp 22
        jr nc,.x
        sub 2                   ; text rows 2..21 spread over playfield lines 6..59
        ld l,a                  ; line = 6 + (row-2)*45/16
        ld h,0
        ld b,h
        ld c,l
        add hl,hl
        add hl,hl
        add hl,hl               ; *8
        add hl,bc               ; *9
        ld b,h
        ld c,l
        add hl,hl
        add hl,hl               ; *36
        add hl,bc               ; *45
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        ld a,h                  ; /16
        add a,6
        ld hl,(V_TXTCOL)
.ln:    ld b,l                  ; column
        ld l,a
        ld h,0
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        ld a,b
        cp 32
        jr nc,.x
        ld c,a
        ld b,0
        add hl,bc
        ld bc,VRAM
        add hl,bc               ; HL = screen byte
        ld a,e
        sub 32
        jr c,.x
        cp 64
        jr c,.f
        sub 32
        cp 64
        jr nc,.x
.f:     ld e,a
        ld d,0
        ex de,hl
        ld b,h
        ld c,l
        add hl,hl
        add hl,hl
        add hl,bc
        ld bc,font
        add hl,bc
        ex de,hl
        ld b,5
.g:     ld a,(de)
        ld (hl),a
        inc de
        ld a,l
        add a,32
        ld l,a
        jr nc,$+3
        inc h
        djnz .g
.x:     pop hl
        pop de
        pop bc
        pop af
        ret

; ---- character leaves 605D (bold) / 606C (plain): HL = Spectrum screen, DE = font char ----
; The score is printed straight through these. Record the character instead of drawing.
vz_chr: push af
        push bc
        ld a,l
        and 0x1f
        ld c,a                  ; column
        ld a,l
        rlca
        rlca
        rlca
        and 7
        ld b,a
        ld a,h
        and 0x18
        or b                    ; row
        ld b,a
        push hl
        push de
        ld hl,-0x3c00           ; char = (DE - font base) / 8
        add hl,de
        srl h
        rr l
        srl h
        rr l
        srl h
        rr l
        ld a,l
        ld hl,(V_TXTCOL)
        push hl
        ld l,c
        ld h,b
        ld (V_TXTCOL),hl
        call txtad
        ld (hl),a
        call scrglyph
        pop hl
        ld (V_TXTCOL),hl
        pop de
        pop hl
        ld a,h                  ; as the original leaves it: 8 lines down, font +8
        add a,8
        ld h,a
        ld a,e
        add a,8
        ld e,a
        jr nc,$+3
        inc d
        pop bc
        ld b,0
        pop af
        ret

; ---- keep the original's coordinate result after a boss hit (see ANALYSIS) -----------
vz_fixhl:
        call SP_E4E0
        push af
        ld a,h
        cp 0x4b                 ; 6B5B moved to 4B5B
        jr nz,.x
        ld a,l
        cp 0x5b
        jr nz,.x
        ld h,0x6b
.x:     pop af
        ret

; ---- variables -------------------------------------------------------------------------
latchv: db LATCH_M1
joyok:  db 0
vzticks: db 0
v_be8e: db 0
v_be7e: db 0
v_isl:  db 0
v_water: db 0xa0
        ALIGN 64
font:   INCLUDE "font.inc"
        ALIGN 64
rowtab: ; VZBUF + row*96 for the 22 back-buffer rows
        DUP 22, r
        dw VZBUF + r*96
        EDUP
HOT_END:
        ASSERT HOT_END <= 0x4791
        ASSERT high rowtab == high (rowtab+43)
