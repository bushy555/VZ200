; =====================================================================================
;  Rainbow Islands VZ300 - expansion bank 1 (B800-FFFF): VZ display and data.
;  Called from the hot code with bank 1 mapped and interrupts off (inside the game frame).
; =====================================================================================
        INCLUDE "defs.inc"
        INCLUDE "hotsyms.inc"

        INCLUDE "filedefs.inc"
HUDL    equ 6                   ; HUD lines at the top
PLAYL   equ 58                  ; playfield lines shown
WOFF    equ 4                   ; ring lines skipped above the visible playfield

        org 0xb800
        jp display
        jp install
        jp loadisl
        jp title
        jp portrait
        jp endpicture
        jp music
        jp prepload

; ---- title tune: the island data overwrites 8000-8239 during play; restore it ---------------
music:  ld hl,musicdata
        ld de,0x8000
        ld bc,MUSICLEN
        ldir
        ret

; ---- SD loading: put the loader and this file's parameters into VRAM ----------------------
prepload:                       ; v_isl = island 0..6, or 7 = the ending
        ld hl,ldrblob
        ld de,LDR
        ld bc,LDRLEN
        ldir
        ld a,(v_isl)
        ld (cur_file),a
        call ftabent            ; HL = entry: name(10) len1 dest1 port1 len2 dest2 port2 art
        ld de,l_name
        ld bc,10+5+5
        ldir
        ld a,(dosmode)
        ld (l_dos),a
        ret
ftabent:
        ld a,(cur_file)
        ld l,a
        ld h,0
        ld d,h
        ld e,l
        add hl,hl
        add hl,hl
        add hl,de               ; *5
        add hl,hl
        add hl,hl               ; *20
        add hl,de               ; *21
        ld de,FTAB
        add hl,de
        ret
cur_file: db 0
dosmode: db 0                   ; port 37 value for DOS calls (set by the boot stub)
ldrblob:
        INCLUDE "loader.asm"
LDRLEN  equ ldr_end-LDR

endpicture:                     ; the ending's rainbow picture into the playfield
        ld hl,endpic
        ld de,VRAM+HUDL*32
        jp dzx0_standard

; ---- island intro: the island's boss under its name (the original prints the name) -------
portrait:
        ld de,(ISLART+770)      ; left piece
        ld a,d
        or e
        ret z
        ld bc,(ISLART+772)      ; right piece
        ld a,(ISLART+774)       ; its x offset
        ld (pt_off),a
        ld (pt_b),bc
        ld (s_frame),de
        ld a,b
        or c
        ld a,(pt_off)
        jr nz,$+3
        xor a                   ; one piece: centre it alone
        ld c,a
        ld a,(de)               ; left width in bytes * 4 px ...
        add a,a
        add a,a
        add a,c                 ; ... or the offset + right piece width (about the same)
        srl a
        neg
        add a,64
        ld (s_vx),a
        xor a
        ld (s_flip),a
        ld a,35
        ld (s_line),a
        call blit
        ld hl,(pt_b)
        ld a,h
        or l
        ret z
        ld (s_frame),hl
        ld a,(pt_off)
        ld hl,s_vx
        add a,(hl)
        ld (hl),a
        ld a,35
        ld (s_line),a
        jp blit
pt_b:   dw 0
pt_off: db 0

; ---- title: compose the 32 animation frames of the MODE(0) logo screen into RAM ---------
title:  xor a
.f:     ld (cf_n),a
        call compose
        ld a,(cf_n)
        inc a
        cp NFR
        jr c,.f
        ld hl,TROWS             ; text rows
        ld de,TROWS_RAM
        ld bc,256
        ldir
        ld hl,FR_LO             ; first picture: frame 0 and rows 11-15
        ld de,VRAM
        ld bc,352
        ldir
        ld hl,TROWS_RAM
        ld bc,96
        ldir
        ld hl,TROWS_RAM+128
        ld bc,32
        ldir
        ld hl,TROWS_RAM+192
        ld bc,32
        ldir
        ret

compose:                        ; frame cf_n -> its RAM slot
        ld a,(cf_n)
        cp 16
        jr nc,.m
        ld hl,FR_LO
        jr .b
.m:     cp 31
        ld hl,FR_HI
        jr z,.got
        sub 16
        ld hl,FR_MID
.b:     or a
        jr z,.got
        ld de,352
.mul:   add hl,de
        dec a
        jr nz,.mul
.got:   ld (cf_dst),hl
        ex de,hl                ; DE = destination
        ld hl,TLOGO
        ld bc,0                 ; B = row, C = column
.cell:  ld a,(hl)
        or a
        jp p,.arc
        ; letter: the glint sweeps diagonals 4f..4f+3 (diag = 2*col + row) in frames 0-17
        push af
        ld a,b
        cp 10
        jr nc,.lit
        ld a,c
        add a,a
        add a,b                 ; diagonal
        rrca
        and 0x7e
        push hl
        ld hl,cf_n
        sub (hl)
        sub (hl)
        pop hl
        jr nz,.lit
        pop af
        and 0x8f
        or 0x40
        jr .st
.lit:   pop af
        jr .st
.arc:   or 0xf0                 ; arcs: band colour by distance from the centre below
        push af
        push hl
        push de
        ld a,b
        cp 10
        ld a,c
        jr c,.ph
        add a,a                 ; row 10: phase = col*8
        add a,a
        add a,a
        jr .ph2
.ph:    sub 16                  ; |col - 15.5| -> 0..15
        jr nc,$+3
        cpl                     ; 15 - col
        ld e,a
        ld a,b
        add a,a
        add a,a
        add a,a
        add a,a                 ; row*16
        add a,e
        ld e,a
        ld d,0
        ld hl,THALF
        add hl,de
        ld a,(hl)
.ph2:   ld hl,cf_n
        sub (hl)
        sub (hl)                ; - 2f
        rrca
        rrca
        rrca
        and 7
        ld e,a
        ld d,0
        ld hl,BANDS
        add hl,de
        pop de
        ld a,(hl)
        pop hl
        ex (sp),hl              ; HL = cell value (in H), keep text pointer on the stack
        and h
        ex (sp),hl
        inc sp                  ; drop the saved AF
        inc sp
.st:    ld (de),a
        inc de
        inc hl
        inc c
        bit 5,c
        jr z,.cell
        ld c,0
        inc b
        ld a,b
        cp 11
        jr c,.cell
        ; sparkles: 10 fixed twinkles in empty logo cells (same random sequence every frame)
        ld a,0x5a
        ld (cf_rnd),a
        ld b,10
.sp:    push bc
.pick:  call rnd8
        ld l,a
        call rnd8
        and 1
        ld h,a                  ; 0..511
        ld de,320
        or a
        sbc hl,de
        add hl,de
        jr nc,.pick             ; rows 0-9 only
        ld de,TLOGO
        add hl,de
        ld a,(hl)
        cp 0x0f                 ; empty cell?
        jr nz,.pick
        ld de,-TLOGO
        add hl,de
        call rnd8
        and NFR-1               ; start frame
        ld e,a
        ld a,(cf_n)
        sub e
        and NFR-1
        cp 7
        jr nc,.ns
        ld e,a
        ld d,0
        push hl
        ld hl,SPKPAT
        add hl,de
        ld a,(hl)
        pop hl
        ld de,(cf_dst)
        add hl,de
        ld (hl),a
.ns:    pop bc
        djnz .sp
        ret
rnd8:   ld a,(cf_rnd)           ; x*5+1 mod 256 with a rotate: a fixed little sequence
        ld c,a
        add a,a
        add a,a
        add a,c
        inc a
        ld (cf_rnd),a
        ret
SPKPAT: db 0xc8,0xc9,0xcf,0xcf,0xc6,0xc1,0xc1
cf_rnd: db 0
BANDS:  db 0xef,0xaf,0xdf,0x8f,0x9f,0xff,0xbf,0x80     ; magenta blue cyan green yellow orange red gap
cf_n:   db 0
cf_dst: dw 0


; ---- island data --------------------------------------------------------------------------
loadisl:                        ; after the SD load: VZ art -> ISLART, island block -> 97C0
        call ftabent
        ld de,20
        add hl,de
        ld a,(hl)               ; has art?
        or a
        jr z,.blk
        ld hl,ARTPACK
        ld de,ISLART
        call dzx0_standard
.blk:   call ftabent
        ld de,12
        add hl,de
        ld e,(hl)               ; dest1
        inc hl
        ld d,(hl)
        ld bc,4
        add hl,bc               ; -> dest2 (entry+17)
        ld a,(hl)
        inc hl
        ld h,(hl)
        ld l,a
        or h
        jr nz,$+3
        ex de,hl                ; no second segment: the block is segment 1
        ld de,0x97c0            ; unpack in place (the packed data sits at the end of the area)
        jp dzx0_standard

install:                        ; VZ tile tables for the loaded island, blue playfield ring
        ld hl,ISLART            ; base tiles (raw, 256 x 3)
        ld de,BASETAB
        ld bc,768
        ldir
        ld hl,ovl_data
        ld de,OVLTAB
        ld bc,OVL_LEN
        ldir
        ld hl,VZBUF
        ld de,VZBUF+1
        ld bc,66*32-1
        ld (hl),0xaa
        ldir
        ret

; ---- display: straight into VRAM during vertical blank ---------------------------------------
display:
        ld a,(v_be8e)
        call x38
        ld (t_top),a
        add a,WOFF
        cp 66
        jr c,$+4
        sub 66
        ld (s_start),a
.wfs:   ld a,(LATCH)            ; wait for field sync: draw while the beam is off screen
        rla
        jr c,.wfs
        ld a,(s_start)
        ld hl,LASTTOP
        cp (hl)
        jr z,.part
        ld (hl),a               ; scrolled: copy the whole playfield
        call fullcopy
        jr .spr
.part:  call dirtyrows
        call erase
.spr:   call sprites
        call water
.wfe:   ld a,(LATCH)            ; let field sync finish before the frame ends
        rla
        jr nc,.wfe
        ret

; ---- rising water (the original display filled the playfield below line (E5E2) with water) --
water:  ld a,(v_water)
        cp 0xa0
        jp nc,.none
        call x38                ; Spectrum playfield line -> VZ screen line
        add a,HUDL-WOFF
        cp HUDL
        jr nc,$+4
        ld a,HUDL
        cp 64
        jp nc,.none
        ld hl,w_last            ; water went down (new round): redraw everything next time
        cp (hl)
        jr c,.up
        jr z,.up
        push af
        ld a,0xff
        ld (LASTTOP),a
        pop af
.up:    ld (hl),a
        push af
        call vramline           ; DE = first water line
        pop af
        ld c,a
        ex de,hl
        xor a                   ; surface: a green line
        call .fill
        ld a,(w_phase)          ; below: green/blue shimmer, moving each frame
        xor 0xaa
        ld (w_phase),a
        ld b,a
.l:     inc c
        ld a,c
        cp 64
        ret nc
        ld a,b
        xor 0xaa
        ld b,a
        call .fill
        jr .l
.fill:  DUP 32
        ld (hl),a
        inc l
        EDUP
        ret nz                  ; (L wraps at 256: next page)
        inc h
        ret
.none:  ld a,(w_last)
        cp 64
        ret z
        ld a,64                 ; water gone: full redraw
        ld (w_last),a
        ld a,0xff
        ld (LASTTOP),a
        ret
w_last: db 64
w_phase: db 0x88

ringline: ; A = screen playfield line (0..57) -> HL = VZBUF + ((start+A) mod 66)*32
        ld hl,s_start
        add a,(hl)
        cp 66
        jr c,$+4
        sub 66
        ld l,a
        ld h,0
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        ld bc,VZBUF
        add hl,bc
        ret
vramline: ; A = screen line (0..63) -> DE = VRAM + A*32
        ld e,a
        ld d,0
        ex de,hl
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        ld bc,VRAM
        add hl,bc
        ex de,hl
        ret

fullcopy:                       ; (LDI counts BC down, so lines are counted in A only)
        ld a,(s_start)
        ld b,a
        ld a,66
        sub b                   ; lines before the ring wraps
        cp PLAYL
        jr c,$+4
        ld a,PLAYL
        ld (fc_n1),a
        xor a
        call ringline
        ld de,VRAM+HUDL*32
        ld a,(fc_n1)
        call cpylines
        ld a,(fc_n1)
        neg
        add a,PLAYL
        jr z,.done
        ld hl,VZBUF
        call cpylines
.done:
        ld hl,DIRTY             ; everything is fresh now
        ld de,DIRTY+1
        ld bc,21
        ld (hl),0
        ldir
        xor a
        ld (OLDCNT),a
        ret

dirtyrows:                      ; copy the ring lines of rows the engine redrew
        ld c,0                  ; row
.r:     ld a,c
        add a,low DIRTY
        ld l,a
        ld h,high DIRTY
        ld a,(hl)
        or a
        jr z,.n
        ld (hl),0
        ld a,c                  ; ring line = row*3, three lines
        add a,a
        add a,c
        ld b,3
.ln:    push bc
        push af
        ld hl,s_start           ; screen line = (ring - start) mod 66
        sub (hl)
        jr nc,$+4
        add a,66
        cp PLAYL
        jr nc,.sk
        push af
        call ringline
        pop af
        add a,HUDL
        push hl
        call vramline
        pop hl
        DUP 32
        ldi
        EDUP
.sk:    pop af
        inc a
        pop bc
        djnz .ln
.n:     inc c
        ld a,c
        cp 22
        jr c,.r
        ret

erase:                          ; put the background back where last frame's sprites were
        ld a,(OLDCNT)
        or a
        ret z
        ld b,a
        ld ix,OLDSPR
.s:     push bc
        ld a,(ix+0)             ; screen line
        ld c,(ix+3)             ; lines
.ln:    push af
        push bc
        sub HUDL
        call ringline           ; HL = ring line start
        pop bc
        push bc
        ld a,(ix+0)
        pop bc
        pop af
        push af
        push bc
        call vramline           ; DE = VRAM line start
        ld a,(ix+1)             ; column
        ld c,a
        ld b,0
        add hl,bc
        ex de,hl
        add hl,bc
        ex de,hl
        ld c,(ix+2)             ; bytes
        ldir
        pop bc
        pop af
        inc a
        dec c
        jr nz,.ln
        ld bc,4
        add ix,bc
        pop bc
        djnz .s
        xor a
        ld (OLDCNT),a
        ret

s_start: db 0
fc_n1:  db 0
cpylines:                       ; A lines of 32 bytes HL -> DE
        DUP 32
        ldi
        EDUP
        dec a
        jp nz,cpylines
        ret

x38:    ; A = A*3/8 (A <= 175)
        ld l,a
        ld h,0
        ld d,h
        ld e,l
        add hl,hl
        add hl,de
        srl h
        rr l
        srl h
        rr l
        srl h
        rr l
        ld a,l
        ret

; ---- text -----------------------------------------------------------------------------------
sprites:
        ld a,(SPRCNT)
        or a
        ret z
        ld b,a
        ld hl,SPRLIST
.s:     push bc
        ld e,(hl)
        inc l
        ld d,(hl)
        inc l
        ld c,(hl)
        inc l
        ld b,(hl)
        inc l
        push hl
        push bc
        pop ix                  ; object
        call sprite
        pop hl
        pop bc
        djnz .s
        ret

; DE = Spectrum graphic pointer, IX = object
sprite: call findframe          ; -> HL = frame record, or carry if unknown
        ret c
        ; record: dx, dy, tw, frame address
        ld a,(hl)
        ld (s_dx),a
        inc hl
        ld a,(hl)
        ld (s_dy),a
        inc hl
        ld a,(hl)
        ld (s_tw),a
        inc hl
        ld a,(hl)
        inc hl
        ld h,(hl)
        ld l,a
        ld (s_frame),hl
        ; x in Spectrum pixels
        ld a,(ix+7)
        ld l,a
        ld h,0
        add hl,hl
        add hl,hl
        add hl,hl
        ld a,(ix+6)
        rlca
        rlca
        rlca
        and 7
        ld e,a
        ld d,0
        add hl,de
        bit 0,(ix+10)
        jr nz,.flip
        ld a,(s_dx)
        ld e,a
        add hl,de
        xor a
        jr .x
.flip:  ld a,(ix+2)             ; mirrored: x + w*8 - (dx + tw)
        add a,a
        add a,a
        add a,a
        ld e,a
        add hl,de
        ld a,(s_dx)
        ld e,a
        ld a,(s_tw)
        add a,e
        ld e,a
        or a
        sbc hl,de
        ld a,1
.x:     ld (s_flip),a
        ; VZ x = x/2
        srl h
        rr l
        ld a,h
        or a
        ret nz                  ; off the right / negative
        ld a,l
        cp 128
        ret nc
        ld (s_vx),a
        ; y: playfield y = (ix9 - be7e)*8 + (ix8>>6)*2 + dy
        ld a,(ix+9)
        ld hl,v_be7e
        sub (hl)
        ld l,a
        ld h,0
        bit 7,a
        jr z,$+3
        dec h                   ; signed
        add hl,hl
        add hl,hl
        add hl,hl
        ld a,(ix+8)
        rlca
        rlca
        and 3
        add a,a
        ld e,a
        ld d,0
        add hl,de
        ld a,(s_dy)
        ld e,a
        add hl,de               ; HL = playfield y (signed)
        ld a,h
        or a
        ret nz                  ; above the top or far below
        ld a,l
        cp 176
        ret nc
        ; absolute back-buffer line -> ring line -> screen line
        ld hl,v_be8e
        add a,(hl)
        jr c,.w
        cp 176
        jr c,.nw
.w:     sub 176
.nw:    call x38                ; ring line
        ld hl,t_top
        sub (hl)
        jr nc,$+4
        add a,66
        sub WOFF
        ret c
        cp PLAYL
        ret nc
        add a,HUDL
        ld (s_line),a
        jp blit

; findframe: DE = graphic pointer -> HL = record (dx, dy, tw, addr) ; carry if not found
findframe:
        ld a,d
        cp 0xd6
        jr c,.isl
        cp 0xdf
        jr nc,.isl
        ld hl,spr_common
        jr .search
.isl:   ld hl,(ISLART+768)      ; this island's sprite records
.search:ld a,(hl)               ; entries: ptr (2), dx, dy, tw, addr (2); 0,0 ends
        inc hl
        ld c,(hl)
        inc hl
        or c
        jr z,.nf
        dec hl
        dec hl
        ld a,(hl)
        cp e
        jr nz,.nx
        inc hl
        ld a,(hl)
        cp d
        jr nz,.nx1
        inc hl
        or a
        ret
.nx:    inc hl
.nx1:   ld bc,6
        add hl,bc
        jr .search
.nf:    scf
        ret

; blit frame (s_frame: W bytes, H lines, gfx rows, mask rows) at s_vx, s_line
blit:   ld hl,(s_frame)
        ld a,(hl)
        ld (b_w),a
        inc hl
        ld a,(hl)
        ld (b_h),a
        inc hl
        ld (b_gfx),hl
        ld e,a                  ; mask rows follow H*W gfx bytes
        ld a,(b_w)
        call mul8               ; HL = W*H
        ld de,(b_gfx)
        add hl,de
        ld (b_msk),hl
        call record
        ld a,(b_h)
        ld b,a
        ld a,(s_line)
.row:   cp 64
        ret nc
        push bc
        push af
        ld l,a                  ; dest row start
        ld h,0
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        ld de,VRAM
        add hl,de
        ld a,(s_vx)
        rrca
        rrca
        and 0x3f
        ld e,a
        ld d,0
        add hl,de
        ld (b_dst),hl
        ld a,e
        ld (b_col),a
        call blitrow
        ld hl,(b_gfx)
        ld a,(b_w)
        ld e,a
        ld d,0
        add hl,de
        ld (b_gfx),hl
        ld hl,(b_msk)
        add hl,de
        ld (b_msk),hl
        pop af
        inc a
        pop bc
        djnz .row
        ret

; remember the rectangle for erasing next frame (called by blit before the rows)
record: ld a,(OLDCNT)
        cp NSPR
        ret nc
        inc a
        ld (OLDCNT),a
        dec a
        add a,a
        add a,a
        add a,low OLDSPR
        ld l,a
        ld h,high OLDSPR
        ld a,(s_line)
        ld (hl),a
        inc l
        ld a,(s_vx)
        rrca
        rrca
        and 0x3f
        ld (hl),a
        ld c,a
        inc l
        ld a,(s_vx)             ; bytes: W, or W+1 when shifted; clipped at the right edge
        and 3
        ld a,(b_w)
        jr z,$+3
        inc a
        ld b,a
        add a,c
        sub 32
        jr c,.w
        ld c,a
        ld a,b
        sub c
        ld b,a
.w:     ld (hl),b
        inc l
        ld a,(s_line)           ; lines, clipped at the bottom
        ld c,a
        ld a,(b_h)
        add a,c
        sub 64
        ld a,(b_h)
        jr c,.h
        ld a,64
        sub c
.h:     ld (hl),a
        ret

; one row: W source bytes -> W+1 destination bytes, shifted right by (vx & 3) pixels
blitrow:
        ld a,(s_vx)
        and 3
        add a,a
        ld (b_sh),a             ; table index 0,2,4,6
        xor a
        ld (b_cg),a             ; carry gfx from the previous byte
        ld (b_cm),a             ; carry of inverted mask
        ld a,(b_w)
        ld b,a
        ld c,0                  ; source index
.b:     ; fetch source byte i (or mirrored W-1-i)
        ld a,(s_flip)
        or a
        ld a,c
        jr z,.nf
        ld a,(b_w)
        dec a
        sub c
.nf:    ld e,a
        ld d,0
        ld hl,(b_gfx)
        add hl,de
        ld a,(hl)
        ld hl,(b_msk)
        add hl,de
        ld e,(hl)               ; E = mask (11 = transparent)
        ld d,a                  ; D = gfx
        ld a,(s_flip)
        or a
        jr z,.nm
        ld h,high fliptab
        ld l,d
        ld d,(hl)
        ld l,e
        ld e,(hl)
.nm:    ld a,e
        cpl
        ld e,a                  ; E = opaque bits
        call put
        inc c
        djnz .b
        ; trailing byte from the carries
        ld d,0
        ld e,0
        ld a,(b_sh)
        or a
        ret z
        jp put

; put: D = gfx, E = opaque bits for source byte; shift by b_sh bits; writes one dest byte
put:    push bc
        ld a,(b_sh)
        or a
        jr z,.ns
        ; hi part = byte >> sh  (table A), spill = byte << (8-sh) (table B)
        add a,high shtab-2      ; shtab pages: 2 tables per shift
        ld h,a
        ld l,d
        ld a,(hl)               ; gfx >> sh
        ld b,a
        ld l,e
        ld c,(hl)               ; opaque >> sh
        inc h
        ld l,d
        ld a,(hl)               ; gfx spill
        ld l,e
        ld l,(hl)               ; opaque spill
        ld h,a
        ld a,(b_cg)
        or b
        ld d,a                  ; this byte's gfx
        ld a,(b_cm)
        or c
        ld e,a                  ; this byte's opaque bits
        ld a,h
        ld (b_cg),a
        ld a,l
        ld (b_cm),a
.ns:    ld a,(b_col)
        cp 32
        jr nc,.off
        ld hl,(b_dst)
        ld a,e
        cpl
        and (hl)
        or d
        ld (hl),a
.off:   ld hl,(b_dst)
        inc hl
        ld (b_dst),hl
        ld hl,b_col
        inc (hl)
        pop bc
        ret

mul8:   ; HL = A * E
        ld hl,0
        ld d,0
        ld b,8
.m:     add hl,hl
        rla
        jr nc,$+3
        add hl,de
        djnz .m
        ret

s_dx:   db 0
s_dy:   db 0
s_tw:   db 0
s_frame: dw 0
s_flip: db 0
s_vx:   db 0
s_line: db 0
t_top:  db 0
b_w:    db 0
b_h:    db 0
b_gfx:  dw 0
b_msk:  dw 0
b_dst:  dw 0
b_col:  db 0
b_sh:   db 0
b_cg:   db 0
b_cm:   db 0

        INCLUDE "dzx0_standard.asm"

        ALIGN 256
fliptab:                        ; reverse the four 2-bit pixels of a byte
        DUP 256, i
        db ((i & 3) << 6) | ((i & 12) << 2) | ((i & 48) >> 2) | ((i & 192) >> 6)
        EDUP
shtab:  ; for sh = 2,4,6 bits: page A = b >> sh, page B = (b << (8-sh)) & 255
        DUP 256, i
        db i >> 2
        EDUP
        DUP 256, i
        db (i << 6) & 255
        EDUP
        DUP 256, i
        db i >> 4
        EDUP
        DUP 256, i
        db (i << 4) & 255
        EDUP
        DUP 256, i
        db i >> 6
        EDUP
        DUP 256, i
        db (i << 2) & 255
        EDUP

        INCLUDE "b1data.inc"
B1_END:
        ASSERT B1_END <= 0x10000
