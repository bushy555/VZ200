; =====================================================================================
;  Rainbow Islands VZ300 - title animation driver, in expansion bank 0 at DC22
;  (the Spectrum's common sprite pixels lived here; the VZ never reads them).
;
;  The Spectrum title music (8000) is a beeper loop that times every half wave with
;  "dec hl : jp nz" delay loops. Those loops are replaced by tdel, which spends exactly
;  the same number of T-states but uses them to copy the title animation into VRAM in
;  14-iteration units. So the music keeps its pitch and the logo keeps moving.
; =====================================================================================
        INCLUDE "defs.inc"
UNITN   equ 14                  ; delay iterations (x24 T) per 8-byte copy unit
K_ADJ   equ 17                  ; fixed overhead of a tdel call, in iterations
TICK_FULL equ 25                ; cost of a frame tick, in iterations (measured)
TICK_HALF equ 4                 ; cost of the other field's tick
TNEXT_N equ 10                  ; cost of loading the next copy job

        org 0xdc22
; called from the patched delay loops: "call tdel_hl / nop / nop / nop"  ------------------
tdel_hl:                        ; HL = loop count (was: ld a,l / or h / dec hl / jp nz)
        ex de,hl
        ex de,hl                ; (same cost as tdel_de)
        call tdel_in
        ret
tdel_de:                        ; DE = loop count, HL kept
        ex de,hl
        call tdel_in
        ex de,hl
        ret

tdel_in:
        ld a,(tmode)
        or a
        jp z,.orig
        ld a,l                  ; n < K_ADJ: not even time for the bookkeeping
        sub K_ADJ
        ld a,h
        sbc a,0
        jr c,.small
        push bc
        push de
        ld de,-K_ADJ            ; pay for this routine's own fixed cost
        add hl,de
        jr nc,.small            ; (never: just keeps the timing of the first version)
        ld a,0                  ; padding (30 T)
        ld a,0
        nop
        nop
        nop
        nop
        ld a,(LATCH)            ; field sync edge: next animation frame
        cpl
        and 0x80
        ld b,a
        ld a,(tfsprev)
        cpl
        and b
        ld c,a
        ld a,b
        ld (tfsprev),a
        ld a,c
        or a
        call nz,ttick
.w:     ld de,-(UNITN+1)        ; enough time left for a unit?
        add hl,de
        jr nc,.end
        ld a,(tunits)
        or a
        jr z,.nojob
        ld de,(tdst)            ; one unit: copy 8 bytes
        push hl
        ld hl,(tsrc)
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ld (tsrc),hl
        ld (tdst),de
        pop hl
        inc hl
        ld a,(tunits)
        dec a
        ld (tunits),a
        and 0xff                ; padding (7 T): a unit is exactly UNITN*24 T
        call z,tnextc
        jp .w
.nojob: ld de,UNITN+1
        add hl,de
        jr .idle
.end:   ld de,UNITN+1
        add hl,de
        nop
        nop
        nop
        nop
        nop
        nop
        nop
        nop
        nop                     ; (36 T: same cost as .nojob)
.idle:  ld a,l                  ; the rest of the time: the original loop
        or h
        dec hl
        jp nz,.idle
        pop de
        pop bc
        ret
.small: ld a,l                  ; short delay: the original loop, 8 iterations shorter
        sub 8
        jr c,.orig              ; (tiny: as it comes)
        ld l,a
        ld a,0                  ; padding (25 T)
        ld a,0
        ld a,0
        nop
.orig:  ld a,l
        or h
        dec hl
        jp nz,.orig
        ret

; field sync: every second field, queue the next frame and the text rows ----------------
ttick:  push hl
        ld hl,tfield
        ld a,(hl)
        xor 1
        ld (hl),a
        jr nz,.x0
        ld hl,(tframe)          ; frame counter (16 bit)
        inc hl
        ld (tframe),hl
        ld a,l
        and NFR-1
        add a,a
        ld e,a
        ld d,0
        ld hl,frtab
        add hl,de
        ld a,(hl)
        inc hl
        ld h,(hl)
        ld l,a
        ld (q_frame),hl
        ld a,(tframe)           ; row 13: every 128 frames
        and 0x80
        rrca
        rrca                    ; 0 / 32
        add a,low (TROWS_RAM+64)
        ld (q_r13),a
        ld a,(tframe)           ; row 14: blink every 16 frames
        and 0x10
        add a,a                 ; 0 / 32
        add a,low (TROWS_RAM+128)
        ld (q_r14),a
        ld a,(tframe)           ; row 15: every 128 frames
        and 0x80
        rrca
        rrca
        add a,low (TROWS_RAM+192)
        ld (q_r15),a
        ld hl,queue
        ld (tqptr),hl
        call tnext
        pop hl
        ld de,-TICK_FULL        ; take this work's time out of the delay
        jr hlsub
.x0:    pop hl
        ld de,-TICK_HALF
        jr hlsub

tnextc: call tnext              ; next job, its time taken out of the delay
        ld de,-TNEXT_N
hlsub:  add hl,de               ; HL -= N, unless that would go below zero
        ret c
        ld a,e
        cpl
        ld e,a
        ld a,d
        cpl
        ld d,a
        inc de
        add hl,de
        ret

tnext:  push hl                 ; load the next copy job from the queue
        push de
        ld hl,(tqptr)
        ld e,(hl)
        inc hl
        ld d,(hl)
        inc hl
        ld (tsrc),de
        ld e,(hl)
        inc hl
        ld d,(hl)
        inc hl
        ld (tdst),de
        ld a,(hl)
        inc hl
        ld (tunits),a
        ld (tqptr),hl
        pop de
        pop hl
        ret

; queue: src, dst, units (8 bytes each); 0 ends
queue:
q_frame: dw 0
        dw VRAM
        db 44
q_r13:  dw TROWS_RAM+64
        dw VRAM+13*32
        db 4
q_r14:  dw TROWS_RAM+128
        dw VRAM+14*32
        db 4
q_r15:  dw TROWS_RAM+192
        dw VRAM+15*32
        db 4
        dw 0,0
        db 0

frtab:  DUP 16, k
        dw FR_LO + k*352
        EDUP
        DUP 15, k
        dw FR_MID + k*352
        EDUP
        dw FR_HI

tmode:  db 0                    ; 1 while the animated title is on screen
tfsprev: db 0
tfield: db 0
tframe: dw 0
tsrc:   dw 0
tdst:   dw 0
tunits: db 0
tqptr:  dw 0
ex0_end:
        ASSERT ex0_end <= 0xde92
        ASSERT (high (TROWS_RAM+64)) == (high (TROWS_RAM+255))
