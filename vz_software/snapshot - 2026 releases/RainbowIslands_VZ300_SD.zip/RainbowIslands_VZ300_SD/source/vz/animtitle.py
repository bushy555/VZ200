"""Data for the animated MODE(0) title (logo + rainbow arches, from the first VZ version):
logo cells, arc phases, glint cells per frame, baked sparkles and the text rows."""
import os, sys, random
HERE = os.path.dirname(os.path.abspath(__file__))
NAMES = ["INSECT", "COMBAT", "MONSTER", "TOY", "DOH'S", "ROBOT", "DRAGON"]
NFR = 32            # animation frames (arc phase step 2)
SPKPAT = [0xc8, 0xc9, 0xcf, 0xcf, 0xc6, 0xc1, 0xc1]


def design():
    cwd = os.getcwd(); argv = sys.argv
    os.chdir(HERE + '/oldtitle'); sys.argv = ['x']; sys.path.insert(0, HERE + '/oldtitle')
    try:
        g = {}
        exec(open('design.py').read().split("if __name__=='__main__':")[0], g)
    finally:
        os.chdir(cwd); sys.argv = argv
    return g['logo'], g['phase']


def tx(s, inv=False):
    return [(ord(c) & 0x3f) | (0x40 if inv and c != ' ' else 0) for c in s.center(32)[:32]]


def data(filenum, islands, hiscore='100000'):
    logo, phase = design()
    ph = list(phase)
    for i, v in enumerate(logo):                 # glint runs along the letters' diagonals
        if v & 0x80:
            cx, cy = i % 32, i // 32
            ph[i] = (cx * 2 + cy) & 255 if cy < 10 else 255
    diag = {}
    for i, v in enumerate(logo):
        if v & 0x80 and i < 320:
            diag.setdefault(ph[i], []).append(i)
    # glint: frames 0..15 sweep 4 diagonals each
    glint = []                                   # per frame: list of cells
    for f in range(NFR):
        cells = []
        if f < 16:
            for d in range(f * 4, f * 4 + 4): cells += diag.get(d, [])
        glint.append(cells)
    # sparkles: fixed pseudo-random twinkles in the empty cells, baked per frame
    cand = [i for i, v in enumerate(logo) if v == 0x0F and i < 320]
    rnd = random.Random(1987)
    spark = []                                   # (frame, cell, value)
    for k in range(10):
        c = rnd.choice(cand); t0 = rnd.randrange(NFR)
        for s, v in enumerate(SPKPAT): spark.append(((t0 + s) % NFR, c, v))
    over = []                                    # overlay: frame, cell lo, cell hi, op (0 = glint, else value)
    for f in range(NFR):
        for (ff, c, v) in spark:
            if ff == f: over.append((f, c, v))
    part = "ALL SEVEN ISLANDS ON SD CARD" if filenum == 0 else \
        f"PART {filenum} OF 4: " + (' + '.join(NAMES[k] for k in islands) if len(islands) > 1 else NAMES[islands[0]] + " ISLAND")
    rows = (tx("THE STORY OF BUBBLE BOBBLE 2") + tx("(C) 1987 TAITO CORPORATION") +
            tx("VZ300 128K CONVERSION") + tx(part) +                     # row 13, alternating
            tx("PRESS FIRE TO PLAY", True) + tx("PRESS FIRE TO PLAY") +  # row 14, blinking
            tx("Z X MOVE M JUMP A DOWN SPC FIRE") + tx("RETURN ADDS CREDITS"))  # row 15, alternating
    import math
    half = [int(math.hypot(dx + 0.5, (cy + 0.5 - 13.5) * 1.5) * 8 / 1.6) & 255 for cy in range(10) for dx in range(16)]
    for i in range(320):                         # check against the design's own phases
        cx, cy = i % 32, i // 32
        if not logo[i] & 0x80: assert half[cy * 16 + (cx - 16 if cx >= 16 else 15 - cx)] == phase[i], i
    L = ['TLOGO:'] + dbl(logo) + ['THALF:'] + dbl(half)
    L += ['TROWS:'] + dbl(rows)
    return L


def dbl(d):
    d = list(d)
    return ['        db ' + ','.join(str(b) for b in d[i:i + 32]) for i in range(0, len(d), 32)]


if __name__ == '__main__':
    L = data(1, [0, 1]); print(len(L), sum(l.count(',') + 1 for l in L if 'db' in l))
