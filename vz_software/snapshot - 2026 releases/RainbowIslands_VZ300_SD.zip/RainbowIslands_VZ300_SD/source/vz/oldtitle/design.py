import math,sys
ANIM='anim' in sys.argv
from PIL import Image
# MC6847 SG4 colours
SG=[(7,255,0),(255,255,67),(59,8,255),(204,0,59),(255,255,255),(7,227,153),(255,28,255),(255,129,0)]
G,Y,B,R,BUFF,C,M,O=range(8)
L1="RAINBOW"; L2="ISLANDS"
F6={
'R':["####.","##.##","####.","##.#.","##.##","##.##"],
'A':[".###.","##.##","##.##","#####","##.##","##.##"],
'I':["#####",".###.",".###.",".###.",".###.","#####"],
'N':["##.##","###.#","#####","#.###","##.##","##.##"],
'B':["####.","##.##","####.","##.##","##.##","####."],
'O':[".###.","##.##","##.##","##.##","##.##",".###."],
'W':["##.##","##.##","##.##","#####","#####",".#.#."]}
F6OLD={
'R':["#####.","##..##","#####.","####..","##.##.","##..##"],
'A':[".####.","##..##","##..##","######","##..##","##..##"],
'I':["######","..##..","..##..","..##..","..##..","######"],
'N':["##..##","###.##","######","######","##.###","##..##"],
'B':["#####.","##..##","#####.","##..##","##..##","#####."],
'O':[".####.","##..##","##..##","##..##","##..##",".####."],
'W':["##..##","##..##","##..##","######","######",".#..#."]}
F8={
'I':["#####","#####",".###.",".###.",".###.",".###.","#####","#####"],
'S':[".####","#####","##...","####.",".####","...##","#####","####."],
'L':["##...","##...","##...","##...","##...","##...","#####","#####"],
'A':[".###.","#####","##.##","##.##","#####","#####","##.##","##.##"],
'N':["##.##","###.#","#####","#####","#.###","#.###","##.##","##.##"],
'D':["####.","#####","##.##","##.##","##.##","##.##","#####","####."]}
F8OLD={
'I':["######","######","..##..","..##..","..##..","..##..","######","######"],
'S':[".#####","######","##....","#####.",".#####","....##","######","#####."],
'L':["##....","##....","##....","##....","##....","##....","######","######"],
'A':[".####.","######","##..##","##..##","######","######","##..##","##..##"],
'N':["##..##","###.##","######","######","##.###","##.###","##..##","##..##"],
'D':["#####.","######","##..##","##..##","##..##","##..##","######","#####."]}
W,H=64,22   # rows 0..10 cells (row 10 = stripe)
lett=[[None]*W for _ in range(H)]   # colour index for letter pixel
L1COL=[R,O,Y,G,C,B,M]
def put(word,font,y0,colfn):
    for k,ch in enumerate(word):
        g=font[ch]; x0=4+8*k
        for y,row in enumerate(g):
            for x,c in enumerate(row):
                if c=='#': lett[y0+y][x0+x]=colfn(k,y)
put(L1,F6,2,lambda k,y: 'RB' if ANIM else (BUFF if y<2 else L1COL[k]))
put(L2,F8,11,lambda k,y: [BUFF,Y,O,R][(y+1)//2] if (y+1)//2<4 else R)
# outline + shadow
black=[[False]*W for _ in range(H)]
for y in range(20):
    for x in range(W):
        if lett[y][x] is not None: continue
        for dy in (-1,0,1):
            for dx in (-1,0,1):
                yy,xx=y+dy,x+dx
                if 0<=yy<H and 0<=xx<W and lett[yy][xx] is not None: black[y][x]=True
        for (dx,dy) in ():   # extra drop shadow
            yy,xx=y+dy,x+dx
            if 0<=yy<H and 0<=xx<W and lett[yy][xx] is not None: black[y][x]=True
# cell encoding
logo=[]
conf=0
for cy in range(11):
    for cx in range(32):
        px=[(cx*2,cy*2),(cx*2+1,cy*2),(cx*2,cy*2+1),(cx*2+1,cy*2+1)]
        bits=[8,4,2,1]
        cols={lett[y][x] for x,y in px if lett[y][x] is not None}
        if 'RB' in cols: cols={'RB'}
        if cy==10: logo.append(0x0C); continue
        if cols:
            if len(cols)>1: conf+=1
            c=max(cols,key=lambda c:sum(1 for x,y in px if lett[y][x]==c))
            pat=sum(b for (x,y),b in zip(px,bits) if lett[y][x]==c)
            logo.append((0x40|pat) if c=='RB' else (0x80|c<<4|pat))
        else:
            pat=sum(b for (x,y),b in zip(px,bits) if not black[y][x])
            logo.append(pat)   # 0x0F transparent, else bg masked
print('colour conflicts',conf)
# phase table: concentric arcs centred below logo
cxc,cyc=16,13.5
phase=[]
for cy in range(11):
    for cx in range(32):
        if cy==10: phase.append((cx*8)&255); continue
        d=math.hypot(cx+0.5-cxc,(cy+0.5-cyc)*1.5)
        phase.append(int(d*8/1.6)&255)
BAND=[M,B,C,G,Y,O,R,None]   # None=black gap
def cellbyte(i,t):
    v=logo[i]
    if v&0x80: return v
    if v&0x40:
        cx,cy=i%32,i//32
        idx=((cx*8+cy*12-3*t)>>4)%7
        c=[R,O,Y,G,C,B,M][idx]
        return 0x80|c<<4|(v&15)
    idx=((phase[i]-t)>>3)&7
    c=BAND[idx]
    if c is None: return 0x80
    return (0x8F|c<<4)&(0xF0|v)
TEXT=["","THE STORY OF BUBBLE BOBBLE 2","(C) 1987 TAITO CORPORATION","VZ300 128K CONVERSION","PRESS FIRE TO PLAY","Z X MOVE M JUMP A DROP SPC FIRE"]
from fontsmall import glyph
def render(t,fn,inv=True):
    im=Image.new('RGB',(256,192))
    for i in range(352):
        b=cellbyte(i,t); cx,cy=i%32,i//32
        col=SG[(b>>4)&7]
        for q,bit in enumerate((8,4,2,1)):
            on=b&bit
            for yy in range(6):
                for xx in range(4):
                    im.putpixel((cx*8+(q%2)*4+xx,cy*12+(q//2)*6+yy),col if on else (0,0,0))
    for r,txt in enumerate(TEXT[1:]):
        row=11+r; s=txt.center(32)
        for cx,ch in enumerate(s):
            inverse = (r==3) and inv and ch!=' '
            fg,bg=((0,64,0),(7,255,0)) if inverse else ((7,255,0),(0,64,0))
            g=glyph(ch)
            for yy in range(12):
                for xx in range(8):
                    on = 1<=xx<=5 and 3<=yy<=9 and g[yy-3][xx-1]=='#'
                    im.putpixel((cx*8+xx,row*12+yy),fg if on else bg)
    im.resize((512,384),Image.NEAREST).save(fn)
if __name__=='__main__':
    for t in (0,8,16):
        render(t,f'title_{t}{"a" if ANIM else ""}.png',inv=(t!=8))
    open('logo.bin','wb').write(bytes(logo)); open('phase.bin','wb').write(bytes(phase))
