; RAINBOW.VZ loader: keep what the BennVenn DOS needs for later, unpack the VZ code, the
; engine and the common data into the BennVenn banks, then boot.
        DEVICE NOSLOT64K
        INCLUDE "defs.inc"
        INCLUDE "linkdefs.inc"
        org 0x7ae9
stub:   di
        ld sp,0x77f0            ; (VRAM: the system variables are kept untouched for the DOS)
        ld hl,0x5fff            ; DOS window: ROM or RAM? (tested the way 13 Ghosts does)
        ld b,(hl)
        ld a,b
        cpl
        ld (hl),a
        ld a,(hl)
        xor b
        ld (hl),b
        and 1
        ld (v_dos),a
        ld a,MAP_E1             ; ROM system variables -> expansion bank 1
        out (MAPPORT),a
        ld hl,0x7800
        ld de,SAVESYS
        ld bc,0x7ae9-0x7800
        ldir
        ld hl,WSLO              ; DOS workspace (expansion bank 0, EE00-FFFF) -> bank 1
.ws:    push hl
        ld a,MAP_E0
        out (MAPPORT),a
        ld de,0x7000
        ld bc,512
        ldir
        ld a,MAP_E1
        out (MAPPORT),a
        pop de
        push de
        ld hl,0x7000
        ld bc,512
        ldir
        pop hl
        ld bc,512
        add hl,bc
        jr nc,.ws
        ld hl,p_b1              ; VZ display code and data -> expansion bank 1
        ld de,0xb800
        call dzx0_standard
        ld a,(v_dos)
        ld (B1_DOSMODE),a
        ld a,MAP_E0             ; hot code, moved block, text grid, 5B00-67FF -> DOS RAM bank 1
        out (MAPPORT),a
        ld hl,p_dos0
        ld de,0x4000
        call dzx0_standard
        ld hl,p_tail
        ld de,0x7600
        ld bc,32
        ldir
        ld hl,final
        ld de,0x7400
        ld bc,final_end-final
        ldir
        jp 0x7400
v_dos:  db 0
        INCLUDE "dzx0_standard.asm"
final:
        DISP 0x7400             ; (VRAM)
fin:    ld hl,p_main+MAINLEN-1  ; move the packed engine to the top of memory
        ld de,0xffff
        ld bc,MAINLEN
        lddr
        ld hl,0x10000-MAINLEN
        ld de,0x7800
        call dz2
        ld hl,0x7600            ; last 32 bytes
        ld de,0x10000-32
        ld bc,32
        ldir
        jp VZBOOT
        MODULE d2
        INCLUDE "dzx0_standard.asm"
        ENDMODULE
dz2     equ d2.dzx0_standard
        ENT
final_end:
p_b1:   INCBIN "out/p_b1.zx0"
        ASSERT $ < 0xb800       ; read while expansion bank 1 is in
p_dos0: INCBIN "out/p_dos0.zx0"
p_tail: INCBIN "out/p_tail.bin"
p_main: INCBIN "out/p_main.zx0"
img_end:
        ASSERT img_end <= WSLO  ; the DOS workspace must survive the load
        ASSERT img_end <= 0xf480 ; .VZ file <= 31,151 bytes
        SAVEBIN "out/RAINBOW.bin",stub,img_end-stub
