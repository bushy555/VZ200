"""VZ ending picture: the Spectrum's big rainbow (6 bands) as a MODE(1) playfield (58 lines)."""
import math
G, Y, B, R = 0, 1, 2, 3


def picture():
    bands = [(R, R), (R, Y), (Y, Y), (G, G), (G, B), (R, B)]   # red orange yellow green cyan magenta
    out = []
    for yl in range(58):
        row = []
        for x in range(128):
            sx = (x + 0.5) * 2; sy = (yl + 0.5) * 8 / 3
            d = math.hypot(sx - 128, (sy - 158) * 0.82)
            c = B
            if 60 <= d < 126:
                a, b = bands[min(5, int((126 - d) / 11))]
                c = a if (x + yl) % 2 == 0 else b
            row.append(c)
        bs = []
        for i in range(0, 128, 4):
            v = 0
            for k in range(4): v = v << 2 | row[i + k]
            bs.append(v)
        out += bs
    return bytes(out)
