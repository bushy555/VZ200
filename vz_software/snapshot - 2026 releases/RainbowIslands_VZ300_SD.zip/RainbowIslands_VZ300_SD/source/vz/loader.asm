; =====================================================================================
;  SD card file loader - copied to VRAM (LDR) and run there, because the DOS window
;  (4000-67FF) holds the BennVenn DOS while a file is read.
;  The calls are made exactly the way 13 Ghosts makes them:
;     (FB80) = F800 : A = 1 : call 5F00 (HL -> "NAME")  ->  FB03 = 1, FB05 <> 1 when open
;     A = 1 : call 5F03                                  ->  first 512 bytes at F800
;     (FB80) = buffer : call 5F09                        ->  next 512 bytes at the buffer
;  with the DOS seeing the machine as it was when RAINBOW.VZ was loaded: its workspace at
;  EE00-FFFF in expansion bank 0 and the ROM's system variables at 7800-7AE8 are swapped
;  back in for the call (copies taken at boot), and swapped out again afterwards.
;  in: parameters below (set by prepload). out: A = 0 ok, 1 = file not opened.
; =====================================================================================
        DISP LDR
ldr:    ld (l_sp),sp
        ld sp,LSTACK
        im 1                    ; if the DOS enables interrupts, the ROM's handler takes them
        call swap               ; DOS workspace + system variables in
        ld a,(l_dos)            ; DOS window as at boot (ROM or its RAM), expansion bank 0
        out (MAPPORT),a
        ld hl,0xf800
        ld (0xfb80),hl
        ld hl,l_name
        ld a,1
        call 0x5f00
        ld a,(0xfb03)
        cp 1
        jp nz,.fail
        ld a,(0xfb05)
        cp 1
        jp z,.fail
        ld a,1
        call 0x5f03
        ld hl,0xf800            ; first sector
        ld a,(l_port)           ; destination outside internal RAM: through the VRAM buffer
        or a
        jr z,.cp
        ld de,LBUF
        ld bc,512
        ldir
        ld hl,LBUF
        jr .cp
.next:  ld hl,LBUF
        ld (0xfb80),hl
        call 0x5f09
        ld hl,LBUF
.cp:    ld bc,(l_len)           ; this sector: min(512, bytes left in the segment)
        ld a,b
        cp 2
        jr c,$+5
        ld bc,512
        push bc
        ld a,(l_port)
        or a
        jr z,$+4
        out (MAPPORT),a
        ld de,(l_dest)
        ldir
        ld (l_dest),de
        ld a,(l_dos)
        out (MAPPORT),a
        pop bc
        ld hl,(l_len)
        or a
        sbc hl,bc
        ld (l_len),hl
        ld a,h
        or l
        jr nz,.next
        ld hl,(l_len2)          ; second segment (starts on a sector boundary)
        ld a,h
        or l
        jr z,.ok
        ld (l_len),hl
        ld hl,0
        ld (l_len2),hl
        ld hl,(l_dest2)
        ld (l_dest),hl
        ld a,(l_port2)
        ld (l_port),a
        jr .next
.ok:    xor a
        jr .end
.fail:  ld a,1
.end:   push af
        ld a,MAP_E0
        out (MAPPORT),a
        call swap               ; game memory back
        pop af
        ld sp,(l_sp)
        im 2
        ret

; exchange EXP0 EE00-FFFF with the copy in EXP1, 512 bytes at a time through LBUF,
; and internal 7800-7AE8 with its copy in EXP1 (the same exchange undoes itself)
swap:   ld hl,WSLO
.c:     push hl
        ld a,MAP_E0
        out (MAPPORT),a
        ld de,LBUF              ; EXP0 chunk -> buffer
        ld bc,512
        ldir
        ld a,MAP_E1
        out (MAPPORT),a
        pop hl
        push hl
        ld de,LBUF              ; buffer <-> EXP1 chunk
        ld bc,512
        call xchg
        ld a,MAP_E0
        out (MAPPORT),a
        pop de
        push de
        ld hl,LBUF              ; buffer -> EXP0 chunk
        ld bc,512
        ldir
        pop hl
        ld bc,512
        add hl,bc
        jr nc,.c                ; up to FFFF
        ld a,MAP_E1
        out (MAPPORT),a
        ld hl,0x7800
        ld de,SAVESYS
        ld bc,0x7ae9-0x7800
        call xchg
        ld a,MAP_E0
        out (MAPPORT),a
        ret
xchg:   ld a,(de)               ; exchange BC bytes at HL and DE
        push af
        ld a,(hl)
        ld (de),a
        pop af
        ld (hl),a
        inc hl
        inc de
        dec bc
        ld a,b
        or c
        jr nz,xchg
        ret

l_name: ds 10                   ; "RISLANDn" (in quotes, as 13 Ghosts passes it)
l_len:  dw 0                    ; segment 1
l_dest: dw 0
l_port: db 0                    ; 0 = internal RAM, else the port 37 value for writing
l_len2: dw 0                    ; segment 2
l_dest2: dw 0
l_port2: db 0
l_dos:  db 0                    ; port 37 value for the DOS (found at boot, like 13 Ghosts)
l_sp:   dw 0
ldr_end:
        ENT
        ASSERT ldr_end <= 0x7800
        ASSERT LBUF+512 <= 0xa1cb   ; below the lowest in-place island data
