"""Build RAINBOW.VZ + the island data files for the BennVenn SD card:
the original Spectrum Rainbow Islands engine + VZ300 hardware layer + VZ art.
RAINBOW.VZ holds the engine and everything common; each island (RISLAND1-7.DAT) and the ending
(RIENDING.DAT) is read from the SD card when the game reaches it, as the Spectrum read them from tape."""
import sys, os, subprocess, pickle, struct
sys.path.insert(0, '/home/claude/p2'); sys.path.insert(0, '/home/claude/p3'); sys.path.insert(0, '/home/claude/p1')
import reloc
from assets import Island, rainbow_chars, item_vz, sprite_conv, BLUE
import bubart
import animtitle
import endpic

HERE = '/home/claude/p3'
OUT = HERE + '/out'
os.makedirs(OUT, exist_ok=True)
REL = -0x2000
FILENUM = 0                    # single file + SD data files
ISLANDS = list(range(7))
FINAL = True
MAP_E1 = 0x07
ISLART, ARTPACK, SAVESYS = 0xd800, 0xe000, 0xe600


def run(cmd):
    r = subprocess.run(cmd, cwd=HERE, capture_output=True, text=True)
    if r.returncode or 'error:' in (r.stdout + r.stderr).lower():
        print(r.stdout, r.stderr); raise SystemExit('failed: ' + ' '.join(cmd))
    return r.stdout


def zx0(data, name):
    p = f'{OUT}/{name}.bin'
    open(p, 'wb').write(bytes(data))
    subprocess.run(['zx0', '-f', p, p + '.zx0'], capture_output=True, check=True)
    return open(p + '.zx0', 'rb').read()


def syms(fn):
    d = {}
    for l in open(fn):
        p = l.replace(':', ' ').split()
        if len(p) >= 3 and p[1] == 'EQU':
            d[p[0]] = int(p[2], 16)
    return d


def enc_tile(px):
    out = []
    for r in px:
        b = 0
        for x, c in enumerate(r):
            b |= (BLUE if c < 0 else c) << (6 - 2 * x)
        out.append(b)
    return out


def enc_masked(px):
    out = []
    for r in px:
        g = m = 0
        for x, c in enumerate(r):
            if c < 0:
                m |= 3 << (6 - 2 * x)
            else:
                g |= c << (6 - 2 * x)
        out += [g, m]
    return out


def enc_frame(px):
    W = (len(px[0]) + 3) // 4
    g = []; m = []
    for r in px:
        gb = [0] * W; mb = [0xff] * W
        for x, c in enumerate(r):
            if c >= 0:
                gb[x // 4] |= c << (6 - 2 * (x % 4))
                mb[x // 4] &= ~(3 << (6 - 2 * (x % 4))) & 0xff
        g += gb; m += mb
    return [W, len(px)] + g + m


def dbl(data):
    data = list(data)
    return ['        db ' + ','.join(str(b) for b in data[i:i + 32]) for i in range(0, len(data), 32)]


# ------------------------------------------------------------------ font (3x5, yellow on blue)
F = {' ': "000000000000000", '0': "111101101101111", '1': "010110010010111", '2': "111001111100111",
     '3': "111001011001111", '4': "101101111001001", '5': "111100111001111", '6': "111100111101111",
     '7': "111001010010010", '8': "111101111101111", '9': "111101111001111", 'A': "010101111101101",
     'B': "110101110101110", 'C': "011100100100011", 'D': "110101101101110", 'E': "111100110100111",
     'F': "111100110100100", 'G': "011100101101011", 'H': "101101111101101", 'I': "111010010010111",
     'J': "001001001101010", 'K': "101101110101101", 'L': "100100100100111", 'M': "101111111101101",
     'N': "110101101101101", 'O': "010101101101010", 'P': "110101110100100", 'Q': "010101101110011",
     'R': "110101110101101", 'S': "011100010001110", 'T': "111010010010010", 'U': "101101101101111",
     'V': "101101101101010", 'W': "101101111111101", 'X': "101101010101101", 'Y': "101101010010010",
     'Z': "111001010100111", '!': "010010010000010", '?': "110001010000010", '.': "000000000000010",
     ',': "000000000010100", ':': "000010000010000", '-': "000000111000000", '+': "000010111010000",
     '/': "001001010100100", '(': "010100100100010", ')': "010001001001010", "'": "010010000000000",
     '=': "000111000111000", '%': "101001010100101", '*': "000101010101000", '#': "101111101111101",
     '@': "010101111100011", '"': "101101000000000", '<': "001010100010001", '>': "100010001010100",
     '[': "110100100100110", ']': "011001001001011", '&': "010101010101011", '$': "011110010011110",
     ';': "000010000010100", '^': "010101000000000", '_': "000000000000111", '\\': "100100010001001"}


def font_inc():
    lines = []
    for code in range(32, 96):
        ch = chr(code)
        pat = F.get(ch, "111101101101111")
        bs = []
        for row in range(5):
            b = 0
            for x in range(4):
                on = x < 3 and pat[row * 3 + x] == '1'
                b |= (1 if on else 2) << (6 - 2 * x)     # yellow on blue
            bs.append(b)
        lines.append('        db ' + ','.join('%d' % b for b in bs) + '   ; ' + repr(ch))
    open(HERE + '/font.inc', 'w').write('\n'.join(lines) + '\n')


# ------------------------------------------------------------------ VZ art tables
def art(m00):
    IA = pickle.load(open('/home/claude/p1/itemattr.pkl', 'rb'))
    rb, _, _ = rainbow_chars(m00)
    # overlay table: index a = 0..223 (3 bytes each, opaque)
    ovl = []
    items = {}
    for a in range(224):
        if a in rb:
            px = rb[a]
        elif a >= 0x13:
            first = 0x13 + 4 * ((a - 0x13) // 4)
            if first not in items:
                items[first] = item_vz(m00, first, IA.get(first, 0x46))[0]
            q = (a - 0x13) % 4
            dx = (q & 1) * 4; dy = (q >> 1) * 3
            px = [r[dx:dx + 4] for r in items[first][dy:dy + 3]]
        else:
            px = [[-1] * 4 for _ in range(3)]
        ovl += enc_tile(px)
    mask = []
    for a in range(17):
        px = rb.get(a, [[-1] * 4 for _ in range(3)])
        mask += enc_masked(px)
    return ovl + mask


def sprites():
    G = pickle.load(open('/home/claude/p1/groups.pkl', 'rb'))
    items = list(G.items())
    bubs = [i for i, ((isl, img), g) in enumerate(items) if isl is None and len(img[0]) >= 20]
    hand = bubart.frames()
    frames = []; recs = {}       # recs[isl] = list of (ptr, dx, dy, tw, frame index)
    boss = {}                    # island -> first boss frame index (for the island intro)
    for n, ((isl, img), g) in enumerate(items):
        if n in bubs and bubs.index(n) < len(hand):
            px = hand[bubs.index(n)]
        else:
            px = sprite_conv(isl, img)
        fi = len(frames)
        frames.append(enc_frame(px))
        tw = len(img[0][0])
        if isl is not None and len(img[0]) >= 36:
            boss.setdefault(isl, []).append((min(k[1] for k, _, _ in g['keys']), fi, tw))
        for (key, x0, y0) in g['keys']:
            kisl, de, w, h = key
            recs.setdefault(kisl, []).append((de, x0, y0, tw, fi))
    return frames, recs, boss


def build():
    font_inc()
    open(HERE + '/filedefs.inc', 'w').write(
        f'FILENUM equ {FILENUM}\nFIRSTISL equ {ISLANDS[0]}\nENDROUND equ {(ISLANDS[-1] + 1) * 4}\n')
    # title animation driver (expansion bank 0, DC22) first: the hot code calls it
    run(['sjasmplus', '--nologo', '--raw=ex0.bin', '--sym=ex0.sym', 'ex0.asm'])
    X0 = syms(HERE + '/ex0.sym')
    open(HERE + '/ex0syms.inc', 'w').write(''.join(f'{k} equ 0x{v:04x}\n' for k, v in X0.items()
                                                    if '.' not in k and k in ('tdel_hl', 'tdel_de', 'tmode', 'tunits', 'tframe')))
    ex0 = open(HERE + '/ex0.bin', 'rb').read()
    run(['sjasmplus', '--nologo', '--raw=hot.bin', '--sym=hot.sym', 'hot.asm'])
    H = syms(HERE + '/hot.sym')
    H.update({k: X0[k] for k in ('tdel_hl', 'tdel_de')})
    D = syms_defs = set(l.split()[0] for f in ('defs.inc', 'filedefs.inc', 'ex0syms.inc') for l in open(HERE + '/' + f)
                        if ' equ ' in l and not l.startswith(';'))
    open(HERE + '/hotsyms.inc', 'w').write(''.join(f'{k} equ 0x{v:04x}\n' for k, v in H.items() if k not in D and '.' not in k))
    hot = open(HERE + '/hot.bin', 'rb').read()

    # ---- Spectrum engine image, relocated and patched -------------------------------
    img = open('/home/claude/p2/unpacked.bin', 'rb').read()
    m, _ = reloc.relocate(img, REL)
    m = bytearray(m)

    PATCHED = set()

    def put(a, bs, orig=None):
        PATCHED.update(range(a, a + len(bs)))
        if orig is not None:
            assert bytes(m[a:a + len(orig)]) == bytes(orig), ('%04x' % a, m[a:a + len(orig)].hex(), bytes(orig).hex())
        for i, b in enumerate(bs):
            m[a + i] = b & 0xff

    def jp(a, t, orig=None): put(a, [0xc3, t & 255, t >> 8], orig)
    def call(a, t, orig=None): put(a, [0xcd, t & 255, t >> 8], orig)
    call(0xfe05, H['vz_title'], [0xcd, 0x92, 0x5c])
    call(0xfe0b, H['vz_round'], [0xcd, 0xb0, 0x63])
    jp(0x6ffa + REL, H['vz_island'], [0x21, 0x06, 0x5b])
    put(0xb90e, [0xcd, H['vzinput'] & 255, H['vzinput'] >> 8, 0x0e, 0x00, 0xc3, 0x77, 0xb9], [0x0e, 0x00, 0x06, 0x05])
    for a, sym, orig in ((0x5bdc, 'vzkey_df', [0x3e, 0xdf, 0xdb, 0xfe]), (0x5bec, 'vzkey_fb', [0x3e, 0xfb, 0xdb, 0xfe]),
                         (0x5bf8, 'vzkey_df', [0x3e, 0xdf, 0xdb, 0xfe]), (0x5c0a, 'vzkey_fd', [0x3e, 0xfd, 0xdb, 0xfe]),
                         (0x5d14, 'vzkey_bf', [0x3e, 0xbf, 0xdb, 0xfe])):
        put(a, [0xcd, H[sym] & 255, H[sym] >> 8, 0x00], orig)
    call(0x5c2c, H['vzkey_all'], [0xaf, 0xdb, 0xfe])
    call(0x5c3a, H['vzkey_all'], [0xaf, 0xdb, 0xfe])
    put(0x5d41, [0xcd, H['vzinput'] & 255, H['vzinput'] >> 8, 0xe6, 0x18, 0xc9],
        [0xdb, 0x1f, 0xfe, 0x10, 0xc2, 0x0e])                         # title start: fire or jump
    # ---- title, new game, end of this part ----
    put(0x5cb1, [0xcd, H['vz_titlepage'] & 255, H['vz_titlepage'] >> 8, 0x18, 0x05],
        [0xdd, 0x21, 0x24, 0x61, 0x01])                              # page 1 = the VZ screen
    call(0xfe08, H['vz_newgame'], [0xcd, 0x75, 0x63])
    jp(0x5ddf, H['vz_islintro'], [0x3e, 0x03, 0xc3])               # island intro: + boss portrait
    # title music: beeper OUT (FE) -> VZ speaker
    put(0x8103, [0xcd, H['vzspk'] & 255, H['vzspk'] >> 8, 0x00], [0xee, 0x10, 0xd3, 0xfe])
    put(0x8111, [0xcd, H['vzspkoff'] & 255, H['vzspkoff'] >> 8], [0xaf, 0xd3, 0xfe])
    # its two delay loops (and the title page wait) run the animation in their spare time
    if not os.environ.get('REFMUSIC'):
      put(0x80fc, [0xcd, H['tdel_hl'] & 255, H['tdel_hl'] >> 8, 0, 0, 0], [0x7d, 0xb4, 0x2b, 0xc2, 0xfc, 0x80])
      put(0x810a, [0xcd, H['tdel_de'] & 255, H['tdel_de'] >> 8, 0, 0, 0], [0x7b, 0xb2, 0x1b, 0xc2, 0x0a, 0x81])
    put(0x5cf7, [0x21, 0x27, 0x15, 0xcd, H['tdel_hl'] & 255, H['tdel_hl'] >> 8],
        [0x01, 0x88, 0x13, 0xcd, 0xc6, 0x5b])                        # same wait, animated
    put(0xf1d0, [0xc3, H['vzbeep'] & 255, H['vzbeep'] >> 8, 0], [0x3e, 0x10, 0xd3, 0xfe])
    jp(0xe5e3, H['vz_display'], [0xfd, 0x21, 0x3c])
    jp(0xedb5, H['vz_leaf_base'], [0x87, 0x6f, 0x26])
    jp(0xeda7, H['vz_leaf_ovl'], [0x3d, 0x6f, 0x26])
    jp(0xee25, H['vz_leaf_mask'], [0x3d, 0x87, 0x87])
    jp(0xd4d8, H['vz_sprhook'], [0xd9, 0x29, 0x29])
    jp(0x608f, H['vz_print'], [0xcd, 0x03, 0x61])
    jp(0x60b0, H['vz_printbig'], [0xcd, 0x03, 0x61])
    jp(0x5df6, H['vz_cls_play'], [0xaf, 0x08, 0x21])
    jp(0x5e14, H['vz_cls_bottom'], [0x21, 0xc0, 0x50])
    jp(0x5e0b, H['vz_cls_hi'], [0x21, 0x08, 0x40])
    jp(0x605d, H['vz_chr'], [0x06, 0x08, 0x1a])
    jp(0x606c, H['vz_chr'], [0x06, 0x08, 0x1a])
    put(0xbb64, [0], [0x12]); put(0xbb66, [0], [0x12])
    put(0xdf39, [H['vz_fixhl'] & 255, H['vz_fixhl'] >> 8], [0xe0, 0xe4])
    put(0xdf91, [H['vz_fixhl'] & 255, H['vz_fixhl'] >> 8], [0xe0, 0xe4])

    # ---- DOS bank 0: hot code, relocated block, text grid, Spectrum 5B00-67FF ---------
    dos0 = bytearray(m[0x4000:0x6800])
    for i in range(0x4000, 0x4791): dos0[i - 0x4000] = 0
    for i in range(0x5800, 0x5b00): dos0[i - 0x4000] = 0x20
    dos0[0:len(hot)] = hot
    for a in range(0x6ffd + REL, 0x70e0 + REL):   # the Spectrum tape loader (only its entry is used, patched)
        if a not in PATCHED: dos0[a - 0x4000] = 0
    assert len(hot) <= 0x791
    # internal + expansion bank 0: Spectrum 7800-FFFF, old back buffer cleared
    main = bytearray(m[0x7800:0x10000])
    for i in range(0x9f00, 0xb500): main[i - 0x7800] = 0
    # Spectrum-only graphics and the routines the VZ replaced: never read on the VZ
    # (found with read/exec maps over all islands; see ANALYSIS.md, Phase 3)
    for a, b in [(0x823a, 0x97c0),      # left over below the island load address (title music 8000-8239 kept)
                 (0xd8a2, 0xde92),      # common sprite pixels (VZ has its own frames)
                 (0xf700, 0xfcf2),      # tile/rainbow/item pixels
                 (0xe5e3, 0xe830),      # Spectrum screen copy
                 (0xe870, 0xeb05),      # Spectrum sprite blitter
                 (0xedb5, 0xee30),      # Spectrum char renderers (leaf routines)
                 (0xb800, 0xb900),      # IM2 vector table (rebuilt by vzboot)
                 (0xc338, 0xc3f8),      # sprite tables read only by the Spectrum blitter
                 (0xd662, 0xd6f2),      # more common sprite pixels
                 (0xf322, 0xf352)]:     # blitter table
        for i in range(a, b):
            if i not in PATCHED: main[i - 0x7800] = 0
    main[0xdc22 - 0x7800:0xdc22 - 0x7800 + len(ex0)] = ex0

    # ---- island data files (SD card) -------------------------------------------------
    m00 = open('/home/claude/emu/cap/m00a.bin', 'rb').read()
    ovl = art(m00)
    frames, recs, boss = sprites()
    common = sorted({fi for (de, x0, y0, tw, fi) in recs.get(None, [])})
    files = []                       # (name, data, ftab entry)
    for k in ISLANDS:
        # VZ art blob at ISLART: base tiles, sprite records, boss pieces, frames
        I = Island(k)
        bt = []
        for c in range(256):
            bt += enc_tile(I.tile(c)) if (c & 0x7f) < len(I.chars) else [0xaa] * 3
        mine = sorted({fi for (de, x0, y0, tw, fi) in recs.get(k, [])})
        p = sorted(boss.get(k, []))[:2]
        A = ['        DEVICE NOSLOT64K', f'        org 0x{ISLART:04x}', 'art:'] + dbl(bt)
        A += ['        dw recs',
              f'        dw {"fr%d" % p[0][1] if p else 0},{"fr%d" % p[1][1] if len(p) > 1 else 0}',
              f'        db {(p[0][2] + 1) // 2 if p else 0}']
        for fi in mine:
            A += [f'fr{fi}:'] + dbl(frames[fi])
        A += ['recs:']
        for (de, x0, y0, tw, fi) in sorted(recs.get(k, [])):
            A += [f'        db {de & 255},{de >> 8},{x0},{y0},{tw}', f'        dw fr{fi}']
        A += ['        db 0,0', 'art_end:', f'        ASSERT art_end <= 0x{ARTPACK:04x}',
              f'        SAVEBIN "out/art{k}.bin",art,art_end-art']
        open(f'{HERE}/out/art{k}.asm', 'w').write('\n'.join(A) + '\n')
        run(['sjasmplus', '--nologo', f'out/art{k}.asm'])
        za = zx0(open(f'{OUT}/art{k}.bin', 'rb').read(), f'artz{k}')
        za = za + bytes(-len(za) % 512)                    # the island block starts on a sector
        assert len(za) <= SAVESYS - ARTPACK, (k, len(za))
        # island block with the Spectrum pixels zeroed (tile chars + sprite sources; see strip.py)
        blk = open(f'/home/claude/p2/strip/tb{6 + 2 * k:02d}.bin', 'rb').read()
        zb, delta = zx0d(blk, f'isl{k}')
        assert delta <= 32
        dest = 0x97c0 + len(blk) + 32 - len(zb)             # packed at the end: unpacked in place
        name = f'RISLAND{k + 1}'
        files.append((name, za + zb, (name, len(za), ARTPACK, MAP_E1, len(zb), dest, 0, 1)))
    # the ending block (tape index 7), Spectrum picture removed
    eb = bytearray(open('/home/claude/emu/tb20.bin', 'rb').read())
    def ep(a, bs, orig):
        o = a - 0x97c0
        assert bytes(eb[o:o + len(orig)]) == bytes(orig), hex(a)
        eb[o:o + len(bs)] = bytes(bs)
    for i in range(0, 0xa130 - 0x97c0): eb[i] = 0          # packed Spectrum picture
    w = lambda v: [v & 255, v >> 8]
    ep(0xa66c, [0xc3] + w(H['vz_endpic']), [0x21, 0x00, 0x58])      # picture -> VZ rainbow
    ep(0xa601, [0xc3] + w(H['vz_endfade']), [0x16, 0x08, 0x01])     # fade -> pause + clear
    ep(0xa21f, [0xc9], [0x21])                                      # attribute clears
    ep(0xa133, [0x3a, 0xac, 0x69 - 0x20], [0x3a, 0xac, 0x69])      # big diamonds: moved block
    ep(0xa16b, [0xcd] + w(H['vz_cls_play']) + [0x18, 0x0f], [0x21, 0x00, 0x40, 0x11, 0x01])
    ze, delta = zx0d(eb, 'ending')
    assert delta <= 32
    files.append(('RIENDING', ze, ('RIENDING', len(ze), 0x97c0 + len(eb) + 32 - len(ze), 0, 0, 0, 0, 0)))
    for name, data, ent in files:
        open(f'{OUT}/{name}.DAT', 'wb').write(data)
    # ---- bank 1: VZ display code + common data ------------------------------------------
    L = ['FTAB:']                        # per file: "NAME", len1, dest1, port1, len2, dest2, port2, art
    for name, data, (nm, l1, d1, p1, l2, d2, p2, a) in files:
        L += ['        db ' + ','.join(str(b) for b in b'"' + nm.encode() + b'"'),
              f'        dw {l1},{d1}', f'        db {p1}', f'        dw {l2},{d2}', f'        db {p2},{a}']
    L += [f'OVL_LEN equ {len(ovl)}', 'ovl_data:'] + dbl(ovl)
    L += animtitle.data(FILENUM, ISLANDS)
    L += ['endpic:'] + dbl(zx0(endpic.picture(), 'endpic'))
    mus = m[0x8000:0x823a]
    L += [f'MUSICLEN equ {len(mus)}', 'musicdata:'] + dbl(mus)
    L += ['frames:']
    for fi in common:
        L += [f'fr{fi}:'] + dbl(frames[fi])
    L += ['spr_common:']
    for (de, x0, y0, tw, fi) in sorted(recs.get(None, [])):
        L += [f'        db {de & 255},{de >> 8},{x0},{y0},{tw}', f'        dw fr{fi}']
    L += ['        db 0,0']
    open(HERE + '/b1data.inc', 'w').write('\n'.join(L) + '\n')
    run(['sjasmplus', '--nologo', '--raw=b1.bin', '--sym=b1.sym', 'b1.asm'])
    b1 = open(HERE + '/b1.bin', 'rb').read()
    B1 = syms(HERE + '/b1.sym')
    print('hot', len(hot), 'bank1', len(b1), 'ends', hex(0xb800 + len(b1)),
          'files', [(n, len(d)) for n, d, e in files])
    assert 0xb800 + len(b1) <= ISLART

    # ---- pack ---------------------------------------------------------------------------
    TAIL = 32
    zmain = zx0(main[:-TAIL], 'main')
    zdos0 = zx0(dos0, 'dos0')
    zb1 = zx0(b1, 'b1')
    tail = bytes(main[-TAIL:])
    return dict(zmain=zmain, zdos0=zdos0, zb1=zb1, tail=tail, H=H, B1=B1)


def zx0d(data, name):
    """zx0 with the in-place delta it reports"""
    p = f'{OUT}/{name}.bin'
    open(p, 'wb').write(bytes(data))
    r = subprocess.run(['zx0', '-f', p, p + '.zx0'], capture_output=True, text=True, check=True)
    import re
    dl = int(re.findall(r'delta (\d+)', r.stdout + r.stderr)[0])
    return open(p + '.zx0', 'rb').read(), dl


def link(parts):
    H = parts['H']
    open(OUT + '/p_b1.zx0', 'wb').write(parts['zb1'])
    open(OUT + '/p_dos0.zx0', 'wb').write(parts['zdos0'])
    open(OUT + '/p_tail.bin', 'wb').write(parts['tail'])
    open(OUT + '/p_main.zx0', 'wb').write(parts['zmain'])
    open(HERE + '/linkdefs.inc', 'w').write(
        f"VZBOOT equ 0x{H['vzboot']:04x}\nMAINLEN equ {len(parts['zmain'])}\nB1_DOSMODE equ 0x{parts['B1']['dosmode']:04x}\n")
    run(['sjasmplus', '--nologo', '--raw=out/RAINBOW.bin', 'stub.asm'])
    body = open(OUT + '/RAINBOW.bin', 'rb').read()
    name = b'RAINBOW ISLANDS\0\0'
    vz = b'VZF0' + name[:17] + bytes([0xf1]) + struct.pack('<H', 0x7ae9) + body
    open(OUT + '/RAINBOW.VZ', 'wb').write(vz)
    print('RAINBOW.VZ', len(vz), 'bytes; load 7AE9-%04X' % (0x7ae9 + len(body) - 1))


if __name__ == '__main__':
    link(build())
