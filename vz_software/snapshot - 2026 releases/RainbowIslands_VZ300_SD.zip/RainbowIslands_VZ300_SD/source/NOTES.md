# Rainbow Islands (Spectrum) engine analysis - working notes (2026-10-23)

Tools: emu/spec2 (snapshots SNAP=, save/prof/exec/rmap/wmap/ports, CALLF=frame call trace),
tools/z80dis.py (disassembler), tools/memclass.py, tools/anal.py.
Snapshots: emu/title.snap (after island-1 load), menu.snap (title), round1.snap (round 1 start).
Controls in original: K left, L right, A up/jump, Z down, SPACE/M/N/B fire; ENTER = coin, SPACE = start.
Launch: TAP=tape BIN=a37a,blk4.bin,a37a STARTBLK=5 ./spec2 script

## Tape
blk4 23808 bytes packed, loaded at A37A, unpacks to 5B00-FFFF. Islands: 5-byte hdr (index,len..) + data
loaded at 97C0 (hdr at 97B8, index checked vs (5B00)). Island index 7 (8163 b) = ending, code at A130
(fe44: after round 28 -> load 7, call A130). 128K mode pages islands into banks (OUT 7FFD @74B4-74D5, 774C).

## Flow
fe01 DI, SP=FDFD; fe08 6375 (game init) 63b0 5db3 6412 6443 5ee8 5c4c EI; loop bf11 5e3a 5c07 5bdc.
c0b3&3: bit0 died (6370 lives), else round clear -> inc 636f (round 0..27).
IM2: I=B8, table B800-B900 = FD -> FDFD: jp FE93 = whole game frame (guard be80>=3).
FE93 calls: bab9 b90e(input) c091 c0ab bb2f bb19 c1f6 c0b7 be36 be90 eea5 5c68 e008 dffd de94 c70b c3f8
d443(object loop, ix=6D3A+32n, cafb script interp, 605c=jp(hl) via 5f40) eb88(map stream + row render)
5c61 e5e3(display) 5c68 5c4c. Measured 315 game frames / 1000 ints = ~15.7 Hz.

## Display (replace)
Back buffer 9F00-B4FF (32 x 176 lines, circular), attr buffer B500-B7FF. Row renderer ecd9/ed9f from
map buffer 7100-7FFF + tile gfx (F600-FCxx common, island tiles). e5e3: copy buffer->screen via SP
(e74a unrolled, ~49% CPU), masked sprites onto screen e870-e9f3 (pre-shifted data 8000-9EFF, mirror table),
attrs B500->5840. Text: 605d (bold) / 606c via 608b.

## Hardware touchpoints
IN FE: b917 b932 b93a (input b90e), 5bde 5c0c 5c2d 5c3b (keys), 5d16 (title); IN 1F: 5d41, b928.
OUT FE: f1d2 f1d8 (SFX f127), 8105 8112 (title music 8000-812E), 7405 (loader).
ROM: 70f9 call 0562 (LD-BYTES). SMC jp 0000 placeholders at 6f8b e7c7 e8ac.

## Memory classes (play)
code 5B00-6FFF (mixed data/vars), loader 7000-70FF, map buf 7100-7FFF, island expand 8000-9EFF,
back buf 9F00-B7FF, IM2 table B800, code B900-D5FF, buf D600-DAFF, data DC00-DDFF, code DE00-F1FF,
data F200-FDFF, code FE00-FFFF.
VZ conflict: Spectrum 6800-77FF (VZ latch 6800-6FFF + VRAM 7000-77FF) must be relocated.

## Sizes (ZX0)
load-time image excl. island/screen 33,984 -> 17,796. Islands (already packed) 5.1-6.0K each, ending 5.2K.

## BennVenn (MAME sdloader.cpp)
port 37h: b0 DOS ROM/RAM, b1 DOS RAM bank, b2 exp bank, b3 LED. DOS window 4000-67FF (2 RAM banks).
Expansion 2 banks; VZ300 mode only B800-FFFF visible (18K each). 3Ah mode.

## Phase 1 (2026-10-23) - art pipeline in /home/claude/p1
Decision (user): 2:1 across, 8:3 down (VZ pixel = 2x3 Spectrum px), tiles 4x3, HUD as MODE(0) text row.
Sprites: object table 6D3A+32n; d49f builds records; gfx ptr from D5FA slot table (0-21 common D662-DE91,
22-43 island 9578+, boss slots via e535 = 2x doubled enemy). Slot data = rows of (mask,gfx) pairs, odd rows
reversed+bit-mirrored (zigzag). Obj fields: +2 w bytes, +3 h, +6 subx(top3 bits), +7 col, +8 (top2 bits)/+9 y,
+10 b0 flip. Screen y = (ix9-be7e)*8 + (ix8>>6)*2.
Tiles: back buffer row = page (9F00+row*256+col), playfield line y = BB line (be8e+y)%176. Base char via edb5
(8000+c*8, bit7 mirror), opaque overlay eda7 (F700+(a-1)*8), masked overlay ee25 (F600 16-byte), attr ed9f.
Rainbow = overlay chars 1-18 in 6x4 template RB_T. Items = 4-char groups from 0x17. 0a=G, 0b-0d = markers 1-3.
Scripts: extract_spr.py, dedupe.py, assets.py, vzconv.py, mock.py, sheets.py, sheet_tiles.py, memsize.py, bubart.py.
Start any round: SNAP=title.snap, key SP at 5, at 100 poke fe08-fe0a 0, 636f=round, 636e=254, load tbNN at 97c0, pc fe0b sp fdfd.
Boss: poke be36 201, be7f 252 each frame, pokerel 6d63,be7e 8.
Sizes: VZ art ~0.6K zx0 per island; island maps+layouts w/o Spectrum gfx 0.8-1.4K zx0; all 7 ~12K.

## Phase 2 display (2026-10-23)
b1 display draws straight to VRAM after FS start: full copy when the top ring line changes, else DIRTY rows
(set by cellad in the leaves) + erase of last frame's sprite rects (OLDSPR) then sprites to VRAM. vz_sprhook
returns early (no Spectrum sprite records). Game frame now every 3 fields ~85%, 4-5 otherwise.
Bug fixed: DUP LDI loops must not keep a counter in B (LDI decrements BC). Verify: dump + /tmp/claude-0/chk.py
(VRAM vs ring outside sprite rects; dumps taken while display waits for FS show the previous start).
Rainbow: last VZ line of the legs dropped (stray green pixel from ragged Spectrum lines 29-30).

## Phase 3 (2026-10-23) - memory, parts, title, intros, ending
Island block (97C0): 6 section lengths, 128 B -> F280, byte -> 6357, sections (sec0 = 8x8 chars -> 8000),
then map struct X (66A1 copies X[20..28) to RAM, 6709 decodes bitstream at X[28]), sprite descriptors
(w,h,src,mask; FF) at X+X[30]+1, then sprite pixels (copied by 6F31). VZ never needs sec0 or the pixels:
p2/strip/tbNN.bin zero them (engine state identical in harness except timing). Level data itself is
~4-4.8K zx0 per island, so the full game cannot fit one 31.2K .VZ: four parts (FILES in build.py):
RAINBOW1 islands 1-2, 2: 3-4, 3: 5-6, 4: 7 + ending. Part end: FE41 cp ENDROUND, FE44 -> vz_fileend.
Main image: zeroed 823A-97BF, D8A2-DE91, F700-FCF1, replaced display/blit/leaf code (PATCHED kept).
Title: original 5C92 loop; page 1 (5CB1) = VZ MODE(0) screen (titlescr.py); music 8000-8239 via vzspk.
Start: 5D41 -> vzinput&18 (fire/jump), coin = RETURN. Island intro 5DDF -> boss portrait (2 pieces).
Text rows 2-21 -> playfield lines 6 + (row-2)*45/16. Ending: tb20 at 97C0, A66C/A601/A21F/A16B patched,
A133 ld a,(69AC) -> 49AC (moved block!), VZ rainbow picture endpic.py.
Title (rev 2): the first version's animated MODE(0) logo (animtitle.py + oldtitle/design.py), 32 frames composed
by b1 'title' into RAM free on the title (9F00/8240/7800, rows at 7A00; V_ISLAND=FD forces an island reload).
Driven by ex0.asm at DC22 (EXP0; D662-DAE1 is written by eb88 during play, DC22-DE91 is not): the music's two
delay loops (80FC, 810A) and the 5CF7 wait call tdel, which spends exactly the original T-states while copying
8-byte units into VRAM (92% of half-waves identical to the original, the rest within ~10-300 T).
Limits: stub asserts img_end <= F480 (.VZ <= 31,151 bytes); part 2 is 31,069.

## SD edition (2026-10-25) - /home/claude/p3
13 Ghosts (13GHOSTS.VZ, loader at D000) shows the BennVenn DOS file API: (FB80)=F800, A=1, call 5F00
(HL -> "NAME" in quotes; NAME.DAT on the card), ok if (FB03)=1 and (FB05)<>1; A=1, call 5F03 -> first
512 bytes at F800; then (FB80)=buf, call 5F09 -> next 512 bytes at buf. DOS window mode found by testing
5FFF for RAM (port value 0 or 1, expansion bank 0). It loads only at boot, into DOS RAM bank 1 / RAM, and
never touches DOS RAM bank 0 or E420.. etc. (13GHOST1 -> DOS1 4000 10240 bytes, 13GHOST2 -> 7AE8, 13GHOST3
-> E420, then port 3, jp E420).
SD edition: VZ code moved to DOS RAM bank 1 (MAP_E0=03, MAP_E1=07), bank 0 never touched. RAINBOW.VZ
(21.4K) + RISLAND1-7.DAT (VZ art padded to 512, then the packed island block) + RIENDING.DAT. vz_island
(6FFA) loads the file at run time: loader.asm copied to VRAM 7600 (stack below it, sector buffer 9F10);
for the call it swaps EXP0 EE00-FFFF with the DOS workspace copy taken at boot (EXP1 EE00-FFFF) and
7800-7AE8 with the saved ROM system variables (EXP1 E600), IM 1 while the DOS runs. Island block is
loaded at its in-place position (97C0+L+32-P) and unpacked to 97C0; art to EXP1 E000 -> ISLART D800.
Emulator: vzemu emulates 5F00/5F03/5F09 (SDDIR) and checks workspace/sysvar signatures. poke0 = EXP0 poke.
Also: title arc phase bug (jr nc,$+4 -> $+3), title tune restored from b1 copy before each title (5C8F=0),
rising water drawn from (E5E2) (original display variable) as green surface + green/blue shimmer.
Pitfall: never push/pop or call across an EXP bank switch - the stack (FDxx) is in the banked area.
