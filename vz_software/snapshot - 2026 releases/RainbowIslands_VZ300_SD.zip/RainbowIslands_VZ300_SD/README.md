# Rainbow Islands – The Story of Bubble Bobble 2
### Dick Smith VZ300 conversion – SD card edition (BennVenn SD loader + 128K RAM)

![Title screen](screenshots/00_title_animated.gif)

The arcade game is © 1987 Taito Corporation. The ZX Spectrum version is by Graftgold and was published by Ocean in 1989. This is a fan conversion made from the Spectrum tape. It is not for sale.

The VZ version runs the **original Spectrum game code**. Bub, the enemies, the rainbows, the islands, the scoring, the bosses, the rising water and the ending all behave as they did on the Spectrum. Only the hardware parts were replaced: screen, keyboard, joysticks, sound, timing and loading. The game is drawn with its own graphics for the VZ's 128×64 four-colour screen, at true Spectrum proportions.

---

## What's in the zip

| File | Contents |
|---|---|
| `RAINBOW.VZ` | The game: engine, title, sound, common graphics (21 KB) |
| `RISLAND1.DAT` … `RISLAND7.DAT` | One file per island: its maps and its VZ graphics |
| `RIENDING.DAT` | The ending |
| `rainbow_title_music.wav` | The title music, recorded from the emulated VZ speaker |
| `screenshots/` | Screens captured from a VZ300 emulator |
| `four_part_version/` | The older four-file version, which needs no data files (see below) |
| `source/` | Z80 source and the conversion scripts |

### How the islands load
The whole game is too big for one `.VZ` file. The BennVenn loader takes about 31,200 bytes, and the seven island files alone come to about 39 KB. So this edition works like the Spectrum's 48K version, which loaded each island from tape as you reached it. Here, `RAINBOW.VZ` loads each island's file from the SD card when you reach it. Loading takes about a second, and the bottom few lines of the screen flicker while it happens.

The file reading uses the BennVenn DOS calls in the same way the VZ game **13 Ghosts** uses them to load its data files.

---

## What you need

* A Dick Smith VZ300 (or a VZ200 with the same expansion)
* The BennVenn SD card loader with its 128K RAM
* Optional: one or two VZ joysticks

## Loading

1. Copy `RAINBOW.VZ`, `RISLAND1.DAT` … `RISLAND7.DAT` and `RIENDING.DAT` to the SD card, all in the same folder.
2. Load `RAINBOW.VZ` from the BennVenn menu.
3. The animated title appears and the Spectrum title music plays.

If an island file can't be read, the game says so and waits. Fix the card, then press fire to try again.

> **Please test on real hardware.** This edition has only been tested in a VZ300 emulator that imitates the BennVenn DOS calls the way 13 Ghosts uses them. 13 Ghosts loads its files once at start-up. This game also loads while it is running. It sets the machine back up the way the DOS saw it at start-up before each load: the DOS's working memory, the ROM's system variables, and its own RAM bank, which the game never touches. Even so, this is the part most likely to need fixing. If island loading fails on your VZ, use the four-part version meanwhile.

---

## Controls

**Keyboard**

| Key | Action |
|---|---|
| `Z` or `,` | Move left |
| `X` or `.` | Move right |
| `M` or `Q` | Jump |
| `A` | Down (drop through / break the rainbow you stand on) |
| `SPACE` | Fire a rainbow |
| `RETURN` | Add a credit (the Spectrum's ENTER/coin key) |
| `P` | Pause. While paused, `Q` quits to the title; fire or `P` carries on |
| `S` | Sound on/off |

**Joysticks** (either stick, or both)

| Control | Action |
|---|---|
| Left / Right | Move |
| Up | Jump |
| Down | Down |
| Fire | Fire a rainbow |
| Arm button | Jump |

## Starting a game

The title gives you one credit, so **fire** (or `SPACE`) starts straight away. When you lose your last life the game offers a **continue** if you have credits left. Press `RETURN` to add credits, as with the coin key on the Spectrum.

If you wait on the title, it shows the credits page and the high-score table, then comes back round. The title music plays again every time you return to the title.

## The game

Climb each island by firing rainbows. Use them as bridges and to trap the enemies. Don't take too long, or "HURRY!" appears and the water starts to rise. Round 4 of every island has the island's boss, shown on the island's intro screen. Collect the seven big diamonds for the better ending.

The islands:
1. Insect Island
2. Combat Island
3. Monster Island
4. Toy Island
5. Doh's Island
6. Robot Island
7. Dragon Island

---

## The four-part version
`four_part_version/RAINBOW1.VZ` … `RAINBOW4.VZ` need no data files. Each holds two islands; part 4 holds Dragon Island and the ending. Each part is a complete game, and score doesn't carry between parts.

It has the corrected title animation. It does not have the rising water, and the title music doesn't replay after a game, because those no longer fit in its files.

## Known limitations

* **Jingles:** the Spectrum's island and game-over tunes exist only in its 128K version, as music-chip tunes. This conversion has the 48K beeper title music and all the sound effects.
* **Cramped text:** the Spectrum's 22 rows of text share the VZ's 58 playfield lines, so long messages such as the ending story are tightly packed.
* **Water colour:** the rising water is green and blue, because the VZ has no cyan in this screen mode.

---

## How it works

For the technically curious; details are in `source/NOTES.md`.

* **The engine:**
  * The Spectrum game image is unpacked with its original code intact.
  * One block that collides with the VZ's video RAM and keyboard area is moved down by 2000h, and every reference to it is patched.
  * The VZ's own code lives in BennVenn DOS RAM bank 1. Bank 0 is left to the DOS.
* **Replaced routines:** the screen copy, sprite drawing, character drawing, keyboard, joystick, beeper and tape loader are replaced by VZ routines.
* **Display:**
  * The VZ display keeps its own tile buffer. The engine's own row-drawing routines update it.
  * It is drawn straight to video RAM during vertical blank, redrawing only the changed rows and the sprites.
  * The water is drawn from the same variable the Spectrum's display used.
* **Speed:** the game runs at about the Spectrum's speed, one game frame every three TV fields.
* **Island loading:**
  * The tape loader's entry point now reads `RISLANDn.DAT` from the SD card. The read is done by a small routine copied into video RAM, because the DOS takes over the 4000–67FF window while it reads.
  * The island's maps arrive compressed (ZX0) and are unpacked in place. The Spectrum pixel graphics have been removed from them; the VZ uses its own.
* **Title:** the animated MODE(0) title shares the CPU with the Spectrum title music. The music's timing loops spend their waiting time copying animation frames, taking exactly as long, so the tune keeps its pitch.

### Rebuilding
`source/vz/build.py` builds `RAINBOW.VZ` and the data files. It needs the original Spectrum tape image (not included), `sjasmplus` and `zx0`.

---

*Rainbow Islands is a trademark of Taito Corporation. This conversion is a non-commercial fan project.*
