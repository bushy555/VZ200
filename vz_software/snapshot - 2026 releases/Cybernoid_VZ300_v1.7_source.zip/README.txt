CYBERNOID - THE FIGHTING MACHINE  -  VZ300 conversion
(from the ZX Spectrum version, Hewson 1988, by Raffaele Cecco, music by Dave Rogers)
=====================================================================================

FILES  (copy to the ROOT of the SD card)
  CYBRNOID.VZ     the whole game in one file (v1.7, 24.9K, loads at $8000-$E39B).
                  No .DAT files are needed: everything (all 3 levels, 75 rooms,
                  graphics, sound effects, the music driver and its tunes)
                  unpacks from this one file with ZX0 at start-up, so the
                  13 Ghosts data-file loading isn't used.
  Then:  LOAD"CYBRNOID"   (or pick it from the SD loader menu)

REQUIREMENTS
  VZ300 + BennVenn SD loader with the 128K RAM expansion.

CHANGES IN v1.7
  * Joystick buttons fixed: on both joysticks FIRE is the laser and ARM is
    the special weapon. (v1.2-v1.6 read joystick 1's ARM as FIRE and
    joystick 2's FIRE as ARM.)

CHANGES IN v1.6
  * The living, rippling biomass now runs behind every front-end screen:
    HALL OF FAME, GAME OVER, CONGRATULATIONS (name entry) and the depot
    report, as well as the title (the bubbles are gone). The music tempo
    is compensated per screen (all within 0.2% in the emulator).

CHANGES IN v1.5
  * Title: the biomass background is now alive - a smooth "depth" map of the
    flesh is coloured through a slowly rotating red / magenta / blue cycle,
    so veins swell out of the dark, roll across the screen and sink back,
    growing and shrinking a quarter-cell at a time. It runs alongside the
    music: the background is redrawn a quarter of the screen per music step
    and the player gives up exactly that much time, so the tempo is
    unchanged (checked in the emulator: 300 music steps in 299 frames).
  * No more white or orange in the backgrounds: the bubbles on the other
    screens now swell and burst in magenta, red and blue.

CHANGES IN v1.4
  * The depot report at the end of each level (WELL DONE CYBERNOID PILOT /
    YOU HAVE FAILED...) now uses the bubbling biomass background with the
    thin black border and outlined cyber lettering, like the other screens.
    (Its yellow frame, stars and flying ship are gone.)

CHANGES IN v1.3
  * The GAME OVER, CONGRATULATIONS (name entry) and HALL OF FAME screens use
    the bubbling biomass background too, instead of the yellow girder frame.
  * The black border round these screens and the title is now a thin line,
    and the logo no longer sits on a black box: every letter has a thin black
    outline, so the biomass shows above the logo and around the letters.
  * Logo lettering is now cyber chrome: white, cyan and a blue underline.

CHANGES IN v1.2
  * FIRE now fires the laser only. The special weapons are used with the
    joystick ARM button or M (the Spectrum used "hold fire").
  * New title screen (see below); cyber-coloured lettering on all screens.
  * (M on the title screen now only toggles the music; before, it also
    counted as FIRE.)

LOADING (v1.1 - fixes v1.0 not booting)
  v1.0 loaded right up to $F9FF, switched the BennVenn mapper to 3 and ran
  its unpacker from video RAM - the same combination that reset your
  machine with Xevious v1.0. v1.1 boots the way Xevious v1.2 does:
  * it loads low, at $8000-$E251, like an ordinary program;
  * nothing runs from video RAM;
  * it doesn't switch the BennVenn mapper. Cybernoid needs more memory than
    $7800-$FFFF, so it also uses the SRAM at $4000-$67FF exactly as the DOS
    leaves it mapped (mapping 1, the one that tested writable on your
    machine). It checks this first: if that RAM isn't writable it sets
    mapping 1 itself and checks again, and if it still isn't writable it
    shows "CYBERNOID NEEDS THE BENNVENN RAM AT 4000-67FF..." instead of
    crashing - please tell me if you see that.
  This overwrites the DOS's copy of itself in that SRAM and its work area at
  $FA00-$FFFF (neither is needed once the game has loaded), so press RESET
  to get back to the SD loader. If the loader doesn't come back after a
  reset, switch off and on.

CONTROLS
  Keyboard      O left,  P right,  Q thrust (up),  SPACE fire (laser only)
                M  use the selected special weapon (hold for more)
                1-5  select weapon: bombs, mines, shield, bounce, seeker
                H  pause (any key resumes)      CTRL+Q  quit to the title
  Joysticks     both VZ joysticks: directions, FIRE = laser,
                ARM = special weapon (choose the weapon with keys 1-5).
  Title screen  FIRE / SPACE / RETURN / 1 starts
                M  music on/off     S  sound effects on/off
                J  joysticks on/off  (the current setting is shown on the
                   bottom line; it also shows the keys and credits in turn)
                The title and the hall of fame alternate.
  Name entry    type your name (8 letters), CTRL deletes, RETURN ends.

WHAT'S IN IT
  * The original Spectrum game code runs unchanged: all 3 levels, 75 rooms,
    the depot at the end of each level (cargo quota 1500 in the time
    allowed), extra lives, all five special weapons, the enemies, the
    scoring and the hall of fame.
  * Replaced with VZ code: block and sprite drawing (mode(1) 128x64, 4
    colours), the status panel, keyboard and joysticks, the speaker effects
    and music, the front end, the depot report and the hall of fame.
  * Scaling is 2:1 across and 8:3 down (true Spectrum proportions). The
    playfield is the Spectrum's full 160-line game window; the status panel
    is a 4-line red bar with lives, score, cargo, weapon, ammo and the time
    bar.
  * Artwork, checked object by object against the Spectrum original. Colour
    language: Spectrum black = blue, white/lit surfaces = yellow,
    cyan and green = green, magenta/red and shadows = red.
    - The organic "biomass" walls are no longer drawn tile by tile: the VZ
      draws one seamless vein texture across every room (it repeats every
      4x3 blocks), so the walls look like one living mass instead of
      2:1/8:3 scaled noise. The tendrils at its edges are converted with the
      thin lines kept.
    - Hand-drawn at VZ resolution: yellow girders (lit top, red shadowed
      underside, rivets and windows), the white/cyan pipe corners, capsule
      ends, bolts and vertical pipes, the cyan/green pillars (lit band, body
      and a dithered shadow side - Spectrum dithers stay dithers), circuit
      panels, green X-girders and grilles, the magenta machinery, spikes and
      drills, the white drips, the sphere, and the yellow dish turret.
    - Sprites are hand-drawn: the Cybernoid ship (yellow hull, green deck),
      the four-way pods, dart fighters, dome walkers, robots, the cargo
      crystal, the 4-stage explosion, missiles, bombs, sparks and debris.
  * Screens (mode(0), semigraphics):
    - Title: neon "cyber" CYBERNOID logo (white-cyan-magenta-blue) with a
      light glint sweeping across it, on black inside a black screen border,
      over a boiling biomass background (magenta and red veins, like the
      game's organic walls) where bubbles swell, burst and close again; a
      flashing PRESS FIRE line and a rotating info line. The other screens'
      lettering uses the same cyber colours.
    - Hall of fame, game over (GAME OVER in the logo lettering), name entry
      with a flashing cursor, and the depot report ("WELL DONE CYBERNOID
      PILOT! ... BONUS POINTS." / "YOU HAVE FAILED TO RETRIEVE ...") with
      your score - all animated the same way.
  * Music: the 128K version's AY music driver and Dave Rogers' tunes run
    unchanged; each 50 Hz step the driver's AY registers are turned into
    three speaker voices: true pitch from the AY periods (so the vibrato,
    slides and arpeggios come through), pulse-interleaved mixing, pulse width
    following the AY volume (notes decay), and the AY noise played as short
    drum bursts. Title / hall of fame: the main theme. Game over and a
    failed level: the game-over tune. Hall of fame entry and a completed
    level: the congratulations tune.
  * Sound effects: the 48K version's beeper effects, unchanged, on the VZ
    speaker. As on the 48K Spectrum there's no music during play.
  * Speed matches the Spectrum: the game runs at 25 frames a second
    (measured in the emulator: 1496 of 1499 game frames on time).

KNOWN LIMITS / THINGS TO CHECK ON REAL HARDWARE
  * Tested in an emulator model of the VZ300 + BennVenn (load, title, all 3
    levels, depot reports, game over, name entry, hall of fame, pause, quit
    and weapon keys), with memory guards: no Spectrum code writes over the VZ
    code. Not yet run on a real VZ300.
  * The hall of fame is kept until reset (no save).
  * The original "define keys" menu isn't included; Kempston/Interface 2
    options are replaced by the VZ joysticks.

BUILDING (source zip)
  python3 tools/build.py   (needs sjasmplus, zx0 and the ZX0 z80 decoders in
  /tmp/ZX0/z80). Steps: prep.py relocates the Spectrum code that sat on the
  VZ video/latch area ($67EE-$7813 -> $D600), gen.py makes the VZ graphics
  (blkhand.py / sprhand.py hand art, biotex.py biomass texture, conv2.py for
  the rest), screens.py the mode(0) screens, then vz.asm is assembled and
  package.py builds CYBRNOID.VZ.  emu/vzemu.c is the test emulator.
