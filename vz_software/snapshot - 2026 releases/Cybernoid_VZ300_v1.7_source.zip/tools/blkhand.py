"""Hand-drawn VZ blocks (8x6, mode(1) CSS0).  '.' blue (= Spectrum black),
G green, Y yellow, R red.  Colour language: white/lit -> Y, cyan/green -> G,
magenta/red and shadow -> R, dithers stay dithers."""
C = {'.': 2, 'G': 0, 'Y': 1, 'R': 3}
def T(*rows):
    assert len(rows) == 6, rows
    for r in rows: assert len(r) == 8, (r, rows)
    return [[C[c] for c in r] for r in rows]

H = {}
# ---- yellow girders
H[0x14] = T('YYYYYYYY',
            'Y.Y.Y.Y.',
            'YYR.R.YY',
            'YY.R.RYY',
            'RRRRRRRR',
            '.R.R.R.R')
H[0x15] = T('Y.YYRR.R',
            'YY.YR.RR',
            'Y.Y.R.R.',
            'YY.R.RRR',
            'Y.YR.RR.',
            'YY.YR.RR')
H[0x96] = T('YYYYYYYY',
            'Y.YYYR.R',
            'YYY.R.RR',
            'Y.YYRR.R',
            'YYY.R.RR',
            'Y.YYRR.R')
H[0x99] = T('Y.YYYR.R',
            'YYYYRRRR',
            'Y.YR.R.R',
            'YYYYRRRR',
            'Y.YR.R.R',
            'YYYYRRRR')
# ---- yellow/white bolt on pipes
H[0x18] = T('........',
            '...YYY..',
            'Y.YYYY.Y',
            'R.RRRR.R',
            '..RRRR..',
            '........')
# ---- white/cyan fan corners
H[0x10] = T('.....GG.',
            '...YGGG.',
            '..YYG.G.',
            '.YYYGGG.',
            '.Y.YGGGG',
            'YYYYGGG.')
H[0x11] = T('YYY.....',
            'YYYYG...',
            'YYYYGG..',
            'YY.YGGG.',
            'Y.YYGGG.',
            '.YYYGGG.')
H[0x12] = T('YYYYGGG.',
            '.YYYGGG.',
            '..YYG.G.',
            '...YGGG.',
            '....GGG.',
            '.....GG.')
H[0x13] = T('.YYYGGGG',
            'YYYYGGG.',
            'Y.YYG.G.',
            'YY.YGG..',
            'YYYYG...',
            'YY......')
H[0x48] = T('..YYGGG.',
            '.YYYGGG.',
            '.YYYG.G.',
            '.YYYGG..',
            '.YYY.GG.',
            '.YYYGG..')
H[0x49] = T('.YYYGGG.',
            '.YYYGGGG',
            '.YY.GGG.',
            '.YYYGG..',
            '.Y.YGGG.',
            '..Y.GG..')
H[0x4A] = T('.Y.YGG..',
            'Y.YYGGG.',
            '.YY.GGGG',
            'Y.YYGGG.',
            '.YYYGGG.',
            '..YYGG..')
H[0x4B] = T('..YYGGGG',
            '.Y.YGGGG',
            '.YY.GGG.',
            '.YYYGGG.',
            '.YYYGGG.',
            '.YYYGG..')
# ---- capsule pipe ends (white cap | cyan body ... cyan body | grey cap)
H[0x16] = T('.YYY.GGG',
            'YYYY.GGG',
            'YYYY.GGG',
            'YYYY.GGG',
            'YYYY.G.G',
            '.YYY..G.')
H[0x17] = T('GGG.GG..',
            'GGG.GGG.',
            'GGG.GGGR',
            'GGG.GGGR',
            'G.G.GGR.',
            '.G..GR..')
# ---- vertical white/cyan pipe
H[0x7B] = T('.YYYGGG.',
            'Y.YYGGGG',
            'YYY.GGG.',
            '.YYYGGGG',
            'YY.YGGG.',
            'YYYYGGGG')
H[0x7C] = T('Y.YYGGGG',
            'YYY.GGG.',
            '.YYYGGGG',
            'YYYYGGG.',
            'Y.YYGGGG',
            'YYY.GGG.')
H[0x7D] = T('YY.YGGGG',
            'YYYYGG.G',
            'Y.YYGGG.',
            'YYY.GGGG',
            '.YYYGGG.',
            'YY.YGGGG')
H[0x7E] = T('YY.YGGG.',
            'Y.Y.GGGG',
            'YYYYG.G.',
            'Y.YYGGGG',
            'YY.YGGG.',
            'YYYYGGGG')
H[0x7F] = H[0x7C]
# ---- spike / drill (white with cyan shade)
H[0x46] = T('...YG...',
            '...YG...',
            '..YY.G..',
            '..YYG...',
            '.Y.YGG..',
            'YYY.GGG.')
H[0x47] = T('YYY.GGG.',
            '.YYYG...',
            '..YY.G..',
            '..YYG...',
            '...YG...',
            '...YG...')
# ---- white drips / stalactite chain (Y lit, G grey side)
H[0x1D] = T('..YYGG..',
            '.YYYGG..',
            '..YYG...',
            '...YG...',
            '...YG...',
            '...YG...')
H[0x1E] = T('YYYYGGG.',
            '..YYGG..',
            '..YYG...',
            '...YG...',
            '........',
            '...YG...')
H[0x1F] = T('YYYYGGGG',
            '..YYGG..',
            '..YYG...',
            '........',
            '...YG...',
            '...YG...')
H[0x20] = T('...YG...',
            '...YG...',
            '..YYG...',
            '........',
            '.YYYGG..',
            '.YYYGG..')
H[0x22] = T('........',
            '...YG...',
            '..YYG...',
            '........',
            'YYYYGGGG',
            '..YYGG..')
# ---- cyan/green pillar (lit band Y, body G, dithered shadow)
H[0x3B] = T('G.YYGGG.',
            'G.YYGG.G',
            'G.YYGGG.',
            'G.YYGG.G',
            'G.YYGGG.',
            'G.YYGG.G')
H[0x3C] = T('Y.Y.G.G.',
            'G.YYGG.G',
            'G.YYGGG.',
            'G.YYGG.G',
            'G.YYGGG.',
            'G.YYGG.G')
H[0x3D] = T('G.YYGGG.',
            'G.YYGG.G',
            'G.YYGGG.',
            'G.YYGG.G',
            'G.YYGG..',
            'Y.Y.G.G.')
# ---- cyan/green circuit panels
H[0xA8] = T('YYY..YYY',
            '..YYYY..',
            'YY.YY.YY',
            'GG.GG.GG',
            '..GGGG..',
            'GGG..GGG')
H[0xA9] = T('YY.Y..GG',
            'YY.YYGG.',
            'YYYY.GGG',
            'YY.YYGG.',
            'YY.Y.GGG',
            'YY.Y..GG')
# ---- white sphere
H[0x8D] = T('..YYGG..',
            '.YYYGGG.',
            'YYYYYGGG',
            'GGGGGG.G',
            '.GGGGG..',
            '..GG.G..')
# ---- small white robot sentinel
H[0x8F] = T('...YG...',
            '..YYGG..',
            'YY.Y..GG',
            'YY.G.G.G',
            '..Y..G..',
            '...GG...')
# ---- green X girders
H[0x9B] = T('GGGGGGGG',
            'GG....GG',
            '..G..G..',
            '...GG...',
            'G.G..G.G',
            'GGGGGGGG')
H[0x9A] = T('GGGGGGGG',
            'GG....GG',
            'G.GG.G..',
            'G...G...',
            'G.G..G.G',
            'GGGGGGGG')
H[0x9C] = T('GGGGGGGG',
            'GG....GG',
            '..G.G.GG',
            '...G..G.',
            'G.G..GG.',
            'GGGGGGG.')
H[0x9E] = T('GG.G..GG',
            'GG..GG.G',
            'GG..G..G',
            'GG..G..G',
            'GG..GG.G',
            'GG.G..GG')
H[0x9D] = T('GGGGGGG.',
            'GG.G..GG',
            'GG..GG.G',
            'GG..G..G',
            'GG..GG.G',
            'GG.G..GG')
H[0x9F] = T('GG.G..GG',
            'GG..GG.G',
            'GG..G..G',
            'GG..GG.G',
            'GG.G..GG',
            'GGGGGGG.')
# ---- green/cyan grille panels (2E/2F: window frames with cyan top-left)
H[0x2E] = T('GGGGGGG.',
            'G.YY.GG.',
            'G.Y.Y.G.',
            'G.GG.GG.',
            'G.G.G.G.',
            'G.G.G.G.')
H[0x2F] = T('GGGGGGG.',
            'G.GGGGG.',
            'G.G.G.G.',
            'G.GG.G..',
            'G.G.G.G.',
            'G.G.G.G.')
H[0x78] = T('GGGGGGGG',
            '.G.G.G.G',
            'G.G.G.G.',
            '.G.G.G.G',
            'GGGGGGGG',
            '.G.G.G.G')
H[0x79] = T('YYYYGGG.',
            'YY....G.',
            'YY.Y.GG.',
            'GG.G.GG.',
            'GG....G.',
            'GGGGGGG.')
H[0x87] = T('GG.GGG.G',
            'GG.GGGG.',
            'GG.GGG.G',
            'GG.GGGG.',
            'GG.GGG.G',
            'GG.GGGG.')
H[0x88] = T('GGGGGGGG',
            'G.G.G.G.',
            'GG.G.G.G',
            'G.G.G.G.',
            'GG.G.G.G',
            'G.G.G.G.')
H[0x91] = T('.G.GGGG.',
            'GG.GGGGG',
            'GG.GGGG.',
            'G......G',
            '.G.GGGG.',
            '.G.GGG.G')
H[0x92] = T('.G.GGGG.',
            '.G.GGG.G',
            '.G.GGGG.',
            '.G.GGG.G',
            '.G.GGGG.',
            '.G.GG.G.')
H[0x93] = T('GG.GGGGG',
            '........',
            'GG.GGGG.',
            '.G.GGG..',
            '.G.GGGG.',
            'GG.GGGG.')
# ---- magenta/red machinery
H[0x1B] = T('RRRRRRRR',
            '.R.R.R.R',
            'RRRRRRRR',
            'RRRRRRRR',
            'R.R.R.R.',
            '.R.R.R.R')
H[0x19] = T('..RRRR..',
            '.RR..RR.',
            'RR.RR.RR',
            'RR.RR.RR',
            '.RR..RR.',
            '..RRRR..')
H[0x1A] = T('....RRRR',
            '..R.RRR.',
            'RR.RRRRR',
            'RR.RRRRR',
            '.R..R.RR',
            '....R.R.')
H[0x1C] = T('RRRR....',
            'R.RR.R..',
            'RRRR.RRR',
            'RRRR.RR.',
            'R.RR.RR.',
            'R.R.....')
# ---- white/yellow plate edges
H[0x4C] = T('Y.YYYYYY',
            'Y.YYYYYY',
            '........',
            '.Y.YYYYY',
            '..Y.YYYY',
            '..Y.YYYY')
H[0x4D] = T('RRRR.R.R',
            'RRRR.R.R',
            '........',
            'RRRR.R.R',
            'RRR.R.R.',
            'RR.R.R..')
# ---- yellow dish turret, 2x2 blocks (27 28 / 29 2A) and its ceiling
# version (30 31 / 32 33, flipped vertically)
TUR = ['..YYYY..........',
       '.Y.YY.Y.........',
       'Y.Y..Y.YR.......',
       'Y.Y.YY.YR.......',
       '.Y.YY.YR........',
       '..YYYYR.........',
       '...RYR..........',
       '...RYR..........',
       '..RYYYR....YY...',
       '.RYYYYYR..Y..Y..',
       'RYYYYYYYR..YY...',
       'RRRRRRRRR.......']
def _split(rows, ids):
    a, b, c, d = ids
    H[a] = T(*[r[0:8] for r in rows[0:6]])
    H[b] = T(*[r[8:16] for r in rows[0:6]])
    H[c] = T(*[r[0:8] for r in rows[6:12]])
    H[d] = T(*[r[8:16] for r in rows[6:12]])
_split(TUR, (0x27, 0x28, 0x29, 0x2A))
_split(TUR[::-1], (0x30, 0x31, 0x32, 0x33))
H[0x15] = T('Y.YYRR.R',
            'YYYYRRRR',
            'Y.YYRR.R',
            'YYYYRRRR',
            'Y.YYRR.R',
            'YYYYRRRR')
