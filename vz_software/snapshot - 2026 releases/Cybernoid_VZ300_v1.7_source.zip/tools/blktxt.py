import sys
sys.path.insert(0,'/home/claude/cy/tools')
from variants import bits, attr, variants
L='.bRMgcYW'   # spectrum colours: black blue red magenta green cyan yellow white
LB='.BRMGCYW'
V={0:'G',1:'Y',2:'.',3:'R'}
for n in [int(x) for x in sys.argv[1].split(',')]:
    b=bits(n); at=attr(n); v=variants(n)[0]
    print('== %d'%n)
    for y in range(16):
        s=''
        for x in range(16):
            a=at[y//8][x//8]; c=(a&7) if b[y][x] else (a>>3)&7
            s+=(LB if a&64 else L)[c]
        vz=''.join(V[p] for p in v[y*6//16]) if y%3==0 and y<18 else ''
        print('  '+s+'    '+(''.join(V[p] for p in v[y//3]) if y<6*3 and y%3==0 else ''))
