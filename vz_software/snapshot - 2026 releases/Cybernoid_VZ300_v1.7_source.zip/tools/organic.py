"""Organic 'biomass' background for mode(0) screens (64x32 SG blocks) and
the bubble sites that animate on it."""
import math, random, sys
sys.path.insert(0, '/home/claude/cy/tools')
GRN, YEL, BLU, RED, BUF, CYN, MAG, ORG = range(8)
def field(seed, W=64, H=32, fx=4, fy=2):
    r = random.Random(seed); comps = []
    while len(comps) < 9:
        kx = r.randint(-fx, fx); ky = r.randint(-fy, fy)
        if kx == 0 and ky == 0: continue
        comps.append((kx, ky, r.uniform(0, 2*math.pi), 1/math.hypot(kx, ky*1.6)))
    v = [[sum(a*math.cos(2*math.pi*(kx*x/W+ky*y/H)+p) for kx, ky, p, a in comps) for x in range(W)] for y in range(H)]
    fl = sorted(q for row in v for q in row); lo, hi = fl[0], fl[-1]
    return [[(q-lo)/(hi-lo) for q in row] for row in v]
def biomass(s, seed=4, bands=3.0, w=0.20):
    f = field(seed)
    for y in range(32):
        for x in range(64):
            t = f[y][x]*bands
            k = int(t); fr = t-k
            if abs(fr-0.5) < w:
                s.block(x, y, MAG if k % 2 else RED)
def bubbles(s, n, rows_ok, seed=5):
    """pick cells that are fully inside the texture area"""
    r = random.Random(seed); out = []
    tries = 0
    while len(out) < n and tries < 5000:
        tries += 1
        rr = r.choice(rows_ok); c = r.randrange(0, 32)
        if (rr, c) in s.txt or (rr, c) in out: continue
        if any((rr+a, c+b) in out for a in (-1, 0, 1) for b in (-1, 0, 1)): continue
        out.append((rr, c))
    return out
