import sys, json
sys.path.insert(0,'/home/claude/cy/tools')
from PIL import Image, ImageDraw
from vzart import *
import roomprev
m=open('/home/claude/cy/build/spec48.bin','rb').read()
def bits(n): return [[(m[0xD479+n*32+y*2+(x>>3)]>>(7-(x&7)))&1 for x in range(16)] for y in range(16)]
def attr(n): a=m[0xE9B9+4*n:0xE9B9+4*n+4]; return [[a[0],a[1]],[a[2],a[3]]]
orgs=[1,2,3,4,5,12,13,14,15,52,53,54,55,80,81,82,83,120,121,128,129,130]
def conv(n,cm,thr):
    b=bits(n); at=attr(n); ds=downsample(b,16,16,8,6,thr=thr,lthr=thr,dither=False)
    return [[ (cm.get(at[oy//3][ox//4]&7,2) if ds[oy][ox] else 2) for ox in range(8)] for oy in range(6)]
opts=[({3:3,2:3},0.5),({3:0,2:3},0.5),({3:3,2:1},0.5),({3:3,2:3},0.6)]
art=roomprev.art
out=Image.new('RGB',(1024,768))
for k,(cm,t) in enumerate(opts):
    save=dict()
    for n in orgs: art['blocks'][n]=conv(n,cm,t)
    out.paste(roomprev.room_img(int(sys.argv[2]),2),((k%2)*512,(k//2)*384))
out.save(sys.argv[1])
