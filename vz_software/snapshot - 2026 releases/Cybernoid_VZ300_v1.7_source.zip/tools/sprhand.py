"""Hand-drawn VZ sprites.  24-wide Spectrum sprites (16x16) -> 8x6, small
sprites (8x8) -> 4x3.  '.' = transparent (XOR with background)."""
C = {'.': 2, 'G': 0, 'Y': 1, 'R': 3}
def T(*rows):
    return [[C[c] for c in r] for r in rows]
def mirror(t): return [r[::-1] for r in t]

S = {}
# player ship (S1 right, S2 left): lit hull, green under-deck
S[1] = T('.YYG....',
         'YYYYYG..',
         'YYYYYYYY',
         '.GGGGGG.',
         'GG.GGG.G',
         '.GG.....')
S[2] = mirror(S[1])
# four-way pod (S3 up, S5 down, S4 left, S6 right)
S[3] = T('..GGGG..',
         '.GGYYGG.',
         'GYGGGGYG',
         'GGYGGYGG',
         'G.G..G.G',
         '........')
S[5] = T('........',
         'G.G..G.G',
         'GGYGGYGG',
         'GYGGGGYG',
         '.GGYYGG.',
         '..GGGG..')
S[4] = T('..GGYG..',
         '.GGGYG..',
         'GYGG.G..',
         'GYGG.G..',
         '.GGGYG..',
         '..GGYG..')
S[6] = T('..GYGG..',
         '..GYGGG.',
         '..G.GGYG',
         '..G.GGYG',
         '..GYGGG.',
         '..GYGG..')
# dart fighters (S7 nose left, S8 nose right)
S[7] = T('.....R.R',
         '..YYRRYR',
         'YRYYRYRR',
         '..YYRRYR',
         '.....R.R',
         '........')
S[8] = mirror(S[7])
# explosion: rock -> burst -> ring -> dust
S[9] = T('.RYYR...',
         'RYYYYRYR',
         'YYRYYYRY',
         'RYYYRYYR',
         'YRYYRRYR',
         '.RYRRYR.')
S[10] = T('.RYR..R.',
          'YR...RYR',
          'R.....RY',
          'YR....RR',
          'RY..RRYR',
          '.RRY.RR.')
S[11] = T('..R....R',
          'R.....R.',
          'R.......',
          'Y......R',
          'R......R',
          '.R.R.RR.')
S[12] = T('...R..R.',
          'R......R',
          '........',
          'R......R',
          '........',
          '.R...R..')
# dome walker (two frames)
S[13] = T('..RRRR..',
          '.RYYYYR.',
          'YR.RR.RY',
          'RRRRRRRR',
          'RRRRRRR.',
          '.R.RR.R.')
S[15] = T('..RRRR..',
          '.RYYYYR.',
          'RRRRRRRR',
          'R.RRRR.R',
          'R..RR..R',
          '.R.RR.R.')
# robot (two frames)
S[14] = T('.GYGGYG.',
          'GGYGGYGG',
          'GGGGGGGG',
          '.GGGGGG.',
          'GGGGGGG.',
          '..GYYG..')
S[16] = T('.GYGGYG.',
          'GGYGGYGG',
          'GGGGGGGG',
          '..GGGG..',
          'G.GYYG.G',
          'GG.GG.GG')
# cargo crystal
S[17] = T('Y..GG..Y',
          '.YGYYGY.',
          'GYYGGYYG',
          'GYYGGYYG',
          '.YGYYGY.',
          'Y..GG..Y')
S[0] = T('........', '........', '........', '........', '........', '........')

M = {}
M[0] = T('YY..', '.GYY', 'YY..')      # missile right
M[1] = T('..YY', 'YYG.', '..YY')      # missile left
M[2] = T('.RR.', 'RYRR', '.RR.')      # spore blob
M[3] = T('.R..', 'RYRR', '.R..')      # spark
M[4] = T('.YY.', 'Y..Y', '.YY.')      # ring
M[5] = T('.YY.', 'YYYG', '.GG.')      # bomb
M[6] = T('.R.Y', 'R.R.', '.Y.R')      # debris
M[7] = T('.R..', 'R.R.', '..R.')
M[8] = T('....', '.R..', '..R.')
M[9] = T('....', '....', '....')
M[10] = T('.GG.', 'G.YG', '.GG.')     # seeker
M[11] = T('....', '....', '....')
