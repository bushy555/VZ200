import sys,struct
def read(fn):
    d=open(fn,'rb').read()
    ntr=d[0x30]; nsd=d[0x31]
    sizes=[d[0x34+i]*256 for i in range(ntr*nsd)]
    off=0x100; tracks={}
    for t,sz in enumerate(sizes):
        if sz==0: continue
        ti=d[off:off+sz]
        assert ti[:10]==b'Track-Info',(t,ti[:12])
        trk=ti[0x10]; side=ti[0x11]; ssz=ti[0x14]; nsec=ti[0x15]; gap=ti[0x16]; fill=ti[0x17]
        secs=[]; p=0x100
        for s in range(nsec):
            c,h,r,n,st1,st2,ln=struct.unpack('<BBBBBBH',ti[0x18+8*s:0x20+8*s])
            if ln==0: ln=128<<n
            secs.append(dict(c=c,h=h,r=r,n=n,st1=st1,st2=st2,data=ti[p:p+ln])); p+=ln
        tracks[(trk,side)]=secs
        off+=sz
    return tracks
if __name__=='__main__':
    tr=read(sys.argv[1])
    for k in sorted(tr):
        s=tr[k]
        print(k, len(s), ' '.join('%d/%d/%02X/n%d/%d%s'%(x['c'],x['h'],x['r'],x['n'],len(x['data']),'' if not(x['st1']|x['st2']) else '!%02X%02X'%(x['st1'],x['st2'])) for x in s))
