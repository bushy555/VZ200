import sys; sys.path.insert(0,'/home/claude/cy/tools')
from variants import bits, attr
L='.bRMgcYW'; LB='.BRMGCYW'
ids=[int(x) for x in sys.argv[1].split(',')]
for grp in [ids[i:i+5] for i in range(0,len(ids),5)]:
    print('   '.join('%-16s'%('#%d'%n) for n in grp))
    for y in range(16):
        line=[]
        for n in grp:
            b=bits(n); at=attr(n); s=''
            for x in range(16):
                a=at[y//8][x//8]; c=(a&7) if b[y][x] else (a>>3)&7
                s+=(LB if a&64 else L)[c]
            line.append(s)
        print('   '.join(line))
