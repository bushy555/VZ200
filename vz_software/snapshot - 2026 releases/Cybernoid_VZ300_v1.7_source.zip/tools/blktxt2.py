import sys
m=open('/home/claude/cy/build/spec48.bin','rb').read()
L='KBRMGCYW'
def txt(n):
    a=m[0xE9B9+4*n:0xE9B9+4*n+4]; out=[]
    for y in range(16):
        s=''
        for x in range(16):
            at=a[(y//8)*2+(x//8)]; b=(m[0xD479+n*32+y*2+(x>>3)]>>(7-(x&7)))&1
            c=L[at&7] if b else '.'
            if b and not at&64: c=c.lower()
            s+=c
        out.append(s)
    return out
ids=[int(x,16) for x in sys.argv[1].split(',')]
for i in range(0,len(ids),6):
    grp=ids[i:i+6]; ts=[txt(n) for n in grp]
    print('   '.join('%02X%s'%(n,' '*14) for n in grp))
    for y in range(16): print('   '.join(t[y] for t in ts))
    print()
