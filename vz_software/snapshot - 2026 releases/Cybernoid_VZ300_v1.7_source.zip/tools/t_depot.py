import sys; sys.path.insert(0,'/home/claude/cy/tools')
import emu
RD=28178
lvl=sys.argv[1] if len(sys.argv)>1 else '00'
cargo=sys.argv[2] if len(sys.argv)>2 else '2'
s='''frames 60
down SPACE
frames 5
up SPACE
rununtil 6567 500
seta %s
frames 200
poke 796D 3%s
poke 796E 30
poke 796F 30
poke 7973 D0
poke 7974 07
poke %04X 00
poke %04X 00
poke %04X 02
frames 300
screen d0.ppm
frames 100
screen d1.ppm
down SPACE
frames 10
up SPACE
frames 150
screen l2.ppm
rand 300 3
screen l2b.ppm
peek %04X 1
'''%(lvl,cargo,0x7644+RD,0x7645+RD,0x7643+RD,0x74E1+RD)
print(emu.run(s,start=False)[-300:])
emu.sheet(['d0','d1','l2','l2b'],'/home/claude/cy/vrun/lsheet.png',cols=4)
