"""Compact Z80 disassembler. dis(mem, addr) -> (length, text, info)
info: dict with 'abs' (absolute 16-bit operand addr, if any), 'jump' target, 'kind'"""
R8 = ['B', 'C', 'D', 'E', 'H', 'L', '(HL)', 'A']
R16 = ['BC', 'DE', 'HL', 'SP']
R16AF = ['BC', 'DE', 'HL', 'AF']
CC = ['NZ', 'Z', 'NC', 'C', 'PO', 'PE', 'P', 'M']
ALU = ['ADD A,', 'ADC A,', 'SUB ', 'SBC A,', 'AND ', 'XOR ', 'OR ', 'CP ']
ROT = ['RLC', 'RRC', 'RL', 'RR', 'SLA', 'SRA', 'SLL', 'SRL']
MISC0 = ['RLCA', 'RRCA', 'RLA', 'RRA', 'DAA', 'CPL', 'SCF', 'CCF']


def h2(v): return '$%02X' % v
def h4(v): return '$%04X' % v


def dis(m, a):
    def b(i): return m[(a + i) & 0xffff]
    def w(i): return b(i) | (b(i + 1) << 8)
    info = {}
    op = b(0)
    prefix = None
    if op in (0xDD, 0xFD):
        prefix = 'IX' if op == 0xDD else 'IY'
        op2 = b(1)
        if op2 == 0xCB:
            d = b(2); d = d - 256 if d > 127 else d; o = b(3)
            x, y, z = o >> 6, (o >> 3) & 7, o & 7
            idx = '(%s%+d)' % (prefix, d)
            if x == 0: t = '%s %s' % (ROT[y], idx)
            elif x == 1: t = 'BIT %d,%s' % (y, idx)
            elif x == 2: t = 'RES %d,%s' % (y, idx)
            else: t = 'SET %d,%s' % (y, idx)
            if z != 6 and x != 1: t += ',' + R8[z]
            return 4, t, info
        if op2 in (0xDD, 0xFD, 0xED):
            return 1, 'DEFB %s ; prefix' % h2(op), info
        n, t, info = dis_main(m, a + 1, prefix)
        return n + 1, t, info
    if op == 0xED:
        return dis_ed(m, a)
    if op == 0xCB:
        o = b(1); x, y, z = o >> 6, (o >> 3) & 7, o & 7
        if x == 0: t = '%s %s' % (ROT[y], R8[z])
        elif x == 1: t = 'BIT %d,%s' % (y, R8[z])
        elif x == 2: t = 'RES %d,%s' % (y, R8[z])
        else: t = 'SET %d,%s' % (y, R8[z])
        return 2, t, info
    return dis_main(m, a, None)


def dis_ed(m, a):
    def b(i): return m[(a + i) & 0xffff]
    def w(i): return b(i) | (b(i + 1) << 8)
    o = b(1); info = {}
    x, y, z = o >> 6, (o >> 3) & 7, o & 7
    p, q = y >> 1, y & 1
    if x == 1:
        if z == 0: return 2, ('IN %s,(C)' % R8[y]) if y != 6 else 'IN (C)', info
        if z == 1: return 2, ('OUT (C),%s' % R8[y]) if y != 6 else 'OUT (C),0', info
        if z == 2: return 2, ('SBC HL,%s' if q == 0 else 'ADC HL,%s') % R16[p], info
        if z == 3:
            info['abs'] = w(2); info['abspos'] = 2
            return 4, ('LD (%s),%s' % (h4(w(2)), R16[p])) if q == 0 else ('LD %s,(%s)' % (R16[p], h4(w(2)))), info
        if z == 4: return 2, 'NEG', info
        if z == 5: return 2, 'RETN' if y != 1 else 'RETI', dict(kind='ret')
        if z == 6: return 2, 'IM %s' % ['0', '0/1', '1', '2', '0', '0/1', '1', '2'][y], info
        return 2, ['LD I,A', 'LD R,A', 'LD A,I', 'LD A,R', 'RRD', 'RLD', 'NOP*', 'NOP*'][y], info
    if x == 2 and z <= 3 and y >= 4:
        t = [['LDI', 'CPI', 'INI', 'OUTI'], ['LDD', 'CPD', 'IND', 'OUTD'], ['LDIR', 'CPIR', 'INIR', 'OTIR'], ['LDDR', 'CPDR', 'INDR', 'OTDR']][y - 4][z]
        return 2, t, info
    return 2, 'DEFB $ED,%s ; ??' % h2(o), info


def dis_main(m, a, ix):
    def b(i): return m[(a + i) & 0xffff]
    def w(i): return b(i) | (b(i + 1) << 8)
    info = {}
    o = b(0)
    x, y, z = o >> 6, (o >> 3) & 7, o & 7
    p, q = y >> 1, y & 1
    disp_len = 0

    def r8(r, allow_hl_sub=True):
        nonlocal disp_len
        if ix is None: return R8[r]
        if r == 6:
            d = b(1); d = d - 256 if d > 127 else d
            disp_len = 1
            return '(%s%+d)' % (ix, d)
        if allow_hl_sub and r in (4, 5): return ix + ('H' if r == 4 else 'L')
        return R8[r]

    def r16(r): return ix if (ix and r == 2) else R16[r]
    def r16af(r): return ix if (ix and r == 2) else R16AF[r]
    if x == 0:
        if z == 0:
            if y == 0: return 1, 'NOP', info
            if y == 1: return 1, "EX AF,AF'", info
            d = b(1); d = d - 256 if d > 127 else d; tgt = (a + 2 + d) & 0xffff
            info['jump'] = tgt; info['rel'] = True
            if y == 2: return 2, 'DJNZ %s' % h4(tgt), info
            if y == 3: info['kind'] = 'jp'; return 2, 'JR %s' % h4(tgt), info
            return 2, 'JR %s,%s' % (CC[y - 4], h4(tgt)), info
        if z == 1:
            if q == 0:
                info['imm16'] = w(1); info['abspos'] = 1
                return 3, 'LD %s,%s' % (r16(p), h4(w(1))), info
            return 1, 'ADD %s,%s' % (r16(2), r16(p)), info
        if z == 2:
            if q == 0:
                if p == 0: return 1, 'LD (BC),A', info
                if p == 1: return 1, 'LD (DE),A', info
                info['abs'] = w(1); info['abspos'] = 1
                if p == 2: return 3, 'LD (%s),%s' % (h4(w(1)), r16(2)), info
                return 3, 'LD (%s),A' % h4(w(1)), info
            else:
                if p == 0: return 1, 'LD A,(BC)', info
                if p == 1: return 1, 'LD A,(DE)', info
                info['abs'] = w(1); info['abspos'] = 1
                if p == 2: return 3, 'LD %s,(%s)' % (r16(2), h4(w(1))), info
                return 3, 'LD A,(%s)' % h4(w(1)), info
        if z == 3: return 1, ('INC ' if q == 0 else 'DEC ') + r16(p), info
        if z == 4: t = r8(y); return 1 + disp_len, 'INC ' + t, info
        if z == 5: t = r8(y); return 1 + disp_len, 'DEC ' + t, info
        if z == 6:
            t = r8(y); n = b(1 + disp_len)
            return 2 + disp_len, 'LD %s,%s' % (t, h2(n)), info
        return 1, MISC0[y], info
    if x == 1:
        if z == 6 and y == 6: return 1, 'HALT', info
        if y == 6 or z == 6:
            t1 = r8(y, False) if y == 6 else R8[y]
            t2 = r8(z, False) if z == 6 else R8[z]
            if y == 6: t2 = R8[z]
            if z == 6: t1 = R8[y]
            return 1 + disp_len, 'LD %s,%s' % (t1, t2), info
        return 1, 'LD %s,%s' % (r8(y), r8(z)), info
    if x == 2:
        t = r8(z); return 1 + disp_len, ALU[y] + t, info
    # x == 3
    if z == 0: return 1, 'RET ' + CC[y], dict(kind='retc')
    if z == 1:
        if q == 0: return 1, 'POP ' + r16af(p), info
        if p == 0: return 1, 'RET', dict(kind='ret')
        if p == 1: return 1, 'EXX', info
        if p == 2: return 1, 'JP (%s)' % r16(2), dict(kind='jpi')
        return 1, 'LD SP,%s' % r16(2), info
    if z == 2:
        info['jump'] = w(1); info['abs'] = w(1); info['abspos'] = 1
        return 3, 'JP %s,%s' % (CC[y], h4(w(1))), info
    if z == 3:
        if y == 0:
            info['jump'] = w(1); info['abs'] = w(1); info['abspos'] = 1; info['kind'] = 'jp'
            return 3, 'JP %s' % h4(w(1)), info
        if y == 2: return 2, 'OUT (%s),A' % h2(b(1)), info
        if y == 3: return 2, 'IN A,(%s)' % h2(b(1)), info
        if y == 4: return 1, 'EX (SP),%s' % r16(2), info
        if y == 5: return 1, 'EX DE,HL', info
        if y == 6: return 1, 'DI', info
        return 1, 'EI', info
    if z == 4:
        info['jump'] = w(1); info['abs'] = w(1); info['abspos'] = 1; info['call'] = True
        return 3, 'CALL %s,%s' % (CC[y], h4(w(1))), info
    if z == 5:
        if q == 0: return 1, 'PUSH ' + r16af(p), info
        if p == 0:
            info['jump'] = w(1); info['abs'] = w(1); info['abspos'] = 1; info['call'] = True
            return 3, 'CALL %s' % h4(w(1)), info
        return 1, 'DEFB ??', info
    if z == 6: return 2, ALU[y] + h2(b(1)), info
    info['jump'] = y * 8; info['call'] = True
    return 1, 'RST %s' % h2(y * 8), info


def listing(m, start, end, labels=None):
    out = []
    a = start
    while a < end:
        n, t, info = dis(m, a)
        bs = ' '.join('%02X' % m[(a + i) & 0xffff] for i in range(n))
        out.append('%04X  %-12s %s' % (a, bs, t))
        a += n
    return out
