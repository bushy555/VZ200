"""Cybernoid VZ300 mode(0) screens: SG4 semigraphics (64x32 blocks, 8 colours on
black) + VZ text.  Produces 512-byte screen images, animation tables and PNG
previews."""
import sys
sys.path.insert(0, '/home/claude/cy/tools')
from fonts import F35
GRN, YEL, BLU, RED, BUF, CYN, MAG, ORG = range(8)
PAL = [(0x30,0xd2,0),(0xc1,0xe5,0),(0x4c,0x3a,0xb4),(0x9a,0x32,0x36),(0xbf,0xc8,0xad),(0x41,0xaf,0x71),(0xc8,0x4e,0xf0),(0xd4,0x7f,0)]

class Screen:
    def __init__(s):
        s.blk = [[None]*64 for _ in range(32)]
        s.txt = {}
        s.stars = []
        s.glyph = set()
        s.bubbles = []
        s.reserved = set()                  # cells written at run time
        s.over = {}                         # final byte overrides
        s.halo = set()
        s.glrow = 1
    def block(s, x, y, c):
        if 0 <= x < 64 and 0 <= y < 32: s.blk[y][x] = c
    def gblock(s, x, y, c):
        if 0 <= x < 64 and 0 <= y < 32:
            s.blk[y][x] = c; s.glyph.add((x, y))
    def isolate(s):
        """lettering over the biomass: in any cell holding a letter pixel the
        other pixels go black (one colour per SG cell), so the letters stay
        clean and the biomass shows in the gaps and above/below them"""
        s.halo = set()
        for x, y in list(s.glyph):          # one-block black outline
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    q = (x+dx, y+dy)
                    if q not in s.glyph and 0 <= q[0] < 64 and 0 <= q[1] < 32:
                        s.blk[q[1]][q[0]] = None; s.halo.add(q)
        cells = {(y//2, x//2) for x, y in s.glyph}
        for r, c in cells:
            for y in (2*r, 2*r+1):
                for x in (2*c, 2*c+1):
                    if (x, y) not in s.glyph: s.blk[y][x] = None
    def glmask(s):
        out = []
        for c in range(32):
            m = 0
            for k in range(4):
                r = s.glrow+k
                if any((x, y) in s.glyph for y in (2*r, 2*r+1) for x in (2*c, 2*c+1)): m |= 1 << k
            out.append(m)
        return out
    def bitmap(s, x, y, rows, pal):
        for j, row in enumerate(rows):
            for i, ch in enumerate(row):
                if ch in pal: s.block(x+i, y+j, pal[ch])
    def text(s, row, col, t, inv=False):
        for i, ch in enumerate(t):
            v = ord(ch); v = v-64 if v >= 64 else v
            s.txt[(row, col+i)] = v | (0x40 if inv else 0)
    def ctext(s, row, t, inv=False):
        s.text(row, (32-len(t))//2, t, inv)
    def small(s, x, y, text, rowcols, scale=1):
        """3x5 font in blocks, colour chosen per font row"""
        for i, ch in enumerate(text):
            g = F35.get(ch, F35[' '])
            for r in range(5):
                for k in range(3):
                    if g[r][k] == '#':
                        for a in range(scale):
                            for b in range(scale):
                                s.gblock(x+(i*4+k)*scale+a, y+r*scale+b, rowcols[(r*scale+b)//scale if scale == 1 else r])
    def bytes(s):
        out = bytearray(512)
        for r in range(16):
            for c in range(32):
                if (r, c) in s.txt:
                    out[r*32+c] = s.txt[(r, c)]; continue
                if (r, c) in s.over:
                    out[r*32+c] = s.over[(r, c)]; continue
                q = [s.blk[2*r][2*c], s.blk[2*r][2*c+1], s.blk[2*r+1][2*c], s.blk[2*r+1][2*c+1]]
                cols = [x for x in q if x is not None]
                if not cols:
                    out[r*32+c] = 0x80; continue
                col = max(set(cols), key=cols.count)
                bits = sum(1 << (3-i) for i, x in enumerate(q) if x == col)
                out[r*32+c] = 0x80 | (col << 4) | bits
        return bytes(out)

def render(b, fn, css=1):
    """PNG preview of a 512-byte mode(0) screen (VZ internal font)"""
    from PIL import Image
    sys.path.insert(0, '/home/claude/cy/emu')
    font = load_font()
    img = Image.new('RGB', (256, 192)); p = img.load()
    fg = (0xff, 0xb7, 0) if css else (0x30, 0xd2, 0)
    bg = (0x6b, 0x27, 0) if css else (0, 0x40, 0)
    for r in range(16):
        for c in range(32):
            v = b[r*32+c]
            for y in range(12):
                for x in range(8):
                    if v & 0x80:
                        q = (0 if y < 6 else 2)+(0 if x < 4 else 1)
                        p[c*8+x, r*12+y] = PAL[(v >> 4) & 7] if (v >> (3-q)) & 1 else (16, 16, 16)
                    else:
                        on = 0
                        if 3 <= y < 10 and 1 <= x < 6: on = font[v & 63][y-3][x-1]
                        on ^= (v >> 6) & 1
                        p[c*8+x, r*12+y] = fg if on else bg
    img.resize((512, 384), Image.NEAREST).save(fn)

def load_font():
    import re
    src = open('/home/claude/cy/emu/font6847.h').read()
    body = src[src.index('={')+2:]
    nums = [int(x) for x in re.findall(r'\d+', body)]
    # 64 glyphs x 7 rows, 5 bits each
    out = []
    for ch in range(64):
        rows = []
        for y in range(7):
            v = nums[ch*7+y]
            rows.append([(v >> (4-x)) & 1 for x in range(5)])
        out.append(rows)
    return out

# ---------------------------------------------------------------------------
# artwork
LOGO = {
'C': [".####", "##...", "##...", "##...", "##...", "##...", ".####"],
'Y': ["##.##", "##.##", "##.##", ".####", "...##", "...##", "####."],
'B': ["####.", "##.##", "##.##", "####.", "##.##", "##.##", "####."],
'E': ["#####", "##...", "##...", "####.", "##...", "##...", "#####"],
'R': ["####.", "##.##", "##.##", "####.", "##.#.", "##.##", "##.##"],
'N': ["####.", "##.##", "##.##", "##.##", "##.##", "##.##", "##.##"],
'O': [".###.", "##.##", "##.##", "##.##", "##.##", "##.##", ".###."],
'I': ["##", "##", "##", "##", "##", "##", "##"],
'G': [".####", "##...", "##...", "##.##", "##.##", "##.##", ".####"],
'A': [".###.", "##.##", "##.##", "#####", "##.##", "##.##", "##.##"],
'M': ["##.##", "#####", "#####", "#.#.#", "##.##", "##.##", "##.##"],
'V': ["##.##", "##.##", "##.##", "##.##", "##.##", ".###.", "..#.."],
' ': ["...", "...", "...", "...", "...", "...", "..."],
'D': ["####.", "##.##", "##.##", "##.##", "##.##", "##.##", "####."],
}
LOGO_ROWS = [BUF, BUF, CYN, CYN, CYN, CYN, BLU, BLU]   # by block row: neon 'cyber' chrome
SLANT = [0, 0, 0, 0, 0, 0, 0]                           # italic shear per row

def logo_width(word):
    return sum(len(LOGO[c][0])+1 for c in word)-1+max(SLANT)

def logo(s, x0, y0, word="CYBERNOID"):
    x = x0
    for ch in word:
        g = LOGO[ch]
        for r in range(7):
            for k in range(len(g[r])):
                if g[r][k] == '#':
                    s.gblock(x+k+SLANT[r], y0+r, LOGO_ROWS[r])
        x += len(g[0])+1

def frame(s):
    """yellow girder frame with cyan corner bolts (as the Spectrum title)"""
    for x in range(2, 62):
        s.block(x, 0, YEL)
        if x % 2 == 0: s.block(x, 1, YEL)
        s.block(x, 31, YEL)
        if x % 2 == 0: s.block(x, 30, YEL)
    for y in range(2, 30):
        s.block(0, y, YEL)
        if y % 2 == 0: s.block(1, y, YEL)
        s.block(63, y, YEL)
        if y % 2 == 0: s.block(62, y, YEL)
    for (x, y) in ((0, 0), (62, 0), (0, 30), (62, 30)):
        for a in range(2):
            for b in range(2): s.block(x+a, y+b, CYN)

def border_cells():
    """frame cells clockwise from top-left (for the chase light)"""
    cells = [(0, c) for c in range(32)] + [(r, 31) for r in range(1, 16)] + \
            [(15, c) for c in range(30, -1, -1)] + [(r, 0) for r in range(14, 0, -1)]
    return cells

# Cybernoid ship, 10x4 blocks, facing right; 'E' = exhaust (animated)
SHIP = [
"...BCC....",
"E.BBCCBB..",
"EEBBCCBBBB",
"...BCC....",
]
SHIP_PAL = {'B': BUF, 'C': CYN, 'E': ORG}

import random
STARS = []
def stars(s, rows, n=26, seed=7):
    rnd = random.Random(seed)
    STARS = s.stars = []
    while len(STARS) < n:
        r = rnd.choice(rows); c = rnd.randrange(1, 31)
        if (r, c) in s.txt or (r, c) in STARS: continue
        q = [s.blk[2*r+a][2*c+b] for a in (0, 1) for b in (0, 1)]
        if any(v is not None for v in q): continue
        STARS.append((r, c))
        s.block(2*c+rnd.randrange(2), 2*r+rnd.randrange(2), rnd.choice([BUF, CYN, BLU, BLU, MAG]))

import organic
def bioscreen(seed=7):
    """biomass background with a thin (one block) black border"""
    s = Screen()
    organic.biomass(s, seed, 3.0, 0.22)
    for y in range(32):
        for x in range(64):
            if y in (0, 31) or x in (0, 63): s.blk[y][x] = None
    return s
def finish(s, n=30, rows=None):
    s.isolate()
    b = s.bytes()
    rows = rows if rows is not None else range(16)
    cand = organic.bubbles(s, 400, list(rows), seed=len(s.glyph))
    s.bubbles = [rc for rc in cand if b[rc[0]*32+rc[1]] != 0x80 and rc not in s.reserved
                 and not any((x, y) in s.glyph for y in (2*rc[0], 2*rc[0]+1) for x in (2*rc[1], 2*rc[1]+1))][:n]
    return s
def title():
    s = bioscreen(7)
    logo(s, (64-logo_width("CYBERNOID"))//2, 4)
    s.glrow = 2
    s.ctext(6, "THE FIGHTING MACHINE")
    s.ctext(8, "BY RAFFAELE CECCO")
    s.ctext(9, "MUSIC BY DAVE ROGERS")
    s.ctext(11, "PRESS FIRE TO START")
    s.ctext(13, "(C) 1988 HEWSON")
    for c in range(1, 31): s.reserved.add((13, c))     # rotating info line
    return warp_setup(finish(s, 0))

# ---- title background: living flesh. A smooth field gives every cell a
# "depth" band (0-15); each pass the colour table is rotated by one step, so
# rings of red, magenta and blue swell out of the dark and sink back, rolling
# across the screen. Only background quadrants are written (letters, their
# outlines, text and the border stay).
def _S(c, q): return 0x80 | c << 4 | q
# flesh cycle: each step grows or shrinks a cell by a quadrant or changes its
# hue, so neighbouring steps differ only slightly (rows redrawn a frame apart
# never show a seam)
FLESH_LUT = [0x80, _S(RED, 8), _S(RED, 9), _S(RED, 11), _S(RED, 15), _S(MAG, 7), _S(MAG, 15), _S(MAG, 15),
             _S(MAG, 14), _S(MAG, 6), _S(BLU, 6), _S(BLU, 4), 0x80, 0x80, 0x80, 0x80]
def flesh_bands():
    f = organic.field(3, 32, 16, 2, 1)
    return [int(f[r][c]*23.99) & 15 for r in range(16) for c in range(32)]
def warp_setup(s):
    bands = flesh_bands()
    spans = []                              # per row: (col, n, mask)
    for r in range(16):
        row = []; c = 0
        while c < 32:
            m = cellmask(s, r, c)
            if not m: c += 1; continue
            c0 = c
            while c < 32 and cellmask(s, r, c) == m: c += 1
            row.append((c0, c-c0, m))
        spans.append(row)
    s.warp = (bands, spans)
    s.over = {}
    for r in range(16):
        for c0, n, m in spans[r]:
            for c in range(c0, c0+n):
                s.over[(r, c)] = FLESH_LUT[bands[r*32+c]] & m
    return s
def cellmask(s, r, c):
    if (r, c) in s.txt or (r, c) in s.reserved: return 0
    q = 0
    for i, (dx, dy) in enumerate(((0, 0), (1, 0), (0, 1), (1, 1))):
        x, y = 2*c+dx, 2*r+dy
        if (x, y) in s.glyph: return 0
        if (x, y) in s.halo or x in (0, 63) or y in (0, 31): continue
        q |= 1 << (3-i)
    return 0xF0 | q if q else 0

def hof():
    s = bioscreen(13)
    s.small(8, 2, "HALL OF FAME", [BUF, BUF, CYN, CYN, CYN])
    for r in range(4, 14):
        for c in range(6, 27): s.reserved.add((r, c))
    return warp_setup(finish(s, 0))

def entry():
    s = bioscreen(21)
    s.small(2, 2, "CONGRATULATIONS", [BUF, BUF, CYN, CYN, CYN])
    s.ctext(5, "YOUR SCORE IS IN THE")
    s.ctext(6, "CYBERNOID HALL OF FAME")
    s.ctext(8, "PLEASE ENTER YOUR NAME")
    s.ctext(12, "CTRL DELETES  RETURN ENDS")
    for c in range(11, 22): s.reserved.add((10, c))    # name field + cursor
    return warp_setup(finish(s, 0))

def over():
    s = bioscreen(5)
    logo(s, (64-logo_width("GAME OVER"))//2, 8, "GAME OVER")
    s.glrow = 4
    for c in range(1, 31): s.reserved.add((12, c))     # score line
    return warp_setup(finish(s, 0))

def level():
    s = bioscreen(29)
    logo(s, (64-logo_width("CYBERNOID"))//2, 4)
    s.glrow = 2
    for r in (6, 7, 8, 13, 14):                         # report lines (run time)
        for c in range(1, 31): s.reserved.add((r, c))
    return warp_setup(finish(s, 0))

WARPIT = [42, 56, 58, 51, 59]   # samples the warp costs per music step, per screen (measured)
def asm_tables(scrs):
    L = ['; generated by screens.py']
    cells = border_cells()
    L.append('BUBTAB:')
    for i in range(len(scrs)):
        L.append('        dw WSROW%d,%d,0,GLM%d' % (i, WARPIT[i], i))
        L.append('        db 0,%d' % scrs[i].glrow)
    for i, t in enumerate(scrs):
        L.append('GLM%d:   db ' % i + ','.join(str(v) for v in t.glmask()))
    L.append('FLESHLUT: db ' + ','.join('$%02X' % v for v in FLESH_LUT))
    W = []
    for i, t in enumerate(scrs):
        bands, spans = t.warp
        w = ['WSROW%d: dw ' % i + ','.join('WSP%d_%d' % (i, r) for r in range(16))]
        for r in range(16):
            w.append('WSP%d_%d: db %d' % (i, r, len(spans[r])) + ''.join(',%d,%d,$%02X' % sp for sp in spans[r]))
        W.append('\n'.join(w)+'\n')
    asm_tables.ws = W
    L.append('; ---- split ----')
    bands = scrs[0].warp[0]
    L.append('BANDS:')
    for k in range(0, 512, 32): L.append('        db ' + ','.join('LUTLO+%d' % v for v in bands[k:k+32]))
    L.append('LUTP:   ds 16')
    L.append('LUTLO   equ LUTP & 255')
    L.append('        ASSERT (LUTP & 255) <= 240')
    return '\n'.join(L)+'\n'

if __name__ == '__main__':
    import subprocess, os
    B = '/home/claude/cy/build'
    scrs = []
    for name, fn in (('title', title), ('hof', hof), ('entry', entry), ('over', over), ('level', level)):
        sc = fn(); scrs.append(sc)
        b = sc.bytes()
        open(B+'/scr_%s.bin' % name, 'wb').write(b)
        subprocess.run('zx0 -f scr_%s.bin scr_%s.zx0' % (name, name), shell=True, cwd=B, capture_output=True)
        render(b, '/home/claude/cy/run/scr_%s.png' % name)
        print(name, os.path.getsize(B+'/scr_%s.zx0' % name))
    t1, t2 = asm_tables(scrs).split('; ---- split ----')
    open(B+'/screens.asm', 'w').write(t1)
    open(B+'/screens2.asm', 'w').write(t2)
    for i, w in enumerate(asm_tables.ws): open(B+'/ws%d.asm' % i, 'w').write(w)
