"""Spectrum -> VZ mode(1) art conversion helpers (2:1 horizontal, 8:3 vertical)."""
# VZ CSS0 codes: 0 green 1 yellow 2 blue(background) 3 red
VZRGB={0:(0x30,0xd2,0x00),1:(0xc1,0xe5,0x00),2:(0x4c,0x3a,0xb4),3:(0x9a,0x32,0x36)}
SPRGB=[(0,0,0),(0,0,205),(205,0,0),(205,0,205),(0,205,0),(0,205,205),(205,205,0),(205,205,205),
       (0,0,0),(0,0,255),(255,0,0),(255,0,255),(0,255,0),(0,255,255),(255,255,0),(255,255,255)]
BG=2
DEFMAP={0:2,1:3,2:3,3:3,4:0,5:0,6:1,7:1}
def rows_weights(oy,src_h,out_h):
    """source rows and weights covering output row oy"""
    a=oy*src_h/out_h; b=(oy+1)*src_h/out_h
    res=[]
    r=int(a)
    while r<b-1e-9:
        lo=max(a,r); hi=min(b,r+1)
        if hi>lo: res.append((r,hi-lo))
        r+=1
    return res
def downsample(bits,W,H,OW,OH,thr=0.5,lthr=0.3,dither=True):
    """bits[y][x] 0/1 -> out[oy][ox] in {0,1,'d'} ('d' = dithered: checker)"""
    out=[]
    for oy in range(OH):
        rw=rows_weights(oy,H,OH)
        row=[]
        for ox in range(OW):
            cols=[2*ox,2*ox+1]
            tot=0; ink=0
            for r,w in rw:
                for c in cols:
                    tot+=w; ink+=w*bits[r][c]
            f=ink/tot
            # checkerness
            pix=[[bits[r][c] for c in cols] for r,w in rw]
            diff=0; pairs=0
            for rr in range(len(pix)):
                pairs+=1; diff+= pix[rr][0]!=pix[rr][1]
            for rr in range(len(pix)-1):
                for cc in range(2):
                    pairs+=1; diff+= pix[rr][cc]!=pix[rr+1][cc]
            chk=diff/pairs
            if dither and chk>=0.74 and 0.3<=f<=0.7: v='d'
            elif f>=thr: v=1
            elif f>=lthr: v=1 if (chk<0.74) else 'd'
            else: v=0
            row.append(v)
        out.append(row)
    return out
def pack(pix):
    """pix rows of codes (len multiple of 4) -> bytes"""
    out=[]
    for row in pix:
        for i in range(0,len(row),4):
            b=0
            for k in range(4): b=(b<<2)|(row[i+k]&3)
            out.append(b)
    return bytes(out)
# perceptual targets for matching (blue background stands in for black)
TGT={0:(40,190,10),1:(210,220,30),2:(0,0,0),3:(165,30,50)}
SPRGBN=[(0,0,0),(0,0,190),(200,0,0),(200,0,200),(0,200,0),(0,200,200),(200,200,0),(200,200,200)]
def nearest(rgb,allowed=(0,1,2,3)):
    best=None
    for c in allowed:
        t=TGT[c]; d=(rgb[0]-t[0])**2*0.35+(rgb[1]-t[1])**2*0.5+(rgb[2]-t[2])**2*0.15
        if best is None or d<best[0]: best=(d,c)
    return best[1]
def conv_rgb(colfn,W,H,OW,OH,chkfn=None,allowed=(0,1,2,3)):
    """colfn(x,y)->(spectrum colour index, inkbit). Returns VZ codes."""
    out=[]
    for oy in range(OH):
        rw=rows_weights(oy,H,OH); row=[]
        for ox in range(OW):
            cols=[2*ox,2*ox+1]; tot=0; acc=[0,0,0]; ink=0
            pix=[]
            for r,w in rw:
                pr=[]
                for c in cols:
                    ci,b=colfn(c,r); rgb=SPRGBN[ci&7]
                    for k in range(3): acc[k]+=w*rgb[k]
                    tot+=w; ink+=w*b; pr.append(b)
                pix.append(pr)
            avg=[a/tot for a in acc]; f=ink/tot
            diff=0; pairs=0
            for rr in range(len(pix)):
                pairs+=1; diff+= pix[rr][0]!=pix[rr][1]
            for rr in range(len(pix)-1):
                for cc in range(2):
                    pairs+=1; diff+= pix[rr][cc]!=pix[rr+1][cc]
            chk=diff/pairs
            if chk>=0.74 and 0.3<=f<=0.7: v=('d',)
            else: v=nearest(avg,allowed)
            row.append(v)
        out.append(row)
    return out
# ---- structure-aware conversion: ink / shade / paper per VZ pixel
SHADE={0:3,1:3,3:2,2:2}       # darker companion of a VZ colour (green,yellow->red; red->blue)
def conv_struct(bits,cellfn,W,H,OW,OH,thr=0.45,dither=True):
    """bits[y][x]; cellfn(ox,oy)->(ink_vz, paper_vz). Returns VZ codes."""
    out=[]
    for oy in range(OH):
        rw=rows_weights(oy,H,OH); row=[]
        for ox in range(OW):
            ink,pap=cellfn(ox,oy)
            cols=[2*ox,2*ox+1]
            tot=sum(w for r,w in rw)*2
            f=sum(w*bits[r][c] for r,w in rw for c in cols)/tot
            pix=[[bits[r][c] for c in cols] for r,w in rw]
            diff=0; pairs=0
            for rr in range(len(pix)):
                pairs+=1; diff+= pix[rr][0]!=pix[rr][1]
            for rr in range(len(pix)-1):
                for cc in range(2):
                    pairs+=1; diff+= pix[rr][cc]!=pix[rr+1][cc]
            chk=diff/pairs
            strong=[r for r,w in rw if w>=0.5]
            if dither and chk>=0.74 and 0.3<=f<=0.7:
                v=ink if (ox+oy)&1 else pap
            elif f>=thr:
                # groove: a whole source column or row of paper inside the pixel
                gcol=any(all(bits[r][c]==0 for r in strong) for c in cols) if strong else False
                grow=any(bits[r][cols[0]]==0 and bits[r][cols[1]]==0 for r in strong)
                if (gcol or grow) and f<0.8 and ink!=pap:
                    v=SHADE.get(ink,ink) if SHADE.get(ink,ink)!=pap else ink
                else: v=ink
            elif f>=0.25:
                v=SHADE.get(ink,ink) if ink!=pap and SHADE.get(ink,ink)!=pap else (ink if f>=0.34 else pap)
            else: v=pap
            row.append(v)
        out.append(row)
    return out
