"""Helper: run the VZ emulator with the standard header + a script body."""
import subprocess, sys, re
W='/home/claude/cy'
HDR='''mapper 01
loadbin ../build/memA.bin 4000
loadbin ../build/memL.bin 5B00
loadbin ../build/memH.bin 7800
gspec 5B00 67ED
gspec 7814 C6F8
gspec D600 E625
gprot 4000 57FF
gprot 6800 77FF
gprot C6F9 D5FF
setpc 4300
'''
START='''frames 60
down SPACE
frames 5
up SPACE
frames 60
'''
def sym():
    return {l.split(':')[0]:int(l.split('0x')[1],16) for l in open(W+'/build/vz.sym') if 'EQU' in l}
def run(body, name='t', start=True):
    s=HDR+(START if start else '')+body
    open(W+'/vrun/%s.scr'%name,'w').write(s)
    r=subprocess.run([W+'/emu/vzemu',name+'.scr'],cwd=W+'/vrun',capture_output=True,text=True)
    return r.stderr
def sheet(names, out, cols=3):
    from PIL import Image
    ims=[Image.open(W+'/vrun/'+n+'.ppm') for n in names]
    rows=(len(ims)+cols-1)//cols
    o=Image.new('RGB',(256*cols,192*rows))
    for i,im in enumerate(ims): o.paste(im,((i%cols)*256,(i//cols)*192))
    o.save(out)
