"""Prepare the Spectrum image for the VZ build: relocate $67FF-$7813 (the part that
falls on the VZ latch/VRAM at $6800-$77FF) to NEWBASE and fix every reference."""
import sys, json
sys.path.insert(0,'/home/claude/cy/tools')
from z80dis import dis
W='/home/claude/cy'
m=bytearray(open(W+'/build/spec48.bin','rb').read())
LO,HI=0x67EE,0x7814
NEWBASE=int(sys.argv[1],16) if len(sys.argv)>1 else 0xD600
DELTA=NEWBASE-LO
# --- code instruction starts from the coverage listing (+ manual seeds)
code=[]
for line in open(W+'/build/cyber.lst'):
    p=line.split()
    if p[0].endswith(':'): p=p[1:]
    if p[1]!='db': code.append(int(p[0],16))
EXTRA=[0x6BCF,0x6BD2,0x6BD3,0x6BD5,0x6BD6,0x6BFB,0x6BFE,0x6BFF,0x6C00,0x6C03,0x6C04]
code=sorted(set(code+EXTRA))
# data words that point into the moved block (checked by hand, see notes)
DATAW=[0x6C44,0x6C46,0x6C48,   # print-routine vector table
       0x71B0,                 # room 74 (depot) data pointer
       0x7413,0x7422,0x7427,   # coordinate-list bases
       0x88B8,0x88D4]          # object buffers cleared at room start
out=bytearray(m)
fixed=0; seen=[]
def inr(v): return LO<=v<HI
for a in code:
    l,t,i=dis(m,a)
    if t.startswith(('JR','DJNZ')): continue
    for k in ('abs','jump','imm16'):
        v=i.get(k)
        if v is not None and inr(v):
            p=a+l-2
            if (m[p]|m[p+1]<<8)!=v:
                p=a+i['abspos']
            assert (m[p]|m[p+1]<<8)==v,(hex(a),t)
            nv=v+DELTA
            out[p]=nv&255; out[p+1]=nv>>8
            fixed+=1; seen.append(a)
            break
for a in DATAW:
    v=m[a]|m[a+1]<<8
    assert inr(v),hex(a)
    nv=v+DELTA; out[a]=nv&255; out[a+1]=nv>>8
# move the block
blk=out[LO:HI]
img=bytearray(out)
img[NEWBASE:NEWBASE+len(blk)]=blk
for x in range(0x6800,0x7800): img[x]=0
open(W+'/build/spec.bin','wb').write(img)
# check: no relative jumps leaving/entering the block
for a in code:
    l,t,i=dis(m,a)
    if t.startswith(('JR','DJNZ')):
        j=i['jump']
        if inr(a)!=inr(j): print('WARNING relative jump across block %04X %s'%(a,t))
json.dump({'delta':DELTA,'newbase':NEWBASE,'lo':LO,'hi':HI},open(W+'/build/reloc.json','w'))
open(W+'/build/reloc.asm','w').write('RD equ %d\nRELO_LO equ $%04X\nRELO_HI equ $%04X\nRELO_NEW equ $%04X\nRELO_END equ $%04X\n'%(DELTA,LO,HI,NEWBASE,NEWBASE+HI-LO))
print('relocated %d code refs + %d data words; block $%04X-$%04X -> $%04X-$%04X'%(fixed,len(DATAW),LO,HI-1,NEWBASE,NEWBASE+HI-LO-1))
