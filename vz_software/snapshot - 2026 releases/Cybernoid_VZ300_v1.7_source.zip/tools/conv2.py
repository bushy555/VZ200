"""Block conversion v2: per-pixel colour from the Spectrum ink (per 8x8 cell),
area coverage with line/groove preservation and dither detection."""
import sys
sys.path.insert(0,'/home/claude/cy/tools')
from vzart import rows_weights
m=open('/home/claude/cy/build/spec48.bin','rb').read()
G_,Y_,B_,R_=0,1,2,3
# (ink, bright) -> VZ colour
def inkcol(ink,br):
    return {0:B_,1:R_,2:R_,3:R_,4:G_,5:G_,6:Y_,7:(Y_ if br else G_)}[ink]
SHADE={Y_:B_,G_:B_,R_:B_,B_:B_}
def bits(n,base=0xD479):
    return [[(m[base+n*32+y*2+(x>>3)]>>(7-(x&7)))&1 for x in range(16)] for y in range(16)]
def attrs(n): return m[0xE9B9+4*n:0xE9B9+4*n+4]
def conv(n, thr=0.5, lthr=0.3, dither=True):
    b=bits(n); a=attrs(n)
    def col(x,y):
        at=a[(y//8)*2+(x//8)]; return inkcol(at&7,(at>>6)&1)
    out=[]
    for oy in range(6):
        rw=rows_weights(oy,16,6); row=[]
        for ox in range(8):
            xs=(2*ox,2*ox+1)
            tot=0; ink=0; cols={}
            for r,w in rw:
                for x in xs:
                    tot+=w
                    if b[r][x]:
                        ink+=w; c=col(x,r); cols[c]=cols.get(c,0)+w
            f=ink/tot
            # checker score
            pix=[[b[r][x] for x in xs] for r,w in rw]
            diff=pairs=0
            for rr in range(len(pix)):
                pairs+=1; diff+=pix[rr][0]!=pix[rr][1]
            for rr in range(len(pix)-1):
                for cc in range(2): pairs+=1; diff+=pix[rr][cc]!=pix[rr+1][cc]
            chk=diff/pairs
            c=max(cols,key=cols.get) if cols else B_
            strong=[r for r,w in rw if w>=0.6]
            if dither and chk>=0.7 and 0.3<=f<=0.7:
                v=c if (ox+oy)&1 else B_
            elif f>=thr:
                # a full black source row/col inside -> groove: shade
                grow=any(b[r][xs[0]]==0 and b[r][xs[1]]==0 for r in strong)
                gcol=any(all(b[r][x]==0 for r in strong) for x in xs) if strong else False
                v=SHADE[c] if (grow or gcol) and f<0.8 else c
            elif f>=lthr:
                # thin line: a full source row or column of ink in the area
                lrow=any(b[r][xs[0]] and b[r][xs[1]] for r in strong)
                lcol=any(all(b[r][x] for r in strong) for x in xs) if strong else False
                v=c if (lrow or lcol or not dither) else B_
            else: v=B_
            row.append(v)
        out.append(row)
    return out
