import sys
sys.path.insert(0,'/home/claude/cy/tools')
from z80dis import dis
def run(mem,s,e):
    a=s
    while a<e:
        l,t,i=dis(mem,a)
        print('%04X  %-12s %s'%(a,' '.join('%02X'%mem[(a+k)&0xffff] for k in range(l)),t))
        a+=l
if __name__=='__main__':
    m=bytearray(open(sys.argv[1],'rb').read())
    base=int(sys.argv[2],16) if len(sys.argv)>2 else 0
    mem=bytearray(65536); mem[base:base+len(m)]=m[:65536-base]
    run(mem,int(sys.argv[3],16),int(sys.argv[4],16))
