import sys, math
NAMES=['C','C#','D','D#','E','F','F#','G','G#','A','A#','B']
def note(p):
    if p==0: return None
    f=1773400/(16*p); return round(12*math.log2(f/440)+69)
def nn(n): return '%s%d'%(NAMES[n%12],n//12-1) if n is not None else '--'
def load(fn):
    out=[]
    for l in open(fn):
        r=[int(x,16) for x in l.split()[1:]]
        ch=[]
        for k in range(3):
            p=r[2*k]|(r[2*k+1]&15)<<8; vol=r[8+k]&31
            ton=not (r[7]>>k)&1; noi=not (r[7]>>(k+3))&1
            ch.append((note(p) if ton else None,vol,noi,p))
        out.append((ch,r[6]))
    return out
if __name__=='__main__':
    rows=load(sys.argv[1]); a=int(sys.argv[2]); b=int(sys.argv[3])
    for i in range(a,b):
        ch,nz=rows[i]
        print('%5d '%i+' | '.join('%-4s %4d v%2d%s'%(nn(c[0]),c[3],c[1],'N' if c[2] else ' ') for c in ch),'nz%d'%nz)
