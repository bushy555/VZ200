import sys
from PIL import Image, ImageDraw
m=open(sys.argv[1],'rb').read()
base=int(sys.argv[2],16); n=int(sys.argv[3]); W=int(sys.argv[4]); H=int(sys.argv[5]); stride=int(sys.argv[6]); out=sys.argv[7]
cols=int(sys.argv[8]) if len(sys.argv)>8 else 8; S=3
cw=W*8+4; ch=H+12
img=Image.new('RGB',(cols*cw*S,((n+cols-1)//cols)*ch*S),(40,40,40))
d=ImageDraw.Draw(img)
for i in range(n):
    gx=(i%cols)*cw*S; gy=(i//cols)*ch*S
    d.text((gx+2,gy),'%02X'%i,fill=(255,255,0))
    for y in range(H):
        for xb in range(W):
            b=m[base+i*stride+y*W+xb]
            for bit in range(8):
                if (b>>(7-bit))&1:
                    x=xb*8+bit
                    d.rectangle([gx+x*S,gy+12*S//1+y*S-24,gx+x*S+S-1,gy+12*S+y*S+S-1-24],fill=(255,255,255))
img.save(out)
