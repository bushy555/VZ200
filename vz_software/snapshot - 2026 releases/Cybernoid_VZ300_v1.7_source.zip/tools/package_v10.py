"""Package the memory images into one .VZ file for the BennVenn SD loader.

Layout (loads so that it ends at $FA00, below the DOS RAM):
  [stub][zA][zL][zHhi][zHlo]
The stub copies its core to video RAM ($7400) and runs from there:
  zA  -> $4000 (SRAM bank 1),  zL -> $5B00
  zHhi copied to $5800 (attribute area, free until the game starts)
  zHlo -> $7800..T1 forward *in place* (it is the last thing in the file)
  $5800 -> T1..$FFFF (the top of memory, incl. the DOS RAM - no longer needed)
"""
import subprocess, sys, os, re
W = '/home/claude/cy'; B = W + '/build'
sys.path.insert(0, W + '/tools')
from mkvz import mkvz

def run(cmd, cwd=B):
    r = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True)
    if r.returncode != 0 or re.search(r'Errors: [1-9]|error:', r.stdout + r.stderr):
        print(r.stdout[-3000:], r.stderr[-3000:]); sys.exit(1)
    return r.stdout + r.stderr

def zx0(raw, name):
    open(B + '/%s.raw' % name, 'wb').write(raw)
    o = run('zx0 -f %s.raw %s.zx0' % (name, name))
    d = re.search(r'delta (\d+)', o)
    return open(B + '/%s.zx0' % name, 'rb').read(), int(d.group(1)) if d else 0

syms = {}
for l in open(B + '/vz.sym'):
    m = re.match(r'(\S+):\s+EQU\s+0x([0-9A-Fa-f]+)', l)
    if m: syms[m.group(1)] = int(m.group(2), 16)
boot = syms['vz_boot']
memA = open(B + '/memA.bin', 'rb').read()
memL = open(B + '/memL.bin', 'rb').read()
memH = open(B + '/memH.bin', 'rb').read()          # $7800-$FFFF
GAP = 8
T1 = 0xFA00 - GAP
zA, _ = zx0(memA, 'pA')
zL, _ = zx0(memL, 'pL')
zHhi, _ = zx0(memH[T1 - 0x7800:], 'pHhi')
zHlo, d = zx0(memH[:T1 - 0x7800], 'pHlo')
assert d <= GAP, 'in-place delta %d > %d' % (d, GAP)
assert len(zHhi) <= 0x300, 'zHhi too big for the $5800 stash'

stub = r'''
        DEVICE NOSLOT64K
        ORG LOAD
start:  di
        ld sp,$7800
        ld hl,core_src
        ld de,$7400
        ld bc,core_len
        ldir
        jp $7400
core_src:
        DISP $7400
core:   ld a,$03                ; SRAM bank 1 at $4000 (the DOS keeps bank 0)
        out ($37),a
        ld hl,ZA
        ld de,$4000
        call dzx0_standard
        ld hl,ZL
        ld de,$5B00
        call dzx0_standard
        ld hl,ZHHI
        ld de,$5800
        ld bc,ZHHI_LEN
        ldir
        ld hl,ZHLO
        ld de,$7800
        call dzx0_standard
        ld hl,$5800
        ld de,T1
        call dzx0_standard
        jp BOOT
        INCLUDE "/tmp/ZX0/z80/dzx0_standard.asm"
        ENT
core_len equ $-core_src
ZA:     INCBIN "pA.zx0"
ZL:     INCBIN "pL.zx0"
ZHHI:   INCBIN "pHhi.zx0"
ZHHI_LEN equ $-ZHHI
ZHLO:   INCBIN "pHlo.zx0"
all_end:
        ASSERT all_end == $FA00
        SAVEBIN "cyber_vz.bin",start,all_end-start
'''
def build(load, check):
    src = stub.replace('LOAD', '$%04X' % load).replace('T1', '$%04X' % T1).replace('BOOT', '$%04X' % boot)
    if not check: src = src.replace('        ASSERT all_end == $FA00\n', '')
    open(B + '/stub.asm', 'w').write(src)
    run('sjasmplus --nologo --sym=stub.sym stub.asm')
    s = {l.split(':')[0]: int(l.split('0x')[1], 16) for l in open(B + '/stub.sym') if 'EQU' in l}
    return s['all_end'] - s['start']
size = build(0x8000, False)
load = 0xFA00 - size
build(load, True)
img = open(B + '/cyber_vz.bin', 'rb').read()
mkvz(B + '/cyber_vz.bin', B + '/CYBRNOID.VZ', load, 'CYBERNOID')
sz = os.path.getsize(B + '/CYBRNOID.VZ')
print('CYBRNOID.VZ %d bytes, loads $%04X-$F9FF; zA %d zL %d zHhi %d zHlo %d (delta %d), boot $%04X'
      % (sz, load, len(zA), len(zL), len(zHhi), len(zHlo), d, boot))
assert sz <= 31200, 'too big for the SD loader'
