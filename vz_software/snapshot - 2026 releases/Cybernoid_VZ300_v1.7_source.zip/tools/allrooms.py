import sys, json
sys.path.insert(0,'/home/claude/cy/tools')
from roomprev import room_img
from PIL import Image
ids=list(range(int(sys.argv[1]),int(sys.argv[2])))
cols=4
o=Image.new('RGB',(256*cols,(192)*((len(ids)+cols-1)//cols)))
for k,n in enumerate(ids):
    o.paste(room_img(n,1),((k%cols)*256,(k//cols)*192))
o.save(sys.argv[3])
