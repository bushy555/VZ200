import sys; sys.path.insert(0,'/home/claude/cy/tools')
from biogen import show
T=[
["..RRR..R",
 ".R...R.R",
 "R..R..RR",
 "R.....R.",
 ".RR.RR..",
 "R..R..RR"],
["R.RR..RR",
 ".R..R...",
 ".R.R.R.R",
 "R...RR.R",
 ".RRR..R.",
 "..R.RR.."],
[".RR..RR.",
 "R..RR..R",
 "R.R..R..",
 "RR.R.R.R",
 "..R..RR.",
 "RR.RR..R"],
["RR..RR.R",
 "..RR..R.",
 ".R..R..R",
 "R..RR.R.",
 "R.R..RR.",
 ".RR.R..R"],
["..R.RRR.",
 "RR.R...R",
 ".R.R.R.R",
 "R..R..R.",
 ".RR.RR.R",
 "R...R.R."],
]
def parse(t): return [[1 if c=='R' else 0 for c in r] for r in t]
if __name__=='__main__':
    show([parse(t) for t in T],sys.argv[1])
