import sys, json
sys.path.insert(0,'/home/claude/cy/tools')
from PIL import Image, ImageDraw
from vzart import *
m=open('/home/claude/cy/build/spec48.bin','rb').read()
rooms=json.load(open('/home/claude/cy/build/rooms.json'))
art=json.load(open('/home/claude/cy/build/art.json'))
def bits(n): return [[(m[0xD479+n*32+y*2+(x>>3)]>>(7-(x&7)))&1 for x in range(16)] for y in range(16)]
def attr(n): a=m[0xE9B9+4*n:0xE9B9+4*n+4]; return [[a[0],a[1]],[a[2],a[3]]]
def conv(n,cmap,thr):
    b=bits(n); at=attr(n); ds=downsample(b,16,16,8,6,thr=thr,lthr=thr,dither=False)
    return [[ (cmap[at[oy//3][ox//4]&7] if ds[oy][ox] else 2) for ox in range(8)] for oy in range(6)]
def room_img(n,blocks,S=1):
    im=Image.new('RGB',(256*S,192*S),VZRGB[2])
    d=ImageDraw.Draw(im)
    for i,bb in enumerate(rooms[str(n)]):
        if bb>=170: bb=0
        bx=(i%16)*8; by=4+(i//16)*6
        pix=blocks.get(bb, art['blocks'][bb])
        for y in range(6):
            for x in range(8):
                X=(bx+x)*2*S; Y=(by+y)*3*S
                d.rectangle([X,Y,X+2*S-1,Y+3*S-1],fill=VZRGB[pix[y][x]])
    return im
orgs=[1,2,3,4,5,12,13,14,15,52,53,54,55,80,81,82,83,120,121,128,129,130]
opts=[({3:3,2:3},0.4),({3:3,2:1},0.4),({3:1,2:3},0.4),({3:3,2:0},0.4)]
out=Image.new('RGB',(512*2,384*2))
for k,(cm,t) in enumerate(opts):
    full=dict(DEFMAP); full.update(cm)
    blocks={n:conv(n,full,t) for n in orgs}
    out.paste(room_img(0,blocks,2),((k%2)*512,(k//2)*384))
out.save(sys.argv[1])
