import sys, json
sys.path.insert(0,'/home/claude/cy/tools')
from PIL import Image
from vzart import VZRGB, rows_weights
m=open('/home/claude/cy/build/spec48.bin','rb').read()
rooms=json.load(open('/home/claude/cy/build/rooms.json'))
def bits(n): return [[(m[0xD479+n*32+y*2+(x>>3)]>>(7-(x&7)))&1 for x in range(16)] for y in range(16)]
BIO=[1,2,3,4,5,0x0C,0x0D,0x0E,0x0F,0x34,0x35,0x36,0x37,0x80,0x81,0x82,0x83,0x19,0x1A,0x1B,0x1C]
def m_point(b):
    rows=[1,4,6,9,12,14]
    return [[1 if (b[r][2*x] or b[r][2*x+1]) else 0 for x in range(8)] for r in rows]
def m_area(b,thr=0.5):
    out=[]
    for oy in range(6):
        rw=rows_weights(oy,16,6); row=[]
        for ox in range(8):
            t=sum(w for r,w in rw)*2; f=sum(w*(b[r][2*ox]+b[r][2*ox+1]) for r,w in rw)/t
            row.append(1 if f>=thr else 0)
        out.append(row)
    return out
def m_mid(b):  # centre two source rows of each band, 3 of 4 pixels
    out=[]
    for oy in range(6):
        c=(oy+0.5)*16/6; r0=int(c-0.5); r1=r0+1
        out.append([1 if (b[r0][2*x]+b[r0][2*x+1]+b[r1][2*x]+b[r1][2*x+1])>=2 else 0 for x in range(8)])
    return out
METH={'point':m_point,'area':m_area,'mid':m_mid,'area4':lambda b:m_area(b,0.4)}
def room(n,meth,S=2):
    im=Image.new('RGB',(128*S*2,60*S*3),VZRGB[2]); p=im.load()
    for i,blk in enumerate(rooms[str(n)]):
        if blk not in BIO: continue
        pix=METH[meth](bits(blk))
        bx=(i%16)*8; by=(i//16)*6
        for y in range(6):
            for x in range(8):
                if pix[y][x]:
                    for dy in range(3*S):
                        for dx in range(2*S): p[(bx+x)*2*S+dx,(by+y)*3*S+dy]=VZRGB[3]
    return im
if __name__=='__main__':
    ms=sys.argv[2].split(',')
    rs=[int(x) for x in sys.argv[1].split(',')]
    S=1
    out=Image.new('RGB',(256*len(ms),180*len(rs)))
    for j,r in enumerate(rs):
        for i,mm in enumerate(ms): out.paste(room(r,mm,S),(i*256,j*180))
    out.save(sys.argv[3])
