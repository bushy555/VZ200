"""Build: prep (relocation) -> gen (art) -> screens -> assemble -> package CYBRNOID.VZ"""
import subprocess, sys, os
W='/home/claude/cy'
def run(cmd, cwd=None):
    r=subprocess.run(cmd,shell=True,cwd=cwd,capture_output=True,text=True)
    import re
    if r.returncode!=0 or re.search(r'Errors: [1-9]|error:',r.stdout+r.stderr):
        print(r.stdout[-4000:]); print(r.stderr[-4000:]); sys.exit(1)
    return r.stdout
print(run('python3 tools/prep.py',W).strip())
print(run('python3 tools/gen.py',W).strip())
run('python3 tools/screens.py',W)
out=run('sjasmplus --nologo --sym=../build/vz.sym --lst=../build/vz.lst vz.asm',W+'/src')
for l in out.splitlines():
    if l.startswith('>'): print(l)
print(run('python3 tools/package.py',W).strip())
