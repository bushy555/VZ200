import sys; sys.path.insert(0,'/home/claude/cy/tools')
import emu, re
emu.HDR=emu.HDR.replace('gprot C6F9 D5FF\n','gprot C6F9 D5FF\ngprot 81A6 8309\ngprot 830B 8598\ngprot FB86 FDFC\n')
b='frames 100\n'
for i in range(8): b+='frames 8\nscreen w%d.ppm\n'%i
b+='bplog bpm.txt\nbp EFE5\nframes 300\n'
out=emu.run(b,start=False)
print([l for l in out.splitlines() if 'GUARD' in l][:3])
emu.sheet(['w%d'%i for i in range(8)],'/home/claude/cy/vrun/wsheet.png',cols=4)
L=[l for l in open('/home/claude/cy/vrun/bpm.txt').read().split('\n') if l]
fr=[int(l.split()[0]) for l in L]; ln=[int(l.split()[1][1:]) for l in L]
t=[f*312+x for f,x in zip(fr,ln)]
d=[b-a for a,b in zip(t,t[1:])]
print('steps',len(fr),'frames',fr[-1]-fr[0],'step lines min/max',min(d),max(d), 'avg', sum(d)/len(d))
