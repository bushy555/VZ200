import sys; sys.path.insert(0,'/home/claude/cy/tools')
from roomprev import room_img
from PIL import Image
ids=[int(x) for x in sys.argv[1].split(',')]
o=Image.new('RGB',(512*2,384*len(ids)//2+384*(len(ids)%2)))
for k,n in enumerate(ids):
    a=room_img(n,1); b=Image.open('/home/claude/cy/run/rooms/r%02d.ppm'%n)
    x=(k%2)*512; y=(k//2)*192
    o.paste(a,(x,y)); o.paste(b,(x+256,y))
o=o.crop((0,0,1024,192*((len(ids)+1)//2)))
o.save(sys.argv[2])
