import sys, json
sys.path.insert(0,'/home/claude/cy/tools')
from PIL import Image
from vzart import *
W='/home/claude/cy'
art=json.load(open(W+'/build/art.json'))
rooms=json.load(open(W+'/build/rooms.json'))
def room_img(n,S=2):
    im=Image.new('RGB',(256*S,192*S),VZRGB[2])
    c=rooms[str(n)]
    for i,b in enumerate(c):
        if b>=170: b=0
        if 1<=b<=5: b=170+((i//16)%3)*4+(i%16)%4
        bx=(i%16)*8; by=4+(i//16)*6
        pix=art['blocks'][b]
        for y in range(6):
            for x in range(8):
                col=VZRGB[pix[y][x]]
                X=(bx+x)*2*S; Y=(by+y)*3*S
                for dy in range(3*S):
                    for dx in range(2*S): im.putpixel((X+dx,Y+dy),col)
    return im
if __name__=='__main__':
    ids=[int(x) for x in sys.argv[1].split(',')]
    S=1
    sheet=Image.new('RGB',(256*S*len(ids),192*S*2))
    for k,n in enumerate(ids):
        sheet.paste(room_img(n,S),(k*256*S,0))
        sp=Image.open(W+'/run/rooms/r%02d.ppm'%n)
        sheet.paste(sp,(k*256*S,192*S))
    sheet.save(sys.argv[2])
