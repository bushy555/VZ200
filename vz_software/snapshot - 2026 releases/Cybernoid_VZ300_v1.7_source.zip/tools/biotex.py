"""Seamless (toroidal) biomass texture, 32x18 VZ pixels = 4x3 blocks."""
import math, random, sys
sys.path.insert(0,'/home/claude/cy/tools')
from PIL import Image
from vzart import VZRGB
TW,TH=32,18
def noise(seed,fx,fy):
    r=random.Random(seed)
    # sum of periodic sinusoids (torus), random phases
    comps=[]
    for k in range(10):
        kx=r.randint(-fx,fx); ky=r.randint(-fy,fy)
        if kx==0 and ky==0: continue
        comps.append((kx,ky,r.uniform(0,2*math.pi),1/math.hypot(kx,ky*1.5)))
    def f(x,y):
        return sum(a*math.cos(2*math.pi*(kx*x/TW+ky*y/TH)+ph) for kx,ky,ph,a in comps)
    return f
def tex(seed,w=0.22,fx=3,fy=2,mode='lines'):
    f=noise(seed,fx,fy); g=noise(seed+99,fx+1,fy+1)
    vals=[[f(x+0.5,y+0.5) for x in range(TW)] for y in range(TH)]
    v2=[[g(x+0.5,y+0.5) for x in range(TW)] for y in range(TH)]
    flat=sorted(v for r in vals for v in r); lo,hi=flat[0],flat[-1]
    out=[]
    for y in range(TH):
        row=[]
        for x in range(TW):
            t=(vals[y][x]-lo)/(hi-lo)
            # veins: several contour bands
            band=(t*4)%1.0
            c=2
            if abs(band-0.5)<w: c=3
            row.append(c)
        out.append(row)
    return out
def show(t,fn,S=3,rep=(3,3)):
    im=Image.new('RGB',(TW*rep[0]*2*S,TH*rep[1]*3*S)); p=im.load()
    for Y in range(TH*rep[1]):
        for X in range(TW*rep[0]):
            c=VZRGB[t[Y%TH][X%TW]]
            for dy in range(3*S):
                for dx in range(2*S): p[X*2*S+dx,Y*3*S+dy]=c
    im.save(fn)
if __name__=='__main__':
    seeds=[int(s) for s in sys.argv[1].split(',')]
    w=float(sys.argv[2])
    ims=[]
    for s in seeds:
        t=tex(s,w); show(t,'/tmp/claude-0/-home-claude/3d0297f7-bf78-5534-8633-64a7c6f82c97/scratchpad/bt%d.png'%s,S=2,rep=(2,2))
    from PIL import Image as I
    ims=[I.open('/tmp/claude-0/-home-claude/3d0297f7-bf78-5534-8633-64a7c6f82c97/scratchpad/bt%d.png'%s) for s in seeds]
    W_,H_=ims[0].size
    o=I.new('RGB',(W_*2+10,(H_+10)*((len(ims)+1)//2)),(0,0,0))
    for i,im in enumerate(ims): o.paste(im,((i%2)*(W_+10),(i//2)*(H_+10)))
    o.save(sys.argv[3])
