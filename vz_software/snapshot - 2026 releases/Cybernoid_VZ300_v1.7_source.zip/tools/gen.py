"""Generate VZ graphics from the Spectrum data: blocks, sprites, small sprites."""
import sys, json
sys.path.insert(0,'/home/claude/cy/tools')
from vzart import *
W='/home/claude/cy'
m=open(W+'/build/spec48.bin','rb').read()
NBLK=170
def blk_bits(n,base=0xD479):
    return [[(m[base+n*32+y*2+(x>>3)]>>(7-(x&7)))&1 for x in range(16)] for y in range(16)]
def blk_attr(n):
    a=m[0xE9B9+4*n:0xE9B9+4*n+4]; return [[a[0],a[1]],[a[2],a[3]]]
# ---------------------------------------------------------------- blocks
BLKOVR=json.load(open(W+'/tools/blkovr.json')) if __import__('os').path.exists(W+'/tools/blkovr.json') else {}
HAND={}
# luminance ramp: [dark, bright] spectrum colour -> VZ (Y > G > R > blue)
LUM=[{0:2,1:3,2:3,3:3,4:0,5:0,6:1,7:1},{0:2,1:3,2:3,3:3,4:0,5:0,6:1,7:1}]
from handart import HANDBLK, HANDSPR, HANDSML, ORGANIC
import sprhand
HANDSPR=sprhand.S; HANDSML=sprhand.M
HAND={} if __import__('os').environ.get('NOHAND') else HANDBLK
import blkhand, conv2
HAND=blkhand.H
THIN={0x34,0x35,0x36,0x37,0x0C,0x0D,0x0E,0x0F,0x80,0x81,0x82,0x23,0x24,0x25,0x26,0xA0,0xA1,0xA2,0xA3,0x06,0x08}
def conv_block(n):
    if n in HAND: return HAND[n]
    if n in THIN: return conv2.conv(n,thr=0.34,lthr=0.16,dither=False)
    return conv2.conv(n)
def conv_block_old(n):
    bits=blk_bits(n); at=blk_attr(n)
    cmap=dict(DEFMAP); cmap.update({int(k):v for k,v in BLKOVR.get(str(n),{}).get('map',{}).items()})
    ds=downsample(bits,16,16,8,6,thr=0.5,lthr=0.34)
    pix=[]
    for oy in range(6):
        row=[]
        for ox in range(8):
            a=at[oy//3][ox//4]; br=(a>>6)&1
            ink=LUM[br][a&7]; pap=LUM[br][(a>>3)&7]
            v=ds[oy][ox]
            if v=='d': v=(ox+oy)&1
            row.append(ink if v else pap)
        pix.append(row)
    return pix
blocks=[conv_block(n) for n in range(NBLK)]
# ---- biomass: one seamless texture over the whole room (4x3 blocks), chosen
# by block position at draw time (ids 1-5 -> 170 + (row%3)*4 + col%4)
import biotex
def biomass_tex():
    f=biotex.noise(2,2,2)
    TW,TH=biotex.TW,biotex.TH
    vals=[[f(x+0.5,y+0.5) for x in range(TW)] for y in range(TH)]
    flat=sorted(v for r in vals for v in r); lo,hi=flat[0],flat[-1]
    return [[3 if abs(((vals[y][x]-lo)/(hi-lo)*3)%1-0.5)<0.25 else 2 for x in range(TW)] for y in range(TH)]
BIOTEX=biomass_tex()
for ty in range(3):
    for tx in range(4):
        blocks.append([row[tx*8:tx*8+8] for row in BIOTEX[ty*6:ty*6+6]])
NBLK=len(blocks)
blkdata=bytes(b^0xAA for b in b''.join(pack(p) for p in blocks))
# ---------------------------------------------------------------- sprites (XOR)
SPRCOL={1:1,2:1,3:3,4:3,5:3,6:3,7:0,8:0,9:3,10:3,11:3,12:1,13:3,14:3,15:3,16:3,17:1}
def spr24_bits(g):
    base=0xC6F9+g*192
    return [[(m[base+y*3+(x>>3)]>>(7-(x&7)))&1 for x in range(16)] for y in range(16)]
def conv_spr(bits,col,W_=16,H_=16,OW=8,OH=6):
    ds=downsample(bits,W_,H_,OW,OH,thr=0.45,lthr=0.25)
    return [[(col if ((v=='d' and (ox+oy)&1) or v==1) else BG) for ox,v in enumerate(r)] for oy,r in enumerate(ds)]
def xorshifts(pix,wbytes):
    """pix rows (colour codes, BG transparent) -> 4 preshifted XOR images (wbytes per row)"""
    outs=[]
    for s in range(4):
        rows=[]
        for r in pix:
            line=[BG]*s+r+[BG]*(wbytes*4-len(r)-s)
            rows.append([(c^BG) for c in line])
        outs.append(pack(rows))
    return outs
spr24=[]
sprpix=[]
for g in range(18):
    if g in HANDSPR: pix=HANDSPR[g]
    else: pix=conv_spr(spr24_bits(g),SPRCOL.get(g,1))
    sprpix.append(pix)
    spr24+=xorshifts(pix,3)
s24data=b''.join(spr24)
# small sprites: 8 lines, data 2 bytes x 8 x 4 shifts at $EC61 (shift 0 = first 16 bytes)
SMLCOL={0:1,1:1,2:3,3:1,4:1,5:1,6:0,7:0,8:1,9:1,10:0,11:1}
def sml_bits(g):
    base=0xEC61+g*64
    return [[(m[base+y*2+(x>>3)]>>(7-(x&7)))&1 for x in range(8)] for y in range(8)]
smlpix=[]
for g in range(12):
    if g in HANDSML: pix=HANDSML[g]
    else: pix=conv_spr(sml_bits(g),SMLCOL.get(g,1),8,8,4,3)
    smlpix.append(pix)
smldata=b''.join(b''.join(xorshifts(p,2)) for p in smlpix)
assert len(s24data)==18*72 and len(blkdata)==len(blocks)*12 and len(smldata)==12*24
VZS24=0xC6F9; VZBLK=VZS24+len(s24data); VZSML=VZBLK+len(blkdata); GEND=VZSML+len(smldata)
open(W+'/build/vzgfx.bin','wb').write(s24data+blkdata+smldata)
open(W+'/build/gfx.asm','w').write('VZS24 equ $%04X\nVZBLK equ $%04X\nVZSML equ $%04X\nGFX_END equ $%04X\n'%(VZS24,VZBLK,VZSML,GEND))
json.dump({'blocks':blocks,'spr':sprpix,'sml':smlpix},open(W+'/build/art.json','w'))
print('gfx $%04X-$%04X'%(VZS24,GEND-1))

# ---------------------------------------------------------------- panel / text data
from fonts import DIG34, F35, rows_to_nibbles
PBG=3   # panel background: red
def db(name,data):
    return name+':\n'+''.join('        db '+','.join('$%02X'%b for b in data[i:i+16])+'\n' for i in range(0,len(data),16))
ga=[]
dig=[]
for ch in '0123456789 ':
    n=rows_to_nibbles(DIG34[ch]); dig+= [n[0]<<4|n[1], n[2]<<4|n[3]]
ga.append(db('DIGITS',dig))
nib=[]
for c in range(4):
    for v in range(16):
        b=0
        for k in range(4): b=(b<<2)|(c if (v>>(3-k))&1 else PBG)
        nib.append(b)
ga.append(db('NIBTAB',nib))
f5=[]
for code in range(32,96):
    ch=chr(code)
    rows=F35.get(ch,F35[' '])
    f5+= [x<<4 for x in rows_to_nibbles(rows)]
def img(rows):   # rows of chars '.','G','Y','B','R' -> packed VZ bytes
    cm={'.':PBG,'G':0,'Y':1,'B':2,'R':3}
    return list(pack([[cm[c] for c in r] for r in rows]))
from handart import WICON, PSHIP, PHG, BAR
ga.append(db('WICONS',sum((img(WICON[k]) for k in range(5)),[])))
ga.append(db('PICON_SHIP',img(PSHIP)))
ga.append(db('PICON_HG',img(PHG)))
ga.append(db('BARFULL',img(BAR)))
ga.append(db('BARLEN',[round((17-t)*28/17) for t in range(18)]))
ga.append(db('PMASK',[0,0xC0,0xF0,0xFC]))
open(W+'/build/gendata.asm','w').write(''.join(ga))
