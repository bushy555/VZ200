import sys
sys.path.insert(0,'/home/claude/cy/tools')
from PIL import Image, ImageDraw
from vzart import SPRGB
m=open('/home/claude/cy/build/spec48.bin','rb').read()
def blk(n,S=10):
    im=Image.new('RGB',(16*S+1,16*S+1),(60,60,60)); d=ImageDraw.Draw(im)
    for y in range(16):
        for x in range(16):
            b=(m[0xD479+n*32+y*2+(x>>3)]>>(7-(x&7)))&1
            a=m[0xE9B9+4*n+(y//8)*2+(x//8)]
            c=(a&7) if b else (a>>3)&7
            if a&64: c+=8
            d.rectangle([x*S+1,y*S+1,x*S+S-1,y*S+S-1],fill=SPRGB[c])
    return im
ids=[int(x) for x in sys.argv[1].split(',')]
cols=min(6,len(ids))
S=10
out=Image.new('RGB',(cols*(16*S+10),((len(ids)+cols-1)//cols)*(16*S+22)),(20,20,20))
d=ImageDraw.Draw(out)
for k,n in enumerate(ids):
    x=(k%cols)*(16*S+10); y=(k//cols)*(16*S+22)
    out.paste(blk(n,S),(x,y+14)); d.text((x+2,y),str(n),fill=(255,255,0))
out.save(sys.argv[2])
