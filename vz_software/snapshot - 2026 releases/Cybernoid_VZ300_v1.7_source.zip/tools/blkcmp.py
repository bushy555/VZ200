"""Spectrum block vs VZ block, same physical size, for a list of ids."""
import sys, json
sys.path.insert(0,'/home/claude/cy/tools')
from PIL import Image, ImageDraw
from vzart import VZRGB, SPRGB
m=open('/home/claude/cy/build/spec48.bin','rb').read()
import os
art=json.load(open(os.environ.get('ART','/home/claude/cy/build/art.json')))
def spec(n,S):
    im=Image.new('RGB',(16*S,16*S)); p=im.load()
    a=m[0xE9B9+4*n:0xE9B9+4*n+4]
    for y in range(16):
        for x in range(16):
            at=a[(y//8)*2+(x//8)]; b=(m[0xD479+n*32+y*2+(x>>3)]>>(7-(x&7)))&1
            c=(at&7) if b else (at>>3)&7
            if at&64: c+=8
            for dy in range(S):
                for dx in range(S): p[x*S+dx,y*S+dy]=SPRGB[c]
    return im
def vz(pix,S):
    im=Image.new('RGB',(16*S,16*S)); d=ImageDraw.Draw(im)
    for y in range(6):
        for x in range(8):
            d.rectangle([x*2*S,round(y*16*S/6),x*2*S+2*S-1,round((y+1)*16*S/6)-1],fill=VZRGB[pix[y][x]])
    return im
if __name__=='__main__':
    ids=[int(x,16) for x in sys.argv[1].split(',')]
    S=4; cols=8; w=16*S*2+12; h=16*S+14
    out=Image.new('RGB',(w*cols,h*((len(ids)+cols-1)//cols)),(40,40,40)); d=ImageDraw.Draw(out)
    for k,n in enumerate(ids):
        x=(k%cols)*w; y=(k//cols)*h
        out.paste(spec(n,S),(x,y+12)); out.paste(vz(art['blocks'][n],S),(x+16*S+4,y+12))
        d.text((x,y),'%02X'%n,fill=(255,255,0))
    out.save(sys.argv[2])
