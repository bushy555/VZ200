import sys; sys.path.insert(0,'/home/claude/cy/tools')
import emu
s=emu.sym(); RD=28178
def meas(name, pre, start=False):
    b=pre+'bplog tp.txt\nbp EFE5\nframes 200\nbpclear\n'
    emu.run(b,name='tp',start=start)
    L=[l for l in open('/home/claude/cy/vrun/tp.txt').read().split('\n') if l]
    fr=[int(l.split()[0]) for l in L]
    t=[f*312+int(l.split()[1][1:]) for f,l in zip(fr,L)]
    per=(t[-1]-t[0])/(len(t)-1)
    print('%-6s steps %d  lines/step %.2f  (%+.1f%%)'%(name,len(t),per,(per/312-1)*100))
meas('title','frames 100\n')
meas('hof','frames 680\n')
go='frames 150\npoke 78D3 01\npoke 78F9 30\npoke 78FA 33\nrandunt\n'.replace('randunt\n','')+'randuntil %04X 40000 8\nframes 20\n'%s['vz_gameover']
meas('over',go,True)
meas('entry',go+'rununtil %04X 3000\nframes 20\n'%s['vz_entry'],True)
lv='''frames 260
poke 7973 D0
poke 7974 07
poke %04X 00
poke %04X 00
poke %04X 02
frames 250
'''%(0x7644+RD,0x7645+RD,0x7643+RD)
meas('level',lv,True)
