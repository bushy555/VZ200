"""Candidate VZ conversions of each Spectrum block, for picking by eye."""
import sys, json
sys.path.insert(0,'/home/claude/cy/tools')
from PIL import Image, ImageDraw
from vzart import *
m=open('/home/claude/cy/build/spec48.bin','rb').read()
def bits(n): return [[(m[0xD479+n*32+y*2+(x>>3)]>>(7-(x&7)))&1 for x in range(16)] for y in range(16)]
def attr(n): a=m[0xE9B9+4*n:0xE9B9+4*n+4]; return [[a[0],a[1]],[a[2],a[3]]]
CMAP=dict(DEFMAP)
def colourize(n,ds,cmap=CMAP):
    at=attr(n)
    out=[]
    for oy in range(6):
        row=[]
        for ox in range(8):
            a=at[oy//3][ox//4]; ink=cmap[a&7]; pap=cmap[(a>>3)&7]
            v=ds[oy][ox]
            if v=='d': v=(ox+oy)&1
            row.append(ink if v else pap)
        out.append(row)
    return out
def v_area(b,thr,lthr): return downsample(b,16,16,8,6,thr=thr,lthr=lthr)
def v_point(b,rows,off): return [[b[r][2*x+off] for x in range(8)] for r in rows]
def v_pool(b,mode):
    out=[]
    for oy in range(6):
        rw=rows_weights(oy,16,6); row=[]
        for ox in range(8):
            vals=[b[r][c] for r,w in rw if w>0.4 for c in (2*ox,2*ox+1)]
            row.append(int(any(vals)) if mode=='or' else int(all(vals)))
        out.append(row)
    return out
def variants(n):
    b=bits(n)
    vs=[v_area(b,0.5,0.34), v_area(b,0.5,0.5), v_area(b,0.35,0.25), v_point(b,(0,3,5,8,11,13),0), v_point(b,(1,4,6,9,12,14),1),
        v_pool(b,'or'), v_pool(b,'and')]
    at=attr(n)
    def cf(ox,oy):
        a=at[oy//3][ox//4]; return CMAP[a&7], CMAP[(a>>3)&7]
    return [colourize(n,v) for v in vs]+[conv_struct(b,cf,16,16,8,6)]
def vzimg(pix,S):
    im=Image.new('RGB',(8*2*S,6*3*S)); d=ImageDraw.Draw(im)
    for y in range(6):
        for x in range(8): d.rectangle([x*2*S,y*3*S,x*2*S+2*S-1,y*3*S+3*S-1],fill=VZRGB[pix[y][x]])
    return im
def specimg(n,S):
    im=Image.new('RGB',(16*S,16*S)); d=ImageDraw.Draw(im)
    b=bits(n); at=attr(n)
    for y in range(16):
        for x in range(16):
            a=at[y//8][x//8]; c=(a&7) if b[y][x] else (a>>3)&7
            if a&64: c+=8
            d.rectangle([x*S,y*S,x*S+S-1,y*S+S-1],fill=SPRGB[c])
    return im
if __name__=='__main__':
    ids=[int(x) for x in sys.argv[1].split(',')]
    S=3; w=16*S+6
    out=Image.new("RGB",(w*9+30,len(ids)*(18*S+8)),(25,25,25)); d=ImageDraw.Draw(out)
    for k,n in enumerate(ids):
        y=k*(18*S+8)
        d.text((0,y+20),str(n),fill=(255,255,0))
        out.paste(specimg(n,S),(24,y))
        for j,v in enumerate(variants(n)):
            out.paste(vzimg(v,S),(24+w*(j+1),y))
            if k==0: d.text((24+w*(j+1),y),str(j),fill=(255,255,255))
    out.save(sys.argv[2])
