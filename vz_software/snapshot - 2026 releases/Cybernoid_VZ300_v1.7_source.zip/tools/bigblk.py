import sys; sys.path.insert(0,'/home/claude/cy/tools')
from blkcmp import spec
from PIL import Image, ImageDraw
ids=[int(x,16) for x in sys.argv[1].split(',')]
S=5; cols=10
out=Image.new('RGB',(cols*(16*S+4),((len(ids)+cols-1)//cols)*(16*S+14)),(60,60,60)); d=ImageDraw.Draw(out)
for k,n in enumerate(ids):
    x=(k%cols)*(16*S+4); y=(k//cols)*(16*S+14)
    out.paste(spec(n,S),(x,y+12)); d.text((x,y),'%02X'%n,fill=(255,255,0))
out.save(sys.argv[2])
