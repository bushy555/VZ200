import sys
from PIL import Image, ImageDraw
m=open(sys.argv[1],'rb').read()
base=int(sys.argv[2],16); n=int(sys.argv[3]); out=sys.argv[4]
attr=int(sys.argv[5],16) if len(sys.argv)>5 else None
pal=[(0,0,0),(0,0,205),(205,0,0),(205,0,205),(0,205,0),(0,205,205),(205,205,0),(205,205,205),(0,0,0),(0,0,255),(255,0,0),(255,0,255),(0,255,0),(0,255,255),(255,255,0),(255,255,255)]
cols=16; S=3
img=Image.new('RGB',(cols*20*S,((n+cols-1)//cols)*28*S),(40,40,40))
d=ImageDraw.Draw(img)
for i in range(n):
    gx=(i%cols)*20*S; gy=(i//cols)*28*S
    d.text((gx+2,gy),'%02X'%i,fill=(255,255,255))
    for y in range(16):
        for xb in range(2):
            b=m[base+i*32+y*2+xb]
            for bit in range(8):
                x=xb*8+bit
                if attr is not None:
                    a=m[attr+i*4+(y//8)*2+xb]
                    on=(b>>(7-bit))&1
                    c=(a&7) if on else (a>>3)&7
                    if a&64: c+=8
                    col=pal[c]
                else:
                    col=(255,255,255) if (b>>(7-bit))&1 else (0,0,0)
                d.rectangle([gx+x*S,gy+10+y*S,gx+x*S+S-1,gy+10+y*S+S-1],fill=col)
img.save(out)
