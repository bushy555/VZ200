import sys, json
sys.path.insert(0,'/home/claude/cy/tools')
from PIL import Image, ImageDraw
from vzart import *
W='/home/claude/cy'
m=open(W+'/build/spec48.bin','rb').read()
art=json.load(open(W+'/build/art.json'))
def spec_block(n,S):
    im=Image.new('RGB',(16*S,16*S))
    for y in range(16):
        for x in range(16):
            b=(m[0xD479+n*32+y*2+(x>>3)]>>(7-(x&7)))&1
            a=m[0xE9B9+4*n+(y//8)*2+(x//8)]
            c=(a&7) if b else (a>>3)&7
            if a&64: c+=8
            for dy in range(S):
                for dx in range(S): im.putpixel((x*S+dx,y*S+dy),SPRGB[c])
    return im
def vz_img(pix,S):
    h=len(pix); w=len(pix[0])
    im=Image.new('RGB',(w*2*S,h*3*S))
    d=ImageDraw.Draw(im)
    for y in range(h):
        for x in range(w):
            d.rectangle([x*2*S,y*3*S,x*2*S+2*S-1,y*3*S+3*S-1],fill=VZRGB[pix[y][x]])
    return im
def sheet(ids,out,cols=10,S=3):
    cw=16*S*2+12; ch=18*S+14
    img=Image.new('RGB',(cols*cw,((len(ids)+cols-1)//cols)*ch),(30,30,30))
    d=ImageDraw.Draw(img)
    for k,n in enumerate(ids):
        x=(k%cols)*cw; y=(k//cols)*ch
        img.paste(spec_block(n,S),(x,y+12))
        img.paste(vz_img(art['blocks'][n],S),(x+16*S+4,y+12))
        d.text((x+2,y),str(n),fill=(255,255,0))
    img.save(out)
if __name__=='__main__':
    a=int(sys.argv[1]); b=int(sys.argv[2])
    sheet(list(range(a,b)),sys.argv[3])
