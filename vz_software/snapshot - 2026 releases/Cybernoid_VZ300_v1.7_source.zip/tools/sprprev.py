import sys, json
sys.path.insert(0,'/home/claude/cy/tools')
from PIL import Image, ImageDraw
from vzart import VZRGB
m=open('/home/claude/cy/build/spec48.bin','rb').read()
art=json.load(open('/home/claude/cy/build/art.json'))
S=4
def spec(base,W,H,stride,n):
    im=Image.new('RGB',(W*S,H*S),(0,0,0)); d=ImageDraw.Draw(im)
    for y in range(H):
        for x in range(W):
            if (m[base+n*stride+y*(W//8)+(x>>3)]>>(7-(x&7)))&1: d.rectangle([x*S,y*S,x*S+S-1,y*S+S-1],fill=(230,230,230))
    return im
def vz(pix):
    h=len(pix); w=len(pix[0])
    im=Image.new('RGB',(w*2*S,h*3*S)); d=ImageDraw.Draw(im)
    for y in range(h):
        for x in range(w): d.rectangle([x*2*S,y*3*S,x*2*S+2*S-1,y*3*S+3*S-1],fill=VZRGB[pix[y][x]])
    return im
out=Image.new('RGB',(9*2*(16*S+8),4*(18*S+16)),(30,30,30)); d=ImageDraw.Draw(out)
for g in range(18):
    x=(g%9)*2*(16*S+8); y=(g//9)*(18*S+16)
    out.paste(spec(0xC6F9,24,16,192,g).crop((0,0,16*S,16*S)),(x,y+12)); out.paste(vz(art['spr'][g]),(x+16*S+4,y+12)); d.text((x,y),'S%d'%g,fill=(255,255,0))
for g in range(12):
    x=(g%9)*2*(16*S+8); y=2*(18*S+16)+(g//9)*(18*S+16)
    out.paste(spec(0xEC61,16,8,64,g).crop((0,0,8*S,8*S)),(x,y+12)); out.paste(vz(art['sml'][g]),(x+16*S+4,y+12)); d.text((x,y),'s%d'%g,fill=(255,255,0))
out.save(sys.argv[1])
