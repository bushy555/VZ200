"""Procedural tileable biomass tiles (8x6) with shared edge ports."""
import random, heapq, sys
from PIL import Image
sys.path.insert(0,'/home/claude/cy/tools')
from vzart import VZRGB
W,H=8,6
PORTS=[(1,0),(5,0),(1,5),(5,5),(0,1),(0,4),(7,1),(7,4)]
def route(a,b,cost):
    dist={a:0}; prev={}; pq=[(0,a)]
    while pq:
        d,u=heapq.heappop(pq)
        if u==b: break
        if d>dist[u]: continue
        x,y=u
        for dx,dy in ((1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)):
            v=(x+dx,y+dy)
            if not(0<=v[0]<W and 0<=v[1]<H): continue
            nd=d+cost[v[1]][v[0]]*(1.4 if dx and dy else 1)
            if nd<dist.get(v,1e9): dist[v]=nd; prev[v]=u; heapq.heappush(pq,(nd,v))
    p=[b]
    while p[-1]!=a: p.append(prev[p[-1]])
    return p
def tile(seed,cover=0.5):
    r=random.Random(seed)
    ports=PORTS[:]; r.shuffle(ports)
    g=[[0]*W for _ in range(H)]
    cost=[[r.uniform(1,6) for x in range(W)] for y in range(H)]
    for i in range(0,8,2):
        for (x,y) in route(ports[i],ports[i+1],cost):
            g[y][x]=1
            cost[y][x]=8  # avoid overlapping paths
    # keep ports exact: edge cells not at ports are cleared
    for y in range(H):
        for x in range(W):
            edge = x in (0,W-1) or y in (0,H-1)
            if edge and (x,y) not in PORTS and g[y][x]:
                # allow corners only if they connect to port neighbours? clear
                g[y][x]=0
    for (x,y) in PORTS: g[y][x]=1
    # thicken interior up to coverage
    n=sum(map(sum,g)); tries=0
    while n<cover*W*H and tries<500:
        tries+=1
        x=r.randrange(1,W-1); y=r.randrange(1,H-1)
        if g[y][x]: continue
        nb=sum(g[y+dy][x+dx] for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)))
        if nb>=1 and r.random()<0.5: g[y][x]=1; n+=1
    return g
def show(tiles,fn,arr=None,S=3):
    rnd=random.Random(1)
    cols,rows=12,8
    im=Image.new('RGB',(cols*8*2*S,rows*6*3*S)); p=im.load()
    for ty in range(rows):
        for tx in range(cols):
            t=tiles[rnd.randrange(len(tiles))] if arr is None else tiles[arr[ty][tx]]
            for y in range(6):
                for x in range(8):
                    c=VZRGB[3] if t[y][x] else VZRGB[2]
                    for dy in range(3*S):
                        for dx in range(2*S): p[(tx*8+x)*2*S+dx,(ty*6+y)*3*S+dy]=c
    im.save(fn)
if __name__=='__main__':
    seeds=[int(s) for s in sys.argv[1].split(',')]
    cov=float(sys.argv[2])
    ts=[tile(s,cov) for s in seeds]
    for s,t in zip(seeds,ts):
        print(s); print('\n'.join(''.join('R' if v else '.' for v in row) for row in t))
    show(ts,sys.argv[3])
