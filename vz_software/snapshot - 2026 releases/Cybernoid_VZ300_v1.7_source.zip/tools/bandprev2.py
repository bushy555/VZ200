import sys, math; sys.path.insert(0,'/home/claude/cy/tools')
import organic, screens
from screens import *
from PIL import Image
P='/tmp/claude-0/-home-claude/3d0297f7-bf78-5534-8633-64a7c6f82c97/scratchpad/'
f1=organic.field(3, 32, 16, 2, 1)
def S(c,q): return 0x80|c<<4|q
LUT=[0x80, S(RED,8), S(RED,9), S(RED,11), S(RED,15), S(MAG,7), S(MAG,15), S(MAG,15),
     S(MAG,14), S(MAG,6), S(BLU,6), S(BLU,4), 0x80, 0x80, 0x80, 0x80]
def frame(p,mix=False):
    b=bytearray(512)
    for r in range(16):
        pp = p + (1 if (mix and r%4 < (p%4)) else 0)
        for c in range(32):
            band=int(f1[r][c]*23.99)&15
            b[r*32+c]=LUT[(band+pp)&15]
    return bytes(b)
ims=[]
for i in range(8):
    render(frame(i*2, mix=(i>=4)),P+'bf%d.png'%i); ims.append(Image.open(P+'bf%d.png'%i).resize((256,192)))
o=Image.new('RGB',(1024,384))
for i,im in enumerate(ims): o.paste(im,((i%4)*256,(i//4)*192))
o.save('/home/claude/cy/run/bands.png')
