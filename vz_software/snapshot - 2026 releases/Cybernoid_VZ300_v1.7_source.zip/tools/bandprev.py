import sys, math; sys.path.insert(0,'/home/claude/cy/tools')
import organic, screens
from screens import *
from PIL import Image
P='/tmp/claude-0/-home-claude/3d0297f7-bf78-5534-8633-64a7c6f82c97/scratchpad/'
def cellfield(seed, fx=2, fy=1):
    f = organic.field(seed, 32, 16, fx, fy)
    return f
f1=cellfield(int(sys.argv[1]) if len(sys.argv)>1 else 3)
# 16-step colour/shape cycle
F=0xF
LUT=[0x80,0x80,0x80|BLU<<4|F,0x80|RED<<4|F, 0x80|MAG<<4|F,0x80|MAG<<4|F,0x80|RED<<4|F,0x80|BLU<<4|F,
     0x80,0x80,0x80,0x80|RED<<4|F, 0x80|RED<<4|F,0x80|BLU<<4|F,0x80,0x80]
def frame(p):
    b=bytearray(512)
    for r in range(16):
        for c in range(32):
            band=int(f1[r][c]*23.99)&15
            b[r*32+c]=LUT[(band+p)&15]
    return bytes(b)
ims=[]
for i,p in enumerate(range(0,16,2)):
    render(frame(p),P+'bf%d.png'%i); ims.append(Image.open(P+'bf%d.png'%i).resize((256,192)))
o=Image.new('RGB',(1024,384))
for i,im in enumerate(ims): o.paste(im,((i%4)*256,(i//4)*192))
o.save('/home/claude/cy/run/bands.png')
