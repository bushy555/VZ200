"""Coverage-seeded recursive disassembly listing of the Spectrum image."""
import sys
sys.path.insert(0,'/home/claude/cy/tools')
from z80dis import dis
m=bytearray(open(sys.argv[1],'rb').read())
covs=sys.argv[3:]
ex=bytearray(65536); rd=bytearray(65536); wr=bytearray(65536)
for f in covs:
    d=open(f,'rb').read()
    for i in range(65536):
        if d[i]: ex[i]=1
        if len(d)>65536:
            if d[65536+i]: rd[i]=1
            if d[131072+i]: wr[i]=1
exb=bytearray(65536)
for a0 in range(65536):
    if ex[a0]:
        l0,_,_=dis(m,a0)
        for k in range(l0): exb[(a0+k)&0xffff]=1
for a0 in range(65536):
    if exb[a0]: rd[a0]=0
code=bytearray(65536)  # 1=instr start, 2=continuation
SEEDS=[0x7C5C,0x7DCE,0x7E76,0x7E95,0x800E]
starts=[i for i in range(0x5B00,0x10000) if ex[i]]+SEEDS
work=list(starts); seen=set()
while work:
    a=work.pop()
    while a<0x10000 and a not in seen:
        if code[a]==2: break
        l,t,i=dis(m,a)
        if any(code[a+k] for k in range(1,l) if a+k<65536) : break
        if not ex[a] and any((rd[(a+k)&0xffff] or wr[(a+k)&0xffff]) for k in range(l)): break
        seen.add(a); code[a]=1
        for k in range(1,l):
            if a+k<65536: code[a+k]=2
        j=i.get('jump')
        if j is not None and j>=0x5B00: work.append(j)
        if t.startswith('JP ') and ',' not in t and '(' not in t: break
        if t.startswith('JR ') and ',' not in t: break
        if t in ('RET','RETI','RETN') or t.startswith('JP (') : break
        a+=l
refs={}
for a in range(0x5B00,0x10000):
    if code[a]==1:
        l,t,i=dis(m,a)
        for k in ('abs','jump'):
            v=i.get(k)
            if v is not None: refs.setdefault(v,[]).append(a)
out=open(sys.argv[2],'w')
a=0x5B00
while a<0x10000:
    lab=('L%04X:'%a) if a in refs else ''
    if code[a]==1:
        l,t,i=dis(m,a)
        mark='' if ex[a] else ' ;(static)'
        out.write('%-7s %04X  %-12s %s%s\n'%(lab,a,' '.join('%02X'%m[a+k] for k in range(l) if a+k<65536),t,mark))
        a+=l
    else:
        b=a; n=0
        while b<0x10000 and code[b]==0 and n<16 and (b==a or b not in refs): b+=1; n+=1
        flags=''.join('W' if wr[x] else ('r' if rd[x] else '.') for x in range(a,b))
        out.write('%-7s %04X  db %s  ; %s %s\n'%(lab,a,','.join('%02X'%m[x] for x in range(a,b)),flags,''.join(chr(m[x]) if 32<=m[x]<127 else '.' for x in range(a,b))))
        a=b
