"""Package the memory images into CYBRNOID.VZ (v1.1 boot layout).

Lessons from the Xevious port on real hardware: load LOW like an ordinary
program, never run code from video RAM, don't switch the BennVenn mapper.
The file loads at $8000:  [stub][stage2][zS][zH]
  stub   : checks the SRAM at $4000-$67FF is writable as the DOS left it
           (mapping 1; only if not, it tries mapping 1 itself, and if that
           fails too it shows a message instead of crashing),
           unpacks zS -> $4000-$67ED (VZ code, attributes, Spectrum low code),
           copies stage2 to $5800 (attribute area, cleared later) and runs it
  stage2 : moves zH down so it starts 'delta' bytes below $7820, unpacks it
           backwards in place into $7820-$FFFF, copies the 32 bytes for
           $7800-$781F, jumps to vz_boot.
"""
import subprocess, sys, os, re
W = '/home/claude/cy'; B = W + '/build'
sys.path.insert(0, W + '/tools')
from mkvz import mkvz

def run(cmd, cwd=B):
    r = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True)
    if r.returncode != 0 or re.search(r'Errors: [1-9]|error:', r.stdout + r.stderr):
        print(r.stdout[-3000:], r.stderr[-3000:]); sys.exit(1)
    return r.stdout + r.stderr

syms = {}
for l in open(B + '/vz.sym'):
    m = re.match(r'(\S+):\s+EQU\s+0x([0-9A-Fa-f]+)', l)
    if m: syms[m.group(1)] = int(m.group(2), 16)
boot = syms['vz_boot']
memA = open(B + '/memA.bin', 'rb').read()           # $4000-$57FF
memL = open(B + '/memL.bin', 'rb').read()           # $5B00-...
memH = open(B + '/memH.bin', 'rb').read()           # $7800-$FFFF
S = memA + bytes(0x300) + memL                      # $4000-$67xx
assert 0x4000 + len(S) <= 0x6800
open(B + '/pS.raw', 'wb').write(S)
run('zx0 -f pS.raw pS.zx0')
H0 = memH[:0x20]
open(B + '/pH.raw', 'wb').write(memH[0x20:])
o = run('zx0 -f -b pH.raw pH.zx0')
delta = int(re.search(r'delta (\d+)', o).group(1))
zS = open(B + '/pS.zx0', 'rb').read(); zH = open(B + '/pH.zx0', 'rb').read()
Z0 = 0x7820 - delta

src = r'''
        DEVICE NOSLOT64K
        ORG $8000
start:  di
        ld sp,$7FF0
        ld hl,$4000
        call ramtest
        jr nz,.map
        ld hl,$67FF
        call ramtest
        jr z,.ok
.map:   ld a,1                  ; only if the DOS left the SRAM unmapped
        out ($37),a
        ld hl,$4000
        call ramtest
        jr nz,fail
        ld hl,$67FF
        call ramtest
        jr nz,fail
.ok:    ld hl,ZS
        ld de,$4000
        call dzx0_standard
        ld hl,S2SRC
        ld de,$5800
        ld bc,S2_END-S2SRC
        ldir
        jp $5800
; Z if (HL) is writable RAM (contents kept)
ramtest:
        ld a,(hl)
        ld b,a
        cpl
        ld (hl),a
        cp (hl)
        ld (hl),b
        ret
fail:   xor a                   ; mode(0) text
        ld ($6800),a
        ld hl,$7000
        ld de,$7001
        ld bc,511
        ld (hl),$20
        ldir
        ld hl,MSG
        ld de,$7000+6*32
.m:     ld a,(hl)
        or a
        jr z,.h
        cp 64
        jr c,.s
        sub 64
.s:     ld (de),a
        inc hl
        inc de
        jr .m
.h:     jr .h
MSG:    db "CYBERNOID NEEDS THE BENNVENN    "
        db "RAM AT 4000-67FF, BUT IT ISN'T  "
        db "WRITABLE AFTER LOADING.",0
        INCLUDE "/tmp/ZX0/z80/dzx0_standard.asm"
S2SRC:
        DISP $5800
s2:     ld sp,$5AF0
        ld hl,ZH_SRC
        ld de,%(Z0)d
        ld bc,%(ZLEN)d
        ldir                    ; downwards move, source above destination
        ld hl,%(Z0)d+%(ZLEN)d-1
        ld de,$FFFF
        call dzx0_standard_back
        ld hl,H0
        ld de,$7800
        ld bc,32
        ldir
        jp %(BOOT)d
H0:     INCBIN "pH0.raw"
        INCLUDE "/tmp/ZX0/z80/dzx0_standard_back.asm"
        ENT
S2_END:
        ASSERT $5800 + (S2_END - S2SRC) < $5A80
ZS:     INCBIN "pS.zx0"
ZH_SRC: INCBIN "pH.zx0"
all_end:
        ASSERT ZH_SRC > %(Z0)d
        ASSERT all_end <= $F000
        SAVEBIN "cyber_vz.bin",start,all_end-start
''' % dict(Z0=Z0, ZLEN=len(zH), BOOT=boot)
open(B + '/pH0.raw', 'wb').write(H0)
open(B + '/stub.asm', 'w').write(src)
run('sjasmplus --nologo stub.asm')
img = open(B + '/cyber_vz.bin', 'rb').read()
mkvz(B + '/cyber_vz.bin', B + '/CYBRNOID.VZ', 0x8000, 'CYBERNOID')
sz = os.path.getsize(B + '/CYBRNOID.VZ')
print('CYBRNOID.VZ %d bytes, loads $8000-$%04X; zS %d zH %d (delta %d), boot $%04X'
      % (sz, 0x8000 + len(img) - 1, len(zS), len(zH), delta, boot))
assert sz <= 31200, 'too big for the SD loader'
