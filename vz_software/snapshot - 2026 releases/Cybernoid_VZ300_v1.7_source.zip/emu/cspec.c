// Cybernoid Spectrum 48K/128K harness: image load, keys, screens, AY + beeper capture, ROM-call trap.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "z80.h"
#define FRAME 69888
static uint8_t mem[65536], cov[65536], wcov[65536], rcov[65536];
static int covon=0; static z80 cpu; static uint8_t keys[8]; static int beeper=0; static unsigned long beepcount=0, frames=0;
static uint16_t curpc; static uint8_t bpmap[65536]; static FILE *bplog=0; static int bpma=-1,bpml=0;
static unsigned long prof[65536]; static int profon=0; static uint8_t romhit[0x4000];
static int ayreg=0; static uint8_t ay[16]; static FILE *aylog=0; static int aywr=0;
static FILE *wlog=0; static uint8_t watch[65536];
static int guard=0; static uint8_t gseen[65536];
static void gchk(uint16_t a,char k){ if(guard && a>=0x6800 && a<0x7800 && !gseen[curpc]){ gseen[curpc]=1; fprintf(stderr,"GUARD %c %04X at PC %04X frame %lu\n",k,a,curpc,frames);} }
static unsigned rlo=0,rhi=0; static unsigned long rpc[65536];
static uint8_t rb(void *u, uint16_t a) { gchk(a,'r'); if (covon && curpc!=0x6773) rcov[a]=1; if (a>=rlo && a<rhi && (uint16_t)(a-curpc)>3) rpc[curpc]++; return mem[a]; }
static unsigned wlo=0,whi=0; static unsigned long wpc[65536];
static void wb(void *u, uint16_t a, uint8_t v) { gchk(a,'w'); if (a>=wlo && a<whi) wpc[curpc]++; if (watch[a]&&wlog) fprintf(wlog,"%lu PC=%04X W %04X=%02X\n",frames,curpc,a,v); if (a >= 0x4000) { mem[a] = v; if (covon && curpc!=0x6773) wcov[a]=1; } }
static int kemp=0;
static uint8_t pin(z80 *z, uint16_t p) {
  if ((p & 1) == 0) { uint8_t r = 0x1f; uint8_t hi = p >> 8;
    for (int i = 0; i < 8; i++) if (!(hi & (1 << i))) r &= keys[i];
    return r | 0xa0; }
  if ((p & 0xff) == 0x1f) return kemp;
  if ((p & 0xc002) == 0xc000) return ay[ayreg&15];
  return 0xff;
}
static FILE *wavf=0; static long wavn=0; static unsigned long long wavt=0, tglob=0;
static void pout(z80 *z, uint16_t p, uint8_t v) {
  if ((p & 1) == 0) { int nb = (v >> 4) & 1; if (nb != beeper) beepcount++; beeper = nb; }
  if ((p & 0xc002) == 0xc000) ayreg = v;
  else if ((p & 0xc002) == 0x8000) { ay[ayreg&15] = v; aywr++; }
}
static int keypos(const char *k, int *row, int *bit) {
  static const char *rows[8] = {"#ZXCV", "ASDFG", "QWERT", "12345", "09876", "POIUY", "@LKJH", " $MNB"};
  for (int r = 0; r < 8; r++) for (int b = 0; b < 5; b++) if (rows[r][b] == k[0]) { *row = r; *bit = b; return 1; }
  return 0;
}
static void setkey(const char *k, int down) {
  int r, b; if (!strcmp(k, "SPACE")) k = " "; if (!strcmp(k, "ENTER")) k = "@"; if (!strcmp(k, "CAPS")) k = "#"; if (!strcmp(k, "SYM")) k = "$";
  if (keypos(k, &r, &b)) { if (down) keys[r] &= ~(1 << b); else keys[r] |= (1 << b); }
}
static int cat_hook=-1, cat_tgt=0;
static void step1(void) {
  if (cpu.pc==cat_hook) { cat_hook=-1; cpu.sp-=2; mem[cpu.sp]=cpu.pc&255; mem[(uint16_t)(cpu.sp+1)]=cpu.pc>>8; cpu.pc=cat_tgt; }
  curpc = cpu.pc;
  if (covon) cov[curpc] = 1;
  if (curpc < 0x4000 && !romhit[curpc]) { romhit[curpc]=1; uint16_t r = mem[cpu.sp]|mem[(uint16_t)(cpu.sp+1)]<<8; fprintf(stderr,"ROM exec %04X (ret %04X) frame %lu\n",curpc,r,frames); }
  if (bpmap[curpc] && bplog) { fprintf(bplog,"%lu %04X A=%02X BC=%04X DE=%04X HL=%04X IX=%04X IY=%04X SP=%04X :",frames,curpc,cpu.a,(cpu.b<<8)|cpu.c,(cpu.d<<8)|cpu.e,(cpu.h<<8)|cpu.l,cpu.ix,cpu.iy,cpu.sp);
    for(int q=0;q<8;q++) fprintf(bplog," %02X",mem[(uint16_t)(cpu.sp+q)]); if(bpma>=0){fprintf(bplog," | M:"); for(int q=0;q<bpml;q++) fprintf(bplog," %02X",mem[(uint16_t)(bpma+q)]);} fprintf(bplog,"\n"); }
  unsigned long c0 = cpu.cyc;
  z80_step(&cpu);
  int d = cpu.cyc - c0; if (profon) prof[curpc] += d;
  tglob += d; if (wavf) { while (tglob - wavt >= 79) { wavt += 79; short smp = beeper ? 8000 : -8000; fwrite(&smp,2,1,wavf); wavn++; } }
}
static void run_frames(int n) {
  for (int f = 0; f < n; f++) {
    unsigned long start = cpu.cyc; z80_gen_int(&cpu, 0xff); int ic = 0;
    while (cpu.cyc - start < FRAME) { step1(); if (!ic && cpu.cyc - start > 32) { cpu.int_pending = 0; ic = 1; } }
    frames++;
    if (aylog) { fprintf(aylog,"%lu",frames); for(int r=0;r<14;r++) fprintf(aylog," %02X",ay[r]); fprintf(aylog,"\n"); }
  }
}
static void save_ppm(const char *fn) {
  static const int pal[16][3] = {{0,0,0},{0,0,205},{205,0,0},{205,0,205},{0,205,0},{0,205,205},{205,205,0},{205,205,205},
    {0,0,0},{0,0,255},{255,0,0},{255,0,255},{0,255,0},{0,255,255},{255,255,0},{255,255,255}};
  FILE *f = fopen(fn, "wb"); fprintf(f, "P6\n256 192\n255\n");
  for (int y = 0; y < 192; y++) for (int x = 0; x < 256; x++) {
    int a = 0x4000 | ((y & 0xc0) << 5) | ((y & 7) << 8) | ((y & 0x38) << 2) | (x >> 3);
    int at = mem[0x5800 + (y >> 3) * 32 + (x >> 3)];
    int pix = (mem[a] >> (7 - (x & 7))) & 1;
    int c = pix ? (at & 7) : ((at >> 3) & 7); if (at & 64) c += 8;
    fputc(pal[c][0], f); fputc(pal[c][1], f); fputc(pal[c][2], f);
  }
  fclose(f);
}
int main(int argc, char **argv) {
  if (argc < 2) { fprintf(stderr, "cspec script\n"); return 1; }
  memset(keys, 0x1f, 8); memset(mem, 0xff, 0x4000);
  z80_init(&cpu); cpu.read_byte = rb; cpu.write_byte = wb; cpu.port_in = pin; cpu.port_out = pout;
  FILE *s = fopen(argv[1], "r"); char line[256];
  while (fgets(line, sizeof line, s)) {
    char cmd[64], a1[128] = "", a2[128] = ""; if (sscanf(line, "%63s %127s %127s", cmd, a1, a2) < 1 || cmd[0] == ';') continue;
    if (!strcmp(cmd, "frames")) run_frames(atoi(a1));
    else if (!strcmp(cmd, "img")) { FILE *g=fopen(a1,"rb"); fseek(g,0x4000,0); fread(mem+0x4000,1,0xC000,g); fclose(g); }
    else if (!strcmp(cmd, "rom")) { FILE *g=fopen(a1,"rb"); fread(mem,1,0x4000,g); fclose(g); }
    else if (!strcmp(cmd, "down")) setkey(a1, 1);
    else if (!strcmp(cmd, "up")) setkey(a1, 0);
    else if (!strcmp(cmd, "tap")) { setkey(a1, 1); run_frames(5); setkey(a1, 0); run_frames(5); }
    else if (!strcmp(cmd, "kemp")) kemp = strtol(a1,0,16);
    else if (!strcmp(cmd, "screen")) save_ppm(a1);
    else if (!strcmp(cmd, "dump")) { FILE *g=fopen(a1,"wb"); fwrite(mem,1,65536,g); fclose(g); }
    else if (!strcmp(cmd, "cov")) covon = atoi(a1);
    else if (!strcmp(cmd, "covsave")) { FILE *g = fopen(a1, "wb"); fwrite(cov, 1, 65536, g); fwrite(rcov, 1, 65536, g); fwrite(wcov, 1, 65536, g); fclose(g); }
    else if (!strcmp(cmd, "covclear")) { memset(cov, 0, 65536); memset(rcov, 0, 65536); memset(wcov, 0, 65536); }
    else if (!strcmp(cmd, "regs")) { fprintf(stderr, "frame %lu beeps %lu aywr %d  ", frames, beepcount, aywr); fflush(stderr); z80_debug_output(&cpu); fflush(stdout); }
    else if (!strcmp(cmd, "poke")) mem[strtol(a1,0,16)] = strtol(a2,0,16);
    else if (!strcmp(cmd, "setpc")) { cpu.pc = strtol(a1,0,16); if(a2[0]) cpu.sp=strtol(a2,0,16); }
    else if (!strcmp(cmd, "bp")) bpmap[strtol(a1,0,16)] = 1;
    else if (!strcmp(cmd, "bpmem")) { bpma=strtol(a1,0,16); bpml=atoi(a2); }
    else if (!strcmp(cmd, "bpclear")) memset(bpmap,0,sizeof bpmap);
    else if (!strcmp(cmd, "bplog")) { if(bplog) fclose(bplog); bplog = fopen(a1,"w"); }
    else if (!strcmp(cmd, "watch")) { int a=strtol(a1,0,16), b=a2[0]?strtol(a2,0,16):a; for(int i=a;i<=b;i++) watch[i]=1; if(!wlog) wlog=fopen("watch.txt","w"); }
    else if (!strcmp(cmd, "aylog")) { if (aylog) fclose(aylog); aylog = a1[0]=='-'?0:fopen(a1,"w"); }
    else if (!strcmp(cmd, "untilpc")) { unsigned pc=strtol(a1,0,16); long mx=atol(a2); unsigned long st=frames; int hit=0;
        while (!hit && frames-st < mx) { unsigned long start=cpu.cyc; z80_gen_int(&cpu,0xff); int ic=0;
          while (cpu.cyc-start < FRAME) { if(cpu.pc==pc){hit=1;break;} step1(); if(!ic && cpu.cyc-start>32){cpu.int_pending=0;ic=1;} }
          if(!hit) frames++; }
        fprintf(stderr,"untilpc %04X hit=%d frame %lu\n",pc,hit,frames); }
    else if (!strcmp(cmd, "wav")) { wavf=fopen(a1,"wb"); char h[44]={0}; fwrite(h,1,44,wavf); wavt=tglob; wavn=0; }
    else if (!strcmp(cmd, "wavend")) { long n=wavn; fseek(wavf,0,SEEK_SET); unsigned int sr=44304, br=sr*2, ds=n*2, rs=36+ds, fl=16; unsigned short fmt=1,ch=1,ba=2,bps=16;
        fwrite("RIFF",1,4,wavf); fwrite(&rs,4,1,wavf); fwrite("WAVEfmt ",1,8,wavf); fwrite(&fl,4,1,wavf); fwrite(&fmt,2,1,wavf); fwrite(&ch,2,1,wavf); fwrite(&sr,4,1,wavf); fwrite(&br,4,1,wavf); fwrite(&ba,2,1,wavf); fwrite(&bps,2,1,wavf); fwrite("data",1,4,wavf); fwrite(&ds,4,1,wavf); fclose(wavf); wavf=0; }
    else if (!strcmp(cmd, "prof")) { profon = atoi(a1); if (profon) memset(prof,0,sizeof prof); }
    else if (!strcmp(cmd, "profsave")) { FILE *g=fopen(a1,"w"); for(int i=0;i<65536;i++) if(prof[i]) fprintf(g,"%04X %lu\n",i,prof[i]); fclose(g); }
    else if (!strcmp(cmd, "wtrace")) { wlo = strtol(a1,0,16); whi = strtol(a2,0,16); memset(wpc,0,sizeof wpc); }
    else if (!strcmp(cmd, "wsave")) { FILE *g=fopen(a1,"w"); for(int i=0;i<65536;i++) if(wpc[i]) fprintf(g,"%04X %lu\n",i,wpc[i]); fclose(g); }
    else if (!strcmp(cmd, "rtrace")) { rlo = strtol(a1,0,16); rhi = strtol(a2,0,16); memset(rpc,0,sizeof rpc); }
    else if (!strcmp(cmd, "rsave")) { FILE *g=fopen(a1,"w"); for(int i=0;i<65536;i++) if(rpc[i]) fprintf(g,"%04X %lu\n",i,rpc[i]); fclose(g); }
    else if (!strcmp(cmd, "rand")) { int n=atoi(a1); const char *ks[6]={"M","O","P","Q","A","SPACE"}; srand(atoi(a2)+frames);
        const char *ws[5]={"1","2","3","4","5"}; for(int i=0;i<n;i+=8){ for(int k=0;k<6;k++) setkey(ks[k], (rand()%3)==0); int w=rand()%40; for(int k=0;k<5;k++) setkey(ws[k], w==k); run_frames(8);} for(int k=0;k<6;k++) setkey(ks[k],0); for(int k=0;k<5;k++) setkey(ws[k],0); }
    else if (!strcmp(cmd, "callat")) { cat_hook=strtol(a1,0,16); cat_tgt=strtol(a2,0,16); }
    else if (!strcmp(cmd, "guard")) guard=atoi(a1);
    else fprintf(stderr, "?? %s\n", cmd);
  }
  return 0;
}
