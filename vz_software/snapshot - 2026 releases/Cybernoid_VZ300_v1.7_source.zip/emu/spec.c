// Minimal ZX Spectrum 48K harness: tape pulses, keyboard script, dumps, coverage.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "z80.h"

#define FRAME 69888
static uint8_t mem[65536];
static uint8_t cov[65536];      // executed-PC coverage
static uint8_t rcov[65536], wcov[65536];
static int covon = 0;
static unsigned wlo=0,whi=0; static unsigned long wpc[65536]; static unsigned long prof[65536]; static int profon=0; static uint16_t curpc; static uint8_t bpmap[65536]; static FILE *bplog=0; static int bpma=-1,bpml=0;
static z80 cpu;
static uint8_t keys[8];          // active-low rows
static uint8_t border = 0;
static int beeper = 0;
static unsigned long beepcount = 0;

// tape pulses
static int *pulses; static int npulses = 0, pcap = 0, ppos = 0;
static long pulse_left = 0; static int ear = 0; static int tape_on = 0;
static void addp(int t) { if (npulses == pcap) { pcap = pcap ? pcap * 2 : 65536; pulses = realloc(pulses, pcap * sizeof(int)); } pulses[npulses++] = t; }
static void load_tap(const char *fn) {
  FILE *f = fopen(fn, "rb"); if (!f) { perror(fn); exit(1); }
  if (strstr(fn, ".pls")) { int t; while (fread(&t, 4, 1, f) == 1) addp(t); fclose(f); fprintf(stderr, "pulses: %d\n", npulses); return; }
  static uint8_t d[1 << 20]; int n = fread(d, 1, sizeof d, f); fclose(f);
  int i = 0;
  while (i + 2 <= n) {
    int L = d[i] | d[i + 1] << 8; uint8_t *b = d + i + 2;
    int pilot = b[0] < 128 ? 8063 : 3223;
    for (int k = 0; k < pilot; k++) addp(2168);
    addp(667); addp(735);
    for (int k = 0; k < L; k++) for (int bit = 7; bit >= 0; bit--) { int t = (b[k] >> bit) & 1 ? 1710 : 855; addp(t); addp(t); }
    addp(3500000 * 2); // pause ~0.5s  (as one long level)
    i += 2 + L;
  }
  fprintf(stderr, "tape: %d pulses\n", npulses);
}
static void tape_adv(int cyc) {
  if (!tape_on) return;
  pulse_left -= cyc;
  while (pulse_left <= 0) {
    if (ppos >= npulses) { tape_on = 0; return; }
    ear ^= 1; pulse_left += pulses[ppos++];
  }
}

static unsigned rlo=0,rhi=0; static unsigned long rpc[65536]; static uint16_t rfirst[65536];
static uint8_t rb(void *u, uint16_t a) { if (covon) rcov[a] = 1; if (a>=rlo && a<rhi && a!=curpc && (uint16_t)(a-curpc)>3) { if(!rpc[curpc]) rfirst[curpc]=a; rpc[curpc]++; } return mem[a]; }
static void wb(void *u, uint16_t a, uint8_t v) { if (a>=wlo && a<whi) wpc[curpc]++; if (a >= 0x4000) { mem[a] = v; if (covon) wcov[a] = 1; } }

static FILE *lsin=0,*lsout=0; static unsigned long lsi=0, lsraw0=0, lstr=0; static FILE *lstrf=0; static unsigned long lsdn=0, lsskip=0; static char lsdfn[200];
static void ls_hook(uint16_t pc, uint8_t (*R)(void*,uint16_t), void (*Wr)(void*,uint16_t,uint8_t)) {
  if (!lsout) return;
  if (lstrf && lsi==lstr && pc<0x8000==0) fprintf(lstrf,"%04X\n",pc);
  if (pc == 0xA360) {
    lsi++; if (lsdn && lsi==lsdn) { FILE *g=fopen(lsdfn,"wb"); for (int a=0;a<65536;a++) fputc(R(0,a),g); fclose(g); }
    uint32_t h=2166136261u;
    for (int a=0x5CB2;a<0x6200;a++){ if (a==0x6140) continue; h^=R(0,a); h*=16777619u; }
    fprintf(lsout,"%lu %08X",lsi,h);
    if (lsi>=lsraw0 && lsi<=lsraw0+12) { fprintf(lsout," RAW"); for (int a=0x5CB2;a<0x6200;a++) fprintf(lsout,"%02X",R(0,a)); }
    for (int q=0;q<8;q++) fprintf(lsout," %02X",R(0,0x5CB2+q));
    fprintf(lsout," A402=%02X lives=%02X score=%02X%02X\n",R(0,0xA402),R(0,0x6145),R(0,0x614B),R(0,0x614C));
    uint16_t rnd = (uint16_t)(lsi*40503u+12345u); Wr(0,0xE1F7,rnd&255); Wr(0,0xE1F8,rnd>>8); Wr(0,0x5C80,(lsi%14)==0?0:20);
  }
  if (pc == 0xA360 && lsskip) Wr(0,0x5C94,1);
  if (pc == 0xD66C && lsskip && ((cpu.h<<8)|cpu.l)==0x5C88) { Wr(0,0x5C88,(lsi%lsskip)==lsskip-1?1:0); }
  if (pc == 0xA382 && lsin) { int v; if (fscanf(lsin,"%d",&v)==1) Wr(0,0x5C86,v); else Wr(0,0x5C86,0); }
}
static uint8_t pin(z80 *z, uint16_t p) {
  if ((p & 1) == 0) {
    uint8_t r = 0x1f; uint8_t hi = p >> 8;
    for (int i = 0; i < 8; i++) if (!(hi & (1 << i))) r &= keys[i];
    r |= 0xa0; if (ear) r |= 0x40;
    return r;
  }
  if ((p & 0xff) == 0x1f) return 0; // kempston
  return 0xff;
}
static FILE *wavf=0; static long wavn=0; static unsigned long long wavt=0, tglob=0;
static void pout(z80 *z, uint16_t p, uint8_t v) {
  if ((p & 1) == 0) { border = v & 7; int nb = (v >> 4) & 1; if (nb != beeper) beepcount++; beeper = nb; }
}

// key names -> (row, bit)
static int keypos(const char *k, int *row, int *bit) {
  static const char *rows[8] = {"#ZXCV", "ASDFG", "QWERT", "12345", "09876", "POIUY", "@LKJH", " $MNB"};
  // '#'=CAPS SHIFT, '$'=SYMBOL SHIFT, '@'=ENTER, ' '=SPACE
  for (int r = 0; r < 8; r++) for (int b = 0; b < 5; b++) if (rows[r][b] == k[0]) { *row = r; *bit = b; return 1; }
  return 0;
}
static void setkey(const char *k, int down) {
  int r, b; if (!strcmp(k, "SPACE")) k = " "; if (!strcmp(k, "ENTER")) k = "@"; if (!strcmp(k, "CAPS")) k = "#"; if (!strcmp(k, "SYM")) k = "$";
  if (keypos(k, &r, &b)) { if (down) keys[r] &= ~(1 << b); else keys[r] |= (1 << b); }
}

static unsigned long frames = 0;
static uint8_t *tblk[256]; static int tlen[256], ntblk=0, tcur=0, trapon=0; static unsigned long nloads=0;
static void do_trap(void) {
  uint8_t flag = cpu.a_; int ix = cpu.ix, de = (cpu.d<<8)|cpu.e;
  for (int k = 0; k < ntblk; k++) { int j = (tcur + k) % ntblk;
    if (tblk[j][0] == flag) { int n = tlen[j]-2; if (n > de) n = de; for (int q=0;q<n;q++) wb(0, ix+q, tblk[j][1+q]);
      fprintf(stderr,"TRAP load flag %02X -> %04X len %d (blk %d) frame %lu\n",flag,ix,de,j,frames); tcur=(j+1)%ntblk; nloads++;
      cpu.cf = 1; cpu.ix = ix+de; cpu.d=cpu.e=0; break; } }
  uint16_t r = mem[cpu.sp] | mem[(uint16_t)(cpu.sp+1)]<<8; cpu.sp += 2; cpu.pc = r;
}
static int ltrap=0;
static void do_ltrap(void) {
  int req = mem[0x5CA1], hl = (cpu.h<<8)|cpu.l; char fn[64]; char t = hl==0x6E00?'M':hl==0x6200?'C':'S';
  sprintf(fn, "lv/%c%02X.bin", t, req); FILE *g = fopen(fn, "rb");
  if (!g) { fprintf(stderr, "LTRAP missing %s\n", fn); cpu.cf = 0; }
  else { static uint8_t bb[8192]; int n = fread(bb,1,sizeof bb,g); fclose(g); for (int q=0;q<n;q++) wb(0,hl+q,bb[q]); cpu.cf = 1; fprintf(stderr,"LTRAP %s -> %04X (%d) frame %lu\n",fn,hl,n,frames); }
  uint16_t r = mem[cpu.sp] | mem[(uint16_t)(cpu.sp+1)]<<8; cpu.sp += 2; cpu.pc = r;
}
static unsigned long long tot = 0;
static void run_frames(int n) {
  for (int f = 0; f < n; f++) {
    unsigned long start = cpu.cyc;
    z80_gen_int(&cpu, 0xff);
    int intclear = 0;
    while (cpu.cyc - start < FRAME) {
      unsigned long c0 = cpu.cyc;
      if (covon) cov[cpu.pc] = 1;
      curpc = cpu.pc;
      ls_hook(cpu.pc,rb,wb);
      if (trapon && cpu.pc == 0x0562) { do_trap(); continue; } if (ltrap && cpu.pc == 0xD331) { do_ltrap(); continue; }
      if (bpmap[curpc] && bplog) { fprintf(bplog,"%lu %04X A=%02X BC=%04X DE=%04X HL=%04X IX=%04X IY=%04X SP=%04X :",frames,curpc,cpu.a,(cpu.b<<8)|cpu.c,(cpu.d<<8)|cpu.e,(cpu.h<<8)|cpu.l,cpu.ix,cpu.iy,cpu.sp); for(int q=0;q<32;q++) fprintf(bplog," %02X",mem[(uint16_t)(cpu.iy+q)]); fprintf(bplog," | HL:"); for(int q=0;q<16;q++) fprintf(bplog," %02X",mem[(uint16_t)(((cpu.h<<8)|cpu.l)+q)]); fprintf(bplog," | SP:"); for(int q=0;q<12;q++) fprintf(bplog," %02X",mem[(uint16_t)(cpu.sp+q)]); if(bpma>=0){fprintf(bplog," | M:"); for(int q=0;q<bpml;q++) fprintf(bplog," %02X",mem[(uint16_t)(bpma+q)]);} fprintf(bplog,"\n"); }
      z80_step(&cpu);
      int d = cpu.cyc - c0;
      if (profon) prof[curpc] += d;
      tglob += d; if (wavf) { while (tglob - wavt >= 79) { wavt += 79; short smp = beeper ? 8000 : -8000; fwrite(&smp,2,1,wavf); wavn++; } }
      tape_adv(d);
      if (!intclear && cpu.cyc - start > 32) { cpu.int_pending = 0; intclear = 1; }
    }
    frames++;
  }
}

static void save_ppm(const char *fn) {
  static const int pal[16][3] = {{0,0,0},{0,0,205},{205,0,0},{205,0,205},{0,205,0},{0,205,205},{205,205,0},{205,205,205},
    {0,0,0},{0,0,255},{255,0,0},{255,0,255},{0,255,0},{0,255,255},{255,255,0},{255,255,255}};
  FILE *f = fopen(fn, "wb"); fprintf(f, "P6\n256 192\n255\n");
  for (int y = 0; y < 192; y++) for (int x = 0; x < 256; x++) {
    int a = 0x4000 | ((y & 0xc0) << 5) | ((y & 7) << 8) | ((y & 0x38) << 2) | (x >> 3);
    int at = mem[0x5800 + (y >> 3) * 32 + (x >> 3)];
    int pix = (mem[a] >> (7 - (x & 7))) & 1;
    int c = pix ? (at & 7) : ((at >> 3) & 7); if (at & 64) c += 8;
    fputc(pal[c][0], f); fputc(pal[c][1], f); fputc(pal[c][2], f);
  }
  fclose(f);
}
static void dump_state(const char *fn) {
  FILE *f = fopen(fn, "wb"); fwrite(mem, 1, 65536, f);
  // regs appended
  uint8_t r[32]; int i = 0;
  r[i++] = cpu.pc; r[i++] = cpu.pc >> 8; r[i++] = cpu.sp; r[i++] = cpu.sp >> 8;
  r[i++] = cpu.a; r[i++] = cpu.b; r[i++] = cpu.c; r[i++] = cpu.d; r[i++] = cpu.e; r[i++] = cpu.h; r[i++] = cpu.l;
  r[i++] = cpu.ix; r[i++] = cpu.ix >> 8; r[i++] = cpu.iy; r[i++] = cpu.iy >> 8; r[i++] = cpu.i; r[i++] = cpu.interrupt_mode; r[i++] = cpu.iff1;
  fwrite(r, 1, i, f); fclose(f);
}

int main(int argc, char **argv) {
  if (argc < 3) { fprintf(stderr, "spec rom script [tap]\n"); return 1; }
  FILE *f = fopen(argv[1], "rb"); fread(mem, 1, 16384, f); fclose(f);
  memset(keys, 0x1f, 8);
  if (argc > 3) load_tap(argv[3]);
  z80_init(&cpu); cpu.read_byte = rb; cpu.write_byte = wb; cpu.port_in = pin; cpu.port_out = pout;
  FILE *s = fopen(argv[2], "r"); char line[256];
  while (fgets(line, sizeof line, s)) {
    char cmd[64], a1[128] = "", a2[128] = ""; if (sscanf(line, "%63s %127s %127s", cmd, a1, a2) < 1 || cmd[0] == ';') continue;
    if (!strcmp(cmd, "frames")) run_frames(atoi(a1));
    else if (!strcmp(cmd, "down")) setkey(a1, 1);
    else if (!strcmp(cmd, "up")) setkey(a1, 0);
    else if (!strcmp(cmd, "tap")) { setkey(a1, 1); run_frames(5); setkey(a1, 0); run_frames(5); }
    else if (!strcmp(cmd, "tape")) { tape_on = 1; }
    else if (!strcmp(cmd, "tblk")) { FILE *g=fopen(a1,"rb"); static uint8_t bb[70000]; int n=fread(bb,1,sizeof bb,g); fclose(g); tblk[ntblk]=malloc(n); memcpy(tblk[ntblk],bb,n); tlen[ntblk++]=n; }
    else if (!strcmp(cmd, "trap")) { trapon = atoi(a1); }
    else if (!strcmp(cmd, "ltrap")) { ltrap = atoi(a1); }
    else if (!strcmp(cmd, "screen")) save_ppm(a1);
    else if (!strcmp(cmd, "dump")) dump_state(a1);
    else if (!strcmp(cmd, "cov")) { covon = atoi(a1); }
    else if (!strcmp(cmd, "covsave")) { FILE *g = fopen(a1, "wb"); fwrite(cov, 1, 65536, g); fwrite(rcov, 1, 65536, g); fwrite(wcov, 1, 65536, g); fclose(g); }
    else if (!strcmp(cmd, "covclear")) { memset(cov, 0, 65536); memset(rcov, 0, 65536); memset(wcov, 0, 65536); }
    else if (!strcmp(cmd, "load")) { FILE *g = fopen(a1, "rb"); fread(mem, 1, 65536, g); uint8_t r[32]; fread(r, 1, 18, g); fclose(g);
      cpu.pc = r[0] | r[1] << 8; cpu.sp = r[2] | r[3] << 8; cpu.a = r[4]; cpu.b = r[5]; cpu.c = r[6]; cpu.d = r[7]; cpu.e = r[8]; cpu.h = r[9]; cpu.l = r[10];
      cpu.ix = r[11] | r[12] << 8; cpu.iy = r[13] | r[14] << 8; cpu.i = r[15]; cpu.interrupt_mode = r[16]; cpu.iff1 = cpu.iff2 = r[17]; }
    else if (!strcmp(cmd, "regs")) { fprintf(stderr, "frame %lu tape_on %d ppos %d/%d beeps %lu  ", frames, tape_on, ppos, npulses, beepcount); z80_debug_output(&cpu); fflush(stdout); }
    else if (!strcmp(cmd, "untiltape")) { int mx = atoi(a1); while (tape_on && mx-- > 0) run_frames(1); }
    else if (!strcmp(cmd, "rand")) { int n=atoi(a1); const char *ks[5]={"M","O","P","Q","A"}; srand(atoi(a2)+frames);
        for(int i=0;i<n;i+=8){ for(int k=0;k<5;k++) setkey(ks[k], (rand()%3)==0 || (k==0 && rand()%2)); run_frames(8);} for(int k=0;k<5;k++) setkey(ks[k],0); }
    else if (!strcmp(cmd, "lockstep")) { lsin=fopen(a1,"r"); lsout=fopen(a2,"w"); lsi=0; }
    else if (!strcmp(cmd, "lsraw")) { lsraw0=atol(a1); }
    else if (!strcmp(cmd, "lsskip")) { lsskip=atol(a1); }
    else if (!strcmp(cmd, "lsdump")) { lsdn=atol(a1); strcpy(lsdfn,a2); }
    else if (!strcmp(cmd, "lstrace")) { lstr=atol(a1); lstrf=fopen(a2,"w"); }
    else if (!strcmp(cmd, "poke")) { mem[strtol(a1,0,16)] = strtol(a2,0,16); }
    else if (!strcmp(cmd, "setpc")) { cpu.pc = strtol(a1,0,16); if(a2[0]) cpu.sp=strtol(a2,0,16); }
    else if (!strcmp(cmd, "pokew")) { int a=strtol(a1,0,16),v=strtol(a2,0,0); mem[a]=v&255; mem[a+1]=v>>8; }
    else if (!strcmp(cmd, "bp")) { bpmap[strtol(a1,0,16)] = 1; }
    else if (!strcmp(cmd, "bpmem")) { bpma=strtol(a1,0,16); bpml=atoi(a2); }
    else if (!strcmp(cmd, "bpclear")) { memset(bpmap,0,sizeof bpmap); }
    else if (!strcmp(cmd, "bplog")) { if(bplog) fclose(bplog); bplog = fopen(a1,"w"); }
    else if (!strcmp(cmd, "rtrace")) { rlo = strtol(a1,0,16); rhi = strtol(a2,0,16); memset(rpc,0,sizeof rpc); }
    else if (!strcmp(cmd, "rsave")) { FILE *g=fopen(a1,"w"); for(int i=0;i<65536;i++) if(rpc[i]) fprintf(g,"%04X %lu first=%04X\n",i,rpc[i],rfirst[i]); fclose(g); }
    else if (!strcmp(cmd, "untilpc")) { unsigned pc=strtol(a1,0,16); long mx=atol(a2); unsigned long st=frames; 
        while (frames-st < mx) { unsigned long start=cpu.cyc; int hit=0; z80_gen_int(&cpu,0xff); int ic=0;
          while (cpu.cyc-start < FRAME) { if(cpu.pc==pc){hit=1;break;} curpc=cpu.pc; if (covon) cov[cpu.pc]=1; if (trapon && cpu.pc == 0x0562) { do_trap(); continue; } if (ltrap && cpu.pc == 0xD331) { do_ltrap(); continue; } z80_step(&cpu); tape_adv(0); if(!ic && cpu.cyc-start>32){cpu.int_pending=0;ic=1;} }
          if(hit) break; frames++; }
        fprintf(stderr,"untilpc %04X at frame %lu pc=%04X\n",pc,frames,cpu.pc); }
    else if (!strcmp(cmd, "wav")) { wavf=fopen(a1,"wb"); char h[44]={0}; fwrite(h,1,44,wavf); wavt=tglob; wavn=0; }
    else if (!strcmp(cmd, "wavend")) { long n=wavn; fseek(wavf,0,SEEK_SET); unsigned int sr=44304, br=sr*2, ds=n*2, rs=36+ds, fl=16; unsigned short fmt=1,ch=1,ba=2,bps=16;
        fwrite("RIFF",1,4,wavf); fwrite(&rs,4,1,wavf); fwrite("WAVEfmt ",1,8,wavf); fwrite(&fl,4,1,wavf); fwrite(&fmt,2,1,wavf); fwrite(&ch,2,1,wavf); fwrite(&sr,4,1,wavf); fwrite(&br,4,1,wavf); fwrite(&ba,2,1,wavf); fwrite(&bps,2,1,wavf); fwrite("data",1,4,wavf); fwrite(&ds,4,1,wavf); fclose(wavf); wavf=0; }
    else if (!strcmp(cmd, "wtrace")) { wlo = strtol(a1,0,16); whi = strtol(a2,0,16); memset(wpc,0,sizeof wpc); }
    else if (!strcmp(cmd, "wsave")) { FILE *g=fopen(a1,"w"); for(int i=0;i<65536;i++) if(wpc[i]) fprintf(g,"%04X %lu\n",i,wpc[i]); fclose(g); }
    else if (!strcmp(cmd, "prof")) { profon = atoi(a1); if(!profon) {} else memset(prof,0,sizeof prof); }
    else if (!strcmp(cmd, "profsave")) { FILE *g=fopen(a1,"w"); for(int i=0;i<65536;i++) if(prof[i]) fprintf(g,"%04X %lu\n",i,prof[i]); fclose(g); }
    else fprintf(stderr, "?? %s\n", cmd);
  }
  return 0;
}
