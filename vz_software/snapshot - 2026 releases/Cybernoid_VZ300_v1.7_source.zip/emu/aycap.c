// run NZ Story 128K AY player: aycap bank1.bin tune frames > out.txt
#include <stdio.h>
#include <stdlib.h>
#include "z80.h"
static uint8_t mem[65536];
static uint8_t rb(void*u,uint16_t a){return mem[a];}
static void wb(void*u,uint16_t a,uint8_t v){mem[a]=v;}
static uint8_t pin(z80*z,uint16_t p){return 0xff;}
static void pout(z80*z,uint16_t p,uint8_t v){}
static z80 c;
static void call(uint16_t a,uint8_t A){ c.pc=a; c.sp=0x8000; mem[0x8000]=0; mem[0x8001]=0; c.a=A; long n=0; while(c.pc!=0 && n<2000000){z80_step(&c);n++;} }
int main(int ac,char**av){ FILE*f=fopen(av[1],"rb"); fread(mem,1,65536,f); fclose(f);
 z80_init(&c); c.read_byte=rb; c.write_byte=wb; c.port_in=pin; c.port_out=pout;
 int t=atoi(av[2]), fr=atoi(av[3]);
 call(0xC000,t);
 for(int i=0;i<fr;i++){ call(0xC0D3,0); printf("%d",mem[0xC63E]); for(int r=0;r<12;r++) printf(" %02X",mem[0xC461+r]); printf("\n"); }
}
