; ---- data -------------------------------------------------------------------
SCRTAB: dw ZS_TITLE,ZS_HOF,ZS_ENTRY,ZS_OVER,ZS_LEVEL
ZS_TITLE: INCBIN "../build/scr_title.zx0"
ZS_OVER:  INCBIN "../build/scr_over.zx0"

