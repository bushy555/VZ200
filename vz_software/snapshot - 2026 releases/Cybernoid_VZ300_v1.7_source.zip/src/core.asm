; ---------------------------------------------------------------------------
; Core: boot, interrupt, latch/mode, input, pause/quit, delay
; ---------------------------------------------------------------------------
vz_boot:
        di
        ld sp,$61A7             ; (the loader leaves the BennVenn mapper alone)
        call vz_joy_detect
        call vz_gentabs
        call vz_settext
        jp S_START              ; Spectrum entry (DI, SP=0, ...)

; ---- interrupt: $FDFD -> here. INT is level-held during field sync: wait
; for the sync to end, then run the Spectrum handler (ends EI/RETI).
vz_isr:
        push af
.w:     ld a,(LATCH)
        rla
        jr nc,.w                ; bit7 low = field sync active
        ld a,(vz_tick)
        inc a
        ld (vz_tick),a
        pop af
        jp S_ISR

; ---- latch / mode ----------------------------------------------------------
; A = latch base (mode/css bits)
vz_setlatch:
        ld (vz_latch),a
        push af
        or L_SPK0
        ld (vz_spk_off),a
        ld (LATCH),a
        pop af
        or L_SPK1
        ld (vz_spk_on),a
        ret
vz_setgfx:
        ld a,1
        ld (vz_mode),a
        ld a,L_MODE
        jr vz_setlatch
vz_settext:
        xor a
        ld (vz_mode),a
        ld a,(vz_css0)
        jr vz_setlatch

; ---- 688F: game controls -> $68A7 left, $68A8 right, $68A9 up, $68AA fire
vz_input:
        call vz_read_controls
        ld hl,S_KEYS
        ld b,0
        rra                     ; bit0 left
        rl b
        ld (hl),b
        inc hl
        ld b,0
        rra                     ; bit1 right
        rl b
        ld (hl),b
        inc hl
        rra                     ; bit2 down (unused)
        ld b,0
        rra                     ; bit3 up
        rl b
        ld (hl),b
        inc hl
        ld b,0
        rra                     ; bit4 fire
        rl b
        ld (hl),b
        ret

; read VZ controls -> A: bit5 arm, bit4 fire, bit3 up, bit2 down, bit1 right, bit0 left
vz_read_controls:
        push bc
        push hl
        ld c,0
        ld a,(KR0)
        bit 4,a
        jr nz,.n1
        set 3,c                 ; Q up / thrust
.n1:    ld a,(KR1)
        bit 4,a
        jr nz,.n2
        set 2,c                 ; A down
.n2:    ld a,(KR6)
        bit 1,a
        jr nz,.n3
        set 0,c                 ; O left
.n3:    bit 4,a
        jr nz,.n4
        set 1,c                 ; P right
.n4:    ld a,(KR4)
        bit 4,a                 ; SPACE = fire
        jr nz,.n4b
        set 4,c
.n4b:   bit 5,a                 ; M = special weapon (as the joystick ARM)
        jr nz,.n5
        set 5,c
.n5:    ld a,(vz_joyok)
        or a
        jr z,.nojoy
        push de
        ld hl,JMAP
        ld e,12
.jm:    ld a,(hl)
        inc hl
        push bc
        ld c,a
        in a,(c)
        pop bc
        and (hl)
        inc hl
        jr nz,.js
        ld a,c
        or (hl)
        ld c,a
.js:    inc hl
        dec e
        jr nz,.jm
        pop de
.nojoy: ld a,c
        pop hl
        pop bc
        ret

; joystick map: (port, active-low mask, result bits); fire = bit4, arm = bit5
; standard ports: J1 fire $2E, J1 arm $2D, J2 fire $2B, J2 arm $27
JMAP:
        db $2C,$01,$08, $2C,$02,$04, $2C,$04,$01, $2C,$08,$02, $2E,$10,$10, $2D,$10,$20
        db $29,$01,$08, $29,$02,$04, $29,$04,$01, $29,$08,$02, $2B,$10,$10, $27,$10,$20

vz_joy_detect:
        ld b,8
        ld c,$FF
.l:     in a,($2E)
        and c
        ld c,a
        in a,($2D)
        and c
        ld c,a
        djnz .l
        ld a,c
        and $1F
        cp $1F
        ld a,1
        jr z,.ok
        xor a
.ok:    ld (vz_joyok),a
        ret

; ---- 7B4A: weapon keys -> A = Spectrum row $F7FE (bits 0-4 = keys 1-5,
; active low). The joystick ARM button selects the next weapon.
vz_wkeys:
        push bc
        ld a,(KR3)              ; VZ: b0=5 b1=2 b3=3 b4=1 b5=4
        ld c,$FF
        bit 4,a
        jr nz,.k2
        res 0,c
.k2:    bit 1,a
        jr nz,.k3
        res 1,c
.k3:    bit 3,a
        jr nz,.k4
        res 2,c
.k4:    bit 5,a
        jr nz,.k5
        res 3,c
.k5:    bit 0,a
        jr nz,.kj
        res 4,c
.kj:    ld a,c
        pop bc
        ret

; ---- 7C24: special weapon trigger. The Spectrum used "fire held for 5+
; loops"; here it is the joystick ARM button or M, and FIRE is the laser only.
vz_spkey:
        call vz_read_controls
        and $20
        ret z
        ld a,5
        ret

; ---- 65EB: pause (H) --------------------------------------------------------
vz_pause:
        ld a,(KR7)
        bit 0,a
        ret nz
        push af
        push bc
        push de
        push hl
.r1:    call vz_anykey          ; wait for release
        jr nz,.r1
.p:     call vz_anykey
        jr z,.p
.r2:    call vz_anykey
        jr nz,.r2
        pop hl
        pop de
        pop bc
        pop af
        ret

; ---- 660B: CTRL+Q restarts (the Spectrum used 1-5 together) -------------
vz_quitchk:
        ld a,(KR1)
        bit 2,a                 ; CTRL
        ret nz
        ld a,(KR0)
        bit 4,a                 ; Q
        ret nz
        jp S_START

; ---- NZ if any key / fire
vz_anykey:
        push bc
        push hl
        call vz_read_controls
        and $30
        jr nz,.y
        ld bc,$FF08
        ld hl,$68FE
.k:     ld a,(hl)
        and $3F
        cp $3F
        jr nz,.y
        rlc l
        dec c
        jr nz,.k
        pop hl
        pop bc
        xor a
        ret
.y:     pop hl
        pop bc
        or 1
        ret
vz_waitrel:
.r:     ei
        halt
        call vz_anykey
        jr nz,.r
        ret
vz_waitkey:
        call vz_waitrel
.p:     ei
        halt
        call vz_anykey
        jr z,.p
        ret

; ---- 676A: delay BC (the Spectrum did LDIR from ROM onto itself: 21T/byte)
vz_delay:
        push af
        push bc
.l:     dec bc                  ; 6
        ld a,b                  ; 4
        or c                    ; 4
        nop                     ; 4
        jr nz,.l                ; 12 -> 30 (close enough with LDIR's 21 + contention)
        pop bc
        pop af
        ret
