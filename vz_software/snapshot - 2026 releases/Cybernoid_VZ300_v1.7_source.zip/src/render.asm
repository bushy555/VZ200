; ---------------------------------------------------------------------------
; Renderer: mode(1) 128x64, 4 colours.  Spectrum 256x192 -> VZ 2:1 x 8:3.
; Panel = VZ lines 0-3, playfield (Spectrum y 32..191) = VZ lines 4-63.
; Blocks 16x16 -> 8x6 (2 bytes x 6 lines). Sprites are XORed straight into
; VRAM exactly like the Spectrum (erase old + draw new), with their images
; stored pre-XORed against the blue background, so over background they show
; their true colours. Blocks are stored in the same XOR form (art ^ $AA), so
; one copy serves both the opaque room draw and the XOR block-sprites.
; ---------------------------------------------------------------------------

; ---- tables: YADL/YADH = VRAM line address for Spectrum y, YCNT = lines left
vz_gentabs:
        ld b,0                  ; y
.y:     ld a,b
        cp 32
        jr c,.inv
        cp 192
        jr nc,.inv
        sub 32                  ; line = 4 + (3*(y-32))>>3
        ld e,a
        ld d,0
        ld l,e
        ld h,d
        add hl,hl
        add hl,de               ; 3*(y-32)
        srl h
        rr l
        srl h
        rr l
        srl h
        rr l
        ld a,l
        add a,4                 ; VZ line 4..63
        ld c,a
        ld l,a
        ld h,0
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        ld de,VRAM
        add hl,de
        ex de,hl
        ld h,YADL/256
        ld l,b
        ld (hl),e
        inc h
        ld (hl),d
        inc h
        ld a,64
        sub c                   ; lines left
        cp 6
        jr c,.c
        ld a,6
.c:     ld (hl),a
        jr .n
.inv:   ld h,YADL/256
        ld l,b
        xor a
        ld (hl),a
        inc h
        ld (hl),a
        inc h
        ld (hl),a
.n:     inc b
        jr nz,.y
        ; colour fill table: 2-bit code -> full byte
        ret

; ---- A548: opaque block A at (D=y,E=x) --------------------------------------
vz_block:
        cp $E9
        ret nc
        push af
        push bc
        push de
        push hl
        dec a                   ; biomass 1-5 -> room-wide texture tile
        cp 5
        jr nc,.nb
        ld a,d                  ; row = (y-32)/16 mod 3
        sub 32
        rrca
        rrca
        rrca
        rrca
        and $0F
.m3:    cp 3
        jr c,.r3
        sub 3
        jr .m3
.r3:    add a,a
        add a,a
        ld l,a
        ld a,e                  ; col = (x/8) & 3   (E = x/2)
        rrca
        rrca
        rrca
        and 3
        add a,l
        add a,170
        jr .im
.nb:    inc a
.im:    call vz_blkimg          ; HL = image
        push hl
        ld h,YADL/256
        ld l,d
        ld c,(hl)
        inc h
        ld b,(hl)
        inc h
        ld a,(hl)
        pop hl
        or a
        jr z,.x
        ex de,hl                ; DE = image, L = x
        ld h,a                  ; H = count
        ld a,l
        rrca
        rrca
        and $1F
        add a,c
        ld l,a
        ld a,h
        ld h,b                  ; HL = vram
        ld b,a
.l:     ld a,(de)
        xor BGBYTE
        ld (hl),a
        inc de
        inc l
        ld a,(de)
        xor BGBYTE
        ld (hl),a
        inc de
        ld a,l
        add a,31
        ld l,a
        jr nc,.nc
        inc h
.nc:    djnz .l
.x:     pop hl
        pop de
        pop bc
        pop af
        ret

; HL = VZBLK + A*12
vz_blkimg:
        ld l,a
        ld h,0
        add hl,hl
        add hl,hl
        push bc
        ld c,l
        ld b,h
        add hl,hl
        add hl,bc
        ld bc,VZBLK
        add hl,bc
        pop bc
        ret

; ---- A539: HL = handle of block A (for a later XOR erase) ------------------
vz_blkhandle:
        jr vz_blkimg

; ---- A1FD: 24-wide sprite. A = new graphic, HL = old handle, BC = old pos,
;      DE = new pos (E = x in 2-pixel units, D = y). Returns HL = new handle.
vz_spr24:
        push af
        push bc
        push de
        push bc
        push hl
        ld l,a
        ld h,0
        add hl,hl
        add hl,hl               ; A*4
        ld a,e
        and 3
        add a,l
        ld l,a
        add hl,hl               ; *2
        ld c,l
        ld b,h
        add hl,hl
        add hl,hl
        add hl,hl               ; *16
        add hl,bc               ; *18
        ld bc,VZS24
        add hl,bc
        ld (vz_newh),hl
        pop hl                  ; old image
        pop de                  ; old pos
        ld a,3
        call vz_xor
        ld hl,(vz_newh)
        pop de
        push de
        ld a,3
        call vz_xor
        ld hl,(vz_newh)
        pop de
        pop bc
        pop af
        ret

; ---- A4DB: block-sprite (16x16 block graphic, XOR, byte aligned) ----------
;      A = new block, HL = old handle, BC = old pos, DE = new pos -> HL new
vz_blkspr:
        push af
        push bc
        push de
        push bc
        push hl
        call vz_blkimg
        ld (vz_newh),hl
        pop hl
        pop de
        ld a,e
        and $FC                 ; byte aligned like the Spectrum
        ld e,a
        ld a,2
        call vz_xor
        ld hl,(vz_newh)
        pop de
        push de
        ld a,e
        and $FC
        ld e,a
        ld a,2
        call vz_xor
        ld hl,(vz_newh)
        pop de
        pop bc
        pop af
        ret

; ---- 80BD: small sprite A (8 lines) XOR at DE ------------------------------
vz_small:
        push af
        push bc
        push de
        push hl
        ld l,a
        ld h,0
        add hl,hl
        add hl,hl               ; *4
        ld a,e
        and 3
        add a,l
        ld l,a
        add hl,hl               ; *2
        ld c,l
        ld b,h
        add hl,hl               ; *4
        add hl,bc               ; *6
        ld bc,VZSML
        add hl,bc
        ld a,$82                ; width 2, max 3 lines
        call vz_xor
        pop hl
        pop de
        pop bc
        pop af
        ret

; ---- generic XOR blit: HL = image, D = y, E = x, A = width (2/3) +
;      bit7 = 3-line image (small sprite). Clips to the playfield.
vz_xor:
        ld (vz_xw),a
        push hl
        ld h,YADL/256
        ld l,d
        ld c,(hl)
        inc h
        ld b,(hl)
        inc h
        ld a,(hl)               ; lines left (0 = invisible)
        pop hl
        or a
        ret z
        ld d,a
        ld a,(vz_xw)
        bit 7,a
        jr z,.h6
        ld a,d
        cp 3
        jr c,.h6
        ld d,3
.h6:    ld a,d
        ld (vz_xh),a
        ; column
        ld a,e
        cp $AA
        jr nc,.clip
        rrca
        rrca
        and $3F
        ld d,a
        ld a,(vz_xw)
        and $7F
        cp 3
        ld a,d
        jr z,.w3
        cp 31
        jr nc,.clip
        add a,c
        ld c,a
        ex de,hl
        ld h,b
        ld l,c
        ld a,(vz_xh)
        ld b,a
.l2:    ld a,(de)
        xor (hl)
        ld (hl),a
        inc de
        inc l
        ld a,(de)
        xor (hl)
        ld (hl),a
        inc de
        ld a,l
        add a,31
        ld l,a
        jr nc,.n2
        inc h
.n2:    djnz .l2
        ret
.w3:    cp 30
        jr nc,.clip
        add a,c
        ld c,a
        ex de,hl
        ld h,b
        ld l,c
        ld a,(vz_xh)
        ld b,a
.l3:    ld a,(de)
        xor (hl)
        ld (hl),a
        inc de
        inc l
        ld a,(de)
        xor (hl)
        ld (hl),a
        inc de
        inc l
        ld a,(de)
        xor (hl)
        ld (hl),a
        inc de
        ld a,l
        add a,30
        ld l,a
        jr nc,.n3
        inc h
.n3:    djnz .l3
        ret
        ; ---- clipped: signed column c0, per byte test
.clip:  ld a,e
        rrca
        rrca
        and $3F
        ld d,a
        ld a,e
        cp $AA
        ld a,d
        jr c,.cp
        sub 64
.cp:    ld (vz_xc),a
        ex de,hl                ; DE = image
        ld h,b
        ld l,c                  ; HL = line base
        ld a,(vz_xh)
        ld b,a
.cl:    push bc
        push hl
        ld a,(vz_xw)
        and $7F
        ld b,a
        ld a,(vz_xc)
        ld c,a
.cb:    ld a,c
        cp 32
        jr nc,.cs               ; outside 0..31
        push hl
        add a,l
        ld l,a
        ld a,(de)
        xor (hl)
        ld (hl),a
        pop hl
.cs:    inc de
        inc c
        djnz .cb
        pop hl
        ld bc,32
        add hl,bc
        pop bc
        djnz .cl
        ret

; ---- 7A2D: laser dot. C = pixel mask, D = y, E = x. Returns HL = Spectrum
;      screen address for the collision test that follows.
vz_dot:
        ld a,e
        cp $80
        jr nc,.s
        ld h,YADH/256
        ld l,d
        ld a,(hl)
        or a
        jr z,.s
        ld b,a
        dec h
        ld a,e
        rrca
        rrca
        and $1F
        add a,(hl)
        ld l,a
        ld h,b
        ld a,c
        xor (hl)
        ld (hl),a
.s:     jp $673B

; ---- 66AA: clear the whole screen (+ Spectrum attributes) ------------------
vz_cls:
        push af
        push bc
        push de
        push hl
        call vz_attrclr
        call vz_setgfx
        ld hl,VRAM
        ld de,VRAM+1
        ld bc,2047
        ld (hl),BGBYTE
        ldir
        call vz_panelbg
        pop hl
        pop de
        pop bc
        pop af
        ret
vz_attrclr:
        ld hl,$5800
        ld de,$5801
        ld bc,$2FF
        ld (hl),0
        ldir
        ret

; ---- 66C0: clear the play area (rows 4-23) ---------------------------------
vz_clsplay:
        push af
        push bc
        push de
        push hl
        ld hl,$5880
        ld de,$5881
        ld bc,$27F
        ld (hl),0
        ldir
        ld a,(vz_mode)
        or a
        call z,vz_cls           ; came from a text screen: full mode(1) set-up
        ld hl,VRAM+4*32
        ld de,VRAM+4*32+1
        ld bc,60*32-1
        ld (hl),BGBYTE
        ldir
        pop hl
        pop de
        pop bc
        pop af
        ret
