; ---------------------------------------------------------------------------
; Cybernoid VZ300 conversion - equates
; ---------------------------------------------------------------------------
LATCH       equ $6800
VRAM        equ $7000
MAPPER      equ $37            ; BennVenn mapper port
MAP_RUN     equ $03            ; SRAM on, SRAM bank 1 at $4000 (bank 0 = the DOS)
MAP_EXP0    equ $03            ; same but expansion bank 0 (the DOS's bank)

L_SPK0      equ $01
L_MODE      equ $08            ; 1 = mode(1) graphics
L_CSS       equ $10
L_SPK1      equ $20

BGBYTE      equ $AA            ; playfield background (blue)

; keyboard rows (active low, bits 0-5)
KR0         equ $68FE          ; T W - E Q R
KR1         equ $68FD          ; G S CTRL D A F
KR2         equ $68FB          ; B X SHIFT C Z V
KR3         equ $68F7          ; 5 2 - 3 1 4
KR4         equ $68EF          ; N . - , SPACE M
KR5         equ $68DF          ; 6 9 - 8 0 7
KR6         equ $68BF          ; Y O RET I P U
KR7         equ $687F          ; H L : K ; J

; ---- Spectrum game addresses (relocated block uses +RD) --------------------
S_FRAMES    equ $711A+RD       ; ISR frame counter
S_ISR       equ $70D3+RD       ; Spectrum interrupt handler body
S_KEYS      equ $68A7+RD       ; left, right, up, fire flags
S_POS       equ $6969+RD       ; ship x,y
S_LIVES     equ $78D3
S_SCORE     equ $78F9          ; 6 ASCII digits
S_CARGO     equ $796C          ; 6 ASCII digits
S_WEAPON    equ $7BFA
S_WTAB      equ $7BAA          ; weapon table, 16 bytes per weapon
S_TIMER     equ $79D3          ; timer bar steps used (0..$11)
S_SOUND     equ $830A          ; sound on flag
S_HISC      equ $949C          ; hall of fame: 10 x (name 10, score 6), $FF
S_LEVEL     equ $74E1+RD
S_ROOM      equ $744B+RD
S_START     equ $6504
