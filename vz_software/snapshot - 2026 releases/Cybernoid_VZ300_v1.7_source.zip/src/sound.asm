; ---------------------------------------------------------------------------
; Sound: the 48K beeper effects engine runs unchanged from the interrupt;
; only its output loop (8631-8647) is replaced to drive the VZ speaker.
; ---------------------------------------------------------------------------
vz_sfxloop:
.a:     exx
        ld c,2
        ld a,(vz_spk_on)
.b:     ld b,(hl)
        ld (LATCH),a
.c:     exx
        dec hl
        exx
        djnz .c
        ex de,hl
        ld a,(vz_spk_off)
        dec c
        jr nz,.b
        exx
        bit 7,h
        jr z,.a
        jp $8649
