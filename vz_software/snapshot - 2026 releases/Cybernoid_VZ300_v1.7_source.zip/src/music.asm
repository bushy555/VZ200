; ---------------------------------------------------------------------------
; Music: the original 128K AY music driver ($EF38-$F27B, Dave Rogers' tunes
; at $F27B-$FB85) runs unchanged once per 50 Hz step; its AY register shadow
; ($F1F6-$F203) is turned into three speaker voices:
;  * true pitch: phase increment = K / AY period (16-bit accumulators, so
;    the driver's vibrato and slides come through),
;  * pulse-interleaved mixing (each voice owns a third of every sample),
;  * pulse width follows the AY volume (decays, accents),
;  * AY noise becomes a short noise burst at the start of the step.
; The front end screens animate from vz_mhook once per step.
; ---------------------------------------------------------------------------
AY_PLAY     equ $EFE5
AY_STOP     equ $EF93
AY_START    equ $EF43           ; C = channel, E = tune (entry after LD C,A)
AYR         equ $F1F6           ; shadow: R0..R13

MPERIOD     equ 183             ; T-states per output sample (3 voices)
MFRAME      equ 70937           ; T-states per 50 Hz step (3.5469 MHz)
MITERS      equ MFRAME/MPERIOD - 52   ; minus per-step overhead (measured)
MDRUMN      equ 90              ; noise samples in a burst
MDRUMIT     equ 88              ; tone samples the burst replaces

T_TITLE     equ $01
T_OVER      equ $22
T_ENTRY     equ $28

; ---- start tune E (keeps playing until vz_mstop) -------------------------
vz_mstart:
        push ix
        push iy
        push de
        call AY_STOP
        pop de
        ld c,1
        call AY_START
        pop iy
        pop ix
        xor a
        ld (vz_mbusy),a
        ret

; ---- run music + hook for up to B steps (0 = until a key); returns NZ if a
; key/fire was pressed (the press is left for the caller). If the music is
; switched off, the hook still runs at 50 Hz from HALT.
vz_mplay:
        ld a,b
        ld (vz_msteps),a
.step:  ld a,(vz_musicon)
        or a
        jr nz,.mus
        ei
        halt
        call vz_hook
        jr .chk
.mus:   call vz_mstep
.chk:   call vz_anykey
        jr nz,.key
        ld a,(vz_msteps)
        or a
        jr z,.step
        dec a
        ld (vz_msteps),a
        jr nz,.step
        xor a
        ret
.key:   or 1
        ret

vz_hook:
        ld hl,(vz_mhook)
        jp (hl)
vz_nohook:
        ret

; ---- one 50 Hz music step --------------------------------------------------
vz_mstep:
        di
        push ix
        push iy
        call AY_PLAY
        pop iy
        pop ix
        call vz_hook
        ; --- voices from the register shadow
        ld a,(AYR+7)
        ld (vz_mmix),a
        ld hl,AYR+0
        ld de,AYR+8
        ld a,0
        call .voice
        ld (vz_a1),hl
        ld (.t1+1),a
        ld hl,AYR+2
        ld de,AYR+9
        ld a,1
        call .voice
        ld (vz_a2),hl
        ld (.t2+1),a
        ld hl,AYR+4
        ld de,AYR+10
        ld a,2
        call .voice
        ld (vz_a3),hl
        ld (.t3+1),a
        ; --- noise: any channel with noise on and volume -> burst
        ld a,(vz_mmix)
        cpl
        rrca
        rrca
        rrca
        and 7
        ld c,a
        ld hl,AYR+8
        ld b,3
        ld e,0
.nl:    rrc c
        jr nc,.nn
        ld a,(hl)
        and $1F
        cp 9
        jr c,.nn
        inc e
.nn:    inc hl
        djnz .nl
        ; --- play
        ld a,(vz_spk_off)
        ld d,a
        ld iy,(vz_miters)
        ld a,e
        or a
        ld e,$21
        jr z,.nod
        ld hl,(vz_mrnd)
        ld b,MDRUMN
.nz:    ld a,(hl)
        inc hl
        and e
        xor d
        ld (LATCH),a
        ld c,7
.nzd:   dec c
        jr nz,.nzd
        djnz .nz
        res 5,h                 ; ROM bytes $0000-$1FFF as noise source
        res 6,h
        res 7,h
        ld (vz_mrnd),hl
        push de
        ld iy,(vz_miters)
        ld de,-MDRUMIT
        add iy,de
        pop de
.nod:   ld a,iyl
        or a
        jr z,.c0
        inc iyh
.c0:    ld a,d
        exx
        ld d,a
        ld e,$21
        ld hl,(vz_h2)
        ld bc,(vz_a2)
        exx
        ld hl,(vz_h1)
        ld bc,(vz_a1)
        ld ix,(vz_h3)
        ld (vz_msp),sp
        ld sp,(vz_a3)
.l:     add hl,bc               ; voice 1                   11
        ld a,h                  ;                            4
.t1:    cp 0                    ; pulse width                7
        sbc a,a                 ;                            4
        and e                   ;                            4
        xor d                   ;                            4
        ld (LATCH),a            ;                           13
        nop                     ;                            4
        nop                     ;                            4
        exx                     ; voice 2                    4
        add hl,bc               ;                           11
        ld a,h                  ;                            4
.t2:    cp 0                    ;                            7
        sbc a,a                 ;                            4
        and e                   ;                            4
        xor d                   ;                            4
        ld (LATCH),a            ;                           13
        add ix,sp               ; voice 3                   15
        ld a,ixh                ;                            8
.t3:    cp 0                    ;                            7
        sbc a,a                 ;                            4
        and e                   ;                            4
        xor d                   ;                            4
        exx                     ;                            4
        ld (LATCH),a            ;                           13
        dec iyl                 ;                            8
        jp nz,.l                ;                           10 = 183
        dec iyh
        jp nz,.l
        ld sp,(vz_msp)
        ld (vz_h1),hl
        ld (vz_h3),ix
        exx
        ld (vz_h2),hl
        exx
        ld a,d
        ld (LATCH),a
        ret

; HL -> period (2 bytes), DE -> volume, A = channel. Returns HL = phase
; increment, A = pulse width threshold (0 = silent).
.voice: ld b,a
        ld a,(de)
        and $1F
        bit 4,a
        jr z,.v0
        ld a,13                 ; envelope: treat as loud
.v0:    push hl
        ld hl,VOLTAB
        add a,l
        ld l,a
        adc a,h
        sub l
        ld h,a
        ld c,(hl)               ; threshold
        pop hl
        ld a,(vz_mmix)          ; tone enabled? (active low)
        inc b
.vb:    rrca
        djnz .vb
        jr c,.off
        ld a,c
        or a
        jr z,.off
        ld e,(hl)
        inc hl
        ld a,(hl)
        and $0F
        ld d,a
        push bc
        call vz_pinc
        pop bc
        ld a,h
        or l
        ld a,c
        ret nz
.off:   ld hl,0
        xor a
        ret

; DE = AY period -> HL = K/DE (K = 65536 * 1773400/16 / (3546895/183)),
; 0 if the note is too high to play.
vz_pinc:
        ld a,d
        or a
        jr nz,.ok
        ld a,e
        cp 6
        jr nc,.ok
        ld hl,0
        ret
.ok:    ld hl,0                 ; remainder
        ld a,KDIV>>16
        ld bc,KDIV&$FFFF
        push ix
        ld ixl,24
.l:     sla c
        rl b
        rla
        adc hl,hl
        or a
        sbc hl,de
        jr nc,.s
        add hl,de
        jr .n
.s:     inc c
.n:     dec ixl
        jr nz,.l
        pop ix
        ld h,b
        ld l,c
        ret
KDIV        equ 374830

; AY volume 0-15 -> pulse threshold
VOLTAB: db 0,0,0,0,0,20,26,32,44,54,66,80,96,112,124,128

; ---- silence the speaker and the driver ---------------------------------
vz_mstop:
        push ix
        push iy
        call AY_STOP
        pop iy
        pop ix
        ld a,(vz_spk_off)
        ld (LATCH),a
        ret
