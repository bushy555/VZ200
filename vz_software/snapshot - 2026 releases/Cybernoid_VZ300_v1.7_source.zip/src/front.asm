; ---------------------------------------------------------------------------
; Front end (mode(0), SG4 semigraphics + text): title / hall of fame attract
; loop, game over, name entry. Music = the original 128K tunes (music.asm).
; ---------------------------------------------------------------------------
SCR_TITLE   equ 0
SCR_HOF     equ 1
SCR_ENTRY   equ 2
SCR_OVER    equ 3
SCR_LEVEL   equ 4

SG          equ $80             ; SG4 cell: $80 | colour<<4 | quadrants
C_BUF       equ 4
C_CYN       equ 5
C_MAG       equ 6
C_ORG       equ 7

; ---- clear to black mode(0) ----------------------------------------------
vz_cls0:
        call vz_settext
        ld hl,VRAM
        ld de,VRAM+1
        ld bc,511
        ld (hl),SG
        ldir
        ret

; ---- show compressed screen A (mode 0), reset the animation state --------
vz_show0:
        push af
        push af
        call vz_settext
        pop af
        add a,a
        ld l,a
        ld h,0
        ld de,SCRTAB
        add hl,de
        ld a,(hl)
        inc hl
        ld h,(hl)
        ld l,a
        ld de,VRAM
        call dzx0_standard
        xor a
        ld (vz_fcnt),a
        ld (vz_glint),a
        ld (vz_msg),a
        ld hl,vz_nohook
        ld (vz_mhook),hl
        ld hl,MITERS
        ld (vz_miters),hl
        xor a
        ld (vz_wrow),a
        pop af                  ; screen number -> bubble/glint tables
        push af
        ld l,a
        add a,a
        add a,a
        add a,a
        add a,l
        add a,l                 ; *10
        ld l,a
        ld h,0
        ld de,BUBTAB
        add hl,de
        ld de,vz_bubc
        ld bc,10
        ldir                    ; bubc, bubo, bubp, glm, bubn, glrow
        pop af
        ret

; ===========================================================================
; animation pieces (called from the per-step hooks)
; ===========================================================================
; logo glint: a bright column sweeps across logo rows (vz_glrow .. +3)
vz_anglint:
        ld a,(vz_glint)
        inc a
        cp 96
        jr c,.n
        xor a
.n:     ld (vz_glint),a
        cp 1
        ret c
        cp 33
        ret nc
        ; restore column A-2, light column A-1 (cells 0..31)
        sub 2
        jr c,.lt
        call .col
        ld b,4
        ld de,LOGOCOL
.r:     rrc c
        jr nc,.rn
        ld a,(hl)
        cp SG+1
        jr c,.rn
        and $8F
        push hl
        ld l,a
        ld a,(de)
        or l
        pop hl
        ld (hl),a
.rn:    inc de
        ld a,l
        add a,32
        ld l,a
        jr nc,.r2
        inc h
.r2:    djnz .r
.lt:    ld a,(vz_glint)
        dec a
        cp 32
        ret nc
        call .col
        ld b,4
.g:     rrc c
        jr nc,.gn
        ld a,(hl)
        cp SG+1
        jr c,.gn
        and $8F
        or C_BUF<<4
        ld (hl),a
.gn:    ld a,l
        add a,32
        ld l,a
        jr nc,.g2
        inc h
.g2:    djnz .g
        ret
.col:   ld e,a                  ; HL = VRAM + glrow*32 + A, C = letter mask
        ld hl,(vz_glm)
        ld d,0
        add hl,de
        ld c,(hl)
        ld a,(vz_glrow)
        ld l,a
        ld h,0
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        ld d,VRAM/256
        add hl,de
        ret
LOGOCOL: db C_BUF<<4, C_CYN<<4, C_CYN<<4, 2<<4



; blink text row A (toggles inverse every 32 steps), cols 1..30
vz_anblink:
        ld b,a
        ld a,(vz_fcnt)
        and 31
        ret nz
        ld l,b
        ld h,0
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        ld de,VRAM+1
        add hl,de
        ld b,30
.l:     ld a,(hl)
        bit 7,a
        jr nz,.n
        xor $40
        ld (hl),a
.n:     inc hl
        djnz .l
        ret

; print 0-terminated string HL centred on text row B (cols 1..30 cleared)
vz_ctext0:
        push hl
        ld l,b
        ld h,0
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        ld de,VRAM+1
        add hl,de
        ld b,30
.c:     ld (hl),SG
        inc hl
        djnz .c
        ld de,-31
        add hl,de               ; HL = row start
        pop de
        push hl
        ld h,d
        ld l,e
        ld c,0
.len:   ld a,(hl)
        or a
        jr z,.le
        inc hl
        inc c
        jr .len
.le:    ld a,32
        sub c
        srl a
        pop hl
        add a,l
        ld l,a
        jr nc,vz_puts0
        inc h
; DE = string -> HL (0-terminated), mode(0) codes
vz_puts0:
.p:     ld a,(de)
        or a
        ret z
        cp 64
        jr c,.lo
        sub 64
.lo:    ld (hl),a
        inc de
        inc hl
        jr .p

; ===========================================================================
; hooks
; ===========================================================================
vz_thook:                       ; title
        ld hl,vz_fcnt
        inc (hl)
        call vz_anwarp
        call vz_anglint
        ld a,11
        call vz_anblink
        ; info line (row 13) every 128 steps
        ld a,(vz_fcnt)
        or a
        ret nz
        ld a,(vz_msg)
        inc a
        cp TMSGN
        jr c,.m
        xor a
.m:     ld (vz_msg),a
vz_showmsg:
        ld a,(vz_msg)
        add a,a
        ld l,a
        ld h,0
        ld de,TMSGS
        add hl,de
        ld a,(hl)
        inc hl
        ld h,(hl)
        ld l,a
        ; options lines show the live setting
        ld de,MSG_MUS
        or a
        sbc hl,de
        add hl,de
        jr nz,.j
        ld a,(vz_musicon)
        call .onoff
        jr .p
.j:     ld de,MSG_JOY
        or a
        sbc hl,de
        add hl,de
        jr nz,.s
        ld a,(vz_joyok)
        call .onoff
        jr .p
.s:     ld de,MSG_SND
        or a
        sbc hl,de
        add hl,de
        jr nz,.p
        ld a,(S_SOUND)
        call .onoff
.p:     ld b,13
        jp vz_ctext0
.onoff: push hl                 ; A = flag: patch "ON "/"OFF" at the end
        ld c,a
.e:     ld a,(hl)
        or a
        jr z,.ee
        inc hl
        jr .e
.ee:    dec hl
        dec hl
        dec hl
        ex de,hl
        ld hl,S_ON
        ld a,c
        or a
        jr nz,.cp
        ld hl,S_OFF
.cp:    ld bc,3
        ldir
        pop hl
        ret

vz_bubhook:                     ; biomass screens: bubbles + glint
        ld hl,vz_fcnt
        inc (hl)
        call vz_anwarp
        jp vz_anglint
vz_hofhook  equ vz_bubhook
vz_ohook    equ vz_bubhook

vz_ehook:                       ; name entry: cursor blink
        call vz_bubhook
        ld hl,(vz_curs)
        ld a,(vz_fcnt)
        and 16
        ld a,$60                ; solid block / dash
        jr z,.c
        ld a,'-'
.c:     ld (hl),a
        ret

; ===========================================================================
; title / hall of fame attract loop (replaces the Spectrum menu at 81A6)
; ===========================================================================
vz_title:
        ld a,(vz_tplay)
        or a
        jr nz,.t
        ld e,T_TITLE
        call vz_mstart
        ld a,1
        ld (vz_tplay),a
.t:     ld a,SCR_TITLE
        call vz_show0
        call vz_showmsg
        ld hl,vz_thook
        ld (vz_mhook),hl
        ld hl,600               ; 12 s
        call vz_run
        jr nz,.key
        ; hall of fame
        call vz_showhof
        ld hl,450
        call vz_run
        jr nz,.key
        jr .t
.key:   call vz_getkey
        cp 'M'
        jr z,.mus
        cp 'J'
        jr z,.joy
        cp 'S'
        jr z,.snd
        cp ' '
        jr z,.go
        cp 13
        jr z,.go
        cp '1'
        jr z,.go
        call vz_release
        jr .t
.mus:   ld a,(vz_musicon)
        xor 1
        ld (vz_musicon),a
        call z,vz_mstop
        ld a,MSGI_MUS
        jr .opt
.joy:   ld a,(vz_joyok)
        xor 1
        ld (vz_joyok),a
        ld a,MSGI_JOY
        jr .opt
.snd:   ld a,(S_SOUND)
        xor 1
        ld (S_SOUND),a
        ld a,MSGI_SND
.opt:   push af
        call vz_release
        ld a,SCR_TITLE
        call vz_show0
        pop af
        ld (vz_msg),a
        call vz_showmsg
        ld hl,vz_thook
        ld (vz_mhook),hl
        ld a,1                  ; hold the option line for a while
        ld (vz_fcnt),a
        ld hl,600
        call vz_run
        jp nz,.key
        jp .t
.go:    call vz_release
        call vz_mstop
        xor a
        ld (vz_tplay),a
        ei
        ret

; run music/hook for HL steps or until a key; NZ = key pressed
vz_run:
        ld (vz_steps),hl
.l:     ld a,(vz_musicon)
        or a
        jr nz,.m
        ei
        halt
        call vz_hook
        jr .c
.m:     call vz_mstep
.c:     call vz_anykey
        ret nz
        ld hl,(vz_steps)
        dec hl
        ld (vz_steps),hl
        ld a,h
        or l
        jr nz,.l
        ret
; wait for all keys up, keeping the music going
vz_release:
.l:     ld a,(vz_musicon)
        or a
        jr nz,.m
        ei
        halt
        call vz_hook
        jr .c
.m:     call vz_mstep
.c:     call vz_anykey
        jr nz,.l
        ret

; ---- hall of fame screen ---------------------------------------------------
vz_showhof:
        ld a,SCR_HOF
        call vz_show0
        ld hl,vz_hofhook
        ld (vz_mhook),hl
        ld ix,S_HISC
        ld hl,VRAM+4*32+6
        ld c,'1'
        ld b,10
.e:     push bc
        push hl
        ld a,b
        cp 1
        jr nz,.r1
        ld (hl),'1'-0           ; "10"
        inc hl
        ld (hl),'0'
        jr .r2
.r1:    inc hl
        ld (hl),c
.r2:    pop hl
        push hl
        ld de,3
        add hl,de
        ld b,10
.n:     ld a,(ix+0)
        call .ch
        inc ix
        inc hl
        djnz .n
        inc hl
        inc hl
        ld b,6
.s:     ld a,(ix+0)
        call .ch
        inc ix
        inc hl
        djnz .s
        pop hl
        ld de,32
        add hl,de
        pop bc
        inc c
        djnz .e
        ret
.ch:    cp 64
        jr c,.c1
        sub 64
.c1:    ld (hl),a
        ret

; ===========================================================================
; game over (replaces 8F95): GAME OVER screen, hall of fame entry, restart
; ===========================================================================
vz_gameover:
        di
        ld e,T_OVER
        call vz_mstart
        ld a,SCR_OVER
        call vz_show0
        ld hl,MSG_SCORE
        ld b,12
        call vz_ctext0
        ; score digits after "SCORE "
        ld hl,VRAM+12*32+(32-12)/2+6
        ld de,S_SCORE
        ld b,6
.sc:    ld a,(de)
        ld (hl),a
        inc de
        inc hl
        djnz .sc
        ld hl,vz_ohook
        ld (vz_mhook),hl
        call vz_release
        ld hl,300
        call vz_run
        call vz_release
        ; --- hall of fame?
        call vz_hofpos          ; IX = slot or Z if not good enough
        jr z,.nohof
        push ix
        ld e,T_ENTRY
        call vz_mstart
        call vz_entry           ; name -> vz_name (10 chars)
        pop ix
        call vz_hofins
        ld e,T_TITLE
        call vz_mstart
        ld a,1
        ld (vz_tplay),a
        call vz_showhof
        ld hl,500
        call vz_run
        call vz_release
.nohof: call vz_mstop
        xor a
        ld (vz_tplay),a
        jp S_START

; IX = first entry the score beats (NZ), Z if none
vz_hofpos:
        ld ix,S_HISC
.e:     ld a,(ix+0)
        cp $FF
        ret z                   ; end of table: not good enough
        push ix
        ld de,10
        add ix,de
        ld hl,S_SCORE
        ld b,6
.d:     ld a,(ix+0)
        cp (hl)
        jr nz,.df
        inc ix
        inc hl
        djnz .d
        jr .nx                  ; equal: the old entry stays ahead
.df:    jr nc,.nx               ; entry digit > score digit
        pop ix                  ; score beats this entry
        or 1
        ret
.nx:    pop ix
        ld de,16
        add ix,de
        jr .e

; insert vz_name + score at IX, shifting the rest down
vz_hofins:
        push ix
        pop hl
        ld de,S_HISC+9*16
        ex de,hl
        or a
        sbc hl,de               ; bytes to move = last slot - IX
        jr c,.wr
        jr z,.wr
        ld b,h
        ld c,l
        ld hl,S_HISC+9*16-1
        ld de,S_HISC+10*16-1
        lddr
.wr:    push ix
        pop de
        ld hl,vz_name
        ld bc,10
        ldir
        ld hl,S_SCORE
        ld bc,6
        ldir
        ret

; ---- name entry ------------------------------------------------------------
vz_entry:
        ld a,SCR_ENTRY
        call vz_show0
        ld hl,vz_name
        ld b,10
.cl:    ld (hl),' '
        inc hl
        djnz .cl
        ld hl,VRAM+10*32+12
        ld b,8
.du:    ld (hl),'-'
        inc hl
        djnz .du
        xor a
        ld (vz_nlen),a
        ld hl,vz_ehook
        ld (vz_mhook),hl
        call vz_release
.cur:   ld a,(vz_nlen)
        ld hl,VRAM+10*32+12
        add a,l
        ld l,a
        ld (vz_curs),hl
.k:     ld hl,0
        call vz_run
        call vz_getkey
        push af
        call vz_release
        pop af
        cp 13
        jr z,.done
        cp 1                    ; CTRL = delete
        jr z,.del
        cp ' '
        jr c,.k
        ld c,a
        ld a,(vz_nlen)
        cp 8
        jr nc,.k
        ld e,a
        ld d,0
        ld hl,vz_name
        add hl,de
        ld (hl),c
        ld hl,(vz_curs)
        ld a,c
        cp 64
        jr c,.lo
        sub 64
.lo:    ld (hl),a
        ld hl,vz_nlen
        inc (hl)
        jr .cur
.del:   ld a,(vz_nlen)
        or a
        jr z,.k
        ld hl,(vz_curs)
        ld (hl),'-'
        dec a
        ld (vz_nlen),a
        ld e,a
        ld d,0
        ld hl,vz_name
        add hl,de
        ld (hl),' '
        jr .cur
.done:  ld hl,(vz_curs)
        ld a,(vz_nlen)
        cp 8
        ret nc
        ld (hl),'-'
        ret

; ---- key -> ASCII (first key found); joystick fire = 'F' + $80 handled as
; fire: returns ' ' for fire. CTRL = 1, RETURN = 13, 0 = nothing/SHIFT.
vz_getkey:
        call vz_read_controls
        and $10
        ld a,' '
        ret nz
        ld hl,$68FE
        ld de,KEYTAB
.r:     ld c,(hl)
        ld b,6
.b:     rr c
        jr c,.nx
        ld a,(de)
        or a
        ret nz                  ; (SHIFT / unused positions are 0)
.nx:    inc de
        djnz .b
        rlc l
        jr c,.r
        xor a
        ret
KEYTAB: db "TW",0,"EQR"
        db "GS",1,"DAF"
        db "BX",0,"CZV"
        db "52",0,"314"
        db "N.",0,", M"
        db "69-807"
        db "YO",13,"IPU"
        db "HL:K;J"



; ===========================================================================
; level end (76A3 / 76BE): the depot report on a mode(0) screen
; ===========================================================================
vz_lvlwin:
        push hl
        ld hl,MSG_W1
        ld (vz_m1),hl
        ld hl,MSG_W2
        ld (vz_m2),hl
        ld hl,MSG_W3
        ld (vz_m3),hl
        ld e,T_ENTRY
        jr vz_lvlend
vz_lvlfail:
        push hl
        ld hl,MSG_F1
        ld (vz_m1),hl
        ld hl,MSG_F2
        ld (vz_m2),hl
        ld hl,MSG_F3
        ld (vz_m3),hl
        ld e,T_OVER
vz_lvlend:
        push de
        push bc
        push ix
        push iy
        call vz_mstart
        ld a,SCR_LEVEL
        call vz_show0
        ld hl,(vz_m1)
        ld b,6
        call vz_ctext0
        ld hl,(vz_m2)
        ld b,7
        call vz_ctext0
        ld hl,(vz_m3)
        ld b,8
        call vz_ctext0
        ld hl,(vz_m1)
        ld de,MSG_W1
        or a
        sbc hl,de
        jr nz,.nb
        ld hl,$771A+RD          ; bonus digits (the game's own message text)
        ld de,VRAM+8*32+1+10
        ld bc,6
        ldir
.nb:    ld hl,MSG_SCORE
        ld b,13
        call vz_ctext0
        ld hl,VRAM+13*32+(32-12)/2+6
        ld de,S_SCORE
        ld b,6
.sc:    ld a,(de)
        ld (hl),a
        inc de
        inc hl
        djnz .sc
        ld hl,MSG_FIRE
        ld b,14
        call vz_ctext0
        ld hl,vz_lhook
        ld (vz_mhook),hl
        call vz_release
        ld hl,0
        call vz_run
        call vz_release
        call vz_mstop
        call vz_setgfx          ; back to the game screen mode
        ld hl,VRAM
        ld de,VRAM+1
        ld bc,2047
        ld (hl),BGBYTE
        ldir
        pop iy
        pop ix
        pop bc
        pop de
        pop hl
        ei
        ret
vz_lhook:
        call vz_bubhook
        ld a,14
        jp vz_anblink
ZS_LEVEL: INCBIN "../build/scr_level.zx0"
        INCLUDE "../build/screens.asm"
        INCLUDE "fws1.asm"
        INCLUDE "fws3.asm"
        INCLUDE "fws4.asm"
        INCLUDE "warp.asm"
