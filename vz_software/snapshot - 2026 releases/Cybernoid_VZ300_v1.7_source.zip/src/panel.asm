; ---------------------------------------------------------------------------
; Status panel (VZ lines 0-3) and text output
; Layout (bytes): 0-1 ship icon, 2-3 lives, 5-10 score, 12-17 cargo,
;                 19-20 weapon icon, 21-22 ammo, 24 hourglass, 25-31 time bar
; Digits are 3x4 glyphs, one VZ byte (4 pixels) per digit.
; ---------------------------------------------------------------------------
PANELBYTE   equ $FF             ; red panel
P_LIVES     equ 2
P_SCORE     equ 5
P_CARGO     equ 12
P_WICON     equ 19
P_AMMO      equ 21
P_HGLASS    equ 24
P_BAR       equ 25
PC_LIVES    equ 1               ; yellow
PC_SCORE    equ 1
PC_CARGO    equ 0               ; green
PC_AMMO     equ 1               ; yellow

; ---- 6C4A replacement: print char A at row D, col E, attribute C -----------
vz_putc:
        push af
        push bc
        push de
        push hl
        push ix
        push af
        ; Spectrum side effects: attribute = C, block map cell = 0
        ld l,d
        ld h,0
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        ld a,l
        or e
        ld l,a
        ld a,h
        add a,$58
        ld h,a
        ld (hl),c
        add a,$07
        ld h,a
        ld (hl),0
        pop af
        ld b,a                  ; char
        ld a,d
        cp 4
        jr nc,.txt
        ; panel: only the main font draws fields
        ld hl,($6C55+RD)
        ld a,h
        cp $C2
        jr nz,.x
        ld a,b
        call vz_panelchar
        jr .x
.txt:   ld a,(vz_mode)
        or a
        ld a,b
        ; (no in-game text on the playfield: the level reports are mode(0) screens)
.x:     pop ix
        pop hl
        pop de
        pop bc
        pop af
        ret

; A = char at panel (D,E)
vz_panelchar:
        ld c,a
        ld a,d
        cp 1
        jr z,.r1
        cp 2
        ret nz
        ; row 2
        ld a,e
        sub 3
        cp 2
        jr nc,.n1
        add a,P_LIVES           ; lives "04"
        ld b,PC_LIVES
        jr vz_pdigit
.n1:    ld a,e
        sub 8
        cp 6
        jr nc,.n2
        add a,P_CARGO
        ld b,PC_CARGO
        jr vz_pdigit
.n2:    ld a,e
        sub 17
        cp 2
        ret nc
        add a,P_AMMO
        ld b,PC_AMMO
        jr vz_pdigit
.r1:    ld a,e
        sub 8
        cp 6
        jr nc,.m1
        add a,P_SCORE
        ld b,PC_SCORE
        jr vz_pdigit
.m1:    ld a,e
        cp 17
        ret nz
        jp vz_wicon             ; weapon name printed -> icon

; draw digit char C at panel byte A, colour B
vz_pdigit:
        ld e,a
        ld d,0
        ld hl,VRAM
        add hl,de
        ld a,c
        sub '0'
        cp 10
        jr c,.d
        ld a,10                 ; blank
.d:     add a,a                 ; glyph = DIGITS + digit*2 (4 nibbles)
        ld e,a
        ld d,0
        push hl
        ld hl,DIGITS
        add hl,de
        ex de,hl                ; DE = glyph (2 bytes, 4 nibbles)
        pop hl
        ld a,b
        call vz_nibtab          ; IX = nibble->byte table for colour
        ld a,(de)
        call .row
        ld a,(de)
        rlca
        rlca
        rlca
        rlca
        call .row
        inc de
        ld a,(de)
        call .row
        ld a,(de)
        rlca
        rlca
        rlca
        rlca
.row:   rrca
        rrca
        rrca
        rrca
        and $0F
        push de
        ld e,a
        ld d,0
        push ix
        add ix,de
        ld a,(ix+0)
        pop ix
        pop de
        ld (hl),a
        ld a,l
        add a,32
        ld l,a
        ret

; A = colour code -> IX = NIBTAB + A*16
vz_nibtab:
        add a,a
        add a,a
        add a,a
        add a,a
        ld ix,NIBTAB
        push de
        ld e,a
        ld d,0
        add ix,de
        pop de
        ret

; ---- weapon icon (8x4) for weapon S_WEAPON -------------------------------
vz_wicon:
        ld a,(S_WEAPON)
        cp 5
        ret nc
        add a,a
        add a,a
        add a,a                 ; 8 bytes per icon (2 x 4 lines)
        ld e,a
        ld d,0
        ld hl,WICONS
        add hl,de
        ld de,VRAM+P_WICON
        ld b,4
.l:     ld a,(hl)
        ld (de),a
        inc hl
        inc e
        ld a,(hl)
        ld (de),a
        inc hl
        ld a,e
        add a,31
        ld e,a
        djnz .l
        ret

; ---- panel background + static icons (replaces the panel script print) ----
vz_panelbg:
        ld hl,VRAM
        ld de,VRAM+1
        ld bc,4*32-1
        ld (hl),PANELBYTE
        ldir
        ret
vz_panelart:
        call vz_panelbg
        ld hl,PICON_SHIP
        ld de,VRAM+0
        call .i8
        ld hl,PICON_HG
        ld de,VRAM+P_HGLASS
        ld b,4
.h:     ld a,(hl)
        ld (de),a
        inc hl
        ld a,e
        add a,32
        ld e,a
        djnz .h
        ret
.i8:    ld b,4
.l:     ld a,(hl)
        ld (de),a
        inc hl
        inc e
        ld a,(hl)
        ld (de),a
        inc hl
        ld a,e
        add a,31
        ld e,a
        djnz .l
        ret

; ---- 79A9 replacement: time bar, 17 steps used in S_TIMER ----------------
; BARFULL = the full bar (7 bytes x 4 lines); it erodes from the right.
vz_timer:
        push af
        push bc
        push de
        push hl
        ld a,(S_TIMER)
        cp 18
        jr c,.ok
        ld a,17
.ok:    ld e,a
        ld d,0
        ld hl,BARLEN
        add hl,de
        ld c,(hl)               ; pixels remaining (0..28)
        ld hl,VRAM+P_BAR
        ld de,BARFULL
        ld b,4
.ln:    push bc
        push hl
        ld b,7
.cb:    ld a,c
        cp 4
        jr c,.part
        sub 4
        ld c,a
        ld a,(de)
        jr .put
.part:  or a
        ld a,PANELBYTE
        jr z,.put
        push hl                 ; partial byte: C pixels of bar, rest background
        ld hl,PMASK
        ld a,l
        add a,c
        ld l,a
        jr nc,.pm
        inc h
.pm:    ld a,(hl)
        pop hl
        push bc
        ld b,a
        ld a,(de)
        and b
        ld c,a
        ld a,b
        cpl
        and PANELBYTE
        or c
        pop bc
        ld c,0
.put:   ld (hl),a
        inc hl
        inc de
        djnz .cb
        pop hl
        ld bc,32
        add hl,bc
        pop bc
        djnz .ln
        pop hl
        pop de
        pop bc
        pop af
        ret

