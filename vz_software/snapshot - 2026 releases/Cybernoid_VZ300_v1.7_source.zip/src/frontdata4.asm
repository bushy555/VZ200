ZS_ENTRY: INCBIN "../build/scr_entry.zx0"
