; ---- title: living flesh. Every cell of the background has a depth band
; (BANDS, pre-offset into LUTP); each redraw LUTP is FLESHLUT rotated one
; step further, so rings of red, magenta and blue swell out of the dark,
; roll across the screen and sink back. Neighbouring steps differ by one
; quadrant or a hue, so redrawing 4 rows per music step shows no seams.
; Written through the per-cell masks in WSP* (letters, their outlines, the
; text and the border are never touched). The music plays WARPIT fewer
; samples per step to keep the tempo exact.
vz_anwarp:
        ld hl,MITERS
        ld de,(vz_bubo)         ; this screen's cost in samples
        or a
        sbc hl,de
        ld (vz_miters),hl
        ld a,(vz_wrow)
        and 15
        jr nz,.go
        ld hl,vz_wt1            ; new pass: rotate the colour table
        inc (hl)
        ld c,(hl)
        ld de,LUTP
        ld b,16
.rot:   ld a,c
        and 15
        ld hl,FLESHLUT
        add a,l
        ld l,a
        adc a,h
        sub l
        ld h,a
        ld a,(hl)
        ld (de),a
        inc de
        inc c
        djnz .rot
.go:    ld a,4
        ld (vz_wcnt),a
.row:   ld a,(vz_wrow)
        add a,a
        ld l,a
        ld h,0
        ld de,(vz_bubc)         ; this screen's row/span table
        add hl,de
        ld e,(hl)
        inc hl
        ld d,(hl)
        ex de,hl                ; HL = this row's span list
        ld a,(hl)
        inc hl
        or a
        jp z,.rend
        ld b,a
.sp:    push bc
        ld a,(vz_wrow)          ; offset = row*32 + column
        rrca
        rrca
        rrca
        ld e,a
        and $E0
        add a,(hl)
        ld c,a                  ; low byte
        ld a,e
        and 1
        ld b,a                  ; high byte (rows 8-15)
        inc hl
        ld a,(hl)               ; cells
        ld (vz_wn),a
        inc hl
        ld a,(hl)               ; mask
        inc hl
        push hl
        ld hl,BANDS
        add hl,bc               ; HL = band map
        push af
        ld a,b
        add a,VRAM/256
        ld b,a                  ; BC = screen cell
        pop af
        ld d,LUTP/256
        cp $FF
        jr nz,.msk
        ld a,(vz_wn)            ; full cells: unrolled
        neg
        add a,30
        ld e,a
        add a,a
        add a,a
        add a,e                 ; (30-n)*5 bytes into the unrolled block
        ld e,a
        push hl
        ld hl,.un
        ld a,l
        add a,e
        ld l,a
        jr nc,.u1
        inc h
.u1:    ex (sp),hl
        ret                     ; jump into the block
.msk:   ld (.am+1),a
        ld a,(vz_wn)
        ld ixl,a
.ml:    ld e,(hl)
        ld a,(de)
.am:    and 0
        ld (bc),a
        inc hl
        inc c
        dec ixl
        jr nz,.ml
        jp .sd
.un:    REPT 30
        ld e,(hl)
        ld a,(de)
        ld (bc),a
        inc hl
        inc c
        ENDR
.sd:    pop hl
        pop bc
        dec b
        jp nz,.sp
.rend:  ld a,(vz_wrow)
        inc a
        and 15
        ld (vz_wrow),a
        ld hl,vz_wcnt
        dec (hl)
        jp nz,.row
        ret
