; ===========================================================================
;  CYBERNOID - ZX Spectrum (Hewson 1988, Raffaele Cecco) -> VZ300 conversion
;  Target: VZ300 + BennVenn SD loader with 128K RAM expansion
;  Original Spectrum engine retained; hardware layers replaced.
; ===========================================================================
        DEVICE NOSLOT64K
        INCLUDE "../build/reloc.asm"
        INCLUDE "equ.asm"
        INCLUDE "../build/gfx.asm"

; ---- Spectrum image (relocated by prep.py) --------------------------------
        ORG $5B00
        INCBIN "../build/spec.bin",$5B00,RELO_LO-$5B00
        ORG $7814
        INCBIN "../build/spec.bin",$7814,VZS24-$7814
        ORG RELO_NEW
        INCBIN "../build/spec.bin",RELO_NEW,RELO_END-RELO_NEW
        ORG $E9B9
        INCBIN "../build/spec.bin",$E9B9,$EC61-$E9B9
        ORG $EF38                   ; 128K AY music driver + tunes
        INCBIN "../build/spec.bin",$EF38,$FB86-$EF38
        ORG $FDFD
        INCBIN "../build/spec.bin",$FDFD,$10000-$FDFD
; ---- VZ graphics replace the Spectrum sprite/block bitmaps ---------------
        ORG VZS24
        INCBIN "../build/vzgfx.bin"
        ASSERT $ == GFX_END
        ASSERT $ <= RELO_NEW

; ===========================================================================
; patches to the Spectrum code
; ===========================================================================
        MACRO PATCH addr, b0
        ASSERT {b addr} == b0
        ORG addr
        ENDM

        PATCH $651F,$D3             ; border
        nop
        nop
        PATCH $6521,$3A             ; force the 48K paths (beeper, no AY)
        ld a,$FF
        nop
        PATCH $654E,$CD             ; title / menu
        call vz_title
        PATCH $70B9+RD,$21          ; interrupt vector -> VZ wrapper
        ld hl,vz_isr
        PATCH $65EB,$3E             ; pause
        jp vz_pause
        PATCH $660B,$3E             ; 1-5 restart -> CTRL+Q
        jp vz_quitchk
        PATCH $688F+RD,$21          ; game controls
        jp vz_input
        PATCH $7C24,$3A             ; special weapon: ARM / M instead of fire held
        call vz_spkey
        PATCH $7B4A,$3E             ; weapon keys 1-5
        call vz_wkeys
        nop
        PATCH $8631,$D9             ; beeper effects output loop
        jp vz_sfxloop
        PATCH $66AA,$0E             ; cls
        jp vz_cls
        PATCH $66C0,$0E             ; clear play area
        jp vz_clsplay
        PATCH $676A,$C5             ; delay (LDIR onto ROM)
        jp vz_delay
        PATCH $6C4A+RD,$F5          ; print char
        jp vz_putc
        PATCH $7802+RD,$CD          ; panel frame script -> VZ panel art
        call vz_panelart
        PATCH $79A9,$21             ; time bar
        jp vz_timer
        PATCH $A548,$FE             ; block
        jp vz_block
        PATCH $A539,$C5             ; block handle
        jp vz_blkhandle
        PATCH $A1FD,$F5             ; 24-wide sprites
        jp vz_spr24
        PATCH $A4DB,$F5             ; block sprites
        jp vz_blkspr
        PATCH $80BD,$F5             ; small sprites
        jp vz_small
        PATCH $7A2D,$CD             ; laser dot (keeps the collision test)
        call vz_dot
        nop
        nop
        nop
        PATCH $A446,$F5             ; attribute painters (colour is in the VZ art)
        ret
        PATCH $A47B,$F5
        ret
        PATCH $A4AD,$F5
        ret
        PATCH $8F95,$1E             ; game over
        jp vz_gameover
        PATCH $76A3+RD,$CD          ; level end messages -> mode(0) report
        call vz_lvlwin
        PATCH $76B7+RD,$CA          ; (the report already waited for fire)
        nop
        nop
        nop
        PATCH $76BE+RD,$CD
        call vz_lvlfail
        PATCH $76C8+RD,$CA
        nop
        nop
        nop
        PATCH $6531,$3E             ; keep the AY driver entries (front end music)
        jp $653C
        PATCH $EFB0,$01             ; AY register output -> shadow only
        ret

; ===========================================================================
; VZ code area A ($4000-$57FF, SRAM bank 1)
; ===========================================================================
        ORG $4000
YADL:   ds 256
YADH:   ds 256
YCNT:   ds 256
        INCLUDE "core.asm"
        INCLUDE "render.asm"
        INCLUDE "panel.asm"
        INCLUDE "sound.asm"
        INCLUDE "music.asm"
        INCLUDE "front.asm"
        INCLUDE "../build/gendata.asm"
; ---- variables --------------------------------------------------------------
vz_tick:      db 0
vz_latch:     db 0
vz_spk_on:    db 0
vz_spk_off:   db 0
vz_mode:      db 0
vz_css0:      db L_CSS
vz_joyok:     db 1
vz_newh:      dw 0
vz_xw:        db 0
vz_xh:        db 0
vz_xc:        db 0
vz_tmp:       db 0
vz_musicon:   db 1
vz_mbusy:     db 0
vz_msteps:    db 0
vz_steps:     dw 0
vz_mhook:     dw vz_nohook
vz_mmix:      db 0
vz_mrnd:      dw 0
vz_msp:       dw 0
vz_a1:        dw 0
vz_a2:        dw 0
vz_a3:        dw 0
vz_h1:        dw 0
vz_h2:        dw 0
vz_h3:        dw 0
vz_tplay:     db 0
vz_fcnt:      db 0
vz_glint:     db 0
vz_msg:       db 0
vz_curs:      dw 0
vz_nlen:      db 0
vz_name:      ds 10
vz_bubc:      dw 0
vz_bubo:      dw 0
vz_bubp:      dw 0
vz_glm:       dw 0
vz_bubn:      db 0
vz_glrow:     db 1
vz_miters:    dw MITERS
vz_wrow:      db 0
vz_wt1:       db 0
vz_wt2:       db 0
vz_wdc:       db 0
vz_wdrift:    db 0
vz_wn:        db 0
vz_wcnt:      db 0
vz_wxo:       db 0
vz_wsp:       dw 0
vz_wsrc:      dw 0
vz_wdst:      dw 0
vz_m1:        dw 0
vz_m2:        dw 0
vz_m3:        dw 0
codeA_end:
        ASSERT $ <= $5800

; ===========================================================================
; VZ code area B ($E556-$E9B8: was Spectrum block bitmaps)
; ===========================================================================
        ORG RELO_END
        INCLUDE "frontdata.asm"
        INCLUDE "fws0.asm"
codeB_end:
        ASSERT $ <= $E9B9

; ===========================================================================
; VZ code area C ($EC61-$EF37: was Spectrum small sprite bitmaps)
; ===========================================================================
        ORG $EC61
        INCLUDE "frontdata2.asm"
        INCLUDE "fws2.asm"
codeC_end:
        ASSERT $ <= $EF38

; ===========================================================================
; VZ code area D ($FB86-$FDFC: was the Spectrum title-logo code)
; ===========================================================================
        ORG $FB86
        INCLUDE "frontdata3.asm"
codeD_end:
        ASSERT $ <= $FDFD

; ===========================================================================
; VZ areas E ($81A6-$8309) and F ($830B-$8598): the Spectrum menu, define
; keys and hall-of-fame logo code, all replaced by the VZ front end
; ($830A sound flag and $8599 machine flag are kept)
; ===========================================================================
        ORG $81A6
        INCLUDE "frontdata4.asm"
codeE_end:
        ASSERT $ <= $830A
        ORG $830B
        INCLUDE "frontdata5.asm"
codeF_end:
        ASSERT $ <= $8599

; ===========================================================================
        SAVEBIN "../build/memA.bin",$4000,$1800
        SAVEBIN "../build/memL.bin",$5B00,RELO_LO-$5B00
        SAVEBIN "../build/memH.bin",$7800,$8800
        DISPLAY "vz_boot = ",/H,vz_boot
        DISPLAY "codeA end ",/H,codeA_end
        DISPLAY "codeB end ",/H,codeB_end
        DISPLAY "codeC end ",/H,codeC_end
        DISPLAY "codeD end ",/H,codeD_end
        DISPLAY "codeE end ",/H,codeE_end
        DISPLAY "codeF end ",/H,codeF_end
