"""Recursive-descent code discovery for Boulder Dash (Spectrum).
Outputs codeinfo.json: list of instruction start addresses and code byte set."""
import sys, json
sys.path.insert(0, './tools')
from z80dis import dis

m = open('./entry.bin', 'rb').read()
maps = [open(f, 'rb').read() for f in sys.argv[1:]]
LO, HI = 0x5B00, 0xBB80
entries = set()
for mp in maps:
    for a in range(LO, HI):
        if mp[a] & 1:
            entries.add(a)
# ISR source and dispatch table
entries.add(0x8121)
for c in range(0x40):
    v = m[0xAF41 + 2 * c] | m[0xAF42 + 2 * c] << 8
    if v:
        entries.add(v)
entries.add(0x7CC1)
ins = {}
codebytes = set()
work = sorted(entries)
seen = set()
while work:
    a = work.pop()
    while LO <= a < HI and a not in seen:
        seen.add(a)
        n, t, info = dis(m, a)
        ins[a] = (n, t)
        for i in range(n):
            codebytes.add(a + i)
        f = info['flow']
        tgt = None
        if f in ('jp', 'call'):
            tgt = info['imm16'][1]
        elif f == 'jr':
            tgt = info['jr']
        if tgt is not None and LO <= tgt < HI and tgt not in seen:
            work.append(tgt)
        if f in ('ret', 'jpind') and not info['cond']:
            break
        if f in ('jp', 'jr') and not info['cond']:
            break
        if f == 'rst':
            pass
        a += n
# overlap check
starts = sorted(ins)
over = []
for a in starts:
    n = ins[a][0]
    for i in range(1, n):
        if a + i in ins:
            over.append(a)
print('instructions', len(ins), 'code bytes', len(codebytes), 'overlaps', [hex(x) for x in over])
json.dump({'ins': {str(a): ins[a] for a in starts}}, open('./dis/codeinfo.json', 'w'))
# report code not executed
mp = maps[0]
r = []
cur = None
for a in starts:
    ex = any(mm[a] & 1 for mm in maps)
    if not ex:
        if cur and a <= cur[1] + 4:
            cur[1] = a
        else:
            if cur:
                r.append(cur)
            cur = [a, a]
if cur:
    r.append(cur)
print('unexecuted code ranges:')
for s, e in r:
    print(f'  {s:04X}-{e:04X}')
