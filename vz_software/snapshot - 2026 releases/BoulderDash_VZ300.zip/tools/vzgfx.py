"""VZ300 graphics for Boulder Dash: 8x8 four-colour tiles (MC6847 CG2, CSS=0).
Colours:  G=green(0)  Y=yellow(1)  .=blue(2, background)  R=red(3)
Each 8x8 tile is split into four 4x4 quarter-characters matching the Spectrum
character layout (c, c+1, c+16, c+17).  Output: src/vz_gfx.asm + preview PNG."""
from PIL import Image

COL = {'G': 0, 'Y': 1, '.': 2, 'B': 2, 'R': 3}
RGB = [(0, 200, 0), (240, 240, 0), (0, 0, 200), (220, 0, 0)]


def T(s):
    rows = [r.strip() for r in s.strip().split('\n')]
    assert len(rows) == 8 and all(len(r) == 8 for r in rows), s
    return [[COL[c] for c in r] for r in rows]


def quarter_bytes(t, qx, qy):
    out = []
    for y in range(4):
        b = 0
        for x in range(4):
            b = (b << 2) | t[qy * 4 + y][qx * 4 + x]
        out.append(b)
    return out


def tile16(t):  # TL, TR, BL, BR quarters, 4 bytes each
    return quarter_bytes(t, 0, 0) + quarter_bytes(t, 1, 0) + quarter_bytes(t, 0, 1) + quarter_bytes(t, 1, 1)


def mirror(t):
    return [list(reversed(r)) for r in t]


SPACE = T("""
........
........
........
........
........
........
........
........""")
DIRT = T("""
RRRRRRRR
RR.RRRRR
RRRRRR.R
RRRRRRRR
R.RRRRRR
RRRR.RRR
RRRRRRRR
RRRRRR.R""")
STEEL = T("""
YYYYYYYG
YGGGGGG.
YG.GG.G.
YGGGGGG.
YGGGGGG.
YG.GG.G.
YGGGGGG.
G.......""")
BRICK = T("""
RRRRRRR.
RRRRRRR.
RRRRRRR.
YYYYYYYY
RRR.RRRR
RRR.RRRR
RRR.RRRR
YYYYYYYY""")
BOULDER = T("""
..YYYY..
.YYYYYR.
YYGYYYYR
YGYYYYRR
YYYYYYRR
YYYYYRRR
.YRRRRR.
..RRRR..""")
OUTBOX = T("""
YYYYYYYY
Y......Y
Y.GGGG.Y
Y.G..G.Y
Y.G..G.Y
Y.GGGG.Y
Y......Y
YYYYYYYY""")
# explosion stages
EXPL = [T("""
........
...Y....
.Y...R..
...RR...
..RR..Y.
.R...Y..
....R...
........"""), T("""
Y..R...Y
..YRRY..
.RYYYRR.
RRY..YR.
.RY..YRR
.RRYYR..
..YRR.Y.
Y...R..Y"""), T("""
.R..Y..R
R.Y...Y.
...R.R..
Y.R...R.
..R...RY
.R.Y.R..
Y...Y..R
.R..R..Y""")]
REVEAL_Q = [0b01000100, 0b00010001, 0b01000100, 0b00010001]  # green/yellow dither quarter


def diamond(k):
    base = """
...YY...
..YGGY..
.YGGGGY.
YGGGGGGY
.YGGGGY.
..YGGY..
...YY...
........"""
    t = T(base)
    # sparkle: a yellow band sweeps down the facets, plus a twinkle pixel
    band = k % 8
    for y in range(7):
        for x in range(8):
            if t[y][x] == 0 and (y == band or y == band - 1):
                t[y][x] = 1
    tw = [(0, 3), (1, 6), (3, 7), (5, 6), (6, 4), (5, 1), (3, 0), (1, 1)][k]
    if t[tw[0]][tw[1]] == 2:
        t[tw[0]][tw[1]] = 1
    return t


def firefly(k):
    t = [[2] * 8 for _ in range(8)]
    for i in range(8):
        for j in range(8):
            ring = min(i, j, 7 - i, 7 - j)
            if ring == 0:
                t[i][j] = 1 if (k % 2 == 0) else 3
            elif ring == 1:
                t[i][j] = 3 if (k % 2 == 0) else 1
            elif ring == 2:
                t[i][j] = 2
            else:
                t[i][j] = 1
    # rotating dark notch on the outer ring
    path = [(0, x) for x in range(8)] + [(y, 7) for y in range(1, 8)] + [(7, x) for x in range(6, -1, -1)] + [(y, 0) for y in range(6, 0, -1)]
    for d in range(3):
        y, x = path[(k * 4 + d) % len(path)]
        t[y][x] = 2
    return t


BFLY = ["YY....YY",
        "YGY..YGY",
        "YGGYYGGY",
        ".YGYYGY.",
        ".YGYYGY.",
        "YGGYYGGY",
        "YGY..YGY",
        "YY....YY"]


def butterfly(k):
    w = [8, 6, 4, 2, 2, 4, 6, 8][k]          # wing span in pixels
    t = [[2] * 8 for _ in range(8)]
    for y in range(8):
        row = BFLY[y]
        for x in range(8):
            c = row[x]
            if c == '.':
                continue
            # compress horizontally towards the body (columns 3,4)
            if x < 4:
                nx = 4 - max(1, round((4 - x) * w / 8))
            else:
                nx = 3 + max(1, round((x - 3) * w / 8))
            if t[y][nx] == 2 or c == 'Y':
                t[y][nx] = COL[c]
    return t


def amoeba(k):
    base = T("""
.GGGG.G.
GGYGGGGG
GGGGGYGG
.GGGGGGG
GGGYGGG.
GGGGGGGG
GYGGGGYG
.GGG.GG.""")
    t = [r[:] for r in base]
    bub = [(1, 2), (2, 5), (4, 3), (6, 1), (6, 6)]
    for y, x in bub:
        t[y][x] = 0
    for i, (y, x) in enumerate(bub):
        if (i + k) % 3 == 0:
            t[y][x] = 1
        ny, nx = (y + k) % 8, (x + 2 * k) % 8
        if t[ny][nx] == 0 and (k + i) % 2:
            t[ny][nx] = 1
    return t


def magic(k):
    t = [r[:] for r in BRICK]
    for y in range(8):
        for x in range(8):
            if t[y][x] == 1:  # mortar shimmers
                t[y][x] = [1, 0, 2, 0][(x + y + k) % 4] if (x + k) % 2 == 0 else 1
            elif t[y][x] == 3 and (x + y * 3 + k * 2) % 7 == 0:
                t[y][x] = 0
    return t


# Rockford
ROCK_STAND = T("""
..YYYY..
..YRRY..
..YYYY..
...RR...
.YRRRRY.
...RR...
..R..R..
.YY..YY.""")
ROCK_BLINK = T("""
..YYYY..
..YYYY..
..YYYY..
...RR...
.YRRRRY.
...RR...
..R..R..
.YY..YY.""")
ROCK_TAP = T("""
..YYYY..
..YRRY..
..YYYY..
...RR...
.YRRRRY.
...RR...
..R..R..
.YY.YY..""")
WALK_R = [T("""
..YYYY..
...YRY..
..YYYY..
...RR...
..RRRRY.
...RR...
..R..R..
.YY...YY"""), T("""
..YYYY..
...YRY..
..YYYY..
...RR...
..RRRRY.
...RR...
...RR...
...YYY.."""), T("""
..YYYY..
...YRY..
..YYYY..
...RR...
.YRRRR..
...RR...
..R..R..
.YY...YY"""), T("""
..YYYY..
...YRY..
..YYYY..
...RR...
.YRRRR..
...RR...
...RR...
..YYY...""")]
WALK_L = [mirror(t) for t in WALK_R]


def asm_bytes(label, bs):
    lines = [f'{label}:'] if label else []
    for i in range(0, len(bs), 16):
        lines.append('        DEFB ' + ','.join(f'${b:02X}' for b in bs[i:i + 16]))
    return lines


# ---------- build VFONT (128 quarter-chars * 4 bytes) ----------
font = [[0xAA] * 4 for _ in range(128)]


def place(code, t):
    q = tile16(t)
    for i, c in enumerate((code, code + 1, code + 16, code + 17)):
        font[c] = q[4 * i:4 * i + 4]


place(0x40, SPACE)
place(0x26, DIRT)
place(0x2A, STEEL)
place(0x0E, STEEL)        # pre-outbox looks like steel (as original)
place(0x2E, BRICK)
place(0x02, BRICK)        # magic wall dormant
place(0x24, BOULDER)
place(0x42, OUTBOX)
place(0x46, EXPL[0])
place(0x48, EXPL[1])
place(0x4A, EXPL[2])
# explosion turning into diamonds (stages 04..0C): explosion fading to diamond
place(0x04, EXPL[0])
place(0x06, EXPL[1])
place(0x08, EXPL[2])
place(0x0A, EXPL[1])
place(0x0C, diamond(0))
place(0x28, diamond(0))
place(0x20, amoeba(0))
place(0x00, butterfly(0))
place(0x44, firefly(0))
place(0x2C, ROCK_STAND)
place(0x22, ROCK_STAND)   # default head (22,23) and feet (32,33)
font[0x5C] = REVEAL_Q[:]

out = ['; ---- generated by vzgfx.py ----', '        ALIGN 256']
out += asm_bytes('VFONT', [b for g in font for b in g])


def anim(label, fn):
    bs = []
    for k in range(8):
        bs += tile16(fn(k))
    return asm_bytes(label, bs)


out += anim('ANIM_DIAM', diamond)
out += anim('ANIM_AMOEBA', amoeba)
out += anim('ANIM_BFLY', butterfly)
out += anim('ANIM_FFLY', firefly)
out += anim('ANIM_MAGIC', lambda k: magic(k % 4))
out += anim('RF_WALKR', lambda k: WALK_R[k % 4])
out += anim('RF_WALKL', lambda k: WALK_L[k % 4])
# idle Rockford: top half (head) and bottom half (feet), per frame
blink = []
tap = []
for k in range(8):
    tb = tile16(ROCK_BLINK if k in (2, 3) else ROCK_STAND)
    blink += tb[0:8]
    tt = tile16(ROCK_TAP if k % 4 in (1, 2) else ROCK_STAND)
    tap += tt[8:16]
out += asm_bytes('RF_BLINK', blink)
out += asm_bytes('RF_TAP', tap)
st = tile16(ROCK_STAND)
out += asm_bytes('RF_HEAD', st[0:8])
out += asm_bytes('RF_FEET', st[8:16])
out += asm_bytes('BRICK16', tile16(BRICK))

# ---------- status font: 3x5 glyphs in 4x8 cells, yellow on blue ----------
F35 = {
    ' ': ['...', '...', '...', '...', '...'],
    '0': ['YYY', 'Y.Y', 'Y.Y', 'Y.Y', 'YYY'], '1': ['.Y.', 'YY.', '.Y.', '.Y.', 'YYY'],
    '2': ['YYY', '..Y', 'YYY', 'Y..', 'YYY'], '3': ['YYY', '..Y', '.YY', '..Y', 'YYY'],
    '4': ['Y.Y', 'Y.Y', 'YYY', '..Y', '..Y'], '5': ['YYY', 'Y..', 'YYY', '..Y', 'YYY'],
    '6': ['YYY', 'Y..', 'YYY', 'Y.Y', 'YYY'], '7': ['YYY', '..Y', '.Y.', '.Y.', '.Y.'],
    '8': ['YYY', 'Y.Y', 'YYY', 'Y.Y', 'YYY'], '9': ['YYY', 'Y.Y', 'YYY', '..Y', 'YYY'],
    'A': ['.Y.', 'Y.Y', 'YYY', 'Y.Y', 'Y.Y'], 'B': ['YY.', 'Y.Y', 'YY.', 'Y.Y', 'YY.'],
    'C': ['.YY', 'Y..', 'Y..', 'Y..', '.YY'], 'D': ['YY.', 'Y.Y', 'Y.Y', 'Y.Y', 'YY.'],
    'E': ['YYY', 'Y..', 'YY.', 'Y..', 'YYY'], 'F': ['YYY', 'Y..', 'YY.', 'Y..', 'Y..'],
    'G': ['.YY', 'Y..', 'Y.Y', 'Y.Y', '.YY'], 'H': ['Y.Y', 'Y.Y', 'YYY', 'Y.Y', 'Y.Y'],
    'I': ['YYY', '.Y.', '.Y.', '.Y.', 'YYY'], 'J': ['..Y', '..Y', '..Y', 'Y.Y', '.Y.'],
    'K': ['Y.Y', 'Y.Y', 'YY.', 'Y.Y', 'Y.Y'], 'L': ['Y..', 'Y..', 'Y..', 'Y..', 'YYY'],
    'M': ['Y.Y', 'YYY', 'YYY', 'Y.Y', 'Y.Y'], 'N': ['YY.', 'Y.Y', 'Y.Y', 'Y.Y', 'Y.Y'],
    'O': ['.Y.', 'Y.Y', 'Y.Y', 'Y.Y', '.Y.'], 'P': ['YY.', 'Y.Y', 'YY.', 'Y..', 'Y..'],
    'Q': ['.Y.', 'Y.Y', 'Y.Y', 'YY.', '.YY'], 'R': ['YY.', 'Y.Y', 'YY.', 'Y.Y', 'Y.Y'],
    'S': ['.YY', 'Y..', '.Y.', '..Y', 'YY.'], 'T': ['YYY', '.Y.', '.Y.', '.Y.', '.Y.'],
    'U': ['Y.Y', 'Y.Y', 'Y.Y', 'Y.Y', 'YYY'], 'V': ['Y.Y', 'Y.Y', 'Y.Y', 'Y.Y', '.Y.'],
    'W': ['Y.Y', 'Y.Y', 'YYY', 'YYY', 'Y.Y'], 'X': ['Y.Y', 'Y.Y', '.Y.', 'Y.Y', 'Y.Y'],
    'Y': ['Y.Y', 'Y.Y', '.Y.', '.Y.', '.Y.'], 'Z': ['YYY', '..Y', '.Y.', 'Y..', 'YYY'],
    ',': ['...', '...', '...', '.Y.', 'Y..'], '.': ['...', '...', '...', '...', '.Y.'],
    '/': ['..Y', '..Y', '.Y.', 'Y..', 'Y..'], ':': ['...', '.Y.', '...', '.Y.', '...'],
    '-': ['...', '...', 'YYY', '...', '...'], '!': ['.Y.', '.Y.', '.Y.', '...', '.Y.'],
    '\\': ['.G.', 'GYG', 'YGY', 'GYG', '.G.'],   # diamond icon (code $5C)
    '>': ['Y..', '.Y.', '..Y', '.Y.', 'Y..'], '[': ['YY.', 'Y..', 'Y..', 'Y..', 'YY.'],
    ']': ['.YY', '..Y', '..Y', '..Y', '.YY'], '(': ['.Y.', 'Y..', 'Y..', 'Y..', '.Y.'],
    ')': ['.Y.', '..Y', '..Y', '..Y', '.Y.'],
}
sf = []
for code in range(0x20, 0x60):
    ch = chr(code)
    if ch == '@':
        ch = ' '
    g = F35.get(ch, F35[' '])
    rows = ['....'] + [r + '.' for r in g] + ['....', '....']
    for r in rows:
        b = 0
        for c in r:
            b = (b << 2) | COL[c]
        sf.append(b)
out += asm_bytes('STATFONT', sf)

open('./src/vz_gfx.asm', 'w').write('\n'.join(out) + '\n')

# ---------- preview ----------
S = 6
prev = Image.new("RGB", (9 * (16 * S + 6), 7 * (8 * S + 6)), (40, 40, 40))
px = prev.load()


def draw(t, ox, oy):
    for y in range(8):
        for x in range(8):
            c = RGB[t[y][x]]
            for dy in range(S):
                for dx in range(2 * S):
                    px[ox + x * 2 * S + dx, oy + y * S + dy] = c


rows = [[SPACE, DIRT, STEEL, BRICK, BOULDER, OUTBOX] + EXPL,
        [diamond(k) for k in range(8)], [amoeba(k) for k in range(8)], [butterfly(k) for k in range(8)],
        [firefly(k) for k in range(8)], [magic(k) for k in range(4)] + [ROCK_STAND, ROCK_BLINK, ROCK_TAP],
        WALK_R + WALK_L]
for j, r in enumerate(rows):
    for i, t in enumerate(r):
        draw(t, i * (8 * 2 * S + 6), j * (8 * S + 6))
import os; os.makedirs('out', exist_ok=True); prev.save('./out/tiles_preview.png')
print('ok', len(sf))
