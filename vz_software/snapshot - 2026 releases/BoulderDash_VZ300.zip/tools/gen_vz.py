"""Apply VZ300 patches to the verified Spectrum source (bd_body.asm -> bd_vz_body.asm).

Patches keep every original routine at its original (relocated) address:
  jp(a, target)        replace the first instruction(s) at a with JP target (+NOP pad)
  rep(a, n, text)      replace instructions covering exactly n bytes from a with text (padded with NOPs)
  data(a, bytes)       overwrite data bytes starting at a
"""
import json, re, sys
sys.path.insert(0, './tools')

ins = {int(k): v for k, v in json.load(open('./dis/codeinfo.json'))['ins'].items()}
lines = open('./src/bd_body.asm').read().split('\n')

# index: address -> line number for instruction lines
addr_line = {}
for i, l in enumerate(lines):
    m = re.search(r';\s*([0-9A-F]{4})\s*$', l)
    if m and l.startswith('        ') and 'DEFB' not in l:
        addr_line[int(m.group(1), 16)] = i
label_at = {}
for i, l in enumerate(lines):
    if re.match(r'^[LD]_[0-9A-F]{4}:$', l):
        label_at[int(l[2:6], 16)] = i

edits = {}  # line index -> replacement text (list of lines) or None to delete


def span(a, n):
    """instructions starting at a covering >= n bytes; return (addrs, total)"""
    tot = 0
    addrs = []
    x = a
    while tot < n:
        if x not in ins:
            raise SystemExit(f'no instruction at {x:04X}')
        addrs.append(x)
        tot += ins[x][0]
        x += ins[x][0]
    return addrs, tot


def check_labels(addrs):
    for x in addrs[1:]:
        if x in label_at:
            print(f'WARNING: label L_{x:04X} inside patched span')


def rep(a, n, text, exact=True):
    addrs, tot = span(a, n)
    if exact and tot != n:
        raise SystemExit(f'rep {a:04X}: span is {tot} bytes not {n}')
    check_labels(addrs)
    new = [f'        {t:<28}; VZ patch {a:04X}' for t in text.split('\n') if t.strip()]
    new.append(f'        ASSERT $ <= L_{a:04X}+{tot}  ; patch fits')
    new.append(f'        IF L_{a:04X}+{tot}-$ > 0 : DEFS L_{a:04X}+{tot}-$,0 : ENDIF  ; NOP pad')
    edits[addr_line[addrs[0]]] = new
    for x in addrs[1:]:
        edits[addr_line[x]] = []
    labels_needed.add(a)


def jp(a, target):
    addrs, tot = span(a, 3)
    rep(a, tot, f'JP {target}')


labels_needed = set()


def data(a, bs):
    """overwrite bytes in DEFB lines by emitting ORG patch later"""
    data_patches.append((a, bs))


data_patches = []

# ---------------- hardware layer ----------------
jp(0x8100, 'VZ_INTSETUP')          # IM2 vector table install -> VZ version
jp(0x7F94, 'VZ_RENDER')            # playfield renderer
jp(0x80AA, 'VZ_STATUS')            # status line renderer
jp(0x800B, 'VZ_HELPSCREEN')        # joystick/help text screen
jp(0x801E, 'VZ_TITLESCREEN')       # title screen
jp(0x6DC2, 'VZ_ROCKDRAW')          # per-frame Rockford sprite draw (from ISR)
jp(0x6CF4, 'VZ_ROCKANIM')          # Rockford animation frame selection
jp(0x6E32, 'VZ_OBJANIM')           # diamond/amoeba/butterfly/firefly glyph animation
jp(0x6EBC, 'VZ_MAGICOFF')          # magic wall dormant glyph
jp(0x6EC2, 'VZ_MAGICON')           # magic wall active glyph + hum
jp(0x6C46, 'VZ_REVEALANIM')        # cave reveal pattern + noise
jp(0x69E1, 'VZ_TITLEPHASE')        # title logo shimmer pattern
jp(0x76C7, 'VZ_RET')               # title logo shimmer OR (handled in VZ title)
jp(0x6996, 'VZ_SPARKLE')           # bonus-life space sparkle
jp(0x696D, 'VZ_SPARKCLR')
jp(0x6E73, 'VZ_FLASH')             # border flash -> CSS flash
# sound routines (OUT ($FE) -> VZ speaker latch)
jp(0x642D, 'VZ_SND_642D')
jp(0x6531, 'VZ_SND_6531')
jp(0x6544, 'VZ_SND_6544')
jp(0x666D, 'VZ_SND_666D')
jp(0x668F, 'VZ_SND_668F')
jp(0x66A2, 'VZ_SND_66A2')
jp(0x6E89, 'VZ_SND_6E89')
jp(0x79A8, 'VZ_SND_79A8')
rep(0x7C56, 4, 'NOP')               # LD A,0 / OUT ($FE),A (border black)
rep(0x76A2, 3, 'CALL VZ_BEEPER')    # ROM BEEPER call in title tune
# keyboard / joystick
jp(0x7CEE, 'VZ_KEYCMD')
jp(0x7D06, 'VZ_KEYCMD2')
jp(0x7E16, 'VZ_JOYKEYS')
rep(0x7720, 6, 'LD A,($687F)\nAND $20')   # J key on title
rep(0x7D4F, 2, 'LD A,$01')          # default control type = keyboard
rep(0x7D8D, 2, 'CP $02')            # two control types
# colour-attribute map is not used on the VZ: remove all writes to it
rep(0x6056, 1, 'RET')
rep(0x680D, 3, 'RET')
rep(0x6B51, 3, 'RET')
rep(0x6BA0, 11, 'NOP')
rep(0x6C70, 15, 'NOP')
rep(0x7503, 0x7536 - 0x7503, 'NOP')
rep(0x7DCF, 0x7DEA - 0x7DCF, 'NOP')
rep(0x77B4, 0x77C1 - 0x77B4, 'NOP')
rep(0x784C, 0x7892 - 0x784C, 'NOP')
# vertical scrolling for a 14-character-row window (Spectrum: 22 rows)
rep(0x6A79, 2, 'CP VZ_SCR_UP')
rep(0x6A82, 2, 'CP VZ_SCR_DOWN')
rep(0x6A8B, 2, 'CP VZ_SCR_C0')
rep(0x6A90, 2, 'CP VZ_SCR_C1')
rep(0x6A95, 2, 'CP VZ_SCR_C2')
rep(0x6AEE, 4, 'LD (IY-$51),VZ_VMAX_INTER')
rep(0x6AF9, 4, 'LD (IY-$51),VZ_VMAX')
# timing: pace the game to the measured Spectrum rates
jp(0x6F4F, 'VZ_6F4F')
jp(0x76E3, 'VZ_76E3')
jp(0x70FA, 'VZ_70FA')
jp(0x7107, 'VZ_SCANROW')
jp(0x60BA, 'VZ_60BA')
jp(0x614F, 'VZ_614F')
rep(0x6967, 3, 'CALL VZ_THUDFLAG')
jp(0x6F84, 'VZ_6F84')
jp(0x60F1, 'VZ_60F1')
jp(0x6C8D, 'VZ_DRAWROW')

out = []
for i, l in enumerate(lines):
    if i in edits:
        out.extend(edits[i])
    else:
        out.append(l)
txt = '\n'.join(out)
# make sure labels exist for every patched address
for a in labels_needed:
    if f'L_{a:04X}:' not in txt:
        li = None
        for j, l in enumerate(out):
            if l.endswith(f'; VZ patch {a:04X}'):
                li = j
                break
        out.insert(li, f'L_{a:04X}:')
        txt = '\n'.join(out)
open('./src/bd_vz_body.asm', 'w').write(txt + '\n')
print('patched', len(edits), 'sites')
