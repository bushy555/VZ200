import sys
b=open(sys.argv[1],'rb').read()
name=b'BOULDER DASH'
hdr=b'VZF0'+name.ljust(17,b'\0')[:17]+bytes([0xF1])+(0x7B00).to_bytes(2,'little')
assert len(hdr)==24
open(sys.argv[2],'wb').write(hdr+b)
print('wrote',sys.argv[2],len(hdr+b))
