"""Compact Z80 disassembler returning structured instructions.

dis(mem, addr) -> (length, text, info)
info: dict with keys
  'imm16': (offset_in_instr, value) if a 16-bit immediate/address operand
  'imm8' : (offset, value) for 8-bit immediates (n)
  'jr'   : target for relative jumps
  'flow' : one of None,'jp','jr','call','ret','rst','jpind','halt'
  'cond' : True if conditional
Text uses ${:04X} for 16-bit operands and ${:02X} for 8-bit.
"""
R = ['B', 'C', 'D', 'E', 'H', 'L', '(HL)', 'A']
RP = ['BC', 'DE', 'HL', 'SP']
RP2 = ['BC', 'DE', 'HL', 'AF']
CC = ['NZ', 'Z', 'NC', 'C', 'PO', 'PE', 'P', 'M']
ALU = ['ADD A,', 'ADC A,', 'SUB ', 'SBC A,', 'AND ', 'XOR ', 'OR ', 'CP ']
ROT = ['RLC', 'RRC', 'RL', 'RR', 'SLA', 'SRA', 'SLL', 'SRL']


def w(m, a):
    return m[a & 0xFFFF] | (m[(a + 1) & 0xFFFF] << 8)


def s8(v):
    return v - 256 if v > 127 else v


def dis(m, a):
    op = m[a]
    info = {'flow': None, 'cond': False}
    if op == 0xCB:
        o = m[a + 1]
        x, y, z = o >> 6, (o >> 3) & 7, o & 7
        if x == 0:
            t = f'{ROT[y]} {R[z]}'
        else:
            t = f"{['', 'BIT', 'RES', 'SET'][x]} {y},{R[z]}"
        return 2, t, info
    if op == 0xED:
        o = m[a + 1]
        x, y, z, p, q = o >> 6, (o >> 3) & 7, o & 7, (o >> 4) & 3, (o >> 3) & 1
        if x == 1:
            if z == 0:
                return 2, (f'IN {R[y]},(C)' if y != 6 else 'IN F,(C)'), info
            if z == 1:
                return 2, (f'OUT (C),{R[y]}' if y != 6 else 'OUT (C),0'), info
            if z == 2:
                return 2, (f'SBC HL,{RP[p]}' if q == 0 else f'ADC HL,{RP[p]}'), info
            if z == 3:
                v = w(m, a + 2)
                info['imm16'] = (2, v)
                if q == 0:
                    return 4, f'LD (${v:04X}),{RP[p]}', info
                return 4, f'LD {RP[p]},(${v:04X})', info
            if z == 4:
                return 2, 'NEG', info
            if z == 5:
                info['flow'] = 'ret'
                return 2, ('RETI' if y == 1 else 'RETN'), info
            if z == 6:
                return 2, f"IM {[0, 0, 1, 2, 0, 0, 1, 2][y]}", info
            if z == 7:
                return 2, ['LD I,A', 'LD R,A', 'LD A,I', 'LD A,R', 'RRD', 'RLD', 'NOP', 'NOP'][y], info
        if x == 2 and z <= 3 and y >= 4:
            t = [['LDI', 'CPI', 'INI', 'OUTI'], ['LDD', 'CPD', 'IND', 'OUTD'],
                 ['LDIR', 'CPIR', 'INIR', 'OTIR'], ['LDDR', 'CPDR', 'INDR', 'OTDR']][y - 4][z]
            return 2, t, info
        return 2, f'DEFB $ED,${o:02X}', info
    if op in (0xDD, 0xFD):
        ix = 'IX' if op == 0xDD else 'IY'
        o = m[a + 1]
        if o == 0xCB:
            d = s8(m[a + 2])
            o2 = m[a + 3]
            x, y, z = o2 >> 6, (o2 >> 3) & 7, o2 & 7
            ds = f'({ix}{d:+d})'.replace('+', '+$').replace('-', '-$') if False else f'({ix}{"+" if d >= 0 else "-"}${abs(d):02X})'
            if x == 0:
                t = f'{ROT[y]} {ds}'
            else:
                t = f"{['', 'BIT', 'RES', 'SET'][x]} {y},{ds}"
            if z != 6 and x != 1:
                t += f',{R[z]}'
            return 4, t, info
        # decode as HL-instruction with substitution
        n, t, inf2 = dis_main(m, a + 1, ix)
        if n is None:
            return 1, f'DEFB ${op:02X}', info
        # shift offsets
        for k in ('imm16', 'imm8'):
            if k in inf2:
                inf2[k] = (inf2[k][0] + 1, inf2[k][1])
        return n + 1, t, inf2
    n, t, inf2 = dis_main(m, a, None)
    return n, t, inf2


def dis_main(m, a, ix):
    """Unprefixed opcode at a (or after DD/FD when ix set)."""
    op = m[a]
    x, y, z, p, q = op >> 6, (op >> 3) & 7, op & 7, (op >> 4) & 3, (op >> 3) & 1
    info = {'flow': None, 'cond': False}
    uses_hl = False
    disp = 0  # extra byte for (IX+d)

    def reg(i):
        nonlocal uses_hl, disp
        if i == 6:
            if ix:
                d = s8(m[a + 1])
                disp = 1
                return f'({ix}{"+" if d >= 0 else "-"}${abs(d):02X})'
            return '(HL)'
        if ix and i in (4, 5):
            uses_hl = True
            return (ix + 'H', ix + 'L')[i - 4]
        return R[i]

    def rp(i, tab=RP):
        nonlocal uses_hl
        if tab[i] == 'HL' and ix:
            uses_hl = True
            return ix
        return tab[i]
    if x == 0:
        if z == 0:
            if y == 0:
                return 1, 'NOP', info
            if y == 1:
                return 1, "EX AF,AF'", info
            tgt = (a + 2 + s8(m[a + 1])) & 0xFFFF
            info['jr'] = tgt
            info['flow'] = 'jr'
            if y == 2:
                info['cond'] = True
                return 2, f'DJNZ ${tgt:04X}', info
            if y == 3:
                return 2, f'JR ${tgt:04X}', info
            info['cond'] = True
            return 2, f'JR {CC[y - 4]},${tgt:04X}', info
        if z == 1:
            if q == 0:
                v = w(m, a + 1)
                info['imm16'] = (1, v)
                return 3, f'LD {rp(p)},${v:04X}', info
            return 1, f'ADD {rp(2)},{rp(p)}', info
        if z == 2:
            if q == 0:
                if p == 0:
                    return 1, 'LD (BC),A', info
                if p == 1:
                    return 1, 'LD (DE),A', info
                v = w(m, a + 1)
                info['imm16'] = (1, v)
                if p == 2:
                    return 3, f'LD (${v:04X}),{rp(2)}', info
                return 3, f'LD (${v:04X}),A', info
            if p == 0:
                return 1, 'LD A,(BC)', info
            if p == 1:
                return 1, 'LD A,(DE)', info
            v = w(m, a + 1)
            info['imm16'] = (1, v)
            if p == 2:
                return 3, f'LD {rp(2)},(${v:04X})', info
            return 3, f'LD A,(${v:04X})', info
        if z == 3:
            return 1, f"{'INC' if q == 0 else 'DEC'} {rp(p)}", info
        if z in (4, 5):
            r = reg(y)
            return 1 + disp, f"{'INC' if z == 4 else 'DEC'} {r}", info
        if z == 6:
            r = reg(y)
            v = m[a + 1 + disp]
            info['imm8'] = (1 + disp, v)
            return 2 + disp, f'LD {r},${v:02X}', info
        if z == 7:
            return 1, ['RLCA', 'RRCA', 'RLA', 'RRA', 'DAA', 'CPL', 'SCF', 'CCF'][y], info
    if x == 1:
        if y == 6 and z == 6:
            info['flow'] = 'halt'
            return 1, 'HALT', info
        if ix and (y == 6 or z == 6):
            # (IX+d) with plain H/L
            if y == 6:
                d = reg(6)
                return 2, f'LD {d},{R[z]}', info
            d = reg(6)
            return 2, f'LD {R[y]},{d}', info
        r1 = reg(y)
        r2 = reg(z)
        return 1 + disp, f'LD {r1},{r2}', info
    if x == 2:
        r = reg(z)
        return 1 + disp, f'{ALU[y]}{r}', info
    # x==3
    if z == 0:
        info['flow'] = 'ret'
        info['cond'] = True
        return 1, f'RET {CC[y]}', info
    if z == 1:
        if q == 0:
            return 1, f'POP {rp(p, RP2)}', info
        if p == 0:
            info['flow'] = 'ret'
            return 1, 'RET', info
        if p == 1:
            return 1, 'EXX', info
        if p == 2:
            info['flow'] = 'jpind'
            return 1, f'JP ({rp(2)})', info
        return 1, f'LD SP,{rp(2)}', info
    if z == 2:
        v = w(m, a + 1)
        info['imm16'] = (1, v)
        info['flow'] = 'jp'
        info['cond'] = True
        return 3, f'JP {CC[y]},${v:04X}', info
    if z == 3:
        if y == 0:
            v = w(m, a + 1)
            info['imm16'] = (1, v)
            info['flow'] = 'jp'
            return 3, f'JP ${v:04X}', info
        if y == 1:
            return None, None, None
        if y == 2:
            v = m[a + 1]
            info['imm8'] = (1, v)
            return 2, f'OUT (${v:02X}),A', info
        if y == 3:
            v = m[a + 1]
            info['imm8'] = (1, v)
            return 2, f'IN A,(${v:02X})', info
        if y == 4:
            return 1, f'EX (SP),{rp(2)}', info
        if y == 5:
            return 1, 'EX DE,HL', info
        if y == 6:
            return 1, 'DI', info
        return 1, 'EI', info
    if z == 4:
        v = w(m, a + 1)
        info['imm16'] = (1, v)
        info['flow'] = 'call'
        info['cond'] = True
        return 3, f'CALL {CC[y]},${v:04X}', info
    if z == 5:
        if q == 0:
            return 1, f'PUSH {rp(p, RP2)}', info
        if p == 0:
            v = w(m, a + 1)
            info['imm16'] = (1, v)
            info['flow'] = 'call'
            return 3, f'CALL ${v:04X}', info
        return None, None, None
    if z == 6:
        v = m[a + 1]
        info['imm8'] = (1, v)
        return 2, f'{ALU[y]}${v:02X}', info
    if z == 7:
        info['flow'] = 'rst'
        return 1, f'RST ${y * 8:02X}', info
