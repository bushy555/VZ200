"""Animated title screen data for the VZ300 (MC6847 text/SG4 semigraphics).

Upper area (char rows 0-9 = 64x20 SG4 blocks): stationary BOULDER / DASH logo with a
black outline + drop shadow, over an expanding "diamond tunnel" whose rings move
outward and are coloured as a pinwheel (colour offset per quadrant).

Data produced (src/vz_title2.asm):
  TT_BG     320 bytes  per cell: $FF = logo cell, else type<<6 | (ring distance & 63)
  TT_LOGO   320 bytes  SG4 code for logo cells (0 elsewhere)
  TT_PAT    256 bytes  per (type, s) the SG4 code of a background cell, aligned
  TT_DIV     32 bytes  divider row
Also writes preview PNGs/GIF to out/.
"""
import os
from PIL import Image

SEQ = [2, 5, 0, 5, 2, 6, 3, 6]       # blue cyan green cyan blue magenta red magenta
TWIST = [0, 0, 0, 0]                  # colour offset per quadrant type (pinwheel)
CX, CY = 32, 10                       # tunnel centre (block coords, on a cell boundary)
BW, BH = 64, 20
ROWS = 10

# chunky faceted letters ('#' = solid). BOULDER: 6x7, DASH: 9x8
F1 = {
 'B': ["####.", "##.##", "####.", "##.##", "##.##", "####."],
 'O': [".###.", "##.##", "##.##", "##.##", "##.##", ".###."],
 'U': ["##.##", "##.##", "##.##", "##.##", "##.##", ".###."],
 'L': ["##...", "##...", "##...", "##...", "##...", "#####"],
 'D': ["####.", "##.##", "##.##", "##.##", "##.##", "####."],
 'E': ["#####", "##...", "####.", "##...", "##...", "#####"],
 'R': ["####.", "##.##", "##.##", "####.", "##.##", "##.##"],
}
F2 = {
 'D': ["######.", "##...##", "##...##", "##...##", "##...##", "##...##", "######."],
 'A': ["..###..", ".##.##.", "##...##", "##...##", "#######", "##...##", "##...##"],
 'S': [".######", "##.....", "##.....", ".#####.", ".....##", ".....##", "######."],
 'H': ["##...##", "##...##", "##...##", "#######", "##...##", "##...##", "##...##"],
}


def place(word, font, y0, gap, mask):
    w = len(font[word[0]][0])
    total = len(word) * (w + gap) - gap
    x0 = (BW - total) // 2
    for i, ch in enumerate(word):
        g = font[ch]
        for y, row in enumerate(g):
            for x, c in enumerate(row):
                if c == '#':
                    mask[y0 + y][x0 + i * (w + gap) + x] = 1


letter = [[0] * BW for _ in range(BH)]
place('BOULDER', F1, 1, 2, letter)
place('DASH', F2, 11, 3, letter)

# black plate: 8-neighbour dilation + drop shadow down-right, holes filled
solid = [[0] * BW for _ in range(BH)]
for y in range(BH):
    for x in range(BW):
        if letter[y][x]:
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1, 2):
                    if dx == 2 and dy < 1:
                        continue
                    yy, xx = y + dy, x + dx
                    if 0 <= yy < BH and 0 <= xx < BW:
                        solid[yy][xx] = 1
# fill enclosed holes (flood fill the outside)
outside = [[0] * BW for _ in range(BH)]
st = [(y, x) for y in range(BH) for x in (0, BW - 1)] + [(y, x) for x in range(BW) for y in (0, BH - 1)]
while st:
    y, x = st.pop()
    if 0 <= y < BH and 0 <= x < BW and not outside[y][x] and not solid[y][x]:
        outside[y][x] = 1
        st += [(y + 1, x), (y - 1, x), (y, x + 1), (y, x - 1)]
for y in range(BH):
    for x in range(BW):
        if not outside[y][x]:
            solid[y][x] = 1

# letter colours by cell row: metallic gold for BOULDER, crystal for DASH
ROWCOL = {0: 4, 1: 1, 2: 7, 3: 3,          # BOULDER: buff, yellow, orange, red
          5: 4, 6: 4, 7: 1, 8: 7, 9: 3}    # DASH: buff, yellow, orange, red


def sg4(bits, col):
    return 0x80 | (col << 4) | bits


# cell-level closing: isolated background cells squeezed between logo cells become black
cellsolid = [[any(solid[cy * 2 + dy][cx * 2 + dx] for dy in (0, 1) for dx in (0, 1)) for cx in range(32)] for cy in range(ROWS)]
for it in range(2):
    for cy in range(ROWS):
        for cx in range(32):
            if not cellsolid[cy][cx]:
                h = 0 < cx < 31 and cellsolid[cy][cx - 1] and cellsolid[cy][cx + 1]
                v = 0 < cy < ROWS - 1 and cellsolid[cy - 1][cx] and cellsolid[cy + 1][cx]
                if h:
                    cellsolid[cy][cx] = True
                    solid[cy * 2][cx * 2] = 1

TT_BG, TT_LOGO = [], []
for cy in range(ROWS):
    for cx in range(32):
        blocks = [(cy * 2, cx * 2, 3), (cy * 2, cx * 2 + 1, 2), (cy * 2 + 1, cx * 2, 1), (cy * 2 + 1, cx * 2 + 1, 0)]
        if cellsolid[cy][cx]:
            bits = 0
            for y, x, b in blocks:
                if letter[y][x]:
                    bits |= 1 << b
            TT_BG.append(0xFF)
            TT_LOGO.append(sg4(bits, ROWCOL.get(cy, 4)))
        else:
            # quadrant type: which block is nearest the centre
            right = cx * 2 >= CX
            below = cy * 2 >= CY
            typ = {(True, True): 0, (False, True): 1, (True, False): 2, (False, False): 3}[(right, below)]
            # distance of the nearest block
            bx = cx * 2 if right else cx * 2 + 1
            by = cy * 2 if below else cy * 2 + 1
            dx = bx - CX if right else CX - 1 - bx
            dy = by - CY if below else CY - 1 - by
            TT_BG.append((typ << 6) | ((dx + dy) & 63))
            TT_LOGO.append(0)

# pattern table: for each type and s = (dist - phase) & 63
NEAR = {0: 3, 1: 2, 2: 1, 3: 0}  # bit of the nearest block per type
TT_PAT = []
for typ in range(4):
    nb = NEAR[typ]
    far = {3: 0, 2: 1, 1: 2, 0: 3}[nb]
    for s in range(64):
        bits = 0
        col = None
        for b in range(4):
            off = 0 if b == nb else (2 if b == far else 1)
            v = (s + off) & 63
            if (v & 7) < 6:
                bits |= 1 << b
                col = SEQ[((v >> 3) + TWIST[typ]) & 7]
        TT_PAT.append(sg4(bits, col if col is not None else 0))

# divider: thin bar of SG4 lower-half blocks in a colour gradient
DIVCOLS = [2, 6, 3, 7, 1, 4, 1, 7, 3, 6, 2, 5]
TT_DIV = [sg4(0x03, DIVCOLS[(abs(x - 15.5) // 1.4).__int__() % len(DIVCOLS)]) for x in range(32)]


def asm(label, bs, align=False):
    L = (['        ALIGN 256'] if align else []) + [f'{label}:']
    for i in range(0, len(bs), 16):
        L.append('        DEFB ' + ','.join(f'${b:02X}' for b in bs[i:i + 16]))
    return L


out = ['; ---- generated by vztitle2.py ----']
out += asm('TT_PAT', TT_PAT, align=True)
bgl = []
for i, v in enumerate(TT_BG):
    if v != 0xFF:
        a = 0x7000 + i
        bgl += [a & 255, a >> 8, v]
bgl += [0, 0]
out += asm('TT_BGL', bgl) + asm('TT_LOGO', [c if c else 0x80 for c in TT_LOGO]) + asm('TT_DIV', TT_DIV)
open('./src/vz_title2.asm', 'w').write('\n'.join(out) + '\n')

# ---------------- preview ----------------
PAL = [(0, 255, 0), (255, 255, 0), (0, 0, 255), (255, 0, 0), (255, 255, 255), (0, 255, 255), (255, 0, 255), (255, 128, 0)]


def render(phase):
    img = Image.new('RGB', (256, 12 * ROWS), (0, 0, 0))
    px = img.load()
    for cy in range(ROWS):
        for cx in range(32):
            i = cy * 32 + cx
            code = TT_LOGO[i] if TT_BG[i] == 0xFF else TT_PAT[(TT_BG[i] & 0xC0) | (((TT_BG[i] & 63) - phase) & 63)]
            col = PAL[(code >> 4) & 7]
            for (by, bx, b) in ((0, 0, 3), (0, 1, 2), (1, 0, 1), (1, 1, 0)):
                if code & (1 << b):
                    for y in range(6):
                        for x in range(4):
                            px[cx * 8 + bx * 4 + x, cy * 12 + by * 6 + y] = col
    return img


os.makedirs('out', exist_ok=True)
frames = [render(p).resize((512, 24 * ROWS), Image.NEAREST) for p in range(0, 64)]
frames[0].save('out/title_anim.gif', save_all=True, append_images=frames[1:], duration=120, loop=0)
sheet = Image.new('RGB', (512 * 2, 24 * ROWS * 2))
for i, p in enumerate((0, 3, 6, 9)):
    sheet.paste(frames[p], (512 * (i % 2), 24 * ROWS * (i // 2)))
sheet.save('out/title_frames.png')
print('logo cells', sum(1 for b in TT_BG if b == 0xFF))
