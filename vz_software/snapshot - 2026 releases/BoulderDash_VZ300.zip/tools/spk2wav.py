import sys,struct,wave
d=open(sys.argv[1],'rb').read(); CPU=3546900; FS=22050
t0=float(sys.argv[3]) if len(sys.argv)>3 else 0; t1=float(sys.argv[4]) if len(sys.argv)>4 else 1e9
ev=[struct.unpack('<Qi',d[i:i+12]) for i in range(0,len(d),12)]
lv={0:0,1:1,2:-1,3:0}
out=bytearray(); cur=0; k=0
n=int((min(t1, ev[-1][0]/CPU)-t0)*FS)
for i in range(n):
    t=(t0+i/FS)*CPU
    while k<len(ev) and ev[k][0]<=t: cur=lv[ev[k][1]]; k+=1
    out+=struct.pack('<h',int(cur*12000))
w=wave.open(sys.argv[2],'wb'); w.setnchannels(1); w.setsampwidth(2); w.setframerate(FS); w.writeframes(bytes(out)); w.close()
