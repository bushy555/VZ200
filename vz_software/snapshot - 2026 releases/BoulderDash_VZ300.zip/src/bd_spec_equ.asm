; Buffer placement for the byte-identical Spectrum verification build
COLMAP  EQU $D96D
CHARMAP EQU $E830
CELLMAP EQU $F790
STATBUF EQU $FF70
STACKTOP EQU $D86D
