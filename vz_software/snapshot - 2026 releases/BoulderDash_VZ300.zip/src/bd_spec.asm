        DEVICE NOSLOT64K
        INCLUDE "bd_spec_equ.asm"
        ORG $5B00
        INCLUDE "bd_body.asm"
        SAVEBIN "bd_spec.bin",$5B00,$BB80-$5B00
