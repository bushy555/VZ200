; =============================================================================
;  BOULDER DASH - VZ300 conversion of the ZX Spectrum version
;  (First Star Software 1984, Peter Liepa / Chris Gray)
;
;  Build:  sjasmplus bd_vz.asm      -> bd_vz.bin (load/run at $7B00)
;          python3 ../tools/mkvz.py -> BOULDER.VZ
;
;  Memory (needs 16K expansion RAM, $7800-$F7FF):
;   $7B00-$7CFF  game variables (Spectrum $5B00)
;   $7D00-$DB7F  original game code and data, relocated by +$2000
;   $AB00-$C2FF  VZ hardware layer (in an unused zero area of the original)
;   $DB80-$DBFF  stack
;   $DC00-$EA62  character map 80x44 (+guards)
;   $EA90-$EE4F  cave cell map 40x24 / title text buffer
;   $EE80-$EEFF  status line texts
;   $EF00-$F0BF  playfield shadow (32x14)
;   $F100-$F200  IM2 vector table,  $F2F2 JP VZ_ISR
;   $F300/$F400  glyph dirty flags / snapshot
; =============================================================================
        DEVICE NOSLOT64K
STACKTOP EQU $DC00
COLMAP  EQU $0000                   ; Spectrum attribute map: not used on the VZ
CHARMAP EQU $DC03
CELLMAP EQU $EA90
STATBUF EQU $EE80
SHADOW  EQU $EF00
IM2TAB  EQU $F100
IM2JP   EQU $F2F2
GDIRTY  EQU $F300
GDSNAP  EQU $F400

        ORG $7B00
        INCLUDE "bd_vz_body.asm"
GAME_END:
        ASSERT GAME_END == $DB80

        ORG $AB00
        INCLUDE "vz_main.asm"
VZ_END:
        ASSERT VZ_END <= $C5E0          ; up to the control-screen text (Spectrum text font area is unused)

        ORG $C801                       ; Spectrum animation-frame area (unused on the VZ)
        INCLUDE "vz_sfx.asm"
        ASSERT $ <= $CE81               ; object tables start at $CE81

; ---- text data patches ----
        ORG D_5E54+8                ; control type names (8 chars each)
        DEFM "JOYSTICK"
        DEFM "KEYBOARD"
        ORG D_A5E0                  ; control/help screen (16 rows max)
        DEFM " SELECT CONTROLS [1-2]",$0D,$0D
        DEFM "         1. JOYSTICK 1 OR 2",$0D
        DEFM "         2. KEYBOARD",$0D,$0D
        DEFM " KEYS:    Q UP      A DOWN",$0D
        DEFM "          M LEFT    , RIGHT",$0D
        DEFM "          . FIRE (GRAB)",$0D,$0D
        DEFM "     PRESS FIRE TO CONTINUE",$0D,$0D
        DEFM " X  TO QUIT A CAVE",$0D
        DEFM " R  TO RESET GAME",$0D
        DEFM " P  TO SELECT NUMBER OF PLAYERS",$0D
        DEFM " J  TO RE-SELECT CONTROLS",$0D
        DEFM "     SPACE TO PAUSE",$FF
        ASSERT $ <= D_A5E0+417

        ORG $7B00                   ; autorun entry (vars are cleared at start)
        JP VZ_BOOT

        SAVEBIN "bd_vz.bin",$7B00,$DB80-$7B00
