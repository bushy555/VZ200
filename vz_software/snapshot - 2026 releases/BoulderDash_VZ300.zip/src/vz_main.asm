; =============================================================================
;  Boulder Dash VZ300 hardware layer
;  Replaces the Spectrum screen, keyboard, sound and interrupt routines of the
;  original program.  Assembled into the free area of the relocated game block.
; =============================================================================

VRAM            EQU $7000
LATCH           EQU $6800           ; write: b0/b5 speaker, b3 graphics, b4 CSS
KBD             EQU $6800           ; read: keyboard rows (A0-A7), b7 = field sync
PLAYTOP         EQU VRAM+256        ; playfield starts below the 8-pixel status bar
PLAYROWS        EQU 14              ; character rows of playfield (2 per cave cell)

; vertical scroll parameters for a 14-row window (see L_6A76)
VZ_SCR_UP       EQU $07
VZ_SCR_DOWN     EQU $0E
VZ_SCR_C0       EQU $09
VZ_SCR_C1       EQU $0A
VZ_SCR_C2       EQU $0B
VZ_VMAX         EQU 44-PLAYROWS     ; 30 = 44 char rows - visible rows
VZ_VMAX_INTER   EQU 24-PLAYROWS     ; intermission caves are 12 cells high

; pacing targets in quarter frames (measured on the Spectrum original)
PACE_GAME       EQU 37              ; 9.25 frames per cave scan
PACE_REVEAL     EQU 29              ; 7.25 frames per cave-reveal step
PACE_IDLE       EQU 16              ; 4.1 frames per screen update without scan
PACE_TITLE      EQU 24              ; 6.1 frames per title update

; ---------------------------------------------------------------------------
; Boot: entered from the .VZ autorun jump at the load address
; ---------------------------------------------------------------------------
VZ_BOOT:
        DI
        LD SP,STACKTOP
        LD A,$09                    ; graphics mode, CSS0, speaker idle
        LD (LATCHV),A
        LD (LATCH),A
        LD HL,VRAM
        LD DE,VRAM+1
        LD BC,$07FF
        LD (HL),$AA                 ; blue
        LDIR
        CALL VZ_INTSETUP
        JP L_7CC1                   ; original program entry

; ---------------------------------------------------------------------------
; Interrupts: IM2 with a 257-byte vector table so the (floating) data bus
; value during interrupt acknowledge does not matter.
; ---------------------------------------------------------------------------
VZ_INTSETUP:
        DI
        LD HL,IM2TAB
        LD DE,IM2TAB+1
        LD BC,256
        LD (HL),high(IM2JP)
        LDIR
        LD A,$C3                    ; JP VZ_ISR at IM2JP
        LD (IM2JP),A
        LD HL,VZ_ISR
        LD (IM2JP+1),HL
        LD A,high(IM2TAB)
        LD I,A
        IM 2
        JP EIFS

; Re-enable interrupts only while the VDG field-sync line is high.  The FS
; interrupt is level-triggered and stays asserted for ~57 lines, so the ISR
; returns with interrupts disabled and these cheap "EI points" re-arm it once
; FS is high again: the ISR never runs twice per field and never busy-waits.
EIFS:   DI                          ; uses A and flags
        LD A,(KBD)
        RLA
        JR C,.high
        LD A,(FIELDDONE)            ; FS low: enable only if this field's
        OR A                        ; interrupt has not been serviced yet
        RET NZ
        EI
        RET
.high:  XOR A
        LD (FIELDDONE),A
        EI
        RET

; 50 Hz field-sync interrupt (the VDG's FS line is the Z80 /INT).
; Does exactly what the Spectrum ISR did, then waits for FS to go high again
; so the level-triggered interrupt is not taken twice in one field.
VZ_ISR:
        PUSH AF
        PUSH BC
        PUSH DE
        PUSH HL
        PUSH IX
        PUSH IY
        LD HL,(FRAMES)
        INC HL
        LD (FRAMES),HL
        LD A,1
        LD (FIELDDONE),A
        LD IY,D_5B80
        LD A,(IY+$32)
        CP $00
        JR NZ,.notgame
        CALL L_6E73                 ; screen flash countdown
        CALL L_65CB                 ; cave timer
        CALL L_6DC2                 ; Rockford animation + direct draw
        LD A,(D_5B71)
        CP $00
        CALL NZ,L_6996              ; bonus-life sparkle
.notgame:
        LD A,(TITLEUP)              ; title screen up: animate every 4th field
        OR A
        JR Z,.nt
        LD HL,TBGCNT
        DEC (HL)
        JR NZ,.nt
        LD (HL),4
        CALL VZ_TITLEBG
.nt:    LD A,(IY+$3A)
        AND A
        JR Z,.c1
        DEC (IY+$3A)
.c1:    LD A,(IY+$3D)
        AND A
        JR Z,.c2
        DEC (IY+$3D)
.c2:    LD A,(KBD)                  ; FS still low? then leave interrupts off
        RLA
        JR NC,.noei
        POP IY
        POP IX
        POP HL
        POP DE
        POP BC
        POP AF
        EI
        RETI
.noei:  POP IY
        POP IX
        POP HL
        POP DE
        POP BC
        POP AF
        RETI

; ---------------------------------------------------------------------------
; Pacing: wait until 'A' quarter-frames have passed since the previous call.
; ---------------------------------------------------------------------------
VZ_PACE:
        LD E,A
        LD D,0
.again: CALL EIFS
        LD HL,(FRAMES)
        ADD HL,HL
        ADD HL,HL                   ; now, in quarter frames
        PUSH HL
        LD BC,(PACENEXT)
        OR A
        SBC HL,BC                   ; HL = now - next (signed)
        JP M,.wait
        LD A,H
        OR A
        JR NZ,.resync
        LD A,L
        CP 16                       ; more than 4 frames late: resynchronise
        JR NC,.resync
        POP HL
        LD HL,(PACENEXT)
        ADD HL,DE
        LD (PACENEXT),HL
        RET
.resync:
        POP HL
        ADD HL,DE
        LD (PACENEXT),HL
        RET
.wait:  POP HL
        LD A,I                      ; P/V = IFF2: halt only if interrupts are on
        JP PO,.again
        HALT                        ; sleep until the next field interrupt
        JR .again

VZ_6F4F:                            ; per-update graphics (Spectrum 6F4F)
        LD A,(IY+$15)
        OR A
        LD A,PACE_REVEAL
        JR NZ,.p
        LD A,(SCANNED)
        OR A
        LD A,PACE_GAME
        JR NZ,.p
        LD A,PACE_IDLE
.p:     CALL VZ_PACE
        XOR A
        LD (SCANNED),A
        CALL L_6F05
        JP L_6F4F+3

VZ_76E3:                            ; title animation step (Spectrum 76E3)
        LD A,PACE_TITLE
        CALL VZ_PACE
        BIT 0,(IY+$33)
        JP L_76E3+4

VZ_70FA:                            ; start of a cave scan
        LD A,1
        LD (SCANNED),A
        LD (IY-$5B),$01
        JP L_70FA+4

VZ_RET: RET

VZ_60BA:                            ; cell write + draw (Spectrum 60BA): EI point
        PUSH HL
        PUSH BC
        PUSH DE
        LD C,A
        CALL EIFS
        LD A,C
        JP L_60BA+3

VZ_60F1:                            ; current-cell write + draw (Spectrum 60F1)
        PUSH HL
        PUSH BC
        PUSH DE
        LD C,A
        CALL EIFS
        LD A,C
        JP L_60F1+3

VZ_6F84:                            ; cave fill, per cell (Spectrum 6F84): EI point
        PUSH BC
        CALL EIFS
        LD IX,D_5C1B
        JP L_6F84+5

VZ_SCANROW:                         ; start of each cave-scan row (Spectrum 7107)
        CALL EIFS
        LD (IY-$5C),$00
        JP L_7107+4

VZ_DRAWROW:                         ; start of each cave-draw row (Spectrum 6C8D)
        PUSH AF
        CALL EIFS
        POP AF
        LD (IY-$5C),$00
        JP L_6C8D+4

; ---------------------------------------------------------------------------
; Display mode helpers
; ---------------------------------------------------------------------------
VZ_GFXMODE:                         ; ensure CG2 graphics mode
        LD A,(LATCHV)
        BIT 3,A
        RET NZ
        OR $08
        AND $EF                     ; CSS0
        LD (LATCHV),A
        LD (LATCH),A
        XOR A
        LD (TITLEUP),A
VZ_CLRGFX:
        LD HL,VRAM
        LD DE,VRAM+1
        LD BC,$07FF
        LD (HL),$AA
        LDIR
VZ_INVALIDATE:                      ; force full redraw of playfield and status
        LD HL,SHADOW
        LD DE,SHADOW+1
        LD BC,PLAYROWS*32-1
        LD (HL),$FF
        LDIR
        LD HL,STATSHADOW
        LD DE,STATSHADOW+1
        LD BC,31
        LD (HL),$FF
        LDIR
        RET

VZ_TEXTMODE:                        ; ensure text/semigraphics mode
        LD A,(LATCHV)
        BIT 3,A
        RET Z
        AND $E7                     ; text, CSS0
        LD (LATCHV),A
        LD (LATCH),A
        LD HL,VRAM
        LD DE,VRAM+1
        LD BC,$01FF
        LD (HL),$20
        LDIR
        RET

; ---------------------------------------------------------------------------
; Playfield renderer (replaces Spectrum 7F94)
; Draws the 32x14 character window at (D_5B00) of the 80-column character
; map.  Each character is a 4x4 pixel block (one byte, four rows of 32 bytes).
; Only characters whose code changed, or whose glyph was animated, are drawn.
; ---------------------------------------------------------------------------
VZ_RENDER:
        CALL VZ_STATUS
        CALL VZ_GFXMODE
        ; snapshot and clear the glyph-dirty flags
        LD HL,GDIRTY
        LD DE,GDSNAP
        LD BC,128
        LDIR
        LD HL,GDIRTY
        LD B,128
        XOR A
.clr:   LD (HL),A
        INC L
        DJNZ .clr
        LD DE,(D_5B00)
        LD HL,SHADOW
        LD B,high(GDSNAP)
.row:
.cell:  LD A,(DE)
        CP (HL)
        JR NZ,.draw
        LD C,A
        LD A,(BC)                   ; glyph animated since last frame?
        OR A
        JR NZ,.draw2
.next:  INC DE
        INC HL
        LD A,L
        AND 31
        JR NZ,.cell
        LD A,E                      ; next map row (80 columns)
        ADD A,80-32
        LD E,A
        JR NC,.nc
        INC D
.nc:    CALL EIFS
        LD A,H
        CP high(SHADOW+PLAYROWS*32)
        JR NZ,.row
        LD A,L
        CP low(SHADOW+PLAYROWS*32)
        JR NZ,.row
        RET
.draw2: LD A,C
.draw:  LD (HL),A
        PUSH DE
        PUSH HL
        ; glyph address
        LD E,A
        LD D,0
        EX DE,HL
        ADD HL,HL
        ADD HL,HL
        LD A,H
        ADD A,high(VFONT)
        LD H,A                      ; HL = glyph, DE = shadow pointer
        ; VRAM = PLAYTOP + (off & ~31)*4 + (off & 31), off = shadow - SHADOW
        LD A,E
        SUB low(SHADOW)
        LD C,A
        LD A,D
        SBC A,high(SHADOW)
        LD D,A
        LD A,C
        AND 31
        LD E,A                      ; column
        LD A,C
        AND $E0
        LD C,A                      ; D:C = row*32
        SLA C
        RL D
        SLA C
        RL D                        ; row*128
        LD A,C
        OR E
        LD E,A
        LD A,D
        ADD A,high(PLAYTOP)
        LD D,A                      ; DE = VRAM (PLAYTOP is page aligned)
        LD A,(HL)
        LD (DE),A
        INC L
        LD A,E
        ADD A,32
        LD E,A
        LD A,(HL)
        LD (DE),A
        INC L
        LD A,E
        ADD A,32
        LD E,A
        LD A,(HL)
        LD (DE),A
        INC L
        LD A,E
        ADD A,32
        LD E,A
        LD A,(HL)
        LD (DE),A
        POP HL
        POP DE
        LD B,high(GDSNAP)
        JR .next

; ---------------------------------------------------------------------------
; Status line (replaces Spectrum 80AA): 32 characters from (D_5BD2) drawn in
; a 3x5 font into the top 8 pixel rows.  Only changed characters are drawn.
; ---------------------------------------------------------------------------
VZ_STATUS:
        CALL EIFS
        CALL VZ_GFXMODE
        LD DE,(D_5BD2)
        LD HL,STATSHADOW
        LD C,0                      ; column
.ch:    LD A,(DE)
        CP (HL)
        JR Z,.nx
        LD (HL),A
        PUSH HL
        PUSH DE
        SUB $20
        AND $3F
        LD L,A
        LD H,0
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        LD DE,STATFONT
        ADD HL,DE                   ; HL = glyph (8 rows)
        LD D,high(VRAM)
        LD E,C                      ; DE = VRAM + column (row 0)
        LD B,8
.rw:    LD A,(HL)
        LD (DE),A
        INC HL
        LD A,E
        ADD A,32
        LD E,A
        DJNZ .rw                    ; 8 rows stay within the first 256 bytes
        POP DE
        POP HL
.nx:    INC DE
        INC HL
        INC C
        LD A,C
        CP 32
        JR NZ,.ch
        RET

; ---------------------------------------------------------------------------
; Rockford: animation (Spectrum 6CF4) and direct draw from the ISR (6DC2)
; ---------------------------------------------------------------------------
VZ_ROCKANIM:
        LD A,(D_5BD8)
        INC (IY+$1A)
        BIT 0,(IY+$1A)
        JR Z,.k
        ADD A,$08
        LD (D_5BD8),A
.k:     AND $3F
        LD C,A                      ; frame*8
        LD A,(D_5B1E)
        CP $0F
        JR Z,.idle
        LD (IY+$16),$00
        LD (IY+$17),$00
        LD HL,RF_WALKR
        BIT 0,(IY-$56)
        JR Z,.w
        LD HL,RF_WALKL
.w:     LD B,0
        ADD HL,BC
        ADD HL,BC                   ; + frame*16
        LD DE,VFONT+$2C*4
        CALL VZ_PUT2X2
        RET
.idle:  LD A,C
        OR A
        JR NZ,.sel
        LD (IY+$17),$00
        CALL L_6120
        AND $03
        JR NZ,.nb
        LD (IY+$17),$01
.nb:    CALL L_6120
        AND $0F
        JR NZ,.sel
        LD A,$01
        XOR (IY+$16)
        LD (D_5B96),A
.sel:   LD HL,RF_HEAD
        BIT 0,(IY+$17)
        JR Z,.h
        LD HL,RF_BLINK
        LD B,0
        ADD HL,BC                   ; frame*8
.h:     LD DE,VFONT+$2C*4
        LD BC,8
        LDIR
        LD A,(D_5BD8)
        AND $3F
        LD C,A
        LD HL,RF_FEET
        BIT 0,(IY+$16)
        JR Z,.f
        LD HL,RF_TAP
        LD B,0
        ADD HL,BC
.f:     LD DE,VFONT+$3C*4
        LD BC,8
        LDIR
        LD HL,GDIRTY+$2C
        LD (HL),1
        INC L
        LD (HL),1
        LD L,low(GDIRTY+$3C)
        LD (HL),1
        INC L
        LD (HL),1
        RET

; copy a 16-byte 2x2 tile (TL,TR,BL,BR) from HL to glyphs at DE (code c),
; i.e. c, c+1 and c+16, c+17; marks them dirty
VZ_PUT2X2:
        PUSH DE
        LD BC,8
        LDIR
        EX DE,HL
        LD BC,16*4-8
        ADD HL,BC
        EX DE,HL
        LD BC,8
        LDIR
        POP HL                      ; glyph address -> code
        LD A,H
        SUB high(VFONT)
        LD H,A
        LD A,L
        SRL H
        RRA
        SRL H
        RRA                         ; A = code (VFONT page aligned, 512 bytes)
        LD L,A
        LD H,high(GDIRTY)
        LD (HL),1
        INC L
        LD (HL),1
        ADD A,16
        LD L,A
        LD (HL),1
        INC L
        LD (HL),1
        RET

VZ_ROCKDRAW:
        CALL VZ_ROCKANIM
        BIT 0,(IY+$48)
        RET Z
        LD A,(LATCHV)
        BIT 3,A
        RET Z                       ; not in graphics mode
        LD A,(D_5B8B)
        CP $20
        RET NC
        LD E,A
        LD A,(D_5B8C)
        SUB $04
        CP PLAYROWS-1
        RET NC
        ; HL = PLAYTOP + row*128 + col
        LD L,A
        LD H,0
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        LD D,0
        ADD HL,DE
        LD DE,PLAYTOP
        ADD HL,DE
        LD DE,VFONT+$2C*4
        CALL .two
        LD BC,128-1
        ADD HL,BC
        LD DE,VFONT+$3C*4
.two:   CALL .one
        LD A,L
        INC HL
        AND $1F
        CP $1F
        JR Z,.skip                  ; right edge: second char off screen
        CALL .one
        RET
.skip:  INC DE
        INC DE
        INC DE
        INC DE
        RET
.one:   PUSH HL
        LD BC,32
        LD A,(DE)
        LD (HL),A
        INC DE
        ADD HL,BC
        LD A,(DE)
        LD (HL),A
        INC DE
        ADD HL,BC
        LD A,(DE)
        LD (HL),A
        INC DE
        ADD HL,BC
        LD A,(DE)
        LD (HL),A
        INC DE
        POP HL
        RET

; ---------------------------------------------------------------------------
; Object animations (Spectrum 6E32): diamond, amoeba, butterfly, firefly
; ---------------------------------------------------------------------------
VZ_OBJANIM:
        LD A,(D_5B98)
        AND $38                     ; frame*8
        LD C,A
        LD B,0
        LD HL,ANIM_DIAM
        LD DE,VFONT+$28*4
        CALL .one
        LD HL,ANIM_AMOEBA
        LD DE,VFONT+$20*4
        CALL .one
        LD HL,ANIM_BFLY
        LD DE,VFONT+$00*4
        CALL .one
        LD HL,ANIM_FFLY
        LD DE,VFONT+$44*4
.one:   PUSH BC
        ADD HL,BC
        ADD HL,BC
        CALL VZ_PUT2X2
        POP BC
        RET

; magic wall (Spectrum 6EBC / 6EC2)
VZ_MAGICOFF:
        LD HL,BRICK16
        LD DE,VFONT+$02*4
        JP VZ_PUT2X2

VZ_MAGICON:
        CALL L_6120                 ; hum
        AND $07
        INC A
        LD C,A
        LD A,(LATCHV)
        LD D,$20
.s:     LD B,C
        XOR $21
        LD (LATCH),A
.d:     DJNZ .d
        EX AF,AF'
        CALL EIFS
        EX AF,AF'
        DEC D
        JP NZ,.s
        LD A,(D_5B98)
        AND $18
        LD C,A
        LD B,0
        LD HL,ANIM_MAGIC
        ADD HL,BC
        ADD HL,BC
        LD DE,VFONT+$02*4
        JP VZ_PUT2X2

; cave reveal: noise and rotating cover pattern (Spectrum 6C46)
VZ_REVEALANIM:
        BIT 0,(IY+$15)
        RET Z
        CALL L_6120
        AND $1F
        OR $02
        LD C,A
        LD D,$20
        LD A,(LATCHV)
.s:     LD B,C
        XOR $21
        LD (LATCH),A
.d:     DJNZ .d
        EX AF,AF'
        CALL EIFS
        EX AF,AF'
        DEC D
        JP NZ,.s
        LD HL,VFONT+$5C*4           ; rotate the 4 pattern bytes
        LD A,(HL)
        INC L
        LD B,(HL)
        DEC L
        LD (HL),B
        INC L
        INC L
        LD B,(HL)
        DEC L
        LD (HL),B
        INC L
        INC L
        LD B,(HL)
        DEC L
        LD (HL),B
        INC L
        LD (HL),A
        LD A,1
        LD (GDIRTY+$5C),A
        RET

; bonus life: space sparkles (Spectrum 6996 / 696D)
VZ_SPARKLE:
        LD A,(D_5B71)
        CP $01
        JR NZ,.go
        CALL VZ_SPARKCLR
        JR .end
.go:    LD HL,VFONT+$40*4
        CALL .q
        LD HL,VFONT+$41*4
        CALL .q
        LD HL,VFONT+$50*4
        CALL .q
        LD HL,VFONT+$51*4
        CALL .q
        LD HL,GDIRTY+$40
        CALL .dirty
.end:   DEC (IY-$0F)
        RET
.q:     LD B,4
.ql:    CALL L_6120
        LD C,A
        CALL L_6120
        AND C
        AND C                       ; sparse bits
        AND $55
        LD C,A
        ADD A,A
        OR C                        ; pixel pairs 00/11
        XOR $AA                     ; on blue: 10 -> 01 yellow
        LD (HL),A
        INC HL
        DJNZ .ql
        RET
.dirty: LD (HL),1
        INC L
        LD (HL),1
        LD L,low(GDIRTY+$50)
        LD (HL),1
        INC L
        LD (HL),1
        RET

VZ_SPARKCLR:
        LD HL,VFONT+$40*4
        LD B,8
.a:     LD (HL),$AA
        INC HL
        DJNZ .a
        LD HL,VFONT+$50*4
        LD B,8
.b:     LD (HL),$AA
        INC HL
        DJNZ .b
        LD HL,GDIRTY+$40
        JR VZ_SPARKLE.dirty

; screen flash when the exit opens (Spectrum 6E73 flashed the border):
; the VZ toggles the CSS colour set for the same number of frames
VZ_FLASH:
        LD A,(D_5B3A)
        CP $00
        JR Z,.off
        DEC A
        LD (D_5B3A),A
        LD A,(LATCHV)
        BIT 3,A
        RET Z
        OR $10
        JR .set
.off:   LD A,(LATCHV)
        BIT 4,A
        RET Z
        AND $EF
.set:   LD (LATCHV),A
        LD (LATCH),A
        RET

; title logo shimmer step (Spectrum 69E1)
VZ_TITLEPHASE:
        LD HL,TITLEPHASE
        INC (HL)
        RET

; ---------------------------------------------------------------------------
; Sound routines: Spectrum OUT ($FE) bit 4 -> VZ latch bits 0 and 5
; ---------------------------------------------------------------------------
VZ_SND_642D:                        ; amoeba/falling rumble
        BIT 0,(IY+$3F)
        RET Z
        LD A,(IY-$5B)
        AND $03
        RET NZ
        CALL L_6120
        AND $0F
        OR $10
        LD C,A
        LD D,$20
        LD A,(LATCHV)
.s:     LD B,C
        XOR $21
        LD (LATCH),A
.d:     DJNZ .d
        EX AF,AF'
        CALL EIFS
        EX AF,AF'
        DEC D
        JP NZ,.s
        RET

VZ_SND_6531:                        ; falling tone
        LD A,(LATCHV)
        LD C,$20
        LD D,C
.s:     XOR $21
        LD (LATCH),A
        INC C
        INC C
        LD B,C
.d:     DJNZ .d
        EX AF,AF'
        CALL EIFS
        EX AF,AF'
        DEC D
        JP NZ,.s
        RET

VZ_SND_6544:                        ; cave timer: out of time / warning beeps
        LD A,$00
        CP (IY-$0C)
        RET NZ
        CP (IY-$0B)
        RET NZ
        CP (IY-$0A)
        JP NZ,.beep
        LD (IY-$57),$01
        RET
.beep:  LD A,(IY-$0A)
        CPL
        ADD A,$30
        LD C,A
        LD A,(LATCHV)
        LD D,$20
.s:     LD B,C
        XOR $21
        LD (LATCH),A
.d:     DJNZ .d
        EX AF,AF'
        CALL EIFS
        EX AF,AF'
        DEC D
        JP NZ,.s
        RET

VZ_SND_666D:                        ; diamond collected
        PUSH DE
        CALL L_64F0
        CALL L_65E7
        CALL L_6600
        CALL L_6633
        LD D,$40
        LD A,(LATCHV)
        LD C,$20
.s:     LD B,C
        XOR $21
        LD (LATCH),A
.d:     DJNZ .d
        EX AF,AF'
        CALL EIFS
        EX AF,AF'
        DEC D
        JP NZ,.s
        POP DE
        JP L_6668

VZ_SND_668F:                        ; digging noise (plays code bytes as noise)
        LD A,(LATCHV)
        AND $DE
        LD C,A
        LD D,$02
.s:     LD A,(HL)
        AND $21
        OR C
        LD (LATCH),A
        INC L
        JP NZ,.s
        INC H
        EX AF,AF'
        CALL EIFS
        EX AF,AF'
        DEC D
        JP NZ,.s
        JP L_6668

VZ_SND_66A2:                        ; step into space: click
        LD A,(LATCHV)
        XOR $21
        LD (LATCHV),A
        LD (LATCH),A
        JP L_6668

VZ_SND_6E89:                        ; per-tick effects (Spectrum 6E89)
        LD A,(DEATHF)               ; Rockford exploded this tick?
        OR A
        JR Z,.n0
        XOR A
        LD (DEATHF),A
        LD (THUDF),A
        CALL VZ_DEATHSND
        JR .end
.n0:    BIT 0,(IY+$42)              ; diamond landed: random chime
        JR Z,.n1
        CALL L_6120
        AND $1F
        ADD A,$10
        JR .play
.n1:    BIT 0,(IY+$43)              ; explosion / boulder push: buzz
        JR Z,.n2
        LD A,$C0
.play:  LD C,A
        LD A,(LATCHV)
        LD D,$20
.s:     LD B,C
        XOR $21
        LD (LATCH),A
.d:     DJNZ .d
        EX AF,AF'
        CALL EIFS
        EX AF,AF'
        DEC D
        JP NZ,.s
        JR .end
.n2:    LD A,(THUDF)                ; boulder landed: thud
        OR A
        CALL NZ,VZ_THUD
.end:   XOR A
        LD (THUDF),A
        LD (IY+$43),A
        LD (IY+$42),A
        RET

; boulder landing "thud": a short noise click then a falling low pulse
; (about 12 ms in total - shorter than the 22 ms buzz it replaces)
VZ_THUD:
        LD A,(LATCHV)
        LD E,A
        LD B,12                     ; noise click
.nz:    PUSH BC
        CALL L_6120
        AND $1F
        INC A
        LD B,A
.nd:    DJNZ .nd
        LD A,E
        XOR $21
        LD E,A
        LD (LATCH),A
        POP BC
        DJNZ .nz
        LD HL,THUDTAB
.p:     LD C,(HL)                   ; half period in 26 T units
        INC HL
        LD B,(HL)
        INC HL
        LD A,B
        OR C
        JR Z,.done
        LD A,E
        XOR $21
        LD E,A
        LD (LATCH),A
.w:     DEC BC
        LD A,B
        OR C
        JR NZ,.w
        JR .p
.done:  LD A,E
        LD (LATCHV),A
        RET
THUDTAB:
        DEFW 150,210,290,385,500,0

; set by the falling-boulder handler when it lands (Spectrum 6967 CALL 628B)
VZ_THUDFLAG:
        LD A,1
        LD (THUDF),A
        RET

; explosion of one cell (Spectrum 614F); notes when Rockford is caught in it
VZ_614F:
        LD HL,(D_5B04)
        LD D,$00
        ADD HL,DE
        LD A,(HL)
        AND $FE
        CP $38                      ; Rockford (38/39)?
        JR NZ,.nr
        LD A,1
        LD (DEATHF),A
.nr:    LD A,(HL)
        CP $07
        RET Z
        LD A,(D_5B16)
        JP L_60BA

; Rockford's death: a 1-bit spoken "Oww!" running into a decaying explosion
VZ_DEATHSND:
        DI
        LD A,(LATCHV)
        AND $DE
        LD B,A                      ; mode bits, speaker bits clear
        LD HL,OWW_SAMPLE
.byte:  LD E,(HL)
        INC HL
        LD D,8
.bit:   RL E                        ; 317 T per sample = 11189 Hz
        SBC A,A
        AND $21
        XOR $01                     ; bit 1 -> $20, bit 0 -> $01
        OR B
        LD (LATCH),A
        LD C,16
.dl:    DEC C
        JR NZ,.dl
        DEC D
        JR NZ,.bit
        LD A,L
        CP low(OWW_END)
        JR NZ,.byte
        LD A,H
        CP high(OWW_END)
        JR NZ,.byte
        CALL EIFS
        ; explosion: random toggles with gaps growing from short to long
        LD A,(LATCHV)
        LD E,A
        LD D,4                      ; base gap
        LD C,0
.ex:    CALL L_6120
        AND $0F
        ADD A,D
        LD B,A
.eg:    DJNZ .eg
        LD A,E
        XOR $21
        LD E,A
        LD (LATCH),A
        INC C
        BIT 0,C
        JR NZ,.ex
        INC D                       ; every second toggle the gap grows
        LD A,D
        CP 240
        JR NZ,.ex
        LD A,E
        LD (LATCHV),A
        JP EIFS

VZ_SND_79A8:                        ; bonus countdown tick
        LD A,(D_5BB5)
        CPL
        AND $7F
        LD B,A
        LD C,B
        LD A,(LATCHV)
        LD D,$40
.s:     XOR $21
        LD (LATCH),A
.d:     DJNZ .d
        LD B,C
        EX AF,AF'
        CALL EIFS
        EX AF,AF'
        DEC D
        JP NZ,.s
        LD B,$80
.e:     DJNZ .e
        RET

; Spectrum ROM BEEPER replacement: DE = number of cycles, HL = pitch value
; (half period = 4*(HL+30) T-states on the Spectrum).  Loop = 26 T per count.
VZ_BEEPER:
        DI
        PUSH IX
        LD BC,30
        ADD HL,BC
        LD B,H
        LD C,L
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        OR A
        SBC HL,BC                   ; *15
        LD A,L
        RLA                         ; >>7 : take H:L bit 7
        LD L,H
        LD H,0
        RL L
        RL H
        LD A,H
        OR L
        JR NZ,.ok
        INC L
.ok:    PUSH HL
        POP IX                      ; IX = half-period count
        LD A,D
        OR E
        JR Z,.done
        LD A,(LATCHV)
.cyc:   XOR $21
        LD (LATCH),A
        PUSH IX
        POP BC
.h1:    DEC BC
        LD H,A
        LD A,B
        OR C
        LD A,H
        JR NZ,.h1
        XOR $21
        LD (LATCH),A
        PUSH IX
        POP BC
.h2:    DEC BC
        LD H,A
        LD A,B
        OR C
        LD A,H
        JR NZ,.h2
        DEC DE
        LD H,A
        LD A,D
        OR E
        LD A,H
        JR NZ,.cyc
.done:  POP IX
        JP EIFS

; ---------------------------------------------------------------------------
; Keyboard and joystick (Spectrum 7CEE, 7D06, 7E16)
;   VZ keyboard rows: $68FE R Q E W T | $68FD F A D CTRL S G |
;   $68FB V Z C SHIFT X B | $68F7 4 1 3 2 5 | $68EF M SPACE , . N |
;   $68DF 7 0 8 - 9 6 | $68BF U P I RET O Y | $687F J ; K : L H
; ---------------------------------------------------------------------------
VZ_KEYCMD:                          ; -> D_5BCC (command key code)
        LD HL,KEYTAB1
.l:     LD A,(HL)
        OR A
        RET Z
        LD E,A
        LD D,$68
        INC HL
        LD A,(DE)
        AND (HL)
        INC HL
        JR NZ,.n
        LD A,(HL)
        LD (D_5BCC),A
        RET
.n:     INC HL
        JR .l

VZ_KEYCMD2:                         ; -> D_5BCD (P = players, R = reset)
        LD A,$00
        LD (D_5BCD),A
        LD HL,KEYTAB2
.l:     LD A,(HL)
        OR A
        RET Z
        LD E,A
        LD D,$68
        INC HL
        LD A,(DE)
        AND (HL)
        INC HL
        JR NZ,.n
        LD A,(HL)
        LD (D_5BCD),A
        RET
.n:     INC HL
        JR .l

; row low byte, bit mask, code
KEYTAB1:
        DEFB $EF,$10,$21            ; SPACE  pause
        DEFB $FB,$02,$1C            ; X      quit cave
        DEFB $F7,$10,$31            ; 1
        DEFB $F7,$02,$32            ; 2
        DEFB $F7,$08,$33            ; 3
        DEFB $F7,$20,$34            ; 4
        DEFB $F7,$01,$35            ; 5
        DEFB $DF,$01,$36            ; 6
        DEFB 0
KEYTAB2:
        DEFB $BF,$10,$03            ; P      number of players
        DEFB $FE,$20,$06            ; R      reset game
        DEFB 0

; directions -> D_5BCE (active-low: b0 up, b1 down, b2 left, b3 right)
; fire -> D_5BD0 (0 = pressed).  Control type 0 = joystick (+keys), 1 = keys
VZ_JOYKEYS:
        LD A,(D_5BD5)
        OR A
        JR NZ,.keys
        IN A,($2C)                  ; joystick 1 (directions + fire/arm)
        LD B,A
        IN A,($29)                  ; joystick 2 (directions, with arm-select low)
        AND B
        LD B,A
        IN A,($23)                  ; joystick 2 (directions + fire/arm)
        AND B
        LD B,A
        OR $F0
        LD HL,D_5BCE
        AND (HL)
        LD (HL),A
        BIT 4,B
        JR NZ,.keys
        XOR A
        LD (D_5BD0),A
.keys:  LD HL,D_5BCE
        LD A,($68FE)                ; Q = up
        AND $10
        JR NZ,.k1
        RES 0,(HL)
.k1:    LD A,($68FD)                ; A = down
        AND $10
        JR NZ,.k2
        RES 1,(HL)
.k2:    LD A,($68EF)                ; M = left, ',' = right, '.' = fire
        LD B,A
        AND $20
        JR NZ,.k3
        RES 2,(HL)
.k3:    LD A,B
        AND $08
        JR NZ,.k4
        RES 3,(HL)
.k4:    LD A,B
        AND $02
        RET NZ
        XOR A
        LD (D_5BD0),A
        RET

; ---------------------------------------------------------------------------
; Text-mode screens.  Game text uses '@' ($40) for space.
; ---------------------------------------------------------------------------
; convert game character A to a 6847 character code
VZ_CHR:
        CP $40
        JR Z,.sp
        CP $60
        JR NC,.sp
        CP $20
        JR C,.sp
        AND $3F
        RET
.sp:    LD A,$20
        RET

; copy B rows of 32 game characters from HL to VRAM at DE
VZ_TEXTROWS:
.r:     PUSH BC
        LD B,32
.c:     LD A,(HL)
        CALL VZ_CHR
        LD (DE),A
        INC HL
        INC DE
        DJNZ .c
        POP BC
        DJNZ .r
        RET

; joystick/help screen (Spectrum 800B): 16 rows of the text buffer
VZ_HELPSCREEN:
        XOR A
        LD (TITLEUP),A
        CALL VZ_TEXTMODE
        LD HL,CELLMAP+$10
        LD DE,VRAM
        LD B,16
        JP VZ_TEXTROWS

; ---------------------------------------------------------------------------
; Title screen (Spectrum 801E), text/SG4 mode, 32x16:
;   rows 0-9   stationary BOULDER DASH logo on a black plate, over an
;              expanding "diamond tunnel" (SG4 rings that move outward one
;              block per update; only the 117 background cells are rewritten,
;              each from a 256-byte lookup table: about 9,000 T per update)
;   row 10     colour divider
;   rows 11-15 the game's own title text (credits / scores, players and
;              control type, cave and level) or the First Star banner
; Called once per title-loop step (about 8 times a second).
; ---------------------------------------------------------------------------
VZ_TITLESCREEN:
        CALL VZ_TEXTMODE
        LD A,(TITLEUP)
        OR A
        JR NZ,.anim
        ; first call since another screen: draw the static parts
        LD HL,TT_LOGO
        LD DE,VRAM
        LD BC,10*32
        LDIR
        LD HL,TT_DIV
        LD BC,32
        LDIR
        LD A,1
        LD (TITLEUP),A              ; the interrupt animates the background now
.anim:
.panel: ; lower panel: First Star banner or the game's text rows 0-4
        LD DE,VRAM+11*32
        BIT 0,(IY-$48)
        JR Z,.txt
        LD HL,FIRSTSTAR
        LD BC,5*32
        LDIR
        RET
.txt:   LD HL,CELLMAP
        LD B,5
        CALL VZ_TEXTROWS
        ; "PRESS FIRE TO PLAY" (row 2 of the text) blinks in inverse video
        LD A,(CELLMAP+64+7)
        CP 'P'
        RET NZ
        LD A,(CELLMAP+64+8)
        CP 'R'
        RET NZ
        LD A,(FRAMES)
        AND $20
        RET Z
        LD HL,VRAM+13*32
        LD B,32
.inv:   LD A,(HL)
        CP $20
        JR Z,.ni
        OR $40
        LD (HL),A
.ni:    INC HL
        DJNZ .inv
        RET

VZ_TITLEBG:                         ; background rings move outward (from the ISR)
        LD A,(TPHASE)
        INC A
        LD (TPHASE),A
        AND 63
        LD C,A
        LD HL,TT_BGL
.bg:    LD E,(HL)
        INC HL
        LD D,(HL)
        INC HL
        LD A,D
        OR A
        RET Z
        LD A,(HL)                   ; type<<6 | ring distance
        INC HL
        LD B,A
        SUB C
        XOR B
        AND 63
        XOR B                       ; = type<<6 | ((dist - phase) & 63)
        PUSH HL
        LD L,A
        LD H,high(TT_PAT)
        LD A,(HL)
        LD (DE),A
        POP HL
        JR .bg

; ---------------------------------------------------------------------------
; VZ variables
; ---------------------------------------------------------------------------
LATCHV:         DEFB $09
FRAMES:         DEFW 0
PACENEXT:       DEFW 0
SCANNED:        DEFB 0
FIELDDONE:      DEFB 0
DEATHF:         DEFB 0
THUDF:          DEFB 0
TITLEPHASE:     DEFB 0
TITLEUP:        DEFB 0
TPHASE:         DEFB 0
TBGCNT:         DEFB 4
STATSHADOW:     DEFS 32,$FF

        INCLUDE "vz_title.asm"
        INCLUDE "vz_title2.asm"
        INCLUDE "vz_gfx.asm"
