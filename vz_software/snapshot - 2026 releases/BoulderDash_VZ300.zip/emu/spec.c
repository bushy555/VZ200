// Minimal 48K Spectrum harness for reverse engineering Boulder Dash.
// usage: spec entry.bin script outprefix
// script lines:
//   key F0 F1 KEYS   hold keys (chars, 'SS'=symbol shift as '$', 'CS' as '^', ' ' as '_', ENTER as '!') frames F0..F1-1
//   shot F           write outprefix_F.ppm at frame F
//   mem F            write outprefix_F.mem (64K)
//   end F            stop at frame F
//   brk ADDR         log first 20 hits of PC==ADDR with regs
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "z80.h"

static uint8_t mem[65536];
static uint8_t mapx[65536];
static unsigned long frame_no;
static int keys[8]; // active-low bits set when pressed (1=pressed)
static unsigned long beeps[1<<20];
static int border;
static int lastfe;
static unsigned long fe_toggles;

static z80* gz; static int contend=0; static unsigned long fstart=0;
static void cont(uint16_t a){ if(!contend||(a&0xc000)!=0x4000) return; long t=(long)(gz->cyc-fstart)-14335; if(t<0||t>=192*224) return; int p=t%224; if(p>=128) return; static const int d[8]={6,5,4,3,2,1,0,0}; gz->cyc+=d[p&7]; }
static uint8_t rd(void* u, uint16_t a){ mapx[a]|=2; cont(a); return mem[a]; }
static void wr(void* u, uint16_t a, uint8_t v){ cont(a); if(a<0x4000) return; mapx[a]|=4; mem[a]=v; }
static uint8_t pin(z80* z, uint16_t port){
  if((port&1)==0){
    uint8_t hi=port>>8, v=0x1f;
    for(int r=0;r<8;r++) if(!(hi&(1<<r))) v&=~keys[r];
    return v|0xa0;
  }
  if((port&0xff)==0x1f) return 0; // kempston
  return 0xff;
}
static void pout(z80* z, uint16_t port, uint8_t v){
  if((port&1)==0){ border=v&7; if((v^lastfe)&0x10) fe_toggles++; lastfe=v; }
}
// key matrix
static const char* rows[8]={"^ZXCV","ASDFG","QWERT","12345","09876","POIUY","!LKJH","_$MNB"};
static void setkeys(const char* s){
  memset(keys,0,sizeof keys);
  for(;*s;s++){ char c=*s; if(c>='a'&&c<='z') c-=32;
    for(int r=0;r<8;r++){ const char* p=strchr(rows[r],c); if(p&&c){ keys[r]|=1<<(p-rows[r]); } } }
}
static void shot(const char* pre, unsigned long f){
  char fn[256]; sprintf(fn,"%s_%05lu.ppm",pre,f);
  FILE* o=fopen(fn,"wb"); fprintf(o,"P6 256 192 255\n");
  static const uint8_t pal[16][3]={{0,0,0},{0,0,205},{205,0,0},{205,0,205},{0,205,0},{0,205,205},{205,205,0},{205,205,205},
   {0,0,0},{0,0,255},{255,0,0},{255,0,255},{0,255,0},{0,255,255},{255,255,0},{255,255,255}};
  for(int y=0;y<192;y++) for(int x=0;x<256;x++){
    int a=0x4000|((y&0xc0)<<5)|((y&7)<<8)|((y&0x38)<<2)|(x>>3);
    int at=mem[0x5800+(y>>3)*32+(x>>3)];
    int bit=(mem[a]>>(7-(x&7)))&1;
    int ink=(at&7)|((at&64)>>3), pap=((at>>3)&7)|((at&64)>>3);
    const uint8_t* c=pal[bit?ink:pap]; fwrite(c,1,3,o);
  }
  fclose(o);
}
typedef struct { int type; unsigned long a,b; char k[32]; } cmd;
static unsigned rngfix=0, rng=1, rngs[8192]; static unsigned long tickno=0; static int born=0; static unsigned tickaddr=0x70FA, celladdr=0xF790; static FILE* cellf=0;
static void applytick(cmd* c,int n);
static const char* tkmap[5][2]={{"U","7"},{"D","6"},{"L","5"},{"R","8"},{"F","0"}};
static void tkeys(const char* d, char* out){ out[0]=0; for(;*d;d++) for(int i=0;i<5;i++) if(tkmap[i][0][0]==*d) strcat(out,tkmap[i][1]); }
static void addkeys(const char* s){ int save[8]; memcpy(save,keys,sizeof keys); setkeys(s); for(int r=0;r<8;r++) keys[r]|=save[r]; }
static void applytick(cmd* c,int n){ for(int i=0;i<n;i++) if(c[i].type==5 && tickno>=c[i].a && tickno<c[i].b){ char t[64]; tkeys(c[i].k,t); addkeys(t);} }
int main(int argc,char**argv){
  if(getenv("RNGFIX")) rngfix=strtol(getenv("RNGFIX"),0,16); if(getenv("TICK")) tickaddr=strtol(getenv("TICK"),0,16); if(getenv("CELLS")) cellf=fopen(getenv("CELLS"),"wb");
  FILE* f=fopen("/tmp/skoolkit/skoolkit/resources/48.rom","rb"); fread(mem,1,16384,f); fclose(f);
  f=fopen(argv[1],"rb"); fread(mem+16384,1,49152,f); fclose(f);
  // entry.bin is full 64K: reload
  f=fopen(argv[1],"rb"); fseek(f,16384,SEEK_SET); fread(mem+16384,1,49152,f); fclose(f);
  cmd cmds[4096]; int nc=0;
  f=fopen(argv[2],"r"); char line[256];
  unsigned brk[16]; int nbrk=0; int brkhits[16]={0};
  unsigned long endf=1000;
  while(fgets(line,256,f)){
    cmd c={0}; char w[16];
    if(sscanf(line,"%15s",w)!=1) continue;
    if(!strcmp(w,"key")){ c.type=1; sscanf(line,"%*s %lu %lu %31s",&c.a,&c.b,c.k); }
    else if(!strcmp(w,"shot")){ c.type=2; sscanf(line,"%*s %lu",&c.a); }
    else if(!strcmp(w,"mem")){ c.type=3; sscanf(line,"%*s %lu",&c.a); }
    else if(!strcmp(w,"end")){ sscanf(line,"%*s %lu",&endf); continue; }
    else if(!strcmp(w,"tkey")){ c.type=5; sscanf(line,"%*s %lu %lu %31s",&c.a,&c.b,c.k); }
    else if(!strcmp(w,"brk")){ sscanf(line,"%*s %x",&brk[nbrk++]); continue; }
    else continue;
    cmds[nc++]=c;
  }
  fclose(f);
  z80 z; z80_init(&z); gz=&z; if(getenv("CONTEND")) contend=1;
  z.read_byte=rd; z.write_byte=wr; z.port_in=pin; z.port_out=pout;
  z.pc= argc>4? strtol(argv[4],0,16):0x7cc1; z.sp=0xff57; z.iy=0x5c3a; z.ix=0xffff; z.i=0x3f; z.interrupt_mode=1; z.iff1=z.iff2=1;
  unsigned long T=0, nextint=69888;
  for(frame_no=0; frame_no<endf; ){
    if(z.cyc>=nextint){
      z80_gen_int(&z,0xff); fstart=nextint; nextint+=69888; frame_no++;
      setkeys(""); applytick(cmds,nc);
      for(int i=0;i<nc;i++){
        if(cmds[i].type==1 && frame_no>=cmds[i].a && frame_no<cmds[i].b){ char tmp[32]; strcpy(tmp,cmds[i].k);
          // accumulate
          int save[8]; memcpy(save,keys,sizeof keys); setkeys(tmp); for(int r=0;r<8;r++) keys[r]|=save[r]; }
        if(cmds[i].type==2 && frame_no==cmds[i].a) shot(argv[3],frame_no);
        if(cmds[i].type==3 && frame_no==cmds[i].a){ char fn[256]; sprintf(fn,"%s_%05lu.mem",argv[3],frame_no); FILE*o=fopen(fn,"wb"); fwrite(mem,1,65536,o); fclose(o);}
      }
    }
    unsigned long c0=z.cyc;
    mapx[z.pc]|=1;
    for(int i=0;i<nbrk;i++) if(z.pc==brk[i] && brkhits[i]<200000){ brkhits[i]++;
      printf("brk %04x T=%lu f=%lu t=%lu A=%02x BC=%02x%02x DE=%02x%02x HL=%02x%02x IX=%04x IY=%04x SP=%04x\n",z.pc,z.cyc,frame_no,z.cyc-fstart,z.a,z.b,z.c,z.d,z.e,z.h,z.l,z.ix,z.iy,z.sp); }
    if(rngfix && z.pc==rngfix){ uint16_t ra=mem[z.sp]|mem[z.sp+1]<<8; unsigned *st=&rngs[ra&0x1fff]; *st=*st*1103515245u+12345u; z.a=(*st>>16)&0xff; z.sp+=2; z.pc=ra; continue; }
    if(z.pc==tickaddr){ if(!born){ for(int q=0;q<960;q++) if((mem[celladdr+q]&0xFE)==0x38) born=1; } if(born) tickno++; if(cellf&&(born||getenv("ALLTICKS"))) fwrite(mem+celladdr,1,960,cellf); memset(keys,0,sizeof keys); applytick(cmds,nc); }
    z80_step(&z);
    if(z.int_pending && z.cyc - (nextint-69888) > 40) z.int_pending=0;
  }
  char fn[256]; sprintf(fn,"%s.map",argv[3]); FILE*o=fopen(fn,"wb"); fwrite(mapx,1,65536,o); fclose(o);
  printf("done frames=%lu pc=%04x fe_toggles=%lu\n",frame_no,z.pc,fe_toggles);
}
