// VZ300 test harness: Z80 + MC6847 (PAL VZ timing per MAME vtech1/mc6847)
// usage: vz <binfile> <loadaddr> <startaddr> <script> <outprefix>
// script commands (frame based, 50Hz):
//   key F0 F1 KEYS   hold VZ keys (letters/digits; ' '=_ ; ','=, '.'=. RETURN=! CTRL=^ SHIFT=~)
//   joy F0 F1 BITS   joystick 1 active bits mask (1=up 2=down 4=left 8=right 16=fire)
//   shot F           write outprefix_F.ppm
//   mem F            write outprefix_F.mem
//   end F
//   brk ADDR         log hits
//   prof F0 F1       profile PC histogram between frames
//   bus V            data bus value during INTACK (default random)
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "z80.h"

#define TPL 227
#define LINES 312
#define TPF (TPL*LINES)
#define FSLOW 57          /* lines FS low after end of active video */
#define ACTIVE0 (57+63)   /* first active line */

static uint8_t mem[65536];
static uint8_t latch = 0;
static int keyrow[8];
static int joy1 = 0, joy2 = 0;
static unsigned long fstart = 0;
static z80 *gz;
static int ramtop = 0xF7FF;
static unsigned long spk_toggles = 0, spk_frame_toggles = 0;
static FILE *wavf = 0;
static unsigned long badwrites = 0;
static FILE *spkf = 0; static unsigned long long totcyc_base = 0;
static uint8_t frame_img[192][32];
static uint8_t frame_mode[192];
static unsigned long profile[65536];
static int profiling = 0; static unsigned long halt_cyc=0, isr_cyc=0, prof_cyc=0; static unsigned isr_lo=0, isr_hi=0;
static unsigned long irq_count = 0, irq_lost = 0;
static unsigned long int_retrigger = 0;

static int line_now(void) { return (int)((gz->cyc - fstart) / TPL); }
static int fs_high(void) { int l = line_now(); return !(l < FSLOW); }

static uint8_t rd(void *u, uint16_t a) {
  if (a >= 0x6800 && a < 0x7000) {
    uint8_t r = 0x3f;
    for (int i = 0; i < 8; i++) if (!(a & (1 << i))) r &= ~keyrow[i];
    r |= 0x40; // cassette in idle
    if (fs_high()) r |= 0x80;
    return r;
  }
  return mem[a];
}
static void wr(void *u, uint16_t a, uint8_t v) {
  if (a < 0x6800) { badwrites++; return; }
  if (a < 0x7000) {
    uint8_t old = latch; latch = v;
    if (((old ^ v) & 0x21)) { spk_toggles++; spk_frame_toggles++; if (spkf) { unsigned long long t = gz->cyc; int lvl = (v & 0x20 ? 2 : 0) | (v & 1); fwrite(&t, 8, 1, spkf); fwrite(&lvl, 4, 1, spkf); } }
    return;
  }
  if (a > ramtop) { badwrites++; return; }
  mem[a] = v;
}
static uint8_t pin(z80 *z, uint16_t port) {
  uint8_t p = port & 0xff;
  if (p >= 0x20 && p <= 0x2f) {
    uint8_t d = 0xff;
    if (!(p & 1)) d &= ~(joy1 & 0x1f);
    if (!(p & 2)) d &= ~(joy1 & 0x10);
    if (!(p & 4)) d &= ~(joy2 & 0x1f);
    if (!(p & 8)) d &= ~(joy2 & 0x10);
    return d;
  }
  return 0xff;
}
static void pout(z80 *z, uint16_t port, uint8_t v) {}

static const char *krows[8] = {"TW#EQR", "GS^DAF", "BX~CZV", "52#314", "N.#,_M", "69-807", "YO!IPU", "HL:K;J"};
// bit positions: index in string = bit number
static void setkeys(const char *s) {
  for (; *s; s++) {
    char c = *s; if (c >= 'a' && c <= 'z') c -= 32;
    for (int r = 0; r < 8; r++) { const char *p = strchr(krows[r], c); if (p && c != ' ') keyrow[r] |= 1 << (p - krows[r]); }
  }
}

// --- video ---
static const uint8_t cg_pal[2][4][3] = {
  {{0, 255, 0}, {255, 255, 0}, {0, 0, 255}, {255, 0, 0}},
  {{255, 255, 255}, {0, 255, 255}, {255, 0, 255}, {255, 128, 0}}};
static const uint8_t sg_pal[8][3] = {{0, 255, 0}, {255, 255, 0}, {0, 0, 255}, {255, 0, 0}, {255, 255, 255}, {0, 255, 255}, {255, 0, 255}, {255, 128, 0}};
static uint8_t spec_rom[16384];
static uint8_t linemode[192]; // latch at each active line
static uint8_t linedata[192][32];
static void capture_line(int l) { // l = active line 0..191
  linemode[l] = latch;
  int row;
  if (latch & 8) row = (l / 3) * 32; else row = (l / 12) * 32;
  memcpy(linedata[l], mem + 0x7000 + row, 32);
}
static void put(FILE *o, const uint8_t *c) { fwrite(c, 1, 3, o); }
static void shot(const char *pre, unsigned long f) {
  char fn[256]; sprintf(fn, "%s_%05lu.ppm", pre, f);
  FILE *o = fopen(fn, "wb"); fprintf(o, "P6 288 224 255\n");
  static const uint8_t black[3] = {0, 0, 0};
  for (int y = 0; y < 224; y++) {
    int l = y - 16;
    uint8_t m = (l >= 0 && l < 192) ? linemode[l] : linemode[l < 0 ? 0 : 191];
    const uint8_t *border = (m & 8) ? cg_pal[(m >> 4) & 1][0] : black;
    for (int x = 0; x < 288; x++) {
      int px = x - 16;
      if (l < 0 || l >= 192 || px < 0 || px >= 256) { put(o, border); continue; }
      if (m & 8) {
        uint8_t b = linedata[l][px >> 3];
        int pix = (b >> (6 - 2 * ((px >> 1) & 3))) & 3;
        put(o, cg_pal[(m >> 4) & 1][pix]);
      } else {
        uint8_t ch = linedata[l][px >> 3];
        int cy = l % 12, cx = px & 7;
        if (ch & 0x80) { // SG4
          int q = ((cy >= 6) ? 2 : 0) + ((cx >= 4) ? 0 : 1);
          int on = (ch >> q) & 1; // bit3=UL bit2=UR bit1=LL bit0=LR
          int bit = ((cy >= 6) ? 0 : 2) + ((cx >= 4) ? 0 : 1);
          on = (ch >> bit) & 1;
          put(o, on ? sg_pal[(ch >> 4) & 7] : black);
        } else {
          int code = ch & 0x3f; int ascii = code < 32 ? code + 64 : code;
          int on = 0;
          if (cy >= 3 && cy < 10) { // 7 rows of glyph from spectrum font rows 0..6
            uint8_t g = spec_rom[0x3d00 + (ascii - 32) * 8 + (cy - 3) + 1 - 1 + 0];
            g = spec_rom[0x3d00 + (ascii - 32) * 8 + (cy - 2)];
            on = (g >> (7 - cx)) & 1;
          }
          if (ch & 0x40) on = !on;
          static const uint8_t fg[3] = {0, 255, 0}, bg[3] = {0, 64, 0};
          put(o, on ? fg : bg);
        }
      }
    }
  }
  fclose(o);
}

typedef struct { int type; unsigned long a, b; char k[32]; } cmd;
static unsigned rngfix = 0, rng = 1, rngs[8192]; static unsigned long tickno = 0; static int born = 0; static unsigned tickaddr = 0x90FA, celladdr = 0xEA90; static FILE *cellf = 0;
static void applytick(cmd *c, int n);
static const char* tkmap[5][2]={{"U","Q"},{"D","A"},{"L","M"},{"R",","},{"F","."}};
static void tkeys(const char* d, char* out){ out[0]=0; for(;*d;d++) for(int i=0;i<5;i++) if(tkmap[i][0][0]==*d) strcat(out,tkmap[i][1]); }
static void applytick(cmd *c, int n) { for (int i = 0; i < n; i++) if (c[i].type == 5 && tickno >= c[i].a && tickno < c[i].b) { char t[64]; tkeys(c[i].k, t); setkeys(t); } }
int main(int argc, char **argv) {
  if (getenv("SPKLOG")) spkf = fopen(getenv("SPKLOG"), "wb"); if (getenv("ISR")) { sscanf(getenv("ISR"), "%x-%x", &isr_lo, &isr_hi); } if (getenv("RNGFIX")) rngfix = strtol(getenv("RNGFIX"), 0, 16); if (getenv("TICK")) tickaddr = strtol(getenv("TICK"), 0, 16); if (getenv("CELLS")) cellf = fopen(getenv("CELLS"), "wb");
  FILE *f = fopen("/tmp/skoolkit/skoolkit/resources/48.rom", "rb"); fread(spec_rom, 1, 16384, f); fclose(f);
  memset(mem, 0xff, 0x4000); // no ROM needed (IM2 used); 0xFF = RST 38
  f = fopen(argv[1], "rb"); int load = strtol(argv[2], 0, 16), start = strtol(argv[3], 0, 16);
  int n = fread(mem + load, 1, 65536 - load, f); fclose(f);
  fprintf(stderr, "loaded %d bytes at %04x\n", n, load);
  cmd cmds[8192]; int nc = 0; unsigned long endf = 1000; unsigned brk[16]; int nbrk = 0; unsigned long brkhits[16] = {0};
  int busval = -1; unsigned long pf0 = 0, pf1 = 0;
  f = fopen(argv[4], "r"); char line[256];
  while (fgets(line, 256, f)) {
    cmd c = {0}; char w[16];
    if (sscanf(line, "%15s", w) != 1) continue;
    if (!strcmp(w, "key")) { c.type = 1; sscanf(line, "%*s %lu %lu %31s", &c.a, &c.b, c.k); }
    else if (!strcmp(w, "joy2")) { c.type = 8; sscanf(line, "%*s %lu %lu %31s", &c.a, &c.b, c.k); }
    else if (!strcmp(w, "joy")) { c.type = 4; sscanf(line, "%*s %lu %lu %31s", &c.a, &c.b, c.k); }
    else if (!strcmp(w, "shot")) { c.type = 2; sscanf(line, "%*s %lu", &c.a); }
    else if (!strcmp(w, "mem")) { c.type = 3; sscanf(line, "%*s %lu", &c.a); }
    else if (!strcmp(w, "end")) { sscanf(line, "%*s %lu", &endf); continue; }
    else if (!strcmp(w, "exit")) { c.type = 6; sscanf(line, "%*s %lu", &c.a); }
    else if (!strcmp(w, "poke")) { c.type = 7; sscanf(line, "%*s %lu %lx %lx", &c.a, &c.b, (unsigned long*)&c.k); }
    else if (!strcmp(w, "tkey")) { c.type = 5; sscanf(line, "%*s %lu %lu %31s", &c.a, &c.b, c.k); }
    else if (!strcmp(w, "brk")) { sscanf(line, "%*s %x", &brk[nbrk++]); continue; }
    else if (!strcmp(w, "bus")) { sscanf(line, "%*s %x", &busval); continue; }
    else if (!strcmp(w, "prof")) { sscanf(line, "%*s %lu %lu", &pf0, &pf1); continue; }
    else continue;
    cmds[nc++] = c;
  }
  fclose(f);
  z80 z; z80_init(&z); gz = &z;
  z.read_byte = rd; z.write_byte = wr; z.port_in = pin; z.port_out = pout;
  z.pc = start; z.sp = 0x7a00;
  unsigned long frame = 0; fstart = 0; int lastline = -1;
  int int_taken_this_low = 0;
  srand(1);
  unsigned long isr_cycles_total = 0;
  while (frame < endf) {
    if (z.cyc - fstart >= TPF) {
      if (!int_taken_this_low && frame > 100) { irq_lost++; if (getenv("LOSTLOG")) fprintf(stderr, "lost f=%lu pc=%04x iff=%d\n", frame, z.pc, z.iff1); }
      fstart += TPF; frame++; lastline = -1; int_taken_this_low = 0;
      spk_frame_toggles = 0;
      memset(keyrow, 0, sizeof keyrow); joy1 = 0; joy2 = 0; applytick(cmds, nc);
      profiling = (frame >= pf0 && frame < pf1);
      for (int i = 0; i < nc; i++) {
        if (cmds[i].type == 1 && frame >= cmds[i].a && frame < cmds[i].b) setkeys(cmds[i].k);
        if (cmds[i].type == 4 && frame >= cmds[i].a && frame < cmds[i].b) joy1 |= atoi(cmds[i].k);
        if (cmds[i].type == 8 && frame >= cmds[i].a && frame < cmds[i].b) joy2 |= atoi(cmds[i].k);
        if (cmds[i].type == 2 && frame == cmds[i].a) shot(argv[5], frame);
        if (cmds[i].type == 6 && frame == cmds[i].a) { for (int q = 0; q < 960; q++) if ((mem[celladdr + q] & 0xFE) == 0x38) { mem[celladdr + q + 1] = 0x05; break; } }
        if (cmds[i].type == 7 && frame == cmds[i].a) mem[cmds[i].b] = *(unsigned long*)cmds[i].k;
        if (cmds[i].type == 3 && frame == cmds[i].a) { char fn[256]; sprintf(fn, "%s_%05lu.mem", argv[5], frame); FILE *o = fopen(fn, "wb"); fwrite(mem, 1, 65536, o); fclose(o); }
      }
    }
    int l = line_now();
    if (l != lastline) {
      for (int k = lastline + 1; k <= l; k++) if (k >= ACTIVE0 && k < ACTIVE0 + 192) capture_line(k - ACTIVE0);
      lastline = l;
    }
    // level-triggered INT while FS low
    if (!fs_high() && z.iff1 && !z.iff_delay) {
      z80_gen_int(&z, busval >= 0 ? busval : (rand() & 0xff));
      irq_count++; if (getenv("DBGF") && frame >= (unsigned long)atol(getenv("DBGF")) && frame <= (unsigned long)atol(getenv("DBGF"))+1) fprintf(stderr, "int f=%lu line=%d pc=%04x cyc=%lu\n", frame, line_now(), z.pc, z.cyc - fstart);
      if (int_taken_this_low) { int_retrigger++; if (getenv("LOSTLOG")) fprintf(stderr, "retrig f=%lu pc=%04x line=%d\n", frame, z.pc, line_now()); }
      int_taken_this_low = 1;
    }
    if (profiling) profile[z.pc]++;
    for (int i = 0; i < nbrk; i++) if (z.pc == brk[i] && brkhits[i] < 100000) { brkhits[i]++;
      printf("brk %04x T=%lu f=%lu l=%d A=%02x BC=%02x%02x DE=%02x%02x HL=%02x%02x IX=%04x IY=%04x SP=%04x\n", z.pc, z.cyc, frame, l, z.a, z.b, z.c, z.d, z.e, z.h, z.l, z.ix, z.iy, z.sp); }
    if (rngfix && z.pc == rngfix) { uint16_t ra = mem[z.sp] | mem[z.sp + 1] << 8; unsigned *st = &rngs[ra & 0x1fff]; *st = *st * 1103515245u + 12345u; z.a = (*st >> 16) & 0xff; z.sp += 2; z.pc = ra; continue; }
    if (z.pc == tickaddr) { if (!born) { for (int q = 0; q < 960; q++) if ((mem[celladdr + q] & 0xFE) == 0x38) born = 1; } if (born) tickno++; if (cellf && (born || getenv("ALLTICKS"))) fwrite(mem + celladdr, 1, 960, cellf); memset(keyrow, 0, sizeof keyrow); applytick(cmds, nc); }
    { unsigned long c0 = z.cyc; int h = z.halted; int inisr = (z.pc >= isr_lo && z.pc < isr_hi); z80_step(&z); if (profiling) { if (h) halt_cyc += z.cyc - c0; if (inisr) isr_cyc += z.cyc - c0; prof_cyc += z.cyc - c0; } }
    z.int_pending = 0;
  }
  if (pf1) printf("profile: halted %.1f%%  isr-wait-loop %.1f%%\n", 100.0*halt_cyc/prof_cyc, 100.0*isr_cyc/prof_cyc);
  if (pf1) {
    FILE *o = fopen("profile.txt", "w");
    for (int a = 0; a < 65536; a++) if (profile[a]) fprintf(o, "%04X %lu\n", a, profile[a]);
    fclose(o);
  }
  printf("done lost=%lu frames=%lu pc=%04x irqs=%lu retrig=%lu spk=%lu badwr=%lu\n", irq_lost, frame, z.pc, irq_count, int_retrigger, spk_toggles, badwrites);
}
