#!/bin/sh
set -e
cd "$(dirname "$0")"
python3 tools/vzgfx.py >/dev/null
python3 tools/vztitle.py >/dev/null
python3 tools/vztitle2.py >/dev/null
python3 tools/vzsfx.py >/dev/null
python3 tools/gen_vz.py
cd src && sjasmplus --nologo --msg=war --sym=bd_vz.sym --lst=bd_vz.lst bd_vz.asm && cd ..
python3 tools/mkvz.py src/bd_vz.bin out/BOULDER.VZ
python3 - <<'PY'
import re
syms=[]
for l in open('src/bd_vz.sym'):
    m=re.match(r'(\S+):\s+EQU\s+0x([0-9A-F]+)',l)
    if m: syms.append((int(m.group(2),16),m.group(1)))
syms.sort()
open('src/syms.txt','w').write('\n'.join(f'{a:04X} {n}' for a,n in syms))
PY
