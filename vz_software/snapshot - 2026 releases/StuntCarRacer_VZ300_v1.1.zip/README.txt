STUNT CAR RACER - VZ300 version 1.1
===================================
Original game (C) Geoff Crammond 1988/9; ZX Spectrum version by Pete Cooke.
This is a conversion of the ZX Spectrum game to the Dick Smith VZ300. The
original Spectrum game code (physics, tracks, opponents, rules, menus) runs
unchanged; only the screen, sound, keyboard and joystick routines are new.

Needs:  VZ300, BennVenn 128K RAM expansion, BennVenn SD loader.
Files:  copy all three to the same folder on the SD card, then run STUNTCAR.VZ
          STUNTCAR.VZ    loader (516 bytes)
          STUNTCR1.DAT   game data (22,281 bytes)
          STUNTCR2.DAT   game data (8,737 bytes)
        If a .DAT file is missing the screen shows "CAN'T OPEN STUNTCR1/2.DAT".

Controls (keyboard)
  S  accelerate        X  brake / reverse
  O  steer left        P  steer right
  M or SPACE  fire (boost while accelerating, select in menus)
  SHIFT+SPACE pause:  then Q = quit race, S = sound on/off, RETURN = resume
Joystick 1 or 2 work as well (up = accelerate, down = brake, fire = boost).

Notes
  Load/Save: there is no tape. Save keeps the season in memory and Load
  brings it back, for as long as the VZ stays switched on.

Changes in 1.1
  - About 9% more frames per second on average (5-12% depending on the
    track): faster polygon fill and horizon drawing, and faster versions of
    four of the original game's maths routines that give exactly the same
    results. Pictures and physics are unchanged.
  - Engine sound is the Spectrum's own (an extra VZ tone whose pitch fell
    as the revs rose has been removed).
  - The game now loads as a small loader plus two data files, read with the
    BennVenn DOS file calls, so it is no longer limited to one 31,200-byte
    file.

Memory use
  $4000-$67FF  DOS RAM bank 0: renderer, buffers, lookup tables (built at
               start-up), screen back buffer at $5B00
  $4000-$67FF  DOS RAM bank 1: start-up, title screen and music, menus, text
  $7000-$77FF  video RAM
  $7800-$B7FF  internal RAM: original game
  $B800-$FFFF  expansion bank 0: original game (with VZ driver code in the
               spaces left by replaced Spectrum routines)
  $B800-$FFFF  expansion bank 1: polygon fill and horizon code, bonnet art
               and boost flame graphics
Loading: STUNTCAR.VZ reads STUNTCR1.DAT (to $7B00 up) and STUNTCR2.DAT (to
DOS RAM bank 1) through the SD loader, then unpacks them (ZX0) into the
banks above.
