
Pitstop II preview.  Geronimus Vanden

Included are a top down version Claude came up with first and pseudo 3d 
version with rudimentary Aust. SHRG support that is being completely 
rewritten as it looks 'buns' according to my kids. 
Requires memory expansion for VZ200 but should run ok on VZ300 if anyone want to have a play.

