
Russell Harrisons XB - Extended Basic Source Code.
Grabbed as a 98k early disk image. Attempted to convert to VZEM 99k .DSK version.
Converted with DISKOPS4 and Mark Hardwood v6.0x version: sub-directories labelled as such.
Also using Extended DOS v1.3, EXT1.2, VZEM, WinVZ200 (2012 version), and a lot of luck.

Bad sector is causing file 'DISKIII' to be not copyable. 
Requires a complete re-read of original floppy disk.

Needs   : cleaning up.
Missing : DISKIII

CONVERT
DEFINE
DISKI
DISKII
DISKIII
DMSG
HELP
HIRES
LOOPS
LPEN
MC
SOUND
STRING
TEXT
XBI

DISKOPS source code           : 'W' file type. Starting address: A813.
Mark Hardwood 6.0x source code: 'S' file type. Starting address: A280.
