#include <stdio.h>
#include <fcntl.h>
#include "vzfile.h"

struct vzfile vzf;
unsigned char data[40000];
int datalen;

char* tokens[] = {
    "END", "FOR", "RESET", "SET", "CLS", "", "", "NEXT", "DATA", "INPUT",
    "DIM", "READ", "LET", "GOTO", "RUN", "IF", "RESTORE", "GOSUB",
    "RETURN", "REM", "STOP", "ELSE", "COPY", "COLOR", "VERIFY", "", "",
    "", "CRUN", "MODE", "SOUND", "", "OUT", "", "", "", "", "", "", "",
    "", "", "", "", "", "", "", "LPRINT", "", "POKE", "PRINT", "CONT",
    "LIST", "LLIST", "", "", "CLEAR", "CLOAD", "CSAVE", "NEW", "TAB(",
    "TO", "", "USING", "", "USR", "", "", "", "", "POINT", "", "",
    "INKEY$", "THEN", "NOT", "STEP", "+", "-", "*", "/", "^", "AND", "OR",
    ">", "=", "<", "SGN", "INT", "ABS", "", "INP", "", "SQR", "RND",
    "LOG", "EXP", "COS", "SIN", "TAN", "ATN", "PEEK", "", "", "", "", "",
    "", "", "", "", "", "", "", "", "LEN", "STR$", "VAL", "ASC", "CHR$",
    "LEFT$", "RIGHT$", "MID$", "", "", "", "", ""
};

void
setinv(int i)
{
    static int lasti = 0;

    if (i == lasti)
	return;
    lasti = i;

    /*printf(i ? "\033[1;7m" : "\033[m");*/
}

int
main(int argc, char* argv[])
{
    int f;
    unsigned char* ptr;
    unsigned short startaddr, nextaddr, lineno;
    unsigned char ch;
    int inquote;

    if (argc != 2) {
	fprintf(stderr, "Usage: %s <files..>\n", argv[0]);
	exit();
    }

    f = open(argv[1], O_RDONLY);
    if (f < 0) {
	perror(argv[1]);
	exit(1);
    }

    if (read(f, &vzf, sizeof(vzf)) < sizeof(vzf)) {
	fprintf(stderr, "%s: too short\n", argv[1]);
	exit(1);
    }

    if (vzf.vzf_magic != VZF_MAGIC) {
	fprintf(stderr, "%s: not a VZ file\n", argv[1]);
	exit(1);
    }

    datalen = read(f, data, sizeof(data));
    if (datalen <= 0) {
	perror("read data");
	exit(1);
    }

    startaddr = vzf.vzf_startaddr_l + (vzf.vzf_startaddr_h << 8);
    printf("REM \"%s\" START %04X LEN %04X\n",
	vzf.vzf_filename, startaddr, datalen);

    ptr = data;

    for (;;) {
	nextaddr = ptr[0] + (ptr[1] << 8);
	ptr += 2;
	if (nextaddr == 0)
	    break;

	lineno = ptr[0] + (ptr[1] << 8);
	ptr += 2;
	inquote = 0;

	printf("%d ", lineno);
	while ((ch = *ptr++)) {
	    if (ch == '\"') {
		inquote = !inquote;
		setinv(0);
	    }

	    if (ch < 0x80) {
		setinv(0);
		putchar(ch);
	    } else if (inquote) {
		setinv(1);
		if (ch < 0xc0)
		    putchar('~');
		else if (ch < 0xe0)
		    putchar(ch - 0x80);
		else
		    putchar(ch - 0xc0);
	    } else
		fputs(tokens[ch - 0x80], stdout);
	}

	putchar('\n');
	if (ptr - data + startaddr != nextaddr) {
	    printf("REM nextaddr is %04x, should be %04x\n",
		nextaddr, ptr - data + startaddr);
	}
    }

    datalen -= (ptr - data);
    if (datalen > 0)
	printf("REM plus %d bytes of trailing data\n", datalen);
}





