TEXT2BAS - freeware BASIC tokenizer

This software is free for any use. The author cannot be held
responsible for any problems it might cause, in no case. If
you don't understand or accept this, delete text2bas immediately.

Purpose:
  TEXT2BAS was written to allow easier importing of BASIC code written
  on a PC into my Colour Genie emulation(s). It now supports (sort of)
  the VZ200 / VZ300 computers token set.
  The set is not verified, so there might be some wrong tokens in
  the list! Please report any irregularities. Thanks ;)

Operation:
  text2bas [options] program[.txt] [output[.vz]]
  source is the filename of a BASIC language program.

Regards,

Juergen Buchmueller <pullmoll@t-online.de>



