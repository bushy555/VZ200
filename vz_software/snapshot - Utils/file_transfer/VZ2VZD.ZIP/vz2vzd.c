#include <stdio.h>
#include <string.h>

static int sector_sequence[] = {0,11,6,1,12,7,2,13,8,3,14,9,4,15,10,5};

int main(int ac, char **av)
{
	char srcdir[128] = ".";
	char dstdir[128] = ".";
	char diskname[128] = "disk.vzd";
	char filename[128];
    FILE *fi, *fo;
	int t, t0;

	if( ac > 1 )
		strcpy(srcdir, av[1]);

	if( ac > 2 )
		strcpy(dstdir, av[2]);

	if( ac > 3 )
		strcpy(diskname, av[3]);

    printf("converting %s/trk[x-y].vz to %s/%s\n", srcdir, dstdir, diskname);

	sprintf(filename, "%s/%s", dstdir, diskname);
	fo = fopen(filename, "wb");
	for( t0 = 0, t = 0; t0 < 40; t0 += 8 )
	{
		unsigned char track[128*16];

		sprintf(filename, "%s/trk%d-%d.vz", srcdir, t, t+7);
		fi = fopen(filename, "rb");
		if( !fi )
		{
			fprintf(stderr, "cannot open %s for input!\n", filename);
			return 1;
		}

        /* skip the VZ header */
        fseek(fi, 24, SEEK_SET);

		/* read the track data */
		do
		{
			int i, o, s;
			unsigned char csum_byte;
			unsigned short csum_word;

			if( fread(track, 1, sizeof(track), fi) != sizeof(track) )
			{
				fprintf(stderr, "error reading track %d from %s!\n", t, filename);
				return 1;
            }

			/* convert 16 sectors */
            for( s = 0; s < 16; s++ )
			{
				fputc(0x80, fo);						/* offset 0x00 */
				fputc(0x80, fo);
				fputc(0x80, fo);
				fputc(0x80, fo);
				fputc(0x80, fo);
				fputc(0x80, fo);
				fputc(0x00, fo);						/* offset 0x06 */
				fputc(0xfe, fo);
				fputc(0xe7, fo);
				fputc(0x18, fo);
				fputc(0xc3, fo);

				csum_byte = 0;
                fputc(t, fo);                           /* offset 0x0b */
				/* checksum of track number */
				csum_byte += t;
				fputc(sector_sequence[s], fo);			/* offset 0x0c */
				/* plus sector number */
				csum_byte += sector_sequence[s];
				/* output checksum */
				fputc(csum_byte, fo);					/* offset 0x0d */

                fputc(0x80, fo);                        /* offset 0x0e */
				fputc(0x80, fo);
				fputc(0x80, fo);
				fputc(0x80, fo);
				fputc(0x80, fo);
				fputc(0x00, fo);						/* offset 0x13 */
                fputc(0xc3, fo);
                fputc(0x18, fo);
				fputc(0xe7, fo);
				fputc(0xfe, fo);

				o = sector_sequence[s] * 128;
				csum_word = 0;
				for( i = 0; i < 128; i++ )
				{
					fputc(track[o + i], fo);			/* offset 0x18..0x97 */
					/* checksum the sector data */
					csum_word = csum_word + track[o + i];
				}
                /* output the checksum */
				fputc(csum_word & 255, fo); 			/* offset 0x98 */
				fputc(csum_word / 256, fo); 			/* offset 0x99 */
            }

			/* next track */
            t++;
		} while( t < (t0 + 8) && !feof(fi) );
		fclose(fi);
	}
	fclose(fo);

    return 0;
}
