#include <stdio.h>
#include <stdlib.h>

#define SAMPLE_RATE 22050

typedef struct WAVEHDR
{
    char        RIFF[4];
    int         nFileLength;
    char        WAVE[4];
    char        type[4];
    int         nLength;
    short       nFormat;
    short       nChannels;
    int         nSampleRate;
    int         nByteRate;
    short       nBlockAlign;
    short       nBitsPerSample;
    char        DATA[4];
    int         dLength;
} HEADER;

int main(int nArgs, char *chArgs[])
{
    long   filelength;
    long   i,n,cntr = 0;
    int    frequency;
    int    duration;       
    int    wavelength;
    char   wb, *pb;
    HEADER wavHeader;
    FILE   *wavfile;
   
    printf("\n\n -= MAKEWAVE =-\n");
    printf("Usage: makewav wavfile.wav frequency duration\n\n");

    if (nArgs != 4)
    {
        printf("Error - wrong number of parameters\n");
        return 1;
    }

    frequency = strtol(chArgs[2], &pb, 0);
    if (*pb != NULL) 
    {
        printf("Error - frequency must be a valid integer\n");
        return 1;
    }
    
    duration = strtol(chArgs[3], &pb, 0);
    if (*pb != NULL) 
    {
        printf("Error - duration must be a valid integer\n");
        return 1;
    }
    
    wavelength = SAMPLE_RATE / frequency;
    filelength = frequency * duration * wavelength;      

    printf("creating WAV file....");
    if ((wavfile = fopen(chArgs[1],"wb")) == NULL)
    {
        printf("error creating wavfile\n");
        return 1;
    }

    printf("OK!\n");
    strcpy(wavHeader.RIFF, "RIFF");
    strcpy(wavHeader.WAVE, "WAVE");
    strcpy(wavHeader.type, "fmt ");
    strcpy(wavHeader.DATA, "data");

    wavHeader.nFileLength    = filelength + sizeof(HEADER) - 8;
    wavHeader.nLength        = 0x00000010;  // length of fmt data (16 bytes)
    wavHeader.nFormat        = 0x0001;      // PCM
    wavHeader.nChannels      = 0x0001;      // Mono
    wavHeader.nSampleRate    = SAMPLE_RATE;
    wavHeader.nByteRate      = SAMPLE_RATE;
    wavHeader.nBlockAlign    = 0x0001;
    wavHeader.nBitsPerSample = 0x0008;
    wavHeader.dLength        = filelength;

    
    printf("writing sound data...");
    fwrite(&wavHeader,sizeof(HEADER),1,wavfile);
    for (n = 0; n < frequency * duration; n++)
    {
      for (i=0; i<wavelength; i++)
      {
        if (i < (wavelength/2))
            wb = 255;
        else
            wb = 0;

        cntr++;
        fwrite(&wb,1,1,wavfile);
      }
    }
    printf("OK!\n");
    fclose(wavfile);
    printf("operation successful\n\n");
    return 0;
}

