This game requires either TWO virtual drives (in an emulator) or TWO real hardware drives in your VZ
32KB Required (sorry VZ200 not supported at this stage unless modded to 32KB)
Load the "game.dsk" to the 1st drive (it is only required at the startup as the Infocom Interpreter)
BRUN "GAME"
Load the two game disks in either drive
To SAVE load the save.dsk in either drive