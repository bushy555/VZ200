Grazie per l'interesse verso il Laser310/Vz300.
Questa macchina rimarr� per sempre nel mio cuore.

Thanks for your interest on Laser310/Vz300
This computer will stand forever in my heart.

Scrivimi a:

Write to:

steve75@libero.it

