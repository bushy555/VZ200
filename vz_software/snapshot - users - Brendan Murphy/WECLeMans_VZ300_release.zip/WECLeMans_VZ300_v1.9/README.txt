W.E.C. LE MANS - VZ300 version 1.9
==================================
Original arcade game (C) Konami 1986. ZX Spectrum 48K version by Imagine
Software 1988. This is a conversion of the ZX Spectrum game to the Dick
Smith VZ300. The original Spectrum game code (driving, opponents, track,
checkpoints, timing, scoring) runs unchanged; the screen, sound, keyboard
and joystick routines are new VZ code.

Needs:  VZ300, BennVenn 128K RAM expansion, BennVenn SD loader.
Files:  copy all three to the same folder on the SD card, then run WECLEMAN.VZ
          WECLEMAN.VZ    loader (524 bytes)
          WECLEMN1.DAT   game data (21,796 bytes)
          WECLEMN2.DAT   game data (17,860 bytes)
        If a .DAT file is missing the screen shows "CAN'T OPEN WECLEMN1/2.DAT".

Controls (keyboard and both joysticks work at the same time)
  Q  accelerate        A  brake
  O  steer left        P  steer right
  SPACE or M  change gear (low / high)
  Joystick: up = accelerate, down = brake, left/right steer, fire = gear
  Boot intro (once, after loading): the Spectrum player car at full Spectrum
  scale in VZ colours drives down the road through all its frames, past
  full-scale Spectrum trees, chevrons and SPARK PLUGS signs, then
  chequered flags wave either side as it crosses the line and spins out
  (about 12 seconds). Any key or fire skips it.
  Title screen: FIRE or SPACE to start.
  Attract sequence: title, high scores, then a demo race (about a minute,
  driven from inputs recorded on a Spectrum autopilot run). Any key or
  fire during the demo returns to the title screen.
  High score: type your initials, or use left/right and fire.

Hints (as on the Spectrum)
  Start in low gear, change up at about 140 MPH. High gear will not pull
  away from below about 45 MPH. Each checkpoint gives extra time.
  Completing the whole course (12 checkpoints) shows the ending - on the
  48K Spectrum this needed side 2 of the tape; here it is built in.

Screen
  mode(1) 128x64 in green/yellow/blue/red for the race: blue sky with
  clouds, yellow road, green grass, blue outlines, red player's car. The
  Spectrum's 256x128 race picture is reduced 2:1 across and about 3:1 down;
  1-pixel dithers keep their phase, so grass bands stay striped.
  Cars and roadside objects are drawn in four colours straight into video
  RAM on top of the converted picture, from VZ versions of every Spectrum
  frame:
    player's car  all 12 Spectrum frames (straight, curve and steering
                  leans, pitch, slide) plus mirrors, and the crash/spin
                  frames (side, three-quarter and front views): red body,
                  blue glass and tyres, yellow wing edge and lights
    rival cars    all 11 sizes x 4 sub-positions: green body, blue outline
                  and tyres, yellow stripes, red lights
    signs         chevrons, S-bend and SPARK PLUGS boards, 24 HEURES
                  banner: blue frame, red/yellow faces
    trees         blue foliage with green edges, red trunk
    start gantry  red/yellow lattice towers and beam
    gear lever    red-framed panel, red knob moving between LO and HI
  Each object keeps its Spectrum position, size, clipping and drawing
  order; the game code still decides what to draw.
  Checkpoint messages (EXTENDED PLAY!, LAP n) are shown as a yellow-on-red
  banner in double-size letters, readable at the VZ's resolution.
  No sprite flicker: picture lines that carry sprites are built in a back
  buffer (background + sprites) and copied to the screen complete, so the
  screen never shows a line with its sprites missing.
  Title, high score, pre-race and arrival map screens use mode(0)
  semigraphics; the congratulations screen uses mode(1) buff/cyan/magenta/
  orange with the driver portrait.

Sound
  The Spectrum title tune and game over tune (two detuned square waves plus
  the drum effects). The 48K Spectrum race is silent (the 128K version has
  AY sound); the VZ version adds short race effects: a beep with each number of the 3-2-1 start countdown
  and a higher GO beep, a blip on each gear change, a crash noise that dies
  away, two rising beeps at each checkpoint, and a tick every second for
  the last ten seconds of time. The race effects play while the game runs
  (the speaker is stepped between picture lines), so they cost no game time.

Speed
  About 4.0 fields per game frame (the Spectrum takes about 4.2 on the same
  drive), so the race runs at the Spectrum's speed or a touch quicker.

Memory use
  $4000-$4FFF  DOS RAM bank 0: Spectrum $6800-$77FF (moved, pointers adjusted)
  $5000-$57FF  DOS RAM bank 0: VZ road-renderer helper
  $5800-$5AFF  DOS RAM bank 0: Spectrum colour attributes (read by the VZ
               converter for the sky/ground colours)
  $5B00-$67FF  DOS RAM bank 0: Spectrum code and fonts at their own addresses
  $4000-$67FF  DOS RAM bank 1: VZ display driver (converter, colour tables,
               HUD, timer, clouds), music player
  $7000-$77FF  video RAM
  $7800-$FFFF  internal RAM + expansion bank 0: original Spectrum game, with
               VZ code in the spaces left by replaced Spectrum routines
               ($8000-$80FF was the Spectrum interrupt table). The VZ
               colour sprites and their drawing code replace the
               Spectrum sprite data at $9D36-$B655 and $C08B-$E2F9
               $DCC0-$E1FF: back buffer for the sprite lines
  $B800-$FFFF  expansion bank 1: front end, music scripts, ending overlay,
               congratulations screen; save area while the ending runs
Loading: WECLEMAN.VZ reads WECLEMN1.DAT (to $7B00 up) and WECLEMN2.DAT
(expansion bank 1) with the BennVenn DOS file calls (as 13 Ghosts does),
then unpacks them (ZX0).
