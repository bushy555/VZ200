import sys,struct
d=open(sys.argv[1],'rb').read()
print(d[:10],d[8],d[9])
p=10;n=0
out=sys.argv[2] if len(sys.argv)>2 else None
while p<len(d):
    t=d[p];p+=1
    if t==0x10:
        pause,l=struct.unpack('<HH',d[p:p+4]);data=d[p+4:p+4+l];p+=4+l
        info=''
        if data[0]==0 and l==19:
            typ=data[1];name=data[2:12];ln,p1,p2=struct.unpack('<HHH',data[12:18]);info=f'HDR type{typ} {name} len{ln} p1={p1} p2={p2}'
        print(n,'std',l,'flag',data[0],info)
        if out: open(f'{out}/b{n:02d}.bin','wb').write(data)
    elif t==0x11:
        hdr=d[p:p+18];l=hdr[15]|hdr[16]<<8|hdr[17]<<16;data=d[p+18:p+18+l]
        print(n,'turbo',l,'pilot',struct.unpack('<HHHHHH',hdr[:12]),'used',hdr[12],'pause',struct.unpack('<H',hdr[13:15]),'flag',data[0])
        if out: open(f'{out}/b{n:02d}.bin','wb').write(data)
        p+=18+l
    elif t==0x12: print(n,'tone');p+=4
    elif t==0x13: c=d[p];print(n,'pulses',c);p+=1+2*c
    elif t==0x14:
        l=d[p+7]|d[p+8]<<8|d[p+9]<<16;data=d[p+10:p+10+l];print(n,'pure',l, struct.unpack('<HH',d[p:p+4]),d[p+4]);
        if out: open(f'{out}/b{n:02d}.bin','wb').write(data)
        p+=10+l
    elif t==0x20: print(n,'pause',struct.unpack('<H',d[p:p+2]));p+=2
    elif t==0x21: l=d[p];print(n,'group',d[p+1:p+1+l]);p+=1+l
    elif t==0x22: print(n,'groupend')
    elif t==0x30: l=d[p];print(n,'text',d[p+1:p+1+l]);p+=1+l
    elif t==0x32: l=struct.unpack('<H',d[p:p+2])[0];print(n,'archive',d[p+2:p+2+l]);p+=2+l
    elif t==0x35: l=struct.unpack('<I',d[p+16:p+20])[0];print(n,'custom',d[p:p+16]);p+=20+l
    elif t==0x5a: p+=9
    elif t==0x24: print(n,'loop',d[p:p+2]);p+=2
    elif t==0x25: print(n,'loopend')
    elif t==0x2a: p+=4
    elif t==0x2b: p+=5
    else: print('unknown',hex(t));break
    n+=1
