"""Elite (ZX Spectrum 48K) -> labelled, relocatable source generator.

Modes:
  zx   : pristine, assembles byte-identical to the loaded image 5B00-FFFF
  move : same code with the VZ memory layout (blocks relocated) + patches from a patch file
"""
import sys, os, re, json, subprocess
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from dz80 import dis

LO, HI = 0x5B00, 0xFFFF
# jump / pointer tables found by analysis: (addr, kind, count)
#   jp3  : C3 lo hi entries          dw : plain words        ship4: C3 lo hi class (pointer at +1)
TABLES = [
    (0xD000, 'jp3', 21),     # module jump table (called by 813E with SP=D000)
    (0x9561, 'jp3', 8),      # sound / effect dispatcher (jp (hl) at 959E)
    (0xD7C3, 'dw', 14),      # text token control codes < 0Eh   (D7B5)
    (0xD7DF, 'dw', 32),      # text token control codes < 20h   (D7B0)
    (0x617C, 'ship4', 20),   # ship blueprint pointers (base 6180 used at B898)
    (0x6FF2, 'jp3', 3),
    (0x606B, 'dp', 1),       # ship slot 0 (space station) blueprint pointer      # entry jump table (6FF2 start, 6FF5, 6FF8 used by 93C6)
]
INLINE1 = {0xD421, 0xE2BC, 0xF068}   # routines that read one inline byte after the CALL
EXTRA_ENTRIES = [0x70E0, 0x93C0, 0x9341, 0xD09E]   # hidden code found by reference scan
BUF_LO, BUF_HI = 0xC000, 0xCFFF      # Spectrum off-screen buffer (runtime)

def load(memf, covf):
    return bytearray(open(memf, 'rb').read()), open(covf, 'rb').read()

def discover(m, cov, extra=()):
    """Return iscode[] (1 start, 2 body, 3 table data) and table word positions."""
    iscode = bytearray(65536)
    tabword = {}            # addr of 16-bit pointer -> target
    work = [a for a in range(LO, HI + 1) if cov[a] & 1] + list(extra) + EXTRA_ENTRIES
    for base, kind, n in TABLES:
        step = {'jp3': 3, 'dw': 2, 'dp': 2, 'ship4': 4}[kind]
        for i in range(n):
            a = base + i * step
            if kind == 'jp3':
                work.append(a)
            else:
                p = a + (1 if kind == 'ship4' else 0)
                t = m[p] | m[p + 1] << 8
                tabword[p] = t
                for k in range(step): iscode[a + k] = 3
                if kind == 'dw': work.append(t)        # code pointer ('dp' = data pointer)
    seen = set()
    while work:
        a = work.pop()
        while LO <= a <= HI and a not in seen:
            if iscode[a] in (2, 3) or BUF_LO <= a <= BUF_HI: break
            t, l, tg, end = dis(m, a)
            if t.startswith('db'): break
            if any(iscode[a + i] for i in range(1, l)): break
            seen.add(a); iscode[a] = 1
            for i in range(1, l): iscode[a + i] = 2
            for x in tg:
                if LO <= x <= HI: work.append(x)
            if end or t == 'ret' or t.startswith('jp (') or t in ('reti', 'retn'): break
            a += l
            if t.startswith('call') and tg and tg[0] in INLINE1:
                iscode[a] = 3; a += 1
    return iscode, tabword

def verify_insns(m, iscode, D):
    """Assemble every decoded instruction in place; return set of starts that do not round-trip."""
    src = [(a,) + dis(m, a)[:2] for a in range(LO, HI + 1) if iscode[a] == 1]
    with open(f'{D}/vt.asm', 'w') as f:
        f.write(' device zxspectrumnext\n')
        for a, t, l in src: f.write(f' org ${a:04x}\n {t}\n')
        f.write(' savebin "vt.bin",0,65536\n')
    subprocess.run([f'{D}/sjasm/sjasmplus', '--nologo', 'vt.asm'], cwd=D, capture_output=True)
    vb = open(f'{D}/vt.bin', 'rb').read()
    return {a for a, t, l in src if vb[a:a + l] != m[a:a + l]}

def build(m, iscode, tabword, layout=None, patches=None, notes=None, header=(), free=()):
    """layout: list of (lo, hi_excl, new_base) blocks to relocate. patches: {addr: (len, asmtext)}"""
    layout = layout or []; patches = patches or {}; notes = notes or {}
    def newaddr(a):
        for lo, hi, nb in layout:
            if lo <= a < hi: return a - lo + nb
        return a
    def moved(a):
        return any(lo <= a < hi for lo, hi, nb in layout)
    labels = {}
    for a in range(LO, HI + 1):
        if iscode[a] != 1: continue
        t, l, tg, _ = dis(m, a)
        for x in tg:
            if LO <= x <= HI: labels[x] = 'L%04X' % x
        mm = re.search(r'\$([0-9a-f]{4})', t)
        if mm and not tg:
            v = int(mm.group(1), 16)
            if LO <= v <= HI and not ((v & 0xff) == 0xfe and t.startswith('ld bc')):
                labels.setdefault(v, 'D%04X' % v)
    for p, t in tabword.items():
        if LO <= t <= HI: labels.setdefault(t, ('L%04X' if iscode[t] == 1 else 'D%04X') % t)
    for a in patches:
        labels.setdefault(a, 'P%04X' % a)
    for a in range(LO, HI + 1):
        if iscode[a] == 1:
            l = dis(m, a)[1]
            if any(a + i in labels for i in range(1, l)): labels.setdefault(a, 'L%04X' % a)
        if a in tabword and a + 1 in labels: labels.setdefault(a, 'D%04X' % a)
    def lab(v):
        return labels[v] if v in labels and LO <= v <= HI else None
    def render(a):
        t, l, tg, _ = dis(m, a)
        def rep(mm):
            v = int(mm.group(1), 16); n = lab(v)
            return n if n else mm.group(0)
        return re.sub(r'\$([0-9a-f]{4})', rep, t), l
    # emit lines per address in original order, grouped by destination block
    out_main, out_blocks = [], {i: [] for i in range(len(layout))}
    equs = []
    def sink(a):
        for i, (lo, hi, nb) in enumerate(layout):
            if lo <= a < hi: return out_blocks[i]
        return out_main
    a = LO
    org_needed = True
    def infree(a):
        for lo, hi in free:
            if lo <= a < hi: return hi
        return None
    for v, nm in labels.items():
        if infree(v): equs.append(f'{nm} equ ${v:04x}   ; freed area: literal value')
    while a <= HI:
        fe = infree(a)
        if fe:
            org_needed = True; a = fe; continue
        S = sink(a)
        if S is out_main and org_needed:
            out_main.append(f'    org ${a:04x}'); org_needed = False
        if S is not out_main: org_needed = True
        if a in patches:
            ln, txt = patches[a]
            S.append(f'{labels[a]}:   ; ---- PATCH {a:04X} ({ln} bytes) ----')
            S.append(txt)
            S.append(f'    assert $ <= {labels[a]}+{ln}')
            S.append(f'    if $ < {labels[a]}+{ln}\n    ds {labels[a]}+{ln}-$,0\n    endif')
            for i in range(1, ln):
                if a + i in labels: equs.append(f'{labels[a+i]} equ {labels[a]}+{i}')
            a += ln; continue
        if a in labels and iscode[a] != 2 and not infree(a):
            S.append(f'{labels[a]}:')
        if iscode[a] == 1:
            t, l = render(a)
            for i in range(1, l):
                if a + i in labels: equs.append(f'{labels[a+i]} equ {labels[a]}+{i}')
            c = (' ; ' + ' | '.join(notes[a])) if a in notes else ''
            S.append(f'    {t:<28} ; {a:04X}{c}')
            a += l
        elif a in tabword:
            n = lab(tabword[a]) or f'${tabword[a]:04x}'
            S.append(f'    dw {n:<25} ; {a:04X} table')
            if a + 1 in labels: equs.append(f'{labels[a+1]} equ {labels[a] if a in labels else "$%04x" % a}+1')
            a += 2
        else:
            b = a; row = []
            while b <= HI and iscode[b] in (0, 3) and b not in tabword and len(row) < 16 \
                    and not (b != a and (b in labels or b in patches)) and sink(b) is S and not infree(b):
                row.append(m[b]); b += 1
            c = (' ; ' + ' | '.join(notes[a])) if a in notes else ''
            txt = ''.join(chr(x) if 32 <= x < 127 else '.' for x in row)
            S.append(f'    db {",".join("$%02x" % x for x in row):<63} ; {a:04X} {txt}{c}')
            a = b
    res = list(header)
    res += out_main
    for i, (lo, hi, nb) in enumerate(layout):
        res.append(f'; ==== relocated block {lo:04X}-{hi-1:04X} -> {nb:04X} ====')
        res.append(f'    org ${nb:04x}')
        res += out_blocks[i]
        res.append(f'    assert $ <= ${nb + (hi - lo):04x}')
    res.append('')
    res += equs
    return res, labels

if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('mem'); ap.add_argument('cov'); ap.add_argument('out')
    ap.add_argument('--mode', default='zx'); ap.add_argument('--notes')
    args = ap.parse_args()
    D = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    m, cov = load(args.mem, args.cov)
    iscode, tw = discover(m, cov)
    bad = verify_insns(m, iscode, D)
    for a in bad:
        l = dis(m, a)[1]
        for i in range(l): iscode[a + i] = 0
    notes = {}
    if args.notes:
        for line in open(args.notes):
            k, a, c = line.split(None, 2); notes.setdefault(int(a, 16), []).append(c.strip())
    hdr = ['; ZX Spectrum 48K ELITE (Firebird/Torus 1985) - labelled source',
           '    device zxspectrum48']
    res, labels = build(m, iscode, tw, notes=notes, header=hdr)
    res.append(f'    savebin "elite_check.bin",${LO:04x},${HI-LO+1:04x}')
    open(args.out, 'w').write('\n'.join(res) + '\n')
    print('insns', sum(1 for a in range(LO, HI + 1) if iscode[a] == 1), 'bad', len(bad), 'labels', len(labels))
