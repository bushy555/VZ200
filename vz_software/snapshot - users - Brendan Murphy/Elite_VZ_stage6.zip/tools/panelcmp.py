import sys
src=open(__file__.replace('panelcmp.py','vzshot.py')).read()
ns={'__name__':'x'}; exec(src[:src.index('out=sys.argv[1]')],ns)
from PIL import Image
out=sys.argv[1]; fs=sys.argv[2:]
G=Image.new('RGB',(768,len(fs)*100),(40,40,40))
for k,f in enumerate(fs):
    G.paste(ns['render'](f).crop((0,129,256,192)).resize((768,96*0+95),Image.NEAREST),(0,k*100))
G.save(out)
