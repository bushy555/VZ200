"""SD-loader size test files: SDTnnnnn.VZ loads at 7AE9h, checks its own contents
(pseudo-random fill, 16-bit sum) and prints the result on the text screen."""
import subprocess, os, random
D = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SJ = f'{D}/sjasm/sjasmplus'; P = f'{D}/pack'
def vzs(t): return ','.join(str(ord(c) & 0x3F) for c in t)
for size in (29500, 30500, 31000, 31500, 32000, 33000, 34000):
    body_len = size - 24
    asm = f'''
    DEVICE NONE
    OUTPUT "{P}/sdt.bin"
    ORG $7AE9
    di
    ld sp,$7800
    ld hl,$7000
    ld de,$7001
    ld bc,$01FF
    ld (hl),$20
    ldir
    ld hl,DATA
    ld bc,DLEN
    ld de,0
.s: ld a,(hl)
    add a,e
    ld e,a
    jr nc,.n
    inc d
.n: inc hl
    dec bc
    ld a,b
    or c
    jr nz,.s
    ld hl,(SUM)
    or a
    sbc hl,de
    ld hl,OK
    jr z,.p
    ld hl,BAD
.p: ld de,$7060
    ld bc,32
    ldir
    ld hl,TITLE
    ld de,$7020
    ld bc,32
    ldir
.h: jr .h
TITLE: DB {vzs(f"  SD TEST: {size} BYTE FILE     "[:32].ljust(32))}
OK:    DB {vzs("  LOADED CORRECTLY - OK         ")}
BAD:   DB {vzs("  DATA DAMAGED - FAILED         ")}
SUM:   DW 0
DATA:
'''
    open(f'{P}/sdt.asm', 'w').write(asm + '    DB 0\n')
    subprocess.run([SJ, '--nologo', f'--sym={P}/sdt.sym', f'{P}/sdt.asm'], capture_output=True)
    code = open(f'{P}/sdt.bin', 'rb').read()[:-1]
    r = random.Random(size)
    dlen = body_len - len(code)
    data = bytes(r.randrange(256) for _ in range(dlen))
    s = sum(data) & 0xFFFF
    sym = {l.split(':')[0]: int(l.split('0x')[1], 16) for l in open(f'{P}/sdt.sym') if ': EQU' in l}
    asm2 = asm.replace('DATA:', f'DLEN EQU {dlen}\nDATA:')
    open(f'{P}/sdt.asm', 'w').write(asm2 + '    DB 0\n')
    subprocess.run([SJ, '--nologo', f'--sym={P}/sdt.sym', f'{P}/sdt.asm'], capture_output=True, check=True)
    code = bytearray(open(f'{P}/sdt.bin', 'rb').read()[:-1])
    sym = {l.split(':')[0]: int(l.split('0x')[1], 16) for l in open(f'{P}/sdt.sym') if ': EQU' in l}
    o = sym['SUM'] - 0x7AE9; code[o] = s & 255; code[o + 1] = s >> 8
    body = bytes(code) + data
    assert len(body) == body_len
    name = f'SDT{size}'.encode().ljust(16, b'\0')
    hdr = b'VZF0' + name + b'\0' + bytes([0xF1]) + (0x7AE9).to_bytes(2, 'little')
    fn = f'{D}/out/sdtest/SDT{size}.VZ'
    open(fn, 'wb').write(hdr + body)
    print(fn, len(hdr + body), 'end', hex(0x7AE9 + body_len - 1))
