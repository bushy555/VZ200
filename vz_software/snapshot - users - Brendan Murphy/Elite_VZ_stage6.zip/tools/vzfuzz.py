import random,sys
keys=['R','Q','E','W','T','F','A','D','CTRL','S','G','V','Z','C','SHIFT','X','B','4','1','3','2','5','M','SPACE','N','7','0','8','9','6','U','P','I','RETURN','O','Y','J','K','L','H','.',',']
seed=int(sys.argv[1]); n=int(sys.argv[2]); r=random.Random(seed)
seq=['260:N:1','280:N:0','420:SPACE:1','440:SPACE:0']
f=500
while f<n:
    if r.random()<0.45: k=r.choice(['S','X','N','M','A','SPACE','CTRL','1','2','3','4','J','T','JUP','JDOWN','JLEFT','JRIGHT','JFIRE'])
    else: k=r.choice(keys)
    d=r.randint(3,60); seq+= [f'{f}:{k}:1', f'{f+d}:{k}:0']; f+=d+r.randint(0,40)
print(' '.join(seq))
