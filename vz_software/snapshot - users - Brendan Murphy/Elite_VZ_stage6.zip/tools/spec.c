// Minimal headless ZX Spectrum 48K with TZX playback, scripted keys, snapshot dump.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../z80core/z80.h"
extern uint8_t z80_port_hi;

static uint8_t mem[65536];
static uint32_t *pulses; static int npulses, cap;
static int tape_on = 0, tape_idx = 0; static long tape_next = 0; static int ear = 0;
static unsigned long long tcount = 0;
static uint8_t keys[8]; // row bits pressed (1 = pressed)
static uint8_t bank1[0x4800]; static int curbank=0; static uint16_t ring[4096], ringhl[4096], ringde[4096]; static int ringi=0; static int border = 0; static uint8_t legit[65536]; static int stray_lo=-1,stray_hi=-1,stray_n=0; static int pois_lo=-1,pois_hi=-1,pois_n=0;
static int tracing=0; static uint16_t curpc, prevpc; static uint32_t scrw[65536], ins[65536], outs[65536], romc[65536]; static uint8_t scrreg[65536], srd[65536], bufw[65536], bufr[65536]; static uint16_t bwmin[65536], bwmax[65536]; static int wlo=-1,whi=-1; static uint8_t wacc[65536]; static uint16_t wmin[65536],wmax[65536];
static void watch(uint16_t a,int k){ if(tracing&&a>=wlo&&a<=whi){ if(!wacc[curpc]||a<wmin[curpc])wmin[curpc]=a; if(a>wmax[curpc])wmax[curpc]=a; wacc[curpc]|=k; } } static uint8_t exec_[65536], rd_[65536], wr_[65536];

static void addp(uint32_t t){ if(npulses==cap){cap=cap?cap*2:4096;pulses=realloc(pulses,cap*4);} pulses[npulses++]=t; }
static void addbytes(const uint8_t*d,int l,int z,int o,int used){
  for(int i=0;i<l;i++){int nb=(i==l-1)?used:8; for(int b=0;b<nb;b++){int bit=(d[i]>>(7-b))&1; addp(bit?o:z); addp(bit?o:z);}}
}
static void addpause(int ms){ if(ms>0){ addp(3500*ms); /* marker */ } }
static void load_tzx(const char*fn){
  FILE*f=fopen(fn,"rb"); fseek(f,0,2); long n=ftell(f); fseek(f,0,0); uint8_t*d=malloc(n); fread(d,1,n,f); fclose(f);
  long p=10;
  while(p<n){ int t=d[p++];
    if(t==0x10){ int pause=d[p]|d[p+1]<<8, l=d[p+2]|d[p+3]<<8; uint8_t*b=d+p+4;
      int pc=b[0]<128?8063:3223; for(int i=0;i<pc;i++)addp(2168); addp(667); addp(735);
      addbytes(b,l,855,1710,8); addpause(pause); p+=4+l; }
    else if(t==0x11){ uint8_t*h=d+p; int pil=h[0]|h[1]<<8,s1=h[2]|h[3]<<8,s2=h[4]|h[5]<<8,z=h[6]|h[7]<<8,o=h[8]|h[9]<<8,pc=h[10]|h[11]<<8,used=h[12],pause=h[13]|h[14]<<8; int l=h[15]|h[16]<<8|h[17]<<16;
      for(int i=0;i<pc;i++)addp(pil); addp(s1); addp(s2); addbytes(h+18,l,z,o,used); addpause(pause); p+=18+l; }
    else if(t==0x14){ uint8_t*h=d+p; int z=h[0]|h[1]<<8,o=h[2]|h[3]<<8,used=h[4],pause=h[5]|h[6]<<8; int l=h[7]|h[8]<<8|h[9]<<16;
      addbytes(h+10,l,z,o,used); addpause(pause); p+=10+l; }
    else if(t==0x12){ int pl=d[p]|d[p+1]<<8,c=d[p+2]|d[p+3]<<8; for(int i=0;i<c;i++)addp(pl); p+=4; }
    else if(t==0x13){ int c=d[p]; for(int i=0;i<c;i++)addp(d[p+1+2*i]|d[p+2+2*i]<<8); p+=1+2*c; }
    else if(t==0x20){ addpause(d[p]|d[p+1]<<8); p+=2; }
    else if(t==0x21){ p+=1+d[p]; } else if(t==0x22){}
    else if(t==0x30){ p+=1+d[p]; } else if(t==0x32){ p+=2+(d[p]|d[p+1]<<8); }
    else { fprintf(stderr,"tzx block %x unsupported\n",t); exit(1);} }
  fprintf(stderr,"%d pulses\n",npulses);
}
static void tape_update(){
  if(!tape_on||tape_idx>=npulses) return;
  while(tape_on && (long long)tcount>=tape_next){ ear^=1; tape_idx++; if(tape_idx>=npulses){tape_on=0;break;} tape_next+=pulses[tape_idx]; }
}
static void pois(uint16_t a,char k){ if(a>=pois_lo&&a<=pois_hi&&pois_n<60){ pois_n++; fprintf(stderr,"POISON %c %04x pc=%04x\n",k,a,curpc);} }
static uint8_t rb(void*u,uint16_t a){ pois(a,a==curpc?'X':'R'); if(a!=curpc) watch(a,1); if(tracing&&a!=curpc){ rd_[a]=1; if(a>=0xc000&&a<0xd000&&(a<curpc||a>curpc+3)) bufr[curpc]=1; if(a>=0x4000&&a<0x5b00 && (a<curpc||a>curpc+3)) srd[curpc]|= a<0x5000?1:a<0x5800?2:4; } return mem[a]; }
static void wb(void*u,uint16_t a,uint8_t v){ pois(a,'W'); if(a>=stray_lo&&a<=stray_hi&&!legit[a]&&stray_n<80&&!(curbank)){ stray_n++; fprintf(stderr,"STRAY %04x pc=%04x\n",a,curpc); if(stray_n==1||getenv("RINGALL")){ fprintf(stderr,"  ring:"); for(int k=0;k<4096;k++) fprintf(stderr," %04x/%04x/%04x",ring[(ringi+k)&4095],ringhl[(ringi+k)&4095],ringde[(ringi+k)&4095]); fprintf(stderr,"\n");} }  watch(a,2); if(tracing){ wr_[a]=1; if(a>=0xc000&&a<0xd000){ if(!bufw[curpc]||a<bwmin[curpc])bwmin[curpc]=a; if(a>bwmax[curpc])bwmax[curpc]=a; bufw[curpc]=1;} if(a>=0x4000&&a<0x5b00){ scrw[curpc]++; scrreg[curpc]|= a<0x5000?1:a<0x5800?2:4; } } if(a>=0x4000) mem[a]=v; }
static uint8_t pin(z80*z,uint8_t lo){
  if(tracing) ins[curpc]++;
  if(lo&1) return 0xff; // kempston etc: nothing
  uint8_t hi=z80_port_hi, r=0x1f;
  for(int i=0;i<8;i++) if(!(hi&(1<<i))) r&=~keys[i];
  tcount=z->cyc; tape_update();
  return r | 0xa0 | (ear?0x40:0);
}

static void bankswitch(int want){ if(want==curbank) return; uint8_t t[0x4800]; memcpy(t,mem+0xb800,0x4800); memcpy(mem+0xb800,bank1,0x4800); memcpy(bank1,t,0x4800); curbank=want; }
static void pout(z80*z,uint8_t lo,uint8_t v){ if(lo==0x37){ bankswitch((v>>2)&1); return; } if(tracing) outs[curpc]++; if(!(lo&1)) border=v&7; }

static void dump_screen(const char*fn){
  static const uint8_t pal[16][3]={{0,0,0},{0,0,205},{205,0,0},{205,0,205},{0,205,0},{0,205,205},{205,205,0},{205,205,205},
   {0,0,0},{0,0,255},{255,0,0},{255,0,255},{0,255,0},{0,255,255},{255,255,0},{255,255,255}};
  FILE*f=fopen(fn,"wb"); fprintf(f,"P6 256 192 255\n");
  for(int y=0;y<192;y++)for(int x=0;x<256;x++){
    int a=0x4000|((y&0xc0)<<5)|((y&7)<<8)|((y&0x38)<<2)|(x>>3); int at=mem[0x5800+(y>>3)*32+(x>>3)];
    int bit=(mem[a]>>(7-(x&7)))&1; int c=bit?(at&7):((at>>3)&7); if(at&64)c+=8; fwrite(pal[c],1,3,f);} fclose(f);
}
static void save_sna(z80*z,const char*fn){
  // push PC onto stack per SNA convention
  uint16_t sp=z->sp-2; mem[sp]=z->pc&0xff; mem[(uint16_t)(sp+1)]=z->pc>>8;
  uint8_t h[27]; h[0]=z->i; h[1]=z->l_;h[2]=z->h_;h[3]=z->e_;h[4]=z->d_;h[5]=z->c_;h[6]=z->b_;
  h[7]=z->f_;h[8]=z->a_;h[9]=z->l;h[10]=z->h;h[11]=z->e;h[12]=z->d;h[13]=z->c;h[14]=z->b;
  h[15]=z->iy&0xff;h[16]=z->iy>>8;h[17]=z->ix&0xff;h[18]=z->ix>>8;h[19]=z->iff2?4:0;h[20]=z->r;
  uint8_t f=(z->sf<<7)|(z->zf<<6)|(z->yf<<5)|(z->hf<<4)|(z->xf<<3)|(z->pf<<2)|(z->nf<<1)|z->cf; h[21]=f;h[22]=z->a;
  h[23]=sp&0xff;h[24]=sp>>8;h[25]=z->interrupt_mode;h[26]=border;
  FILE*o=fopen(fn,"wb"); fwrite(h,1,27,o); fwrite(mem+0x4000,1,49152,o); fclose(o);
  mem[sp]=0; // restore not needed for dumps
}
// key script: frame -> keys
struct ks { int frame; int row; int bit; int down; };
int main(int argc,char**argv){
  // argv: rom tzx outprefix frames [keyspec...] keyspec = frame:row:bit:down
  FILE*r=fopen(argv[1],"rb"); fread(mem,1,16384,r); fclose(r);
  if(getenv("LOADBIN")){ FILE*b=fopen(getenv("LOADBIN"),"rb"); fread(mem+0x4000,1,49152,b); fclose(b); npulses=1; pulses=calloc(1,4);} else load_tzx(argv[2]);
  if(getenv("BANK1")){ FILE*b=fopen(getenv("BANK1"),"rb"); fread(bank1,1,0x4800,b); fclose(b);}
  if(getenv("LEGIT")){ FILE*b=fopen(getenv("LEGIT"),"rb"); fread(legit,1,65536,b); fclose(b); sscanf(getenv("STRAYR"),"%x-%x",&stray_lo,&stray_hi);}
  if(getenv("POISON")) sscanf(getenv("POISON"),"%x-%x",&pois_lo,&pois_hi);
  const char*out=argv[3]; int frames=atoi(argv[4]);
  int nk=argc-5; struct ks*K=calloc(nk+1,sizeof*K);
  for(int i=0;i<nk;i++) sscanf(argv[5+i],"%d:%d:%d:%d",&K[i].frame,&K[i].row,&K[i].bit,&K[i].down);
  z80 z; z80_init(&z); z.read_byte=rb; z.write_byte=wb; z.port_in=pin; z.port_out=pout;
  int tape_started=0;
  if(getenv("LOADBIN")){ z.pc=strtol(getenv("PC"),0,16); z.sp=strtol(getenv("SP"),0,16); z.i=0xfd; z.interrupt_mode=2; z.iff1=z.iff2=getenv("IFF")?1:0; tape_started=1; }
  if(getenv("WATCH")) sscanf(getenv("WATCH"),"%x-%x",&wlo,&whi);
  int trf=getenv("TRACE_FROM")?atoi(getenv("TRACE_FROM")):1<<30;
  for(int fr=0;fr<frames;fr++){ if(fr==trf) tracing=1;
    { char*P=getenv("POKES"); if(P){ char buf[4096]; strcpy(buf,P); for(char*t=strtok(buf,",");t;t=strtok(NULL,",")){int f,a,v; sscanf(t,"%d:%x:%x",&f,&a,&v); if(f==fr){mem[a]=v;fprintf(stderr,"poke %04x=%02x\n",a,v);}}} }
    { char*S=getenv("SHOTS"); if(S){ char buf[4096]; strcpy(buf,S); for(char*t=strtok(buf,",");t;t=strtok(NULL,",")){ if(atoi(t)==fr){ char fn[512]; sprintf(fn,"%s_%d.ppm",out,fr); dump_screen(fn);} } } }
    for(int i=0;i<nk;i++) if(K[i].frame==fr){ if(K[i].down) keys[K[i].row]|=1<<K[i].bit; else keys[K[i].row]&=~(1<<K[i].bit);}
    unsigned long end=(unsigned long)(fr+1)*69888UL;
    z80_gen_int(&z,0xff);
    while(z.cyc<end){
      if(!tape_started && z.pc==0x0556){ tape_started=1; tape_on=1; tcount=z.cyc; tape_next=z.cyc+pulses[0]; fprintf(stderr,"tape start frame %d\n",fr);}
      curpc=z.pc;
      { static int cp=-2; static long cnt=0, c1=0; static int f0=-1,f1=-1; if(cp==-2){ cp=getenv("COUNTPC")?(int)strtol(getenv("COUNTPC"),0,16):-1; if(getenv("COUNTWIN")) sscanf(getenv("COUNTWIN"),"%d-%d",&f0,&f1);} if(z.pc==cp && fr>=f0 && fr<f1) cnt++; if(fr==f1 && !c1){ c1=1; fprintf(stderr,"COUNT %ld in %d frames\n",cnt,f1-f0);} }
      { static int ri=0, tr=-1, done=0; if(tr<0) tr=getenv("TRAPROM")?1:0;
        ringhl[ringi&4095]=(z.h<<8)|z.l; ringde[ringi&4095]=(z.d<<8)|z.e; ring[ringi++&4095]=z.pc; ri=ringi;
        if(tr && !done && z.pc<0x4000 && !(z.pc>=0x22aa&&z.pc<=0x22ca) && !(z.pc>=0x03b5&&z.pc<=0x03f7)){ done=1; fprintf(stderr,"TRAPROM frame %d pc=%04x sp=%04x last:",fr,z.pc,z.sp); for(int k=0;k<64;k++) fprintf(stderr," %04x",ring[(ri+k-64)&4095]); fprintf(stderr,"\n"); } }
      { static int bp=-2; if(bp==-2) bp=getenv("BREAKPC")?(int)strtol(getenv("BREAKPC"),0,16):-1;
        if(z.pc==bp){ FILE*f=fopen(getenv("BREAKOUT"),"wb"); fwrite(mem,1,65536,f); fclose(f); fprintf(stderr,"BREAK at %04x frame %d sp=%04x i=%02x im=%d iff=%d\n",z.pc,fr,z.sp,z.i,z.interrupt_mode,z.iff1); bp=-1; } }
      { static long sl=-2; if(sl==-2) sl=getenv("STEPLOG")?atol(getenv("STEPLOG")):0; if(sl>0){ sl--; fprintf(stderr,"S %04x a=%02x hl=%04x de=%04x bc=%04x sp=%04x\n",z.pc,z.a,(z.h<<8)|z.l,(z.d<<8)|z.e,(z.b<<8)|z.c,z.sp);} }
      if(tracing){ for(int k=0;k<4;k++) exec_[(uint16_t)(z.pc+k)]|= (k==0)?1:2; if(z.pc<0x4000 && prevpc>=0x4000) romc[prevpc]++; prevpc=z.pc; }
      { static int tp=-2; if(tp==-2){ tp=getenv("TRACEPC")?(int)strtol(getenv("TRACEPC"),0,16):-1;} if(tracing && z.pc==tp) fprintf(stderr,"TP %02x %c fr%d\n",z.a,(z.a>=32&&z.a<127)?z.a:'.',fr); }
      z80_step(&z); tcount=z.cyc; tape_update();
    }
    if(fr%250==0) fprintf(stderr,"fr %d pc %04x tape %d/%d\n",fr,z.pc,tape_idx,npulses);
    if(tape_started && !tape_on && tape_idx>=npulses){ static int done=-1; if(done<0){done=fr;fprintf(stderr,"tape end frame %d pc %04x\n",fr,z.pc);} }
  }
  { char fn[512]; sprintf(fn,"%s.trace",out); FILE*t=fopen(fn,"w");
    for(int a=0;a<65536;a++){ if(scrw[a])fprintf(t,"SCR %04x %u %d\n",a,scrw[a],scrreg[a]); if(srd[a])fprintf(t,"SRD %04x 0 %d\n",a,srd[a]); if(ins[a])fprintf(t,"IN %04x %u\n",a,ins[a]); if(outs[a])fprintf(t,"OUT %04x %u\n",a,outs[a]); if(bufw[a])fprintf(t,"BUFW %04x %04x %04x\n",a,bwmin[a],bwmax[a]); if(bufr[a])fprintf(t,"BUFR %04x\n",a); if(wacc[a])fprintf(t,"WATCH %04x %c%c %04x-%04x\n",a,(wacc[a]&1)?'R':'-',(wacc[a]&2)?'W':'-',wmin[a],wmax[a]); if(romc[a])fprintf(t,"ROM %04x %u\n",a,romc[a]); }
    fclose(t); sprintf(fn,"%s.cov",out); t=fopen(fn,"wb"); for(int a=0;a<65536;a++){ uint8_t c=(exec_[a]&1)|(rd_[a]?4:0)|(wr_[a]?8:0); fputc(c,t);} fclose(t); }
  char fn[512]; sprintf(fn,"%s.ppm",out); dump_screen(fn);
  sprintf(fn,"%s.mem",out); FILE*m=fopen(fn,"wb"); fwrite(mem,1,65536,m); fclose(m);
  fprintf(stderr,"final pc %04x sp %04x iff %d im %d\n",z.pc,z.sp,z.iff1,z.interrupt_mode);
  sprintf(fn,"%s.sna",out); save_sna(&z,fn);
  return 0;
}
