"""Build Elite for the VZ300 + Benn Venn memory map.

TARGET=hyb : Spectrum test build (Spectrum ROM/screen, Benn Venn style bank 1 at B800-FFFF via port 37h)
TARGET=vz  : VZ300 build (adds the VZ hardware layer)
"""
import sys, os, subprocess
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gen
from gen import load, discover, verify_insns, build, dis

D = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TARGET = os.environ.get('TARGET', 'hyb')

# ---- memory layout -------------------------------------------------------
#  6800-77FF is VZ hardware (latch/keyboard, video RAM): the Spectrum code/data
#  overlapping it moves into the old off-screen buffer (C000-CFFF) and the old
#  tape SAVE/LOAD code area (D8EF-DA71).
LAYOUT = [(0x68D9, 0x7898, 0xC000),     # blueprints 68D9.. + variables/code 7000-7897
          (0x67BC, 0x68D9, 0xD90A)]     # one ship blueprint
FREE = [(0xC000, 0xD000),               # Spectrum draw buffer: now drawn straight into 4000-4FFF
        (0xD90A, 0xDA72)]               # tape SAVE/LOAD menu (not usable on the VZ)
FORCE_LITERAL = {0xDBCA}                # ld bc,$7406 is a message code pair, not an address

def patches(M):
    P = {}
    nop2 = '    nop\n    nop'
    # 1. draw straight into the shadow screen: no buffer bit
    for a in (0x89DA, 0x89FB, 0x8A40, 0x8A8B, 0x900C, 0x903A, 0xA848):
        P[a] = (2, nop2)                                   # set 7,h
    P[0x8A7C] = (2, '    cp $40')                          # line drawers: top / bottom of view
    P[0x902C] = (2, '    cp $40')
    P[0x8AC7] = (2, '    cp $50')
    P[0x905A] = (2, '    cp $50')
    if TARGET != 'vz':
        P[0x8085] = (3, '    ld sp,$5000')                 # view clear (push fill) now on 4000-4FFF
    # 8142 ld sp,$d000 stays: the module stack keeps CFBF-CFFF (free above the relocated block)
    P[0xD508] = (3, '    ld hl,$4000')                     # text print base (self-modified 40/C0)
    P[0xDA96] = (2, nop2)                                  # set 7,(hl): print into buffer -> no-op
    for a in (0x7440, 0x7454, 0x754A):
        P[a] = (2, nop2)                                   # set 7,(hl) via (D0D5)+2: print into buffer
    P[0x7D0F] = (2, '    ld d,$40')
    P[0xA89B] = (2, nop2)                                  # set 7 on the B348 operand: forced the B433 line family into
                                                           # the old buffer (now relocated code/variables at C000h)                        # star dust address base
    P[0xB347] = (2, '    or $40')                          # B433 line family address base
    for a, v in ((0x906D, 0x3f), (0x9074, 0x4f), (0x9105, 0x3f), (0x910C, 0x4f), (0x9201, 0x3f), (0x9208, 0x4f)):
        P[a] = (2, f'    ld a,${v:02x}')                    # fixed view bounds (were BFh/CFh)
    # the game's own "draw into buffer" setter (8F74) now selects the screen values too
    P[0x8F74] = (2, '    ld a,$40')
    P[0x8F79] = (2, '    ld a,$4f')
    P[0x8F7E] = (2, '    ld a,$3f')
    P[0x8F83] = (3, '    ld hl,$0000')                     # nop nop instead of set 7,h
    P[0x8F86] = (2, '    ld a,$50')
    # ...and the initial values of the self-modified operands it writes
    P[0x8E17] = (2, '    ld a,$50')
    for a in (0x8B01, 0x8C05, 0x8D05, 0x8DFD):
        P[a] = (2, '    ld a,$3f')
    for a in (0x8B08, 0x8C0C, 0x8D0C):
        P[a] = (2, '    ld a,$4f')
    # 8E57: stack-driven re-patching of the line code; value set B (8EAD) is the buffer set
    MAPB = {0xcb: 0x00, 0xfc: 0x00, 0xc0: 0x40, 0xd0: 0x50, 0xcf: 0x4f, 0xbf: 0x3f}
    for i in (10, 11, 12, 13, 17, 18, 19, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31):
        P[0x8EAD + i] = (1, f'    db ${MAPB[M[0x8EAD + i]]:02x}')
    # 2. buffer -> screen copy: present the frame
    P[0x7FBE] = ((3 if TARGET == 'vz' else 37), '    jp PRESENT')   # VZ: the copy loop behind it is freed
    # 3. dashboard save/restore around full-screen pages: bank 1
    P[0x8061] = (22 if TARGET == 'vz' else 11, '    call DREST')
    P[0x8183] = (22 if TARGET == 'vz' else 11, '    call DSAVE')
    # 4. tape SAVE/LOAD menu (D04E: jp D90A) -> "nothing loaded" (A=0, Z)
    P[0xD04E] = (3, '    jp TAPEMENU' if TARGET == 'vz' else '    xor a\n    ret')   # VZ: cassette menu
    if TARGET == 'vz':
        P[0x8080] = (5, '    jp VCLR')
        P[0xD7F5] = (2, '    dw LINE11')                   # text control 11 (heading rule): not over a 3D view                      # view clear: also the view text rows
        P[0xD4F2] = (21, '    call GLYPH')                  # font moved to bank 1 (+ text shadow)
        P[0xD61D] = (5, '    jp VZCLS')                     # CLS also clears the text shadow
        P[0x73D6] = (2, '    ld a,$ff')                     # Kempston probe: none
        P[0x990C] = (3, '    call SCMAP')                   # scanner save buffer -> bank 1
        P[0x990F] = (3, '    ld hl,SCBUF1')
        P[0x9941] = (5, '    jp SCTAIL')
        P[0xD09E] = (2, '    ld a,IM2PAGE')                 # restart code: full IM2 table at 5C00h
        P[0xFC28] = (2, '    ld a,$ff')
        P[0xFD78] = (4, '    call KEYF\n    nop')        # keyboard (+ joysticks)
        P[0xFF46] = (6, '    jp ISREXIT')                   # IRQ exit: VZ frame sync
        for a in (0x89D7, 0x89F8, 0x8A3D, 0x8A88, 0x9009, 0x9037):
            P[a] = (3, '    call P22B0')                    # ROM PIXEL-ADD
        P[0xA83D] = (3, '    call TR_DOT')                 # explosion particles: VZ resolution on 3D pages
        P[0xB0E0] = (3, '    jp TR_LINE')                  # lines
        P[0x86E9] = (3, '    call TR_CIRC')                # circles: note their rows
        P[0x7C92] = (3, '    jp TR_DUST')                  # star dust
        # text tokens: indexed lookup in DOS bank 1 instead of scanning the table
        P[0xD443] = (17, '    ld (TA),a\n    push ix\n    ld ix,D1_TOKA\n    call D1SH\n    pop ix\n    jp LD454')
        P[0xD45F] = (17, '    ld (TA),a\n    push ix\n    ld ix,D1_TOKB\n    call D1SH\n    pop ix\n    jp LD48E')
        P[0xEC22] = (3, '    call P22AA')
        P[0xED22] = (3, '    call P22AA')
        P[0x9BCC] = (3, '    call BEEP')                     # ROM BEEPER
        P[0xE1F4] = (3, '    jp BEEP')
        P[0x7352] = (4, '    call SPKON\n    nop')          # OUT (FEh): speaker
        P[0x735A] = (3, '    call SPKOFF')
        P[0x95F8] = (4, '    call SPKON\n    nop')
        P[0x95FF] = (3, '    call SPKOFF')
        P[0x962F] = (5, '    ld b,e\n    call SPKON\n    nop')
        P[0x9636] = (4, '    ld b,e\n    call SPKOFF')
        P[0x95B0] = (4, '    call VZOUT\n    nop')
    return P

GLUE_HYB = r'''
; ---------------------------------------------------------------- glue (non-banked 7800-7897)
    org $7800
MAPPER    equ $37
MAP_B0    equ $01
MAP_B1    equ $05
; copy 5000-57FF (dashboard) to/from bank-1 C000, interrupts restored as found
DSAVE:
    ld hl,$5000
    ld de,$C000
    jr DCOPY
DREST:
    ld hl,$C000
    ld de,$5000
DCOPY:
    push af
    ld a,i
    jp pe,.ie
    ld a,i                  ; NMOS Z80: read again if an interrupt hit the first LD A,I
.ie:
    di
    push af                 ; P/V = interrupts were on
    ld a,MAP_B1
    out (MAPPER),a
    ld bc,$0800
    ldir
    ld a,MAP_B0
    out (MAPPER),a
    pop af
    jp po,.noei
    ei
.noei:
    pop af
    ret
PRESENT:
    ret
GLUE_END:
    assert GLUE_END <= $7898
'''

def main():
    m, cov = load(f'{D}/run/start.mem', f'{D}/run/long.cov')
    iscode, tw = discover(m, cov)
    bad = verify_insns(m, iscode, D)
    assert not bad, bad
    # forced literals: strip label use by rendering raw text
    P = patches(m)
    for a in FORCE_LITERAL:
        t, l, _, _ = dis(m, a)
        P[a] = (l, '    ' + t)
    # free ranges: drop content (iscode 0 + mark) by turning into "skip" via layout sink trick
    hdr = ['; ELITE (ZX Spectrum 48K) for VZ300 + Benn Venn 128K - generated by tools/build.py',
           f'; TARGET={TARGET}',
           '    device zxspectrum48']
    free = FREE + ([(0x5D70, 0x6048), (0x5B00, 0x5D70), (0x7FC1, 0x8042), (0xFCEA, 0xFD41), (0x8085, 0x80D1)] if TARGET == 'vz' else [])
    if TARGET == 'vz':
        hdr.insert(2, '    include "../vz/vzabi.inc"')
    res, labels = build(m, iscode, tw, layout=LAYOUT, patches=P, header=hdr, free=free)
    if TARGET == 'hyb':
        res.append(GLUE_HYB)
        res.append('    savebin "elite_hyb.bin",$4000,$c000')
    else:
        res.append('ELITE_ENTRY equ L7366')
        res.append('ELITE_CLS2 equ LD61D+5')
        res.append('CLS_SPSAVE equ DD61B')
        res.append('PAGEVAR equ D70E3')
        res.append('PRCOL equ DD045')
        res.append('PRXOR equ $D548')
        res.append('    include "../vz/vz0.asm"')
        res.append('    savebin "elite_vz0.bin",$4000,$c000')
    open(f'{D}/src/elite_{TARGET}.asm', 'w').write('\n'.join(res) + '\n')
    r = subprocess.run([f'{D}/sjasm/sjasmplus', '--nologo', f'--sym=elite_{TARGET}.sym', f'elite_{TARGET}.asm'],
                       cwd=f'{D}/src', capture_output=True, text=True)
    out = r.stdout + r.stderr
    errs = [l for l in out.splitlines() if 'error' in l.lower()]
    print('\n'.join(errs[:30]) or 'assembled OK')
    return r.returncode

if __name__ == '__main__':
    sys.exit(main())
