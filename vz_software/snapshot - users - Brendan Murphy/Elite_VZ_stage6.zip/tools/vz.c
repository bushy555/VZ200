// Headless VZ300 + Benn Venn 128K test machine (model after MAME vtech1 + the Mercenary kit's VZ model).
//  - 0000-3FFF ROM (stand-in: FFh), 4000-67FF DOS area (RAM when port 37h bit0 = 1; two banks by bit1)
//  - 6800-6FFF: read = keyboard matrix (A0-A7 select rows, active low; D0-D5 keys; D6 cassette; D7 = FS, low during frame sync)
//               write = output latch (D0/D5 speaker, D3 mode(1), D4 CSS)
//  - 7000-77FF video RAM, 7800-B7FF internal RAM, B800-FFFF expansion RAM (bank by port 37h bit2)
//  - IRQ: level, asserted while FS is low (first FSLINES of the 312-line frame), bus = FFh
// Usage: vz <out> <frames> [frame:KEY:down ...]   env: LOADVZ=file | (BANK0=file(4000-FFFF) BANK1=file PC= SP=)
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "../z80core/z80.h"
extern uint8_t z80_port_hi;
#define LINE_T 227
#define LINES 312
#define FRAME_T (LINE_T*LINES)
#define FSLINES 57
static uint8_t mem[65536], exp1[0x4800], dos[2][0x2800];
static int expbank=0, dosram=0, dosbank=0, mapper=0;
static uint8_t latch=0, vzmode=0; static int latchw=0, spk_toggles=0;
static uint8_t keyrow[8]; // active-high pressed bits per VZ row
static unsigned long long T=0;
static uint16_t curpc; static uint8_t joy1=0xff, joy2=0xff;
static int stray_lo=-1, stray_hi=-1, stray_n=0; static uint8_t legit[65536];
static long fdbg=0;
static uint16_t ring[4096]; static int ringi=0;
static z80 z;
static long wpch[65536]; static int wplo=-1,wphi=-1;
static uint8_t writemap[65536];   // regions where writes are reported (1)
static int wrep=0, curfr=0, wrepfrom=100;
static uint8_t covf[65536]; static int covon=0; static uint8_t cov1[0x4800], covd1[0x2800];
#define COVOK(a) (covon && (a)>=0x4000 && ((a)>=0x6800 ? ((a)<0xb800||expbank==0) : (dosram&&dosbank==0)))
#define COVX(a) (covon && (a)>=0xb800 && expbank==1)
#define COVD(a) (covon && (a)>=0x4000 && (a)<0x6800 && dosram && dosbank==1)

static void map_exp(int b){ if(b==expbank) return; uint8_t t[0x4800]; memcpy(t,mem+0xb800,0x4800); memcpy(mem+0xb800,exp1,0x4800); memcpy(exp1,t,0x4800); expbank=b; }
static void map_dos(int on,int b){ // save current dos content back
  if(dosram) memcpy(dos[dosbank],mem+0x4000,0x2800);
  dosram=on; dosbank=b;
  if(dosram) memcpy(mem+0x4000,dos[dosbank],0x2800); else memset(mem+0x4000,0xff,0x2800);
}
// ---- cassette: TAPEOUT=file.wav records the latch cassette bits (1,2); TAPEIN=file.wav plays into
//      keyboard bit 6 from frame TAPESTART, at speed TAPESPEED (1.0 = nominal), TAPENOISE = flip probability
#define WAVRATE 44100
static unsigned char *tout=0; static long toutn=0, toutcap=0; static int tlevel=0; static unsigned long long tlastT=0;
static unsigned char *tin=0; static long tinn=0; static unsigned long long tinT0=0; static int tinon=0; static double tspeed=1.0, tnoise=0;
static void tout_adv(void){ if(!tout) return; long want=(long)((double)T*WAVRATE/(LINE_T*LINES*50.08)); while(toutn<want){ if(toutn>=toutcap){ toutcap=toutcap*2+65536; tout=realloc(tout,toutcap);} tout[toutn++]=tlevel?200:56; } }
static int tin_bit(void){ if(!tinon||T<tinT0) return 1; double t=(double)(T-tinT0)/(LINE_T*LINES*50.08)*tspeed; long i=(long)(t*WAVRATE); if(i>=tinn) return 1; int b=tin[i]>128; if(tnoise>0 && (rand()/(double)RAND_MAX)<tnoise) b^=1; return b; }
static void wavwrite(const char*fn,unsigned char*d,long n){ FILE*f=fopen(fn,"wb"); unsigned int v; fwrite("RIFF",1,4,f); v=36+n; fwrite(&v,4,1,f); fwrite("WAVEfmt ",1,8,f); v=16; fwrite(&v,4,1,f); unsigned short s=1; fwrite(&s,2,1,f); fwrite(&s,2,1,f); v=WAVRATE; fwrite(&v,4,1,f); fwrite(&v,4,1,f); fwrite(&s,2,1,f); s=8; fwrite(&s,2,1,f); fwrite("data",1,4,f); v=n; fwrite(&v,4,1,f); fwrite(d,1,n,f); fclose(f); }
static void wavread(const char*fn){ FILE*f=fopen(fn,"rb"); fseek(f,0,SEEK_END); long n=ftell(f); fseek(f,44,SEEK_SET); tin=malloc(n); tinn=fread(tin,1,n-44,f); fclose(f); }
static int fs_low(){ return (T%FRAME_T) < (unsigned long long)FSLINES*LINE_T; }
static uint8_t rb(void*u,uint16_t a){
  if(a>=0x6800&&a<0x7000){ uint8_t r=0x3f; for(int i=0;i<8;i++) if(!(a&(1<<i))) r&=~keyrow[i]; if(tin_bit()) r|=0x40; if(!fs_low()) r|=0x80; return r; }
  if(COVOK(a)) covf[a]|=1; else if(COVX(a)) cov1[a-0xb800]|=1; else if(COVD(a)) covd1[a-0x4000]|=1;
  return mem[a];
}
static void wb(void*u,uint16_t a,uint8_t v){
  if(a<0x4000) return;
  if(a<0x6800){ if(!dosram) return; if(a>=wplo&&a<=wphi&&!(expbank==1&&curpc>=0xb800)&&(!getenv("WP3D")||mem[0xC80A]<4||mem[0xC80A]>=13)) wpch[curpc]++; }
  else if(a<0x7000){ if(((latch^v)&0x21)) spk_toggles++; if(tout && ((latch^v)&6)){ tout_adv(); tlevel=(v&6)!=0; } latch=v; latchw++; return; }
  if(wrep && curfr>=wrepfrom && writemap[a] && stray_n<200){ stray_n++; fprintf(stderr,"WRITE %04x=%02x pc=%04x bank=%d\n",a,v,curpc,expbank); if(stray_n==1&&getenv("WRING")){ fprintf(stderr,"stack %04x:",z.sp); for(int k=0;k<16;k+=2) fprintf(stderr," %04x",mem[(uint16_t)(z.sp+k)]|mem[(uint16_t)(z.sp+k+1)]<<8); fprintf(stderr," hl=%04x de=%04x bc=%04x\n",z.l|z.h<<8,z.e|z.d<<8,z.c|z.b<<8); fprintf(stderr,"ring:"); for(int k=4096-400;k<4096;k++){ uint16_t p=ring[(ringi+k)&4095]; if(k>4096-400 && p==ring[(ringi+k-1)&4095]) continue; fprintf(stderr," %04x",p);} fprintf(stderr,"\n"); } }
  if(curfr>=wrepfrom&&a>=stray_lo&&a<=stray_hi&&!legit[a]&&stray_n<200&&expbank==0){ stray_n++; fprintf(stderr,"STRAY %04x pc=%04x\n",a,curpc); }
  if(COVOK(a)){ if(!(covf[a]&1)) covf[a]|=4; covf[a]|=2; } else if(COVX(a)){ if(!(cov1[a-0xb800]&1)) cov1[a-0xb800]|=4; cov1[a-0xb800]|=2; } else if(COVD(a)){ if(!(covd1[a-0x4000]&1)) covd1[a-0x4000]|=4; covd1[a-0x4000]|=2; }
  mem[a]=v;
}
static uint8_t pin(z80*z,uint8_t lo){
  { static int jf=-1; if(jf<0) jf=getenv("JOYFLOAT")?atoi(getenv("JOYFLOAT")):0; if(jf==1 && (lo==0x2c||lo==0x29)) return (uint8_t)rand(); if(jf==2 && (lo==0x2c||lo==0x29)) return 0x00; if(jf==3 && (lo==0x2c||lo==0x29)) return z->pc>>8; }
  if(lo==0x2c) return joy1; if(lo==0x29) return joy2;
  return 0xff;
}
static void pout(z80*z,uint8_t lo,uint8_t v){
  if(lo==0x37){ mapper=v; map_dos(v&1,(v>>1)&1); map_exp((v>>2)&1); }
  if(lo==0x3a){ vzmode=v; }
}
// VZ keys: name -> row,mask (MAME vtech1)
struct K { const char*n; int r; int m; } KT[]={
 {"R",0,0x20},{"Q",0,0x10},{"E",0,0x08},{"W",0,0x02},{"T",0,0x01},
 {"F",1,0x20},{"A",1,0x10},{"D",1,0x08},{"CTRL",1,0x04},{"S",1,0x02},{"G",1,0x01},
 {"V",2,0x20},{"Z",2,0x10},{"C",2,0x08},{"SHIFT",2,0x04},{"X",2,0x02},{"B",2,0x01},
 {"4",3,0x20},{"1",3,0x10},{"3",3,0x08},{"2",3,0x02},{"5",3,0x01},
 {"M",4,0x20},{"SPACE",4,0x10},{",",4,0x08},{".",4,0x02},{"N",4,0x01},
 {"7",5,0x20},{"0",5,0x10},{"8",5,0x08},{"-",5,0x04},{"9",5,0x02},{"6",5,0x01},
 {"U",6,0x20},{"P",6,0x10},{"I",6,0x08},{"RETURN",6,0x04},{"O",6,0x02},{"Y",6,0x01},
 {"J",7,0x20},{";",7,0x10},{"K",7,0x08},{":",7,0x04},{"L",7,0x02},{"H",7,0x01},
 {"JUP",100,1},{"JDOWN",100,2},{"JLEFT",100,4},{"JRIGHT",100,8},{"JFIRE",100,16},{0,0,0}};
static void dump(const char*fn){ // vram + latch + regs for python renderer
  FILE*f=fopen(fn,"wb"); fwrite(mem+0x7000,1,0x800,f); fputc(latch,f); fclose(f);
}
int main(int argc,char**argv){
  memset(mem,0xff,0x4000);
  const char*out=argv[1]; int frames=atoi(argv[2]);
  z80_init(&z); z.read_byte=rb; z.write_byte=wb; z.port_in=pin; z.port_out=pout;
  if(getenv("LOADVZ")){ FILE*f=fopen(getenv("LOADVZ"),"rb"); uint8_t h[24]; fread(h,1,24,f); int st=h[22]|h[23]<<8; int n=fread(mem+st,1,65536-st,f); fclose(f);
    z.pc=st; z.sp=0x79ff; fprintf(stderr,"loaded %d bytes at %04x\n",n,st); }
  else { FILE*f=fopen(getenv("BANK0"),"rb"); uint8_t*b=malloc(0xc000); fread(b,1,0xc000,f); fclose(f);
    memcpy(dos[0],b,0x2800); memcpy(mem+0x7000,b+0x3000,0x9000); // 7000-FFFF
    dosram=0; map_dos(1,0); mapper=1;
    if(getenv("BANK1")){ f=fopen(getenv("BANK1"),"rb"); fread(exp1,1,0x4800,f); fclose(f);}
    z.pc=strtol(getenv("PC"),0,16); z.sp=strtol(getenv("SP"),0,16); latch=0x08; }
  if(getenv("LEGIT")){ FILE*b=fopen(getenv("LEGIT"),"rb"); fread(legit,1,65536,b); fclose(b); sscanf(getenv("STRAYR"),"%x-%x",&stray_lo,&stray_hi);}
  if(getenv("WREP")){ // comma list lo-hi
    char buf[1024]; strcpy(buf,getenv("WREP")); for(char*t=strtok(buf,",");t;t=strtok(NULL,",")){int lo,hi; sscanf(t,"%x-%x",&lo,&hi); for(int a=lo;a<=hi;a++) writemap[a]=1;} wrep=1; }
  // key script
  int nk=argc-3; struct { int f; int r; int m; int d; } *KS=calloc(nk+1,sizeof*KS);
  for(int i=0;i<nk;i++){ char name[32]; int f,d; char*s=argv[3+i]; char*c1=strchr(s,':'); *c1=0; f=atoi(s); char*c2=strchr(c1+1,':'); *c2=0; strcpy(name,c1+1); d=atoi(c2+1);
    KS[i].f=f; KS[i].d=d; KS[i].r=-1; for(int k=0;KT[k].n;k++) if(!strcmp(KT[k].n,name)){KS[i].r=KT[k].r;KS[i].m=KT[k].m;} if(KS[i].r<0){fprintf(stderr,"bad key %s\n",name);return 1;} }
  char*shots=getenv("SHOTS");
  if(getenv("WPCH")) sscanf(getenv("WPCH"),"%x-%x",&wplo,&wphi);
  if(getenv("TAPEOUT")) { tout=malloc(65536); toutcap=65536; }
  if(getenv("TAPEIN")) wavread(getenv("TAPEIN"));
  if(getenv("TAPESPEED")) tspeed=atof(getenv("TAPESPEED"));
  if(getenv("TAPENOISE")) tnoise=atof(getenv("TAPENOISE"));
  int tstart=getenv("TAPESTART")?atoi(getenv("TAPESTART")):-1;
  long trapromdone=0; int halted_frames=0;
  for(int fr=0;fr<frames;fr++){ curfr=fr;
    for(int i=0;i<nk;i++) if(KS[i].f==fr){ if(KS[i].r==100){ if(KS[i].d) joy1&=~KS[i].m; else joy1|=KS[i].m; } else if(KS[i].d) keyrow[KS[i].r]|=KS[i].m; else keyrow[KS[i].r]&=~KS[i].m; }
    { static int jf=-2, ja; if(jf==-2){ jf=-1; if(getenv("JUMPAT")) sscanf(getenv("JUMPAT"),"%d:%x",&jf,&ja);} if(fr==jf){ setenv("JUMPPEND","1",1);} }
    if(fr==tstart && tin){ tinon=1; tinT0=T; fprintf(stderr,"TAPE start frame %d\n",fr); }
    unsigned long long end=(unsigned long long)(fr+1)*FRAME_T;
    while(T<end){
      if(fs_low() && z.iff1 && !z.int_pending) z80_gen_int(&z, getenv("BUSFF")?0xff:(uint8_t)rand());
      curpc=z.pc; ring[ringi++&4095]=z.pc; if(!covon && getenv("COV") && z.pc==strtol(getenv("COVPC"),0,16)) covon=1;
      if(getenv("JUMPPEND") && expbank==0 && z.iff1 && z.pc>=0x8000 && z.pc<0xb800 && z.sp>=0xff00){ int ja; sscanf(strchr(getenv("JUMPAT"),':')+1,"%x",&ja); unsetenv("JUMPPEND"); z.sp-=2; mem[z.sp]=z.pc&255; mem[(uint16_t)(z.sp+1)]=z.pc>>8; z.pc=ja; if(getenv("JUMPA")) z.a=strtol(getenv("JUMPA"),0,16); fprintf(stderr,"JUMP %04x frame %d\n",ja,fr); }
      { static int bp=-2; if(bp==-2) bp=getenv("BREAKPC")?(int)strtol(getenv("BREAKPC"),0,16):-1;
        if(z.pc==bp){ bp=-1; if(dosram) memcpy(dos[dosbank],mem+0x4000,0x2800); FILE*f=fopen(getenv("BREAKOUT"),"wb"); fwrite(dos[0],1,0x2800,f); fwrite(mem+0x6800,1,0x9800,f); fwrite(exp1,1,0x4800,f); fclose(f); fprintf(stderr,"BREAK %04x frame %d\n",z.pc,fr);} }
      { static int cp=-2; static long cnt=0, c1=0; static int f0=-1,f1=-1; if(cp==-2){ cp=getenv("COUNTPC")?(int)strtol(getenv("COUNTPC"),0,16):-1; if(getenv("COUNTWIN")) sscanf(getenv("COUNTWIN"),"%d-%d",&f0,&f1);} if(z.pc==cp && fr>=f0 && fr<f1) cnt++; if(fr==f1 && !c1){ c1=1; fprintf(stderr,"COUNT %ld in %d frames\n",cnt,f1-f0);} }

      if(!trapromdone && z.pc<0x4000 && getenv("TRAPROM")){ trapromdone=1; fprintf(stderr,"TRAPROM frame %d pc=%04x sp=%04x last:",fr,z.pc,z.sp); { int nn=getenv("TRAPN")?atoi(getenv("TRAPN")):64; uint16_t lp=0; for(int k=4096-nn;k<4096;k++){ uint16_t p=ring[(ringi+k)&4095]; if(p>=0x6000&&p<0x6800&&lp>=0x6000&&lp<0x6800){lp=p;continue;} lp=p; fprintf(stderr," %04x",p);} } fprintf(stderr,"\n"); }
      unsigned long c0=z.cyc; uint16_t ppc=z.pc; int pb=expbank; z80_step(&z); T+=z.cyc-c0;
      { static long long hist[512]; static int h0=-2,h1; static int hd=0; if(h0==-2){ h0=-1; if(getenv("PROFH")) sscanf(getenv("PROFH"),"%d-%d",&h0,&h1);} 
        if(h0>=0 && fr>=h0 && fr<h1) hist[(ppc>>8)+((pb&&ppc>=0xb800)?256:0)]+=z.cyc-c0;
        if(h0>=0 && fr==h1 && !hd){ hd=1; long long t=0; for(int i=0;i<512;i++) t+=hist[i]; for(int k=0;k<25;k++){ int bi=0; for(int i=0;i<512;i++) if(hist[i]>hist[bi]) bi=i; if(!hist[bi]) break; fprintf(stderr,"PAGE %s%02x00 %.1f%%\n",bi>=256?"b1:":"",bi&255,100.0*hist[bi]/t); hist[bi]=0; } } }
      { static int m1=-2,m2,m3; static long c1=0,c3=0,mx1=0,mx3=0,hist[64]; if(m1==-2){ m1=-1; if(getenv("MAXPER")) sscanf(getenv("MAXPER"),"%x,%x,%x",&m1,&m2,&m3);} 
        if(m1>=0 && expbank==0){ if(z.pc==m1) c1++; if(z.pc==m3) c3++; if(z.pc==m2){ if(c1>mx1) mx1=c1; if(c3>mx3) mx3=c3; hist[c1>=630?63:c1/10]++; c1=0; c3=0; } }
        if(m1>=0 && fr==frames-1 && T+20>end){ static int dn=0; if(!dn){ dn=1; fprintf(stderr,"MAXPER max1 %ld max3 %ld hist:",mx1,mx3); for(int i=0;i<64;i++) if(hist[i]) fprintf(stderr," %d:%ld",i*10,hist[i]); fprintf(stderr,"\n"); } } }
      if(getenv("CIRCLOG") && expbank==0){ static uint8_t snap[4096]; static int act=0; static int nlog=0;
        if(z.pc==0x86EE && !act && nlog<400){ memcpy(snap,mem+0x4000,4096); act=1; }
        else if(z.pc==0x86EC && act){ act=0; nlog++; int b=mem[0x861B],c=mem[0x861A],f=mem[0x861C],r=mem[0x861D],fill=mem[0x8629];
          int cx=128+((f&1)?b:-b), cy=64+((f&2)?-c:c); int n=0; double dmin=1e9,dmax=-1; int y0=999,y1=-1,x0=999,x1=-1;
          for(int a=0;a<4096;a++){ uint8_t d=mem[0x4000+a]^snap[a]; if(!d) continue; int y=((a>>5)&0xC0)|((a>>8)&7)|(((a>>5)&7)<<3); int xb=(a&31)*8;
            for(int k=0;k<8;k++) if(d&(0x80>>k)){ int x=xb+k; n++; double dd=sqrt((double)(x-cx)*(x-cx)+(double)(y-cy)*(y-cy)); if(dd<dmin)dmin=dd; if(dd>dmax)dmax=dd; if(y<y0)y0=y; if(y>y1)y1=y; if(x<x0)x0=x; if(x>x1)x1=x; } }
          fprintf(stderr,"CIRC fl=%02x b=%d c=%d r=%d fill=%d cx=%d cy=%d n=%d dist %.1f-%.1f bbox x%d-%d y%d-%d\n",f,b,c,r,fill,cx,cy,n,dmin,dmax,x0,x1,y0,y1); } }
      { static int rn=-1; static int rlo[8],rhi[8],rb[8]; static long long rc[8]; static int rd=0;
        if(rn==-1){ rn=0; char*e=getenv("PROFR"); if(e){ char b[512]; strcpy(b,e); for(char*t=strtok(b,",");t&&rn<8;t=strtok(NULL,",")){ rb[rn]=0; if(*t=='b'){rb[rn]=1;t++;} sscanf(t,"%x-%x",&rlo[rn],&rhi[rn]); rn++; } } }
        if(rn>0 && fr>=1000 && fr<4000){ for(int i=0;i<rn;i++) if(ppc>=rlo[i]&&ppc<=rhi[i]&&(!rb[i]||pb)) rc[i]+=z.cyc-c0; }
        if(rn>0 && fr==4000 && !rd){ rd=1; for(int i=0;i<rn;i++) fprintf(stderr,"RANGE %04x-%04x %lld\n",rlo[i],rhi[i],rc[i]); } }
      { static long long prof[8]; static int pw0=-1,pw1=-1,done=0; static uint16_t wlo,whi; if(pw0==-1){ if(getenv("PROF")) sscanf(getenv("PROF"),"%d-%d-%hx-%hx",&pw0,&pw1,&wlo,&whi); else pw0=-2; }
        if(pw0>=0 && fr>=pw0 && fr<pw1){ int k= (pb&&ppc>=0xb800)?1 : (ppc>=wlo&&ppc<=whi)?2 : (ppc>=0x5d70&&ppc<0x6048)?3 : 0; prof[k]+=z.cyc-c0; }
        if(pw0>=0 && fr==pw1 && !done){ done=1; long long t=prof[0]+prof[1]+prof[2]+prof[3]; fprintf(stderr,"PROF game %lld bank1 %lld wait %lld glue %lld\n",prof[0],prof[1],prof[2],prof[3]);} }
    }
    if(shots){ char buf[2048]; strcpy(buf,shots); for(char*t=strtok(buf,",");t;t=strtok(NULL,",")) if(atoi(t)==fr){ char fn[512]; sprintf(fn,"%s_%d.vram",out,fr); dump(fn);} }
  }
  char fn[512]; sprintf(fn,"%s.vram",out); dump(fn);
  if(getenv("WPCH")){ for(int i=0;i<65536;i++) if(wpch[i]) fprintf(stderr,"WPC %04x %ld\n",i,wpch[i]); }
  if(tout){ tout_adv(); wavwrite(getenv("TAPEOUT"),tout,toutn); }
  if(getenv("COV")){ FILE*c=fopen(getenv("COV"),"wb"); fwrite(covf,1,65536,c); fwrite(cov1,1,0x4800,c); fwrite(covd1,1,0x2800,c); fclose(c); }
  sprintf(fn,"%s.mem",out); FILE*m=fopen(fn,"wb"); fwrite(mem,1,65536,m); fwrite(exp1,1,0x4800,m); fclose(m);
  fprintf(stderr,"final pc %04x sp %04x iff %d expbank %d latchwrites %d spk %d\n",z.pc,z.sp,z.iff1,expbank,latchw,spk_toggles);
  return 0;
}
