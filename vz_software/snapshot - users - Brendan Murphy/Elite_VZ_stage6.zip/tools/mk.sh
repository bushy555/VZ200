#!/bin/bash
D=/tmp/claude-0/-home-claude/a0366c12-459b-5b6b-ade4-1434dea424af/scratchpad
cd $D
python3 vz/gen_dash.py >/dev/null && python3 vz/gen_bank1.py >/dev/null && (cd vz && ../sjasm/sjasmplus --nologo --sym=vz1.sym vz1.asm | grep -i "error" | grep -v "(0 errors)\|Errors: 0")
python3 tools/b1syms.py
(cd vz && ../sjasm/sjasmplus --nologo --sym=dos1.sym dos1.asm | grep -i "error" | grep -v "(0 errors)\|Errors: 0")
TARGET=vz python3 -I tools/build.py | grep -v "Errors: 0" ; (cd src && ../sjasm/sjasmplus --nologo --sym=elite_vz.sym elite_vz.asm | grep -iE "error" | grep -v "(0 errors)\|Errors: 0")
true
