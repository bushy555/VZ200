# Algorithmic Z80 disassembler (decoding per "Decoding Z80 opcodes")
import sys
R=['b','c','d','e','h','l','(hl)','a']
RP=['bc','de','hl','sp'];RP2=['bc','de','hl','af']
CC=['nz','z','nc','c','po','pe','p','m']
ALU=['add a,','adc a,','sub ','sbc a,','and ','xor ','or ','cp ']
ROT=['rlc','rrc','rl','rr','sla','sra','sll','srl']
IM=['0','0','1','2','0','0','1','2']
BLI={(4,0):'ldi',(4,1):'cpi',(4,2):'ini',(4,3):'outi',(5,0):'ldd',(5,1):'cpd',(5,2):'ind',(5,3):'outd',
     (6,0):'ldir',(6,1):'cpir',(6,2):'inir',(6,3):'otir',(7,0):'lddr',(7,1):'cpdr',(7,2):'indr',(7,3):'otdr'}
def h2(v):return '$%02x'%v
def h4(v):return '$%04x'%v
def dis(m,pc,labels=None):
    """returns (text,length,targets(list),is_end)"""
    start=pc
    def b(o=0):return m[(pc+o)&0xffff]
    def lab(a):
        if labels and a in labels: return labels[a]
        return h4(a)
    p0=pc;ix=None
    op=m[pc&0xffff];pc+=1
    if op in (0xdd,0xfd):
        ix='ix' if op==0xdd else 'iy';op=m[pc&0xffff];pc+=1
        if op in (0xdd,0xfd,0xed):
            return ('db '+h2(m[start]),1,[],False)
    def rr(i,disp=None):
        if ix is None: return R[i]
        if i==6:
            d=disp
            return '(%s%+d)'%(ix,d-256 if d>127 else d)
        return R[i]
    def hl(): return ix or 'hl'
    targets=[];end=False
    if op==0xcb:
        if ix:
            d=m[pc&0xffff];pc+=1;op2=m[pc&0xffff];pc+=1
            x,y,z=op2>>6,(op2>>3)&7,op2&7
            mem='(%s%+d)'%(ix,d-256 if d>127 else d)
            t=[ROT[y]+' '+mem,'bit %d,%s'%(y,mem),'res %d,%s'%(y,mem),'set %d,%s'%(y,mem)][x]
            return (t,pc-start,[],False)
        op2=m[pc&0xffff];pc+=1;x,y,z=op2>>6,(op2>>3)&7,op2&7
        t=[ROT[y]+' '+R[z],'bit %d,%s'%(y,R[z]),'res %d,%s'%(y,R[z]),'set %d,%s'%(y,R[z])][x]
        return (t,pc-start,[],False)
    if op==0xed:
        op2=m[pc&0xffff];pc+=1;x,y,z=op2>>6,(op2>>3)&7,op2&7;p,q=y>>1,y&1
        t=None
        if x==1:
            if z==0:t='in %s(c)'%('' if y==6 else R[y]+',')
            elif z==1:t='out (c),%s'%('0' if y==6 else R[y])
            elif z==2:t=('sbc hl,' if q==0 else 'adc hl,')+RP[p]
            elif z==3:
                nn=m[pc&0xffff]|m[(pc+1)&0xffff]<<8;pc+=2
                t='ld (%s),%s'%(lab(nn),RP[p]) if q==0 else 'ld %s,(%s)'%(RP[p],lab(nn))
            elif z==4:t='neg'
            elif z==5:t='retn' if y!=1 else 'reti';end=True
            elif z==6:t='im '+IM[y]
            elif z==7:t=['ld i,a','ld r,a','ld a,i','ld a,r','rrd','rld','nop','nop'][y]
        elif x==2 and z<=3 and y>=4:t=BLI[(y,z)]
        if t is None:t='db $ed,'+h2(op2)
        return (t,pc-start,[],end)
    x,y,z=op>>6,(op>>3)&7,op&7;p,q=y>>1,y&1
    disp=None
    def needdisp(*idx):
        nonlocal pc,disp
        if ix and any(i==6 for i in idx):
            disp=m[pc&0xffff];pc+=1
    def n():
        nonlocal pc;v=m[pc&0xffff];pc+=1;return v
    def nn():
        nonlocal pc;v=m[pc&0xffff]|m[(pc+1)&0xffff]<<8;pc+=2;return v
    t=None
    if x==0:
        if z==0:
            if y==0:t='nop'
            elif y==1:t="ex af,af'"
            else:
                d=n();a=(pc+(d-256 if d>127 else d))&0xffff;targets.append(a)
                t=['djnz ','jr ','jr nz,','jr z,','jr nc,','jr c,'][y-2]+lab(a)
                if y==3:end=True
        elif z==1:
            if q==0:
                v=nn();t='ld %s,%s'%(hl() if p==2 else RP[p],lab(v) if (labels and v in labels) else h4(v))
            else:t='add %s,%s'%(hl(),hl() if p==2 else RP[p])
        elif z==2:
            if p<2:t=['ld (bc),a','ld a,(bc)','ld (de),a','ld a,(de)'][p*2+q]
            else:
                v=nn();a=lab(v)
                t=['ld (%s),%s'%(a,hl()),'ld %s,(%s)'%(hl(),a),'ld (%s),a'%a,'ld a,(%s)'%a][(p-2)*2+q]
        elif z==3:t=('inc ' if q==0 else 'dec ')+(hl() if p==2 else RP[p])
        elif z in (4,5):needdisp(y);t=('inc ' if z==4 else 'dec ')+rr(y,disp)
        elif z==6:needdisp(y);v=n();t='ld %s,%s'%(rr(y,disp),h2(v))
        else:t=['rlca','rrca','rla','rra','daa','cpl','scf','ccf'][y]
    elif x==1:
        if op==0x76:t='halt'
        else:
            needdisp(y,z)
            a=rr(y,disp) if z==6 or y==6 else R[y] if not ix else rr(y,disp)
            b_=rr(z,disp)
            if ix and (y==6 or z==6):
                a=rr(y,disp) if y==6 else R[y];b_=rr(z,disp) if z==6 else R[z]
            elif ix:
                a={4:ix+'h',5:ix+'l'}.get(y,R[y]);b_={4:ix+'h',5:ix+'l'}.get(z,R[z])
            t='ld %s,%s'%(a,b_)
    elif x==2:
        needdisp(z);t=ALU[y]+rr(z,disp)
    else:
        if z==0:t='ret '+CC[y]
        elif z==1:
            if q==0:t='pop '+(hl() if p==2 else RP2[p])
            else:
                t=['ret','exx','jp (%s)'%hl(),'ld sp,'+hl()][p]
                if p in(0,2):end=True
        elif z==2:a=nn();targets.append(a);t='jp %s,%s'%(CC[y],lab(a))
        elif z==3:
            if y==0:a=nn();targets.append(a);t='jp '+lab(a);end=True
            elif y==2:t='out (%s),a'%h2(n())
            elif y==3:t='in a,(%s)'%h2(n())
            elif y==4:t='ex (sp),'+hl()
            elif y==5:t='ex de,hl'
            elif y==6:t='di'
            else:t='ei'
        elif z==4:a=nn();targets.append(a);t='call %s,%s'%(CC[y],lab(a))
        elif z==5:
            if q==0:t='push '+(hl() if p==2 else RP2[p])
            else:a=nn();targets.append(a);t='call '+lab(a)
        elif z==6:t=ALU[y]+h2(n())
        else:t='rst '+h2(y*8);
    return (t,pc-start,targets,end)

if __name__=='__main__':
    m=open(sys.argv[1],'rb').read()
    a=int(sys.argv[2],16);e=int(sys.argv[3],16)
    while a<e:
        t,l,_,_=dis(m,a)
        print('%04x  %-12s %s'%(a,' '.join('%02x'%m[(a+i)&0xffff] for i in range(l)),t))
        a+=l
