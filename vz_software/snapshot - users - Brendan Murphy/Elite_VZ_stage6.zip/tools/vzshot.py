"""Render VZ vram dumps (2048 bytes + latch) to PNG. usage: vzshot.py out.png file1 [file2 ...] (grid)"""
import sys
from PIL import Image, ImageDraw, ImageFont
CSS0=[(0,255,0),(255,255,0),(0,0,255),(255,0,0)]
CSS1=[(255,255,224),(0,255,255),(255,0,255),(255,128,0)]
SG=[(0,255,0),(255,255,0),(0,0,255),(255,0,0),(255,255,224),(0,255,255),(255,0,255),(255,128,0)]
font=ImageFont.load_default()
CH='@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_ !"#$%&\'()*+,-./0123456789:;<=>?'
def render(fn):
    d=open(fn,'rb').read(); v=d[:2048]; latch=d[2048]
    img=Image.new('RGB',(256,192)); px=img.load()
    if latch&0x08:
        pal=CSS1 if latch&0x10 else CSS0
        for y in range(64):
            for xb in range(32):
                b=v[y*32+xb]
                for p in range(4):
                    c=pal[(b>>(6-2*p))&3]
                    for dy in range(3):
                        px[(xb*4+p)*2,y*3+dy]=c; px[(xb*4+p)*2+1,y*3+dy]=c
    else:
        dr=ImageDraw.Draw(img)
        for i in range(512):
            b=v[i]; x0=(i%32)*8; y0=(i//32)*12
            if b&0x80:
                col=SG[(b>>4)&7]
                for q in range(4):
                    if b&(8>>q):
                        qx=x0+(q&1)*4; qy=y0+(q>>1)*6
                        dr.rectangle([qx,qy,qx+3,qy+5],fill=col)
            else:
                inv=bool(b&0x40); hi,lo=((255,190,120),(150,40,0)) if latch&0x10 else ((0,255,0),(0,40,0)); fg=lo if inv else hi; bg=hi if inv else lo
                dr.rectangle([x0,y0,x0+7,y0+11],fill=bg)
                dr.text((x0+1,y0+1),CH[b&63],fill=fg,font=font)
    return img
out=sys.argv[1]; files=sys.argv[2:]
cols=min(4,len(files)); rows=(len(files)+cols-1)//cols
G=Image.new('RGB',(256*cols+4*(cols-1),192*rows+4*(rows-1)),(40,40,40))
for i,f in enumerate(files): G.paste(render(f),((i%cols)*260,(i//cols)*196))
G=G.resize((G.width*2,G.height*2),Image.NEAREST) if len(files)<=2 else G
G.save(out)
