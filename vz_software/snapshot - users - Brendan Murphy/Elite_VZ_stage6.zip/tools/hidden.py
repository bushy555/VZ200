import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from gen import *
m,cov=load(sys.argv[1],sys.argv[2])
iscode,tw=discover(m,cov)
lo,hi=int(sys.argv[3],16),int(sys.argv[4],16)
OPS={0x21:'ld hl',0x11:'ld de',0x01:'ld bc',0x31:'ld sp',0x22:'ld (),hl',0x2a:'ld hl,()',0x32:'ld (),a',0x3a:'ld a,()',0xc3:'jp',0xcd:'call',0xca:'jp z',0xc2:'jp nz',0xda:'jp c',0xd2:'jp nc',0xcc:'call z',0xc4:'call nz',0xdc:'call c',0xd4:'call nc'}
hits=[]
for a in range(LO,HI-2):
    if iscode[a]: continue
    w=m[a+1]|m[a+2]<<8
    if lo<=w<hi and m[a] in OPS: hits.append((a,OPS[m[a]],w))
    if m[a] in (0xdd,0xfd) and m[a+1] in (0x21,0x22,0x2a) and lo<=(m[a+2]|m[a+3]<<8)<hi: hits.append((a,'ix/iy',m[a+2]|m[a+3]<<8))
    if m[a]==0xed and m[a+1] in (0x43,0x4b,0x53,0x5b,0x73,0x7b) and lo<=(m[a+2]|m[a+3]<<8)<hi: hits.append((a,'ed',m[a+2]|m[a+3]<<8))
# also plain words in data (possible pointer tables), count runs
print(len(hits))
for a,o,w in hits: print('%04x %-9s %04x  ctx %s'%(a,o,w,m[a-3:a+5].hex()))
