"""Build ELITE.VZ for VZ300 + Benn Venn 128K (VZ300 mode) from the assembled port.
Same scheme as the Mercenary kit: load at 7AE9h, stage 2 runs from video RAM,
blocks packed with upkr (exoticorn; Z80 unpacker by Ped7g), which packs Elite about
1.6K smaller than ZX0 did, so the file fits under the Benn Venn SD loader's limit."""
import subprocess, re, os, sys
D = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
UPKR = f'{D}/ext2/upkr/target/release/upkr'
SJ = f'{D}/sjasm/sjasmplus'
L = 0x7AE9                      # .VZ load / start address
X = 0x7AF0                      # main split: 7800..X-1 (low, small), X..FFFF (high, in place)
P = f'{D}/pack'
os.makedirs(P, exist_ok=True)
main = bytearray(open(f'{D}/src/elite_vz0.bin', 'rb').read())
main[0xBE00 - 0x4000:0xC000 - 0x4000] = bytes(512)          # n^2 table: built by D1_INIT
# work areas whose start-up contents are never read (always written first; checked by
# watching first accesses over many random-play sessions): cleared so they pack to nothing
for lo, hi in ((0xA984, 0xA991), (0xA9A5, 0xA9AF),          # ship-line work space
               (0xD05F, 0xD080), (0xD082, 0xD0BC),          # loader leftovers, now variables
               (0xFFA9, 0xFFBE), (0xFFCE, 0xFFFF)):         # stack
    main[lo - 0x4000:hi - 0x4000 + 1] = bytes(hi - lo + 1)          # 4000h-FFFFh, bank 0
b1 = open(f'{D}/vz/elite_vz1.bin', 'rb').read()             # B800h-FFFFh, bank 1
d1 = open(f'{D}/vz/elite_dos1.bin', 'rb').read()            # 4000h-, DOS-area RAM bank 1
d1sym = {m.group(1): int(m.group(2), 16) for m in re.finditer(r'^(\w+): EQU 0x([0-9A-F]+)', open(f'{D}/vz/dos1.sym').read(), re.M)}
d1sym['D1_INIT'] = 0x458F
sym = {m.group(1): int(m.group(2), 16) for m in re.finditer(r'^(\w+): EQU 0x([0-9A-F]+)', open(f'{D}/src/elite_vz.sym').read(), re.M)}

def pk(name, data, back=False):
    open(f'{P}/{name}.bin', 'wb').write(data)
    subprocess.run([UPKR] + (['-r'] if back else []) + [f'{P}/{name}.bin', f'{P}/{name}.upk'], check=True, capture_output=True)
    packed = open(f'{P}/{name}.upk', 'rb').read()
    margin = 0
    if back:
        margin = int(subprocess.run([UPKR, '-r', '--margin', f'{P}/{name}.upk', '-'], capture_output=True, text=True).stdout)
    return packed, margin

dos, _ = pk('dos', bytes(main[0:0x2800]))
bank1, _ = pk('bank1', b1)
dos1, _ = pk('dos1', d1)
mlow, _ = pk('mlow', bytes(main[0x7800 - 0x4000:X - 0x4000]))
mhigh, delta = pk('mhigh', bytes(main[X - 0x4000:]), back=True)
assert L + 3 + delta <= X, ('in-place margin', hex(L + 3), delta)
print(f'(upkr) dos {len(dos)}  dos1 {len(dos1)}  bank1 {len(bank1)}  mlow {len(mlow)}  mhigh {len(mhigh)} (delta {delta})')

def vzs(t):
    return ','.join(str(ord(c) & 0x3F) for c in t)

boot = f'''
    DEVICE NONE
    OUTPUT "{P}/body.bin"
    ORG ${L:04X}
    jp BOOT1
MHIGH:
    INCBIN "{P}/mhigh.upk"
MHIGH_END EQU $-1
; ---- stage 1: runs at its load address; moves stage 2 + small blob into video RAM
BOOT1:
    di
    ld sp,$7800
    ld hl,$7000                     ; top half of the text screen: blank, with a message
    ld de,$7001
    ld bc,$00FF
    ld (hl),$20
    ldir
    ld hl,MSG1
    ld de,$7040
    ld bc,MSG1_LEN
    ldir
    ld hl,MSG2
    ld de,$7080
    ld bc,MSG2_LEN
    ldir
    ld hl,STAGE2_SRC
    ld de,$7100
    ld bc,STAGE2_LEN
    ldir
    jp BOOT2
MSG1:
    DB {vzs("  ELITE: UNPACKING, PLEASE WAIT ")}
MSG1_LEN EQU $-MSG1
MSG2:
    DB {vzs("    (ABOUT 45 SECONDS)          ")}
MSG2_LEN EQU $-MSG2
STAGE2_SRC:
    DISP $7100
BOOT2:
    ld a,1
    out ($3A),a                     ; Benn Venn: VZ300 mode (expansion RAM at B800h)
    ld a,$01
    out ($37),a                     ; DOS area -> RAM bank 0, expansion bank 0
    ld hl,B1_SRC                    ; bank-1 blob -> 4000h (visible in both banks)
    ld de,$4000
    ld bc,B1_LEN
    ldir
    ld a,$05
    out ($37),a                     ; expansion bank 1
    exx
    ld de,$B800
    exx
    ld ix,$4000
    call upkr.unpack
    ld a,$03
    out ($37),a                     ; DOS-area RAM bank 1 (the VZ-resolution view)
    exx
    ld de,$4000
    exx
    ld ix,DOS1_SRC
    call upkr.unpack
    ld a,$07
    out ($37),a                     ; DOS bank 1 + expansion bank 1: build the bank-1 tables
    call ${d1sym["B1INIT"]:04X}
    ld a,$01
    out ($37),a                     ; DOS bank 0, expansion bank 0
    exx
    ld de,$4000
    exx
    ld ix,DOS_SRC
    call upkr.unpack
    exx
    ld de,$FFFF
    exx
    ld ix,MHIGH_END
    call upkrb.unpack          ; in place, X..FFFF, backwards
    exx
    ld de,$7800
    exx
    ld ix,MLOW_VID
    call upkr.unpack
    ld a,$03
    out ($37),a                     ; DOS bank 1: build its tables
    call ${d1sym["D1_INIT"]:04X}
    ld a,$01
    out ($37),a
    ; joystick interface check: with no interface the ports float (any value), which
    ; would look like a stick held over. A port whose 5 input bits are not all idle (1)
    ; on every one of 2048 reads is replaced by ld a,$FF.
    ld e,0
    ld bc,$0008
.js:
    in a,($2C)
    or $E0
    inc a
    jr z,.j1
    set 0,e
.j1:
    in a,($29)
    or $E0
    inc a
    jr z,.j2
    set 1,e
.j2:
    ex (sp),hl
    ex (sp),hl
    djnz .js
    dec c
    jr nz,.js
    ld hl,$FF3E                     ; ld a,$FF
    bit 0,e
    jr z,.k1
    ld (${sym["JIN1A"]:04X}),hl
    ld (${sym["JIN1B"]:04X}),hl
.k1:
    bit 1,e
    jr z,.k2
    ld (${sym["JIN2A"]:04X}),hl
    ld (${sym["JIN2B"]:04X}),hl
.k2:
    jp ${sym["VZSTART"]:04X}
    DEFINE UPKR_PROBS_ORIGIN $7600
    DEFINE UPKR_UNPACK_SPEED
    INCLUDE "{D}/tools/upkr/unpack_fwd.asm"
    INCLUDE "{D}/tools/upkr/unpack_back.asm"
MLOW_VID:
    INCBIN "{P}/mlow.upk"
VID_END:
    ASSERT VID_END <= $7600           ; 7600-773F: upkr probabilities, then the stack
    ENT
STAGE2_LEN EQU $-STAGE2_SRC
DOS_SRC:
    INCBIN "{P}/dos.upk"
B1_SRC:
    INCBIN "{P}/bank1.upk"
B1_LEN EQU $-B1_SRC
DOS1_SRC:
    INCBIN "{P}/dos1.upk"
FILE_END:
    ASSERT FILE_END <= $FF00          ; the loader's stack sits at the top of memory
'''
open(f'{P}/boot.asm', 'w').write(boot)
r = subprocess.run([SJ, '--nologo', f'--sym={P}/boot.sym', f'{P}/boot.asm'], capture_output=True, text=True)
txt = r.stdout + r.stderr
assert 'Errors: 0' in txt, txt
body = open(f'{P}/body.bin', 'rb').read()
name = b'ELITE'.ljust(16, b'\0')
hdr = b'VZF0' + name + b'\0' + bytes([0xF1]) + L.to_bytes(2, 'little')
assert len(hdr) == 24
out = sys.argv[1] if len(sys.argv) > 1 else f'{D}/out/ELITE.VZ'
os.makedirs(os.path.dirname(out), exist_ok=True)
open(out, 'wb').write(hdr + body)
print('wrote', out, len(hdr + body), 'bytes; load', hex(L), 'end', hex(L + len(body) - 1))
