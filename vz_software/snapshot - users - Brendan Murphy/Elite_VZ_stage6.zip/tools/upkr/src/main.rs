use std::env;
use std::fs;
// upkr (dependency-free build): upkr <in> <out> [-r] [-u] [-l N] [--margin]   (always the --z80 configuration)
fn main() {
    let mut config = upkr::Config::default();
    config.use_bitstream = true;
    config.bitstream_is_big_endian = true;
    config.invert_bit_encoding = true;
    config.simplified_prob_update = true;
    let mut level = 9u8;
    let mut reverse = false; let mut unpack = false; let mut margin = false;
    let mut files = vec![];
    let args: Vec<String> = env::args().skip(1).collect();
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "-r" => reverse = true,
            "-u" => unpack = true,
            "--margin" => margin = true,
            "-l" => { i += 1; level = args[i].parse().unwrap(); }
            a => files.push(a.to_string()),
        }
        i += 1;
    }
    let mut data = fs::read(&files[0]).unwrap();
    if reverse { data.reverse(); }
    if margin { println!("{}", upkr::calculate_margin(&data, &config).unwrap()); return; }
    let mut out = if unpack { upkr::unpack(&data, &config, 1 << 24).unwrap() } else { upkr::pack(&data, level, &config, None) };
    if reverse { out.reverse(); }
    eprintln!("{} -> {} bytes", data.len(), out.len());
    fs::write(&files[1], &out).unwrap();
}
