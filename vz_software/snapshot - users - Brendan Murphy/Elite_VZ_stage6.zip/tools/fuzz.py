import random,sys
ROWS=[['CS','Z','X','C','V'],['A','S','D','F','G'],['Q','W','E','R','T'],['1','2','3','4','5'],['0','9','8','7','6'],['P','O','I','U','Y'],['ENT','L','K','J','H'],['SPC','SS','M','N','B']]
keys=[k for r in ROWS for k in r]
seed=int(sys.argv[1]); n=int(sys.argv[2]); start=int(sys.argv[3]) if len(sys.argv)>3 else 400
r=random.Random(seed)
seq=['N@200+20','SPC@350+20']
f=start
while f<n:
    k=r.choice(keys); d=r.randint(3,60)
    # bias toward flight keys
    if r.random()<0.4: k=r.choice(['S','X','N','M','A','SPC','1','2','3','4','J','SS','CS'])
    seq.append(f'{k}@{f}+{d}'); f+=d+r.randint(0,40)
print(' '.join(seq))
