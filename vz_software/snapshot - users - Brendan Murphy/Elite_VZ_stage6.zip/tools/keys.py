ROWS=[['CS','Z','X','C','V'],['A','S','D','F','G'],['Q','W','E','R','T'],['1','2','3','4','5'],['0','9','8','7','6'],['P','O','I','U','Y'],['ENT','L','K','J','H'],['SPC','SS','M','N','B']]
K={k:(r,b) for r,row in enumerate(ROWS) for b,k in enumerate(row)}
import sys
# args: seq of key@frame[+dur]  -> prints spec key args
out=[]
for tok in sys.argv[1:]:
    k,rest=tok.split('@'); 
    f,d=(rest.split('+')+['6'])[:2]; f=int(f); d=int(d)
    r,b=K[k]; out+=['%d:%d:%d:1'%(f,r,b),'%d:%d:%d:0'%(f+d,r,b)]
print(' '.join(out))
