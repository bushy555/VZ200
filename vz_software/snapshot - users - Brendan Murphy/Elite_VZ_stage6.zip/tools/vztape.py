"""Decode a VZ Elite commander tape WAV (as written by vz/tape.asm). usage: vztape.py file.wav"""
import sys, wave
w = wave.open(sys.argv[1]); rate = w.getframerate(); d = w.readframes(w.getnframes())
lv = [b > 128 for b in d]
halves = []; last = lv[0]; n = 0
for v in lv:
    if v != last: halves.append(n); n = 0; last = v
    n += 1
thr = rate * 1.5 * 277.8e-6
bits = []; c = 0; i = 0
# align after a long pair
while not (halves[i] > thr and halves[i+1] > thr and halves[i] < rate*0.01): i += 1
i += 2
while i < len(halves):
    h = halves[i]; i += 1
    if h > rate*0.01: break
    if h < thr:
        c += 1
        if c == 6: bits.append(1); c = 0
    else:
        i += 1; bits.append(0); c = 0
sh = 0; k = 0
while k < len(bits):
    sh = ((sh << 1) | bits[k]) & 0xFF; k += 1
    if sh == 0xFE: break
def byte():
    global k
    v = 0
    for _ in range(8): v = (v << 1) | bits[k]; k += 1
    return v
b = byte()
while b == 0xFE: b = byte()
print('type', hex(b))
data = [byte() for _ in range(104)]
s = sum(data[:102]) & 0xFFFF
print('sum ok' if s == data[102] | data[103] << 8 else 'SUM BAD')
print(' '.join('%02x' % x for x in data[:102]))
