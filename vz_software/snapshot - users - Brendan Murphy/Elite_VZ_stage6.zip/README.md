﻿# Elite → VZ300: source kit (stage 6)

*Elite* (ZX Spectrum 48K, Firebird/Torus 1985) ported to the **Dick Smith VZ300 with the Benn Venn 128K RAM expansion**, built on the same VZ approach as the Mercenary port.



**Stage 6** is a fix release:

-
**SD loading.
** `ELITE.VZ` is down from 33,694 to 30,849 bytes, so it now ends at `F351h`, below the point where the Benn Venn SD loader seems to fail.

- **The Y/N hang at the title** is fixed for machines with no joystick interface.

- **Text-page title bars** are solid all the way across.

Everything else plays as in stage 5. It has only been tested in my VZ model, not on real hardware.

![Unpacking message, title, flight, a text page](scenes.png)



## Running it


1. Put the Benn Venn card in **VZ300 mode** (expansion RAM at `B800h`), as for Mercenary.

2. Load `ELITE.VZ` as a machine-code `.VZ` file, from the SD loader or from cassette. It loads at `7AE9h` and runs straight away.

3. **The screen says "ELITE: UNPACKING, PLEASE WAIT (ABOUT 45 SECONDS)"** above a block of garbage characters. That's normal: the garbage is the unpacker itself, running from video RAM. After about 45 seconds the title screen appears.

The file is 30,849 bytes and loads from `7AE9h` to `F351h`. Like Mercenary, it sets port `3Ah` to VZ300 mode and switches the DOS area `4000h`–`67FFh` to RAM (port `37h`), so the SD loader's DOS is switched out once the game runs.



## What changed in stage 6

### 
Loading from the Benn Venn SD loader


The SD error screen (a cluster number of `9596999A`, which is just game data) points to the loader keeping its file-system state in high RAM. A file long enough to reach that area overwrites the state while it loads, and the next cluster read then fails. 
That matches the Facebook report that nothing much over 31,200 bytes loads, which is an end address of about `F4B0h`. Mercenary (29,373 bytes, ending at `ED8Dh`) loads fine. 

Loading at `7B00h` wouldn't help: the start would be 23 bytes higher, but the end is what matters, and the end is set by the file length.

So the file had to get smaller. Stage 6 does it in three ways:


| Change | Bytes saved |
|---|---|
| 
Tables built at start-up instead of stored: pixel masks, colour tables, the ASCII→VZ table, bit counts, the empty-scanner copy, Elite's own n² table at `BE00h` | about 600 |
| The Spectrum font in bank 1 is cleared (text never shows as Spectrum pixels any more). The Spectrum dashboard image keeps only the parts the VZ panel reads: bars, condition light, compass, S area and missile row. The scanner-background buffer starts empty, since it's always saved before it's read | about 950 |
| 

Packer changed from ZX0 to **upkr** (rANS coding; packer by exoticorn, Z80 unpacker by Ped7g) | about 1,600 |
| Work areas that are always written before they are read start empty: stack, a ship-line work space, old loader leftovers that are now variables | about 100 |

**The cost is unpacking time.** upkr packs much tighter than ZX0 but unpacks far more slowly on a Z80: about 45 seconds instead of 1.3. That's why the loader now prints a message. If you load from cassette, the shorter file takes about 25 seconds less to load, so overall it's about 20 seconds slower than before.

**Not sure where the SD limit really is?

** `sdtest/` has seven small test files, `SDT29500.VZ` up to `SDT34000.VZ`, with lengths from 29,500 to 34,000 bytes. Each one checks its own contents after loading and prints "LOADED CORRECTLY - OK" or "DATA DAMAGED - FAILED". The largest one that loads OK shows the real limit on your SD loader. If a build ever needs more room, that number tells me how much there is.



### The title-screen Y/N hang.   

The game also reads the VZ joystick interface (ports `2Ch` and `29h`). On a VZ without one, those ports read whatever happens to be on the data bus. If that isn't all ones, it looks like a joystick held over and the fire button down. Elite waits for the keys to be released before it takes Y or N, so it hangs. My VZ model reproduces this exactly: with the joystick ports reading random values or zeros, stage 5 sticks at "LOAD NEW COMMANDER (Y/N)?" and ignores N.

Stage 6 tests both ports while it unpacks. If a port's five input bits aren't all idle on every one of 2,048 reads, it treats that port as having no joystick and stops reading it. With a joystick interface fitted, the idle reading passes the test and the sticks work as before. Don't hold a joystick over while the game is unpacking, or that port will be switched off for the session.

This is my best explanation for the other user's hang, and stage 5 fails the same way in the model. It's still worth knowing whether he has a joystick interface or anything else plugged into the expansion port.

### Text-page title bars

The dark square was a side effect of how text pages are shown, not a Spectrum leftover. On the Spectrum, Elite colours its titles by giving the characters cyan ink. Ink on a space is invisible, so the Spectrum never shows which cells got the colour. On the VZ, cyan ink becomes inverse video, so every cell matters. Elite's title code moves the cursor across two columns without printing in them, so those two cells kept the normal colour and showed as a dark gap in the bar.

Now any title row (the top two text rows, if they hold cyan text) is inverse all the way across.



### Cassette save output.  

Yes, the save goes to the cassette port. The routine drives the latch's two cassette-output bits, and also the speaker bit so you can hear it. That's why it comes through the speaker.

## Saving and loading commanders (stage 4)

Elite's own "Access Menu" is back, with the Spectrum tape calls replaced by VZ cassette routines. Connect a cassette recorder to the VZ as you would for `CSAVE`/`CLOAD`.

![The menu during a save, and after a load](tape_menu.png)

**To open the menu:**
- **When docked:** press **CTRL** (the Spectrum's SYMBOL SHIFT, as in the original).
- **At the title:** answer **Y** to "Load New Commander (Y/N)?".

**In the menu:**
- **1 Load New Commander:** type the commander's name and press RETURN, then press PLAY. To take the first commander on the tape, just press RETURN. The game reads past any commanders with other names. It shows "Found Commander …" when the load succeeds and "Tape Loading Error" if the checksum fails, in which case the commander in memory is left as it was. Press any key to give up waiting.
- **2 Save Commander:** type a name and press RETURN. At "Start tape, then press any key", start the recorder on RECORD and press a key. The save takes about 5 seconds, and you'll hear it through the VZ speaker. It ends with "Commander saved".
- **3 Exit:** leave the menu. After a load, the game restarts on the loaded commander, as on the Spectrum.

Several commanders can go one after another on the same tape, and the name picks which one loads.



**The recording.** The signal uses the VZ's own cassette encoding at about 600 baud, in the same frequencies and pulse shape as the VZ ROM. It's driven on the latch's cassette bits, and the loader reads the cassette input bit. A file holds a leader, a sync, a type byte, Elite's 102-byte commander block and a checksum.

These files are only meant to be loaded from inside Elite. The VZ ROM's `CLOAD` isn't expected to read them, since the ROM's own file header isn't used. I haven't tried that.

**How it was fitted in.** The original menu code had been overwritten by a ship blueprint when the code was relocated. It's rebuilt, calling Elite's own menu text, name input and messages, in three pieces of memory freed for it:
- the Spectrum buffer-copy loop at `7FC1h`
- the unused part of the Spectrum's IM2 table at `FCEAh`
- the end of the old tape area at `DA27h`

The cassette code itself is in bank 1 (`vz/tape.asm`). The commander block passes through a buffer at `7700h`, video RAM that text mode doesn't display.

**How it was tested.** The VZ model now records the cassette output to a WAV and can play a WAV back into the cassette input.
- Saved from a docked game, then loaded in a fresh session from the title. The status page showed the saved commander.
- Loads also succeeded with the tape running 20% slow and 20% fast, and with random glitches added to the signal.
- A deliberately damaged recording gave "Tape Loading Error".
- Pressing a key while waiting gave "Break" and returned to the menu.
- `tools/vztape.py` decodes a WAV of a save on a PC, which is useful for checking a real recording.

It hasn't been tried with a real recorder yet. If loads fail on real hardware, a recording of a save (a WAV made on a PC) would let me check the levels and timing.

## What changed in stage 3

### Cockpit panel

The dashboard is no longer a pixel-by-pixel conversion of the Spectrum's. It's a hand-drawn 128×21 bitmap (`vz/gen_dash.py`), with the live instruments drawn over it from the values Elite puts on its own Spectrum dashboard. The layout stays the Spectrum's: indicators on the left, scanner in the middle, indicators on the right.

![The panel bitmap with sample readings](panel.png)

- **Grid and symmetry.** Everything sits on one grid. The left and right columns mirror each other about the centre: label strip, yellow frame column, bar track, then a 2-pixel yellow frame against the scanner bay. Borders are a single pixel wide throughout.
- **Scanner.** A blue bay, set apart from the yellow frame, holds a symmetrical ellipse traced on the left half and mirrored. Three evenly spaced dotted range lines run across it, with the V of the field of view and centre ticks. Blips are drawn in yellow. Only scanner cells that differ from the empty Spectrum scanner are copied, so the static art never picks up stray pixels.
- **Bars.** All 13 bars have the same 2-pixel thickness, the same length (18 pixels between end caps) and the same spacing. Yellow is the filled part and red the empty part, matching the Spectrum's colours. Roll and dive (RL, DC) show a yellow marker in a red track, as on the Spectrum. The missile row shows one block per missile, with the Spectrum's missile colours.
- **Labels.** Each bar has its label in the strip beside it: FS AS FU CT LT AL and the missile icon on the left, SP RL DC 1 2 3 4 on the right. Labels alternate yellow and green so neighbouring rows don't merge.
- **Other instruments.** The condition light (top left of the bay) takes its colour from the Spectrum's. The compass (top right) shows the target dot in yellow when it is in front and red when it is behind, which is how the Spectrum's dot reads in 2-pixel form. The safe-zone **S** appears inside the station's zone.

The panel is redrawn every fourth frame, as before, into a buffer in bank 1, then copied to the screen in one go. The bars, missiles, light and S are rewritten in full each time. Only the scanner and compass area is restored from the bitmap first, so nothing is redrawn that doesn't need to be.



### View labels: 3-pixel font

FRONT VIEW, REAR VIEW, LEFT VIEW and RIGHT VIEW, the title lines and any other text Elite prints in the 3D view now use a new font that is 3 pixels high. It was designed for the VZ, not scaled down. Letters are 3 pixels wide, except M, N, R and W, which are wider so they stay legible. F, R, E and W are deliberately different shapes. Characters have 1 pixel between them, labels are centred where Elite centres them, and they appear yellow on blue.

The labels come from the text Elite prints, recorded as it prints it, not from its Spectrum pixels. So they also work for messages, countdowns and the title. A label is only rebuilt when its text changes.

### Fixes

- **Corruption in combat (likely the yellow line after dying).** One of Elite's drawing paths (`A89Bh`, used when ships break up) forced its line routine to draw into the Spectrum's old off-screen buffer at `C000h`. On the VZ that area now holds relocated code and variables, so explosion debris could overwrite live game data. A random-play test hit this and crashed, and stage 2b fails the same way. The bad data could then show up later, for example as a stray line and a missing header on the title screen. Fixed by removing the forced buffer switch.
- **Heading rule over the 3D view.** A text control in Elite draws a heading rule straight onto the screen. On the Spectrum the next buffer copy hid it on cockpit pages. It is now drawn only on text and chart pages.
- **Old dashboard flashing.** On pages that pause rendering (the title's "Load New Commander" prompt, the pause after GAME OVER), the refresh used to redraw the raw Spectrum dashboard for a frame. It now redraws the view and the new panel.



### Speed

The view conversion has a faster path for rows whose three Spectrum lines share a character cell (6 rows in 8), which saves 16 T-states per byte. Overall, flight renders 432 frames per 3,000 against 420 for stage 2b in the same scripted test (+3%), with the new panel included.

## Controls

Keys are where they are on the Spectrum: Spectrum CAPS SHIFT is VZ **SHIFT**, SYMBOL SHIFT is **CTRL**, ENTER is **RETURN**. (Corrected in stage 4: the earlier lists had the chart and page keys wrong. These are read from the game's key handling.)

**Flight**

| Key | Action |
|---|---|
| **S / X** | Dive / climb |
| **N / M** | Roll left / right |
| **SPACE / CTRL** | Speed up / slow down |
| **A** | Fire laser |
| **T / F / U** | Target missile / fire missile / unarm missile |
| **E** | ECM |
| **W** | Energy bomb (if fitted) |
| **Q** | Escape pod (if fitted) |
| **C** | Docking computer (if fitted) |
| **H** | Hyperspace to the selected system |
| **G + H** | Galactic hyperspace (if fitted) |
| **J** | Jump drive (in-system jump) |
| **1 2 3 4** | Front / rear / left / right view |
| **SHIFT** | Pause (SPACE to carry on) |

**Pages (flying or docked):** I galactic chart, O short-range chart, P data on the selected system, K market prices, L status, RETURN inventory. On the charts, N M S X move the cursor.

**Docked:** 1 launch, 2 buy cargo, 3 sell cargo, 4 equip ship, CTRL save/load commander menu.

**Joysticks:** up = S, down = X, left = N, right = M, fire = A (ports `2Ch` and `29h`, as for Mercenary). **Text pages:** `,` and `.` scroll long pages.

## Testing (in my VZ model only)

- **Loading:** after unpacking, every byte of memory matches the stage 5 packer's result except video RAM, where the loader runs.
- **Y/N at the title:** passes with the joystick ports reading idle (FFh), random values, zeros, and an address byte (what some machines put on an idle bus).
- **Pages:** title, status, data on Lave, equip ship. The title bars are solid.
- **Cassette:** saved a commander to a WAV, decoded it on the PC (checksum OK), loaded it back from the title: "Found Commander A", then the restart.
- **Panel:** after launch, the safe-zone S, condition light, compass dot, bars and scanner blips all show as in stage 5.
- **Random play:** 8 random key-and-joystick sessions of 15,000 frames, with a byte on the bus at every interrupt. No jumps into ROM, and every session ended on a working page (views, data, status, the save menu).

## Known limitations / next steps

- **Not yet run on real hardware.**
- **The SD limit is inferred, not measured.** The `sdtest` files will settle it.
- **Unpacking takes about 45 seconds.** If the SD loader turns out to take larger files than expected, I can go back to a faster packer for part of the file.

## Building

```
tools/mk.sh                       bank 1 (vz/gen_dash.py, vz/gen_bank1.py, vz1.asm), tools/b1syms.py,
                                  DOS bank 1 (vz/dos1.asm + vz/b1init.asm), bank 0 (tools/build.py)
python3 tools/mkvz.py             -> ELITE.VZ (needs the upkr packer, see tools/upkr/)
python3 tools/mksdtest.py         -> sdtest/SDT*.VZ
```

`tools/upkr/` holds the packer source, modified to build with no outside crates (`cargo build --release`), and the Z80 unpackers (forward and backward).

| File | What it is |
|---|---|
| `ELITE.VZ` | The playable file |
| `sdtest/SDT*.VZ` | SD-loader size test files |
| `vz/b1init.asm` | Start-up table builders for bank 1 (new; run from DOS bank 1) |
| `vz/mask_dash.py` | Clears the unused parts of the Spectrum dashboard image (new) |
| `vz/gen_dash.py` | Panel bitmap, 3-pixel font, instrument tables |
| `vz/cockpit.asm` | Panel renderer, scanner, compass, view labels (bank 1) |
| `vz/dos1.asm` | VZ-resolution drawing, the view picture, the text-token index (DOS-area RAM bank 1) |
| `vz/native.asm` | View presentation and clear (bank 1) |
| `vz/charttext.asm` | 3-pixel text on the chart pages (bank 1) |
| `vz/tape.asm` | Cassette save/load (bank 1); the menu is at the end of `vz/vz0.asm` |
| `vz/vz0.asm`, `vz/gen_bank1.py`, `vz/vzabi.inc` | VZ layer: glue, text pages, keyboard and joystick |
| `src/elite_vz.asm` | The VZ port (generated): relocated source plus every patch |
| `src/elite_zx.asm` | Spectrum Elite as labelled source (byte-identical) |
| `bin/` | Assembled banks, symbols |
| `tools/` | Generator, build, packer, Spectrum emulator, VZ test machine, screenshot renderer, fuzzers. Paths assume the original workspace. |

## Earlier stages



### Stage 5



#### The 3D view is drawn at VZ resolution

Until now Elite drew every frame into the Spectrum's 256×128 screen, and the VZ layer shrank that to 128×43 (each VZ pixel = 2×3 Spectrum pixels). Now Elite's drawing calls are caught where they start, and the picture is drawn straight onto a VZ-format copy of the view:

- **Ship lines** are caught at Elite's line routine (`B0E0h`). The start point, direction, length and slope Elite has worked out become the two end points. A line-drawing routine for the VZ's pixels then joins them. The lines are thinner and cleaner than the shrunken ones. When Elite draws in XOR mode, for dark lines across a big sun, that is kept too.
- **The sun and planets** are caught at Elite's circle routine (`86E9h`): filled for the sun, outline for planets. The circle is drawn row by row with the VZ's 2:3 pixel shape taken into account, so it stays round. The rare circles whose position Elite gives in a different form still go the old way: Elite draws them Spectrum-style and only their rows are converted.
- **Star dust and explosion particles** are plotted at VZ resolution from the positions Elite lists.
- **Text in the view** comes from the 3-pixel labels as before. Elite's own Spectrum pixels for it are no longer drawn.

The picture lives in a second RAM bank of the Benn Venn card: the DOS-area bank 1, port `37h` bit 1. That gave room for it without touching the game's memory. Because that bank replaces the one holding the interrupt glue, all work in it runs in short stretches with interrupts off. Long jobs, such as a big circle, pause regularly to let a waiting interrupt through. In my model the game now services 99% of interrupts, slightly more than stage 4 did.

Each frame, Elite's own view clear (`8080h`), which pushed zeros over the 4K Spectrum view, becomes a fast clear of the VZ view. Presenting the frame is a straight copy to the screen, with labels laid on top.



#### Faster text

Elite finds the Nth word of its text by scanning its word table from the start each time. That took about a quarter of the time on screens with a lot of text, such as the title, and was also slow in flight. At start-up an index of the table is built, and lookups use it. The title screen's frame rate went from 62 to 82 frames per 1,000 VZ frames.



#### Chart text

The galactic and short-range charts now show their text in the 3-pixel font, in upper case and in the colours of the row (yellow on blue, and the red title bar). Each word starts at the column where Elite printed it, so star names stay beside their stars. Each screen row is built with its text in place before it goes to the screen, so the text no longer flickers when the chart refreshes.



#### Speed

In my scripted flight test, the frames rendered per 3,000 VZ frames were:

- stage 2b: 420
- stage 4: 441
- stage 5: 485

How much faster it feels depends on what is on screen. In busy battles the saving on line drawing grows.

The largest remaining cost is outside the drawing: Elite's interrupt handler has to wait for the VZ's frame-sync signal to end. The VZ holds its interrupt line for the whole of that signal, so the handler can't enable interrupts until it ends. This is about 12% of the time. Removing that wait would mean reworking how the game uses interrupts, so I've left it alone.

#### Text pages in red on buff

Text pages (status, market, inventory, equipment, data, the save/load menu) now use the VZ's second text colour set, red on buff, instead of green.

