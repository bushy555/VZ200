; ---------------------------------------------------------------------------
; Cassette save/load for the commander file (bank 1, interrupts off).
;
; Signal: VZ cassette encoding (as the VZ ROM: one bit = a short sync cycle,
; then two short cycles for 1 or one long cycle for 0, ~600 baud). Output on
; latch bits 1-2 (cassette) and bit 0 (speaker, so the save is audible).
; The reader times half-cycles, so it does not care about signal polarity.
;
; File: 255 x 80h leader, 5 x FEh sync, type byte 'E', 102-byte commander
; block, 16-bit sum of the block, 20 x 00h trailer. About 5 seconds.
;
; Block in TBUF (7700h: video RAM that mode(0) does not display); the bank-0
; glue copies it to and from Elite's commander block at D054h.
; ---------------------------------------------------------------------------
TTYPE     equ 'E'
SAMPLE_N  equ 57                         ; delay loop: one sample = 277.8 us (985 T)
THR       equ 37                         ; half-cycle count: below = short, above = long
CASIN     equ $68FF                      ; keyboard read with no row selected: bit 6 = cassette

TSHF:     db 0
TCNT:     db 0
TABSP:    dw 0

; TSUM: DE = 16-bit sum of the block, HL = TBUF+TLEN
TSUM:
    ld hl,TBUF
    ld b,TLEN
    ld de,0
.l: ld a,(hl)
    add a,e
    ld e,a
    jr nc,.n
    inc d
.n: inc hl
    djnz .l
    ret

; ---- TSAVE: write the block in TBUF. Out: CF = 1
TSAVE:
    di
    call TSUM
    ld (hl),e
    inc hl
    ld (hl),d
    ld a,(LATCHSH)
    and $F8
    ld c,a                              ; C = latch, cassette and speaker low
    ld e,255
.ld:
    ld a,$80
    call WBYTE
    dec e
    jr nz,.ld
    ld e,5
.sy:
    ld a,$FE
    call WBYTE
    dec e
    jr nz,.sy
    ld a,TTYPE
    call WBYTE
    ld hl,TBUF
    ld e,TLEN+2
.dt:
    ld a,(hl)
    call WBYTE
    inc hl
    dec e
    jr nz,.dt
    ld e,20
.tr:
    xor a
    call WBYTE
    dec e
    jr nz,.tr
    ld a,(LATCHSH)
    ld (LATCH),a
    scf
    ret

; WBYTE: A = byte, MSB first. Uses B, D. C = latch base
WBYTE:
    ld b,a
    ld d,8
.bit:
    call HI1                            ; sync cycle
    call LO1
    sla b
    jr nc,.zero
    call HI1                            ; 1: two short cycles
    call LO1
    call HI1
    call LO1
    jr .nx
.zero:
    call HI2                            ; 0: one long cycle
    call LO2
.nx:
    dec d
    jr nz,.bit
    ret
HI2:
    call HI1
HI1:
    ld a,c
    or $07
    ld (LATCH),a
    jr DLY
LO2:
    call LO1
LO1:
    ld a,c
    ld (LATCH),a
DLY:
    ld a,SAMPLE_N
.l: dec a
    jr nz,.l
    ret

; ---- TLOAD: read a file into TBUF.
; Out: CF = 1 loaded and checked; CF = 0 with A = 0 checksum error, A = 1 key pressed
TLOAD:
    di
    ld (TABSP),sp
.rel:
    ld a,(LATCH)                        ; wait until every key is released
    and $3F
    cp $3F
    jr nz,.rel
    ld hl,CASIN
    ld a,(hl)
    and $40
    ld c,a
.start:
    call HALF                           ; align: the end of a 0 bit (two long halves)
    cp THR
    jr c,.start
    call HALF
    cp THR
    jr c,.start
    ld e,0
    xor a
    ld (TSHF),a
.hunt:
    call RBIT                           ; slide bit by bit until FEh
    ld a,(TSHF)
    rla
    ld (TSHF),a
    cp $FE
    jr nz,.hunt
.sync:
    call RBYTE
    cp $FE
    jr z,.sync
    cp TTYPE
    jr nz,.start
    ld ix,TBUF
    ld a,TLEN+2
    ld (TCNT),a
.rd:
    call RBYTE
    ld (ix+0),a
    inc ix
    ld a,(TCNT)
    dec a
    ld (TCNT),a
    jr nz,.rd
    call TSUM
    ld a,(hl)
    cp e
    jr nz,.bad
    inc hl
    ld a,(hl)
    cp d
    jr nz,.bad
    scf
    ret
.bad:
    xor a
    ret

; RBYTE: A = next byte (MSB first). Uses D
RBYTE:
    ld d,8
.l: call RBIT
    ld a,(TSHF)
    rla
    ld (TSHF),a
    dec d
    jr nz,.l
    ret

; RBIT: CF = next bit. E = short halves seen in this bit
RBIT:
    call HALF
    cp THR
    jr nc,.long
    inc e
    ld a,e
    cp 6
    jr nz,RBIT
    ld e,0
    scf                                 ; six short halves: 1
    ret
.long:
    call HALF                           ; second half of the long cycle: 0
    ld e,0
    or a
    ret

; HALF: wait for the cassette input to change. Out: A = duration (39 T units)
; No edge for ~10 ms: give up if a key is pressed, else report a long half.
HALF:
    ld b,0
.lp:
    ld a,(hl)
    and $40
    cp c
    jr nz,.edge
    inc b
    jp nz,.lp
    ld a,(LATCH)
    and $3F
    cp $3F
    jr nz,.abort
    ld a,255
    ret
.edge:
    ld a,(hl)                           ; confirm: a one-read spike is ignored
    and $40
    cp c
    jr z,.lp
    ld c,a
    ld a,b
    ret
.abort:
    ld sp,(TABSP)
    ld a,1
    or a
    ret

; TCLR: blank text shadow row 22 (the tape menu's message line), and put the
; cockpit picture back where TBUF borrowed the video RAM (so mode(1) shows no
; stray row when the game returns)
TCLR:
    push bc
    push de
    push hl
    ld hl,DBUF+(TBUF-VIDEO-43*32)
    ld de,TBUF
    ld bc,TLEN+2
    ldir
    ld hl,TEXTSHADOW+22*32
    ld b,32
.l: ld (hl),' '
    inc hl
    djnz .l
    pop hl
    pop de
    pop bc
    ret
