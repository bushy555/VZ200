; ---------------------------------------------------------------------------
; VZ-resolution 3D view, bank-1 side: presentation and view clear.
; The picture itself is built in DOS bank 1 (vz/dos1.asm). That bank replaces
; DOS bank 0, where the interrupt glue lives, so every access to it here is a
; short window with interrupts off ("WINON" ... "WINOFF"), and no stack use
; that crosses the window.
; ---------------------------------------------------------------------------
FULLCLR   equ $FC5C                      ; set by CLS: wipe the whole Spectrum view
DIRTYL    equ $FC60                      ; 6 bytes DIRTY + XORF, copied from DOS bank 1
VIFF      equ $FC67                      ; 1 = interrupts were on
NVROW     equ $FC68
NVDST     equ $FC69                      ; word

    macro WINON
        di
        ld a,MAP_D1B1
        out (MAPPER),a
    endm
    macro WINOFF
        ld a,MAP_B1
        out (MAPPER),a
        ld a,(VIFF)
        or a
        jr z,1F
        ei
1:
    endm

; GETIFF: VIFF = current interrupt state
GETIFF:
    ld a,i
    jp pe,.on
    ld a,i
    jp pe,.on
    xor a
    ld (VIFF),a
    ret
.on:
    ld a,1
    ld (VIFF),a
    ret

; ROWBIT: C = view row -> carry = its DIRTYL bit
ROWBIT:
    push hl
    ld a,c
    rrca
    rrca
    rrca
    and $1F
    ld hl,DIRTYL
    add a,l
    ld l,a
    jr nc,.a
    inc h
.a:
    ld a,c
    and 7
    inc a
    ld b,a
    ld a,(hl)
.s:
    rrca
    djnz .s
    pop hl
    ret

; NBROW: A = view row -> HL = its address in the DOS-bank-1 picture
NBROW:
    ld l,a
    ld h,0
    add hl,hl
    add hl,hl
    add hl,hl
    add hl,hl
    add hl,hl
    ld a,h
    add a,NB>>8
    ld h,a
    ret

; ---------------------------------------------------------------------------
; NVIEW: present the view (rows 0-42). Rows with Elite-drawn circles are
; converted from the Spectrum screen and merged; labels go on top. Runs of
; plain rows are copied in one window (at most 8 rows, so interrupts are only
; held off briefly).
NVANY     equ $FC6B                      ; any DIRTYL bit set
NVRUN     equ $FC6C                      ; rows in the current run
NVIEW:
    call GETIFF
    WINON
    ld hl,D1_DIRTY
    ld de,DIRTYL
    ld bc,7
    ldir
    WINOFF
    ld hl,DIRTYL
    xor a
    ld b,6
.any:
    or (hl)
    inc hl
    djnz .any
    ld (NVANY),a
    ld a,(DIRTYL+6)                      ; lines drawn with XOR (over a big sun):
    or a                                 ; merge with XOR, so they show dark on it
    ld a,$B6                             ; or (hl)
    jr z,.op
    ld a,$AE                             ; xor (hl)
.op:
    ld (.mg+1),a
    xor a
    ld (NVROW),a
.row:
    ld a,(NVROW)
    call PLAIN
    jr nz,.special
    ; a run of plain rows
    ld a,(NVROW)
    ld b,1
.run:
    inc a
    cp 43
    jr nc,.rend
    push bc
    push af
    call PLAIN
    pop bc                               ; B = row (pushed A), flags lost
    ld a,b
    pop bc
    jr nz,.rend
    inc b
    ld c,a
    ld a,b
    cp 8
    ld a,c
    jr c,.run
.rend:
    ld a,b
    ld (NVRUN),a
    ld a,(NVROW)
    call VROW                            ; DE = video row
    ld a,(NVROW)
    call NBROW                           ; HL = NB row
    ld a,(NVRUN)
    ld b,a
    ld c,0
    srl b
    rr c
    srl b
    rr c
    srl b
    rr c                                 ; BC = rows * 32
    WINON
    ldir
    WINOFF
    ld a,(NVRUN)
    ld b,a
    ld a,(NVROW)
    add a,b
    ld (NVROW),a
    cp 43
    jr c,.row
    ret
.special:
    ld a,(NVROW)
    ld c,a
    ld a,(NVANY)
    or a
    jr z,.clean
    call ROWBIT
    jr nc,.clean
    ld a,(NVROW)                         ; circle row: convert Elite's pixels
    call ROWIX
    ld de,TEMPROW
    call FROW
    ld a,(NVROW)
    call NBROW
    inc hl
    ld de,TEMPROW+1
    ld b,30
    WINON
.mg:
    ld a,(de)
    or (hl)
    and $55                              ; yellow where either is yellow
    ld c,a
    xor $55
    add a,a
    or c
    ld (de),a
    inc hl
    inc de
    djnz .mg
    WINOFF
    jr .lab
.clean:
    ld a,(NVROW)
    call NBROW
    ld de,TEMPROW
    WINON
    rept 32
    ldi
    endr
    WINOFF
.lab:
    ld a,(NVROW)
    ld hl,LROW
    add a,l
    ld l,a
    ld a,(hl)
    cp $FF
    call nz,LOVER
    ld a,(NVROW)
    call VROW
    ld hl,TEMPROW
    ld bc,32
    ldir
    ld a,(NVROW)
    inc a
    ld (NVROW),a
    cp 43
    jp c,.row
    ret

; PLAIN: A = row -> Z if it has no label and no circle
PLAIN:
    ld c,a
    ld hl,LROW
    add a,l
    ld l,a
    ld a,(hl)
    cp $FF
    ret nz
    ld a,(NVANY)
    or a
    ret z
    call ROWBIT
    ld a,0
    jr nc,.z
    inc a
.z:
    or a
    ret

; VROW: A = row -> DE = its video address
VROW:
    ld l,a
    ld h,0
    add hl,hl
    add hl,hl
    add hl,hl
    add hl,hl
    add hl,hl
    ld de,VIDEO
    add hl,de
    ex de,hl
    ret

; ROWIX: A = row -> IX = its ROWTAB entry
ROWIX:
    ld l,a
    ld h,0
    add hl,hl
    add hl,hl
    add hl,hl
    ld de,ROWTAB
    add hl,de
    push hl
    pop ix
    ret

; ---------------------------------------------------------------------------
; VCLR1: Elite's view clear (8080h)
VCLR1:
    ld hl,(VIEWMASK)                     ; text rows printed in the view
    ld a,h
    or l
    jr z,.t9
    ld de,TEXTSHADOW
    ld b,16
.r:
    srl h
    rr l
    jr nc,.n
    ld c,32
    ld a,32
.f:
    ld (de),a
    inc de
    dec c
    jr nz,.f
    jr .x
.n:
    ld a,e
    add a,32
    ld e,a
    jr nc,.x
    inc d
.x:
    djnz .r
    ld hl,0
    ld (VIEWMASK),hl
.t9:
    call GETIFF
    ld a,(FULLCLR)                       ; after a CLS: wipe the whole view
    or a
    jr z,.dirty
    xor a
    ld (FULLCLR),a
    ld hl,$4000
    ld de,$4001
    ld bc,$0FFF
    ld (hl),0
    ldir
    jr .nb
.dirty:
    WINON                                ; else only last frame's circle rows
    ld hl,D1_DIRTY
    ld de,DIRTYL
    ld bc,6
    ldir
    WINOFF
    ld hl,DIRTYL
    xor a
    ld b,6
.any:
    or (hl)
    inc hl
    djnz .any
    or a
    jr z,.nb
    ld ix,ROWTAB
    ld c,0
.dr:
    push bc
    call ROWBIT
    jr nc,.dn
    ld l,(ix+0)
    ld h,(ix+1)
    call .z32
    ld l,(ix+2)
    ld h,(ix+3)
    call .z32
    ld l,(ix+4)
    ld h,(ix+5)
    call .z32
.dn:
    ld bc,8
    add ix,bc
    pop bc
    inc c
    ld a,c
    cp 43
    jr c,.dr
.nb:
    WINON
    call D1_NBCLR
    WINOFF
    ret
.z32:
    ld b,32
    xor a
.zl:
    ld (hl),a
    inc hl
    djnz .zl
    ret

; ---------------------------------------------------------------------------
; Dashboard save / restore around full-screen pages (bitmap 5000-57FF and
; attributes 5A00-5AFF)
DSAVE1:
    ld hl,$5000
    ld de,DSAVEBUF
    ld bc,$0800
    ldir
    ld hl,$5A00
    ld de,ATTRSAVE
    ld bc,$0100
    ldir
    ret
DREST1:
    ld hl,DSAVEBUF
    ld de,$5000
    ld bc,$0800
    ldir
    ld hl,ATTRSAVE
    ld de,$5A00
    ld bc,$0100
    ldir
    ret

; ---------------------------------------------------------------------------
