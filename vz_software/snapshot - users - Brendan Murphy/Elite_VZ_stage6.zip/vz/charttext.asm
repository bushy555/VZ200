; ---------------------------------------------------------------------------
; Chart pages (galactic and short-range chart): FULL converts the Spectrum
; screen row by row into TEMPROW, lays the 3-pixel text over the row there,
; then copies it to the screen, so the shrunken 8x8 text never shows.
; Each character column (one VZ byte) under text is cleared to the
; attribute's paper colour; the words are drawn in its ink colour, each word
; starting at its own column so star names stay beside their stars. Lower
; case is shown as upper case.
CT_TAB    equ $FC70                      ; 24 x 4: first VZ row, rows covered, glyph row, used
CT_R      equ $FC50                      ; text row
CT_VR     equ $FC51                      ; VZ row being built
CT_X      equ $FC54                      ; pen x (VZ pixels)
CT_IN     equ $FC55                      ; inside a word
CT_INK    equ $FC56                      ; ink colour byte
CT_W      equ $FC57                      ; glyph width
CT_TXT    equ $FC58                      ; text row address (word)
CT_ATT    equ $FC5A                      ; attribute row address (word)
CT_GL     equ $FC5E                      ; glyph line to draw (0-2)

; CHARTFULL: the whole screen (from FULL)
CHARTFULL:
    call CTPREP
    ld ix,ROWTAB
    xor a
    ld (CT_VR),a
.row:
    ld de,TEMPROW
    call GROW
    call CTROW
    ld a,(CT_VR)
    ld l,a
    ld h,0
    add hl,hl
    add hl,hl
    add hl,hl
    add hl,hl
    add hl,hl
    ld de,VIDEO
    add hl,de
    ex de,hl
    ld hl,TEMPROW
    ld bc,32
    ldir
    ld bc,8
    add ix,bc
    ld a,(CT_VR)
    inc a
    ld (CT_VR),a
    cp 64
    jr c,.row
    ret

; CTPREP: per text row: VZ rows covered and glyph row, blank or not
CTPREP:
    ld hl,CT_TAB
    ld c,0                               ; text row
.r:
    push hl
    ld a,c
    call CTSET                           ; CT_TXT / CT_ATT
    ld hl,(CT_TXT)
    ld b,32
    ld d,0
.bl:
    ld a,(hl)
    cp 33
    jr c,.b1
    ld d,1
.b1:
    inc hl
    djnz .bl
    pop hl
    ld a,c
    add a,a
    add a,a
    add a,a
    ld e,a                               ; 8r
    call DIV3A
    ld (hl),a                            ; R0
    inc hl
    ld b,a
    ld a,e
    add a,7
    call DIV3A
    sub b
    inc a
    ld (hl),a                            ; rows covered
    inc hl
    ld a,e
    inc a
    call DIV3A
    cp 62
    jr c,.g
    ld a,61
.g:
    ld (hl),a                            ; glyph row
    inc hl
    ld (hl),d                            ; used
    inc hl
    inc c
    ld a,c
    cp 24
    jr c,.r
    ret

; CTSET: A = text row -> CT_TXT, CT_ATT
CTSET:
    ld (CT_R),a
    ld l,a
    ld h,0
    add hl,hl
    add hl,hl
    add hl,hl
    add hl,hl
    add hl,hl
    push hl
    ld de,TEXTSHADOW
    add hl,de
    ld (CT_TXT),hl
    pop hl
    ld de,$5800
    add hl,de
    ld (CT_ATT),hl
    ret

; CTROW: text over VZ row CT_VR in TEMPROW
CTROW:
    push ix
    ; pass 1: clear text columns of every text row covering this VZ row
    ld ix,CT_TAB
    ld c,0
.p1:
    ld a,(ix+3)
    or a
    jr z,.p1n
    ld a,(CT_VR)
    sub (ix+0)
    jr c,.p1n
    cp (ix+1)
    jr nc,.p1n
    push bc
    ld a,c
    call CTSET
    ld c,0
.cl:
    ld hl,(CT_TXT)
    ld a,c
    add a,l
    ld l,a
    ld a,(hl)
    cp 33
    jr c,.cn
    call CTATTR
    ld hl,TEMPROW
    ld e,c
    ld d,0
    add hl,de
    ld (hl),a
.cn:
    inc c
    ld a,c
    cp 32
    jr c,.cl
    pop bc
.p1n:
    ld de,4
    add ix,de
    inc c
    ld a,c
    cp 24
    jr c,.p1
    ; pass 2: glyph lines on this VZ row
    ld ix,CT_TAB
    ld c,0
.p2:
    ld a,(ix+3)
    or a
    jr z,.p2n
    ld a,(CT_VR)
    sub (ix+2)
    jr c,.p2n
    cp 3
    jr nc,.p2n
    ld (CT_GL),a
    push bc
    ld a,c
    call CTSET
    call CTWORDS
    pop bc
.p2n:
    ld de,4
    add ix,de
    inc c
    ld a,c
    cp 24
    jr c,.p2
    pop ix
    ret

; CTWORDS: draw glyph line CT_GL of text row CT_R into TEMPROW
CTWORDS:
    xor a
    ld (CT_IN),a
    ld c,0
.w:
    ld hl,(CT_TXT)
    ld a,c
    add a,l
    ld l,a
    ld a,(hl)
    cp 33
    jr nc,.ch
    xor a
    ld (CT_IN),a
    jr .wn
.ch:
    ld b,a
    ld a,(CT_IN)
    or a
    jr nz,.inw
    ld a,c
    add a,a
    add a,a
    ld (CT_X),a
    ld a,1
    ld (CT_IN),a
.inw:
    call CTATTR                          ; CT_INK
    ld a,b
    call LGLYPH                          ; HL -> width, 3 rows
    ld a,(hl)
    ld (CT_W),a
    inc hl
    ld a,(CT_GL)
    add a,l
    ld l,a
    jr nc,.g1
    inc h
.g1:
    ld e,(hl)                            ; row bits, MSB first
    ld a,(CT_X)
    ld b,a
    ld a,(CT_W)
    ld d,a
.px:
    sla e
    jr nc,.px2
    call CTPLOT
.px2:
    inc b
    dec d
    jr nz,.px
    ld a,(CT_W)
    inc a
    ld b,a
    ld a,(CT_X)
    add a,b
    jr nc,.xw
    ld a,255
.xw:
    ld (CT_X),a
.wn:
    inc c
    ld a,c
    cp 32
    jr c,.w
    ret

; CTATTR: C = column -> A = paper byte, (CT_INK) = ink byte
CTATTR:
    push hl
    ld hl,(CT_ATT)
    ld a,c
    add a,l
    ld l,a
    ld l,(hl)
    ld h,COLX>>8
    ld a,(hl)                            ; ink ^ paper
    inc h
    xor (hl)
    ld (CT_INK),a
    ld a,(hl)                            ; paper
    pop hl
    ret

; CTPLOT: pixel B (0-127) of TEMPROW to the ink colour
CTPLOT:
    bit 7,b
    ret nz
    push bc
    push hl
    ld a,b
    rrca
    rrca
    and $1F
    ld hl,TEMPROW
    add a,l
    ld l,a
    jr nc,.h
    inc h
.h:
    ld a,b
    and 3
    ld c,$C0
    jr z,.m
.ml:
    srl c
    srl c
    dec a
    jr nz,.ml
.m:
    ld a,c
    cpl
    and (hl)
    ld b,a
    ld a,(CT_INK)
    and c
    or b
    ld (hl),a
    pop hl
    pop bc
    ret

; DIV3A: A = A / 3
DIV3A:
    push bc
    ld b,0
.d:
    sub 3
    jr c,.e
    inc b
    jr .d
.e:
    ld a,b
    pop bc
    ret
