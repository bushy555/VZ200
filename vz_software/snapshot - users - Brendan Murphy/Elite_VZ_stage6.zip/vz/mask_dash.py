"""vz/dash.bin (Spectrum dashboard, 5000h-57FFh) -> vz/dash_vz.bin: the parts the VZ
panel never shows are cleared so ELITE.VZ packs smaller. Kept: bars, frame column,
condition light disc, compass circle, safe-zone S area, missile row. Cleared: the
bar labels and the scanner art (the VZ scanner is drawn from its own bitmap; the
blips are found by comparing against this same cleared copy)."""
import os
D = os.path.dirname(os.path.abspath(__file__))
d = bytearray(open(f'{D}/dash.bin', 'rb').read())
def off(y, x): return ((y & 7) << 8) | ((y & 0x38) << 2) | x
def zero(y0, y1, x0, x1):
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1): d[off(y, x)] = 0
zero(0, 55, 0, 2); zero(0, 55, 29, 31)   # labels (missile row kept)
zero(30, 63, 8, 20)                      # scanner, lower part (S area kept)
zero(7, 29, 10, 20)                      # scanner, between light and compass
open(f'{D}/dash_vz.bin', 'wb').write(d)
