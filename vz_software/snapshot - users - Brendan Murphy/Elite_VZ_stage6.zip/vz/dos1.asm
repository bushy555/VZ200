; ---------------------------------------------------------------------------
; Elite VZ: DOS-area RAM bank 1 (Benn Venn port 37h bit 1), 4000h-5FFFh.
;
; The 3D view is drawn here at the VZ's own resolution instead of being drawn
; Spectrum-style and converted:
;   NB      the view picture (43 rows x 32 bytes, VZ mode(1) format)
;   D1_*    drawing routines, entered from the bank-0 hooks in vz0.asm with
;           interrupts off and this bank mapped (the IM2 table and the glue
;           are in DOS bank 0, so nothing here may run with interrupts on).
; Coordinates arrive in Spectrum pixels (x 0-255, y 0-127); a VZ pixel is
; 2 x 3 of them, so X = x/2 and Y = y/3.
; ---------------------------------------------------------------------------
    device zxspectrum48
    include "vzabi.inc"

SPEC_OR   equ $B435                      ; Elite's line opcode: B1h OR, A9h XOR

    org NB
    ds 43*32,$AA

    org D1_VARS
DIRTY:    ds 6                           ; view rows holding Elite-drawn circles
XORF:     db 0                           ; lines were drawn with XOR this frame
SPS:      dw 0
LCNT:     db 0
LOCT:     db 0
LMODE:    db 0
LX0:      db 0
LY0:      db 0
LX1:      db 0
LY1:      db 0
LM:       db 0
LMIN:     db 0
LSLOPE:   db 0
CCX:      dw 0
CCY:      dw 0
CRAD:     db 0
CR2:      dw 0

    org D1_TABLE
    jp LINE
    jp DOT
    jp DUST
    jp CIRCN
    jp NBCLR
    jp INIT
    jp TOKA
    jp TOKB

    org $4600
DIV3:                                 ; y (0-255) -> y/3, at most 42 (built by INIT)
    ds 256

; octant (Elite's D AND 1Ch) -> major dx, major dy, minor dx, minor dy
OCTTAB:
    db 0,1,-1,0                          ; 00: down, minor left
    db 0,-1,-1,0                         ; 04: up, minor left
    db 0,1,1,0                           ; 08: down, minor right
    db 0,-1,1,0                          ; 0C: up, minor right
    db -1,0,0,1                          ; 10: left, minor down
    db -1,0,0,-1                         ; 14: left, minor up
    db 1,0,0,1                           ; 18: right, minor down
    db 1,0,0,-1                          ; 1C: right, minor up

; ---------------------------------------------------------------------------
; SPEC2XY: Spectrum screen address DE, pixel mask C -> B = x, C = y
SPEC2XY:
    ld a,d
    and $18
    rlca
    rlca
    rlca
    ld b,a
    ld a,e
    and $E0
    rrca
    rrca
    or b
    ld b,a
    ld a,d
    and 7
    or b
    push af                              ; y
    ld a,e
    and $1F
    rlca
    rlca
    rlca
    ld b,a
    ld a,c
.p:
    rlca
    jr c,.d
    inc b
    jr .p
.d:
    pop af
    ld c,a
    ret

; PIXADDR: B = X (0-127), C = Y (0-42) -> HL = NB byte, C = pixel mask (both bits)
PIXADDR:
    ld l,c
    ld h,0
    add hl,hl
    add hl,hl
    add hl,hl
    add hl,hl
    add hl,hl
    ld a,b
    rrca
    rrca
    and $1F
    add a,l
    ld l,a
    ld a,h
    adc a,NB>>8
    ld h,a
    ld a,b
    and 3
    ld c,$C0
    ret z
.m:
    srl c
    srl c
    dec a
    jr nz,.m
    ret

; plot routines: HL = byte, C = mask
PLOTOR:
    ld a,c
    cpl
    and (hl)
    ld (hl),a
    ld a,c
    and $55
    or (hl)
    ld (hl),a
    ret
PLOTXR:
    ld a,(hl)
    xor c
    ld (hl),a
    ret

; steps
STXR:
    rrc c
    rrc c
    ret nc
    inc hl
    ret
STXL:
    rlc c
    rlc c
    ret nc
    dec hl
    ret
STYD:
    ld a,l
    add a,32
    ld l,a
    ret nc
    inc h
    ret
STYU:
    ld a,l
    sub 32
    ld l,a
    ret nc
    dec h
    ret
NOSTEP:
    ret

; ---------------------------------------------------------------------------
; LINE: Elite's line, as it stands at B0E0h.
; In: A = count, main D = octant flags (bits 2-4); alternate set: HL = Spectrum
; address and C = mask of the first pixel, E = slope (minor steps x 256 per
; major step, first step at 80h). Elite plots count-1 pixels.
; Out: main registers kept except B = slope (as Elite leaves it).
LINE:
    ld (LCNT),a
    push hl
    push de
    push bc
    ex af,af'
    push af
    ld a,d
    and $1C
    ld (LOCT),a
    ld a,(SPEC_OR)
    ld (LMODE),a
    exx
    ld a,e
    ld (LSLOPE),a
    push hl
    push de
    push bc
    ex de,hl
    call SPEC2XY
    ld a,b
    ld (LX0),a
    ld a,c
    ld (LY0),a
    pop bc
    pop de
    pop hl
    exx
    ; m = major steps = max(count,2) - 2; minor = (80h + m*slope) >> 8
    ld a,(LCNT)
    cp 2
    jr nc,.c1
    ld a,2
.c1:
    sub 2
    ld (LM),a
    ld hl,0
    ld d,0
    ld a,(LSLOPE)
    ld e,a
    ld a,(LM)
    ld b,8
.ml:
    add hl,hl
    rla
    jr nc,.ms
    add hl,de
.ms:
    djnz .ml
    ld de,$80
    add hl,de
    ld a,h
    ld (LMIN),a
    ; end point
    ld a,(LOCT)
    ld e,a
    ld d,0
    ld hl,OCTTAB
    add hl,de
    ld a,(LM)
    ld b,a
    ld a,(LX0)
    call .add                            ; + major dx * m
    ld c,a
    ld a,(LY0)
    call .add                            ; + major dy * m
    push af
    ld a,(LMIN)
    ld b,a
    ld a,c
    call .add                            ; + minor dx * minor
    ld (LX1),a
    pop af
    call .add                            ; + minor dy * minor
    ld (LY1),a
    ; to VZ pixels
    ld h,DIV3>>8
    ld a,(LY0)
    ld l,a
    ld c,(hl)                            ; Y0
    ld a,(LY1)
    ld l,a
    ld e,(hl)                            ; Y1
    ld a,(LX0)
    srl a
    ld b,a                               ; X0
    ld a,(LX1)
    srl a
    ld d,a                               ; X1
    ; plot routine
    ld hl,PLOTOR
    ld a,(LMODE)
    cp $A9
    jr nz,.or
    ld hl,PLOTXR
    ld a,1
    ld (XORF),a
.or:
    ld (.xp+1),hl
    ld (.yp+1),hl
    ; directions and lengths
    ld a,d
    sub b
    ld hl,STXR
    jr nc,.dx
    neg
    ld hl,STXL
.dx:
    ld (.xs1+1),hl
    ld (.xs2+1),hl
    ld (LM),a                            ; dx
    ld a,e
    sub c
    ld hl,STYD
    jr nc,.dy
    neg
    ld hl,STYU
.dy:
    ld (.ys1+1),hl
    ld (.ys2+1),hl
    ld (LMIN),a                          ; dy
    call PIXADDR                         ; HL, C from X0 (B), Y0 (C)
    ld a,(LM)
    ld e,a                               ; E = dx
    ld a,(LMIN)
    ld d,a                               ; D = dy
    cp e
    jr nc,.ymaj
    ; x major
    ld b,e
    inc b
    ld a,e
    srl a
    ex af,af'
.xp:
    call PLOTOR
    dec b
    jr z,.done
.xs1:
    call STXR
    ex af,af'
    sub d
    jr nc,.xn
    add a,e
    ex af,af'
.ys1:
    call STYD
    jr .xp
.xn:
    ex af,af'
    jr .xp
.ymaj:
    ld b,d
    inc b
    ld a,d
    srl a
    ex af,af'
.yp:
    call PLOTOR
    dec b
    jr z,.done
.ys2:
    call STYD
    ex af,af'
    sub e
    jr nc,.yn
    add a,d
    ex af,af'
.xs2:
    call STXR
    jr .yp
.yn:
    ex af,af'
    jr .yp
.done:
    pop af
    ex af,af'
    pop bc
    pop de
    pop hl
    ld a,(LSLOPE)
    ld b,a
    ret
; .add: A += (HL) * B, HL advances (table entry -1, 0 or 1)
.add:
    push af
    ld a,(hl)
    inc hl
    or a
    jr z,.a0
    cp 1
    jr z,.ap
    pop af
    sub b
    ret
.ap:
    pop af
    add a,b
    ret
.a0:
    pop af
    ret

; ---------------------------------------------------------------------------
; DOT: explosion particle at Spectrum x = C, y = B. Registers kept.
DOT:
    push bc
    push de
    push hl
    ld a,b
    cp 128
    jr nc,.x
    ld h,DIV3>>8
    ld l,a
    ld a,c
    srl a
    ld b,a
    ld c,(hl)
    call PIXADDR
    call PLOTOR
.x:
    pop hl
    pop de
    pop bc
    ret

; ---------------------------------------------------------------------------
; DUST: the star dust Elite has listed this frame (count 7F80h, entries of
; Spectrum address and mask from 7F82h).
DUST:
    ld a,($7F80)
    or a
    ret z
    ld b,a
    ld ix,$7F82
.d:
    push bc
    ld e,(ix+0)
    ld d,(ix+1)
    ld c,(ix+2)
    call SPEC2XY                         ; B = x, C = y
    ld a,c
    cp 128
    jr nc,.n
    ld h,DIV3>>8
    ld l,a
    ld c,(hl)
    srl b
    call PIXADDR
    call PLOTOR
.n:
    inc ix
    inc ix
    inc ix
    pop bc
    djnz .d
    ret

; ---------------------------------------------------------------------------
; CIRC: Elite is about to draw a circle (sun, planet, ring) the Spectrum way;
; note which view rows it can touch so they are converted at presentation.
; Circle: offsets 861Ah (y) / 861Bh (x), flags 861Ch, radius 861Dh.
CMARK:
    push bc
    push de
    push hl
    ld a,($861A)
    ld e,a
    ld d,0
    ld hl,64
    ld a,($861C)
    bit 1,a
    jr nz,.up
    add hl,de
    jr .cy
.up:
    or a
    sbc hl,de
.cy:                                     ; HL = centre y (signed)
    ld a,($861D)
    ld e,a
    push hl
    or a
    sbc hl,de                            ; top
    ex (sp),hl
    add hl,de                            ; bottom
    pop de                               ; DE = top, HL = bottom
    bit 7,h
    jr nz,.x                             ; bottom above the view
    ld a,h
    or a
    jr z,.b1
    ld hl,127
.b1:
    ld a,l
    cp 128
    jr c,.b2
    ld l,127
.b2:
    bit 7,d
    jr z,.t1
    ld de,0
.t1:
    ld a,d
    or a
    jr nz,.x                             ; top below the view
    ld a,e
    cp 128
    jr nc,.x
    ld h,DIV3>>8                         ; L = bottom, E = top
    ld a,(hl)
    ld b,a                               ; last row
    ld l,e
    ld c,(hl)                            ; first row
.set:
    ld a,c
    rrca
    rrca
    rrca
    and $1F
    ld e,a
    ld d,0
    ld hl,DIRTY
    add hl,de
    ld a,c
    and 7
    ld e,a
    ld a,1
    jr z,.s2
.s1:
    add a,a
    dec e
    jr nz,.s1
.s2:
    or (hl)
    ld (hl),a
    ld a,c
    cp b
    jr nc,.x
    inc c
    jr .set
.x:
    pop hl
    pop de
    pop bc
    xor a                                ; Elite draws it
    ret

; ---------------------------------------------------------------------------
; NBCLR: empty view (blue, yellow frame, green side strips); clears DIRTY, XORF
NBCLR:
    ld (SPS),sp
    ld sp,NB+43*32
    ld de,$0055                          ; bottom row: frame line
    push de
    ld de,$5555
    rept 14
    push de
    endr
    ld de,$5500
    push de
    ld c,41
.r:
    ld de,$00A9                          ; frame pixel at x = 123
    push de
    ld de,$AAAA
    rept 14
    push de
    endr
    ld de,$6A00                          ; frame pixel at x = 4
    push de
    dec c
    jr nz,.r
    ld de,$0055                          ; top row
    push de
    ld de,$5555
    rept 14
    push de
    endr
    ld de,$5500
    push de
    ld sp,(SPS)
    xor a
    ld (XORF),a
    ld hl,DIRTY
    ld b,6
.z:
    ld (hl),a
    inc hl
    djnz .z
    ret

; ---------------------------------------------------------------------------
; CIRCN: Elite's circle (sun, planet, explosion cloud), call at 86E9h.
; With flags bits 2 and 3 set (the usual case) the circle is centred at
; x = 128 +/- (861Bh), y = 64 -/+ (861Ah), radius (861Dh) in Spectrum pixels:
; draw it here, filled (8629h = 0) or as an outline, and return A = 1 so Elite
; skips its own drawing. Otherwise note its rows (A = 0) and let Elite draw.
CIRCN:
    ld a,($861C)
    and $0C
    cp $0C
    jp nz,CMARK
    push bc
    push de
    push hl
    push iy
    ld a,($861B)
    ld e,a
    ld d,0
    ld hl,128
    ld a,($861C)
    bit 0,a
    jr z,.xm
    add hl,de
    jr .xs
.xm:
    or a
    sbc hl,de
.xs:
    ld (CCX),hl
    ld a,($861A)
    ld e,a
    ld hl,64
    ld a,($861C)
    bit 1,a
    jr nz,.ym
    add hl,de
    jr .ys
.ym:
    or a
    sbc hl,de
.ys:
    ld (CCY),hl
    ld a,($861D)
    ld (CRAD),a
    ld l,a
    ld h,SQL>>8
    ld e,(hl)
    inc h
    ld d,(hl)
    ld (CR2),de
    ; edges of every view row
    ld ix,CROWS
    ld c,0                               ; row
.row:
    ld a,c
    add a,a
    add a,c
    inc a                                ; Spectrum y at the row's middle
    ld l,a
    ld h,0
    ld de,(CCY)
    or a
    sbc hl,de
    jr nc,.pos
    ex de,hl
    ld hl,0
    or a
    sbc hl,de
.pos:
    ld a,h
    or a
    jr nz,.empty
    ld a,(CRAD)
    cp l
    jr c,.empty
    ld h,SQL>>8                          ; t = r^2 - d^2
    ld e,(hl)
    inc h
    ld d,(hl)
    ld hl,(CR2)
    or a
    sbc hl,de
    call ISQRT                           ; A = half width (Spectrum pixels)
    ld e,a
    ld d,0
    ld hl,(CCX)
    push hl
    or a
    sbc hl,de
    sra h
    rr l
    ld (ix+0),l
    ld (ix+1),h
    pop hl
    add hl,de
    sra h
    rr l
    ld (ix+2),l
    ld (ix+3),h
    ld (ix+4),1
    jr .rn
.empty:
    ld (ix+4),0
.rn:
    ld a,c
    and 7
    call z,BRE
    ld de,5
    add ix,de
    inc c
    ld a,c
    cp 43
    jr c,.row
    ; draw
    ld ix,CROWS
    ld c,0
.dr:
    ld a,(ix+4)
    or a
    jp z,.dn
    ld a,($8629)
    or a
    jr nz,.ol
    ld l,(ix+0)                          ; filled: the whole span
    ld h,(ix+1)
    ld e,(ix+2)
    ld d,(ix+3)
    call SPAN
    jp .dn
.ol:
    ld a,c                               ; outline: the neighbour row further out
    add a,a
    add a,c
    inc a
    ld e,a
    ld d,0
    ld hl,(CCY)
    or a
    sbc hl,de                            ; >= 0: row above the centre
    ld de,-5
    jr z,.up
    jr nc,.up
    ld de,5
.up:
    push ix
    pop iy
    add iy,de
    ld a,c
    or a
    jr nz,.o1
    bit 7,d
    jr nz,.cap                           ; row 0 and the neighbour is above
.o1:
    cp 42
    jr nz,.o2
    bit 7,d
    jr z,.cap
.o2:
    ld a,(iy+4)
    or a
    jr z,.cap
    ; left: L .. max(L, Lo-1)
    ld l,(iy+0)
    ld h,(iy+1)
    dec hl
    ld e,(ix+0)
    ld d,(ix+1)
    push hl
    or a
    sbc hl,de
    pop hl
    jp p,.l1
    ex de,hl
.l1:
    ex de,hl                             ; DE = right end
    ld l,(ix+0)
    ld h,(ix+1)
    call SPAN
    ; right: min(R, Ro+1) .. R
    ld l,(iy+2)
    ld h,(iy+3)
    inc hl
    ld e,(ix+2)
    ld d,(ix+3)
    push hl
    or a
    sbc hl,de
    pop hl
    jp m,.r1
    ex de,hl
.r1:
    ld e,(ix+2)
    ld d,(ix+3)
    call SPAN
    jr .dn
.cap:
    ld l,(ix+0)
    ld h,(ix+1)
    ld e,(ix+2)
    ld d,(ix+3)
    call SPAN
.dn:
    ld a,c
    and 7
    call z,BRE
    ld de,5
    add ix,de
    inc c
    ld a,c
    cp 43
    jp c,.dr
    pop iy
    pop hl
    pop de
    pop bc
    ld a,1                               ; drawn here
    ret

; BRE: let an interrupt in (bank-0 helper), registers kept
BRE:
    push af
    push bc
    push de
    push hl
    call BREATHE
    pop hl
    pop de
    pop bc
    pop af
    ret

; ISQRT: HL -> A = floor(sqrt(HL))
ISQRT:
    push bc
    push de
    ld c,0
    ld b,$80
.l:
    ld a,c
    or b
    ld e,a
    ld d,SQH>>8
    ld a,(de)
    cp h
    jr c,.ok
    jr nz,.no
    dec d
    ld a,(de)
    cp l
    jr z,.ok
    jr nc,.no
.ok:
    ld c,e
.no:
    srl b
    jr nz,.l
    ld a,c
    pop de
    pop bc
    ret

; SPAN: row C (0-42), x from HL to DE (signed VZ pixels), clipped to 4-123; OR yellow
SPAN:
    push bc
    bit 7,h                              ; left < 0 -> 4
    jr nz,.l4
    ld a,h
    or a
    jr nz,.x                             ; left beyond the right edge
    ld a,l
    cp 4
    jr nc,.l5
.l4:
    ld l,4
.l5:
    bit 7,d
    jr nz,.x                             ; right < 0
    ld a,d
    or a
    jr nz,.r3
    ld a,e
    cp 124
    jr c,.r4
.r3:
    ld e,123
.r4:
    ld a,e
    sub l
    jr c,.x
    inc a
    ld b,a                               ; count
    push bc
    ld b,l
    call PIXADDR                         ; HL, C mask
    pop af                               ; A = count (pushed B as high byte)
    ld b,a
.p:
    ld a,c
    cp $C0
    jr nz,.one
    ld a,b
    cp 4
    jr c,.one
    ld (hl),$55
    inc hl
    sub 4
    ld b,a
    jr z,.x
    jr .p
.one:
    ld a,c
    cpl
    and (hl)
    ld (hl),a
    ld a,c
    and $55
    or (hl)
    ld (hl),a
    rrc c
    rrc c
    jr nc,.n
    inc hl
.n:
    djnz .p
.x:
    pop bc
    ret

    align 256
SQL:
    ds 256                               ; low bytes of n^2 (built by INIT)
SQH:
    ds 256                               ; high bytes of n^2

; INIT: build the tables (start-up, this bank mapped, interrupts off)
INIT:
    ld hl,DIV3
    ld bc,0                              ; B = y/3, C = y mod 3
.d:
    ld a,b
    cp 43
    jr c,.d1
    ld a,42
.d1:
    ld (hl),a
    inc c
    ld a,c
    cp 3
    jr nz,.d2
    ld c,0
    inc b
.d2:
    inc l
    jr nz,.d
    ld hl,0                              ; n^2, n = 0..255
    ld de,1                              ; 2n+1
    ld bc,SQL
.s:
    ld a,l
    ld (bc),a
    inc b
    ld a,h
    ld (bc),a
    dec b
    add hl,de
    inc de
    inc de
    inc c
    jr nz,.s
    ld hl,SQL                            ; Elite's own n^2 table at BE00h-BFFFh (bank 0)
    ld de,$BE00
    ld bc,512
    ldir
    ; token string indexes: Elite finds its Nth text token by scanning the
    ; table string by string (CPIR), which made printing slow
    ld hl,($F11A)
    ld ix,TOKIA
    call .idx
    ld hl,($F11C)
    ld ix,TOKIB+2                        ; B: entry a = string a-1
    call .idx
    ld hl,(TOKIB+512)                    ; entry 0 = string 255 (wraps)
    ld (TOKIB),hl
    ret
.idx:
    ld b,0
.i1:
    ld (ix+0),l
    ld (ix+1),h
    inc ix
    inc ix
    xor a
.i2:
    cp (hl)
    inc hl
    jr nz,.i2
    djnz .i1
    ret

; TOKA / TOKB: A = token number -> HL = its string (tables at (F11Ah) / (F11Ch))
TOKA:
    ld l,a
    ld h,0
    add hl,hl
    push de
    ld de,TOKIA
    jr TOKX
TOKB:
    ld l,a
    ld h,0
    add hl,hl
    push de
    ld de,TOKIB
TOKX:
    add hl,de
    ld e,(hl)
    inc hl
    ld d,(hl)
    ex de,hl
    pop de
    ret

TOKIA:    ds 512
TOKIB:    ds 514

CROWS:    ds 43*5                        ; per view row: left, right (words), drawn

    include "b1syms.inc"
    include "b1init.asm"

D1_END:
    assert D1_END <= $5FF0
    savebin "elite_dos1.bin",$4000,D1_END-$4000
