; ---------------------------------------------------------------------------
; VZ cockpit (bank 1): hand-drawn instrument panel + 3-pixel view labels.
; The game's instrument values are read from Elite's own (shadow) Spectrum
; screen and drawn into fixed VZ artwork, composed in DBUF and copied to the
; screen in one go (no flicker).
; ---------------------------------------------------------------------------
DBUF      equ $F800                    ; 21 x 32 composed panel
TEMPROW   equ $FAA0                    ; one view row while a label is overlaid
LROW      equ $FAC0                    ; per view row 0-42: label slot*4+line, FFh = none
LSLOT     equ $FB00                    ; 3 label slots x 64: 3 x 16 bytes bitmap, b0, b1
TMPV      equ $FBC0
LCACHE    equ $FBE0
LPRE      equ $D700                    ; per slot: 3 finished rows x 32 bytes (span only valid)                    ; per slot: row number + 32 characters (33 bytes)
NSLOTS    equ 3

; ---- panel -----------------------------------------------------------------
PANEL:
    ld a,(PINIT)
    or a
    jr nz,.restore
    inc a
    ld (PINIT),a
    ld hl,DART
    ld de,DBUF
    ld bc,672
    ldir
    jr .bars
.restore:
    ; bars, missiles, light and S are rewritten in full below; restore the
    ; scanner field (rows 2-20, bytes 8-23) from the artwork
    ld hl,DART+2*32+8
    ld de,DBUF+2*32+8
    ld a,19
.rs:
    ld bc,16
    ldir
    ld bc,16
    add hl,bc
    ex de,hl
    add hl,bc
    ex de,hl
    dec a
    jr nz,.rs
    ld hl,DART+15*32+23                 ; S column
    ld de,DBUF+15*32+23
    ld b,5
.rs2:
    ld a,(hl)
    ld (de),a
    ld a,32
    add a,l
    ld l,a
    jr nc,.rs3
    inc h
.rs3:
    ld a,32
    add a,e
    ld e,a
    jr nc,.rs4
    inc d
.rs4:
    djnz .rs2
.bars:
    ; bars and markers
    ld ix,BARDEF
    ld b,NBARS
.bar:
    push bc
    ld l,(ix+0)
    ld h,(ix+1)                         ; Spectrum: middle line of the bar, first column
    ld a,(ix+4)
    cp 2
    jr z,.mark
    ; bar: count lit pixels in 5 columns
    ld c,0
    ld b,5
.pc:
    ld a,(hl)
    inc l
    push hl
    ld l,a
    ld h,POPC>>8
    ld a,(hl)
    pop hl
    add a,c
    ld c,a
    djnz .pc
    ld a,(ix+4)
    or a
    jr nz,.right
    dec l                               ; left: x=63 is the frame, not bar
    ld a,(hl)
    and 1
    jr z,.l2
    dec c
.l2:
    ld hl,LMAP
    ld de,LBAR
    jr .fill
.right:
    ld hl,RMAP
    ld de,RBAR
.fill:
    ld a,c
    add a,l
    ld l,a
    jr nc,.f2
    inc h
.f2:
    ld a,(hl)                           ; fill length 0-18
    jr .pat
.mark:
    ld c,0                              ; pixel position of the marker
    ld b,5
.mk:
    ld a,(hl)
    inc l
    or a
    jr nz,.mk2
    ld a,c
    add a,8
    ld c,a
    djnz .mk
    ld c,20                             ; none: centre
    jr .mk3
.mk2:
    push hl
    ld l,a
    ld h,FIRSTB>>8
    ld a,(hl)
    pop hl
    add a,c
    ld c,a
.mk3:
    ld hl,MMAP
    ld a,c
    add a,l
    ld l,a
    jr nc,.mk4
    inc h
.mk4:
    ld a,(hl)
    ld de,RMARK
.pat:
    ; DE = table, A = index -> HL = DE + A*6
    ld l,a
    ld h,0
    add hl,hl
    ld b,h
    ld c,l
    add hl,hl
    add hl,bc
    add hl,de
    ld e,(ix+2)
    ld d,(ix+3)                         ; DBUF bar row 1
    ld bc,6
    push hl
    ldir
    pop hl
    ex de,hl
    ld bc,26
    add hl,bc
    ex de,hl
    ld bc,6
    ldir
    ld bc,5
    add ix,bc
    pop bc
    dec b
    jp nz,.bar
    ; missiles: 4 slots, Spectrum line 185 columns 3-6, attributes row 23
    ld hl,MSLINE
    ld de,$5800+23*32+3
    ld ix,DBUF+19*32+3
    ld b,4
.ms:
    ld a,(hl)
    or a
    ld a,$FF                            ; empty: red
    jr z,.ms2
    ld a,(de)
    and 7
    push hl
    ld hl,INKMAP
    add a,l
    ld l,a
    jr nc,.ms1
    inc h
.ms1:
    ld a,(hl)
    pop hl
.ms2:
    and $FC
    ld c,a
    ld a,(ix+0)
    and $03
    or c
    ld (ix+0),a
    ld (ix+32),a
    inc hl
    inc de
    inc ix
    djnz .ms
    ; condition light: ink of attribute (17,8)
    ld a,($5800+17*32+8)
    and 7
    ld hl,LIGHTMAP
    add a,l
    ld l,a
    jr nc,.cl1
    inc h
.cl1:
    ld c,(hl)                           ; colour byte
    ld hl,LMASK
    ld de,DBUF+CR0*32+LIGHT_X/4
    ld b,6
.cl:
    call MERGE2
    ld a,e
    add a,30
    ld e,a
    jr nc,.cl2
    inc d
.cl2:
    djnz .cl
    call SCANOV
    call COMPASS
    call SAFEZONE
    ld hl,DBUF
    ld de,VIDEO+43*32
    ld bc,672
    ldir
    ret

PINIT: db 0

; MERGE2: (DE) = (DE) & ~(HL) | C & (HL) for 2 bytes; HL, DE advance; B kept
MERGE2:
    call MERGE1
MERGE1:
    ld a,(de)
    xor c
    and (hl)
    ex de,hl
    xor (hl)
    ld (hl),a
    ex de,hl
    inc hl
    inc de
    ret

; ---- scanner overlay: Elite's moving scanner items (pixels that differ from
; the empty scanner) drawn in yellow over the VZ scanner, rows 2-20.
SCANOV:
    ld iy,ROWTAB+(43+2)*8
    ld ix,PRIST
    ld hl,DBUF+2*32+8
    ld (TMPV+2),hl                      ; DBUF pointer for the row
    ld a,2
.row:
    ld (TMPV),a
    ld b,13                             ; columns 8-20 near the compass
    cp 9
    jr c,.nc
    ld b,16
    cp 16
    jr c,.nc
    ld b,14                             ; columns 8-21 beside the S
.nc:
    ld a,b
    ld (TMPV+1),a
    ld l,(iy+0)
    ld h,(iy+1)
    ld e,(iy+2)
    ld d,(iy+3)
    ld c,(iy+4)
    ld b,(iy+5)
    ld a,8
    add a,l
    ld l,a
    ld a,8
    add a,e
    ld e,a
    ld a,8
    add a,c
    ld c,a
    exx
    ld hl,(TMPV+2)
    exx
    ld a,(TMPV+1)
    exx
    ld b,a                              ; column count in B'
    exx
.col:
    ld a,(hl)
    xor (ix+0)
    exx
    ld d,a
    exx
    ld a,(de)
    xor (ix+16)
    exx
    or d
    ld d,a
    exx
    ld a,(bc)
    xor (ix+32)
    exx
    or d
    jr z,.skip
    ld e,l                              ; pixel mask via MASKT
    ld d,h
    ld l,a
    ld h,MASKT>>8
    ld a,(hl)
    ld h,d
    ld l,e
    ld d,a
    cpl
    and (hl)
    ld e,a
    ld a,d
    and $55                             ; yellow
    or e
    ld (hl),a
.skip:
    inc hl
    dec b
    exx
    jr z,.rowend
    inc l
    inc e
    inc c
    inc ix
    jr .col
.rowend:
    inc ix
    ; next row: pristine advances 3 lines (48) minus columns done
    ld a,(TMPV+1)
    ld c,a
    ld a,48
    sub c
    ld c,a
    ld b,0
    add ix,bc
    ld bc,8
    add iy,bc
    ld hl,(TMPV+2)
    ld bc,32
    add hl,bc
    ld (TMPV+2),hl
    ld a,(TMPV)
    inc a
    cp 21
    jp c,.row
    ret

; ---- compass dot: Elite draws a filled 4x4 dot (in front) or a hollow one
; (behind) inside the compass circle.
COMPASS:
    ld hl,CPLINES                       ; 16 lines (140-155): Spectrum address of column 21
    ld ix,PRIST+(140-135)*16+13
    ld b,16
    ld c,0                              ; line index
.cl:
    push hl
    ld a,(hl)
    inc hl
    ld h,(hl)
    ld l,a
    ld e,0
    call CPBYTE
    jr nz,.found
    inc l
    ld e,8
    call CPBYTE1
    jr nz,.found
    inc l
    ld e,16
    call CPBYTE2
    jr nz,.found
    pop hl
    inc hl
    inc hl
    push bc
    ld bc,16
    add ix,bc
    pop bc
    inc c
    djnz .cl
    ret                                 ; no dot
.found:
    pop hl
    ; A = differing bits, E = byte offset in pixels, C = line index
    push hl
    ld l,a
    ld h,FIRSTB>>8
    ld a,(hl)
    pop hl
    add a,e
    ld (TMPV+5),a                       ; x0 (0-23)
    ld a,c
    ld (TMPV+6),a                       ; y0 (0-15)
    ; filled? count differing pixels on the next line (3 columns)
    inc hl
    inc hl
    ld a,(hl)
    inc hl
    ld h,(hl)
    ld l,a
    ld bc,16
    add ix,bc
    ld d,0
    ld b,3
    push ix
.cnt:
    ld a,(hl)
    xor (ix+0)
    push hl
    ld l,a
    ld h,POPC>>8
    ld a,(hl)
    pop hl
    add a,d
    ld d,a
    inc l
    inc ix
    djnz .cnt
    pop ix
    ld a,d
    cp 3
    ld c,$55                            ; in front: yellow
    jr nc,.col
    ld c,$FF                            ; behind: red
.col:
    ld a,(TMPV+5)
    ld hl,XMAP
    add a,l
    ld l,a
    jr nc,.x1
    inc h
.x1:
    ld b,(hl)                           ; VZ x
    ld a,(TMPV+6)
    ld hl,YMAP
    add a,l
    ld l,a
    jr nc,.y1
    inc h
.y1:
    ld a,(hl)                           ; panel row
    push af
    call PLOT
    pop af
    inc b
    jp PLOT

CPBYTE:
    ld a,(hl)
    xor (ix+0)
    ret
CPBYTE1:
    ld a,(hl)
    xor (ix+1)
    ret
CPBYTE2:
    ld a,(hl)
    xor (ix+2)
    ret

; PLOT: B = x (0-127), A = panel row, C = colour byte
PLOT:
    push bc
    push hl
    ld l,a
    ld h,0
    add hl,hl
    add hl,hl
    add hl,hl
    add hl,hl
    add hl,hl
    ld a,b
    rrca
    rrca
    and $3F
    add a,l
    ld l,a
    ld de,DBUF
    add hl,de
    ld a,b
    and 3
    ld e,$C0
    jr z,.p2
.p1:
    srl e
    srl e
    dec a
    jr nz,.p1
.p2:
    ld a,e
    cpl
    and (hl)
    ld d,a
    ld a,c
    and e
    or d
    ld (hl),a
    pop hl
    pop bc
    ret

; ---- safe-zone "S": Elite prints a 2x2-character S at columns 22-23, rows 22-23
SAFEZONE:
    ld hl,SZLINES
    ld ix,PRIST+(178-135)*16+14
    ld b,5
.l:
    push hl
    ld a,(hl)
    inc hl
    ld h,(hl)
    ld l,a
    ld a,(hl)
    xor (ix+0)
    ld c,a
    inc l
    ld a,(hl)
    xor (ix+1)
    or c
    pop hl
    jr nz,.on
    inc hl
    inc hl
    ld de,16
    add ix,de
    djnz .l
    ret
.on:
    ld hl,SROWS
    ld de,DBUF+15*32+23
    ld b,5
.s:
    ld a,(hl)
    ld (de),a
    inc hl
    ld a,e
    add a,32
    ld e,a
    jr nc,.s2
    inc d
.s2:
    djnz .s
    ret

; ---- view labels -------------------------------------------------------------
; LABELS: build the 3-pixel versions of the text rows Elite printed in the view
; (rows 0-15 of the text shadow, marked in VIEWMASK) and fill LROW.
LABELS:
    ld hl,LROW
    ld de,LROW+1
    ld bc,42
    ld (hl),$FF
    ldir
    ld hl,(VIEWMASK)
    ld a,h
    or l
    ret z
    ld (TMPV+8),hl
    xor a
    ld (TMPV+10),a                      ; slot
    ld (TMPV+11),a                      ; row
.r:
    ld hl,(TMPV+8)
    srl h
    rr l
    ld (TMPV+8),hl
    jr nc,.next
    ld a,(TMPV+10)
    cp NSLOTS
    ret nc
    call LBUILD
.next:
    ld a,(TMPV+11)
    inc a
    ld (TMPV+11),a
    cp 16
    jr c,.r
    ret

; LBUILD: text row (TMPV+11) -> slot (TMPV+10)
LBUILD:
    ld a,(TMPV+11)
    ld l,a
    ld h,0
    add hl,hl
    add hl,hl
    add hl,hl
    add hl,hl
    add hl,hl
    ld de,TEXTSHADOW
    add hl,de
    ld (TMPV+12),hl                     ; row start
    ; first / last non-blank column
    ld b,0
    ld c,$FF
    ld d,0
.f:
    ld a,(hl)
    inc hl
    cp 33
    jr c,.f2
    ld a,c
    cp $FF
    jr nz,.f1
    ld c,b                              ; first
.f1:
    ld d,b                              ; last
.f2:
    inc b
    ld a,b
    cp 32
    jr c,.f
    ld a,c
    cp $FF
    ret z                               ; blank (erased by XOR)
    ld a,c
    ld (TMPV+14),a
    ld a,d
    ld (TMPV+15),a
    ; same text as last frame in this slot? then the bitmap is still valid
    ld a,(TMPV+10)
    ld l,a
    add a,a
    add a,a
    add a,a
    add a,a
    add a,a
    add a,l                             ; slot*33
    ld e,a
    ld d,0
    ld hl,LCACHE
    add hl,de
    ld (TMPV+22),hl
    ld a,(TMPV+11)
    cp (hl)
    jr nz,.new
    inc hl
    ld de,(TMPV+12)
    ld b,32
.cmp:
    ld a,(de)
    cp (hl)
    jr nz,.new
    inc de
    inc hl
    djnz .cmp
    jp .mark
.new:
    ld hl,(TMPV+22)
    ld a,(TMPV+11)
    ld (hl),a
    inc hl
    ex de,hl
    ld hl,(TMPV+12)
    ld bc,32
    ldir
    ; slot pointer
    ld a,(TMPV+10)
    rrca
    rrca                                ; *64
    ld l,a
    ld h,LSLOT>>8
    ld (TMPV+16),hl
    push hl
    ld d,h
    ld e,l
    inc de
    ld (hl),0
    ld bc,47
    ldir
    pop hl
    ; width in pixels
    call LWIDTH                         ; -> A
    srl a
    ld b,a
    ld a,64
    sub b
    ld (TMPV+18),a                      ; x
    ld (TMPV+21),a                      ; start x
    ; draw characters
    ld a,(TMPV+14)
    ld c,a
.ch:
    ld hl,(TMPV+12)
    ld a,c
    add a,l
    ld l,a
    jr nc,.c1
    inc h
.c1:
    ld a,(hl)
    call LGLYPH                         ; HL -> glyph (width,r0,r1,r2)
    ld a,(hl)
    ld (TMPV+19),a                      ; width
    inc hl
    push bc
    ld de,(TMPV+16)                     ; bitmap row 0
    ld b,3
.gr:
    push bc
    ld a,(hl)
    inc hl
    push hl
    ld c,a
    ld a,(TMPV+18)
    ld b,a
    ld a,(TMPV+19)
    ld h,a
.px:
    sla c
    jr nc,.px2
    call LSET                           ; set bit B in bitmap at DE
.px2:
    inc b
    dec h
    jr nz,.px
    pop hl
    ld a,e
    add a,16
    ld e,a
    pop bc
    djnz .gr
    pop bc
    ld a,(TMPV+19)
    inc a
    ld b,a
    ld a,(TMPV+18)
    add a,b
    ld (TMPV+18),a
    ld a,(TMPV+15)
    cp c
    jr z,.done
    inc c
    jr .ch
.done:
    ; byte span to rewrite: original columns united with the new text
    ld a,(TMPV+18)                      ; x after the last character + gap
    sub 2                               ; last lit x
    rrca
    rrca
    and $3F
    ld c,a
    ld a,(TMPV+15)
    cp c
    jr nc,.e1
    ld a,c
.e1:
    ld (TMPV+20),a                      ; b1
    ld a,(TMPV+21)                      ; start x
    rrca
    rrca
    and $3F
    ld c,a
    ld a,(TMPV+14)
    cp c
    jr c,.e2
    ld a,c
.e2:
    ld hl,(TMPV+16)
    ld de,48
    add hl,de
    ld (hl),a                           ; b0
    inc hl
    ld a,(TMPV+20)
    ld (hl),a                           ; b1
    call LPREP
.mark:
    ; mark the three view rows of this text row: R = (8r+1)/3
    ld a,(TMPV+11)
    add a,a
    add a,a
    add a,a
    inc a
    ld b,0
.d3:
    sub 3
    jr c,.d4
    inc b
    jr .d3
.d4:
    ld a,b
    cp 41
    jr c,.d5
    ld a,40
.d5:
    ld hl,LROW
    add a,l
    ld l,a
    jr nc,.d6
    inc h
.d6:
    ld a,(TMPV+10)
    add a,a
    add a,a
    ld (hl),a
    inc hl
    inc a
    ld (hl),a
    inc hl
    inc a
    ld (hl),a
    ld a,(TMPV+10)
    inc a
    ld (TMPV+10),a
    ret

; LWIDTH: pixel width of columns (TMPV+14)..(TMPV+15) of row (TMPV+12)
LWIDTH:
    push bc
    push hl
    ld a,(TMPV+14)
    ld c,a
    ld b,0                              ; width
.w:
    ld hl,(TMPV+12)
    ld a,c
    add a,l
    ld l,a
    jr nc,.w1
    inc h
.w1:
    ld a,(hl)
    call LGLYPH
    ld a,(hl)
    inc a
    add a,b
    ld b,a
    ld a,(TMPV+15)
    cp c
    jr z,.w2
    inc c
    jr .w
.w2:
    ld a,b
    dec a
    pop hl
    pop bc
    ret

; LGLYPH: A = character -> HL = FONT3 entry
LGLYPH:
    cp 'a'
    jr c,.g1
    cp 'z'+1
    jr nc,.g1
    sub 32
.g1:
    cp 32
    jr c,.sp
    cp 96
    jr c,.g2
.sp:
    ld a,32
.g2:
    sub 32
    ld l,a
    ld h,0
    add hl,hl
    add hl,hl
    push de
    ld de,FONT3
    add hl,de
    pop de
    ret

; LSET: set pixel B (0-127) in the 16-byte bitmap row at DE
LSET:
    push de
    push hl
    ld a,b
    rrca
    rrca
    rrca
    and $0F
    add a,e
    ld e,a
    ld a,b
    and 7
    ld l,a
    ld h,BITTAB>>8
    ld a,(hl)
    ex de,hl
    or (hl)
    ld (hl),a
    pop hl
    pop de
    ret

; LOVER: overlay label line on TEMPROW. A = LROW value (slot*4 + line)
LOVER:
    ld b,a
    and $0C
    rlca
    rlca
    rlca
    rlca                                ; slot*64
    ld l,a
    ld h,LSLOT>>8
    ld de,48
    add hl,de
    ld e,(hl)                           ; b0
    inc hl
    ld a,(hl)
    sub e
    inc a
    ld c,a                              ; count
    ld a,b                              ; slot*4+line -> LPRE + slot*96 + line*32
    and $0C
    srl a
    srl a
    ld l,a
    add a,a
    add a,l                             ; slot*3
    ld l,a
    ld a,b
    and 3
    add a,l                             ; slot*3 + line
    ld l,a
    ld h,0
    add hl,hl
    add hl,hl
    add hl,hl
    add hl,hl
    add hl,hl
    ld d,0
    add hl,de                           ; + b0
    ld a,e
    ld de,LPRE
    add hl,de
    ld de,TEMPROW
    add a,e
    ld e,a
    ld b,0
    ldir
    ret

; LPREP: precompute the finished bytes for slot (TMPV+10), span b0..b1
LPREP:
    ld a,(TMPV+10)
    ld l,a
    add a,a
    add a,l
    ld l,a
    ld h,0
    add hl,hl
    add hl,hl
    add hl,hl
    add hl,hl
    add hl,hl
    ld de,LPRE
    add hl,de                           ; LPRE + slot*96
    ex de,hl                            ; DE = output
    ld hl,(TMPV+16)                     ; bitmap lines (16 bytes each)
    ld c,3
.ln:
    ld b,0                              ; byte 0..31
.by:
    push hl
    ld a,b
    rrca
    and $0F
    add a,l
    ld l,a
    ld a,(hl)
    bit 0,b
    jr nz,.lo
    rrca
    rrca
    rrca
    rrca
.lo:
    and $0F
    ld hl,NIB2VZ
    add a,l
    ld l,a
    jr nc,.nb
    inc h
.nb:
    ld a,(hl)
    ld (de),a
    inc de
    pop hl
    inc b
    ld a,b
    cp 32
    jr c,.by
    ld a,l
    add a,16
    ld l,a
    dec c
    jr nz,.ln
    ret

    align 256
BITTAB:
    db $80,$40,$20,$10,$08,$04,$02,$01

