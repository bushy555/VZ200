"""VZ Elite cockpit: hand-designed instrument panel + 3-pixel font.

Generates vz/dash_data.asm (included in bank 1) and a preview PNG.
Panel = VZ rows 43-63 (local rows 0-20), 128 pixels wide, CSS0 colours
0 green, 1 yellow, 2 blue, 3 red.

Grid: 7 instrument cells of 3 rows (separator row + 2-row bar), mirrored about
x = 63.5:
  left : labels x1-7 | track x10-29 (caps 10/29, interior 11-28) | scanner x32-95
  right: track x98-117 (caps 98/117, interior 99-116) | labels x120-126
"""
import os, math, sys
D = os.path.dirname(os.path.abspath(__file__))
G, Y, B, R = 0, 1, 2, 3
W, H = 128, 21

# ---------------------------------------------------------------- 3-pixel font
# rows top/middle/bottom, '#' = ink. Widths 1-5.
FONT = {
 'A': ['.#.', '###', '#.#'], 'B': ['##.', '###', '###'], 'C': ['###', '#..', '###'],
 'D': ['##.', '#.#', '##.'], 'E': ['###', '##.', '###'], 'F': ['###', '##.', '#..'],
 'G': ['##.', '#..', '###'], 'H': ['#.#', '###', '#.#'], 'I': ['#', '#', '#'],
 'J': ['..#', '..#', '##.'], 'K': ['#.#', '##.', '#.#'], 'L': ['#..', '#..', '###'],
 'M': ['##.##', '#.#.#', '#...#'], 'N': ['##.#', '#.##', '#..#'], 'O': ['###', '#.#', '###'],
 'P': ['###', '###', '#..'], 'Q': ['###', '#.#', '##.'], 'R': ['###.', '###.', '#..#'],
 'S': ['.##', '###', '##.'], 'T': ['###', '.#.', '.#.'], 'U': ['#.#', '#.#', '###'],
 'V': ['#.#', '#.#', '.#.'], 'W': ['#...#', '#.#.#', '.#.#.'], 'X': ['#.#', '.#.', '#.#'],
 'Y': ['#.#', '.#.', '.#.'], 'Z': ['##.', '.#.', '.##'],
 '0': ['###', '#.#', '###'], '1': ['##', '.#', '.#'], '2': ['##.', '.#.', '.##'],
 '3': ['###', '.##', '###'], '4': ['#.#', '###', '..#'], '5': ['###', '##.', '.##'],
 '6': ['#..', '###', '###'], '7': ['###', '..#', '..#'], '8': ['###', '###', '###'],
 '9': ['###', '###', '..#'],
 ' ': ['..', '..', '..'], '-': ['...', '###', '...'], '.': ['.', '.', '#'], ',': ['.', '.', '#'],
 '?': ['##', '.#', '#.'], '!': ['#', '#', '.'], '(': ['.#', '#.', '.#'], ')': ['#.', '.#', '#.'],
 '/': ['..#', '.#.', '#..'], ':': ['.', '#', '#'.replace('#', '.')] , "'": ['#', '.', '.'],
 '+': ['...', '###', '...'], '=': ['###', '...', '###'], '*': ['#.#', '.#.', '#.#'],
 '"': ['#.#', '...', '...'], '%': ['#.', '.#', '#.'], '&': ['##', '##', '##'],
 '$': ['.##', '##.', '.#.'], '#': ['###', '###', '###'], '<': ['.#', '#.', '.#'], '>': ['#.', '.#', '#.'],
 '@': ['###', '#.#', '##.'], '[': ['##', '#.', '##'], ']': ['##', '.#', '##'], '^': ['.#.', '#.#', '...'],
 '_': ['...', '...', '###'], ';': ['.', '#', '#'],
}
FONT[':'] = ['#', '.', '#']
MISSILE_ICON = ['#..##..', '#######', '#..##..']

def text_width(s):
    w = 0
    for ch in s:
        w += len(FONT.get(ch.upper(), FONT[' '])[0]) + 1
    return max(0, w - 1)

# ---------------------------------------------------------------- canvas
img = [[Y] * W for _ in range(H)]
def put(x, y, c):
    if 0 <= x < W and 0 <= y < H: img[y][x] = c
def hline(x0, x1, y, c):
    for x in range(x0, x1 + 1): put(x, y, c)
def mirror_put(x, y, c):
    put(x, y, c); put(127 - x, y, c)
def draw_glyphs(rows, x, y, c):
    for j, row in enumerate(rows):
        for i, ch in enumerate(row):
            if ch == '#': put(x + i, y + j, c)
def draw_text(s, x, y, c):
    for ch in s:
        g = FONT[ch.upper()]
        draw_glyphs(g, x, y, c)
        x += len(g[0]) + 1

# scanner field
for y in range(H):
    for x in range(32, 96): img[y][x] = B

# instrument tracks (empty = red, framed in blue)
LTRK, RTRK = (10, 29), (98, 117)
for k in range(7):
    s = 3 * k
    for (a, b) in (LTRK, RTRK):
        hline(a, b, s, B)
        for r in (s + 1, s + 2):
            put(a, r, B); put(b, r, B)
            hline(a + 1, b - 1, r, R)

# label strips: blue, between yellow frame columns (x0, x8-9 / x118-119, x127)
for y in range(H):
    for x in range(1, 9): mirror_put(x, y, B)
LLAB = ['FS', 'AS', 'FU', 'CT', 'LT', 'AL', None]
RLAB = ['SP', 'RL', 'DC', '1', '2', '3', '4']
for k in range(7):
    y = 3 * k
    if LLAB[k]:
        draw_text(LLAB[k], 2, y, (Y, G)[k & 1])
    else:
        draw_glyphs(MISSILE_ICON, 2, y, (Y, G)[k & 1])
    t = RLAB[k]
    w = text_width(t)
    draw_text(t, 119 + (7 - w + 1) // 2 if len(t) == 1 else 119, y, (Y, G)[k & 1])

# ---- scanner: symmetric ellipse about x = 63.5, rows 5..19 (centre 12)
CX, CY, A, BB = 63.5, 12, 28.5, 7
pts = set()
for i in range(2000):
    th = math.pi / 2 + math.pi * i / 1999          # left half, top -> bottom
    x = CX + A * math.cos(th); y = CY - BB * math.sin(th)
    pts.add((int(round(x - 0.001)), int(round(y))))
for (x, y) in pts:
    if x <= 63: mirror_put(x, y, Y)
# internal divisions (green): range rings (dotted) and the forward "V"
def inside(x, r):
    t = (r - CY) / BB
    return abs(x + 0.5 - (CX + 0.5)) < A * math.sqrt(max(0, 1 - t * t)) - 1.2
for r in (9, 12, 15):
    for x in range(32, 64):
        if inside(x, r) and img[r][x] == B and (x % 2 == 0):
            mirror_put(x, r, G)
# V from the far rim to the centre
for (x0, y0, x1, y1) in ((51, 6, 61, 11),):
    n = max(abs(x1 - x0), abs(y1 - y0))
    for i in range(n + 1):
        x = round(x0 + (x1 - x0) * i / n); y = round(y0 + (y1 - y0) * i / n)
        if img[y][x] == B: mirror_put(x, y, G)
# centre line toward the viewer (dotted, 2 px wide = symmetric)
for r in (13, 15, 17):
    if img[r][63] != Y: mirror_put(63, r, G)

# condition light (left) and compass (right): same 8x6 circle, mirrored
CIRC = ['..####..', '.######.', '########', '########', '.######.', '..####..']
RING = ['..####..', '.#....#.', '#......#', '#......#', '.#....#.', '..####..']
LIGHT_X, COMP_X, CR0 = 32, 88, 2
draw_glyphs(CIRC, LIGHT_X, CR0, G)
draw_glyphs(RING, COMP_X, CR0, Y)

# ---------------------------------------------------------------- packing
def pack_row(row, x0=0, nbytes=32):
    out = []
    for b in range(nbytes):
        v = 0
        for p in range(4):
            v = (v << 2) | row[x0 + b * 4 + p]
        out.append(v)
    return out
art = [pack_row(img[y]) for y in range(H)]

def bar_pattern(trk, fill, marker=None):
    """6 bytes covering the track's bytes (left: bytes 2-7, right: 24-29)."""
    a, b = trk
    row = list(img[1])                     # a bar row of cell 0 as base
    for x in range(a + 1, b):
        row[x] = R
    if marker is None:
        for x in range(a + 1, a + 1 + fill):
            row[x] = Y
    else:
        row[a + 1 + marker] = Y; row[a + 2 + marker] = Y
    x0 = (a // 4) * 4
    return pack_row(row, x0, 6)

LB = [bar_pattern(LTRK, n) for n in range(19)]
RB = [bar_pattern(RTRK, n) for n in range(19)]
MK = [bar_pattern(RTRK, 0, m) for m in range(17)]
LMAP = [min(18, round(c * 18 / 39)) for c in range(41)]
RMAP = [min(18, round(c * 18 / 40)) for c in range(41)]
MMAP = [min(16, max(0, round(p * 16 / 38))) for p in range(41)]

def light_mask():
    out = []
    for j in range(6):
        row = [0] * 128
        for i, ch in enumerate(CIRC[j]):
            if ch == '#': row[LIGHT_X + i] = 3
        out += pack_row(row, LIGHT_X, 2)
    return out

S_GLYPH = ['###', '#..', '###', '..#', '###']   # safe-zone "S", 3x5 at x92-94 rows 15-19
def s_rows():
    out = []
    for j in range(5):
        row = list(img[15 + j]); m = [0] * 128
        for i, ch in enumerate(S_GLYPH[j]):
            if ch == '#': row[92 + i] = Y
        out.append(pack_row(row, 92, 1)[0])
    return out

COLB = [0x00, 0x55, 0xAA, 0xFF]
SPEC2VZ = [2, 2, 3, 3, 0, 0, 1, 1]
INKMAP = [COLB[1] if c == 2 else COLB[c] for c in SPEC2VZ]   # ink black/blue would vanish: show yellow
LIGHTMAP = [COLB[c] for c in (0, 2, 3, 3, 0, 0, 1, 1)]       # condition: green / yellow / red
LIGHTMAP[0] = COLB[0]

def popc(v): return bin(v).count('1')
def firstbit(v):
    for i in range(8):
        if v & (0x80 >> i): return i
    return 8

# pristine Spectrum scanner area (lines 135..191, columns 8..23) from the start image
mem = open(os.path.join(os.path.dirname(D), 'run', 'start.mem'), 'rb').read()
dash = mem[0xC000:0xC800]
def specoff(y): return ((y & 7) << 8) | ((y & 0x38) << 2)
PRIST = []
for y in range(135, 192):
    PRIST += list(dash[specoff(y) + 8: specoff(y) + 24])

# compass dot mapping: Spectrum dot top-left (x0 relative to 168, y0 relative to 140)
# circle centre 182.5,146.5 ; dot is 4x4 -> centre +1.5
def dotx(x0):
    dx = (168 + x0 + 1.5) - 182.5
    return max(COMP_X + 1, min(COMP_X + 5, int(round(COMP_X + 3.5 + dx * 0.45 - 0.5))))
def doty(y0):
    dy = (140 + y0 + 1.5) - 146.5
    return max(CR0 + 1, min(CR0 + 4, int(round(CR0 + 2.5 + dy * 0.36 - 0.5))))
XMAP = [dotx(x) for x in range(24)]
YMAP = [doty(y) for y in range(16)]

# ---------------------------------------------------------------- emit
def db(lst, per=16):
    return '\n'.join('    db ' + ','.join('$%02x' % v for v in lst[i:i + per]) for i in range(0, len(lst), per))
o = []
o.append('; generated by vz/gen_dash.py')
o.append(f'LIGHT_X equ {LIGHT_X}\nCOMP_X equ {COMP_X}\nCR0 equ {CR0}')
o.append('DART:          ; static panel, 21 rows x 32 bytes')
o.append(db([v for r in art for v in r]))
o.append('LBAR:          ; left bar rows, 19 fill lengths x 6 bytes (bytes 2-7)')
o.append(db([v for r in LB for v in r], 6))
o.append('RBAR:          ; right bar rows (bytes 24-29)')
o.append(db([v for r in RB for v in r], 6))
o.append('RMARK:         ; roll / dive marker positions 0-16')
o.append(db([v for r in MK for v in r], 6))
o.append('LMAP:\n' + db(LMAP)); o.append('RMAP:\n' + db(RMAP)); o.append('MMAP:\n' + db(MMAP))
o.append('LMASK:         ; condition light shape, 6 rows x 2 bytes (bytes 8-9)')
o.append(db(light_mask(), 2))
o.append('SROWS:         ; byte 23 rows 15-19 with the safe-zone S')
o.append(db(s_rows()))
o.append('INKMAP:\n' + db(INKMAP)); o.append('LIGHTMAP:\n' + db(LIGHTMAP))
o.append('XMAP:\n' + db(XMAP)); o.append('YMAP:\n' + db(YMAP))
o.append('    align 256\nPOPC:          ; bit counts (built by TBLINIT)\n    ds 256')
o.append('FIRSTB:        ; leading zero bits (built by TBLINIT)\n    ds 256')
o.append('PRIST:         ; pristine Spectrum scanner, lines 135-191 x columns 8-23 (built by TBLINIT from DSAVEBUF)\n    ds 912')
# runtime font: ASCII 32..95, 4 bytes each: width, row0, row1, row2 (bits from bit 7)
fb = []
for c in range(32, 96):
    g = FONT.get(chr(c), FONT[' '])
    w = len(g[0]); fb.append(w)
    for row in g:
        v = 0
        for i, ch in enumerate(row):
            if ch == '#': v |= 0x80 >> i
        fb.append(v)
o.append('FONT3:         ; ASCII 20h-5Fh: width, three rows (bit 7 = left)')
o.append(db(fb, 16))
o.append('NIB2VZ:        ; 4 pixels (bit 3 = left) -> blue / yellow byte')
nb = []
for n in range(16):
    v = 0
    for p in range(4):
        v = (v << 2) | (Y if n & (8 >> p) else B)
    nb.append(v)
o.append(db(nb))
def specaddr(y): return 0x4000 | ((y & 0xC0) << 5) | ((y & 7) << 8) | ((y & 0x38) << 2)
bd = []
for k in range(6):                                   # FS AS FU CT LT AL
    bd.append((specaddr(139 + 8 * k) + 3, (3 * k + 1) * 32 + 2, 0))
for k in range(7):                                   # SP RL DC 1 2 3 4
    bd.append((specaddr(139 + 8 * k) + 24, (3 * k + 1) * 32 + 24, 2 if k in (1, 2) else 1))
o.append(f'NBARS equ {len(bd)}')
o.append('BARDEF:        ; Spectrum middle line address, DBUF offset, type (0 left bar, 1 right bar, 2 marker)')
for a, off, t in bd:
    o.append(f'    dw ${a:04x}, DBUF+{off}\n    db {t}')
o.append(f'MSLINE equ ${specaddr(185) + 3:04x}')
o.append('CPLINES:       ; compass interior lines 140-155, column 21')
o.append('    dw ' + ','.join('$%04x' % (specaddr(y) + 21) for y in range(140, 156)))
o.append('SZLINES:       ; safe-zone S lines 178-182, column 22')
o.append('    dw ' + ','.join('$%04x' % (specaddr(y) + 22) for y in range(178, 183)))
open(os.path.join(D, 'dash_data.asm'), 'w').write('\n'.join(o) + '\n')

# ---------------------------------------------------------------- preview
if '--preview' in sys.argv:
    from PIL import Image
    PAL = [(0, 200, 0), (255, 255, 0), (0, 0, 220), (220, 0, 0)]
    demo = [list(r) for r in img]
    def dput(x, y, c): demo[y][x] = c
    fills = [18, 14, 9, 3, 0, 18]
    for k, f in enumerate(fills):
        for r in (3 * k + 1, 3 * k + 2):
            for x in range(11, 11 + f): dput(x, r, Y)
    for k, f in ((0, 7), (3, 18), (4, 18), (5, 12), (6, 5)):
        for r in (3 * k + 1, 3 * k + 2):
            for x in range(99, 99 + f): dput(x, r, Y)
    for k, m in ((1, 8), (2, 10)):
        for r in (3 * k + 1, 3 * k + 2):
            dput(99 + m, r, Y); dput(100 + m, r, Y)
    for i in range(3):
        for r in (19, 20):
            for x in range(12 + 4 * i, 15 + 4 * i): dput(x, r, Y)
    for (x, y) in ((50, 14), (50, 13), (50, 12), (70, 10), (71, 10), (70, 11), (80, 16), (80, 15)):
        dput(x, y, Y)
    dput(90, 4, Y); dput(91, 4, Y)
    for j in range(5):
        for i, ch in enumerate(S_GLYPH[j]):
            if ch == '#': dput(92 + i, 15 + j, Y)
    im = Image.new('RGB', (256, 63))
    for y in range(H):
        for x in range(W):
            for dy in range(3):
                im.putpixel((2 * x, 3 * y + dy), PAL[demo[y][x]]); im.putpixel((2 * x + 1, 3 * y + dy), PAL[demo[y][x]])
    # label demo above
    lab = Image.new('RGB', (256, 30), PAL[B])
    t = 'FRONT VIEW'; w = text_width(t); x0 = 64 - w // 2
    for ch in t:
        g = FONT[ch]
        for j, row in enumerate(g):
            for i, c in enumerate(row):
                if c == '#':
                    for dy in range(3):
                        lab.putpixel((2 * (x0 + i), 9 + 3 * j + dy), PAL[Y]); lab.putpixel((2 * (x0 + i) + 1, 9 + 3 * j + dy), PAL[Y])
        x0 += len(g[0]) + 1
    full = Image.new('RGB', (256, 93)); full.paste(lab, (0, 0)); full.paste(im, (0, 30))
    full.resize((1024, 372), Image.NEAREST).save(sys.argv[-1])
print('wrote dash_data.asm')
