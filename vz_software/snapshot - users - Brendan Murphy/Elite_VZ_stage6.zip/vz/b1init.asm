; ---------------------------------------------------------------------------
; Start-up table builders for expansion bank 1. They live in DOS-area RAM bank 1
; and run once, from the loader, with DOS bank 1 + expansion bank 1 mapped
; (port 37h = 07h). Bank-1 addresses come from b1syms.inc (made from vz1.sym).
; ---------------------------------------------------------------------------
B1INIT:
; ROWINIT: build ROWTAB (start-up, from the loader): per VZ row r the Spectrum
; addresses of lines 3r, 3r+1, 3r+2 and of the attribute row of line 3r+1
ROWINIT:
    ld ix,ROWTAB
    ld d,0                               ; Spectrum line
    ld e,64
.r:
    ld b,3
.l:
    ld a,d                               ; HL = 4000h | (y&C0h)<<5 | (y&7)<<8 | (y&38h)<<2
    and $38
    rlca
    rlca
    ld l,a
    ld a,d
    and $C0
    rrca
    rrca
    rrca
    ld h,a
    ld a,d
    and 7
    or h
    or $40
    ld h,a
    ld (ix+0),l
    ld (ix+1),h
    inc ix
    inc ix
    inc d
    djnz .l
    ld a,d
    sub 2                                ; line 3r+1
    rrca
    rrca
    rrca
    and $1F
    ld l,a
    ld h,0
    add hl,hl
    add hl,hl
    add hl,hl
    add hl,hl
    add hl,hl
    ld bc,$5800
    add hl,bc
    ld (ix+0),l
    ld (ix+1),h
    inc ix
    inc ix
    dec e
    jr nz,.r
    ; fall through
; ---- TBLINIT: build the bank-1 lookup tables at start-up (keeps ELITE.VZ small)
TBLINIT:
    ld hl,MASKT                          ; MASKT[b] = b | (b<<1)&AAh | (b>>1)&55h ; VIEWTAB = MASKT ^ AAh
.mk:
    ld a,l
    add a,a
    and $AA
    or l
    ld c,a
    ld a,l
    srl a
    and $55
    or c
    ld (hl),a
    inc h
    xor $AA
    ld (hl),a
    dec h
    inc l
    jr nz,.mk
    ld hl,COLX                           ; COLX/COLP from the Spectrum attribute
.co:
    ld a,l
    call .s2v
    ld b,a                               ; ink
    ld a,l
    rrca
    rrca
    rrca
    call .s2v
    ld c,a                               ; paper
    cp b
    jr nz,.ne
    ld b,1
    cp 1
    jr nz,.ne
    ld b,2
.ne:
    ld a,c
    call .cb
    ld c,a                               ; CB[paper]
    ld a,b
    call .cb
    xor c
    ld (hl),a                            ; COLX = CB[ink]^CB[paper]
    inc h
    ld (hl),c                            ; COLP = CB[paper]
    dec h
    inc l
    jr nz,.co
    ld hl,ASC2VZ                         ; ASCII -> MC6847 code, upper case only
.as:
    ld a,l
    and $7F
    cp 97
    jr c,.a1
    cp 123
    jr nc,.a1
    sub 32
.a1:
    cp 32
    jr c,.a2
    cp 96
    jr c,.a3
.a2:
    ld a,32
.a3:
    and $3F
    ld (hl),a
    inc l
    jr nz,.as
    ld hl,POPC                           ; POPC = bit count, FIRSTB = leading zero bits
.pp:
    ld a,l
    ld bc,$0800
.p1:
    rlca
    jr nc,.p2
    inc c
.p2:
    djnz .p1
    ld (hl),c
    inc h
    ld a,l
    ld c,0
    ld b,8
.p3:
    rlca
    jr c,.p4
    inc c
    djnz .p3
.p4:
    ld (hl),c
    dec h
    inc l
    jr nz,.pp
    ; PRIST: the empty Spectrum scanner (lines 135-191, columns 8-23) from DSAVEBUF
    ld de,PRIST
    ld c,7                               ; line - 128
.pr:
    ld a,c
    and $38
    rlca
    rlca
    add a,8
    ld l,a
    ld a,c
    and 7
    add a,DSAVEBUF>>8
    ld h,a
    push bc
    ld bc,16
    ldir
    pop bc
    inc c
    ld a,c
    cp 64
    jr c,.pr
    jr .lz
.s2v:                                    ; Spectrum colour (A&7) -> VZ colour
    and 7
    push hl
    ld hl,.s2vt
    add a,l
    ld l,a
    jr nc,.s1
    inc h
.s1:
    ld a,(hl)
    pop hl
    ret
.s2vt:
    db 2,2,3,3,0,0,1,1
.cb:                                     ; VZ colour -> solid byte (x 55h)
    ld d,a
    xor a
    inc d
.c1:
    dec d
    ret z
    add a,$55
    jr .c1
.lz:
    ret
