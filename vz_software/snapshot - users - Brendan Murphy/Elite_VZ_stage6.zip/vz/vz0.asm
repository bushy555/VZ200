; ---------------------------------------------------------------------------
; Elite VZ layer, bank-neutral part (5D70-6047: the Spectrum font moved to bank 1)
; Everything here is reachable whichever expansion bank is mapped.
; ---------------------------------------------------------------------------
    org $5D70
    db LATCHBASE                        ; LATCHSH
    db 0                                ; BUSY
    dw 0                                ; VZFR
    dw 0                                ; LASTPRES
    dw 0, 0, 0                          ; BC_SP, BC_HL, BC_RET
    db 0                                ; DASHCNT
    db 0                                ; TEXTMODE
    ds GLYPHBUF-$, 0
    ds 8, 0                             ; GLYPHBUF
    ds VZINT1-$, 0

; IRQ while expansion bank 1 is mapped: bank 1 has JP VZINT1 at FEFEh.
; Map bank 0, run Elite's handler (it returns with EI once FS is high), map bank 1.
    assert $ == VZINT1
    push af
    ld a,MAP_B0
    out (MAPPER),a
    pop af
    call $FEFE
    push af
    ld a,MAP_B1
    out (MAPPER),a
    pop af
    ret

; Save interrupt state in P/V (NMOS-safe), then DI. Use: call DIPUSH ... then RESTI.
; (inline macro: the stack layout matters)
    macro DISAVE
        ld a,i
        jp pe,.ie
        ld a,i                          ; NMOS Z80: an IRQ accepted right after LD A,I reads as "off"
.ie:
        di
        push af
    endm
    macro EIREST
        pop af
        jp po,.noei
        ei
.noei:
    endm

; ---------------------------------------------------------------------------
; BANKCALL: call BANKCALL / dw target -- runs target with bank 1 mapped on the
; private stack. All registers and flags pass through both ways.
; Never nested: the interrupt path checks BUSY before using it.
BANKCALL:
    push af
    ld a,1
    ld (BUSY),a
    pop af
    ld (BC_HL),hl
    pop hl                              ; -> inline target
    push de
    ld e,(hl)
    inc hl
    ld d,(hl)
    inc hl
    ld (.jp+1),de
    pop de
    ld (BC_RET),hl
    ld hl,(BC_HL)
    ld (BC_SP),sp
    ld sp,PRIVTOP
    push af
    ld a,i                              ; map bank 1 and set MAPPED with interrupts off
    jp pe,.ie1
    ld a,i
.ie1:
    di
    push af
    ld a,MAP_B1
    out (MAPPER),a
    ld a,1
    ld (MAPPED),a
    pop af
    jp po,.n1
    ei
.n1:
    pop af
.jp:
    call 0
    push af
    ld a,i
    jp pe,.ie2
    ld a,i
.ie2:
    di
    push af
    ld a,MAP_B0
    out (MAPPER),a
    xor a
    ld (MAPPED),a
    ld (BUSY),a
    pop af
    jp po,.n2
    ei
.n2:
    pop af
    ld sp,(BC_SP)
    ld (BC_HL),hl
    ld hl,(BC_RET)
    push hl
    ld hl,(BC_HL)
    ret

; ---------------------------------------------------------------------------
; Frame presentation (replaces the Spectrum buffer -> screen copy at 7FBEh)
PRESENT:
    push hl
    ld hl,(VZFR)
    ld (LASTPRES),hl
    pop hl
    call BANKCALL
    dw B1_VIEW
    ret

; ---------------------------------------------------------------------------
; End of Elite's interrupt handler (replaces LD SP,(FF56h) / EI / RET at FF46h).
; Counts frames, refreshes the VZ screen on pages that never present a frame
; (text pages, charts), then waits for FS to go high: the VZ IRQ is a level
; held for the whole frame-sync period, so EI any earlier would re-enter.
ISREXIT:
    ld sp,($FF56)
    push af
    push hl
    ld hl,(VZFR)
    inc hl
    ld (VZFR),hl
    ld a,(BUSY)
    or a
    jr nz,.wait
    ld a,l
    and 7
    jr nz,.wait
    push de
    ld de,(LASTPRES)
    or a
    sbc hl,de
    pop de
    ld a,h
    or a
    jr nz,.full
    ld a,l
    cp 12                               ; no frame presented for a quarter second
    jr c,.wait
.full:
    ld a,(PAGEVAR)                      ; Elite's page number (70E3h)
    call BANKCALL
    dw B1_PAGE
.wait:
    ld a,(LATCH)
    rla
    jr nc,.wait
    pop hl
    pop af
    ei
    ret

; ---------------------------------------------------------------------------
; Dashboard save/restore around full-screen pages: bitmap 5000-57FF and
; attributes 5A00-5AFF (were copied to C000h and 5B00h) now go to bank 1.
DSAVE:
    call BANKCALL
    dw B1_DSAVE
    ret
DREST:
    call BANKCALL
    dw B1_DREST
    ret

; ---------------------------------------------------------------------------
; Glyph fetch for the print routine (font now in bank 1).
; In: A = character. Out: HL = GLYPHBUF holding its 8 rows. Uses A, BC.
GLYPH:
    push de
    ld (GCHAR),a
    xor a
    ld (GZ),a
    ld hl,(PRCOL)                       ; L = column, H = row (D045h / D046h)
    ld a,h                              ; rows 0-15 (the view): note the row for the
    cp 16                               ; 3-pixel labels; cleared with the view
    jr nc,.nm
    push hl
    ld hl,VIEWMASK
    cp 8
    jr c,.lo
    inc hl
    sub 8
.lo:
    ld b,a
    ld a,1
    inc b
.sh:
    dec b
    jr z,.st
    rlca
    jr .sh
.st:
    or (hl)
    ld (hl),a
    pop hl
    ld a,(PAGEVAR)                      ; 3D pages: the label shows the text, and the
    cp 4                                ; view is drawn at VZ resolution, so the
    jr c,.z                             ; Spectrum pixels are not wanted
    cp 13
    jr c,.nm
.z:
    ld a,1
    ld (GZ),a
.nm:
    ld a,h
    rrca
    rrca
    rrca
    ld d,a
    and $E0
    or l
    ld e,a                              ; row*32 + column (low)
    ld a,d
    and $1F
    ld d,a
    ld hl,TEXTSHADOW
    add hl,de
    ld (GSHAD),hl
    ld a,(PRXOR)                        ; A9h = XOR C (normal), 00h = overwrite
    ld (GXOR),a
    ld a,(GCHAR)
    sub $20
    ld l,a
    ld h,0
    add hl,hl
    add hl,hl
    add hl,hl
    ld bc,FONT1
    add hl,bc
    ld a,(GZ)
    or a
    jr z,.f
    ld hl,FONT1                         ; the space: eight empty rows
.f:
    ld de,GLYPHBUF
    DISAVE
    ld a,MAP_B1
    out (MAPPER),a
    ldi
    ldi
    ldi
    ldi
    ldi
    ldi
    ldi
    ldi
    ld hl,(GSHAD)                       ; record the character in the text shadow
    ld a,(GXOR)
    or a
    ld a,(GCHAR)
    jr z,.put
    cp (hl)
    jr nz,.put
    ld a,' '                            ; XOR over the same character erases it
.put:
    ld (hl),a
    ld a,MAP_B0
    out (MAPPER),a
    EIREST
    ld hl,GLYPHBUF
    pop de
    ret

; ---------------------------------------------------------------------------
; Spectrum ROM PIXEL-ADD replacements (22AAh / 22B0h / 22B1h).
; B = pixel line (0 = top), C = x. Out: HL = screen byte, A = x AND 7.
P22AA:
    ld a,$AF
    sub b
P22B0:
    ld b,a
P22B1:
    ld a,b
    and $38
    rlca
    rlca
    ld l,a
    ld a,c
    rrca
    rrca
    rrca
    and $1F
    or l
    ld l,a
    ld a,b
    and $C0
    rrca
    rrca
    rrca
    ld h,a
    ld a,b
    and $07
    or h
    or $40
    ld h,a
    ld a,c
    and $07
    ret

; Text control 11 draws the heading rule straight onto the screen (D55Ch). On
; the Spectrum the next buffer copy hid it on the cockpit pages; here those
; pages draw on the screen itself, so the rule would stay. Text and chart
; pages (4-12) keep it.
LINE11:
    ld a,(PAGEVAR)
    cp 4
    ret c
    cp 13
    ret nc
    jp LD55C

; View clear (8080h, 3D pages only): bank 1 forgets the view's text rows,
; wipes the circles Elite drew into the Spectrum screen last frame and empties
; the VZ-resolution view in DOS bank 1.
VCLR:
    call BANKCALL
    dw B1_VCLR
    ei
    ret

; ---------------------------------------------------------------------------
; Start-up after unpacking: Benn Venn mapping, mode(1), then Elite's entry.
VZSTART:
    di
    ld a,1
    out (VZMODE),a
    ld a,MAP_B0
    out (MAPPER),a
    ld a,LATCHBASE
    ld (LATCHSH),a
    ld (LATCH),a
    xor a
    ld (BUSY),a
    ld (TEXTMODE),a
    ld hl,VIDEO
    ld de,VIDEO+1
    ld bc,$07FF
    ld (hl),$AA                         ; blue
    ldir
    ld sp,$0000
    ld a,IM2PAGE
    ld i,a
    im 2
    ei
    jp ELITE_ENTRY

VZ0_END:
    assert VZ0_END <= FONTGLUE_END

; ---------------------------------------------------------------------------
; second glue area: 7800-7897 (freed when 6800-77FF moved)
    org $7800
VZCLS:                                  ; Elite's CLS (D61Dh): also clear the text shadow
    call BANKCALL
    dw B1_CLS
    di                                  ; the two instructions replaced at D61Dh
    ld (CLS_SPSAVE),sp
    jp ELITE_CLS2
; Sound: Spectrum speaker (OUT FEh bit 4) -> VZ speaker (latch bits 0 / 5)
SPKON:
    push af
    ld a,(LATCHSH)
    or $01
    ld (LATCH),a
    pop af
    ret
SPKOFF:
    push af
    ld a,(LATCHSH)
    or $20
    ld (LATCH),a
    pop af
    ret
VZOUT:                                  ; AND 18h / OUT (FEh),A
    and $18
    bit 4,a
    jr nz,SPKON
    jr SPKOFF

; Spectrum ROM BEEPER (03B5h): HL = pitch, DE = number of cycles.
; Half period about 4*HL+120 T, as in the ROM.
BEEP:
    di
    push hl
    srl h
    rr l
    srl h
    rr l
    srl h
    rr l                                ; HL/8
    ld b,h
    ld c,l
    srl b
    rr c                                ; HL/16
    add hl,bc
    inc hl
    ld b,h
    ld c,l                              ; BC = delay count (26 T each)
    pop hl
.cyc:
    call SPKON
    push bc
.d1:
    dec bc
    ld a,b
    or c
    jr nz,.d1
    pop bc
    call SPKOFF
    push bc
.d2:
    dec bc
    ld a,b
    or c
    jr nz,.d2
    pop bc
    dec de
    ld a,d
    or e
    jr nz,.cyc
    ei
    ret

; KEYF: fast front end for KEYROW (B = Spectrum half-row select). One read of
; all the VZ keyboard rows that half-row uses, plus the joysticks: if nothing
; is pressed there, answer "no keys" at once instead of testing 5 keys singly.
KEYF:
    push hl
    push de
    ld a,b
    ld hl,SPKFAST-2
KF_f: inc hl
    inc hl
    rrca
    jr c,KF_f
    ld e,(hl)                           ; VZ rows used by this half-row
    ld d,$68
    inc hl
    ld a,(de)
    cpl
    and (hl)                            ; any of its key bits low?
    pop de
    pop hl
    jr nz,KF_slow
JIN1A:
    in a,(JOY1)
    and $1F
    cp $1F
    jr nz,KF_slow
JIN2A:
    in a,(JOY2)
    or $E0
    inc a
    ld a,$1F
    ret z
KF_slow:
    jp KEYROW
; per half-row (same order as SPKTAB): AND of its VZ row selects, OR of its key bits
SPKFAST:
    db $FB,$3E, $FD,$3B, $FE,$3B, $F7,$3B, $DF,$3B, $BF,$3B, $3F,$2F, $E9,$35

VZA_END:
    assert VZA_END <= $7898

; ---------------------------------------------------------------------------
; 5B00-5D6F: freed by moving the scanner/attribute save buffers to bank 1.
    org $5B00
; IM2 vector (any data-bus value): either bank may be mapped.
VZIRQ:
    push af
    ld a,(MAPPED)
    or a
    jr nz,.b1
    pop af
    jp $FEFE                            ; Elite's handler, bank 0 already mapped
.b1:
    ld a,MAP_B0
    out (MAPPER),a
    pop af
    call $FEFE                          ; returns with EI once FS is high
    push af
    ld a,MAP_B1
    out (MAPPER),a
    pop af
    ret

; Scanner background save/restore (990Ch-9944h) copies between the screen and
; a buffer that was at 5B00h; it now runs with bank 1 mapped and interrupts off.
SCMAP:                                  ; replaces LD DE,5049h at 990Ch
    pop hl                              ; return address, read while bank 0 is mapped
    ld a,i
    jp pe,.ie
    ld a,i
.ie:
    di
    ld a,0
    jp po,.s
    inc a
.s:
    ld (SCIFF),a
    ld a,MAP_B1
    out (MAPPER),a
    ld de,$5049
    jp (hl)
SCTAIL:                                 ; replaces DEC A / JR NZ,9915h / RET at 9941h
    dec a
    jp nz,L9915
    ld a,MAP_B0
    out (MAPPER),a
    ld a,(SCIFF)
    or a
    ret z
    ei
    ret
; ---------------------------------------------------------------------------
; Keyboard: replaces IN A,(C) / AND 1Fh in Elite's scan (FD78h).
; B = Spectrum half-row select (one 0 bit). Returns A = 5 key bits, 0 = pressed.
; Joysticks 1 and 2: up = S (dive), down = X (climb), left = N, right = M (roll),
; fire = A (laser).
KEYROW:
    push bc
    push de
    push hl
    ld a,b
    ld (KR_sel+1),a                       ; remember the half-row select
    ld hl,SPKTAB
    ld de,10
KR_find:
    rrca
    jr nc,KR_got
    add hl,de
    jr KR_find
KR_got:
    ld c,$1F                            ; result, active low
    ld b,$01                            ; result bit
    ld d,$68
KR_key:
    ld e,(hl)
    inc hl
    ld a,(de)
    and (hl)
    inc hl
    jr nz,KR_np
    ld a,b
    cpl
    and c
    ld c,a
KR_np:
    sla b
    bit 5,b
    jr z,KR_key
JIN1B:
    in a,(JOY1)                         ; joysticks: active low (loader turns these into
    ld e,a                              ; ld a,$FF when no joystick interface answers)
JIN2B:
    in a,(JOY2)
    and e
    cpl
    and $1F
    jr z,KR_done
    ld e,a                              ; e: bit0 up,1 down,2 left,3 right,4 fire
KR_sel:
    ld a,0
    cp $FD                              ; A S D F G
    jr nz,KR_r1
    bit 0,e
    jr z,KR_f1
    res 1,c                             ; up -> S (dive)
KR_f1:
    bit 4,e
    jr z,KR_done
    res 0,c                             ; fire -> A
    jr KR_done
KR_r1:
    cp $FE                              ; SHIFT Z X C V
    jr nz,KR_r2
    bit 1,e
    jr z,KR_done
    res 2,c                             ; down -> X (climb)
    jr KR_done
KR_r2:
    cp $7F                              ; SPACE SYM M N B
    jr nz,KR_done
    bit 2,e
    jr z,KR_rr
    res 3,c                             ; left -> N
KR_rr:
    bit 3,e
    jr z,KR_done
    res 2,c                             ; right -> M
KR_done:
    ld a,c
    pop hl
    pop de
    pop bc
    ret
; Spectrum half-row (FE,FD,FB,F7,EF,DF,BF,7F) x 5 keys: VZ row address low byte, VZ bit
SPKTAB:
    db $FB,$04, $FB,$10, $FB,$02, $FB,$08, $FB,$20      ; CAPS=SHIFT Z X C V
    db $FD,$10, $FD,$02, $FD,$08, $FD,$20, $FD,$01      ; A S D F G
    db $FE,$10, $FE,$02, $FE,$08, $FE,$20, $FE,$01      ; Q W E R T
    db $F7,$10, $F7,$02, $F7,$08, $F7,$20, $F7,$01      ; 1 2 3 4 5
    db $DF,$10, $DF,$02, $DF,$08, $DF,$20, $DF,$01      ; 0 9 8 7 6
    db $BF,$10, $BF,$02, $BF,$08, $BF,$20, $BF,$01      ; P O I U Y
    db $BF,$04, $7F,$02, $7F,$08, $7F,$20, $7F,$01      ; ENTER=RETURN L K J H
    db $EF,$10, $FD,$04, $EF,$20, $EF,$01, $FB,$01      ; SPACE SYM=CTRL M N B

VZB_END:
    assert VZB_END <= $5C00

    org $5C00
    ds 257,$5D                          ; IM2 table: every vector reads 5D5Dh
    org IRQJP
    jp VZIRQ


; ===========================================================================
; Commander save/load on cassette. Elite's tape menu (D90Ah, entered through
; D04Eh from the title's "Load New Commander" and from the docked SYMBOL SHIFT
; = CTRL key) was replaced by a ship blueprint when the code moved, so it is
; rebuilt here in three spare pieces of bank-0 memory, calling Elite's own text,
; input and message routines as the original did. The Spectrum ROM tape calls
; become VZ cassette routines in bank 1 (vz/tape.asm).
; Returns NZ if a commander was loaded (Elite then restarts on it), as before.
; ===========================================================================
TM_FLAG   equ $D907                     ; the original menu's own variables
TM_SP     equ $D908
CMDR      equ $D054                     ; commander block (102 bytes; 5Dh kept as backup)
CMDRBAK   equ $D232
TNAME     equ $DED0                     ; name typed for LOAD

    org $7FC1                           ; free: the Spectrum buffer copy (7FC1-8041)
TAPEMENU:
    ld a,(PAGEVAR)                      ; show the menu as a VZ text page
    push af
    ld a,11
    ld (PAGEVAR),a
    call TMENU
    pop bc
    ld a,b
    ld (PAGEVAR),a                      ; flags from TMENU kept
    ret
TMENU:
    call $D61D                          ; CLS
    ld de,$D902                         ; heading
    call $D568
    call $D54F
    ld a,$0F
    call $EB6E
    xor a
    ld (TM_FLAG),a
    inc a
    call $D45F                          ; "1 load / 2 save / 3 exit" text
    ld (TM_SP),sp
TKEY:
    ld sp,(TM_SP)
    call $E1F7                          ; wait for a key
    sub '1'
    jp z,TLOADM
    dec a
    jr z,TSAVEM
    dec a
    jr nz,TKEY
    call $E832
    call $E205
    ld a,(TM_FLAG)
    and a
    ret
TSAVEM:
    ld hl,CMDR
    call TNAMEIN                        ; name -> the block itself
    ld hl,D7107                         ; current state into the block
    ld de,$D0B1
    ld bc,9
    ldir
    ld a,$02                            ; "start tape, press a key"
    call TMSG
    call $E1F7
    call TSAVE0
    ld a,$97                            ; "complete"
    call TMSG
TOK:
    ld hl,CMDR                          ; keep as the backup copy
    ld de,CMDRBAK
    ld bc,$005D
    ldir
    jp TKEY
TAREA1_END:
    assert TAREA1_END <= $8042

    org $FCEA                           ; free: the unused part of the Spectrum IM2 table
TLOADM:
    ld hl,TNAME
    call TNAMEIN
TL1:
    call TLOAD0
    jr nc,TLERR
    ld a,1
    ld (TM_FLAG),a
    ld a,$D6                            ; "loaded"
    call TMSG
    ld hl,TNAME                         ; blank name: take any file
    ld de,CMDR
    ld a,(hl)
    and a
    jp z,TOK
    ld b,$0B
TL2:
    ld a,(de)
    cp (hl)
    jr nz,TL1                           ; another commander: keep reading
    or (hl)
    jp z,TOK
    inc hl
    inc de
    djnz TL2
    jr TL1
TLERR:
    push af                             ; restore the commander in memory
    ld hl,CMDRBAK
    ld de,CMDR
    ld bc,$005D
    ldir
    pop af
    or a
    ld a,$03                            ; "error"
    jr z,.m
    ld a,$C7                            ; key pressed: abandoned
.m:
    call TMSG
    jp TKEY
TMSG:
    push af                             ; the message row is cleared with pixel writes,
    call BANKCALL                       ; which the text shadow does not see
    dw B1_TCLR
    pop af
    jp TMSG3
TAREA2_END:
    assert TAREA2_END <= $FD41

    org $DA27                           ; free: end of the old tape menu area
TMSG3:
    push af                             ; message on row 22 (as D A5Ah did)
    xor a
    ld ($D0D1),a
    ld hl,$1600
    ld ($D045),hl
    call $E37A
    pop af
    call $D45F
    call $E2A9
    jp $E1E8
TSAVE0:
    ld hl,CMDR
    ld de,TBUF
    ld bc,TLEN
    ldir
    call BANKCALL
    dw B1_TSAVE
    ei
    ret
TLOAD0:
    call BANKCALL
    dw B1_TLOAD
    ei
    ret nc
    ld hl,TBUF
    ld de,CMDR
    ld bc,TLEN
    ldir
    scf
    ret
TNAMEIN:
    ld b,$0A                            ; up to 10 characters
    ld a,$08
    jp $E3CC
TAREA3_END:
    assert TAREA3_END <= $DA72

; ===========================================================================
; VZ-resolution drawing hooks. On 3D pages (Elite page 0-3 or 13 up) lines,
; explosion particles and star dust go to DOS bank 1 (vz/dos1.asm), drawn
; straight into the VZ-format view; circles are still drawn Spectrum-style
; and only their rows are converted.
; ===========================================================================
    macro TEST3D legacy
        ld a,(PAGEVAR)
        cp 4
        jr c,.n3d
        cp 13
        jr c,legacy
.n3d:
    endm

    org $8085                           ; free: Elite's push-fill view clear
TA:       db 0
GZ:       db 0
TDUMMY:   db 0
D1IE:     db 0
; BREATHE: let a waiting interrupt in (called from long DOS-bank-1 work)
    assert $ == BREATHE
    ld a,(D1IE)
    or a
    ret z
    ld a,MAP_B0
    out (MAPPER),a
    ei
    nop
    di
    ld a,MAP_D1
    out (MAPPER),a
    ret
; D1SH: run DOS-bank-1 routine IX with interrupts off; A passes via TA both ways
D1SH:
    ld a,i
    jp pe,.ie
    ld a,i
.ie:
    di
    push af
    ld a,0
    jp po,.s
    inc a
.s:
    ld (D1IE),a
    ld a,MAP_D1
    out (MAPPER),a
    ld a,(TA)
    call .jx
    ld (TA),a
    ld a,MAP_B0
    out (MAPPER),a
    pop af
    jp po,.n
    ei
.n:
    ld a,(TA)
    ret
.jx:
    jp (ix)
TRA_END:
    assert TRA_END <= $80D1

    org VZ0_END
; TR_CIRC: before Elite draws a circle (call at 86E9h)
TR_CIRC:
    TEST3D .leg
    push ix
    ld ix,D1_CIRC
    call D1SH
    pop ix
    or a
    ret nz                              ; drawn at VZ resolution
.leg:
    jp L86EE
; TR_DOT: explosion particle (call at A83Dh, B = y, C = x)
TR_DOT:
    TEST3D .leg
    push ix
    ld ix,D1_DOT
    call D1SH
    pop ix
    ld hl,TDUMMY                        ; Elite's XOR lands here
    ld a,c
    and 7
    ret
.leg:
    jp P22B1
; TR_DUST: star dust (7C92h)
TR_DUST:
    TEST3D .leg
    push ix
    ld ix,D1_DUST
    call D1SH
    pop ix
    ret
.leg:
    ld hl,$7F82
    jp $7C95
; TR_LINE: Elite's line at B0E0h (A = count, see dos1.asm)
TR_LINE:
    ld (TA),a
    TEST3D .leg
    push ix
    ld ix,D1_LINE
    call D1SH
    pop ix
    exx                                 ; return with the alternate set, as Elite's loops do
    ret
.leg:
    ld a,(TA)
    exx
    cp 2
    jp nc,LB0E7
    ld a,2
    jp LB0E7
TRB_END:
    assert TRB_END <= FONTGLUE_END
