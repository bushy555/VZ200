ROD-LAND for the Dick Smith VZ300
=================================
Converted from the ZX Spectrum 128K version (1991 The Sales Curve / Jaleco,
Spectrum conversion by Twilight).  VZ conversion vibed by BPM 2026.

Requirements
  VZ300 with the BennVenn SD loader (128K RAM expansion).

Files (copy BOTH into the same folder on the SD card)
  RODLAND.VZ    the game - load and run this one
  RODPICS.DAT   the story pictures, loaded automatically by RODLAND.VZ
                (without it the game still plays; story scenes show text only)

Controls
  Title:     1 = one player, 2 = two players (fire also starts)
  Player 1:  Q up, A down, O left, P right, SPACE or M fire - or joystick 1
  Player 2:  T up, G down, F left, H right, Z fire          - or joystick 2
  RETURN     pause / resume
  Any key or fire skips waits in the story scenes.

Notes
  - Runs the original Spectrum game logic at the original 25 frames/second,
    with VZ mode(1) graphics, mode(0) semigraphic title and game over screens,
    two-voice versions of the Spectrum title and story tunes, and all sound effects.
  - All 35 scenes, the four boss fights, extra-life fairy, ending and credits included.
  - Leave the title screen alone for ~25 seconds to see the intro story.
