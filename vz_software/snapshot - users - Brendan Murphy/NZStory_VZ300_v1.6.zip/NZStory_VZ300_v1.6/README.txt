THE NEW ZEALAND STORY  -  VZ300 conversion  v1.6  (26 October 2026)
(from the ZX Spectrum version, Ocean 1989 / Taito, coded by 'Choice', programmed by G. Weatherup)
=============================================================================================

FILES  (copy both to the ROOT of the SD card)
  NZSTORY.VZ      the game (machine code, 20.4K, loads at $7AE9)
  NZSTORY.DAT     all level maps, tile sets, sprite sets, music and screens
                  (28K) - read from the SD card while you play, using the same
                  DOS calls as 13 Ghosts' 13GHOST?.DAT loading
  Then:  LOAD"NZSTORY"   (or pick it from the SD loader menu)

REQUIREMENTS
  VZ300 + BennVenn SD loader with the 128K RAM expansion.
  The game runs in DOS SRAM bank 1 and the VZ300/expansion RAM; DOS bank 0 and
  the DOS RAM at $FA00-$FFFF are left alone so the DOS can still load the
  .DAT files during play. Reset to return to the DOS.

CONTROLS
  Keyboard      Q up (jump / fly),  A down,  O left,  P right
                SPACE or M  fire
                H  pause / resume       CTRL+Q  quit to the title
                (the Spectrum keys 6 7 8 9 0 and the redefined set also work)
  Joysticks     both VZ joysticks: directions + fire, ARM button = jump (up).
  Title screen  FIRE / SPACE starts,  J joystick on/off,  M music on/off.
                Leave it for ~22 seconds and a demo plays (worlds 1-5 in turn);
                any key returns to the title.
                Typing the original cheat word on the title screen still works
                (then RETURN in the game skips a level).

WHAT'S IN IT
  * The original Spectrum game engine runs unchanged: all 21 levels in 5 worlds,
    the four bosses, items, weapons, vehicles, water/air, scoring and lives.
  * Replaced with VZ code: tile renderer (mode(1) 128x64, 4 colours, only
    changed tiles redrawn), masked sprite blitter, status panel, keyboard and
    joystick input, speaker effects, music player, the tape multiload (now SD
    files) and the front-end screens.
  * Artwork, reviewed object by object for what it is meant to look like,
    using all four mode(1) colours (green, yellow, blue, red):
    - Walls and platforms are drawn as solid objects with a lit top/left edge
      and a shadowed bottom/right edge, worked out from where each tile sits in
      the real maps; their own texture (dithers, cracks, carving) stays as a
      two-tone pattern. Jump-through rock is a darker rubble so you can tell it
      from solid wall. Backgrounds and signs are subdued, spikes/stars are red
      and yellow, water is water.
    - The most-used tiles in each world are hand-drawn at VZ resolution
      (world 1 stone blocks, slabs, pillars, ground and ceiling strips, spikes;
      world 2 carved stone, small tiles, mines, floor spikes).
    - World palettes: 1 green stone, 2 red/yellow carved stone + dark rubble,
      3 yellow cracked walls + green water, 4 mossy red rock with green/yellow
      edges, 5 red/green panels.
    - Tiki is hand-drawn in every frame: yellow body, eyes, red beak and feet,
      green wing shadow, diving mask when swimming. The standard enemies (cats,
      raccoon, chicks in pots, bears with spears, imps, bats) are hand-drawn
      with faces; the rest of the sprites are converted as filled shapes with
      eyes and solid features kept and line work in a second colour, and the
      bosses with their hatching turned into light/mid/dark shading.
  * Scaling: 2:1 horizontally, 8:3 vertically (true Spectrum proportions); the
    play area is the Spectrum's full 32x18 character window.
  * Screens: mode(0) title / level start / game over. Lettering is shaded
    per row (white-to-cyan "NEW ZEALAND", yellow-orange-red "STORY" and
    "GAME OVER"), sky and grass borders, and two Tiki kiwis with eyes that walk
    and blink. In-game text and the score panel use the same shaded font, as
    does the ending picture's text.
  * The 48K Spectrum never showed its ending picture (it just dumped the
    packed data on the screen) - this version decodes the 128K ending
    ("THE LEOPARD SEAL WAS SELLING KIWIS...") and shows it properly.
  * Music: the 128K AY tunes (title theme, level intro, hurry up, game over,
    ending) converted to a three-channel speaker player: 16-bit phase
    accumulators for true pitch over the full AY range (bass stays bass),
    pulse-interleaved mixing, pulse width following the AY volume so notes
    decay, and the AY noise hits played as short drum bursts. All in-game
    beeper effects come from the 48K version.
  * Speed matches the Spectrum (game frame every 3.5 VZ frames on average).

ATTRACT MODE
  * Five recorded demos (start of each world). Playback is exact: the demo
    feeds recorded inputs per game loop and seeds the random number generator
    the same way each loop, so it does not depend on interrupt timing (checked
    with the emulator's frame timing skewed both ways). A demo never changes
    the high score.

VERSION HISTORY
  v1.1  fix: the title screen froze (kept restarting) after the first demo.
  v1.0  first release: reviewed artwork, shaded text, animated title kiwis,
        attract-mode demos, three-channel music player, collision fixes.

NOTES
  * Tested in an emulator model of the VZ300 + BennVenn (including a model of
    the DOS file calls the 13 Ghosts loader uses: $5F00 find, $5F03 first
    sector, $5F09 next sector, buffer pointer at $FB80). If a data file can't
    be read the game stops on a "CAN'T LOAD DATA FILE NZSTORY.DAT" screen.
  * No in-game music (as on the 48K Spectrum) - music plays on the front-end
    screens and during HURRY UP.
  * Hiscore is kept until reset (no save).
  * Demos last about 30 s (5-1 about 24 s) and end before the kiwi loses a
    life; if one ever goes wrong on real hardware, tell me which world.

PACKAGE
  NZSTORY.VZ, NZSTORY.DAT   the game (both go on the SD card)
  README.txt                this file
  screenshots/              19 screenshots: front end, every world, busy
                            enemy scenes and the four bosses
  NZStory_VZ300_v1.6_source.zip (separate download)  conversion source: Z80
                            (sjasmplus), Python build tools and the test
                            emulator. Building needs the original Spectrum
                            tapes, which are not included.

The New Zealand Story is (C) 1988 Taito; ZX Spectrum version (C) 1989 Ocean.
This is a non-commercial fan conversion for the VZ300.
