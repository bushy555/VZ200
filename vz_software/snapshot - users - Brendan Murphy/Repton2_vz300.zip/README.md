# Repton 2 — ZX Spectrum → Dick Smith VZ300 conversion

`build/REPTON2.VZ` (26,256 bytes) runs on a VZ300 with the **BennVenn SD loader + 128 KB RAM**.
Copy it to the SD card and load it from the BennVenn DOS like any other `.VZ`.

The original Spectrum Repton 2 engine (Speedlock 7 tape, "GJS'88") runs **unmodified at its original
addresses**. Only the Spectrum hardware layer (screen, keyboard, beeper, interrupts) and the presentation
screens were replaced with native VZ300 code.

## Controls

| Action | Keys | Joystick |
|---|---|---|
| Move | Q up, A down, O left, P right (as the Spectrum) | either VZ joystick (J1 or J2) |
| Start / continue | SPACE | FIRE on either joystick |
| Status screen during play (pause) | SPACE | FIRE (press again to carry on) |
| Lose a life (Spectrum CAPS+1) | CTRL+1 | |
| Quit game (Spectrum CAPS+R) | CTRL+R | |
| Sound / music on-off | D / E | |
| Hi-score name entry | letters, digits, SPACE; RETURN ends, CTRL deletes | |

Keyboard and both joysticks are read every step, so no control selection is needed (the Spectrum's
"CONTROL (J)" option was dropped). A joystick port that reports up+down or left+right at the same time is
treated as absent, so an unplugged or floating interface can never steer Repton.
Joystick 1 directions are read from port $2C, joystick 2 from $29 and $23 combined. On your interface those
are the ports where the arm-select line is also low.

## What you see

All menu screens use the VZ's text/semigraphics mode with the CSS=1 (orange) text colours.
Each has big semigraphics lettering with a black outline, over a slowly scrolling background drawn from
Repton map tiles, then a rainbow divider and an orange text band.

* **Title:** huge "REPTON" with a "2" between two diamonds, in colour-cycling bands, over scrolling bricks, earth,
  diamonds and rocks. The original Repton 2 title tune plays (ported to the VZ speaker).
* **Attract loop:** title → credits → hi-scores → **demonstration**. In the demo the real engine plays level 1 for about
  35 seconds from a recorded 650-step input sequence (`demo/best_1.txt`, chosen by an automated planner that path-finds
  to earth and diamonds and keeps only moves the engine survives). Any key or fire returns to the title. Losing a life also
  returns to the title, and your last score is restored.
* **Credits:** original game, Spectrum version, and "VZ CONVERSION / VIBED BY BPM 2026".
* **Status (start) screen:** header over scrolling green walls, transporters and diamonds, with score, lives and the
  remaining earth, diamonds, transporters, puzzle pieces and monsters. Fire or SPACE during play brings this screen up
  (the game pauses); fire again returns exactly where you were.
* **Game over:** big "GAME" / "OVER" over falling rocks and skulls, with a lament jingle, then hi-score entry and the hi-score table.
* **Completion:** the original fireworks, then an "AMAZING!" screen with fanfare.

## Graphics

* Gameplay uses CG2: 128×64 pixels in 4 colours (green, yellow, blue, red), with blue as the background.
* **Tile size: 16×12 VZ pixels.** A straight 2:1 downscale of the 32×32 Spectrum tiles gives 16×16. The VZ's
  pixels are 2:3 (wide:tall), so 16×16 tiles look 50 % too tall and only 4 tile rows fit on screen. At 16×12 the
  tiles look nearly square (32×36 in Spectrum-pixel terms). A quarter tile, which is the engine's movement and
  scroll unit, is then exactly 1 byte × 3 lines, so all drawing is byte-aligned.
* **View: 8 × 5¼ tiles** (32 × 21 quarter cells) against the Spectrum's 6 × 6. Repton is kept centred, with 9
  quarters above and 8 below.
* The artwork was redrawn by hand from automatic downscales (see `art/vzart.py`): rock with a highlight
  crescent, skull face, diamond, key, transporter rings, safe, cage, monsters, 13 Repton animation frames,
  spirits and explosion frames. Walls are generated from the Spectrum tiles' edge and corner variants, so walls join
  seamlessly. Earth is a sparse "pebble" texture.
* **Per-level colours:** the Spectrum gives each level its own ink colour. The port recolours the 19 wall and earth
  tiles when a level loads, using the level's palette byte: blue levels get green walls, cyan and magenta levels get yellow walls, and red levels get red walls.
  Rocks, Repton and the other objects keep fixed colours, so rocks stay readable on every level.
* **Spirits** are drawn with XOR, as on the Spectrum (centre 8×6 pixels). Puzzle pieces are expanded at run
  time from the original 8×8 piece bitmaps, as the original does.

## How the renderer works

The playfield is a **world-anchored ring buffer** of 32×21 quarter cells (`RING`, $C000–$CA7F, 128-byte rows).
World quarter (x, y) always lives at ring column x mod 32 and ring row y mod 21. When the engine scrolls, no data
moves: the scroll call only records the step type for pacing, and the strip routine draws the single newly
exposed quarter row or column straight from the map. Tile draws (`E024`) are dirty-tile updates into the ring.
Once per game step `vz_sync` waits for the correct frame and copies the ring to video RAM, rotated to the
camera. That is 2,016 bytes through an unrolled LDI block, about 10 ms, finishing ahead of the beam.

**Timing** matches the Spectrum, as measured on the original in an emulator: each main-loop step lasts
2 frames when standing, 3 when moving vertically and 4 when moving horizontally. The port uses the same
frame targets on the 50 Hz field-sync interrupt. Measured on the VZ, the logic and drawing take a median of
21 K T-states per step against a 142 K T-state budget.

## Engine routines — retained / patched / replaced

**Retained unchanged (original Spectrum code at its original address):**
the main loop `F838`; player movement and input decoding `E484`–`E7C9`; rock and egg physics `EB35`;
monsters `ECC5`–`EE6E`; spirits (wall followers) `EEAD`–`EF9F`; random "drift" objects `EFC6`; XOR sprite pass
`F03A`; sound-event dispatcher `F07E`; collection, score and counters `E9C2`, `E7A6`; transporters, puzzle pieces, keys
and safes `E5B7`–`E796`; the level unpacker `E1E8` (5-bit packed maps); death sequence `DB7C`; death handler `F887`;
new game `F7CC`; restart `F818`; level/object tables `7C20`–`8008`; music data `8C9B`–`8D9D`; puzzle bitmaps `8D9E`;
`D0F7`–`DABF` tables (level palettes, input tables, note periods, hi-score names); and the completion fireworks `FAEB`–`FB6E`.

**Patched (a jump or byte change at the original address):**

| Address | Original purpose | Now |
|---|---|---|
| `E024` | draw tile into Spectrum back buffer | `vz_drawtile` – clipped quarter-cell draw into the VZ ring (copy or XOR) |
| `E168` / `E19E` | select XOR / copy drawing (self-modifying) | `vz_xormode` / `vz_copymode` |
| `DFC5` | build puzzle-piece tile graphic | `vz_puzzle` – expands the 8×8 bitmap to a 16×12 VZ tile |
| `DF07` | HALT + copy back buffer to screen | `vz_sync` – Spectrum-matched frame pacing + ring→VRAM blit |
| `E865` | rotate Spectrum ring buffer | `vz_scroll` – records step type (3/4-frame pacing) |
| `E9F8` | draw exposed strip (Spectrum geometry) | `vz_strip` – after the original camera update `E9DE`–`E9F7` |
| `EAD2` | strip parameter setup | `RET` (not needed) |
| `DC30` | new screen: clear buffers, draw 8×8 tiles | `vz_newscreen` – resets view, draws full VZ view from map, rejoins at `DCAA` |
| `DCCF` | copy to screen with wipe | draws Repton then `vz_reveal` (centre-out wipe) |
| `DB3D` / `DB4B` / `DB08` | clear / dissolve / fade Spectrum screen | `vz_cls` / `vz_fade` |
| `DD43` | Spectrum keyboard, Kempston, Sinclair, cursor | `vz_keys_game` → `vz_keys` – VZ keyboard + both joysticks |
| `DC0C` | beeper effects (self-modifying op) | `vz_beep` – same loop structure on the VZ latch |
| `DE06`, `F985` | IM2 interrupt handlers | `vz_isr` – frame counter, rock "thud" (`DE31` equivalent), FS wait |
| `F0E0` | transporter attribute flash + tone | `vz_transport` – CSS colour-set flash + same tone |
| `F5CD` | status / title screen | `vz_status` (VZ text + SG4) |
| `F4AD` | game over / hi-score entry / table | `vz_gameover` |
| `FB71` | completion message screen | `vz_complete` |
| `E203` | level data base `$5B00` | `$40` → level data now at `$4000` (BennVenn DOS RAM page 0) |
| `E300` | after level palette is set | `vz_lc_hook` → recolour wall/earth tiles, then continue |
| `F6F6` | cold start (Speedlock relocation, IM2 table, defaults) | `vz_init` |

**Replaced, now unused:** the Spectrum ring-buffer and attribute code (`E0BA`, `E10A`, `E96A`, `E98E`, `EA03`–`EAD1`),
the wipe `DD02`, the title colour cycler and logo (`F93B`, `F430`, `F43C`–`F4AC`), the bitmap text printer `FA1F`/`FA4E`,
the name-entry keyboard `F230`–`F2EA`, and the title music player `F301` (re-implemented with identical
96-T-state sample timing as `mus_note`).

Behaviour was checked against the original by driving both the Spectrum original and the VZ port
(in emulators) with the same per-step input sequence. Map, objects, position, score and all counters were
identical. The only difference was the R-register-seeded "drift" object table (`B194`), which depends on
instruction timing on the real Spectrum too.

## Memory use

| Range | Bytes | Contents |
|---|---|---|
| `4000–611F` | 8,480 | level data (BennVenn DOS-area RAM page 0) |
| `7000–77FF` | 2,048 | video RAM |
| `7C20–8007` | 1,000 | original transporter / puzzle / object tables |
| `8008–892E` | 2,343 | VZ renderer, input, sound, init |
| `8C9B–8EED` | 595 | original music data and puzzle bitmaps |
| `8EEE–AC5A` | 7,533 | lookup tables, VZ tiles, menu screens, demo data |
| `B01E–BAF7` | 2,778 | original game work RAM, map buffer, main-level backup |
| `C000–CA7F` | 2,688 | VZ ring buffer |
| `CA80–CFAC` | 1,325 | tile colour-variant sources, 5×7 font |
| `D0F7–D32F`, `D887–DABF` | 1,138 | original tables, hi-score names |
| `D330–D838` | 1,289 | menu graphics engine, big font, background tiles/maps |
| `DAC0–FFFF` | 9,536 | original engine code, data, stack, IM2 table, variables (unused original code at `F230` holds the menu letter buffer) |

In total about **38.7 KB** is resident plus 2 KB of video RAM, with about 5 KB still free in gaps. Expansion bank 1 (16.8 KB)
and DOS-area RAM page 1 (8 KB) are only used while loading.

**Loading:** the `.VZ` loads at `$7AE9`. A 218-byte stub stages the LZSS-compressed segments into expansion bank 1,
then unpacks: low segment → `$7C20`, levels → DOS RAM page 0, high code → DOS RAM page 1 → bank 0.
The game runs with mapper `$37` = `$01` (DOS area = RAM page 0, expansion bank 0) and VZ300 mode (`$3A` = 1).
Interrupts are IM 2 with the original vector table. The handler waits for field sync to end because the VZ's
interrupt is level-triggered.

## Building

Requirements: `sjasmplus` and Python 3 with Pillow.
`./build.sh` regenerates `src/gen_data.asm`, `src/gen_data2.asm` from `art/vzart.py` (artwork), assembles `src/main.asm`
on top of `build/orig64k.bin` (the Spectrum memory image recovered from your tape), and packs `build/REPTON2.VZ`.

`tools/` also contains the test harnesses used during the conversion. `zxemu.c` is a 48K Spectrum emulator that
plays TZX pulse streams (used to load the Speedlock tape). `vzemu.c` emulates a VZ300 with the BennVenn banking, keyboard,
joysticks, field-sync interrupt and speaker, and can capture screens and audio. `viewcheck2.py` independently renders the map
to verify the ring buffer.

## Known differences from the Spectrum

* More of the level is visible horizontally (8 tiles instead of 6) and slightly less vertically (5¼ tiles instead of 6).
* Colours follow the VZ's 4-colour palette. Wall and earth colours change per level, but Repton's legs are always red
  (on the Spectrum they take the level colour).
* CAPS SHIFT combinations became CTRL combinations, and the control-selection option was dropped (all inputs are always on).
* Noise-based sound effects use a pseudo-random table instead of Spectrum ROM bytes, so they sound similar but not identical.
