; ---------------------------------------------------------------------------
;  One-bit sound for the VZ300 speaker (latch bits 0 and 5, toggled together)
;  Ports of the Spectrum routines with the same loop timings.
; ---------------------------------------------------------------------------

; ---- interrupt (IM2 vector FDFD -> DE06 -> here) ----
; counts frames; plays the rock "thud" like the original ISR; waits for FS to
; end so the level-triggered VZ interrupt fires once per frame.
vz_isr:
        push af
        push hl
        ld hl,(vz_frames)
        inc hl
        ld (vz_frames),hl
        ld a,(V_THUD)
        ld l,a
        ld a,(V_SOUND)
        and l
        call nz,vz_thud
.fs:    ld a,($6800)
        rla
        jr nc,.fs
        pop hl
        pop af
        ei
        reti

; rock landing click (DE31): 100 samples of noise
vz_thud:
        push bc
        ld hl,NOISE
        ld b,100
        ld a,(vz_latch)
        and $DE
        ld c,a
.l:     ld a,(hl)
        and SPK_MASK
        or c
        ld (LATCH),a
        inc hl
        djnz .l
        ld a,c
        ld (LATCH),a
        pop bc
        ret

; ---- general effect (replaces DC0C) ----
; A = "op" byte of the original self-modifying loop:
;   $41 B=254  $42 B=D  $43 B=E  $44 B=H  $46 B=noise  $00 B unchanged
; D = outer count, E = value for $43 (incremented each outer pass), H = inner count
vz_beep:
        push af
        ld a,(V_SOUND)
        or a
        jr nz,.on
        pop af
        ret
.on:    pop af
        di
        cp $46
        jp z,vb_noise
        cp $41
        jr nz,.n41
        ld a,$06                ; ld b,$FE
        ld (vz_beep.op),a
        ld a,$FE
        ld (vz_beep.op+1),a
        jr .go
.n41:   ld (vz_beep.op),a            ; ld b,d / ld b,e / ld b,h  (or nop)
        xor a
        ld (vz_beep.op+1),a          ; nop
.go:    ld a,(vz_latch)
        and $DE
        or 1
        ld (vb_base),a
.outer: push hl
        ld a,(vb_base)
.inner: ld c,$FE
        xor SPK_MASK
        ld (LATCH),a
.op:    nop
        nop
.dj:    djnz .dj
        dec h
        jr nz,.inner
        inc e
        pop hl
        dec d
        jr nz,.outer
vb_end: xor a
        ld (V_THUD),a
        ld a,(vz_latch)
        and $DE
        ld (LATCH),a
        ei
        ret
vb_base: db 0
; noise variant: B = NOISE[H] for each inner step
vb_noise:
        ld a,(vz_latch)
        and $DE
        or 1
        ld (vb_base),a
.outer: push hl
        ld a,(vb_base)
.inner: ld c,a
        push hl
        ld l,h
        ld h,NOISE/256
        ld b,(hl)
        pop hl
        ld a,c
        xor SPK_MASK
        ld (LATCH),a
.dj:    djnz .dj
        dec h
        jr nz,.inner
        inc e
        pop hl
        dec d
        jr nz,.outer
        jr vb_end

; ---- transporter effect (replaces F0E0): flashing colour set + rising tone ----
vz_transport:
        ld b,12
        xor a
        ld (V_THUD),a
.lp:    push bc
        ei
        halt
        ld a,(vz_latch)
        xor $10                 ; swap CSS colour set
        ld (vz_latch),a
        ld (LATCH),a
        ld a,(V_SOUND)
        or a
        jr z,.ns
        di
        ld a,b
        add a,a
        add a,a
        add a,a
        add a,a
        ld b,a
        ld c,b
        ld hl,$03E8
        ld d,SPK_MASK
        ld a,(vz_latch)
        and $DE
        or 1
.out:   ld (LATCH),a
.t1:    dec b
        jp nz,.t2
        ld b,c
        xor d
        jp .out
.t2:    dec l
        jp nz,.t1
        dec h
        jp nz,.t1
        ei
.ns:    pop bc
        djnz .lp
        ld a,(vz_latch)
        and $CE                 ; CSS back to 0, speaker idle
        ld (vz_latch),a
        ld (LATCH),a
        ret

; ---------------------------------------------------------------------------
;  Two-channel music player (port of F301; 96 T-states per sample as original)
;  Song pointers as the original: mus1/mus2 point at the byte BEFORE the next note.
;  Note bytes index the D264 period table (+12).  $40 = loop, $3F = end of song.
; ---------------------------------------------------------------------------
mus_ptr1:   dw 0
mus_loop1:  dw 0
mus_ptr2:   dw 0
mus_loop2:  dw 0
mus_end:    db 0

; HL = channel-1 data, DE = channel-2 data (first note at the address given)
mus_start:
        dec hl
        ld (mus_ptr1),hl
        inc hl
        ld (mus_loop1),hl
        dec de
        ld (mus_ptr2),de
        inc de
        ld (mus_loop2),de
        xor a
        ld (mus_end),a
        ret

; fetch next note of a channel: HL -> pointer variable (ptr, loop)
mus_fetch:
        ld e,(hl)
        inc hl
        ld d,(hl)
        inc de
.chk:   ld a,(de)
        cp $40
        jr z,.loop
        cp $3F
        jr z,.stop
        ld (hl),d
        dec hl
        ld (hl),e
        ret
.loop:  inc hl
        ld e,(hl)
        inc hl
        ld d,(hl)
        dec hl
        dec hl
        jr .chk
.stop:  ld a,1
        ld (mus_end),a
        ld a,$29                ; rest
        ret

; play one note (both channels).  Returns NZ if the song has ended.
mus_note:
        ld a,(mus_end)
        or a
        ret nz
        ld hl,mus_ptr1
        call mus_fetch
        ld (mn_1),a
        ld hl,mus_ptr2
        call mus_fetch
        ld (mn_2),a
        ld a,(mus_end)
        or a
        ret nz
        di
        ld a,(mn_1)
        call mus_period
        push hl
        ld a,(mn_2)
        call mus_period
        pop de
        ld a,(V_MUSIC)          ; music off: keep the timing, stay silent
        or a
        jp z,mus_rest
        ld a,h
        dec a
        jr nz,.tone
        ld a,d
        dec a
        jp z,mus_rest
.tone:  ld a,(vz_latch)
        and $DE
        or 1
        ld c,$EA
        ld b,0
        ex af,af'
        ld a,(vz_latch)
        and $DE
        or 1
        ld ixh,d
        ld d,SPK_MASK
.m336:  nop
.m338:  ex af,af'
        dec e
        ld (LATCH),a
        jr nz,.m351
        ld e,ixh
        xor d
        ex af,af'
        dec l
        jp nz,.m358
.m346:  ld (LATCH),a
        ld l,h
        xor d
        djnz .m336
        call mus_poll
        inc c
        jp nz,.m338
        jr mus_done
.m351:  jr z,.m351
        ex af,af'
        dec l
        jp z,.m346
.m358:  ld (LATCH),a
        nop
        nop
        djnz .m336
        call mus_poll
        inc c
        jp nz,.m338
mus_done:
        ld a,(vz_latch)
        and $DE
        ld (LATCH),a
        ei
        xor a
        ret
mus_rest:
        ld c,$15
        ld b,0
.r:     push hl
        ld hl,0
        sra (hl)
        sra (hl)
        sra (hl)
        nop
        pop hl
        djnz .r
        dec c
        jr nz,.r
        jr mus_done
; remember a SPACE press during music (checked once per 256 samples)
mus_poll:
        push af
        ld a,($68EF)
        bit 4,a
        jr nz,.n
        ld a,1
        ld (kb_sticky),a
.n:     pop af
        ret
kb_sticky: db 0
mus_period:                     ; A = note -> H = period, L = 1
        add a,$0C
        ld e,a
        ld d,0
        ld hl,$D264
        add hl,de
        ld h,(hl)
        ld l,1
        ret
mn_1:   db 0
mn_2:   db 0

; play a whole (non-looping) jingle: HL = ch1, DE = ch2. Abort early on key if B<>0
play_jingle:
        call mus_start
.n:     call mus_note
        jr z,.n
        ret
