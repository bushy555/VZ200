; ---------------------------------------------------------------------------
;  Presentation: title / credits / hi-score attract loop, status ("start")
;  screen, game over, hi-score name entry and completion screens.
;  All in VZ text + SG4 semigraphics mode (32x16 text, 64x32 8-colour blocks).
; ---------------------------------------------------------------------------

BLACK   EQU $80             ; SG4 cell with no pixels = black

; ---------------- text helpers ----------------
; B = row, C = col -> HL = VRAM address
tx_at:  push de
        ld l,b
        ld h,0
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        ld e,c
        ld d,VRAM/256
        add hl,de
        pop de
        ret

; print inline: call tx_inline / db row,col,"TEXT",0   (1=inverse on, 2=inverse off)
tx_inline:
        ex (sp),hl
        push bc
        push de
        ld b,(hl)
        inc hl
        ld c,(hl)
        inc hl
        ex de,hl
        call tx_at
        ex de,hl
        call tx_str
        pop de
        pop bc
        ex (sp),hl
        ret
; DE = screen, HL = string; returns HL past the terminator
tx_str: xor a
        ld (tx_inv),a
.c:     ld a,(hl)
        inc hl
        or a
        ret z
        cp 1
        jr nz,.n1
        ld a,$40
        ld (tx_inv),a
        jr .c
.n1:    cp 2
        jr nz,.n2
        xor a
        ld (tx_inv),a
        jr .c
.n2:    call tx_code
        ld (de),a
        inc de
        jr .c
tx_inv: db 0
; ASCII in A -> 6847 code (with current inverse flag)
tx_code:
        cp 'a'
        jr c,.u
        sub 32
.u:     and $3F
        push hl
        ld hl,tx_inv
        or (hl)
        pop hl
        ret

; fill the whole text screen with black SG4 cells
tx_cls: call vz_txtmode
        ld hl,VRAM
        ld de,VRAM+1
        ld bc,511
        ld (hl),BLACK
        ldir
        ret
; A = row -> fill with black
tx_clearrow:
        push bc
        push hl
        ld b,a
        ld c,0
        call tx_at
        ld b,32
.l:     ld (hl),BLACK
        inc hl
        djnz .l
        pop hl
        pop bc
        ret
; A = row -> fill with text spaces (dark green band)
tx_bandrow:
        push bc
        push hl
        ld b,a
        ld c,0
        call tx_at
        ld b,32
.l:     ld (hl),$20
        inc hl
        djnz .l
        pop hl
        pop bc
        ret

; print 6-digit number (word + units digit) right aligned, leading spaces.
; DE = screen address, HL -> number (word lo, word hi, digit)
tx_num6:
        push bc
        push hl
        ld c,(hl)
        inc hl
        ld b,(hl)
        inc hl
        ld a,(hl)
        ld (tn_last),a
        ld h,b
        ld l,c
        ld a,1
        ld (tn_lead),a
        ld bc,10000
        call tn_dig
        ld bc,1000
        call tn_dig
        ld bc,100
        call tn_dig
        ld bc,10
        call tn_dig
        ld bc,1
        call tn_dig
        ld a,(tn_last)
        add a,'0'
        and $3F
        ld (de),a
        inc de
        pop hl
        inc hl
        inc hl
        pop bc
        ret
tn_dig: ld a,'0'-1
.s:     inc a
        or a
        sbc hl,bc
        jr nc,.s
        add hl,bc
        cp '0'
        jr nz,.nz
        push af
        ld a,(tn_lead)
        or a
        jr z,.z0
        pop af
        ld a,' '
        jr .out
.z0:    pop af
        jr .out
.nz:    push af
        xor a
        ld (tn_lead),a
        pop af
.out:   and $3F
        ld (de),a
        inc de
        ret
tn_last: db 0
tn_lead: db 0

; ---------------- SG4 helpers ----------------
; plot pixel D=x (0..63) E=y (0..31) colour C (0..7)
sg_plot:
        push hl
        push de
        ld a,e
        srl a
        ld l,a
        ld h,0
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        ld a,d
        srl a
        add a,l
        ld l,a
        ld a,h
        adc a,VRAM/256
        ld h,a
        ; quadrant: even y -> 8/4, odd y -> 2/1 ; even x -> left
        ld a,8
        bit 0,e
        jr z,.ty
        ld a,2
.ty:    bit 0,d
        jr z,.tx
        srl a
.tx:    ld e,a
        ld a,(hl)
        bit 7,a
        jr nz,.sg
        xor a
.sg:    and $0F
        or e
        ld e,a
        ld a,c
        rlca
        rlca
        rlca
        rlca
        or $80
        or e
        ld (hl),a
        pop de
        pop hl
        ret
; draw 5x7 glyph: A = ASCII, D = x, E = y, C = colour
sg_char:
        push bc
        push de
        push hl
        sub 32
        ld l,a
        ld h,0
        ld b,h
        ld c,l
        add hl,hl
        add hl,hl
        add hl,hl
        or a
        sbc hl,bc               ; *7
        ld bc,FONT57
        add hl,bc
        pop bc                  ; (old HL) discard later
        push bc
        ld b,7
        ld a,(sgc_col)
        ld c,a
.r:     ld a,(hl)
        push de
        push bc
        ld b,5
.p:     bit 4,a
        jr z,.n
        push af
        call sg_plot
        pop af
.n:     add a,a
        inc d
        djnz .p
        pop bc
        pop de
        inc e
        inc hl
        djnz .r
        pop hl
        pop de
        pop bc
        ret
sgc_col: db 0
; draw inline string in 5x7: call sg_inline / db x,y,colour,"TEXT",0  (6 px per char)
sg_inline:
        ex (sp),hl
        push bc
        push de
        ld d,(hl)
        inc hl
        ld e,(hl)
        inc hl
        ld a,(hl)
        inc hl
        ld (sgc_col),a
.c:     ld a,(hl)
        inc hl
        or a
        jr z,.e
        call sg_char
        ld a,d
        add a,6
        ld d,a
        jr .c
.e:     pop de
        pop bc
        ex (sp),hl
        ret

; copy SG4 cell pattern: HL = pattern (quad nibbles), DE = screen, B = count, C = colour
sg_pattern:
        ld a,c
        rlca
        rlca
        rlca
        rlca
        or $80
        ld c,a
.l:     ld a,(hl)
        or a
        jr z,.z
        or c
        ld (de),a
.z:     inc hl
        inc de
        djnz .l
        ret

; recolour all non-empty SG4 cells in rows [B .. B+C-1] with colour bands
; phase in A ; band colour = RAINBOW[(row + phase) & 7]
sg_rainbow:
        ld (sr_phase),a
.row:   push bc
        ld a,b
        ld hl,sr_phase
        add a,(hl)
        and 7
        ld e,a
        ld d,0
        ld hl,RAINBOW
        add hl,de
        ld a,(hl)
        rlca
        rlca
        rlca
        rlca
        or $80
        ld e,a                  ; colour bits
        ld c,0
        call tx_at
        ld b,32
.c:     ld a,(hl)
        bit 7,a
        jr z,.n
        and $0F
        jr z,.n
        or e
        ld (hl),a
.n:     inc hl
        djnz .c
        pop bc
        inc b
        dec c
        jr nz,.row
        ret
sr_phase: db 0
RAINBOW: db 3,7,1,0,5,2,6,4         ; red orange yellow green cyan blue magenta buff

; rainbow divider: row A, top-half SG4 cells in moving colours (phase = pl_tick)
divider:
        ld b,a
        ld c,0
        call tx_at
        ld a,(pl_tick)
        ld c,a
        ld b,32
.d:     ld a,c
        srl a
        and 7
        push hl
        ld e,a
        ld d,0
        ld hl,RAINBOW
        add hl,de
        ld a,(hl)
        pop hl
        rlca
        rlca
        rlca
        rlca
        or $8C
        ld (hl),a
        inc hl
        inc c
        djnz .d
        ret

; wait ~one note length when music is off (7 frames)
note_or_wait:
        ld a,(V_MUSIC)
        or a
        jr z,.w
        call mus_note
        ret z
        ; song ended -> restart the title tune
        call start_tune
        ret
.w:     ld b,7
.h:     ei
        halt
        djnz .h
        ret
start_tune:
        ld hl,$8C9C
        ld de,$8D1D
        jp mus_start

; =====================================================================
;  ATTRACT LOOP: title -> credits -> hi-scores -> ...
; =====================================================================
title_attract:
        di
        ld sp,$FDE7
        ld hl,$DE06
        ld ($FDFE),hl
        xor a
        ld (V_THUD),a
        ei
        call start_tune
        call wait_release
.cycle: call title_page
        jr z,.go
        call credits_page
        jr z,.go
        call hiscore_page
        jr z,.go
        jp demo_start
.go:    call wait_release
        ld hl,J_START1
        ld de,J_START2
        call play_jingle
        jp O_NEWGAME

; common page loop: B = number of notes, IX = per-note animation routine
; returns Z if start pressed
page_loop:
        ld (pl_count),a
.n:     call note_or_wait
        call any_start
        ret z
        call pl_toggles
        ld hl,pl_tick
        inc (hl)
        call pl_anim
        ld hl,pl_count
        dec (hl)
        jr nz,.n
        or 1
        ret
pl_anim: ld hl,(pl_animptr)
        jp (hl)
pl_animptr: dw 0
pl_count: db 0
pl_tick:  db 0
; D / E toggle sound / music anywhere in the attract loop
pl_toggles:
        ld a,($68FD)            ; D
        bit 3,a
        jr nz,.e
        ld a,(V_SOUND)
        xor 1
        ld (V_SOUND),a
        call wait_nokey
.e:     ld a,($68FE)            ; E
        bit 3,a
        ret nz
        ld a,(V_MUSIC)
        xor 1
        ld (V_MUSIC),a
        call wait_nokey
        ret
wait_nokey:
        ld b,25
.w:     ei
        halt
        djnz .w
        ret

; ---------------- title page ----------------
title_page:
        call tx_cls
        ld hl,MAP_TITLE
        ld de,BAND_WARM
        ld bc,BAND_COOL
        ld a,12
        call fx_setup
        ld a,1
        ld (fx_dx),a
        ld (fx_dy),a
        call fg_bigstr
        db 2,2,$40,"REPTON",0
        call fg_bigstr
        db 13,14,$20,"*",0
        call fg_bigstr
        db 27,13,$40,"2",0
        call fg_bigstr
        db 41,14,$20,"*",0
        call fg_halo
        call fx_draw
        ld a,12
        call divider
        ld a,13
        call tx_band_from
        call tx_inline
        db 13,2,"(C) 1985 SUPERIOR SOFTWARE",0
        call tx_inline
        db 14,7,"PRESS FIRE TO PLAY",0
        call tx_inline
        db 15,7,"HIGH SCORE",0
        ld de,VRAM+15*32+18
        ld hl,V_HISCORE
        call tx_num6
        ld hl,title_anim
        ld (pl_animptr),hl
        ld a,90
        jp page_loop
title_anim:
        call fx_step
        ld a,12
        call divider
        ld b,14
        ld c,7
        ld e,18
        jp flash_row

; header style used by status / credits / hi-scores / completion:
; HL = map, then inline 5x7 text follows the call:  db x,"TEXT",0
fx_header:
        ld de,BAND_RAIN
        ld bc,BAND_WARM
        ld a,5
        call fx_setup
        ld a,1
        ld (fx_dx),a
        xor a
        ld (fx_dy),a
        ld a,$40
        ld (fb_flag),a
        pop hl                  ; inline args
        ld d,(hl)
        inc hl
        ld e,2
.c:     ld a,(hl)
        inc hl
        or a
        jr z,.e
        call fg_c57
        ld a,d
        add a,6
        ld d,a
        jr .c
.e:     push hl
        call fg_halo
        call fx_draw
        ld a,5
        call divider
        ld a,6
        jp tx_band_from
hdr_anim:
        call fx_step
        ld a,5
        jp divider

; ---------------- credits page ----------------
credits_page:
        call tx_cls
        ld hl,MAP_TITLE
        call fx_header
        db 8,"REPTON 2",0
        call tx_inline
        db 6,4,1," ORIGINAL BBC MICRO GAME ",2,0
        call tx_inline
        db 7,4,"TIM TYLER 1985",0
        call tx_inline
        db 8,4,"(C) SUPERIOR SOFTWARE",0
        call tx_inline
        db 9,4,1," ZX SPECTRUM VERSION ",2,0
        call tx_inline
        db 10,4,"GJS 1988",0
        call tx_inline
        db 11,4,1," VZ CONVERSION ",2,0
        call tx_inline
        db 12,4,"VIBED BY BPM 2026",0
        call tx_inline
        db 13,2,"Q A O P OR JOYSTICK TO MOVE",0
        call tx_inline
        db 14,2,"FIRE IN GAME SHOWS STATUS",0
        call tx_inline
        db 15,2,"D SOUND  E MUSIC  CTRL+R QUIT",0
        ld hl,hdr_anim
        ld (pl_animptr),hl
        ld a,45
        jp page_loop

; ---------------- hi-score table ----------------
hiscore_page:
        call hiscore_draw
        ld hl,hdr_anim
        ld (pl_animptr),hl
        ld a,45
        jp page_loop
hiscore_draw:
        call tx_cls
        ld hl,MAP_HISC
        call fx_header
        db 5,"HI-SCORES",0
        ld b,0                  ; entry
.e:     push bc
        ld a,b
        add a,6
        ld b,a
        ld c,2
        call tx_at
        ex de,hl
        pop bc
        push bc
        ld a,b
        add a,'1'
        and $3F
        ld (de),a
        inc de
        ld a,'.'
        ld (de),a
        inc de
        inc de
        ; name: D8A3 + 26*entry, 20 chars
        ld a,b
        ld l,a
        ld h,0
        add hl,hl               ; *2
        ld c,l
        ld b,h
        add hl,hl
        add hl,hl               ; *8
        push hl
        add hl,hl               ; *16
        pop bc
        add hl,bc               ; *24
        pop bc
        push bc
        ld a,b
        add a,a
        add a,l
        ld l,a
        jr nc,$+3
        inc h                   ; *26
        ld bc,$D8A3
        add hl,bc
        xor a
        ld (tx_inv),a
        ld b,20
.n:     ld a,(hl)
        call tx_code
        ld (de),a
        inc hl
        inc de
        djnz .n
        inc de
        ; score
        pop bc
        push bc
        ld a,b
        ld l,a
        add a,a
        add a,l
        ld l,a
        ld h,0
        ld bc,V_HISCORE
        add hl,bc
        call tx_num6
        pop bc
        inc b
        ld a,b
        cp 8
        jr c,.e
        call tx_inline
        db 15,7,"LAST SCORE",0
        ld de,VRAM+15*32+18
        ld hl,V_SCORE
        call tx_num6
        ret

; =====================================================================
;  STATUS / START SCREEN  (replaces F5CD .. F6DF)
; =====================================================================
vz_status:
        di
        ld sp,$FDE7
        ld hl,$DE06
        ld ($FDFE),hl
        xor a
        ld (V_THUD),a
        ei
        ld a,(vz_demo)
        or a
        jp nz,demo_status
        call status_screen
        ld hl,J_START1
        ld de,J_START2
        call play_jingle
        jp O_PLAY

; status screen loop; returns when SPACE / fire is pressed (and released)
status_screen:
        call status_draw
        call start_tune
        call wait_release
.loop:  call note_or_wait
        ld hl,pl_tick
        inc (hl)
        call hdr_anim
        call st_flash
        call vz_keys
        ld a,(V_KSUICIDE)
        or a
        jp z,st_suicide
        ld a,(V_KQUIT)
        or a
        jp z,vz_gameover
        ld a,(V_KSOUND)
        or a
        jr nz,.ns
        ld a,(V_SOUND)
        xor 1
        ld (V_SOUND),a
        call st_toggles
        call wait_nokey
.ns:    ld a,(V_KMUSIC)
        or a
        jr nz,.nm
        ld a,(V_MUSIC)
        xor 1
        ld (V_MUSIC),a
        call st_toggles
        call wait_nokey
.nm:    call any_start
        jr nz,.loop
        jp wait_release

; in-game: SPACE or fire shows the status screen; again returns to play
vz_keys_game:
        ld a,(vz_demo)
        or a
        jp nz,demo_keys
        call vz_keys
        call any_start
        ret nz
        call wait_release
        call status_screen
        call vz_gfxmode
        call vz_blit
        ld hl,(vz_frames)
        ld (vz_last),hl
        ld a,$0F
        ld (V_KDIR),a
        ret

st_flash:
        ld b,13
        ld c,7
        ld e,18
; invert/restore E text cells at (B,C) depending on pl_tick bit 1
flash_row:
        call tx_at
        ld a,(pl_tick)
        and 2
        ld d,a
.f:     ld a,(hl)
        and $3F
        bit 1,d
        jr nz,.st
        or $40
.st:    ld (hl),a
        inc hl
        dec e
        jr nz,.f
        ret
; CTRL+1 on the status screen: restart at the last restart point, losing a life
st_suicide:
        ld bc,(V_RESTART)
        ld (V_POSY),bc
        call O_DAE2
        ld a,(hl)
        cp $0F
        jr nz,.n
        ld de,-38
        add hl,de
        ld a,(V_POSY)
        sub 4
        ld (V_POSY),a
.n:     ld (V_MAPCUR),hl
        ld (V_MAPNXT),hl
        jp O_DEATH

status_draw:
        call tx_cls
        ld hl,MAP_STATUS
        call fx_header
        db 8,"REPTON 2",0
        call tx_inline
        db 6,1,"SCORE",0
        ld de,VRAM+6*32+8
        ld hl,V_SCORE
        call tx_num6
        call tx_inline
        db 6,19,"LIVES",0
        ld a,(V_LIVES)
        add a,'0'
        and $3F
        ld (VRAM+6*32+26),a
        call tx_inline
        db 7,2,"EARTH ..............",0
        call tx_inline
        db 8,2,"DIAMONDS ...........",0
        call tx_inline
        db 9,2,"TRANSPORTERS .......",0
        call tx_inline
        db 10,2,"PUZZLE PIECES ......",0
        call tx_inline
        db 11,2,"MONSTERS ...........",0
        ld b,5
        ld hl,V_COUNT
        ld de,VRAM+7*32+23
.c:     push bc
        push de
        call tx_num6
        inc hl
        pop de
        ex de,hl
        ld bc,32
        add hl,bc
        ex de,hl
        pop bc
        djnz .c
        call st_toggles
        call tx_inline
        db 13,7,"PRESS FIRE TO PLAY",0
        call tx_inline
        db 14,2,"CTRL+1 KILL YOURSELF",0
        call tx_inline
        db 15,2,"CTRL+R QUIT",0
        ret
st_toggles:
        call tx_inline
        db 12,2,"SOUND     (D)   MUSIC     (E)",0
        ld hl,ST_ON
        ld a,(V_SOUND)
        or a
        jr nz,.s
        ld hl,ST_OFF
.s:     ld de,VRAM+12*32+8
        call tx_str
        ld hl,ST_ON
        ld a,(V_MUSIC)
        or a
        jr nz,.m
        ld hl,ST_OFF
.m:     ld de,VRAM+12*32+24
        jp tx_str
ST_ON:  db "ON ",0
ST_OFF: db "OFF",0

; =====================================================================
;  GAME OVER + HI-SCORE ENTRY (replaces F4AD .. F5B7)
; =====================================================================
vz_gameover:
        di
        ld sp,$FDE7
        ld hl,$DE06
        ld ($FDFE),hl
        xor a
        ld (V_THUD),a
        ei
        call tx_cls
        ld hl,MAP_OVER
        ld de,BAND_HOT
        ld bc,BAND_WARM
        ld a,12
        call fx_setup
        xor a
        ld (fx_dx),a
        dec a
        ld (fx_dy),a            ; rocks and skulls rain down
        call fg_bigstr
        db 12,1,$40,"GAME",0
        call fg_bigstr
        db 12,13,$40,"OVER",0
        call fg_halo
        call fx_draw
        ld a,12
        call divider
        ld a,13
        call tx_band_from
        call tx_inline
        db 13,6,"FINAL SCORE",0
        ld de,VRAM+13*32+18
        ld hl,V_SCORE
        call tx_num6
        call tx_inline
        db 15,5,"BETTER LUCK NEXT TIME",0
        ld hl,go_anim
        ld (pl_animptr),hl
        ld hl,J_OVER1
        ld de,J_OVER2
        call go_jingle_anim
        ld a,60
        call anim_wait
vz_after_game:
        call hs_check
        jr c,.nohi
        call hs_enter
.nohi:  call hiscore_draw
        call wait_release
        ld hl,hdr_anim
        ld (pl_animptr),hl
        ld a,255
        call anim_wait
        call wait_release
        jp title_attract
go_anim:
        call fx_step
        ld a,12
        jp divider

; play a jingle, animating the current screen once per note
go_jingle_anim:
        call mus_start
.n:     call mus_note
        ret nz
        ld hl,pl_tick
        inc (hl)
        call pl_anim
        jr .n

; wait A frames (or until SPACE/fire), animating every 3rd frame. Z if a key ended it
anim_wait:
        ld (aw_n),a
.f:     ei
        halt
        call any_start
        ret z
        ld hl,aw_t
        inc (hl)
        ld a,(hl)
        cp 3
        jr c,.nx
        ld (hl),0
        ld hl,pl_tick
        inc (hl)
        call pl_anim
.nx:    ld hl,aw_n
        dec (hl)
        jr nz,.f
        or 1
        ret
aw_n:   db 0
aw_t:   db 0

; compare score with hi-score table. Returns NC and A = slot (0..7) if it qualifies
hs_check:
        ld b,0
        ld hl,V_HISCORE
.e:     push hl
        push bc
        ; compare score (word, digit) with entry at HL
        ld e,(hl)
        inc hl
        ld d,(hl)
        inc hl
        ld c,(hl)               ; entry digit
        ld hl,(V_SCORE)
        or a
        sbc hl,de
        jr c,.less
        jr nz,.ge
        ld a,(V_SCORE+2)
        cp c
        jr c,.less
.ge:    pop bc
        pop hl
        ld a,b
        or a                    ; NC
        ret
.less:  pop bc
        pop hl
        inc hl
        inc hl
        inc hl
        inc b
        ld a,b
        cp 8
        jr c,.e
        scf
        ret

; insert the score at slot A and let the player type a name
hs_enter:
        ld (hs_slot),a
        ; shift scores and names below the slot down by one
        ld b,a
        ld a,7
        sub b
        jr z,.noshift
        ld b,a                  ; entries to move
.mv:    push bc
        ; entry index k = slot + b - 1 -> k+1
        ld a,(hs_slot)
        add a,b
        dec a
        push af
        call hs_scoreptr        ; HL = score k
        ld d,h
        ld e,l
        inc de
        inc de
        inc de
        ld bc,3
        ldir
        pop af
        call hs_nameptr
        ld de,26
        ex de,hl
        add hl,de
        ex de,hl                ; DE = name k+1
        ld bc,20
        ldir
        pop bc
        djnz .mv
.noshift:
        ld a,(hs_slot)
        call hs_scoreptr
        ex de,hl
        ld hl,V_SCORE
        ld bc,3
        ldir
        ; name entry screen
        call tx_cls
        ld hl,MAP_TITLE
        call fx_header
        db 5,"WELL DONE",0
        call tx_inline
        db 7,2,"YOU'VE ACHIEVED A NEW HIGH",0
        call tx_inline
        db 8,2,"SCORE! ENTER YOUR NAME:",0
        call tx_inline
        db 13,2,"RETURN = END   CTRL = DELETE",0
        ld hl,J_HI1
        ld de,J_HI2
        call play_jingle
        call wait_release
        ; clear name buffer
        ld hl,hs_name
        ld b,20
.cl:    ld (hl),' '
        inc hl
        djnz .cl
        xor a
        ld (hs_len),a
.ed:    call hs_showname
        call key_ascii_wait
        cp 13
        jr z,.done
        cp 8
        jr nz,.add
        ld a,(hs_len)
        or a
        jr z,.ed
        dec a
        ld (hs_len),a
        ld e,a
        ld d,0
        ld hl,hs_name
        add hl,de
        ld (hl),' '
        jr .ed
.add:   ld c,a
        ld a,(hs_len)
        cp 20
        jr nc,.ed
        ld e,a
        ld d,0
        ld hl,hs_name
        add hl,de
        ld (hl),c
        inc a
        ld (hs_len),a
        call hs_click
        jr .ed
.done:  ld a,(hs_slot)
        call hs_nameptr
        ex de,hl
        ld hl,hs_name
        ld bc,20
        ldir
        ret
hs_showname:
        ld de,VRAM+10*32+5
        ld hl,hs_name
        xor a
        ld (tx_inv),a
        ld b,20
.l:     ld a,(hl)
        call tx_code
        or $40                  ; inverse field
        ld (de),a
        inc hl
        inc de
        djnz .l
        ; cursor
        ld a,(hs_len)
        cp 20
        ret nc
        ld e,a
        ld d,0
        ld hl,VRAM+10*32+5
        add hl,de
        ld (hl),$1F             ; arrow glyph as cursor
        ret
hs_click:
        ld a,$43
        ld de,$0101
        ld h,8
        jp vz_beep
hs_scoreptr:            ; A = slot -> HL
        ld l,a
        add a,a
        add a,l
        ld l,a
        ld h,0
        ld de,V_HISCORE
        add hl,de
        ret
hs_nameptr:             ; A = slot -> HL = D8A3 + 26*A
        ld l,a
        ld h,0
        ld e,l
        ld d,h
        add hl,hl
        add hl,de               ; 3
        add hl,hl
        add hl,hl               ; 12
        add hl,de               ; 13
        add hl,hl               ; 26
        ld de,$D8A3
        add hl,de
        ret
hs_slot: db 0
hs_len:  db 0
hs_name: ds 20

; wait for a key press, return ASCII in A (13 = RETURN, 8 = CTRL/delete), with debounce
key_ascii_wait:
.rel:   ei
        halt
        call key_scan
        or a
        jr nz,.rel
.prs:   ei
        halt
        call key_scan
        or a
        jr z,.prs
        ret
; scan keyboard -> ASCII of the first key found, 0 if none
key_scan:
        push bc
        push de
        push hl
        ld hl,KEYMAP
        ld c,$FE
.row:   ld a,c
        ld (.rd+1),a
.rd:    ld a,($68FE)
        ld b,6
        ld e,$20
.bit:   push af
        and e
        jr nz,.no
        ld a,(hl)
        or a
        jr z,.no
        pop de
        jr .out
.no:    pop af
        inc hl
        srl e
        djnz .bit
        rlc c
        jr c,.row
        xor a
.out:   pop hl
        pop de
        pop bc
        ret
; rows 0..7, bits 5..0
KEYMAP: db "RQE",0,"WT"
        db "FAD",8,"SG"
        db "VZC",0,"XB"
        db "413",0,"25"
        db "M ,",0,".N"
        db "708-96"
        db "UPI",13,"OY"
        db "J;K:LH"

; =====================================================================
;  COMPLETION (after the original fireworks; replaces FB71..)
; =====================================================================
vz_complete:
        di
        ld sp,$FDE7
        ld hl,$DE06
        ld ($FDFE),hl
        ei
        call tx_cls
        ld hl,MAP_STATUS
        call fx_header
        db 8,"AMAZING!",0
        call tx_inline
        db 7,4,1," REPTON TWO COMPLETED! ",2,0
        call tx_inline
        db 9,6,"YOUR SCORE",0
        ld de,VRAM+9*32+18
        ld hl,V_SCORE
        call tx_num6
        call tx_inline
        db 13,7,"PRESS FIRE TO GO ON",0
        ld hl,hdr_anim
        ld (pl_animptr),hl
        ld hl,J_DONE1
        ld de,J_DONE2
        call go_jingle_anim
.w:     ld a,255
        call anim_wait
        jr nz,.w
        call wait_release
        jp vz_after_game
