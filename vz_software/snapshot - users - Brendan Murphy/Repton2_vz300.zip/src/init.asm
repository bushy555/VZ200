; ---------------------------------------------------------------------------
;  Cold start (replaces F6F6..F7CB) and small glue routines
; ---------------------------------------------------------------------------
vz_init:
        di
        ld sp,$FDE7
        ld a,BV_RUN
        out (BV_MAPPER),a
        ; clear game work RAM and the ring buffer ($B01E..$CA7F)
        ld hl,$B01E
        ld de,$B01F
        ld bc,$CA7F-$B01E
        ld (hl),0
        ldir
        ; IM2 vector table exactly as the original
        ld a,$C3
        ld ($FDFD),a
        ld hl,$DE06
        ld ($FDFE),hl
        ld hl,$FE00
        ld de,$FE01
        ld bc,256
        ld (hl),$FD
        ldir
        ld a,$FE
        ld i,a
        im 2
        ld (V_PUZCACHE),a
        xor a
        ld (V_THUD),a
        ld (V_ISRSTATE),a
        ld (V_CONTROL),a
        inc a
        ld (V_SOUND),a
        ld (V_MUSIC),a
        ; fixed colour slots FF40..FF45 (as F77A..F794)
        ld ix,V_PAL
        ld (ix+5),$31
        ld (ix+6),$04
        ld (ix+7),$06
        ld (ix+8),$07
        ld (ix+9),$46
        ld (ix+10),$47
        ; default hi-scores 20000 .. 2500  (stored /10)
        ld ix,V_HISCORE
        ld hl,2000
        ld de,-250
        ld b,8
.hs:    ld (ix+0),l
        ld (ix+1),h
        ld (ix+2),0
        inc ix
        inc ix
        inc ix
        add hl,de
        djnz .hs
        ; engine vectors
        ld hl,O_DEATH
        ld (V_DEATHVEC),hl
        ld hl,$F8A5
        ld (V_STATVEC),hl
        ld hl,$FAEE
        ld (V_DONEVEC),hl
        xor a
        ld (V_SCORE),a
        ld (V_SCORE+1),a
        ld (V_SCORE+2),a
        call vz_cls
        ei
        jp title_attract

; DC30 replacement: reset the view at the restart point and draw it
vz_newscreen:
        xor a
        ld (V_DIR),a
        ld (V_STEP),a
        ld ($FF2D),a
        ld ($FF2E),a
        call vz_copymode
        ld hl,(V_RESTART)
        ld (V_POSY),hl
        ld (V_OLDPOS),hl
        call vz_fullview
        jp $DCAA

; E300 hook: recolour level-variant tiles, then continue the original code
vz_lc_hook:
        call vz_levelcolours
        ld hl,$B01E
        jp $E303
