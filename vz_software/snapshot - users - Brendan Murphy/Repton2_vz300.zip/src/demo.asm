; ---------------------------------------------------------------------------
;  Attract-mode demonstration: the real engine plays level 1 from a recorded
;  input sequence (DEMO: pairs of FF74 key bits, step count; count 0 = end).
;  Any key or fire returns to the title; so does losing a life.
; ---------------------------------------------------------------------------
vz_demo:  db 0
demo_go:  db 0
demo_ptr: dw 0
demo_cnt: db 0
demo_key: db $0F
demo_ss:  ds 3

demo_start:
        ld hl,(V_SCORE)
        ld (demo_ss),hl
        ld a,(V_SCORE+2)
        ld (demo_ss+2),a
        ld hl,DEMO
        ld (demo_ptr),hl
        xor a
        ld (demo_cnt),a
        ld (demo_go),a
        inc a
        ld (vz_demo),a
        jp O_NEWGAME

; vz_status while in demo mode: first visit starts play, any later visit ends the demo
demo_status:
        ld a,(demo_go)
        or a
        jr nz,demo_end
        inc a
        ld (demo_go),a
        jp O_PLAY

; replaces the keyboard read during the demo
demo_keys:
        call any_start
        jr z,demo_end
        call any_key
        jr nz,demo_end
        ld a,(demo_cnt)
        or a
        jr nz,.have
        ld hl,(demo_ptr)
        ld a,(hl)
        ld (demo_key),a
        inc hl
        ld a,(hl)
        inc hl
        ld (demo_ptr),hl
        or a
        jr z,demo_end
.have:  dec a
        ld (demo_cnt),a
        ld a,(demo_key)
        ld (V_KDIR),a
        ld a,$10
        ld (V_KSUICIDE),a
        ld (V_KQUIT),a
        ld (V_KCTRL),a
        ld (V_KSOUND),a
        ld (V_KMUSIC),a
        ret

demo_end:
        di
        ld sp,$FDE7
        xor a
        ld (vz_demo),a
        ld hl,(demo_ss)
        ld (V_SCORE),hl
        ld a,(demo_ss+2)
        ld (V_SCORE+2),a
        ei
        call vz_fade
        call wait_release
        jp title_attract

        INCLUDE "../build/demo_data.asm"
