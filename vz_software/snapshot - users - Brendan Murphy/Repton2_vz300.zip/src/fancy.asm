; ---------------------------------------------------------------------------
;  Menu-screen graphics engine (SG4 semigraphics, 64x32 blocks, 8 colours)
;  Big lettering is drawn into a foreground buffer (FGBUF, one byte per cell:
;  0 = transparent, $80 = black halo, $40|quad = main letters, $20|quad =
;  accent letters).  fx_draw composites it over a scrolling background built
;  from 8x8-pixel map tiles reminiscent of the Repton levels.
; ---------------------------------------------------------------------------
FGBUF   EQU $F230               ; 12 rows x 32 cells (old Spectrum name-entry/music code)

fx_rows:  db 11
fx_ox:    db 0
fx_oy:    db 0
fx_dx:    db 1
fx_dy:    db 1
fx_map:   dw MAP_TITLE
fx_band:  dw BAND_WARM
fx_acc:   dw BAND_COOL
fx_phase: db 0
fx_bc:    db 0
fx_ac:    db 0
fx_ro:    db 0
fx_mr:    dw 0
fb_xy:    dw 0

; HL = map, DE = main band, BC = accent band, A = rows ; then clear FG
fx_setup:
        ld (fx_map),hl
        ld (fx_band),de
        ld (fx_acc),bc
        ld (fx_rows),a
fg_clear:
        ld hl,FGBUF
        ld de,FGBUF+1
        ld bc,383
        ld (hl),0
        ldir
        ret

; plot D=x (0..63) E=y (0..21) into FG with flag C ($40 / $20)
fg_plot:
        push bc
        push de
        push hl
        ld a,e
        cp 24
        jr nc,.out
        ld a,d
        cp 64
        jr nc,.out
        ld b,8
        bit 0,e
        jr z,.ty
        ld b,2
.ty:    bit 0,d
        jr z,.tx
        srl b
.tx:    ld a,e
        srl a
        ld l,a
        ld h,0
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        ld a,d
        srl a
        ld e,a
        ld d,0
        add hl,de
        ld de,FGBUF
        add hl,de
        ld a,(hl)
        bit 7,a
        jr z,.k
        xor a
.k:     or b
        or c
        ld (hl),a
.out:   pop hl
        pop de
        pop bc
        ret

; big 9x11 glyph: A = glyph index, D = x, E = y, C = flag
fg_big: push bc
        push de
        push hl
        ld b,a
        add a,a
        ld l,a                  ; 2i
        add a,a
        ld h,a                  ; 4i
        add a,a
        add a,a                 ; 16i
        add a,l
        add a,h                 ; 22i
        ld l,a
        ld h,0
        push de
        ld de,BIGFONT
        add hl,de
        pop de
        ld b,11
.r:     push bc
        push de
        ld a,(hl)
        inc hl
        ld b,8
.p:     add a,a
        push af
        call c,fg_plot
        pop af
        inc d
        djnz .p
        ld a,(hl)
        inc hl
        add a,a
        call c,fg_plot
        pop de
        inc e
        pop bc
        djnz .r
        pop hl
        pop de
        pop bc
        ret

; 5x7 glyph from FONT57: A = ASCII, D = x, E = y, C = flag
fg_c57: push bc
        push de
        push hl
        sub 32
        ld l,a
        ld h,0
        ld b,h
        ld c,l
        add hl,hl
        add hl,hl
        add hl,hl
        or a
        sbc hl,bc               ; *7
        ld bc,FONT57
        add hl,bc
        ld a,(fb_flag)
        ld c,a
        ld b,7
.r:     ld a,(hl)
        push de
        push bc
        ld b,5
.p:     bit 4,a
        jr z,.n
        push af
        call fg_plot
        pop af
.n:     add a,a
        inc d
        djnz .p
        pop bc
        pop de
        inc e
        inc hl
        djnz .r
        pop hl
        pop de
        pop bc
        ret
fb_flag: db 0

; inline big text:  call fg_bigstr / db x,y,flag,"TEXT",0   (pitch 10)
fg_bigstr:
        ex (sp),hl
        push bc
        push de
        ld d,(hl)
        inc hl
        ld e,(hl)
        inc hl
        ld c,(hl)
        inc hl
.c:     ld a,(hl)
        inc hl
        or a
        jr z,.e
        push hl
        sub 32
        ld l,a
        ld h,0
        push de
        ld de,BIGMAP
        add hl,de
        pop de
        ld a,(hl)
        pop hl
        cp $FF
        call nz,fg_big
        ld a,d
        add a,10
        ld d,a
        jr .c
.e:     pop de
        pop bc
        ex (sp),hl
        ret

; inline 5x7 text:  call fg_str57 / db x,y,flag,"TEXT",0   (pitch 6)
fg_str57:
        ex (sp),hl
        push bc
        push de
        ld d,(hl)
        inc hl
        ld e,(hl)
        inc hl
        ld a,(hl)
        ld (fb_flag),a
        inc hl
.c:     ld a,(hl)
        inc hl
        or a
        jr z,.e
        call fg_c57
        ld a,d
        add a,6
        ld d,a
        jr .c
.e:     pop de
        pop bc
        ex (sp),hl
        ret

; black halo around every letter cell
fg_halo:
        ld hl,FGBUF
        ld b,0
.y:     ld c,0
.x:     ld a,(hl)
        and $60
        call nz,.nb
        inc hl
        inc c
        ld a,c
        cp 32
        jr c,.x
        inc b
        ld a,(fx_rows)
        cp b
        jr nz,.y
        ret
.nb:    push hl
        ld de,-33
        add hl,de               ; (-1,-1)
        ld a,b
        or a
        jr z,.noup
        ld a,c
        or a
        call nz,.m
        inc hl
        call .m
        inc hl
        ld a,c
        cp 31
        call nz,.m
        jr .mid
.noup:  inc hl
        inc hl
.mid:   ld de,30
        add hl,de               ; (-1,0)
        ld a,c
        or a
        call nz,.m
        inc hl
        inc hl                  ; (+1,0)
        ld a,c
        cp 31
        call nz,.m
        ld de,30
        add hl,de               ; (-1,+1)
        ld a,(fx_rows)
        dec a
        cp b
        jr z,.done
        ld a,c
        or a
        call nz,.m
        inc hl
        call .m
        inc hl
        ld a,c
        cp 31
        call nz,.m
.done:  pop hl
        ret
.m:     ld a,(hl)
        or a
        ret nz
        ld (hl),$80
        ret

; composite FG over the scrolling background into VRAM rows 0..fx_rows-1
fx_draw:
        ld hl,FGBUF
        ld de,VRAM
        ld b,0
.row:   push bc
        push hl
        ld a,(fx_phase)
        add a,b
        and 15
        ld c,a
        ld hl,(fx_band)
        call .col16
        ld (fx_bc),a
        ld hl,(fx_acc)
        call .col16
        ld (fx_ac),a
        ld a,(fx_oy)
        add a,b
        ld c,a
        and 3
        add a,a
        add a,a
        ld (fx_ro),a
        ld a,c
        rrca
        rrca
        and 3
        add a,a
        add a,a
        add a,a
        ld hl,(fx_map)
        add a,l
        ld l,a
        jr nc,$+3
        inc h
        ld (fx_mr),hl
        pop hl
        ld b,0
.col:   ld a,(hl)
        or a
        jr nz,.fg
        push hl
        ld a,(fx_ox)
        add a,b
        ld c,a
        rrca
        rrca
        and 7
        ld hl,(fx_mr)
        add a,l
        ld l,a
        jr nc,$+3
        inc h
        ld a,c
        and 3
        add a,(hl)
        ld hl,fx_ro
        add a,(hl)
        ld l,a
        ld h,0
        push de
        ld de,BGTILES
        add hl,de
        pop de
        ld a,(hl)
        pop hl
        jr .st
.fg:    cp $80
        jr z,.st
        bit 6,a
        jr z,.acc
        and $0F
        push hl
        ld hl,fx_bc
        or (hl)
        pop hl
        jr .st
.acc:   and $0F
        push hl
        ld hl,fx_ac
        or (hl)
        pop hl
.st:    ld (de),a
        inc de
        inc hl
        inc b
        ld a,b
        cp 32
        jp c,.col
        pop bc
        inc b
        ld a,(fx_rows)
        cp b
        jp nz,.row
        ret
.col16: ld a,l                  ; A = SG4 colour bits of band[C]
        add a,c
        ld l,a
        jr nc,$+3
        inc h
        ld a,(hl)
        rlca
        rlca
        rlca
        rlca
        or $80
        ret

; advance the scroll / colour phase and redraw
fx_step:
        ld a,(fx_ox)
        ld hl,fx_dx
        add a,(hl)
        ld (fx_ox),a
        ld a,(fx_oy)
        ld hl,fx_dy
        add a,(hl)
        ld (fx_oy),a
        ld hl,fx_phase
        inc (hl)
        jp fx_draw

; fill rows A..15 with text-band spaces
tx_band_from:
        cp 16
        ret nc
        push af
        call tx_bandrow
        pop af
        inc a
        jr tx_band_from
