; ---------------------------------------------------------------------------
;  .VZ loader stub (runs at $7AE9 after the BennVenn DOS has loaded the file)
;
;  blob = [levels][high A][high B][low]   (LZSS compressed)
;  1. stage [levels][high A][high B] into expansion bank 1 ($B800..)
;  2. unpack [low] (still in bank 0) straight to $7C20..$B01D
;  3. unpack levels -> DOS RAM page 0 at $4000
;  4. unpack high A / high B into DOS RAM page 1, then copy them into bank 0
; ---------------------------------------------------------------------------
        DEVICE NOSLOT64K
        INCLUDE "../build/pack.inc"

P0B0    EQU $01         ; DOS area RAM page 0, expansion bank 0  (run-time setting)
P0B1    EQU $05
P1B1    EQU $07
P1B0    EQU $03
BOUNCE  EQU $8000
STAGE   EQU $B800

        ORG $7AE9
start:  di
        ld sp,$7AE0
        ld a,1
        out ($3A),a             ; VZ300 memory mode
        ; --- 1. stage the first three segments into bank 1
        ld a,P0B1
        out ($37),a
        ld hl,blob
        ld de,STAGE
        ld bc,S1_INT            ; bytes of the staged part that lie below $B800
        ldir
    IF S1_EXT > 0
        ld a,P0B0
        out ($37),a
        ld hl,$B800
        ld de,BOUNCE
        ld bc,S1_EXT
        ldir
        ld a,P0B1
        out ($37),a
        ld hl,BOUNCE
        ld de,STAGE+S1_INT
        ld bc,S1_EXT
        ldir
    ENDIF
        ; --- 2. low segment straight from the loaded image (bank 0)
        ld a,P0B0
        out ($37),a
        ld hl,LOW_SRC
        ld de,$7C20
        call unpack
        ; --- 3. levels
        ld a,P0B1
        out ($37),a
        ld hl,STAGE+OFF_LEVELS
        ld de,$4000
        call unpack
        ; --- 4. high A and high B via DOS RAM page 1
        ld a,P1B1
        out ($37),a
        ld hl,STAGE+OFF_HA
        ld de,$4000
        call unpack
        ld a,P1B0
        out ($37),a
        ld hl,$4000
        ld de,HA_DST
        ld bc,HA_LEN
        ldir
        ld a,P1B1
        out ($37),a
        ld hl,STAGE+OFF_HB
        ld de,$4000
        call unpack
        ld a,P1B0
        out ($37),a
        ld hl,$4000
        ld de,HB_DST
        ld bc,HB_LEN
        ldir
        ld a,P0B0
        out ($37),a
        jp ENTRY

; LZSS: flag byte (LSB first) 1 = literal, 0 = match (2 bytes: off lo, off hi<<4 | len-3)
unpack:
.ctl:   ld a,(hl)
        inc hl
        ld (flags),a
        ld a,8
        ld (cnt),a
.bit:   ld a,(flags)
        srl a
        ld (flags),a
        jr nc,.match
        ld a,(hl)
        ld (de),a
        inc hl
        inc de
        jr .next
.match: ld c,(hl)
        inc hl
        ld a,(hl)
        inc hl
        push hl
        ld b,a
        and $0F
        add a,3
        push af
        ld a,b
        rrca
        rrca
        rrca
        rrca
        and $0F
        ld b,a
        or c
        jr z,.end
        ld h,d
        ld l,e
        or a
        sbc hl,bc
        pop af
        ld c,a
        ld b,0
        ldir
        pop hl
.next:  ld a,(cnt)
        dec a
        ld (cnt),a
        jr nz,.bit
        jr .ctl
.end:   pop af
        pop hl
        ret
flags:  db 0
cnt:    db 0
STUB_END:
        ASSERT STUB_END <= $7C20
blob:
        INCBIN "../build/blob.bin"
blob_end:
        SAVEBIN "../build/image.bin",$7AE9,blob_end-$7AE9
