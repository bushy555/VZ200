; ---------------------------------------------------------------------------
;  Native VZ300 tile renderer for the Repton 2 engine
;
;  The playfield is a world-anchored ring buffer of 32 x 21 "quarter" cells
;  (a quarter = 1/4 tile = 4x3 VZ pixels = 1 byte x 3 lines).  World quarter
;  (x,y) lives at ring column x&31, ring row y mod 21, so scrolling never moves
;  data: the engine's scroll call only exposes one new strip, drawn from the map.
;  vz_sync blits the ring to video RAM once per game step, rotated to the camera.
;
;  Ring row r occupies RING + r*128 (lines at +0,+32,+64), so all addressing is
;  carry-free:  H = RRH[y], L = RRL[y] | (x & 31).
; ---------------------------------------------------------------------------

; ---- vz_drawtile : replacement for E024 ----
; In : A = tile code, B = x, C = y (quarter units, tile's top-left)
; Out: preserves BC, DE, HL, IX, IY (AF destroyed) - same contract as original
vz_drawtile:
        push bc
        push de
        push hl
        ld e,a
        ld a,(V_POSX)
        sub VIEW_CX
        ld d,a                  ; vx0
        ld a,b
        sub d
        ld (dt_dx),a            ; dx = x - vx0
        add a,3
        cp VIEW_W+3
        jp nc,dt_out
        ld a,(V_POSY)
        sub VIEW_CY
        ld d,a
        ld a,c
        sub d
        ld (dt_dy),a
        add a,3
        cp VIEW_H+3
        jp nc,dt_out
        ld a,e
        cp $C0
        jr c,.n1
        ld a,$0D
        jr .n2
.n1:    cp $80
        call nc,vz_puzzle
.n2:    ld e,a
        ld a,(vz_xor)
        or a
        jp nz,dt_xor
        ; ---- copy mode: gfx = TILEPTR[tile]
        ld l,e
        ld h,0
        add hl,hl
        ld de,TILEPTR
        add hl,de
        ld e,(hl)
        inc hl
        ld d,(hl)
        ld (dt_gfx),de
        ; column range i0..i1, row range j0..j1
        ld a,(dt_dx)
        call dt_range31         ; A=dx -> D=i0, E=count
        ld a,d
        ld (dt_i0),a
        ld a,e
        ld (dt_in),a
        ld a,(dt_dy)
        call dt_range20
        ; rows
        ld a,d                  ; j0
        ld (dt_j),a
.rowlp: ld a,e
        ld (dt_jn),a
        ; y' = C + j ; ring row ptr
        ld a,(dt_j)
        add a,c
        ld l,a
        ld h,RRH_PAGE
        ld a,(hl)
        ld (dt_rh),a
        inc h
        ld a,(hl)
        ld (dt_rl),a
        ; columns
        ld a,(dt_i0)
        ld (dt_i),a
        ld a,(dt_in)
        ld (dt_icnt),a
.collp: ; gfx src = dt_gfx + (j*4+i)*3
        ld a,(dt_j)
        add a,a
        add a,a
        ld hl,dt_i
        add a,(hl)
        ld l,a
        add a,a
        add a,l                 ; *3
        ld hl,(dt_gfx)
        add a,l
        ld l,a
        jr nc,$+3
        inc h
        ex de,hl                ; DE = src
        ld a,(dt_i)
        add a,b
        and 31
        ld hl,dt_rl
        or (hl)
        ld l,a
        ld a,(dt_rh)
        ld h,a
        ld a,(de)
        ld (hl),a
        inc de
        set 5,l
        ld a,(de)
        ld (hl),a
        inc de
        res 5,l
        set 6,l
        ld a,(de)
        ld (hl),a
        ld hl,dt_i
        inc (hl)
        ld hl,dt_icnt
        dec (hl)
        jr nz,.collp
        ld hl,dt_j
        inc (hl)
        ld a,(dt_jn)
        ld e,a
        dec e
        jr nz,.rowlp
dt_out:
        pop hl
        pop de
        pop bc
        ret

; ---- XOR mode: only the centre 2x2 quarters, sprites $30-$35 ----
dt_xor:
        ld a,e
        sub $30
        cp 6
        jr nc,dt_out
        ld l,a
        add a,a
        add a,l                 ; *3
        add a,a
        add a,a                 ; *12
        ld l,a
        ld h,0
        ld de,XORSPR
        add hl,de
        ld (dt_gfx),hl
        ld e,0                  ; quarter index 0..3
        ld d,1                  ; j
.xr:    ld a,(dt_dy)
        add a,d
        cp VIEW_H
        jr nc,.xskiprow
        ld a,c
        add a,d
        ld l,a
        ld h,RRH_PAGE
        ld a,(hl)
        ld (dt_rh),a
        inc h
        ld a,(hl)
        ld (dt_rl),a
        push de
        ld d,1                  ; i
.xc:    ld a,(dt_dx)
        add a,d
        cp VIEW_W
        jr nc,.xskip
        push de
        ; src = gfx + e*3
        ld a,e
        add a,a
        add a,e
        ld hl,(dt_gfx)
        add a,l
        ld l,a
        jr nc,$+3
        inc h
        ex de,hl
        ld a,b
        pop hl
        push hl
        add a,h                 ; x + i
        and 31
        ld hl,dt_rl
        or (hl)
        ld l,a
        ld a,(dt_rh)
        ld h,a
        ld a,(de)
        xor (hl)
        ld (hl),a
        inc de
        set 5,l
        ld a,(de)
        xor (hl)
        ld (hl),a
        inc de
        res 5,l
        set 6,l
        ld a,(de)
        xor (hl)
        ld (hl),a
        pop de
.xskip: inc e
        inc d
        ld a,d
        cp 3
        jr c,.xc
        ld a,e                  ; keep quarter index in step
        pop de
        ld e,a
        jr .xnext
.xskiprow:
        inc e
        inc e
.xnext: inc d
        ld a,d
        cp 3
        jr c,.xr
        jp dt_out

; A = dx (signed) -> D = first index (0..3), E = count, clipped to [0,31]
dt_range31:
        ld d,0
        bit 7,a
        jr z,.pos
        neg
        ld d,a                  ; i0 = -dx
        ld a,4
        sub d
        ld e,a
        ret
.pos:   ld e,4
        cp 29
        ret c                   ; dx <= 28 -> full
        ld e,a
        ld a,32
        sub e
        ld e,a                  ; count = 32-dx
        ret
dt_range20:
        ld d,0
        bit 7,a
        jr z,.pos
        neg
        ld d,a
        ld a,4
        sub d
        ld e,a
        ret
.pos:   ld e,4
        cp 18
        ret c
        ld e,a
        ld a,21
        sub e
        ld e,a
        ret

dt_dx:  db 0
dt_dy:  db 0
dt_gfx: dw 0
dt_i0:  db 0
dt_in:  db 0
dt_i:   db 0
dt_icnt: db 0
dt_j:   db 0
dt_jn:  db 0
dt_rh:  db 0
dt_rl:  db 0
vz_xor: db 0

; ---- mode switches (replace E168 / E19E) ----
vz_xormode:
        ld a,1
        ld (vz_xor),a
        ret
vz_copymode:
        xor a
        ld (vz_xor),a
        ret

; ---- draw one quarter straight from the map:  B = x, C = y ----
vz_mapquarter:
        push bc
        ; tile column with clamping to 0..37
        ld a,b
        cp 38*4
        jr c,.xok
        cp $C0
        ld a,0
        jr nc,.xok
        ld a,37*4
.xok:   rrca
        rrca
        and $3F
        ld e,a
        ld a,c
        cp 42*4
        jr c,.yok
        ld a,41*4
.yok:   rrca
        rrca
        and $3F
        add a,a
        ld l,a
        ld h,0
        ld a,e
        ld de,MAPROWS
        add hl,de
        ld e,(hl)
        inc hl
        ld d,(hl)
        ex de,hl
        add a,l
        ld l,a
        jr nc,$+3
        inc h
        ld a,(hl)               ; tile code
        cp $C0
        jr c,.m1
        ld a,$0D
        jr .m2
.m1:    cp $80
        call nc,vz_puzzle
.m2:    ld l,a
        ld h,0
        add hl,hl
        ld de,TILEPTR
        add hl,de
        ld e,(hl)
        inc hl
        ld d,(hl)               ; DE = tile gfx
        ld a,c
        and 3
        add a,a
        add a,a
        ld l,a
        ld a,b
        and 3
        add a,l
        ld l,a
        add a,a
        add a,l                 ; *3
        add a,e
        ld e,a
        jr nc,$+3
        inc d
        ld l,c
        ld h,RRH_PAGE
        ld a,(hl)
        inc h
        ld l,(hl)
        ld h,a
        ld a,b
        and 31
        or l
        ld l,a
        ld a,(de)
        ld (hl),a
        inc de
        set 5,l
        ld a,(de)
        ld (hl),a
        inc de
        res 5,l
        set 6,l
        ld a,(de)
        ld (hl),a
        pop bc
        ret

; ---- draw the whole view from the map (replaces DC66..DCA9 tile loop) ----
vz_fullview:
        ld a,(V_POSY)
        sub VIEW_CY
        ld c,a
        ld a,VIEW_H
.r:     push af
        ld a,(V_POSX)
        sub VIEW_CX
        ld b,a
        ld a,VIEW_W
.c:     push af
        call vz_mapquarter
        inc b
        pop af
        dec a
        jr nz,.c
        inc c
        pop af
        dec a
        jr nz,.r
        ret

; ---- scroll (replaces E865): ring is world anchored, only set step pacing ----
vz_scroll:
        ld a,(V_DIR)
        and 1
        ld a,3                  ; vertical move: 3 frames per step (as Spectrum)
        jr z,.v
        ld a,4                  ; horizontal move: 4 frames per step
.v:     ld (vz_target),a
        ret

; ---- strip (replaces E9F8.. after the camera update in E9DE) ----
vz_strip:
        ld a,(V_DIR)
        or a
        jr z,.up
        dec a
        jr z,.right
        dec a
        jr z,.down
        ; left: column x = vx0
        ld a,(V_POSX)
        sub VIEW_CX
        jr .col
.right: ld a,(V_POSX)
        sub VIEW_CX-VIEW_W+1
.col:   ld b,a
        ld a,(V_POSY)
        sub VIEW_CY
        ld c,a
        ld a,VIEW_H
.cl:    push af
        call vz_mapquarter
        inc c
        pop af
        dec a
        jr nz,.cl
        ret
.up:    ld a,(V_POSY)
        sub VIEW_CY
        jr .row
.down:  ld a,(V_POSY)
        sub VIEW_CY-VIEW_H+1
.row:   ld c,a
        ld a,(V_POSX)
        sub VIEW_CX
        ld b,a
        ld a,VIEW_W
.rl:    push af
        call vz_mapquarter
        inc b
        pop af
        dec a
        jr nz,.rl
        ret

; ---- puzzle piece tile (replaces DFC5): A = $80..$A9 -> builds tile $0E, returns $0E
vz_puzzle:
        push hl
        ld hl,V_PUZCACHE
        cp (hl)
        jr z,.done
        ld (hl),a
        push bc
        push de
        and $7F
        ld l,a
        ld h,0
        add hl,hl
        add hl,hl
        add hl,hl
        ld de,$8D9E
        add hl,de               ; 8 bitmap rows
        ld de,pz_rows
        ld b,8
.ex:    push bc
        ld c,(hl)               ; expand 8 bits -> 16 px (2 bytes), green on blue
        call pz_nib
        ld (de),a
        inc de
        call pz_nib
        ld (de),a
        inc de
        call pz_nib
        ld (de),a
        inc de
        call pz_nib
        ld (de),a
        inc de
        inc hl
        pop bc
        djnz .ex
        ; 8 rows -> 12 rows, write quarter-major into tile $0E
        ld hl,pz_map
        ld de,TILES+$0E*48
        ld b,4                  ; quarter rows
.qr:    push bc
        push hl
        ld c,0                  ; quarter column
.qc:    pop hl
        push hl
        ld b,3
.ql:    ld a,(hl)               ; source row index*4
        push hl
        add a,c
        ld l,a
        ld h,0
        push de
        ld de,pz_rows
        add hl,de
        pop de
        ld a,(hl)
        ld (de),a
        inc de
        pop hl
        inc hl
        djnz .ql
        inc c
        ld a,c
        cp 4
        jr c,.qc
        pop hl
        inc hl
        inc hl
        inc hl
        pop bc
        djnz .qr
        pop de
        pop bc
.done:  ld a,$0E
        pop hl
        ret
; take 2 bits from C (msb first) -> byte with 2 px each: bit set = green(00) else blue(10)
pz_nib: ld a,0
        rl c
        jr c,.b1
        or $A0
.b1:    rl c
        jr c,.b2
        or $0A
.b2:    ret
pz_rows: ds 32
pz_map:  db 0,4,4, 8,12,12, 16,20,20, 24,28,28     ; 12 output rows -> source row*4

; ---- frame sync + blit (replaces DF07) ----
vz_sync:
        push ix
        ei
.w:     ld hl,(vz_frames)
        ld de,(vz_last)
        or a
        sbc hl,de
        ld a,h
        or a
        jr nz,.go
        ld a,(vz_target)
        ld e,a
        ld a,l
        cp e
        jr nc,.go
        halt
        jr .w
.go:    ld hl,(vz_frames)
        ld (vz_last),hl
        ld a,2
        ld (vz_target),a
        call vz_blit
        pop ix
        ret

vz_frames:  dw 0
vz_last:    dw 0
vz_target:  db 2

; ---- blit ring -> VRAM, rotated to the camera ----
vz_blit:
        call bl_setup
        ld a,VIEW_H
        ld (bl_n),a
        xor a
        ld (bl_r),a
.row:   call bl_qrow
        ld hl,bl_r
        inc (hl)
        ld hl,bl_n
        dec (hl)
        jr nz,.row
        ret
; prepare the column rotation entry points for the current camera
bl_setup:
        ld a,(V_POSX)
        sub VIEW_CX
        and 31
        ld (bl_off),a
        ld e,a                  ; entry1 = LDIBLK + 2*off  (copies 32-off bytes)
        ld d,0
        ld hl,LDIBLK
        add hl,de
        add hl,de
        ld (bl_qrow.c1+1),hl
        ld a,32
        sub e
        ld e,a                  ; entry2 = LDIBLK + 2*(32-off)  (copies off bytes)
        ld hl,LDIBLK
        add hl,de
        add hl,de
        ld (bl_qrow.c2+1),hl
        ret
; copy view quarter-row (bl_r) to VRAM row bl_r*96
bl_qrow:
        ld a,(V_POSY)
        sub VIEW_CY
        ld hl,bl_r
        add a,(hl)
        ld l,a
        ld h,MOD21_PAGE
        ld a,(hl)               ; ring row
        ld c,a
        srl a
        add a,RING/256
        ld h,a
        ld a,c
        rrca
        and $80
        ld (bl_lb),a
        ; DE = VRAM + r*96
        ld a,(bl_r)
        ld l,a
        ld e,a
        ld d,0
        push hl
        ld h,0
        add hl,hl
        add hl,de               ; *3
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl               ; *96
        ld de,VRAM
        add hl,de
        ex de,hl
        pop hl
        ld a,(V_POSY)
        sub VIEW_CY
        ld hl,bl_r
        add a,(hl)
        ld l,a
        ld h,MOD21_PAGE
        ld a,(hl)
        srl a
        add a,RING/256
        ld h,a
        ld b,3
.line:  push bc
        ld a,(bl_off)
        ld c,a
        ld a,(bl_lb)
        or c
        ld l,a
.c1:    call LDIBLK
        ld a,(bl_lb)
        ld l,a
.c2:    call LDIBLK
        ld a,(bl_lb)
        add a,32
        ld (bl_lb),a
        pop bc
        djnz .line
        ret
bl_off: db 0
bl_r:   db 0
bl_lb:  db 0
bl_n:   db 0

LDIBLK:
        REPT 32
        ldi
        ENDR
        ret

; ---- reveal the freshly drawn view: centre-out wipe (replaces DCCF/DD02 wipe)
vz_reveal:
        call vz_cls
        call bl_setup
        ld b,0
.st:    push bc
        ei
        halt
        pop bc
        push bc
        ld a,10
        sub b
        ld (bl_r),a
        call bl_qrow
        pop bc
        push bc
        ld a,10
        add a,b
        cp 21
        jr nc,.nx
        ld (bl_r),a
        call bl_qrow
.nx:    pop bc
        inc b
        ld a,b
        cp 11
        jr c,.st
        ld hl,(vz_frames)
        ld (vz_last),hl
        ret

; ---- screen helpers ----
vz_gfxmode:
        ld a,LAT_GFX
        ld (vz_latch),a
        ld (LATCH),a
        ret
vz_txtmode:
        ld a,LAT_TXT
        ld (vz_latch),a
        ld (LATCH),a
        ret
vz_latch: db LAT_GFX

; clear graphics screen to background blue (replaces DB3D)
vz_cls:
        call vz_gfxmode
        ld hl,VRAM
        ld de,VRAM+1
        ld bc,2047
        ld (hl),$AA
        ldir
        ret

; dissolve the current screen to blue in a few frames (replaces DB4B / DB08)
vz_fade:
        ld a,(vz_latch)
        and 8
        jr z,.text
        ld hl,fade_masks
        ld b,5
.p:     push bc
        push hl
        ld c,(hl)               ; mask of pixels to keep
        ld a,c
        cpl
        and $AA
        ld b,a                  ; blue in the cleared pixels
        ld hl,VRAM
        ld de,2048
.lp:    ld a,(hl)
        and c
        or b
        ld (hl),a
        inc hl
        dec de
        ld a,d
        or e
        jr nz,.lp
        ei
        halt
        halt
        pop hl
        inc hl
        pop bc
        djnz .p
        jp vz_cls
.text:  ; text screens: wipe rows from the outside in
        ld b,8
.tw:    push bc
        ld a,b
        dec a
        call tx_clearrow
        ld a,16
        sub b
        call tx_clearrow
        ei
        halt
        pop bc
        djnz .tw
        jp vz_cls
fade_masks: db $F3,$33,$30,$00,$00

; ---- level colours: recolour wall/earth tiles for the level (hooked after E2FF)
; level ink (FF3B & 7): 1 blue -> green, 5 cyan -> yellow, 2 red / 3 magenta -> red
vz_levelcolours:
        push bc
        push de
        push hl
        ld a,(V_PAL)
        and 7
        ld hl,lc_perm_green
        cp 1
        jr z,.go
        ld hl,lc_perm_yellow
        cp 5
        jr z,.go
        cp 3                    ; magenta levels -> yellow walls too
        jr z,.go
        ld hl,lc_perm_red
.go:    ld (lc_perm),hl
        ; for each variant tile: copy base, remap colours
        ld hl,VARLIST
.t:     ld a,(hl)
        cp $FF
        jr z,.end
        inc hl
        push hl
        ld l,a
        ld h,0
        add hl,hl
        ld de,TILEPTR
        add hl,de
        ld e,(hl)
        inc hl
        ld d,(hl)               ; DE = destination tile
        pop hl
        push hl
        dec hl                  ; index into VARLIST -> base copy
        ld bc,VARLIST
        or a
        sbc hl,bc
        ; base = VARBASE + idx*48
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl               ; *16
        ld b,h
        ld c,l
        add hl,hl               ; *32
        add hl,bc               ; *48
        ld bc,VARBASE
        add hl,bc
        ld b,48
.by:    push bc
        ld c,(hl)
        call lc_remap
        ld (de),a
        inc hl
        inc de
        pop bc
        djnz .by
        pop hl
        jr .t
.end:   pop hl
        pop de
        pop bc
        ret
; remap 4 pixels in C through the 4-entry permutation table
lc_remap:
        push hl
        push de
        ld hl,(lc_perm)
        ld b,4
        ld e,0
.px:    ld a,c
        rlca
        rlca
        ld c,a
        and 3
        push hl
        add a,l
        ld l,a
        jr nc,$+3
        inc h
        ld a,(hl)
        pop hl
        sla e
        sla e
        or e
        ld e,a
        djnz .px
        ld a,e
        pop de
        pop hl
        ret
lc_perm:        dw lc_perm_green
lc_perm_green:  db 0,1,2,3
lc_perm_yellow: db 1,0,2,3
lc_perm_red:    db 3,1,2,0
