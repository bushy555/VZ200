; ---------------------------------------------------------------------------
;  REPTON 2 for the Dick Smith VZ300  (BennVenn 128K + SD)
;  Built on the original ZX Spectrum engine image; see patches.asm.
; ---------------------------------------------------------------------------
        DEVICE NOSLOT64K
        INCLUDE "defs.asm"

        ORG 0
        INCBIN "../build/orig64k.bin"

; ---- region A: $8008..$8C9A (old Spectrum font / logo / line tables) ----
        ORG $8008
REGION_A:
        INCLUDE "render.asm"
        INCLUDE "input.asm"
        INCLUDE "sound.asm"
        INCLUDE "init.asm"
END_A:
        ASSERT END_A <= $8C9B

; ---- region B: $8EEE..$B01D (old Spectrum tile graphics) ----
        ORG $8EEE
REGION_B:
        INCLUDE "gen_data.asm"
        INCLUDE "screens.asm"
        INCLUDE "demo.asm"
END_B:
        ASSERT END_B <= $B01E

RING    EQU $C000               ; 21 rows x 128 bytes ($C000-$CA7F)

; ---- region C: $CA80..$D0F6 (old Spectrum attribute ring) ----
        ORG $CA80
REGION_C:
        INCLUDE "gen_data2.asm"
END_C:
        ASSERT END_C <= $D0F7

; ---- region D: $D330..$D886 (old Spectrum clip/strip/wipe tables and status texts) ----
        ORG $D330
REGION_D:
        INCLUDE "fancy.asm"
        INCLUDE "gen_fancy.asm"
END_D:
        ASSERT END_D <= $D887

        INCLUDE "patches.asm"

        SAVEBIN "../build/vz64k.bin",0,65536
        DISPLAY "region A end: ",/H,END_A," (limit 8C9B)"
        DISPLAY "region B end: ",/H,END_B," (limit B01E)"
        DISPLAY "region C end: ",/H,END_C," (limit D0F7)"
        DISPLAY "region D end: ",/H,END_D," (limit D887)"
