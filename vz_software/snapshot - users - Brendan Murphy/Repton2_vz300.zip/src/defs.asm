; ---------------------------------------------------------------------------
;  Repton 2  -  ZX Spectrum -> Dick Smith VZ300 conversion
;  Equates: VZ hardware, BennVenn SD loader, original Spectrum engine variables
; ---------------------------------------------------------------------------

; ---- VZ300 hardware ----
LATCH           EQU $6800       ; write: b0/b5 speaker, b3 AG (1=128x64x4), b4 CSS
KBD             EQU $6800       ; read : $68xx, row i selected by A(i)=0, b0-5 keys, b7 FS
VRAM            EQU $7000
LAT_GFX         EQU $08         ; CG2 mode, CSS=0 (green/yellow/blue/red)
LAT_TXT         EQU $10         ; text/SG4 mode, CSS=1 (orange text)
LAT_TXT_ORANGE  EQU $10
SPK_MASK        EQU $21         ; toggle both speaker bits for full swing

; ---- BennVenn SD loader ----
BV_MAPPER       EQU $37         ; b0 DOS ROM/RAM, b1 DOS RAM page, b2 exp bank, b3 LED
BV_MODE         EQU $3A         ; b0 = VZ300 mode
BV_RUN          EQU $01         ; DOS area = RAM page 0, expansion bank 0

; ---- joystick interface ----
JOY1_PORT       EQU $2C         ; J1 directions (arm select also low, works on user's unit)
JOY2_PORT_A     EQU $29         ; J2 (left/right reliable on user's unit)
JOY2_PORT_B     EQU $23         ; J2 via joy1+arm select

; ---- original engine variables (unchanged addresses) ----
V_POSY          EQU $FF01       ; camera / Repton y (quarter tiles)
V_POSX          EQU $FF02
V_OLDPOS        EQU $FF03
V_RESTART       EQU $FF05
V_MAPCUR        EQU $FF07
V_MAPNXT        EQU $FF09
V_DIR           EQU $FF15
V_LIVES         EQU $FF16
V_LEVEL         EQU $FF17
V_COUNT         EQU $FF18       ; 5 x 3-byte counters: earth, diamonds, transp., puzzle, monsters
V_SNDFLAGS      EQU $FF27
V_THUD          EQU $FF28
V_SOUND         EQU $FF29
V_MUSIC         EQU $FF2A
V_ISRSTATE      EQU $FF2B
V_CONTROL       EQU $FF2C
V_STEP          EQU $FF2F
V_SCORE         EQU $FF30       ; word + units digit
V_PAL           EQU $FF3B       ; level palette (5 bytes)
V_DEATHVEC      EQU $FF46
V_STATVEC       EQU $FF48
V_HISCORE       EQU $FF4A       ; 8 x 3 bytes
V_MUS1          EQU $FF6C
V_MUS1LOOP      EQU $FF6E
V_MUS2          EQU $FF70
V_MUS2LOOP      EQU $FF72
V_KDIR          EQU $FF74       ; b3 up b2 down b1 left b0 right (0=pressed), $0F=none
V_KSUICIDE      EQU $FF75       ; 0 = pressed
V_KQUIT         EQU $FF76
V_KCTRL         EQU $FF77
V_KSOUND        EQU $FF78
V_KMUSIC        EQU $FF79
V_SPIRITS       EQU $FF7C
V_DONEVEC       EQU $FF7D
V_PUZCACHE      EQU $FF7F

MAPBASE         EQU $B1BC       ; 38 x 42 map buffer
MAPW            EQU 38

; ---- original routine addresses ----
O_DAE2          EQU $DAE2       ; BC=(x,y) -> HL = map cell
O_MAINLOOP      EQU $F838
O_PLAY          EQU $F828
O_NEWGAME       EQU $F7CC
O_DEATH         EQU $F887
O_GAMEOVER      EQU $F4AD
O_LEVELLOAD     EQU $E1E8

; ---- view geometry (quarter tiles) ----
VIEW_W          EQU 32
VIEW_H          EQU 21
VIEW_CX         EQU 14          ; Repton tile occupies view columns 14..17
VIEW_CY         EQU 9           ; and rows 9..12
