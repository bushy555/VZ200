; ---------------------------------------------------------------------------
;  VZ300 keyboard + joystick input (replaces DD43 / DDE6)
;  Movement : Q up, A down, O left, P right  -or-  either VZ joystick
;  CTRL+1   : lose a life (Spectrum CAPS+1)     CTRL+R : quit game (CAPS+R)
;  D        : sound on/off                       E      : music on/off
; ---------------------------------------------------------------------------

vz_keys:
        push bc
        ld b,$0F
        ld a,($68FE)            ; row 0 : R Q E - W T
        ld c,a
        bit 4,c
        jr nz,.k1
        res 3,b                 ; Q = up
.k1:    ld a,($68FD)            ; row 1 : F A D CTRL S G
        bit 4,a
        jr nz,.k2
        res 2,b                 ; A = down
.k2:    ld a,($68BF)            ; row 6 : U P I RET O Y
        bit 1,a
        jr nz,.k3
        res 1,b                 ; O = left
.k3:    bit 4,a
        jr nz,.k4
        res 0,b                 ; P = right
.k4:    call joy_read           ; A: b0 up b1 down b2 left b3 right (0 = pressed)
        bit 0,a
        jr nz,.j1
        res 3,b
.j1:    bit 1,a
        jr nz,.j2
        res 2,b
.j2:    bit 2,a
        jr nz,.j3
        res 1,b
.j3:    bit 3,a
        jr nz,.j4
        res 0,b
.j4:    ld a,b
        ld (V_KDIR),a
        ; CTRL held?
        ld a,($68FD)
        and 4                   ; 0 = CTRL pressed
        ld b,a
        ld a,($68F7)            ; row 3 : 4 1 3 - 2 5   ('1' = bit 4)
        and $10
        or b
        ld (V_KSUICIDE),a       ; 0 only when CTRL+1
        ld a,c                  ; row 0, R = bit 5
        and $20
        or b
        ld (V_KQUIT),a          ; 0 only when CTRL+R
        ld a,1
        ld (V_KCTRL),a          ; control selection not needed on the VZ
        ld a,($68FD)            ; D = row 1 bit 3
        and 8
        ld (V_KSOUND),a
        ld a,c                  ; E = row 0 bit 3
        and 8
        ld (V_KMUSIC),a
        pop bc
        ret

; read both joysticks, return combined active-low bits (b0 up b1 down b2 left b3 right b4 fire)
; a joystick that reads up+down or left+right together is treated as absent
joy_read:
        push bc
        in a,(JOY1_PORT)
        call joy_valid
        ld c,a
        in a,(JOY2_PORT_A)
        ld b,a
        in a,(JOY2_PORT_B)
        and b
        call joy_valid
        and c
        pop bc
        ret
joy_valid:
        push bc
        ld b,a
        and 3
        jr z,.bad
        ld a,b
        and $0C
        jr z,.bad
        ld a,b
        pop bc
        ret
.bad:   ld a,$FF
        pop bc
        ret

; ---- generic helpers used by the menus ----
; Z set if SPACE or any fire button is down
any_start:
        ld a,(kb_sticky)
        or a
        jr z,.ns
        xor a
        ld (kb_sticky),a
        ret                     ; Z
.ns:    ld a,($68EF)            ; row 4 : M SPACE , - . N
        bit 4,a
        ret z
        call joy_read
        bit 4,a
        ret
; wait until SPACE and fire are released
wait_release:
        xor a
        ld (kb_sticky),a
        call any_start
        jr z,wait_release
        ret
; Z set if any key at all (or joystick) is pressed
any_key:
        ld a,($6800)
        and $3F
        cp $3F
        ret nz
        call joy_read
        and $1F
        cp $1F
        ret
