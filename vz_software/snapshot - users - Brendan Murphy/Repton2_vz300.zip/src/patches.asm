; ---------------------------------------------------------------------------
;  Patches applied to the ORIGINAL Spectrum engine at its original addresses.
;  Everything not listed here (movement, rock physics, monsters, spirits,
;  transporters, puzzle pieces, scoring, level unpacking, death/completion
;  logic and the main loop at F838) runs unchanged.
; ---------------------------------------------------------------------------

        ORG $DE06               ; IM2 interrupt handler (vector at FDFD)
        jp vz_isr
        ORG $F985               ; title-screen interrupt handler
        jp vz_isr

        ORG $E024               ; draw tile into the display buffer
        jp vz_drawtile
        ORG $E168               ; select XOR drawing (sprites)
        jp vz_xormode
        ORG $E19E               ; select copy drawing
        jp vz_copymode
        ORG $DFC5               ; build puzzle-piece tile
        jp vz_puzzle
        ORG $DF07               ; wait frame + copy buffer to screen
        jp vz_sync
        ORG $E865               ; scroll the ring buffer one quarter
        jp vz_scroll
        ORG $E9F8               ; draw newly exposed strip (after camera update)
        jp vz_strip
        ORG $EAD2               ; strip parameter setup - not needed
        ret

        ORG $DC30               ; new screen: reset view and draw it
        jp vz_newscreen
        ORG $DCCF               ; copy buffer to screen with wipe -> VZ reveal
        ld bc,(V_POSY)
        ld a,$23
        call vz_drawtile
        jp vz_reveal

        ORG $DB3D               ; clear screen
        jp vz_cls
        ORG $DB4B               ; dissolve screen
        jp vz_fade
        ORG $DB08               ; fade (before status screen)
        jp vz_fade

        ORG $DD43               ; keyboard / joystick (+ fire = status, demo playback)
        jp vz_keys_game
        ORG $DC0C               ; beeper effects
        jp vz_beep
        ORG $F0E0               ; transporter flash + sound
        jp vz_transport

        ORG $F5CD               ; status / start screen
        jp vz_status
        ORG $F4AD               ; game over -> hi-score table
        jp vz_gameover
        ORG $FB71               ; completion message screen
        jp vz_complete

        ORG $E203               ; level data relocated from $5B00 to $4000 (DOS RAM)
        db $40
        ORG $E300               ; after the level palette is set: recolour tiles
        jp vz_lc_hook

        ORG $F6F6               ; original cold start
        jp vz_init
