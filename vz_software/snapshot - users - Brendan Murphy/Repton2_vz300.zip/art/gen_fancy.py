#!/usr/bin/env python3
"""Big-lettering glyphs, background map tiles and colour bands for the menu screens -> src/gen_fancy.asm"""
out = []
def label(n): out.append(f"{n}:")
def db(bs, per=16):
    bs = list(bs)
    for i in range(0, len(bs), per):
        out.append("        db " + ",".join(f"${b:02X}" for b in bs[i:i + per]))

# ---- big glyphs 9 x 11 ----
G = {
'R': ["#######..", "########.", "##....###", "##....###", "##...###.", "#######..", "######...", "##..###..", "##...###.", "##....###", "##....###"],
'E': ["#########", "#########", "##.......", "##.......", "#######..", "#######..", "##.......", "##.......", "##.......", "#########", "#########"],
'P': ["#######..", "########.", "##....###", "##....###", "##...###.", "#######..", "######...", "##.......", "##.......", "##.......", "##......."],
'T': ["#########", "#########", "...###...", "...###...", "...###...", "...###...", "...###...", "...###...", "...###...", "...###...", "...###..."],
'O': ["..#####..", ".#######.", "###...###", "##.....##", "##.....##", "##.....##", "##.....##", "##.....##", "###...###", ".#######.", "..#####.."],
'N': ["###....##", "####...##", "#####..##", "##.##..##", "##..##.##", "##...####", "##....###", "##.....##", "##.....##", "##.....##", "##.....##"],
'G': ["..######.", ".########", "###......", "##.......", "##.......", "##...####", "##...####", "##.....##", "###...###", ".########", "..######."],
'A': ["...###...", "..#####..", ".###.###.", "###...###", "##.....##", "##.....##", "#########", "#########", "##.....##", "##.....##", "##.....##"],
'M': ["##.....##", "###...###", "####.####", "##.###.##", "##..#..##", "##.....##", "##.....##", "##.....##", "##.....##", "##.....##", "##.....##"],
'V': ["##.....##", "##.....##", "##.....##", "##.....##", "##.....##", "###...###", ".##...##.", ".###.###.", "..#####..", "...###...", "....#...."],
'2': [".#######.", "#########", "##....###", ".....###.", "....###..", "...###...", "..###....", ".###.....", "###......", "#########", "#########"],
'*': ["....#....", "...###...", "..#####..", ".#######.", "#########", ".#######.", "..#####..", "...###...", "....#....", ".........", "........."],
}
ORDER = "REPTONGAMV2*"
label("BIGFONT")
for ch in ORDER:
    g = G[ch]; assert len(g) == 11 and all(len(r) == 9 for r in g), ch
    bs = []
    for r in g:
        v = 0
        for k, c in enumerate(r):
            if c == '#': v |= 1 << (15 - k)
        bs += [v >> 8, v & 255]
    db(bs)
label("BIGMAP")      # ASCII -> glyph index (only the letters used)
m = [0xFF] * 64
for i, ch in enumerate(ORDER): m[ord(ch) - 32] = i
db(m)

# ---- background tiles: 8x8 px -> 4x4 SG4 cells (one colour per cell) ----
COL = {'.': None, 'g': 0, 'y': 1, 'b': 2, 'r': 3, 'w': 4, 'c': 5, 'm': 6, 'o': 7}
TILES = {
 'empty':  ["........"] * 8,
 'brick':  ["bbbbbbb.", "bbbbbbb.", "........", "bbb.bbbb", "bbb.bbbb", "........", "bbbbbbb.", "bbbbbbb."],
 'earth':  ["........", ".m....m.", "...m....", "......m.", ".m......", "....m...", "........", "..m...m."],
 'diam':   ["...cc...", "..cccc..", ".cccccc.", "cccccccc", "cccccccc", ".cccccc.", "..cccc..", "...cc..."],
 'rock':   ["..rrrr..", ".rrrrrr.", "rrrrrrrr", "rrrrrrrr", "rrrrrrrr", "rrrrrrrr", ".rrrrrr.", "..rrrr.."],
 'gwall':  ["gggggggg", "gggggggg", "gg.gg.gg", "gggggggg", "gggggggg", "g.gg.ggg", "gggggggg", "gggggggg"],
 'skull':  ["..wwww..", ".wwwwww.", "w..ww..w", "w..ww..w", "wwwwwwww", ".w.ww.w.", ".wwwwww.", "..w..w.."],
 'mwall':  ["mmmmmmm.", "mmmmmmm.", "........", "mmm.mmmm", "mmm.mmmm", "........", "mmmmmmm.", "mmmmmmm."],
 'transp': ["cccccccc", "c......c", "c.cccc.c", "c.c..c.c", "c.c..c.c", "c.cccc.c", "c......c", "cccccccc"],
 'egg':    ["...yy...", "..yyyy..", ".yyyyyy.", ".yyyyyy.", "yyyyyyyy", "yyyyyyyy", ".yyyyyy.", "..yyyy.."],
}
TNAMES = list(TILES)
def tcells(rows):
    cells = []
    for cy in range(4):
        for cx in range(4):
            px = [rows[cy * 2][cx * 2], rows[cy * 2][cx * 2 + 1], rows[cy * 2 + 1][cx * 2], rows[cy * 2 + 1][cx * 2 + 1]]
            cols = [COL[p] for p in px if COL[p] is not None]
            if not cols:
                cells.append(0x80); continue
            c = max(set(cols), key=cols.count)
            q = 0
            for bit, p in zip((8, 4, 2, 1), px):
                if COL[p] == c: q |= bit
            cells.append(0x80 | (c << 4) | q)
    return cells
label("BGTILES")
for n in TNAMES: db(tcells(TILES[n]))
def bmap(lbl, rows):
    label(lbl)
    bs = []
    for r in rows:
        for n in r.split(): bs.append(TNAMES.index(n) * 16)
    assert len(bs) == 32
    db(bs)
bmap("MAP_TITLE", ["brick brick diam earth earth rock brick brick",
                   "earth empty rock brick brick earth diam earth",
                   "rock brick earth diam earth brick brick empty",
                   "brick diam earth brick empty rock earth brick"])
bmap("MAP_STATUS", ["gwall diam gwall transp gwall egg gwall diam",
                    "empty gwall diam gwall empty gwall transp gwall",
                    "gwall egg gwall empty gwall diam gwall empty",
                    "diam gwall empty gwall diam gwall egg gwall"])
bmap("MAP_OVER", ["rock empty skull mwall rock earth empty skull",
                  "mwall rock earth empty skull rock mwall empty",
                  "empty skull mwall rock empty mwall skull rock",
                  "skull earth rock empty mwall empty rock mwall"])
bmap("MAP_HISC", ["diam empty diam empty diam empty diam empty",
                  "empty transp empty diam empty transp empty diam",
                  "diam empty diam empty diam empty diam empty",
                  "empty diam empty transp empty diam empty transp"])

# ---- letter colour bands (16 entries, indexed by cell row + phase) ----
def band(lbl, seq):
    label(lbl); db((seq * 16)[:16])
band("BAND_WARM", [4, 1, 1, 7, 7, 3, 3, 7, 7, 1, 1, 4])
band("BAND_COOL", [4, 5, 5, 0, 0, 1, 1, 0, 0, 5, 5, 4])
band("BAND_HOT",  [3, 3, 7, 7, 1, 1, 4, 4, 1, 1, 7, 7])
band("BAND_RAIN", [3, 7, 1, 0, 5, 2, 6, 4])

open('/home/claude/repton2/src/gen_fancy.asm', 'w').write("; generated by art/gen_fancy.py\n" + "\n".join(out) + "\n")
print("ok")
