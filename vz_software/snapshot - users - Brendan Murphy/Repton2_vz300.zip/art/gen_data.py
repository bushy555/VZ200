#!/usr/bin/env python3
"""Generate VZ300 data tables for the Repton 2 port -> src/gen_data.asm"""
import sys, random
sys.path.insert(0, '/home/claude/repton2/art')
from vzart import T

LEGS = 'r'          # Repton legs colour
COL = {'g': 0, 'y': 1, '.': 2, 'r': 3, 'l': {'g': 0, 'y': 1, 'r': 3}[LEGS]}

out = []
def label(n): out.append(f"{n}:")
def db(bs, per=16):
    bs = list(bs)
    for i in range(0, len(bs), per):
        out.append("        db " + ",".join(f"${b:02X}" for b in bs[i:i + per]))
def align(n): out.append(f"        ALIGN {n}")

def tile_bytes(rows):
    """16x12 art -> 48 bytes quarter-major: quarter (qy,qx) = 3 lines x 1 byte"""
    px = [[COL[c] for c in r] for r in rows]
    res = []
    for qy in range(4):
        for qx in range(4):
            for l in range(3):
                y = qy * 3 + l
                b = 0
                for k in range(4):
                    b = (b << 2) | px[y][qx * 4 + k]
                res.append(b)
    return res

NT = 0x3B
tiles = [tile_bytes(T[t]) for t in range(NT)]

# level-variant tiles (walls + earth): recoloured at level start
VAR = [0x04, 0x05, 0x06, 0x07, 0x0A, 0x0B, 0x0C] + list(range(0x13, 0x1F))

# XOR sprites $30-$35 : centre 2x2 quarters; opaque pixels stored as colour ^ blue(2)
xorspr = []
for t in range(0x30, 0x36):
    rows = T[t]
    for qy in (1, 2):
        for qx in (1, 2):
            for l in range(3):
                y = qy * 3 + l
                b = 0
                for k in range(4):
                    c = rows[y][qx * 4 + k]
                    v = 0 if c == '.' else (COL[c] ^ 2)
                    b = (b << 2) | v
                xorspr.append(b)

# ---------------------------------------------------------------- page aligned tables
align(256)
label("RRH")          # ring row high byte for world quarter-row y
db([0xC0 + ((y % 21) >> 1) for y in range(256)])
label("RRL")          # ring row low byte base (0 / 128)
db([((y % 21) & 1) * 128 for y in range(256)])
label("MOD21")
db([y % 21 for y in range(256)])
label("NOISE")
rnd = random.Random(1988)
db([rnd.randrange(256) for _ in range(256)])
out.append("RRH_PAGE EQU RRH/256")
out.append("MOD21_PAGE EQU MOD21/256")
out.append("        ASSERT RRL == RRH+256")

label("MAPROWS")
for r in range(42):
    out.append(f"        dw ${0xB1BC + r * 38:04X}")
label("TILEPTR")
for t in range(NT):
    out.append(f"        dw TILES+{t * 48}")
label("TILES")
for t in range(NT):
    db(tiles[t])
label("VARLIST")
db(VAR + [0xFF])
SPLIT1=len(out)
label("VARBASE")
for t in VAR:
    db(tiles[t])
SPLIT2=len(out)
label("XORSPR")
db(xorspr)

SPLIT3=len(out)
# ---------------------------------------------------------------- 5x7 font for SG4 text
F57 = {
 'A': [".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#"],
 'B': ["####.", "#...#", "#...#", "####.", "#...#", "#...#", "####."],
 'C': [".###.", "#...#", "#....", "#....", "#....", "#...#", ".###."],
 'D': ["####.", "#...#", "#...#", "#...#", "#...#", "#...#", "####."],
 'E': ["#####", "#....", "#....", "####.", "#....", "#....", "#####"],
 'F': ["#####", "#....", "#....", "####.", "#....", "#....", "#...."],
 'G': [".###.", "#...#", "#....", "#.###", "#...#", "#...#", ".####"],
 'H': ["#...#", "#...#", "#...#", "#####", "#...#", "#...#", "#...#"],
 'I': [".###.", "..#..", "..#..", "..#..", "..#..", "..#..", ".###."],
 'J': ["..###", "...#.", "...#.", "...#.", "...#.", "#..#.", ".##.."],
 'K': ["#...#", "#..#.", "#.#..", "##...", "#.#..", "#..#.", "#...#"],
 'L': ["#....", "#....", "#....", "#....", "#....", "#....", "#####"],
 'M': ["#...#", "##.##", "#.#.#", "#.#.#", "#...#", "#...#", "#...#"],
 'N': ["#...#", "#...#", "##..#", "#.#.#", "#..##", "#...#", "#...#"],
 'O': [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###."],
 'P': ["####.", "#...#", "#...#", "####.", "#....", "#....", "#...."],
 'Q': [".###.", "#...#", "#...#", "#...#", "#.#.#", "#..#.", ".##.#"],
 'R': ["####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#"],
 'S': [".####", "#....", "#....", ".###.", "....#", "....#", "####."],
 'T': ["#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#.."],
 'U': ["#...#", "#...#", "#...#", "#...#", "#...#", "#...#", ".###."],
 'V': ["#...#", "#...#", "#...#", "#...#", "#...#", ".#.#.", "..#.."],
 'W': ["#...#", "#...#", "#...#", "#.#.#", "#.#.#", "#.#.#", ".#.#."],
 'X': ["#...#", "#...#", ".#.#.", "..#..", ".#.#.", "#...#", "#...#"],
 'Y': ["#...#", "#...#", ".#.#.", "..#..", "..#..", "..#..", "..#.."],
 'Z': ["#####", "....#", "...#.", "..#..", ".#...", "#....", "#####"],
 '0': [".###.", "#...#", "#..##", "#.#.#", "##..#", "#...#", ".###."],
 '1': ["..#..", ".##..", "..#..", "..#..", "..#..", "..#..", ".###."],
 '2': [".###.", "#...#", "....#", "...#.", "..#..", ".#...", "#####"],
 '3': ["#####", "...#.", "..#..", "...#.", "....#", "#...#", ".###."],
 '4': ["...#.", "..##.", ".#.#.", "#..#.", "#####", "...#.", "...#."],
 '5': ["#####", "#....", "####.", "....#", "....#", "#...#", ".###."],
 '6': ["..##.", ".#...", "#....", "####.", "#...#", "#...#", ".###."],
 '7': ["#####", "....#", "...#.", "..#..", ".#...", ".#...", ".#..."],
 '8': [".###.", "#...#", "#...#", ".###.", "#...#", "#...#", ".###."],
 '9': [".###.", "#...#", "#...#", ".####", "....#", "...#.", ".##.."],
 ' ': [".....", ".....", ".....", ".....", ".....", ".....", "....."],
 '!': ["..#..", "..#..", "..#..", "..#..", "..#..", ".....", "..#.."],
 '-': [".....", ".....", ".....", "#####", ".....", ".....", "....."],
 '.': [".....", ".....", ".....", ".....", ".....", ".##..", ".##.."],
}
label("FONT57")      # 7 bytes per char, ASCII 32..90 (missing -> blank), bit4 = leftmost
fb = []
for c in range(32, 91):
    g = F57.get(chr(c), F57[' '])
    for r in g:
        v = 0
        for k, ch in enumerate(r):
            if ch == '#': v |= 1 << (4 - k)
        fb.append(v)
db(fb)

SPLIT4=len(out)
# ---------------------------------------------------------------- jingles
NAMES = {'C': 0, 'C#': 1, 'D': 2, 'D#': 3, 'E': 4, 'F': 5, 'F#': 6, 'G': 7, 'G#': 8, 'A': 9, 'A#': 10, 'B': 11}
def note(n):
    if n in ('-', 'r'): return 0x29
    name, octv = n[:-1], int(n[-1])
    semi = (octv * 12 + NAMES[name]) - (3 * 12 + 2)      # 0 = D3
    assert -12 <= semi <= 38, n
    return semi & 0xFF
def song(lbl, seq):
    label(lbl)
    bs = []
    for tok in seq.split():
        if '*' in tok:
            n, k = tok.split('*'); bs += [note(n)] * int(k)
        else:
            bs.append(note(tok))
    db(bs + [0x3F])
    return len(bs)

a = song("J_START1", "D4 F#4 A4 D5 F#5 A5*2 r")
b = song("J_START2", "D3 D3 F#3 A3 D4 D4*2 r")
a = song("J_OVER1",  "A4*2 G4*2 F4*2 E4*2 D4*3 C#4 D4*4 r")
b = song("J_OVER2",  "D3*2 C3*2 A#2*2 A2*2 A#2*3 A2 D3*4 r")
a = song("J_HI1",    "G4 G4 G4 C5*2 r E5 r G5*2 E5 G5*4 r")
b = song("J_HI2",    "C3 C3 C3 E3*2 r G3 r C4*2 G3 C4*4 r")
a = song("J_DONE1",  "C5 E5 G5 C6*2 B5 G5 A5*2 F5 A5 C6*2 r G5 E5 G5 C6*4 D6*2 E6*6 r")
b = song("J_DONE2",  "C3 C3 E3 G3*2 G3 E3 F3*2 F3 A3 F3*2 r E3 C3 E3 G3*4 G3*2 C4*6 r")

part1 = out[:SPLIT1] + out[SPLIT2:SPLIT3] + out[SPLIT4:]
part2 = out[SPLIT1:SPLIT2] + out[SPLIT3:SPLIT4]
with open('/home/claude/repton2/src/gen_data.asm', 'w') as f:
    f.write("; generated by art/gen_data.py - do not edit\n" + "\n".join(part1) + "\n")
with open('/home/claude/repton2/src/gen_data2.asm', 'w') as f:
    f.write("; generated by art/gen_data.py - do not edit\n" + "\n".join(part2) + "\n")
print("ok", len(out))
