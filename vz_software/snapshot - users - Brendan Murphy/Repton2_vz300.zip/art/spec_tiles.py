# Extract Spectrum tiles as logical colour grids (32x32), save as JSON
import json
m=open('/home/claude/repton2/orig/load_end.snap','rb').read()
# fixed slot table relative FF3B: slots 0-4 level palette, others fixed
fixed={5:0x31,6:0x04,7:0x06,8:0x07,9:0x46,10:0x47,0x47:0x02,0x48:0x12,0x49:0x1A}
names={0:'K',1:'B',2:'R',3:'M',4:'G',5:'C',6:'Y',7:'W'}
def colour(slot,bit):
    if slot<=4:
        if bit: return 'L'
        return ['K','B','R','M','Y'][slot]
    a=fixed.get(slot)
    if a is None: return '?'
    c = a&7 if bit else (a>>3)&7
    return names[c]
tiles=[]
for t in range(0x3B):
    g=0x8EEE+t*128; at=0xAC6E+t*16
    grid=[]
    for y in range(32):
        row=''
        for x in range(32):
            b=m[g+y*4+x//8]>>(7-x%8)&1
            slot=m[at+(y//8)*4+x//8]
            row+=colour(slot,b)
        grid.append(row)
    tiles.append(grid)
json.dump(tiles,open('spec_tiles.json','w'))
from collections import Counter
for t,g in enumerate(tiles):
    c=Counter(''.join(g)); print('%02X'%t, dict(c))
