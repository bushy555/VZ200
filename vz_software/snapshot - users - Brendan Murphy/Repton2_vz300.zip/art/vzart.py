# Hand-refined VZ300 tile artwork for Repton 2 (16x12 pixels, CG2 colours)
#   '.' = blue (background)   'g' = green   'y' = yellow   'r' = red
# Level-variant tiles (walls/earth) are drawn in the base (green) scheme; at level
# start the port recolours them (green<->yellow or green<->red) per the level's colour.

def brick_base():
    A = "ggggggg.ggggggg."
    B = "ggg.ggggggg.gggg"
    M = "................"
    return [A, A, M, B, B, M, A, A, M, B, B, M]

def edges(rows, top=False, bot=False, left=False, right=False, rtl=False, rtr=False, rbl=False, rbr=False):
    r = [list(x) for x in rows]
    if top:
        r[0] = list("g" * 16)
    if bot:
        r[11] = list("g" * 16)
    if left:
        for v in range(12): r[v][0] = 'g'
    if right:
        for v in range(12): r[v][15] = 'g'
    def cut(v, u): r[v][u] = '.'
    if rtl: cut(0, 0); cut(0, 1); cut(1, 0)
    if rtr: cut(0, 15); cut(0, 14); cut(1, 15)
    if rbl: cut(11, 0); cut(11, 1); cut(10, 0)
    if rbr: cut(11, 15); cut(11, 14); cut(10, 15)
    return ["".join(x) for x in r]

def smooth_base():
    rows = []
    for v in range(12):
        s = ""
        for u in range(16):
            dot = (v % 3 == 1) and ((u + (2 if (v // 3) % 2 else 0)) % 4 == 1)
            s += 'y' if dot else 'g'
        rows.append(s)
    return rows

def earth(seed):
    # sparse speckle of short dashes (level colour) on background
    import random
    rnd = random.Random(seed)
    g = [['.'] * 16 for _ in range(12)]
    for v in range(12):
        u = rnd.randrange(0, 3)
        while u < 16:
            ln = rnd.choice([1, 1, 2, 2])
            for k in range(ln):
                if u + k < 16: g[v][u + k] = 'g'
            u += ln + rnd.choice([3, 4, 5, 6])
    return ["".join(x) for x in g]

T = {}
T[0x00] = ["." * 16] * 12
T[0x01] = [  # rock: red boulder with a yellow highlight crescent
    "....rrrrrrrr....",
    "..rryyyrrrrrrr..",
    ".ryyyrrrrrrrr.r.",
    ".ryyrrrrr.rrrr..",
    "ryyrrrrrrr.rrr.r",
    "ryrrrr.rrrrrrrrr",
    "rrrrrrr.rrrrr.rr",
    "rr.rrrrrrrrrr.rr",
    ".rr.rrrrr.rrrrr.",
    ".rrrrrrrrr.rr.r.",
    "..rrr.rrrrrrrr..",
    "....rrrrrrrr....",
]
T[0x02] = [  # egg
    "......yyyy......",
    "....yyyyyyyy....",
    "...yyyyyyyyyy...",
    "..yyyyyyyyyyyy..",
    "..yyyyyyyyyyyy..",
    ".yyyyyyyyyyyyyy.",
    ".yyyyyyyyyyyyyy.",
    ".yyyyyyyyyyyyyy.",
    ".yyyyyyyyyyyygy.",
    "..yyyyyyyyyygy..",
    "...yyyyyyyggy...",
    ".....yyyyyy.....",
]
T[0x03] = [  # skull / face (deadly)
    "....yyyyyyyy....",
    "..yyyyyyyyyyyy..",
    ".yyyyyyyyyyyyyy.",
    "yyy..yyyyyy..yyy",
    "yy.rr.yyyy.rr.yy",
    "yyy..yyyyyy..yyy",
    "yyyyyyy..yyyyyyy",
    "yy.yyyyyyyyyy.yy",
    "yyy.y.y.y.y.yyy.",
    ".yyy.y.y.y.yyy..",
    "..yyyyyyyyyyyy..",
    "....yyyyyyyy....",
]
T[0x08] = [  # diamond
    ".......yy.......",
    ".....yyggyy.....",
    "....yygyygyy....",
    "...ygyyggyygy...",
    "..yyyggyyggyyy..",
    ".ygyyyyggyyyygy.",
    ".ygyyyyggyyyygy.",
    "..yyyggyyggyyy..",
    "...ygyyggyygy...",
    "....yygyygyy....",
    ".....yyggyy.....",
    ".......yy.......",
]
T[0x09] = [  # key
    "................",
    "................",
    "................",
    "..........yyyy..",
    ".........yy..yy.",
    ".yyyyyyyyy....y.",
    ".yyyyyyyyy....y.",
    ".y.y.y...yy..yy.",
    ".y.y......yyyy..",
    "................",
    "................",
    "................",
]
T[0x0A] = [  # earth (sparse pebbles in the level colour)
    "................",
    "..gg.......g....",
    "......g......gg.",
    "...........g....",
    ".g....gg........",
    "..........g..g..",
    "....g...........",
    "gg.......gg.....",
    "............g...",
    "...gg...g......g",
    "................",
    ".......g...gg...",
]
T[0x0B] = [
    "....g......gg...",
    "................",
    ".gg......g....g.",
    "......g.........",
    "...........gg...",
    "..g..g..........",
    "........g....g..",
    "................",
    ".g....gg........",
    "...........g..g.",
    "...g............",
    "........gg......",
]
T[0x0C] = [
    "..........g.....",
    ".g...gg.........",
    "............gg..",
    "......g.........",
    "..gg........g...",
    "................",
    ".......gg.....g.",
    "g...............",
    ".....g....g.....",
    "..g........gg...",
    "........g.......",
    ".gg..........g..",
]
T[0x0D] = [  # transporter
    "yyyyyyyyyyyyyyyy",
    "yy............yy",
    "yy.yyyyyyyyyy.yy",
    "yy.y........y.yy",
    "yy.y.yyyyyy.y.yy",
    "yy.y.y.gg.y.y.yy",
    "yy.y.y.gg.y.y.yy",
    "yy.y.yyyyyy.y.yy",
    "yy.y........y.yy",
    "yy.yyyyyyyyyy.yy",
    "yy............yy",
    "yyyyyyyyyyyyyyyy",
]
T[0x0E] = ["." * 16] * 12   # puzzle piece: generated at run time from the 8x8 piece bitmap
T[0x0F] = [  # restart point (diamond outline)
    ".......yy.......",
    ".....yy..yy.....",
    "....y......y....",
    "...y...gg...y...",
    "..y...g..g...y..",
    ".y...g....g...y.",
    ".y...g....g...y.",
    "..y...g..g...y..",
    "...y...gg...y...",
    "....y......y....",
    ".....yy..yy.....",
    ".......yy.......",
]
T[0x10] = [  # final goal piece
    "..yyyyyyyyyyyy..",
    ".yyyyyyyyyyyyyy.",
    "yyy..yy..yy..yyy",
    "yy.yy..rr..yy.yy",
    "yy.y.rr..rr.y.yy",
    "yyy.r.rggr.r.yyy",
    "yyy.r.rggr.r.yyy",
    "yy.y.rr..rr.y.yy",
    "yy.yy..rr..yy.yy",
    "yyy..yy..yy..yyy",
    ".yyyyyyyyyyyyyy.",
    "..yyyyyyyyyyyy..",
]
T[0x11] = [  # safe
    "yyyyyyyyyyyyyyyy",
    "y.y.y.y.y.y.y.yy",
    "yy.y.y.y.y.y.y.y",
    "y.y.y.y.y.y.y.yy",
    "yy.y.y.yyyyy.y.y",
    "y.y.y.yy...yy.yy",
    "yy.y.y.y.r.yy.yy",
    "y.y.y.yy...yy.yy",
    "yy.y.y.yyyyy.y.y",
    "y.y.y.y.y.y.y.yy",
    "yy.y.y.y.y.y.y.y",
    "yyyyyyyyyyyyyyyy",
]
T[0x12] = [  # cage
    "yyyyyyyyyyyyyyyy",
    "y.y.y.y.y.y.y.yy",
    "y.y.y.y.y.y.y.yy",
    "y.y.y.y.y.y.y.yy",
    "y.y.y.y.y.y.y.yy",
    "y.y.y.y.y.yyyyyy",
    "y.y.y.y.y.yy.ryy",
    "y.y.y.y.y.yyyyyy",
    "y.y.y.y.y.y.y.yy",
    "y.y.y.y.y.y.y.yy",
    "y.y.y.y.y.y.y.yy",
    "yyyyyyyyyyyyyyyy",
]
# brick walls
b = brick_base()
T[0x13] = b
T[0x04] = edges(b, top=True, left=True, rtl=True)
T[0x05] = edges(b, top=True, right=True, rtr=True)
T[0x14] = edges(b, bot=True, left=True, rbl=True)
T[0x15] = edges(b, bot=True, right=True, rbr=True)
T[0x16] = edges(b, top=True)
T[0x17] = edges(b, bot=True)
T[0x18] = edges(b, left=True)
T[0x19] = edges(b, right=True)
s = smooth_base()
T[0x1A] = s
T[0x06] = edges(s, rtl=True)
T[0x07] = edges(s, rtr=True)
T[0x1B] = edges(s, rbl=True)
T[0x1C] = edges(s, rbr=True)
T[0x1D] = [  # window block
    ".gggggg..gggggg.",
    "gg....gggg....gg",
    "g.y.y..gg.y.y..g",
    "g..y.y.gg..y.y.g",
    "gg....gggg....gg",
    ".gggggg..gggggg.",
    ".gggggg..gggggg.",
    "gg....gggg....gg",
    "g.y.y..gg.y.y..g",
    "g..y.y.gg..y.y.g",
    "gg....gggg....gg",
    ".gggggg..gggggg.",
]
T[0x1E] = ["y.y.y.y.y.y.y.y.", ".y.y.y.y.y.y.y.y", "................"] + brick_base()[3:]
# monsters
T[0x1F] = [
    "gg..g......g..gg",
    "..g..gggggg..g..",
    "....gggggggg....",
    "...gg.rggr.gg...",
    "...gggggggggg...",
    "gg...gg..gg...gg",
    ".gg.gggggggg.gg.",
    "..gggg.gg.gggg..",
    "....gggggggg....",
    "...gg.gggg.gg...",
    "..gg...gg...gg..",
    "ggg..........ggg",
]
T[0x20] = [
    "gg..g......g....",
    "..g..gggggg..g..",
    "....gggggggg..gg",
    "...gg.rggr.gg...",
    "gg.gggggggggg...",
    "..g..gg..gg...gg",
    "...ggggggggggg..",
    "....g.gg.gggg...",
    "....gggggggg....",
    "...gg.gggg.ggg..",
    "..gg........ggg.",
    "ggg...........gg",
]
T[0x21] = [
    "....g......g..gg",
    "..g..gggggg..g..",
    "gg..gggggggg....",
    "...gg.rggr.gg...",
    "...gggggggggg.gg",
    "gg...gg..gg..g..",
    "..ggggggggggg...",
    "...gggg.gg.g....",
    "....gggggggg....",
    "..ggg.gggg.gg...",
    ".ggg........gg..",
    "gg...........ggg",
]
T[0x22] = [  # cracked egg
    "......yyyy......",
    "....yyy.yyyy....",
    "...yy.yyy.yyy...",
    "..yyyy.y.yyyyy..",
    "..y.yyy.yyy.yy..",
    ".yyy.y.yyy.y.yy.",
    ".yy.yyy.y.yyy.y.",
    ".y.yyy.yyy.yyyy.",
    ".yyy.y.y.yyy.yy.",
    "..yyyy.yyy.yyy..",
    "...yy.yy.yy.y...",
    ".....yyyyyy.....",
]

# ---- Repton frames ('l' = legs colour, chosen at build time) ----
def body_front(head):
    return head + [
        "...yyyyyyyyyy...",
        "..yyyyyyyyyyyy..",
        "..yy.yyyyyy.yy..",
        "..yy.llllll.yy..",
        ".....llllll.....",
        "....lll..lll....",
        "...lll....lll...",
        "...ll......ll...",
        ".llll......llll.",
    ]
T[0x23] = body_front(["....gggggggg....", "....g..gg..g....", ".....gggggg....."])
T[0x24] = body_front(["...gggggggg.....", "...g..g..gg.....", "....gggggg......"])
T[0x25] = body_front([".....gggggggg...", ".....gg..g..g...", "......gggggg...."])
T[0x26] = [
    "....gggggggg..yy",
    "....g..gg..g.yy.",
    ".....gggggg.yy..",
    "...yyyyyyyyyy...",
    "..yyyyyyyyyy....",
    "..yy.yyyyyy.....",
    "..yy.lllllll....",
    ".....lllllllll..",
    "....lll.....lll.",
    "...lll..........",
    "...ll...........",
    ".llll...........",
]
T[0x27] = [x[::-1] for x in T[0x26]]
T[0x28] = [
    "....gggggg......",
    "...g.ggggg......",
    "....ggggg.......",
    ".....yyyy.......",
    "yyyyyyyyy.......",
    ".....yyyy.......",
    ".....lllll......",
    "....llllll......",
    "...lll..lll.....",
    "..lll....lll....",
    ".lll......lll...",
    "lll.......llll..",
]
T[0x29] = [
    "....gggggg......",
    "...g.ggggg......",
    "....ggggg.......",
    ".....yyyy.......",
    "....yyyyyy......",
    "....yyyyyy......",
    ".....llll.......",
    ".....lllll......",
    "....lll.ll......",
    "....ll..lll.....",
    "...lll...ll.....",
    "..llll..llll....",
]
T[0x2A] = [
    "....gggggg......",
    "...g.ggggg......",
    "....ggggg.......",
    ".....yyyy.......",
    ".....yyyyy......",
    ".....yyyyy......",
    ".....llll.......",
    ".....llll.......",
    ".....llll.......",
    ".....lll........",
    ".....lll........",
    "....lllll.......",
]
T[0x2B] = [
    "....gggggg......",
    "...g.ggggg......",
    "....ggggg.......",
    ".....yyyy.......",
    ".....yyyyyyyy...",
    ".....yyyy.......",
    ".....lllll......",
    "....llllll......",
    "...lll..llll....",
    "..lll.....lll...",
    "..ll.......ll...",
    "llll.......llll.",
]
for a, b in [(0x28, 0x2C), (0x29, 0x2D), (0x2A, 0x2E), (0x2B, 0x2F)]:
    T[b] = [x[::-1] for x in T[a]]

# ---- spirits: XOR sprites, only the central 8x6 (cols 4-11, rows 3-8) is drawn ----
def centre(rows8):
    out = ["." * 16] * 3 + ["...." + r + "...." for r in rows8] + ["." * 16] * 3
    return out
T[0x30] = centre([".yyyyyy.", "yyy..yyy", "yy.yy.yy", "yy.yy.yy", "yyy..yyy", ".yyyyyy."])
T[0x31] = centre(["..y..y..", ".yyyyyy.", "yyy..yyy", "yyy..yyy", ".yyyyyy.", "..y..y.."])
T[0x32] = centre(["...yy...", "..yyyy..", ".yy..yy.", ".yy..yy.", "..yyyy..", "...yy..."])
T[0x33] = centre(["........", "..y..y..", "...yy...", "...yy...", "..y..y..", "........"])
T[0x34] = centre(["........", "........", "...yy...", "...yy...", "........", "........"])

# ---- explosion / death frames 35..3A ----
def burst(rx, ry, seed, dens):
    import random
    rnd = random.Random(seed)
    g = []
    for v in range(12):
        s = ""
        for u in range(16):
            dx = (u - 7.5) / rx; dy = (v - 5.5) / ry
            d = dx * dx + dy * dy
            if d <= 1.0 and rnd.random() < dens + (0.35 if d < 0.3 else 0):
                s += 'r' if rnd.random() < 0.18 else 'y'
            else:
                s += '.'
        g.append(s)
    return g
T[0x35] = burst(8.2, 6.2, 1, 0.62)
T[0x36] = burst(7.0, 5.3, 2, 0.6)
T[0x37] = burst(5.8, 4.4, 3, 0.62)
T[0x38] = burst(4.4, 3.4, 4, 0.66)
T[0x39] = burst(3.0, 2.4, 5, 0.7)
T[0x3A] = burst(1.7, 1.4, 6, 0.9)
