// Minimal 48K Spectrum harness with tape pulse playback, key scripting, snapshots.
#include "z80.h"
#include <stdlib.h>
#include <string.h>
uint8_t mem[65536];
typedef struct {uint32_t n; uint8_t l;} seg;
seg *segs; long nseg, segi; uint64_t seg_end; int ear; int tape_on; uint64_t tape_t0;
uint8_t keyrows[8]; // active-low bits per row
uint64_t T=0; z80 cpu; int watchpc=-1; long watchn=0; long curframe=0; uint8_t border;
uint8_t cov[65536]; int covon=0; // bit0 exec,1 read,2 write
int contend=1; uint64_t fstart=0;
static const int cdel[8]={6,5,4,3,2,1,0,0};
static inline void cont(uint16_t a){ if(contend && (a&0xC000)==0x4000){ long t=(long)(cpu.cyc-fstart)-14335; if(t>=0 && t<192*224 && (t%224)<128) cpu.cyc+=cdel[t&7]; } }
static uint8_t rb(void*u,uint16_t a){ if(covon) cov[a]|=2; cont(a); return mem[a];}
static void wb(void*u,uint16_t a,uint8_t v){ if(covon) cov[a]|=4; cont(a); if(a>=0x4000) mem[a]=v; }
static void tape_update(){
  if(!tape_on) return;
  uint64_t t=cpu.cyc;
  while(segi<nseg && t>=seg_end){ segi++; if(segi<nseg){ ear=segs[segi].l; seg_end+=segs[segi].n; } }
}
static uint8_t pin(z80*z,uint16_t p){
  if(!(p&1)){ uint8_t v=0x1f; uint8_t hi=p>>8;
    for(int r=0;r<8;r++) if(!(hi&(1<<r))) v&=keyrows[r];
    tape_update(); if(ear) v|=0x40; return v|0xa0; }
  if((p&0xff)==0x1f) return 0;
  return 0xff;
}
static void pout(z80*z,uint16_t p,uint8_t v){ if(!(p&1)) border=v&7; }
// key names: row,bit
struct {const char*n;int r,b;} K[]={{"CS",0,0},{"Z",0,1},{"X",0,2},{"C",0,3},{"V",0,4},{"A",1,0},{"S",1,1},{"D",1,2},{"F",1,3},{"G",1,4},
{"Q",2,0},{"W",2,1},{"E",2,2},{"R",2,3},{"T",2,4},{"1",3,0},{"2",3,1},{"3",3,2},{"4",3,3},{"5",3,4},{"0",4,0},{"9",4,1},{"8",4,2},{"7",4,3},{"6",4,4},
{"P",5,0},{"O",5,1},{"I",5,2},{"U",5,3},{"Y",5,4},{"EN",6,0},{"L",6,1},{"K",6,2},{"J",6,3},{"H",6,4},{"SP",7,0},{"SS",7,1},{"M",7,2},{"N",7,3},{"B",7,4},{0,0,0}};
static void setkeys(const char*s){ memset(keyrows,0x1f,8); char b[256]; strncpy(b,s,255); b[255]=0;
  for(char*t=strtok(b,"+");t;t=strtok(0,"+")) for(int i=0;K[i].n;i++) if(!strcmp(K[i].n,t)) keyrows[K[i].r]&=~(1<<K[i].b); }
static void dumpscr(const char*fn){
  static const int pal[16][3]={{0,0,0},{0,0,205},{205,0,0},{205,0,205},{0,205,0},{0,205,205},{205,205,0},{205,205,205},{0,0,0},{0,0,255},{255,0,0},{255,0,255},{0,255,0},{0,255,255},{255,255,0},{255,255,255}};
  FILE*f=fopen(fn,"wb"); fprintf(f,"P6 256 192 255\n");
  for(int y=0;y<192;y++) for(int x=0;x<256;x++){ int a=0x4000|((y&0xc0)<<5)|((y&7)<<8)|((y&0x38)<<2)|(x>>3);
    int at=mem[0x5800+(y>>3)*32+(x>>3)]; int bit=(mem[a]>>(7-(x&7)))&1; int br=(at&0x40)?8:0;
    int c=bit?((at&7)|br):(((at>>3)&7)|br); fputc(pal[c][0],f);fputc(pal[c][1],f);fputc(pal[c][2],f);} fclose(f);}
static void savesnap(const char*fn){ FILE*f=fopen(fn,"wb"); fwrite(mem,1,65536,f); fwrite(&cpu,sizeof cpu,1,f); fwrite(&border,1,1,f); fclose(f);}
static int loadsnap(const char*fn){ FILE*f=fopen(fn,"rb"); if(!f) return 0; uint8_t rom[16384]; memcpy(rom,mem,16384); fread(mem,1,65536,f); memcpy(mem,rom,16384);
  z80 c; fread(&c,sizeof c,1,f); fread(&border,1,1,f); fclose(f); c.read_byte=cpu.read_byte; c.write_byte=cpu.write_byte; c.port_in=cpu.port_in; c.port_out=cpu.port_out; c.cyc=0; cpu=c; return 1;}
// script: lines "frame cmd arg": key <combo>|none, tape, scr <file>, snap <file>, quit, pcprof <file>
char kseq[20000][32]; int nks=0, kspos=0; long kspc=-1; long ksdump=-1; char ksdumpfn[256];
int main(int argc,char**argv){
  if(argc<3){fprintf(stderr,"zxemu rom script [tape.seg] [snapin]\n");return 1;}
  FILE*f=fopen(argv[1],"rb"); fread(mem,1,16384,f); fclose(f);
  z80_init(&cpu); cpu.read_byte=rb; cpu.write_byte=wb; cpu.port_in=pin; cpu.port_out=pout;
  memset(keyrows,0x1f,8);
  if(argc>3 && strcmp(argv[3],"-")){ f=fopen(argv[3],"rb"); fseek(f,0,2); long sz=ftell(f); fseek(f,0,0); nseg=sz/5; segs=malloc(nseg*sizeof(seg));
    for(long i=0;i<nseg;i++){ uint32_t n; uint8_t l; fread(&n,4,1,f); fread(&l,1,1,f); segs[i].n=n; segs[i].l=l;} fclose(f);}
  if(argc>4) loadsnap(argv[4]);
  static uint32_t prof[65536]; int profon=0;
  FILE*sc=fopen(argv[2],"r"); long nextf=-1; char cmd[64],arg[256]; 
  if(fscanf(sc,"%ld %63s %255[^\n]",&nextf,cmd,arg)<2) nextf=-1;
  for(long frame=0;;frame++){
    while(nextf!=-1 && nextf<=frame){
      if(!strcmp(cmd,"key")) setkeys(arg);
      else if(!strcmp(cmd,"tape")){ tape_on=1; segi=0; ear=segs[0].l; seg_end=cpu.cyc+segs[0].n; }
      else if(!strcmp(cmd,"scr")) dumpscr(arg);
      else if(!strcmp(cmd,"snap")) savesnap(arg);
      else if(!strcmp(cmd,"prof")){ profon=1; memset(prof,0,sizeof prof);}
      else if(!strcmp(cmd,"profdump")){ FILE*o=fopen(arg,"wb"); fwrite(prof,4,65536,o); fclose(o); profon=0;}
      else if(!strcmp(cmd,"regs")){ printf("f%ld PC=%04x SP=%04x IM%d IFF%d I=%02x tapeseg=%ld/%ld\n",frame,cpu.pc,cpu.sp,cpu.interrupt_mode,cpu.iff1,cpu.i,segi,nseg); fflush(stdout);}
      else if(!strcmp(cmd,"quit")) return 0;
      else if(!strcmp(cmd,"keyseq")){ char fnk[200]; unsigned pc; sscanf(arg,"%x %199s %ld %255s",&pc,fnk,&ksdump,ksdumpfn); kspc=pc; FILE*kf=fopen(fnk,"r"); nks=0; while(nks<20000 && fgets(kseq[nks],32,kf)){ kseq[nks][strcspn(kseq[nks],"\n")]=0; nks++; } fclose(kf); kspos=0; }
      else if(!strcmp(cmd,"cov")) covon=1;
      else if(!strcmp(cmd,"nocontend")) contend=0;
      else if(!strcmp(cmd,"watch")){ unsigned a; long n; sscanf(arg,"%x %ld",&a,&n); watchpc=a; watchn=n; }
      else if(!strcmp(cmd,"covdump")){ FILE*o=fopen(arg,"wb"); fwrite(cov,1,65536,o); fclose(o);}
      else if(!strcmp(cmd,"poke")){ unsigned a,v; sscanf(arg,"%x %x",&a,&v); mem[a]=v; }
      if(fscanf(sc,"%ld %63s %255[^\n]",&nextf,cmd,arg)<2) nextf=-1;
    }
    curframe=frame; fstart=frame*69888ULL; uint64_t end=(frame+1)*69888ULL + 0; 
    if(cpu.cyc < frame*69888ULL) cpu.cyc = frame*69888ULL; // after snapshot load, align
    z80_gen_int(&cpu,0xff);
    while(cpu.cyc<end){ if(cpu.pc==kspc){ if(kspos<nks){ setkeys(kseq[kspos]); } kspos++; if(kspos==ksdump){ savesnap(ksdumpfn); printf("dumped at iteration %d frame %ld\n",kspos,frame); fflush(stdout); return 0; } } if(profon) prof[cpu.pc]++; if(covon) cov[cpu.pc]|=1; if(cpu.pc==watchpc && watchn>0){ printf("hit %04x frame %ld cyc %lu\n",watchpc,curframe,(unsigned long)(cpu.cyc-curframe*69888ULL)); watchn--; } z80_step(&cpu); if(cpu.int_pending && cpu.cyc>frame*69888ULL+32) cpu.int_pending=0; }
  }
}
