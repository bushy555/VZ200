// VZ300 + BennVenn SD loader (128K) emulator harness for testing.
#include "z80.h"
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <stdint.h>

#define FRAME_T 70938
#define LINE_T 227
#define FS_LOW_T (57*LINE_T)

z80 cpu;
uint8_t rom[0x4000];
uint8_t ram[0x10000];      // internal: 0x7000-0xB7FF used (video 7000-77FF)
uint8_t bv[0x20000];       // BennVenn 128K
int dos_ram=0, dos_page=0, exp_bank=0, vz300=1;
uint8_t latch=0; int keyrows[8]; uint8_t joy[4]={0xff,0xff,0xff,0xff};
long frame=0; uint64_t fstart=0;
uint16_t hist[64]; int hpos=0; int trapped=0; int traplo=1;
uint8_t cov[65536]; int covon=0; long watchpc=-1, watchn=0; static uint32_t prof[65536]; int profon=0;
// audio
FILE *wav=0; long wavsamples=0; double wavacc=0; int spk=0; uint64_t lastT=0;
static void audio_adv(uint64_t t){
  if(!wav) { lastT=t; return; }
  double samples_per_T=44100.0/3546894.0;
  while(lastT<t){ uint64_t step = t-lastT; if(step>80) step=80; wavacc+=step*samples_per_T; lastT+=step;
    while(wavacc>=1.0){ int16_t s= spk? 8000 : -8000; fwrite(&s,2,1,wav); wavsamples++; wavacc-=1.0; } }
}
static uint8_t* expptr(uint16_t a){ return &bv[0x10000 + exp_bank*0x8000 + (a&0x7fff)]; }
static uint8_t rb(void*u,uint16_t a){
  if(covon) cov[a]|=2;
  if(a<0x4000) return rom[a];
  if(a<0x6800){ if(!dos_ram) return 0xff; return bv[dos_page*0x8000 + (a-0x4000)]; }
  if(a<0x7000){ uint8_t r=0x3f; for(int i=0;i<8;i++) if(!(a&(1<<i))) r&=keyrows[i];
     uint64_t t=cpu.cyc-fstart; if(t>=FS_LOW_T) r|=0x80; r|=0x40; return r; }
  if(a<0x9000) return ram[a];
  if(a<0xB800){ if(vz300) return ram[a]; return *expptr(a); }
  return *expptr(a);
}
static void wb(void*u,uint16_t a,uint8_t v){
  if(covon) cov[a]|=4;
  if(a<0x4000) return;
  if(a<0x6800){ bv[dos_page*0x8000 + (a-0x4000)]=v; return; } // MAME: rom view writes go to bank too
  if(a<0x7000){ int ns=((v>>5)&1)^(v&1); audio_adv(cpu.cyc); spk=(v&1); latch=v; return; }
  if(a<0x9000){ ram[a]=v; return; }
  if(a<0xB800){ if(vz300) ram[a]=v; else *expptr(a)=v; return; }
  *expptr(a)=v;
}
static uint8_t pin(z80*z,uint16_t p){
  uint8_t lo=p&0xff;
  if(lo>=0x20 && lo<=0x2f){ uint8_t d=0xff; int o=lo-0x20;
    if(!(o&1)) d&=joy[0]; if(!(o&2)) d&=joy[1]; if(!(o&4)) d&=joy[2]; if(!(o&8)) d&=joy[3]; return d; }
  return 0xff;
}
static void pout(z80*z,uint16_t p,uint8_t v){
  uint8_t lo=p&0xff;
  if(lo==0x37){ dos_ram=v&1; dos_page=(v>>1)&1; exp_bank=(v>>2)&1; }
  if(lo==0x3a){ vz300=v&1; }
}
// keyboard: rows X0..X7, bits per MAME vtech1
struct {const char*n;int r,b;} K[]={
{"R",0,5},{"Q",0,4},{"E",0,3},{"W",0,1},{"T",0,0},
{"F",1,5},{"A",1,4},{"D",1,3},{"CTRL",1,2},{"S",1,1},{"G",1,0},
{"V",2,5},{"Z",2,4},{"C",2,3},{"SHIFT",2,2},{"X",2,1},{"B",2,0},
{"4",3,5},{"1",3,4},{"3",3,3},{"2",3,1},{"5",3,0},
{"M",4,5},{"SP",4,4},{",",4,3},{".",4,1},{"N",4,0},
{"7",5,5},{"0",5,4},{"8",5,3},{"-",5,2},{"9",5,1},{"6",5,0},
{"U",6,5},{"P",6,4},{"I",6,3},{"EN",6,2},{"O",6,1},{"Y",6,0},
{"J",7,5},{";",7,4},{"K",7,3},{":",7,2},{"L",7,1},{"H",7,0},{0,0,0}};
static void setkeys(const char*s){ for(int i=0;i<8;i++) keyrows[i]=0x3f; char b[256]; strncpy(b,s,255); b[255]=0;
  for(char*t=strtok(b,"+");t;t=strtok(0,"+")) for(int i=0;K[i].n;i++) if(!strcmp(K[i].n,t)) keyrows[K[i].r]&=~(1<<K[i].b); }
// video
static const int pal[8][3]={{0x30,0xd2,0},{0xc1,0xe5,0},{0x4c,0x3a,0xb4},{0x9a,0x32,0x36},{0xbf,0xc8,0xad},{0x41,0xaf,0x71},{0xc8,0x4e,0xf0},{0xd4,0x7f,0}};
uint8_t font[128*8]; int havefont=0;
static void dumpscr(const char*fn){
  static uint8_t img[192][256][3];
  int css=(latch>>4)&1;
  if(latch&8){ // CG2 128x64
    for(int y=0;y<64;y++) for(int x=0;x<128;x++){ int b=ram[0x7000+y*32+x/4]; int c=(b>>(6-2*(x&3)))&3; c+=css*4;
      for(int dy=0;dy<3;dy++) for(int dx=0;dx<2;dx++){ for(int k=0;k<3;k++) img[y*3+dy][x*2+dx][k]=pal[c][k];} }
  } else {
    for(int r=0;r<16;r++) for(int col=0;col<32;col++){ int ch=ram[0x7000+r*32+col];
      for(int py=0;py<12;py++) for(int px=0;px<8;px++){ int on; int fg[3],bg[3];
        if(ch&0x80){ int q; int c=(ch>>4)&7; int top=py<6, left=px<4; q= top?(left?8:4):(left?2:1); on=(ch&q)!=0;
          for(int k=0;k<3;k++) fg[k]=pal[c][k]; bg[0]=bg[1]=bg[2]=0; bg[0]=0x10;bg[1]=0x10;bg[2]=0x10;
        } else { int c=ch&0x3f; int asc = c<32? c+64 : c; int gy=py-2; on=0;
          if(gy>=0 && gy<8 && havefont) on=(font[asc*8+gy]>>(7-px))&1;
          if(ch&0x40) on=!on;
          if(css){ fg[0]=0xff;fg[1]=0xb7;fg[2]=0; bg[0]=0x6b;bg[1]=0x27;bg[2]=0; } else { fg[0]=0x30;fg[1]=0xd2;fg[2]=0; bg[0]=0;bg[1]=0x7c;bg[2]=0; }
        }
        int*cc= on?fg:bg; for(int k=0;k<3;k++) img[r*12+py][col*8+px][k]=cc[k]; } }
  }
  FILE*f=fopen(fn,"wb"); fprintf(f,"P6 256 192 255\n"); fwrite(img,1,sizeof img,f); fclose(f);
}
static void savesnap(const char*fn){ FILE*f=fopen(fn,"wb"); fwrite(ram,1,65536,f); fwrite(bv,1,sizeof bv,f); fwrite(&cpu,sizeof cpu,1,f);
  int st[5]={dos_ram,dos_page,exp_bank,vz300,latch}; fwrite(st,sizeof st,1,f); fclose(f);}
static void loadsnap(const char*fn){ FILE*f=fopen(fn,"rb"); fread(ram,1,65536,f); fread(bv,1,sizeof bv,f); z80 c; fread(&c,sizeof c,1,f);
  int st[5]; fread(st,sizeof st,1,f); fclose(f); dos_ram=st[0];dos_page=st[1];exp_bank=st[2];vz300=st[3];latch=st[4];
  c.read_byte=cpu.read_byte; c.write_byte=cpu.write_byte; c.port_in=cpu.port_in; c.port_out=cpu.port_out; c.cyc=0; cpu=c; }
static void loadvz(const char*fn){ FILE*f=fopen(fn,"rb"); uint8_t h[24]; fread(h,1,24,f); uint16_t st=h[22]|h[23]<<8; int c,a=st;
  while((c=fgetc(f))!=EOF){ wb(0,a,c); a++; } fclose(f); cpu.pc=st; cpu.sp=0x7AE0; fprintf(stderr,"loaded %s %04x-%04x type %02x (%d bytes)\n",fn,st,a,h[21],a-st); }
char kseq[20000][32]; int nks=0, kspos=0; long kspc=-1; long ksdump=-1; char ksdumpfn[256];
int main(int argc,char**argv){
  if(argc<3){ fprintf(stderr,"vzemu script file.vz|snap\n"); return 1; }
  z80_init(&cpu); cpu.read_byte=rb; cpu.write_byte=wb; cpu.port_in=pin; cpu.port_out=pout;
  for(int i=0;i<8;i++) keyrows[i]=0x3f;
  FILE*ff=fopen("/home/claude/roms/zx/zx/roms/Spectrum48.rom","rb"); if(ff){ uint8_t r[16384]; fread(r,1,16384,ff); fclose(ff); for(int c=32;c<128;c++) memcpy(&font[c*8],&r[0x3D00+(c-32)*8],8); havefont=1; }
  const char*fn=argv[2]; int l=strlen(fn);
  if(l>3 && !strcasecmp(fn+l-3,".vz")) loadvz(fn); else loadsnap(fn);
  FILE*sc=fopen(argv[1],"r"); long nextf=-1; char cmd[64],arg[256];
  if(fscanf(sc,"%ld %63s %255[^\n]",&nextf,cmd,arg)<2) nextf=-1;
  for(frame=0;;frame++){
    while(nextf!=-1 && nextf<=frame){
      if(!strcmp(cmd,"key")) setkeys(arg);
      else if(!strcmp(cmd,"joy")){ int n; unsigned v; sscanf(arg,"%d %x",&n,&v); if(n==1) joy[0]=v; else joy[2]=v; }
      else if(!strcmp(cmd,"joyraw")){ unsigned a,b,c,d; sscanf(arg,"%x %x %x %x",&a,&b,&c,&d); joy[0]=a;joy[1]=b;joy[2]=c;joy[3]=d; }
      else if(!strcmp(cmd,"scr")) dumpscr(arg);
      else if(!strcmp(cmd,"snap")) savesnap(arg);
      else if(!strcmp(cmd,"prof")){ profon=1; memset(prof,0,sizeof prof);}
      else if(!strcmp(cmd,"profdump")){ FILE*o=fopen(arg,"wb"); fwrite(prof,4,65536,o); fclose(o); profon=0;}
      else if(!strcmp(cmd,"cov")) covon=1;
      else if(!strcmp(cmd,"covdump")){ FILE*o=fopen(arg,"wb"); fwrite(cov,1,65536,o); fclose(o);}
      else if(!strcmp(cmd,"watch")){ unsigned a; sscanf(arg,"%x %ld",&a,&watchn); watchpc=a; }
      else if(!strcmp(cmd,"regs")){ printf("f%ld PC=%04x SP=%04x AF=%02x BC=%02x%02x DE=%02x%02x HL=%02x%02x IX=%04x IY=%04x IM%d IFF%d I=%02x bank=%d dos=%d/%d latch=%02x\n",frame,cpu.pc,cpu.sp,cpu.a,cpu.b,cpu.c,cpu.d,cpu.e,cpu.h,cpu.l,cpu.ix,cpu.iy,cpu.interrupt_mode,cpu.iff1,cpu.i,exp_bank,dos_ram,dos_page,latch); fflush(stdout);}
      else if(!strcmp(cmd,"wav")){ if(!strcmp(arg,"stop")){ if(wav){ long n=wavsamples; fseek(wav,0,0);
            uint32_t sz=36+n*2; fwrite("RIFF",1,4,wav); fwrite(&sz,4,1,wav); fwrite("WAVEfmt ",1,8,wav); uint32_t v=16; fwrite(&v,4,1,wav); uint16_t s=1; fwrite(&s,2,1,wav); fwrite(&s,2,1,wav);
            v=44100; fwrite(&v,4,1,wav); v=88200; fwrite(&v,4,1,wav); s=2; fwrite(&s,2,1,wav); s=16; fwrite(&s,2,1,wav); fwrite("data",1,4,wav); v=n*2; fwrite(&v,4,1,wav); fclose(wav); wav=0; } }
          else { wav=fopen(arg,"wb"); char z[44]={0}; fwrite(z,1,44,wav); wavsamples=0; lastT=cpu.cyc; } }
      else if(!strcmp(cmd,"peek")){ unsigned a,n; sscanf(arg,"%x %x",&a,&n); printf("f%ld %04x:",frame,a); for(unsigned i=0;i<n;i++) printf(" %02x",rb(0,a+i)); printf("\n"); fflush(stdout);}
      else if(!strcmp(cmd,"poke")){ unsigned a,v; sscanf(arg,"%x %x",&a,&v); wb(0,a,v); }
      else if(!strcmp(cmd,"quit")) return 0;
      else if(!strcmp(cmd,"keyseq")){ char fnk[200]; unsigned pc; sscanf(arg,"%x %199s %ld %255s",&pc,fnk,&ksdump,ksdumpfn); kspc=pc; FILE*kf=fopen(fnk,"r"); nks=0; while(nks<20000 && fgets(kseq[nks],32,kf)){ kseq[nks][strcspn(kseq[nks],"\n")]=0; nks++; } fclose(kf); kspos=0; }
      if(fscanf(sc,"%ld %63s %255[^\n]",&nextf,cmd,arg)<2) nextf=-1;
    }
    fstart=(uint64_t)frame*FRAME_T; uint64_t end=fstart+FRAME_T;
    if(cpu.cyc<fstart) cpu.cyc=fstart;
    while(cpu.cyc<end){
      if(profon) prof[cpu.pc]++; if(covon) cov[cpu.pc]|=1;
      if(cpu.pc==watchpc && watchn>0){ printf("hit %04lx frame %ld T %lu SP=%04x A=%02x BC=%02x%02x DE=%02x%02x HL=%02x%02x\n",watchpc,frame,(unsigned long)(cpu.cyc-fstart),cpu.sp,cpu.a,cpu.b,cpu.c,cpu.d,cpu.e,cpu.h,cpu.l); watchn--; }
      if(cpu.pc==kspc){ if(kspos<nks){ setkeys(kseq[kspos]); } kspos++; if(kspos==ksdump){ savesnap(ksdumpfn); printf("dumped at iteration %d frame %ld\n",kspos,frame); fflush(stdout); return 0; } }
      hist[hpos++&63]=cpu.pc;
      if(traplo && cpu.pc<0x4000 && !trapped){ trapped=1; printf("TRAP pc=%04x frame %ld SP=%04x; history:",cpu.pc,frame,cpu.sp); for(int k=0;k<64;k++) printf(" %04x",hist[(hpos+k)&63]); printf("\n"); fflush(stdout); }
      cpu.int_pending = (cpu.cyc-fstart) < FS_LOW_T; cpu.int_data=0xff;
      z80_step(&cpu);
    }
    audio_adv(cpu.cyc);
  }
}
