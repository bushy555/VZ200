#!/bin/sh
# usage: vzrun.sh script.txt file.vz   (sorts script by frame number first)
sort -n -k1,1 -s "$1" > "$1.sorted" && timeout 300 /home/claude/tools/vzemu "$1.sorted" "$2"
