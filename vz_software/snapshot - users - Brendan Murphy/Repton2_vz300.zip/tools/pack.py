#!/usr/bin/env python3
"""Package the assembled 64K image into REPTON2.VZ (LZSS segments + loader stub)."""
import subprocess, sys, os
B = '/home/claude/repton2/build'
orig = open(f'{B}/orig64k.bin', 'rb').read()
img = open(f'{B}/vz64k.bin', 'rb').read()

def lz(data):
    out = bytearray(); i = 0; n = len(data)
    head = {}
    def find(i):
        best_len, best_off = 0, 0
        key = bytes(data[i:i + 3])
        for j in reversed(head.get(key, [])[-64:]):
            off = i - j
            if off > 4095: break
            l = 0
            while l < 18 and i + l < n and data[j + l] == data[i + l]: l += 1
            if l > best_len: best_len, best_off = l, off
            if l == 18: break
        return best_len, best_off
    def add(i):
        if i + 3 <= n: head.setdefault(bytes(data[i:i + 3]), []).append(i)
    items = []
    while i < n:
        l, o = find(i)
        if l >= 3:
            l2, _ = find(i + 1) if i + 1 < n else (0, 0)
            if l2 > l + 1:
                items.append(('L', data[i])); add(i); i += 1; continue
            items.append(('M', o, l))
            for k in range(l): add(i + k)
            i += l
        else:
            items.append(('L', data[i])); add(i); i += 1
    items.append(('E',))
    for g in range(0, len(items), 8):
        grp = items[g:g + 8]; flags = 0; body = bytearray()
        for k, it in enumerate(grp):
            if it[0] == 'L': flags |= 1 << k; body.append(it[1])
            elif it[0] == 'M': body += bytes([it[1] & 255, ((it[1] >> 8) << 4) | (it[2] - 3)])
            else: body += b'\x00\x00'
        out.append(flags); out += body
    return bytes(out)

def unlz(c):
    o = bytearray(); i = 0
    while True:
        f = c[i]; i += 1
        for k in range(8):
            if f & 1:
                o.append(c[i]); i += 1
            else:
                lo, hi = c[i], c[i + 1]; i += 2
                off = lo | ((hi >> 4) << 8); ln = (hi & 15) + 3
                if off == 0: return bytes(o)
                for _ in range(ln): o.append(o[-off])
            f >>= 1

LEVELS = orig[0x5B00:0x7C20]
LOW = img[0x7C20:0xB01E]
HA_DST, HB_DST = 0xCA80, 0xEA00
HA = img[HA_DST:HB_DST]
HB = img[HB_DST:0x10000]
segs = {}
for name, d in (('levels', LEVELS), ('ha', HA), ('hb', HB), ('low', LOW)):
    c = lz(d)
    assert unlz(c) == d, name
    segs[name] = c
    print(f"{name:7s} {len(d):6d} -> {len(c):6d}")
assert len(HA) <= 0x2800 and len(HB) <= 0x2800
blob = segs['levels'] + segs['ha'] + segs['hb'] + segs['low']
open(f'{B}/blob.bin', 'wb').write(blob)
staged = len(segs['levels']) + len(segs['ha']) + len(segs['hb'])
assert staged <= 0x4800, "staged part too big for bank 1"

def build(blob_addr):
    s1_int = min(blob_addr + staged, 0xB800) - blob_addr
    s1_ext = staged - s1_int
    low_src = blob_addr + staged
    inc = f"""OFF_LEVELS EQU 0
OFF_HA EQU {len(segs['levels'])}
OFF_HB EQU {len(segs['levels']) + len(segs['ha'])}
LOW_SRC EQU ${low_src:04X}
HA_DST EQU ${HA_DST:04X}
HA_LEN EQU {len(HA)}
HB_DST EQU ${HB_DST:04X}
HB_LEN EQU {len(HB)}
ENTRY EQU $F6F6
S1_INT EQU {s1_int}
S1_EXT EQU {s1_ext}
"""
    open(f'{B}/pack.inc', 'w').write(inc)
    r = subprocess.run(['sjasmplus', '--nologo', '--sym=../build/loader.sym', 'loader.asm'],
                       cwd='/home/claude/repton2/src', capture_output=True, text=True)
    if r.returncode: print(r.stdout, r.stderr); sys.exit(1)
    sym = {}
    for l in open(f'{B}/loader.sym'):
        if ':' in l and 'EQU' in l:
            k, v = l.split(':', 1)
            sym[k.strip()] = int(v.split('EQU')[1].strip().lstrip('$').rstrip('h'), 16)
    return sym, s1_int, s1_ext, low_src
sym, *_ = build(0x7C00)
blob_addr = sym['blob']
sym, s1_int, s1_ext, low_src = build(blob_addr)
assert sym['blob'] == blob_addr
# the low segment source must lie entirely in bank 0 above $B800 and below the high-A destination
assert low_src >= 0xB800, "low segment would overlap its own destination"
# (high A is unpacked after low, so overlapping HA_DST is fine)
image = open(f'{B}/image.bin', 'rb').read()
print(f"stub {blob_addr - 0x7AE9} bytes, staged {staged} ({s1_int}+{s1_ext}), low src ${low_src:04X}, load $7AE9-${0x7AE9 + len(image):04X}")
name = b'REPTON 2'.ljust(17, b'\x00')
hdr = b'VZF0' + name + bytes([0xF1]) + (0x7AE9).to_bytes(2, 'little')
assert len(hdr) == 24
vz = hdr + image
open(f'{B}/REPTON2.VZ', 'wb').write(vz)
print(f"REPTON2.VZ {len(vz)} bytes (limit ~31200)")
assert len(vz) <= 31200
