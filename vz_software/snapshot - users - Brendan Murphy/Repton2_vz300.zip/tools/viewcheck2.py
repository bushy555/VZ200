import sys,re
symf='/home/claude/repton2/build/main.sym'
sym={}
for l in open(symf):
    m=re.match(r'(\S+): EQU 0x([0-9A-F]+)',l)
    if m: sym[m.group(1)]=int(m.group(2),16)
tot=0
for snap in sys.argv[1:]:
    d=open(snap,'rb').read(); ram=d[:65536]; bv=d[65536:65536+131072]
    def rd(a):
        if a>=0xB800: return bv[0x10000+(a&0x7fff)]
        if 0x4000<=a<0x6800: return bv[a-0x4000]
        return ram[a]
    def rw(a): return rd(a)|rd(a+1)<<8
    if not (rd(0x783B) if False else True): pass
    posy=rd(0xFF01); posx=rd(0xFF02)
    vx0=(posx-14)&255; vy0=(posy-9)&255
    # skip if not in game graphics mode (latch AG bit) -> use VRAM heuristic: check vz_latch var
    if not rd(sym['vz_latch'])&8: continue
    ign=set()
    def ignore_tile(x,y,r=0):
        for i in range(-r,4+r):
            for j in range(-r,4+r): ign.add(((x+i)&255,(y+j)&255))
    ignore_tile(posx,posy); ignore_tile(rd(0xFF03),rd(0xFF04),1)
    for k in range(2):
        b=0xB01E+9*k
        if rd(b): ignore_tile(rd(b),rd(b+1),1)
    for k in range(8):
        b=0xB030+7*k
        if rd(b): ignore_tile(rd(b),rd(b+1),1)
    a=0xB194
    while rd(a) not in (0,0xFF):
        ignore_tile(rd(a),rd(a+1),1); a+=2
    # rocks list B068 (falling objects may be mid-update) - ignore their cells too
    a=0xB068
    while rd(a):
        ignore_tile(rd(a),rd(a+1),1); a+=5
    TP=sym['TILEPTR']; bad=0
    for r in range(21):
        for c in range(32):
            x=(vx0+c)&255; y=(vy0+r)&255
            if (x,y) in ign: continue
            cx = x>>2 if x<152 else (0 if x>=0xC0 else 37)
            cy = min(y>>2,41)
            t=rd(0xB1BC+cy*38+cx)
            if t>=0xC0: t=0x0D
            elif t>=0x80: continue
            g=rw(TP+2*t)+((y&3)*4+(x&3))*3
            exp=[rd(g+k) for k in range(3)]
            got=[rd(0xC000+(y%21)*128+(x&31)+32*k) for k in range(3)]
            if exp!=got:
                bad+=1
                if bad<4: print(snap,'mismatch view (%d,%d) world (%d,%d) tile %02x exp %s got %s'%(c,r,x,y,t,exp,got))
    tot+=bad
    if bad: print(snap,'bad',bad)
print('total bad',tot)
