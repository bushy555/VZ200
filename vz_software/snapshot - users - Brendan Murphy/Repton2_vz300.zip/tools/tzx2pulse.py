# TZX -> segment stream: pairs of (uint32 duration T-states, uint8 level)
import sys,struct
d=open(sys.argv[1],'rb').read(); i=10
segs=[]; level=0
def pulse(n):
    global level
    level^=1; segs.append((n,level))
def data(blk,z,o,used):
    for k,b in enumerate(blk):
        nb = used if k==len(blk)-1 else 8
        for bit in range(nb):
            v=(b>>(7-bit))&1
            pulse(o if v else z); pulse(o if v else z)
def pause(ms):
    global level
    if ms==0: return
    pulse(3500)  # end edge
    level=0; segs.append((ms*3500,0))
while i<len(d):
  b=d[i]
  if b==0x10:
    p=d[i+1]|d[i+2]<<8; l=d[i+3]|d[i+4]<<8; blk=d[i+5:i+5+l]
    for _ in range(8063 if blk[0]<128 else 3223): pulse(2168)
    pulse(667); pulse(735); data(blk,855,1710,8); pause(p); i+=5+l
  elif b==0x11:
    pl,s1,s2,z,o,pc=struct.unpack('<6H',d[i+1:i+13]); used=d[i+13]; p=d[i+14]|d[i+15]<<8
    l=d[i+16]|d[i+17]<<8|d[i+18]<<16; blk=d[i+19:i+19+l]
    for _ in range(pc): pulse(pl)
    pulse(s1); pulse(s2); data(blk,z,o,used); pause(p); i+=19+l
  elif b==0x14:
    z,o=struct.unpack('<2H',d[i+1:i+5]); used=d[i+5]; p=d[i+6]|d[i+7]<<8
    l=d[i+8]|d[i+9]<<8|d[i+10]<<16; blk=d[i+11:i+11+l]
    data(blk,z,o,used); pause(p); i+=11+l
  elif b==0x12:
    pl,n=struct.unpack('<2H',d[i+1:i+5]); [pulse(pl) for _ in range(n)]; i+=5
  elif b==0x13:
    n=d[i+1]
    for k in range(n): pulse(d[i+2+2*k]|d[i+3+2*k]<<8)
    i+=2+2*n
  elif b==0x20:
    p=d[i+1]|d[i+2]<<8
    if p==0: segs.append((0xffffffff,level))  # stop
    else: pause(p)
    i+=3
  elif b==0x21: i+=2+d[i+1]
  elif b==0x22: i+=1
  elif b==0x30: i+=2+d[i+1]
  elif b==0x32: l=d[i+1]|d[i+2]<<8; i+=3+l
  else: raise Exception('blk %x'%b)
segs.append((3500*2000,0))
with open(sys.argv[2],'wb') as f:
    for n,l in segs: f.write(struct.pack('<IB',min(n,0xffffffff),l))
print(len(segs),'segs', sum(n for n,l in segs)/3.5e6,'sec')
