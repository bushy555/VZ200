#!/bin/sh
set -e
cd /home/claude/repton2/art && python3 gen_data.py >/dev/null && python3 gen_fancy.py >/dev/null
cd /home/claude/repton2/src && sjasmplus --nologo --sym=../build/main.sym main.asm | grep -E "error|warning|region" || true
cd /home/claude/repton2 && python3 tools/pack.py | tail -2
