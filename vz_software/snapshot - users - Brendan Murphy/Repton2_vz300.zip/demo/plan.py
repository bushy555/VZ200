import subprocess, os, sys, random
from collections import deque
from multiprocessing import Pool
VZ='/home/claude/repton2/build/REPTON2.VZ'
W='/home/claude/repton2/demo/work'; os.makedirs(W,exist_ok=True)
KEYS={'Q':'Q','A':'A','O':'O','P':'P','-':'none'}
DIRS={'Q':(-1,0),'A':(1,0),'O':(0,-1),'P':(0,1)}
def run(args):
    idx,seq=args
    kf=f'{W}/k{idx}.txt'; sf=f'{W}/s{idx}.snap'; sc=f'{W}/r{idx}.script'
    if os.path.exists(sf): os.remove(sf)
    open(kf,'w').write("\n".join(KEYS[c] for c in seq)+"\n")
    n=len(seq)
    open(sc,'w').write(f"100 key SP\n112 key none\n330 key SP\n342 key none\n345 keyseq F838 {kf} {n+1} {sf}\n{345+n*5+300} quit -\n")
    subprocess.run(['/home/claude/tools/vzemu',sc,VZ],capture_output=True)
    if not os.path.exists(sf): return idx,None
    d=open(sf,'rb').read(); ram=d[:65536]; bv=d[65536:65536+131072]
    rd=lambda a: bv[0x10000+(a&0x7fff)] if a>=0xB800 else ram[a]
    st=dict(score=(rd(0xFF30)|rd(0xFF31)<<8)*10+rd(0xFF32),lives=rd(0xFF16),level=rd(0xFF17),y=rd(0xFF01),x=rd(0xFF02),step=rd(0xFF2F))
    st['map']=[[rd(0xB1BC+r*38+c) for c in range(38)] for r in range(42)]
    return idx,st
def ok(s): return s and s['lives']==2 and s['level']==1 and s['y']>=28
PASS=lambda t: t in (0,8,10,11,12)
GOAL=lambda t: t in (8,10,11,12)
def targets(st,k):
    m=st['map']; r0,c0=st['y']//4,st['x']//4
    prev={(r0,c0):None}; q=deque([(r0,c0)]); found=[]
    while q and len(found)<k:
        r,c=q.popleft()
        if GOAL(m[r][c]) and (r,c)!=(r0,c0): found.append((r,c))
        for d,(dr,dc) in DIRS.items():
            nr,nc=r+dr,c+dc
            if 0<=nr<42 and 0<=nc<38 and (nr,nc) not in prev and PASS(m[nr][nc]) and nr>=7:
                prev[(nr,nc)]=(r,c,d); q.append((nr,nc))
    paths=[]
    for t in found:
        p=[]; cur=t
        while prev[cur]: r,c,d=prev[cur]; p.append(d); cur=(r,c)
        paths.append(p[::-1])
    return paths
if __name__=='__main__':
    target=int(sys.argv[1]) if len(sys.argv)>1 else 800
    seed=int(sys.argv[2]) if len(sys.argv)>2 else 3
    seq='--'; rnd=random.Random(seed); hist=[]
    with Pool(8) as pool:
        _,st=run((0,seq))
        while len(seq)<target:
            paths=targets(st,8)
            if not paths: print('no targets'); break
            cands=[]
            for p in paths:
                p=p[:rnd.randint(2,5)]
                cands.append(seq+''.join(d*4 for d in p))
            for _ in range(6):
                cands.append(seq+''.join(rnd.choice('QAOP')*4 for _ in range(rnd.randint(1,3))))
            res=dict(pool.map(run,list(enumerate(cands))))
            good=[(res[i]['score'],-len(c),i,c) for i,c in enumerate(cands) if ok(res[i])]
            if not good:
                waits=getattr(sys.modules[__name__],'waits',0)+1; sys.modules[__name__].waits=waits
                c=seq+'----'; _,s2=run((99,c))
                if ok(s2) and waits<3: seq,st=c,s2; continue
                sys.modules[__name__].waits=0
                print('stuck at',len(seq)); seq=seq[:-8]; _,st=run((0,seq)); continue
            sys.modules[__name__].waits=0
            # prefer score gain, else any new position
            sc,_,i,c=max(good)
            seq,st=c,res[i]
            hist.append((len(seq),st['score']))
    # trim to the last score increase
    last=max(hist,key=lambda h:(h[1],-h[0]))
    keep=seq[:last[0]+8]
    open(f'/home/claude/repton2/demo/best_{seed}.txt','w').write(keep)
    print('seed',seed,'productive length',last[0],'score',last[1])
