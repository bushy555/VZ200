/*
Copyright� 2002, Mark Hamilton
Port to Z88DK by Stefano Bodrato - Oct 2003

VZ kinda cool rubbish done by Dave. Nov 2021.
Cycle intensive, and therefore requires super fast speed of VZEM, JVZ200 and WinDSE300 emulators.

- SLED
- DIAMOND
- TANK

*/

// zcc +zx -vn showlib3d.c -o showlib3d -lndos -llib3d -create-app

//#include <oz.h>
#include <lib3d.h>
#include <graphics.h>
#include <stdio.h>
#include <stdlib.h>
#include <vz.h>

#define MX2	100
#define MX0	64
#define MY0	46

#define backg_mem	0x9800
#define buffer_mem	0x9000




Vector_t tank[20]
=     { { -15 ,   -2,   -10  }, //centre square
	{ -15 ,   -2,    10  }, //centre square
	{  15 ,   0,    10  }, //centre square
	{  15 ,   0,   -10  }, //centre square
	{ -10 ,   5,  -5 },	// rear bottom	//bottom square
	{ -10 ,   5,   5 },	// rear bottom
	{ 12 ,   5,  -5 },	// front bottom
	{ 12 ,   5,   5 },	// front bottom
	{ -7,   -10, -4},	// rear Top
	{ -7,   -10, 4 },	// rear Top
	{ 3,   -4,  -5 },	// front Top
	{ 3,   -4,  5  },	// front Top
	{  -1  , -6, -2 },	// 12. rear bit of gun  //12
	{  -1  , -6,  2 },	// 13.
	{  -4 , -8, -2 },	// 14.
	{  -4 , -8,  2 },	// 15.
	{  18 , -12, -4},	// 16. front bit of gun
	{  18 , -12,  4},	// 17
	{  18 , -7, -4 },	// 18
	{  18 , -7,  4 }};	// 19




int vz_line2(int x1, int y1, int x2, int y2, int c)
{
  #asm
	ld	hl, 2
	add	hl, sp
	ld	c, (hl)			// get C. C=colour
	inc	hl
	inc	hl
	ld	d, (hl)			// get Y2. d=Y2
	inc	hl
	inc	hl
	ld	e, (hl)			// get X2. e=X2
	inc	hl
	inc	hl
	ld	a, (hl)			// get Y1. temp make A=Y1
	inc	hl
	inc	hl
	ld	l, (hl)			// get X1. L=x1
	ld	h, a			// set h=Y1 from temp A.
; 	c = colour
; 	l = x1
; 	h = y1
; 	e = x2
; 	d = y2
asmentry:
   	ld a,e
   	cp l
   	jr nc, line1
   	ex de,hl                  ; swap so that x1 < x2
line1: 	ld a ,e
   	sub l                     ; dx
   	ld e,a                    ; save dx
   	ld a,d
   	sub h
   	jp c, lup                 ; negative (up)
ldn:   	ld d,a                    ; save dy
   	cp e                      ; dy < dx ?
   	jr c, ldnx
ldny:  	ld b,a                    ; count = dy
   	srl a                     ; /2 -> overflow
ldny1: 	push af		; push return
   	push bc		; push colour
;   	push de		; push Y2/X2
   	push hl		; push Y1/X1
;=============================
   ; 	l = x
   ; 	h = y
   ; 	c = colour
;   	ld h,e
;   	ld	a,c
;   	and 3
;   	ld	c,a
;   	ld a,h
   	ld a,l
   	sla l                     ; calculate screen offset
   	srl h
   	rr l
   	srl h
   	rr l
   	srl h
   	rr l
   	and $03                   ; pixel offset   
   	inc a
   	ld b,a
      	ld a,$fc
pset1: 	rrca
   	rrca
   	rrc c
   	rrc c
   	djnz pset1
;   	ld de,(base_graphics)
;   	add hl,de
	add hl, buffer_mem
   	and (hl)
   	or c
   	ld (hl),a
;==================================   
   	pop hl
;   	pop de
   	pop bc
   	pop af
   	dec b                     ; done?
   	ret m
   	inc h                     ; y++
   	sub e                     ; overflow -= dx
   	jr nc, ldny1
   	inc l                     ; x++
   	add a,d                   ; overflow += dy
   	jp ldny1
ldnx:  	ld a,e                    ; get dx
   	ld b,a                    ; count = dx
   	srl a                     ; /2 -> overflow
ldnx1: 	push af
   	push bc
;   	push de
   	push hl
;=============================
;   	ld h,e
   ; 	l = x
   ; 	h = y
   ; 	c = colour
;  	ld	a,c
;  	and 3
;  	ld	c,a
;   	ld a,h
   	ld a,l
   	sla l                     ; calculate screen offset
   	srl h
   	rr l
   	srl h
   	rr l
   	srl h
   	rr l
   	and $03                   ; pixel offset   
   	inc a
   	ld b,a
      	ld a,$fc
pset2: 	rrca
   	rrca
   	rrc c
   	rrc c
   	djnz pset2
;   	ld de,(base_graphics)
;   	add hl,de
	add hl, buffer_mem
   	and (hl)
   	or c
   	ld (hl),a
;==================================   
   	pop hl
;   	pop de
   	pop bc
   	pop af
   	dec b                     ; done?
   	ret m
   	inc l                     ; x++
   	sub d                     ; overflow -= dy
   	jr nc, ldnx1
   	inc h                     ; y++
   	add a,e                   ; overflow += dx
   	jp ldnx1
lup:   	neg                       ; make dy positive
   	ld d,a                    ; save dy
   	cp e                      ; dy < dx ?
   	jr c, lupx
lupy:  	ld b,a                    ; count = dy
   	srl a                     ; /2 -> overflow
lupy1: 	push af
   	push bc
;   	push de
   	push hl
;=============================
;   	ld h,e
   ; 	l = x
   ; 	h = y
   ; 	c = colour
;   	ld	a,c
;   	and 3
;   	ld	c,a
;   	ld a,h
   	ld a,l
   	sla l                     ; calculate screen offset
   	srl h
   	rr l
   	srl h
   	rr l
   	srl h
   	rr l
   	and $03                   ; pixel offset   
   	inc a
   	ld b,a
   	ld a,$fc
pset3: 	rrca
   	rrca
   	rrc c
   	rrc c
   	djnz pset3
;   	ld de,(base_graphics)
;   	add hl,de
	add hl, buffer_mem
   	and (hl)
   	or c
   	ld (hl),a
;==================================   
   	pop hl
;   	pop de
   	pop bc
   	pop af
   	dec b                     ; done?
   	ret m
   	dec h                     ; y--
   	sub e                     ; overflow -= dx
   	jr nc, lupy1
   	inc l                     ; x++
   	add a,d                   ; overflow += dy
   	jp lupy1
lupx:  	ld a,e                    ; get dx
   	ld b,a                    ; count = dx
   	srl a                     ; /2 -> overflow
lupx1: 	push af
   	push bc
;   	push de
   	push hl
;=============================
   ; 	l = x
   ; 	h = y
   ; 	c = colour
;   	ld	a,c
;   	and 3
;   	ld	c,a
;   	ld a,h
   	ld a,l
   	sla l                     ; calculate screen offset
   	srl h
   	rr l
   	srl h
   	rr l
   	srl h
   	rr l
   	and $03                   ; pixel offset   
   	inc a
   	ld b,a
   	ld a,$fc
pset4: 	rrca
   	rrca
   	rrc c
   	rrc c
   	djnz pset4
;   	ld de,(base_graphics)
;   	add hl,de
	add hl, buffer_mem
   	and (hl)
   	or c
   	ld (hl),a
;==================================   
   	pop hl
;   	pop de
   	pop bc
   	pop af
   	dec b                     ; done?
   	ret m
   	inc l                     ; x++
   	sub d                     ; overflow -= dy
   	jr nc, lupx1
   	dec h                     ; y--
   	add a,e                   ; overflow += dx
   	jp lupx1
   #endasm
}


void background(void)
{
	#asm
	ld	hl, backg_mem	; fill with blue for first 10 rows. saves ~150 bytes.
	push	hl
	pop	de
	inc	de
	ld	(hl), $aa
	ld	bc, 160
	ldir

	ld	hl, backg_pic		// main bit of pic. stars and mountains.
	ld	de, backg_mem + 160	// could do this way better , but I am lazy.
	ld	bc, 1024-128-64
	ldir
	push	de
	pop	hl
	ld	(hl), 255	; fill in bottom red. saves ~1k !
	inc	de
	ld	bc, 1088
	ldir
	ret

backg_pic:

defb $0AA,$09A,$09A,$0AA,$0A6,$0AA,$06A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$06A,$0AA,$0AA,$0AA,$0AA,$06A
defb $0AA,$0AA,$0AA,$0AA,$0AA,$09A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0A6,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$09A,$0AA,$0AA
defb $0AA,$0A9,$0A6,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$09A,$0AA,$0AA,$02A,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0A6,$0AA,$0AA,$0AA,$0A6,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0A6,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0BA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0A9,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$08A,$0AA,$0AA,$0A6,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$09A,$0AA,$0AA,$0AA,$0AA,$0AA,$0A9,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0A2,$0AA,$0A6
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$06A,$0AA,$0A9,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$09A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AB,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$02A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0BA,$0AA,$0AA,$0AA,$06A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0A9,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$06A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0A6,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$09A,$0AA,$06A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0A6,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0A9,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AB,$0FE,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$06A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$09A,$0AA,$0AA,$0AA,$0FA,$0AA,$0AA,$0AE,$0AB,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0EA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0A6,$0AB,$0AE,$0AB,$0AA,$0FA,$0AF,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AB,$0BE,$0AA,$0A9,$0AA
defb $0AA,$0AA,$0A9,$0AA,$0BE,$0AB,$0AE,$0FF,$0AE,$0FA,$0EA,$0AA,$0AA,$0AA,$0AA,$06A
defb $0AA,$0A9,$0AA,$0AA,$0AA,$0A6,$0AA,$0AA,$0AA,$0AA,$0AA,$0AE,$0AB,$0AA,$0AA,$0AA
defb $0AA,$0AE,$0AA,$0AA,$0EA,$0AA,$0FA,$0AB,$0AB,$0AA,$0BA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$06A,$0AA,$08A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AF,$0FA,$0AF,$0FA,$0AA,$0AA
defb $0AA,$0FB,$0BF,$0FF,$0AA,$0AA,$0AA,$0BE,$0AA,$0AA,$0AF,$0EA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AF,$0FA,$0AA,$0BA,$0AF,$0FA,$0AA
defb $0AB,$0AA,$0EA,$0BA,$0AA,$0AA,$0AA,$0EA,$0AA,$0AA,$0AA,$0BA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0BA,$0AA,$0AA,$0EA,$0AA,$0AF,$0AA
defb $0AE,$0AA,$0AA,$0EA,$0AA,$0AA,$0AB,$0AA,$0AA,$0AA,$0AA,$0AE,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0EA,$0AA,$0AB,$0AA,$0AA,$0AA,$0EA


; --------------------------------------
	#endasm
}
	

void main(void)
{

	static Vector_t rot3;
	static Vector_t t3;
	static Point_t  p3[20];

	static unsigned c , i;
	static int MX, MY;
	static int zf2 = 100;

	#asm
		ld	a, 8
		ld	($6800), a
		di
	#endasm
	background();
	MY = MY0;
	MX = 100;

	rot3.z = (270*(rot3.z+5))%360;
	rot3.y = (10*(rot3.y+5))%360;

	
	while(1){
                
		c++;
			for(i=0;i<20;i++) {
			ozcopyvector(&t3,&tank[i]);	// Table
			ozrotatepointx(&t3, rot3.x);
			ozrotatepointy(&t3, rot3.y);
			ozrotatepointz(&t3, rot3.z);
			t3.z += zf2; 			// Zoom factor
			ozplotpoint(&t3, &p3[i]);
			}


	if ((c>58) && (c<190)) {rot3.y = (rot3.y+5)%360;}
        if (c<48){	MX=MX-1;
			zf2=zf2-5;}
	if (c>184){MX--;}

	if ((c>220)&&(c<400)){	MX--;
				MX--;
				MX--;}

	if ((c>300)&&(c<311)){rot3.y = (rot3.y+5)%360;
			      }
	if ((c>320)&&(c<330)) {MY--;}

	if ((c>310)&&(c<310+48)) {MX--;
		   		  zf2=zf2+5;
				  }



		#asm			
			ld	hl, buffer_mem	// blit from buffer to screen.
			ld	de, $7000
			ld	bc, 2048
			ldir
	
			ld	hl, backg_mem	// COPY background.
			ld	de, buffer_mem
			ld	bc, 2048
			ldir
		#endasm





//=================
//	TANK
//=================
	vz_line2(p3[0].x+MX,p3[0].y+MY,p3[1].x+MX,p3[1].y+MY,1); //centre
	vz_line2(p3[1].x+MX,p3[1].y+MY,p3[2].x+MX,p3[2].y+MY,1);
	vz_line2(p3[2].x+MX,p3[2].y+MY,p3[3].x+MX,p3[3].y+MY,1);
	vz_line2(p3[3].x+MX,p3[3].y+MY,p3[0].x+MX,p3[0].y+MY,1);

	vz_line2(p3[4].x+MX,p3[4].y+MY,p3[5].x+MX,p3[5].y+MY,1); //bottom
	vz_line2(p3[5].x+MX,p3[5].y+MY,p3[7].x+MX,p3[7].y+MY,1);
	vz_line2(p3[7].x+MX,p3[7].y+MY,p3[6].x+MX,p3[6].y+MY,1);
	vz_line2(p3[6].x+MX,p3[6].y+MY,p3[4].x+MX,p3[4].y+MY,1);

	vz_line2(p3[0].x+MX,p3[0].y+MY,p3[4].x+MX,p3[4].y+MY,1); //bottom verticals
	vz_line2(p3[1].x+MX,p3[1].y+MY,p3[5].x+MX,p3[5].y+MY,1);
	vz_line2(p3[2].x+MX,p3[2].y+MY,p3[7].x+MX,p3[7].y+MY,1);
	vz_line2(p3[3].x+MX,p3[3].y+MY,p3[6].x+MX,p3[6].y+MY,1);

	vz_line2(p3[0].x+MX,p3[0].y+MY,p3[8].x+MX,p3[8].y+MY,1); //rear verticals
	vz_line2(p3[1].x+MX,p3[1].y+MY,p3[9].x+MX,p3[9].y+MY,1);

	vz_line2(p3[8].x+MX,p3[8].y+MY,p3[9].x+MX,p3[9].y+MY,1);    // Top front angled bonnet
	vz_line2(p3[10].x+MX,p3[10].y+MY,p3[11].x+MX,p3[11].y+MY,1);
	vz_line2(p3[8].x+MX,p3[8].y+MY,p3[10].x+MX,p3[10].y+MY,1);
	vz_line2(p3[9].x+MX,p3[9].y+MY,p3[11].x+MX,p3[11].y+MY,1);
	vz_line2(p3[10].x+MX,p3[10].y+MY,p3[3].x+MX,p3[3].y+MY,1);
	vz_line2(p3[11].x+MX,p3[11].y+MY,p3[2].x+MX,p3[2].y+MY,1);

	vz_line2(p3[12].x+MX,p3[12].y+MY,p3[13].x+MX,p3[13].y+MY,1); // rear square gun
	vz_line2(p3[13].x+MX,p3[13].y+MY,p3[15].x+MX,p3[15].y+MY,1);
	vz_line2(p3[15].x+MX,p3[15].y+MY,p3[14].x+MX,p3[14].y+MY,1);
	vz_line2(p3[14].x+MX,p3[14].y+MY,p3[12].x+MX,p3[12].y+MY,1);

	vz_line2(p3[16].x+MX,p3[16].y+MY,p3[17].x+MX,p3[17].y+MY,1); // front square gun
	vz_line2(p3[17].x+MX,p3[17].y+MY,p3[19].x+MX,p3[19].y+MY,1); 
	vz_line2(p3[19].x+MX,p3[19].y+MY,p3[18].x+MX,p3[18].y+MY,1);
	vz_line2(p3[18].x+MX,p3[18].y+MY,p3[16].x+MX,p3[16].y+MY,1);

	vz_line2(p3[12].x+MX,p3[12].y+MY,p3[18].x+MX,p3[18].y+MY,1); // rear to front gun
	vz_line2(p3[13].x+MX,p3[13].y+MY,p3[19].x+MX,p3[19].y+MY,1);
	vz_line2(p3[14].x+MX,p3[14].y+MY,p3[16].x+MX,p3[16].y+MY,1);
	vz_line2(p3[15].x+MX,p3[15].y+MY,p3[17].x+MX,p3[17].y+MY,1);



	}
}



