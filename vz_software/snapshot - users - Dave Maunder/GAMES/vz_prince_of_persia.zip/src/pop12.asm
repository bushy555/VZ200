; ============================================================================
; POP12 - Prince-of-Persia style engine for the VZ200, 256x192 mono (Aus)
; Step 12: CHOMPERS (jaws slam every 16 frames, deadly while shut) and several LEVELS: the exit door
;         leads to the next level in levels.txt; after the last one the game starts over.
; Step 11: SOUND (speaker bits on the latch; short blocking effects played after each frame is drawn;
;         M toggles mute) and a TITLE SCREEN (big lettering, controls, blinking prompt, jingle).
; Step 10: GATES and PRESSURE PLATES.  A plate opens every gate in the room (6 frames up), they hold
;         ~11 s, then slam shut - never on someone standing in a doorway.  Closed gates block both fighters.
; Step 9: HEALTH POTIONS (crouch on one with S to drink: +1 HP) and LOOSE FLOOR tiles (they crumble ~4
;         frames after you step on them; kills/potions/collapses are remembered per room).
; Step 8: FALL DAMAGE (1 row safe, 2 rows -1 HP, 3+ rows fatal), CLIMBING DOWN (hang from a ledge,
;         S at an edge, then drop), a LEVEL EXIT door with a 'LEVEL COMPLETE' screen, and an
;         8-room level in levels.txt.
; Step 7: FULL ANIMATION SET - run start/stop, turn, crouch (S), landing, standing vs running
;         jump, fall frames, longer climb, sword draw/sheathe and retreat poses.
; Step 6: MULTI-ROOM LEVELS (levels.txt): walk/jump off a screen edge, fall into the room
;         below, climb up into the room above; guards per room, kills are remembered.
; Step 5: SWORD FIGHT.  A guard (simple AI) shares the room; D draws/sheathes the
;         sword; with it drawn: Z/X step, A strike, S hold = parry.  3 hit points
;         each (pips on the bottom strip); a death resets the fight.
;         Variable-size sprites (width/height/offset per frame), runtime mirroring.
; Earlier steps: room renderer, run, jump, ledge climb (see pop04).  Origin $7B00.
;
; Screen = 3 floor rows x 8 columns, each cell 32 px (4 bytes) x 64 lines, so
; one floor row == one video bank.
; Keys: Z = left, X = right, A = jump/strike, D = draw/sheathe sword, S = parry.
; ============================================================================

VRAM        EQU $7000
LATCH       EQU $6800
PORT_RES    EQU 32
ROOM_W      EQU 8
ROOM_H      EQU 3

KEYROW_ZX   EQU $68FB       ; row A2: V Z C SHFT X B = D5..D0 (active low)
KEY_Z_BIT   EQU 4
KEY_X_BIT   EQU 1
KEYROW_123  EQU $68F7       ; row A3: 4 1 3 2 5 = D5..D1 (active low)
KEYROW_A    EQU $68FD       ; row A1: F A D CTRL S G = D5..D0
KEY_A_BIT   EQU 4
KEY_D_BIT   EQU 3
KEY_S_BIT   EQU 1
KEYROW_M    EQU $68EF       ; row 4: M SPACE , - . N = D5..D0
KEY_M_BIT   EQU 5
SND_STEP    EQU 1           ; sound ids = priorities (a louder event overrides a quieter one)
SND_GATE    EQU 2
SND_LAND    EQU 3
SND_DRAW    EQU 4
SND_PARRY   EQU 5
SND_HIT     EQU 6
SND_LOOSE   EQU 7
SND_FALLHURT EQU 8
SND_POTION  EQU 9
SND_DEATH   EQU 10

STEP        EQU 4           ; pixels per game frame when running
FALLSTEP    EQU 8           ; pixels per frame when falling (must divide 64)
MAXX        EQU 239         ; reference-box left edge limit
SPR_H       EQU 42          ; height of the reference box (feet = top + SPR_H-1)
JUMP_LEN    EQU 8
FRAME_VBL   EQU 1           ; vsyncs waited after the work (work ~50-68 ms + 20 ms = ~12 fps)

; fighter record layout (prince = P_ENT, guard = G_ENT)
E_X         EQU 0           ; reference-box left edge (px)
E_Y         EQU 1           ; reference-box top line
E_FACE      EQU 2           ; 0 right, 1 left
E_FRAME     EQU 3
E_FS        EQU 4           ; fight state
E_FI        EQU 5           ; step within a strike
E_HP        EQU 6
E_TMR       EQU 7
E_ROW       EQU 8           ; floor row he stands on
E_BL        EQU 9           ; bounds of what was last drawn (for erasing)
E_BR        EQU 10
E_BT        EQU 11
E_BB        EQU 12

FS_GARDE    EQU 0
FS_STRIKE   EQU 2
FS_PARRY    EQU 3
FS_HURT     EQU 4
FS_DEAD     EQU 5
FR_GARDE    EQU 9
FR_ADV      EQU 10
FR_ST1      EQU 11
FR_ST2      EQU 12
FR_PARRY    EQU 13
FR_HURT     EQU 14
FR_DEAD     EQU 15
FR_RETREAT  EQU 16          ; frames 9-18 also exist as dithered guard copies
FR_DRAW1    EQU 17
FR_DRAW2    EQU 18
FR_RUNST1   EQU 19          ; locomotion frames
FR_RUNST2   EQU 20
FR_STOP1    EQU 21
FR_STOP2    EQU 22
FR_TURN1    EQU 23
FR_TURN2    EQU 24
FR_TURN3    EQU 25
FR_CROUCH   EQU 26
FR_LAND     EQU 27
FR_JWIND    EQU 28
FR_JRISE    EQU 29
FR_JAPEX    EQU 30
FR_JFALL    EQU 31
FR_FALL     EQU 32
FR_JUMPUP   EQU 33
FR_CLIMB3   EQU 34
FR_SWA      EQU 35          ; sword-drawn walk: feet passing, two phases
FR_SWB      EQU 36
FS_DRAW     EQU 1           ; drawing the sword (2 frames)
FS_SHEATH   EQU 6           ; putting it away (2 frames)
HIT_RANGE   EQU 30          ; centre-to-centre distance a lunge can reach
MIN_SEP     EQU 14          ; fighters cannot get closer than this
FSTEP       EQU 3           ; px per step with the sword out
ENGAGE      EQU 96          ; guard wakes up inside this distance
WALK_RANGE  EQU 30          ; guard stops closing in at this distance

REV_TBL     EQU $FE00       ; 256-byte bit-reverse table, built at start (page aligned, top of the 32 KB)
STACK_TOP   EQU $FE00       ; stack grows down from here (needs the 32 KB layout: RAM to $FFFF)
NONE        EQU 255
PLATE_HOLD  EQU 140         ; frames a gate stays up after its plate was pressed (~11 s)
T_POTION    EQU $40         ; tile decoration bit: a potion stands on this floor tile (T_TORCH = $80)
POTION_Y    EQU 41
DECOR_Y     EQU 14
POTION_H    EQU 9

            ORG $7B00

START:      DI
            LD   SP,STACK_TOP
            CALL VIDEO_INIT
            CALL INIT_REV
            CALL INTRO_SCREEN           ; the palace picture, then the title screen
            CALL TITLE_SCREEN
            LD   A,(START_LV)
            CALL SET_LEVEL              ; level 1 (or the one picked on the intro screen with keys 1-3)
            CALL RESET_FIGHT            ; loads the start room and draws it
            CALL DRAW_GUARD
            CALL DRAW_PRINCE

GAME_LOOP:  CALL WAIT_FRAME
            CALL READ_INPUT
            CALL CHECK_MUTE
            CALL UPDATE
            CALL CHECK_EXIT
            CALL CHECK_LOOSE
            CALL CHECK_GATES
            CALL CHECK_CHOMP
            LD   A,(WINFLAG)
            OR   A
            CALL NZ,DO_WIN
            CALL GUARD_STEP
            CALL UPDATE_SCREEN          ; torches, then compose the changed cells off-screen and copy them over
            CALL DRAW_STATUS
            CALL PLAY_SOUND             ; effects last: the picture is already up to date
FRAME_DONE: JR   GAME_LOOP

; ---------------------------------------------------------------------------
; Video
; ---------------------------------------------------------------------------
VIDEO_INIT: XOR  A
SET_BANK:   LD   (CUR_BANK),A           ; A = 0..2 -> lines 0-63/64-127/128-191
            ADD  A,28
            OUT  (PORT_RES),A
            LD   A,8
            LD   (LATCH),A
            RET

; wait for the start of vertical blank, FRAME_VBL times (bit 7 of $6800 = /FS)
WAIT_FRAME: LD   B,FRAME_VBL
WF_LOOP:    LD   A,(LATCH)
            BIT  7,A
            JR   Z,WF_LOOP
WF_BLANK:   LD   A,(LATCH)
            BIT  7,A
            JR   NZ,WF_BLANK
            DJNZ WF_LOOP
            RET

; build the 256-entry bit-reverse table used to mirror sprites
INIT_REV:   LD   HL,REV_TBL
            LD   C,0
IR_LOOP:    LD   A,C
            LD   D,0
            LD   B,8
IR_BIT:     RRA
            RL   D
            DJNZ IR_BIT
            LD   (HL),D
            INC  HL
            INC  C
            JR   NZ,IR_LOOP
            RET

; ---------------------------------------------------------------------------
; Input -> KEYS: bit0 left, bit1 right, bit2 A (press), bit3 D (press), bit4 S (held)
; ---------------------------------------------------------------------------
READ_INPUT: LD   A,(KEYROW_ZX)
            LD   B,A
            LD   C,0
            BIT  KEY_Z_BIT,B
            JR   NZ,RI_NOL
            SET  0,C
RI_NOL:     BIT  KEY_X_BIT,B
            JR   NZ,RI_NOR
            SET  1,C
RI_NOR:     LD   A,(KEYROW_A)
            LD   B,A
            BIT  KEY_S_BIT,B
            JR   NZ,RI_NOS
            SET  4,C
RI_NOS:     LD   A,0
            BIT  KEY_A_BIT,B
            JR   NZ,RI_A0
            LD   A,1
RI_A0:      LD   D,A
            LD   A,(JPREV)
            LD   E,A
            LD   A,D
            LD   (JPREV),A
            LD   A,E
            OR   A
            JR   NZ,RI_DK
            LD   A,D
            OR   A
            JR   Z,RI_DK
            SET  2,C
RI_DK:      LD   A,0
            BIT  KEY_D_BIT,B
            JR   NZ,RI_D0
            LD   A,1
RI_D0:      LD   D,A
            LD   A,(DPREV)
            LD   E,A
            LD   A,D
            LD   (DPREV),A
            LD   A,E
            OR   A
            JR   NZ,RI_DONE
            LD   A,D
            OR   A
            JR   Z,RI_DONE
            SET  3,C
RI_DONE:    LD   A,C
            LD   (KEYS),A
            RET

; ---------------------------------------------------------------------------
; Room renderer (from pop01)
; ---------------------------------------------------------------------------
RENDER_ROOM:
            XOR  A
            LD   (RR_ROW),A
RR_ROWLOOP: LD   A,(RR_ROW)
            CALL SET_BANK
            LD   HL,VRAM
            LD   DE,VRAM+1
            LD   BC,2047
            LD   (HL),0
            LDIR
            LD   A,(RR_ROW)
            ADD  A,A
            ADD  A,A
            ADD  A,A
            LD   E,A
            LD   D,0
            LD   HL,ROOM_MAP
            ADD  HL,DE
            LD   B,ROOM_W
            LD   C,0
RR_COL:     PUSH BC
            PUSH HL
            LD   A,(HL)
            LD   B,C
            CALL DRAW_TILE
            POP  HL
            POP  BC
            INC  HL
            INC  C
            DJNZ RR_COL
            LD   A,(RR_ROW)
            INC  A
            LD   (RR_ROW),A
            CP   ROOM_H
            JR   NZ,RR_ROWLOOP
            RET

; CELL_ADDR - A = line in bank (0..63), B = column -> HL = VRAM+line*32+col*4
CELL_ADDR:  LD   L,A
            LD   H,0
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            LD   A,B
            ADD  A,A
            ADD  A,A
            LD   E,A
            LD   D,0
            ADD  HL,DE
            LD   DE,(DRAW_BASE)         ; VRAM normally, SHADOW while composing
            ADD  HL,DE
            RET

; DRAW_TILE - A = tile id (bit 7 = torch), B = column, current bank
DRAW_TILE:  PUSH AF
            PUSH BC
            AND  $3F
            JR   Z,DT_DECO
            LD   L,A
            LD   H,0
            ADD  HL,HL
            ADD  HL,HL
            LD   DE,TILE_TBL
            ADD  HL,DE
            LD   E,(HL)
            INC  HL
            LD   D,(HL)
            INC  HL
            LD   A,(HL)
            INC  HL
            LD   C,(HL)
            PUSH DE
            PUSH BC
            CALL CELL_ADDR
            EX   DE,HL
            POP  BC
            LD   A,C
            POP  HL
DT_LINE:    LDI
            LDI
            LDI
            LDI
            EX   DE,HL
            LD   BC,28
            ADD  HL,BC
            EX   DE,HL
            DEC  A
            JR   NZ,DT_LINE
DT_DECO:    POP  BC
            POP  AF
            LD   C,A                    ; C = tile id (decoration bits)
            BIT  7,A
            JR   NZ,DT_NOWD             ; no wall detail behind a torch
            AND  $3F
            JR   Z,DT_WD1               ; an empty cell, or a plain floor tile (FLOOR..FLOORL), may get some
            CP   T_FLOOR
            JR   C,DT_NOWD
            CP   T_PILLAR
            JR   NC,DT_NOWD
DT_WD1:     LD   A,(CUR_ROOM)           ; pseudo-random but stable: hash of level, room, row, column
            LD   D,A
            ADD  A,A
            ADD  A,A
            ADD  A,D                    ; room*5
            LD   D,A
            LD   A,(CUR_BANK)
            LD   E,A
            ADD  A,A
            ADD  A,E                    ; row*3
            ADD  A,D
            LD   D,A
            LD   A,(CUR_LEVEL)
            ADD  A,A
            ADD  A,A
            ADD  A,D
            LD   D,A
            LD   A,B
            ADD  A,A
            ADD  A,A
            ADD  A,A
            SUB  B                      ; column*7
            ADD  A,D
            AND  7
            CP   3
            JR   NZ,DT_NOWD
            PUSH BC
            CALL DT_DECOR               ; B = column
            POP  BC
DT_NOWD:    BIT  7,C
            JR   Z,DT_NOTORCH
            PUSH BC
            LD   A,TORCH_Y              ; torch: 2 bytes wide at byte column 1
            CALL CELL_ADDR
            INC  HL
            LD   DE,(TORCH_PTR)         ; the current flame frame
            LD   B,TORCH_H
DT_TL:      LD   A,(DE)
            OR   (HL)
            LD   (HL),A
            INC  DE
            INC  HL
            LD   A,(DE)
            OR   (HL)
            LD   (HL),A
            INC  DE
            LD   A,L
            ADD  A,31
            LD   L,A
            JR   NC,DT_TNC
            INC  H
DT_TNC:     DJNZ DT_TL
            POP  BC
DT_NOTORCH: BIT  6,C
            RET  Z
            LD   A,POTION_Y             ; potion: 1 byte wide at byte column 2
            CALL CELL_ADDR
            INC  HL
            INC  HL
            LD   DE,POTION_BMP
            LD   B,POTION_H
DT_PL:      LD   A,(DE)
            OR   (HL)
            LD   (HL),A
            INC  DE
            LD   A,L
            ADD  A,32
            LD   L,A
            JR   NC,DT_PNC
            INC  H
DT_PNC:     DJNZ DT_PL
            RET

POTION_BMP: DEFB $18,$18,$3C,$7E,$FF,$D7,$FF,$FF,$7E

; ---------------------------------------------------------------------------
; Torch flames: every second frame the next flame picture (sequence 0,1,0,2) is stored over the flame of every
; torch in the room.  The sprites have just been erased and are drawn again afterwards, so nothing can be overdrawn.
; ---------------------------------------------------------------------------
ANIM_TORCH: LD   A,(TORCH_T)
            INC  A
            LD   (TORCH_T),A
            AND  1
            RET  NZ
            LD   A,(TORCH_T)
            RRCA
            AND  3
            LD   E,A
            LD   D,0
            LD   HL,TORCH_SEQ
            ADD  HL,DE
            LD   A,(HL)
            ADD  A,A
            LD   E,A
            LD   HL,TORCH_FRAMES
            ADD  HL,DE
            LD   E,(HL)
            INC  HL
            LD   D,(HL)
            LD   (TORCH_PTR),DE
            LD   A,(CUR_BANK)
            PUSH AF
            LD   HL,ROOM_MAP
            LD   C,0                    ; row
AT_ROW:     LD   B,0                    ; column
AT_COL:     BIT  7,(HL)
            CALL NZ,AT_DRAW
            INC  HL
            INC  B
            LD   A,B
            CP   8
            JR   NZ,AT_COL
            INC  C
            LD   A,C
            CP   3
            JR   NZ,AT_ROW
            POP  AF
            JP   SET_BANK
AT_DRAW:    PUSH HL
            PUSH BC
            LD   A,C
            CALL SET_BANK
            LD   A,TORCH_Y
            CALL CELL_ADDR              ; B = column
            INC  HL
            LD   DE,(TORCH_PTR)
            LD   B,TORCH_H
AT_LINE:    LD   A,(DE)
            LD   (HL),A
            INC  DE
            INC  HL
            LD   A,(DE)
            LD   (HL),A
            INC  DE
            LD   A,L
            ADD  A,31
            LD   L,A
            JR   NC,AT_NC
            INC  H
AT_NC:      DJNZ AT_LINE
            POP  BC
            POP  HL
            RET
TORCH_SEQ:  DEFB 0,1,0,2
TORCH_FRAMES: DEFW TORCH_BMP,TORCH2_BMP,TORCH3_BMP

; wall detail: loose bricks / cracks on the dark back wall, 3 bytes wide x DECOR_H lines at byte column 1;
; the two pictures alternate with the cell's column
DT_DECOR:   PUSH BC
            LD   A,DECOR_Y
            CALL CELL_ADDR
            INC  HL
            POP  BC
            LD   DE,DECOR_BMP
            LD   A,B
            AND  1
            JR   Z,DD_GO
            LD   DE,DECOR_BMP+DECOR_H*3
DD_GO:      LD   B,DECOR_H
DD_LINE:    LD   C,3
DD_BYTE:    LD   A,(DE)
            OR   (HL)
            LD   (HL),A
            INC  DE
            INC  HL
            DEC  C
            JR   NZ,DD_BYTE
            LD   A,L
            ADD  A,29
            LD   L,A
            JR   NC,DD_NC
            INC  H
DD_NC:      DJNZ DD_LINE
            RET

; DRAW_CELL - B = column, C = row: clear that cell completely, redraw its tile
DRAW_CELL:  PUSH BC
            LD   A,C
            CALL SET_BANK
            POP  BC
            PUSH BC
            XOR  A
            CALL CELL_ADDR
            LD   B,64
            LD   DE,28
DC_CLR:     LD   (HL),0
            INC  HL
            LD   (HL),0
            INC  HL
            LD   (HL),0
            INC  HL
            LD   (HL),0
            INC  HL
            ADD  HL,DE
            DJNZ DC_CLR
            POP  BC
            LD   A,C
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,B
            LD   E,A
            LD   D,0
            LD   HL,ROOM_MAP
            ADD  HL,DE
            LD   A,(HL)
            JP   DRAW_TILE

; GET_TILE - B = column, C = row -> A = tile type (torch bit stripped)
GET_TILE:   LD   A,C
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,B
            LD   E,A
            LD   D,0
            LD   HL,ROOM_MAP
            ADD  HL,DE
            LD   A,(HL)
            AND  $3F
            RET

; ---------------------------------------------------------------------------
; ERASE_AT - redraw every cell inside the pixel box ER_L..ER_R x ER_T..ER_B
; ---------------------------------------------------------------------------
ERASE_PRINCE:
            LD   A,(P_ENT+E_BL)
            LD   (ER_L),A
            LD   A,(P_ENT+E_BR)
            LD   (ER_R),A
            LD   A,(P_ENT+E_BT)
            LD   (ER_T),A
            LD   A,(P_ENT+E_BB)
            LD   (ER_B),A
            JR   ERASE_AT
ERASE_GUARD:
            LD   A,(G_ACTIVE)
            OR   A
            RET  Z
            LD   A,(G_ENT+E_BL)
            LD   (ER_L),A
            LD   A,(G_ENT+E_BR)
            LD   (ER_R),A
            LD   A,(G_ENT+E_BT)
            LD   (ER_T),A
            LD   A,(G_ENT+E_BB)
            LD   (ER_B),A
ERASE_AT:   LD   A,(ER_T)               ; clip the box to the screen
            CP   192
            JR   C,EA_TOPOK
            LD   A,(ER_B)               ; top is off-screen:
            CP   192
            RET  NC                     ;   all of it is -> nothing to erase
            XOR  A                      ;   or it wrapped over the top -> start at line 0
            LD   (ER_T),A
EA_TOPOK:   LD   A,(ER_B)
            CP   192
            JR   C,EA_GO
            LD   A,191
            LD   (ER_B),A
EA_GO:      LD   A,(ER_L)
            RLCA
            RLCA
            RLCA
            AND  7
            LD   (ER_C0),A
            LD   A,(ER_R)
            RLCA
            RLCA
            RLCA
            AND  7
            LD   (ER_C1),A
            LD   A,(ER_T)
            RLCA
            RLCA
            AND  3
            LD   (ER_R0),A
            LD   A,(ER_B)
            RLCA
            RLCA
            AND  3
            LD   (ER_R1),A
ER_ROW:     LD   A,(ER_C0)
            LD   (ER_C),A
ER_COL:     LD   A,(ER_C)
            LD   B,A
            LD   A,(ER_R0)
            LD   C,A
            CALL DRAW_CELL
            LD   A,(ER_C)
            INC  A
            LD   (ER_C),A
            LD   B,A
            LD   A,(ER_C1)
            CP   B
            JR   NC,ER_COL
            LD   A,(ER_R0)
            INC  A
            LD   (ER_R0),A
            LD   B,A
            LD   A,(ER_R1)
            CP   B
            JR   NC,ER_ROW
            RET

; ---------------------------------------------------------------------------
; DRAW_PRINCE / DRAW_GUARD - pick the frame and blit it; remember what it covered
; ---------------------------------------------------------------------------
DRAW_PRINCE:
            CALL SET_PRINCE_SPR
            CALL DRAW_SPRITE
STORE_P_BOX:
            LD   A,(DS_BL)
            LD   (P_ENT+E_BL),A
            LD   A,(DS_BR)
            LD   (P_ENT+E_BR),A
            LD   A,(DS_BT)
            LD   (P_ENT+E_BT),A
            LD   A,(DS_BB)
            LD   (P_ENT+E_BB),A
            RET

SET_PRINCE_SPR:
            LD   A,(PX)
            LD   (SP_X),A
            LD   A,(PY)
            LD   (SP_Y),A
            LD   A,(PFACE)
            LD   (SP_FLIP),A
            LD   A,(PFRAME)
            ADD  A,A
            LD   E,A
            LD   D,0
            LD   HL,PRINCE_TBL
            ADD  HL,DE
            LD   E,(HL)
            INC  HL
            LD   D,(HL)
            EX   DE,HL
            RET

DRAW_GUARD: LD   A,(G_ACTIVE)
            OR   A
            RET  Z
            CALL SET_GUARD_SPR
            CALL DRAW_SPRITE
STORE_G_BOX:
            LD   A,(DS_BL)
            LD   (G_ENT+E_BL),A
            LD   A,(DS_BR)
            LD   (G_ENT+E_BR),A
            LD   A,(DS_BT)
            LD   (G_ENT+E_BT),A
            LD   A,(DS_BB)
            LD   (G_ENT+E_BB),A
            RET

SET_GUARD_SPR:
            LD   A,(GX)
            LD   (SP_X),A
            LD   A,(GY)
            LD   (SP_Y),A
            LD   A,(GFACE)
            LD   (SP_FLIP),A
            LD   A,(GFRAME)
            CP   FR_SWA
            JR   C,SG_LOW
            SUB  FR_SWA-10              ; sword-walk frames sit at guard table entries 10, 11
            JR   SG_IDX
SG_LOW:     SUB  FR_GARDE
SG_IDX:     ADD  A,A
            LD   E,A
            LD   D,0
            LD   HL,GUARD_TBL
            LD   A,(GKIND)
            OR   A
            JR   Z,DG_TBL
            LD   HL,SKEL_TBL
DG_TBL:     ADD  HL,DE
            LD   E,(HL)
            INC  HL
            LD   D,(HL)
            EX   DE,HL
            RET

; ---------------------------------------------------------------------------
; UPDATE_SCREEN - flicker-free redraw.  The cells touched by the old and new boxes of the prince and the guard are
; built in the RAM copy of a bank (SHADOW: tile + guard + prince), then copied to the screen in one quick pass,
; so a sprite is never missing from the screen while it is being redrawn.
; ---------------------------------------------------------------------------
UPDATE_SCREEN:
            CALL ANIM_TORCH
            XOR  A
            LD   (DIRTY),A
            LD   (DIRTY+1),A
            LD   (DIRTY+2),A
            LD   A,(P_ENT+E_BL)         ; old boxes
            LD   (ER_L),A
            LD   A,(P_ENT+E_BR)
            LD   (ER_R),A
            LD   A,(P_ENT+E_BT)
            LD   (ER_T),A
            LD   A,(P_ENT+E_BB)
            LD   (ER_B),A
            CALL MARK_BOX
            LD   A,(G_ACTIVE)
            OR   A
            JR   Z,US_NOG1
            LD   A,(G_ENT+E_BL)
            LD   (ER_L),A
            LD   A,(G_ENT+E_BR)
            LD   (ER_R),A
            LD   A,(G_ENT+E_BT)
            LD   (ER_T),A
            LD   A,(G_ENT+E_BB)
            LD   (ER_B),A
            CALL MARK_BOX
US_NOG1:    LD   A,1                    ; new boxes (box only, nothing drawn)
            LD   (DS_MODE),A
            CALL SET_PRINCE_SPR
            CALL DRAW_SPRITE
            CALL STORE_P_BOX
            LD   A,(P_ENT+E_BL)
            LD   (ER_L),A
            LD   A,(P_ENT+E_BR)
            LD   (ER_R),A
            LD   A,(P_ENT+E_BT)
            LD   (ER_T),A
            LD   A,(P_ENT+E_BB)
            LD   (ER_B),A
            CALL MARK_BOX
            LD   A,(G_ACTIVE)
            OR   A
            JR   Z,US_NOG2
            CALL SET_GUARD_SPR
            CALL DRAW_SPRITE
            CALL STORE_G_BOX
            LD   A,(G_ENT+E_BL)
            LD   (ER_L),A
            LD   A,(G_ENT+E_BR)
            LD   (ER_R),A
            LD   A,(G_ENT+E_BT)
            LD   (ER_T),A
            LD   A,(G_ENT+E_BB)
            LD   (ER_B),A
            CALL MARK_BOX
US_NOG2:    LD   A,2                    ; compose into SHADOW, one bank row at a time
            LD   (DS_MODE),A
            LD   HL,SHADOW
            LD   (DRAW_BASE),HL
            XOR  A
            LD   (US_R),A
US_ROW:     LD   A,(US_R)
            LD   E,A
            LD   D,0
            LD   HL,DIRTY
            ADD  HL,DE
            LD   A,(HL)
            OR   A
            JP   Z,US_NEXTROW
            LD   (US_M),A
            LD   (DS_ROW),A             ; (overwritten below; keeps A free)
            LD   A,(US_R)
            LD   (DS_ROW),A
            LD   B,0                    ; tiles of the dirty cells
US_TC:      LD   A,(US_M)
            LD   C,A
            LD   A,B
            CALL US_BITTEST             ; Z clear if column B is dirty
            JR   Z,US_TNEXT
            PUSH BC
            LD   A,(US_R)
            LD   C,A
            CALL DRAW_CELL              ; B = column, C = row
            POP  BC
US_TNEXT:   INC  B
            LD   A,B
            CP   8
            JR   NZ,US_TC
            LD   A,(G_ACTIVE)           ; guard, then prince on top
            OR   A
            JR   Z,US_NOG3
            CALL SET_GUARD_SPR
            CALL DRAW_SPRITE
US_NOG3:    CALL SET_PRINCE_SPR
            CALL DRAW_SPRITE
            LD   A,(US_R)               ; copy the dirty cells to the screen
            CALL SET_BANK
            LD   B,0
US_CC:      LD   A,(US_M)
            LD   C,A
            LD   A,B
            CALL US_BITTEST
            JR   Z,US_CNEXT
            PUSH BC
            CALL COPY_CELL
            POP  BC
US_CNEXT:   INC  B
            LD   A,B
            CP   8
            JR   NZ,US_CC
US_NEXTROW: LD   A,(US_R)
            INC  A
            LD   (US_R),A
            CP   3
            JP   NZ,US_ROW
            XOR  A
            LD   (DS_MODE),A
            LD   HL,VRAM
            LD   (DRAW_BASE),HL
            RET

; A = column, C = mask byte -> Z set if that column's bit is clear
US_BITTEST: LD   D,A
            LD   A,C
            INC  D
US_BT1:     DEC  D
            JR   Z,US_BT2
            RRCA
            JR   US_BT1
US_BT2:     AND  1
            RET

; COPY_CELL - B = column: SHADOW cell -> screen cell (64 lines of 4 bytes, current bank)
COPY_CELL:  LD   A,B
            ADD  A,A
            ADD  A,A
            LD   C,A
            LD   B,0
            LD   HL,SHADOW
            ADD  HL,BC
            LD   DE,VRAM
            EX   DE,HL
            ADD  HL,BC
            EX   DE,HL                  ; HL = shadow, DE = screen
            LD   A,64
CC_LINE:    LDI
            LDI
            LDI
            LDI
            LD   BC,28
            ADD  HL,BC
            EX   DE,HL
            ADD  HL,BC
            EX   DE,HL
            DEC  A
            JR   NZ,CC_LINE
            RET

; MARK_BOX - set the DIRTY bits of every cell inside the pixel box ER_L..ER_R x ER_T..ER_B (clipped like ERASE_AT)
MARK_BOX:   LD   A,(ER_T)
            CP   192
            JR   C,MB_TOPOK
            LD   A,(ER_B)
            CP   192
            RET  NC
            XOR  A
            LD   (ER_T),A
MB_TOPOK:   LD   A,(ER_B)
            CP   192
            JR   C,MB_GO
            LD   A,191
            LD   (ER_B),A
MB_GO:      LD   A,(ER_L)
            RLCA
            RLCA
            RLCA
            AND  7
            LD   B,A                    ; B = first column
            LD   A,(ER_R)
            RLCA
            RLCA
            RLCA
            AND  7
            SUB  B
            INC  A
            LD   C,A                    ; C = column count
            XOR  A
MB_M1:      SCF
            RLA
            DEC  C
            JR   NZ,MB_M1               ; A = 2^count - 1
            INC  B
MB_M2:      DEC  B
            JR   Z,MB_M3
            ADD  A,A
            JR   MB_M2
MB_M3:      LD   E,A                    ; E = column mask
            LD   A,(ER_T)
            RLCA
            RLCA
            AND  3
            LD   C,A                    ; C = first row
            LD   A,(ER_B)
            RLCA
            RLCA
            AND  3
            SUB  C
            INC  A
            LD   B,A                    ; B = row count
            LD   HL,DIRTY
            LD   D,0
            PUSH BC
            LD   B,0
            ADD  HL,BC
            POP  BC
MB_ROW:     LD   A,(HL)
            OR   E
            LD   (HL),A
            INC  HL
            DJNZ MB_ROW
            RET

; ---------------------------------------------------------------------------
; DRAW_SPRITE - HL = frame: DEFB W,H,XO,YO then per line W image + W mask bytes.
; Drawn at reference box (SP_X,SP_Y); SP_FLIP mirrors about the box centre.
; Per line: shift mask + image into line buffers, then dest = (dest & ~mask) | image.
; Leaves the pixel box it covered in DS_BL/BR/BT/BB.
; ---------------------------------------------------------------------------
DRAW_SPRITE:
            LD   A,(HL)
            LD   (DS_W),A
            INC  HL
            LD   A,(HL)
            LD   (DS_N),A
            INC  HL
            LD   A,(HL)
            LD   (DS_XO),A
            INC  HL
            LD   A,(HL)
            INC  HL
            LD   (DS_SRC),HL
            LD   B,A                    ; top line = SP_Y + YO
            LD   A,(SP_Y)
            ADD  A,B
            LD   (DS_Y),A
            LD   (DS_BT),A
            LD   B,A
            LD   A,(DS_N)
            ADD  A,B
            DEC  A
            LD   (DS_BB),A
            LD   A,(SP_FLIP)            ; effective x offset
            OR   A
            LD   A,(DS_XO)
            JR   Z,DS_XOK
            LD   B,A                    ; mirrored: 16 - xo - 8*W
            LD   A,(DS_W)
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,B
            NEG
            ADD  A,16
DS_XOK:     LD   L,A                    ; left = SP_X + signed offset
            LD   H,0
            OR   A
            JP   P,DS_XPOS
            DEC  H
DS_XPOS:    LD   A,(SP_X)
            LD   E,A
            LD   D,0
            ADD  HL,DE
            BIT  7,H
            JR   Z,DS_NONEG
            LD   HL,0
DS_NONEG:   LD   A,(DS_W)               ; clamp left to 255 - 8*W
            ADD  A,A
            ADD  A,A
            ADD  A,A
            LD   B,A
            LD   A,255
            SUB  B
            LD   C,A
            LD   A,H
            OR   A
            JR   NZ,DS_CLAMP
            LD   A,L
            CP   C
            JR   C,DS_LEFTOK
            JR   Z,DS_LEFTOK
DS_CLAMP:   LD   L,C
DS_LEFTOK:  LD   A,L
            LD   (DS_BL),A
            AND  7
            LD   (DS_S),A               ; bit shift 0..7
            LD   A,L
            RRCA
            RRCA
            RRCA
            AND  31
            LD   (DS_D0),A              ; first destination byte
            LD   B,A
            LD   A,(DS_W)
            ADD  A,B
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,7
            LD   (DS_BR),A              ; right edge of the last byte written
            LD   A,(DS_S)               ; hi-part mask and the rotate entry point
            LD   E,A
            LD   D,0
            LD   HL,HM_TBL
            ADD  HL,DE
            LD   A,(HL)
            LD   (DS_HM),A
            LD   HL,ROT_END
            OR   A
            SBC  HL,DE
            LD   (ROT_TRAMP+1),HL
            LD   A,(DS_MODE)            ; 1 = only work out the box
            CP   1
            RET  Z
            LD   A,255
            LD   (DS_BANK),A
DS_LINE:    LD   A,(DS_Y)
            LD   B,A
            CP   192
            JP   NC,DS_NEXT             ; off the top or bottom: clip this line
            RLCA
            RLCA
            AND  3
            LD   C,A
            LD   A,(DS_MODE)            ; 2 = draw into SHADOW, only the lines of bank row DS_ROW
            OR   A
            JR   Z,DS_SCREEN
            LD   A,(DS_ROW)
            CP   C
            JP   NZ,DS_NEXT
            JR   DS_SAME
DS_SCREEN:  LD   A,(DS_BANK)
            CP   C
            JR   Z,DS_SAME
            LD   A,C
            LD   (DS_BANK),A
            CALL SET_BANK
DS_SAME:    LD   A,B                    ; destination pointer for this line
            AND  63
            LD   L,A
            LD   H,0
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            LD   DE,(DRAW_BASE)
            ADD  HL,DE
            LD   A,(DS_D0)
            LD   E,A
            LD   D,0
            ADD  HL,DE
            LD   (DS_DEST),HL
            LD   HL,(DS_SRC)            ; ---- mask bytes
            LD   A,(DS_W)
            LD   B,A
            LD   E,A
            LD   D,0
            ADD  HL,DE
            LD   IX,MBUF
            LD   A,(SP_FLIP)
            OR   A
            JR   Z,DS_MN
            ADD  HL,DE
            DEC  HL
            CALL SHIFT_FLIP
            JR   DS_MD
DS_MN:      CALL SHIFT_NORM
DS_MD:      LD   HL,(DS_SRC)            ; ---- image bytes
            LD   A,(DS_W)
            LD   B,A
            LD   E,A
            LD   D,0
            LD   IX,IBUF
            LD   A,(SP_FLIP)
            OR   A
            JR   Z,DS_IN
            ADD  HL,DE
            DEC  HL
            CALL SHIFT_FLIP
            JR   DS_APPLY
DS_IN:      CALL SHIFT_NORM
DS_APPLY:   LD   HL,(DS_DEST)
            LD   DE,MBUF
            LD   IY,IBUF
            LD   A,(DS_W)
            INC  A
            LD   B,A
AP_LOOP:    LD   A,(DE)
            CPL
            AND  (HL)
            OR   (IY+0)
            LD   (HL),A
            INC  HL
            INC  DE
            INC  IY
            DJNZ AP_LOOP
DS_NEXT:    LD   HL,(DS_SRC)            ; next source line = + 2*W
            LD   A,(DS_W)
            ADD  A,A
            LD   E,A
            LD   D,0
            ADD  HL,DE
            LD   (DS_SRC),HL
            LD   A,(DS_Y)
            INC  A
            LD   (DS_Y),A
            LD   A,(DS_N)
            DEC  A
            LD   (DS_N),A
            JP   NZ,DS_LINE
            RET

; SHIFT_NORM / SHIFT_FLIP: HL = first byte (flip: last byte, walking down), B = W,
; IX = output buffer (W+1 bytes).  Shifts the line right by DS_S bits.
SHIFT_NORM: LD   C,0
SN_LOOP:    LD   A,(HL)
            INC  HL
            CALL ROT_TRAMP
            LD   E,A
            LD   A,(DS_HM)
            AND  E
            OR   C
            LD   (IX+0),A
            INC  IX
            LD   A,(DS_HM)
            CPL
            AND  E
            LD   C,A
            DJNZ SN_LOOP
            LD   (IX+0),C
            RET
SHIFT_FLIP: LD   C,0
SF_LOOP:    LD   A,(HL)
            DEC  HL
            LD   E,A
            LD   D,REV_TBL/256
            LD   A,(DE)
            CALL ROT_TRAMP
            LD   E,A
            LD   A,(DS_HM)
            AND  E
            OR   C
            LD   (IX+0),A
            INC  IX
            LD   A,(DS_HM)
            CPL
            AND  E
            LD   C,A
            DJNZ SF_LOOP
            LD   (IX+0),C
            RET

ROT_TRAMP:  JP   0                      ; operand patched to ROT_END - shift
            RRCA
            RRCA
            RRCA
            RRCA
            RRCA
            RRCA
            RRCA
ROT_END:    RET
HM_TBL:     DEFB $FF,$7F,$3F,$1F,$0F,$07,$03,$01

; ---------------------------------------------------------------------------
; Game logic
; ---------------------------------------------------------------------------
; RESPAWN - restart the level: forget kills, prince to the start position, load the start room
RESPAWN:    LD   HL,ROOM_FLAGS
            LD   B,32
RS_CLR:     LD   (HL),0
            INC  HL
            DJNZ RS_CLR
            XOR  A
            LD   (PFACE),A
            LD   (PFRAME),A
            LD   (PSTATE),A
            LD   (PFS),A
            LD   (PSWORD),A
            LD   (RUNPH),A
            LD   (FALLN),A
            LD   HL,(LVL_START)         ; this level's start: room, X, floor row
            INC  HL
            INC  HL
            LD   A,(HL)                 ; floor row
            LD   (PROW),A
            RRCA
            RRCA
            AND  $C0
            ADD  A,18
            LD   (PY),A
            LD   HL,(LVL_START)
            INC  HL
            LD   A,(HL)
            LD   (PX),A
            LD   HL,(LVL_START)
            LD   A,(HL)
            JP   LOAD_ROOM

; SET_LEVEL - A = level number (0-based): point at its start data and its rooms
SET_LEVEL:  LD   (CUR_LEVEL),A
            ADD  A,A
            LD   E,A
            LD   D,0
            LD   HL,LEVEL_TBL
            ADD  HL,DE
            LD   E,(HL)
            INC  HL
            LD   D,(HL)
            LD   (LVL_START),DE
            INC  DE
            INC  DE
            INC  DE
            LD   (LVL_ROOMS),DE
            RET

; LOAD_ROOM - A = room number: copy its tiles + links, place its guard, draw it
LOAD_ROOM:  LD   (CUR_ROOM),A
            LD   L,A
            LD   H,0
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL                  ; room*32
            LD   DE,(LVL_ROOMS)
            ADD  HL,DE
            LD   DE,ROOM_MAP
            LD   BC,24
            LDIR
            LD   DE,NEIGH_L             ; L,R,U,D
            LD   BC,4
            LDIR
            LD   A,(HL)                 ; guard column
            INC  HL
            LD   B,(HL)                 ; guard row
            INC  HL
            PUSH AF
            LD   A,(HL)                 ; guard kind: 0 guard, 1 skeleton
            LD   (GKIND),A
            POP  AF
            CP   NONE
            JR   Z,LR_NOGUARD
            LD   C,A
            LD   A,1
            LD   (G_ACTIVE),A
            LD   A,C
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,8
            LD   (GX),A                 ; column*32 + 8
            LD   A,B
            LD   (GROW),A
            RRCA
            RRCA
            AND  $C0
            ADD  A,18
            LD   (GY),A
            LD   A,1
            LD   (GFACE),A
            XOR  A
            LD   (GFI),A
            LD   (GTMR),A
            LD   A,(CUR_ROOM)           ; killed before?
            LD   E,A
            LD   D,0
            LD   HL,ROOM_FLAGS
            ADD  HL,DE
            LD   A,(HL)
            AND  1
            JR   NZ,LR_DEAD
            LD   A,FR_GARDE
            LD   (GFRAME),A
            XOR  A
            LD   (GFS),A
            LD   A,(GKIND)
            OR   A
            LD   A,3
            JR   Z,LR_HP
            INC  A                      ; a skeleton takes 4 hits
LR_HP:      LD   (GHP),A
            JR   LR_DRAW
LR_DEAD:    LD   A,FS_DEAD
            LD   (GFS),A
            LD   A,FR_DEAD
            LD   (GFRAME),A
            XOR  A
            LD   (GHP),A
            JR   LR_DRAW
LR_NOGUARD: XOR  A
            LD   (G_ACTIVE),A
            LD   (GHP),A
LR_DRAW:    LD   A,(CUR_ROOM)           ; apply what happened here before: potion drunk (bit 1),
            LD   E,A                    ; loose tile already fallen (bit 2)
            LD   D,0
            LD   HL,ROOM_FLAGS
            ADD  HL,DE
            LD   A,(HL)
            LD   (LR_FL),A
            XOR  A
            LD   (LOOSE_ARM),A
            LD   (GATE_LVL),A          ; gates start shut in every room
            LD   (GATE_TGT),A
            LD   (GATE_HOLD),A
            LD   HL,ROOM_MAP
            LD   B,24
LR_FIX:     LD   A,(LR_FL)
            BIT  1,A
            JR   Z,LR_NOPOT
            RES  6,(HL)
LR_NOPOT:   LD   A,(LR_FL)
            BIT  2,A
            JR   Z,LR_NOLS
            LD   A,(HL)
            AND  $3F
            CP   T_LOOSE
            JR   NZ,LR_NOLS
            LD   A,(HL)
            AND  $C0                    ; fallen: empty, keep any decoration
            LD   (HL),A
LR_NOLS:    INC  HL
            DJNZ LR_FIX
            LD   A,200                  ; nothing of either sprite is on the new screen yet
            LD   (P_ENT+E_BT),A
            LD   (P_ENT+E_BB),A
            LD   (G_ENT+E_BT),A
            LD   (G_ENT+E_BB),A
            JP   RENDER_ROOM

; EDGE_CHECK - after a horizontal move: leave through the left/right edge if there is a room there
EDGE_CHECK: LD   A,(PX)
            CP   232
            JR   C,EC_LEFT
            LD   A,(NEIGH_R)
            CP   NONE
            RET  Z
            CALL LOAD_ROOM
            LD   A,8
            LD   (PX),A
            RET
EC_LEFT:    CP   5
            RET  NC
            LD   A,(NEIGH_L)
            CP   NONE
            RET  Z
            CALL LOAD_ROOM
            LD   A,228
            LD   (PX),A
            RET

; GET_TILE_X - like GET_TILE, but row 255 (= "above row 0") reads row 2 of the room above
GET_TILE_X: LD   A,C
            CP   255
            JP   NZ,GET_TILE
            LD   A,(NEIGH_U)
            LD   L,A
            LD   H,0
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            LD   DE,(LVL_ROOMS)
            ADD  HL,DE
            LD   DE,16
            ADD  HL,DE
            LD   E,B
            LD   D,0
            ADD  HL,DE
            LD   A,(HL)
            AND  $3F
            RET

UPDATE:     LD   A,(PSTATE)
            OR   A
            JR   Z,UPD_GROUND
            CP   1
            JP   Z,UPD_FALL
            CP   2
            JP   Z,UPD_JUMP
            CP   3
            JP   Z,UPD_CLIMB
            CP   4
            JP   Z,UPD_TURN
            CP   5
            JP   Z,UPD_LAND
            JP   UPD_CDOWN

; ---- on the ground ---------------------------------------------------------
UPD_GROUND: LD   A,(PSWORD)             ; sword out (or hurt/dead): fight controls
            OR   A
            JP   NZ,PRINCE_FIGHT
            LD   A,(PFS)
            CP   FS_HURT
            JP   NC,PRINCE_FIGHT
            LD   A,(KEYS)
            BIT  3,A                    ; D = draw the sword
            JR   Z,UG_NODRAW
            LD   A,1
            LD   (PSWORD),A
            LD   A,FS_DRAW
            LD   (PFS),A
            XOR  A
            LD   (PFI),A
            LD   (RUNPH),A
            LD   A,FR_DRAW1
            LD   (PFRAME),A
            LD   A,SND_DRAW
            JP   REQ_SND
UG_NODRAW:  LD   A,(KEYS)
            BIT  2,A                    ; jump pressed?
            JR   Z,UG_WALK
            AND  3
            CP   1
            JR   Z,UJ_L
            CP   2
            JR   Z,UJ_R
            CALL CAN_GRAB               ; ledge beside us one row up?
            JP   C,START_CLIMB
            XOR  A                      ; no: straight up hop
            LD   (JMOVE),A
            JR   UJ_GO
UJ_L:       LD   A,1
            LD   (PFACE),A
            LD   (JMOVE),A
            JR   UJ_GO
UJ_R:       XOR  A
            LD   (PFACE),A
            LD   A,1
            LD   (JMOVE),A
UJ_GO:      XOR  A
            LD   (JIDX),A
            LD   A,(RUNPH)              ; mid-run: running jump (8 px/frame); else standing jump (5)
            LD   B,5
            OR   A
            JR   Z,UJ_SPD
            CP   4
            JR   NC,UJ_SPD
            LD   B,8
UJ_SPD:     LD   A,B
            LD   (JSPD),A
            XOR  A
            LD   (RUNPH),A
            LD   A,2
            LD   (PSTATE),A
            JP   UPD_JUMP
UG_WALK:    LD   A,(KEYS)
            AND  3
            JP   Z,UG_RELEASE
            CP   3
            JP   Z,UG_RELEASE
            LD   B,0                    ; B = the way the key points
            CP   1
            JR   NZ,UW_FACE
            LD   B,1
UW_FACE:    LD   A,(PFACE)
            CP   B
            JR   Z,UW_SAME
            LD   A,B                    ; opposite key: turn around on the spot
            LD   (TURNTO),A
            XOR  A
            LD   (TIDX),A
            LD   (RUNPH),A
            LD   A,4
            LD   (PSTATE),A
            JP   UPD_TURN
UW_SAME:    LD   A,(RUNPH)              ; 0 stand, 1-2 start-up, 3 running, 4-5 stopping
            OR   A
            JR   Z,UW_P1
            CP   4
            JR   NC,UW_P1
            CP   3
            JR   Z,UW_RUN
            INC  A
            JR   UW_SETP
UW_P1:      LD   A,1
UW_SETP:    LD   (RUNPH),A
UW_RUN:     LD   A,(RUNPH)
            LD   E,A
            LD   D,0
            LD   HL,STEP_TBL
            ADD  HL,DE
            LD   A,(HL)
            CALL MOVE_FACING
            JR   C,UG_BLOCKED
            LD   A,(RUNPH)
            CP   1
            LD   B,FR_RUNST1
            JR   Z,UW_FR
            CP   2
            LD   B,FR_RUNST2
            JR   Z,UW_FR
            LD   A,(PFRAME)             ; running: cycle frames 1..4
            CP   4
            JR   NC,UW_F1
            OR   A
            JR   Z,UW_F1
            INC  A
            JR   UW_FS
UW_F1:      LD   A,1
UW_FS:      LD   B,A
UW_FR:      LD   A,B
            LD   (PFRAME),A
            CP   1                      ; footfalls on run frames 1 and 3
            JR   Z,UW_STEP
            CP   3
            JR   NZ,UG_FOOT
UW_STEP:    LD   A,SND_STEP
            CALL REQ_SND
            JR   UG_FOOT
UG_BLOCKED: XOR  A
            LD   (RUNPH),A
            LD   (PFRAME),A
            JR   UG_FOOT
UG_RELEASE: LD   A,(RUNPH)
            OR   A
            JR   Z,UG_IDLE
            CP   5
            JR   Z,UG_IDLE
            CP   4
            JR   Z,UR_S2
            LD   A,4                    ; was running: slide to a stop over 2 frames
            LD   (RUNPH),A
            LD   A,FR_STOP1
            LD   (PFRAME),A
            LD   A,3
            CALL MOVE_FACING
            JR   UG_FOOT
UR_S2:      LD   A,5
            LD   (RUNPH),A
            LD   A,FR_STOP2
            LD   (PFRAME),A
            LD   A,2
            CALL MOVE_FACING
            JR   UG_FOOT
UG_IDLE:    XOR  A
            LD   (RUNPH),A
            LD   (PFRAME),A
            LD   A,(KEYS)               ; S held with the sword away: climb down at an edge, else crouch
            BIT  4,A
            JR   Z,UG_FOOT
            CALL CAN_HANGDOWN
            JP   C,START_CDOWN
            CALL TRY_DRINK
            LD   A,FR_CROUCH
            LD   (PFRAME),A
UG_FOOT:    LD   A,(PX)                 ; floor under the centre of the body?
            ADD  A,8
            RLCA
            RLCA
            RLCA
            AND  7
            LD   B,A
            LD   A,(PROW)
            LD   C,A
            CALL GET_TILE
            CP   T_FLOOR
            JR   C,UG_LEDGE
            CP   T_SPIKES
            RET  C
UG_LEDGE:   LD   A,1
            LD   (PSTATE),A
            XOR  A
            LD   (RUNPH),A
            LD   (FALLN),A
            LD   A,FR_FALL
            LD   (PFRAME),A
            RET

; MOVE_FACING - A = pixels: step that far the way he faces.  Carry set if a wall stopped him.
MOVE_FACING:
            LD   (MV_STEP),A
            LD   A,(PFACE)
            OR   A
            LD   A,(PX)
            JR   NZ,MF_LEFT
            LD   B,A
            LD   A,(MV_STEP)
            ADD  A,B
            CP   MAXX+1
            JR   C,MF_TRY
            LD   A,MAXX
            JR   MF_TRY
MF_LEFT:    LD   B,A
            LD   A,(MV_STEP)
            LD   C,A
            LD   A,B
            SUB  C
            JR   NC,MF_TRY
            XOR  A
MF_TRY:     LD   (NEWX),A
            ADD  A,4                    ; left probe
            CALL PROBE_WALL
            RET  C
            LD   A,(NEWX)
            ADD  A,11                   ; right probe
            CALL PROBE_WALL
            RET  C
            LD   A,(NEWX)
            LD   (PX),A
            CALL EDGE_CHECK
            OR   A
            RET

; turning on the spot: 3 frames (the facing flips on the middle one), then straight on with the walk
UPD_TURN:   LD   A,(TIDX)
            CP   3
            JR   C,UT_SHOW
            XOR  A
            LD   (PSTATE),A
            LD   (PFRAME),A
            JP   UPD_GROUND
UT_SHOW:    LD   E,A
            LD   D,0
            LD   HL,TURN_FR
            ADD  HL,DE
            LD   A,(HL)
            LD   (PFRAME),A
            LD   A,(TIDX)
            CP   1
            JR   NZ,UT_NOF
            LD   A,(TURNTO)
            LD   (PFACE),A
UT_NOF:     LD   A,(TIDX)
            INC  A
            LD   (TIDX),A
            RET

; landing crouch: LTMR frames, then back to normal control
UPD_LAND:   LD   A,(LTMR)
            DEC  A
            LD   (LTMR),A
            RET  NZ
            XOR  A
            LD   (PSTATE),A
            LD   (PFRAME),A
            JP   UPD_GROUND

STEP_TBL:   DEFB 0,2,3,4,0,0            ; pixels per frame by run phase
TURN_FR:    DEFB FR_TURN1,FR_TURN2,FR_TURN3
JUMP_FR:    DEFB FR_JWIND,FR_JRISE,FR_JRISE,FR_JAPEX,FR_JAPEX,FR_JFALL,FR_JFALL,FR_JFALL

; PROBE_WALL - A = x pixel, row PROW: carry set if that cell is a wall
PROBE_WALL: RLCA
            RLCA
            RLCA
            AND  7
            LD   B,A
            LD   A,(PROW)
            LD   C,A
            CALL GET_TILE
            CP   T_WALL
            JR   Z,PW_HIT
            CP   T_WALLR
            JR   Z,PW_HIT
            CP   T_GATE0
            JR   C,PW_OK
            CP   T_GATE5
            JR   C,PW_HIT               ; a gate that is not fully up blocks
PW_OK:      OR   A                      ; clear carry
            RET
PW_HIT:     SCF
            RET

; ---- jumping: JUMP_LEN frames of vertical arc, JSTEP px forward per frame ----
UPD_JUMP:   LD   A,(JIDX)
            LD   E,A
            LD   D,0
            LD   HL,JUMP_FR
            ADD  HL,DE
            LD   A,(HL)
            LD   (PFRAME),A
            LD   HL,JUMP_DY
            ADD  HL,DE
            LD   B,(HL)
            LD   A,(PY)
            ADD  A,B                    ; signed step
            LD   (PY),A
            LD   A,(JMOVE)
            OR   A
            JR   Z,UJ_NOX
            LD   A,(PFACE)
            OR   A
            LD   A,(PX)
            JR   NZ,UJ_LEFTX
            LD   B,A
            LD   A,(JSPD)
            ADD  A,B
            CP   MAXX+1
            JR   C,UJ_TX
            LD   A,MAXX
            JR   UJ_TX
UJ_LEFTX:   LD   B,A
            LD   A,(JSPD)
            LD   C,A
            LD   A,B
            SUB  C
            JR   NC,UJ_TX
            XOR  A
UJ_TX:      LD   (NEWX),A
            ADD  A,4
            CALL PROBE_WALL
            JR   C,UJ_NOX               ; blocked by a wall: carry on straight up/down
            LD   A,(NEWX)
            ADD  A,11
            CALL PROBE_WALL
            JR   C,UJ_NOX
            LD   A,(NEWX)
            LD   (PX),A
            CALL EDGE_CHECK
UJ_NOX:     LD   A,(JIDX)
            INC  A
            LD   (JIDX),A
            CP   JUMP_LEN
            RET  C
            XOR  A                      ; arc finished: floor here? else fall
            LD   (PSTATE),A
            CALL UG_FOOT
            LD   A,(PSTATE)
            OR   A
            RET  NZ                     ; no floor: falling
            LD   A,5                    ; landed: a one-frame crouch
            LD   (PSTATE),A
            LD   A,1
            LD   (LTMR),A
            LD   A,FR_LAND
            LD   (PFRAME),A
            LD   A,SND_LAND
            JP   REQ_SND

JUMP_DY:    DEFB 248,251,254,255,1,2,5,8   ; -8 -5 -2 -1 +1 +2 +5 +8  (net 0)

; ---- ledge grab ---------------------------------------------------------------
; CAN_GRAB: carry set if the prince can jump up and grab a ledge.  Needs: a row
; above, open air (empty cell) directly above him, a floor in the next column in
; the direction he faces, and him standing within 16 px of that edge.
; Sets CL_HX (x while hanging), CL_FX (x when standing on top), CL_DIR.
CAN_GRAB:   LD   A,(PROW)
            OR   A
            JR   NZ,CG_OK
            LD   A,(NEIGH_U)            ; top row: only if there is a room above
            CP   NONE
            JP   Z,CG_NO
CG_OK:
            LD   A,(PX)
            ADD  A,8
            LD   (CG_CEN),A
            RLCA
            RLCA
            RLCA
            AND  7
            LD   (CG_C),A
            LD   A,(PFACE)
            LD   (CL_DIR),A
            OR   A
            JR   NZ,CG_LEFT
            LD   A,(CG_C)               ; facing right: target column c+1
            INC  A
            CP   ROOM_W
            JR   NC,CG_NO
            LD   (CG_TC),A
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,A                    ; boundary = TC*32
            LD   (CG_B),A
            SUB  16
            LD   B,A
            LD   A,(CG_CEN)
            CP   B
            JR   C,CG_NO                ; too far from the edge
            LD   A,(CG_B)
            SUB  10
            LD   (CL_HX),A
            ADD  A,6
            LD   (CL_FX),A
            JR   CG_TILES
CG_LEFT:    LD   A,(CG_C)               ; facing left: target column c-1
            OR   A
            JR   Z,CG_NO
            DEC  A
            LD   (CG_TC),A
            LD   A,(CG_C)
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,A                    ; boundary = c*32
            LD   (CG_B),A
            ADD  A,17
            LD   B,A
            LD   A,(CG_CEN)
            CP   B
            JR   NC,CG_NO
            LD   A,(CG_B)
            SUB  5
            LD   (CL_HX),A
            SUB  7
            LD   (CL_FX),A
CG_TILES:   LD   A,(PROW)
            DEC  A
            LD   C,A                    ; row above
            LD   A,(CG_TC)
            LD   B,A
            PUSH BC
            CALL GET_TILE_X             ; target must be a walkable floor
            POP  BC
            CP   T_FLOOR
            JR   C,CG_NO
            CP   T_SPIKES
            JR   NC,CG_NO
            LD   A,(CG_C)
            LD   B,A
            CALL GET_TILE_X             ; cell above us must be open air
            OR   A
            JR   NZ,CG_NO
            SCF
            RET
CG_NO:      OR   A
            RET

START_CLIMB:
            XOR  A
            LD   (CIDX),A
            LD   (RUNPH),A
            LD   A,3
            LD   (PSTATE),A
            LD   A,(PROW)
            OR   A
            JR   NZ,SC_SAME
            LD   A,(NEIGH_U)            ; climbing out of the top: switch to the room above and
            CALL LOAD_ROOM              ; carry on one screen (192 lines) lower, hanging off its floor
            LD   A,3
            LD   (PROW),A               ; (the climb ends one row up = row 2)
            LD   A,(PY)
            ADD  A,192
            LD   (PY),A
SC_SAME:    LD   A,(PY)
            LD   (CL_BASE),A
            ; falls through into UPD_CLIMB

; ---- climbing: jump up, hang, pull up (8 game frames) -----------------------------
UPD_CLIMB:  LD   A,(CIDX)
            CP   8
            JP   Z,UC_FINISH
            LD   E,A
            LD   D,0
            LD   HL,CL_FRAME
            ADD  HL,DE
            LD   A,(HL)
            LD   (PFRAME),A
            LD   HL,CL_DY
            ADD  HL,DE
            LD   B,(HL)                 ; height above the starting line
            LD   A,(CL_BASE)
            SUB  B
            LD   (PY),A
            LD   A,(CIDX)
            CP   2
            JR   C,UC_APPROACH
            CP   5
            JR   C,UC_AT_HX
            CP   7
            JR   Z,UC_AT_FX
            SUB  5                      ; steps 5,6: slide onto the floor
            LD   E,A
            LD   D,0
            LD   A,(CL_DIR)
            OR   A
            LD   HL,CL_OFF_R
            JR   Z,UC_OFFR
            LD   HL,CL_OFF_L
UC_OFFR:    ADD  HL,DE
            LD   A,(CL_HX)
            ADD  A,(HL)
            LD   (PX),A
            JR   UC_NEXT
UC_AT_FX:   LD   A,(CL_FX)
            LD   (PX),A
            JR   UC_NEXT
UC_AT_HX:   LD   A,(CL_HX)
            LD   (PX),A
            JR   UC_NEXT
UC_APPROACH:LD   A,(CL_HX)              ; steps 0,1: move to the hang position
            LD   B,A
            LD   A,(PX)
            CP   B
            JR   Z,UC_NEXT
            JR   C,UC_MORE
            SUB  B
            CP   9
            JR   C,UC_SNAP
            LD   A,(PX)
            SUB  8
            LD   (PX),A
            JR   UC_NEXT
UC_MORE:    LD   D,A
            LD   A,B
            SUB  D
            CP   9
            JR   C,UC_SNAP
            LD   A,D
            ADD  A,8
            LD   (PX),A
            JR   UC_NEXT
UC_SNAP:    LD   A,B
            LD   (PX),A
UC_NEXT:    LD   A,(CIDX)
            INC  A
            LD   (CIDX),A
            RET
UC_FINISH:  LD   A,(CL_FX)              ; standing on the upper floor
            LD   (PX),A
            LD   A,(CL_BASE)
            SUB  64
            LD   (PY),A
            LD   A,(PROW)
            DEC  A
            LD   (PROW),A
            XOR  A
            LD   (PSTATE),A
            LD   (PFRAME),A
            RET

; frame / rise-above-start for climb steps 0..6
CL_FRAME:   DEFB FR_JUMPUP,FR_JUMPUP,6,6,6,7,8,FR_CLIMB3
CL_DY:      DEFB 10,18,22,22,22,38,52,60
CL_OFF_R:   DEFB 2,4
CL_OFF_L:   DEFB 253,251                ; -3,-5

; ---- falling ----------------------------------------------------------------
UPD_FALL:   LD   A,FR_FALL
            LD   (PFRAME),A
            LD   A,(PY)
            ADD  A,FALLSTEP
            LD   (PY),A
            ADD  A,SPR_H-1              ; A = feet line
            CP   192
            JR   C,UF_ON
            LD   A,(NEIGH_D)            ; fell out of the bottom: room below?
            CP   NONE
            JP   Z,RESPAWN
            CALL LOAD_ROOM
            LD   A,(PY)
            SUB  192                    ; keep falling from just above its top (wraps, drawn clipped)
            LD   (PY),A
            RET
UF_ON:      LD   C,A
            AND  63
            CP   59                     ; walkway line inside a row
            RET  NZ
            LD   HL,FALLN               ; one more floor line passed
            INC  (HL)
            LD   A,C
            RLCA
            RLCA
            AND  3
            LD   C,A                    ; C = row under the feet
            LD   A,(PX)
            ADD  A,8
            RLCA
            RLCA
            RLCA
            AND  7
            LD   B,A
            PUSH BC
            CALL GET_TILE
            POP  BC
            CP   T_SPIKES
            JP   Z,RESPAWN
            CP   T_FLOOR
            RET  C
            CP   T_SPIKES
            RET  NC
            LD   A,C                    ; land on this floor
            LD   (PROW),A
            RRCA
            RRCA
            AND  $C0                    ; row*64
            ADD  A,18
            LD   (PY),A
            LD   A,(FALLN)              ; rows fallen: 1 = safe, 2 = -1 HP, 3+ = fatal
            CP   2
            LD   B,2                    ; B = landing crouch frames
            JR   C,UF_LAND
            CP   3
            JR   NC,UF_KILL
            LD   A,(PHP)
            DEC  A
            LD   (PHP),A
            JR   Z,UF_KILL
            LD   B,5                    ; hurt: a longer crouch
UF_LAND:    LD   A,5
            LD   (PSTATE),A
            LD   A,B
            LD   (LTMR),A
            LD   A,FR_LAND
            LD   (PFRAME),A
            LD   A,B                    ; a hurt landing sounds worse
            CP   5
            LD   A,SND_LAND
            JR   NZ,UF_SND
            LD   A,SND_FALLHURT
UF_SND:     JP   REQ_SND
UF_KILL:    LD   A,SND_DEATH
            CALL REQ_SND
            XOR  A
            LD   (PHP),A
            LD   (PSTATE),A
            LD   (PTMR),A
            LD   A,FS_DEAD
            LD   (PFS),A
            LD   A,FR_DEAD
            LD   (PFRAME),A
            RET

; ---------------------------------------------------------------------------
; Climbing down: S at a floor edge with open air in front -> hang from the ledge, let go
; ---------------------------------------------------------------------------
; CAN_HANGDOWN - carry set if he stands within 16 px of an edge he faces, with a gap beyond it.
; Sets CD_HX (x while hanging) and CD_FACE (he hangs facing back towards the floor).
CAN_HANGDOWN:
            LD   A,(PROW)
            CP   2
            JR   NZ,CH_OK
            LD   A,(NEIGH_D)            ; bottom row: only if there is a room below
            CP   NONE
            JP   Z,CH_NO
CH_OK:      LD   A,(PX)
            ADD  A,8
            LD   (CG_CEN),A
            RLCA
            RLCA
            RLCA
            AND  7
            LD   (CG_C),A
            LD   A,(PFACE)
            OR   A
            JR   NZ,CH_LEFT
            LD   A,(CG_C)               ; facing right: the gap cell is c+1
            INC  A
            CP   ROOM_W
            JR   NC,CH_NO
            LD   (CG_TC),A
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,A
            LD   (CG_B),A               ; edge = (c+1)*32
            SUB  16
            LD   B,A
            LD   A,(CG_CEN)
            CP   B
            JR   C,CH_NO                ; too far from the edge
            LD   A,(CG_B)
            SUB  5
            LD   (CD_HX),A
            LD   A,1
            LD   (CD_FACE),A
            JR   CH_TILES
CH_LEFT:    LD   A,(CG_C)               ; facing left: the gap cell is c-1
            OR   A
            JR   Z,CH_NO
            DEC  A
            LD   (CG_TC),A
            LD   A,(CG_C)
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,A
            LD   (CG_B),A               ; edge = c*32
            ADD  A,17
            LD   B,A
            LD   A,(CG_CEN)
            CP   B
            JR   NC,CH_NO
            LD   A,(CG_B)
            SUB  10
            LD   (CD_HX),A
            XOR  A
            LD   (CD_FACE),A
CH_TILES:   LD   A,(PROW)
            LD   C,A
            LD   A,(CG_TC)
            LD   B,A
            CALL GET_TILE               ; the cell beyond the edge must be open (not floor, not wall)
            CP   T_FLOOR
            JR   NC,CH_NOT03
            CP   T_WALL
            JR   Z,CH_NO
            CP   T_WALLR
            JR   Z,CH_NO
            JR   CH_YES
CH_NOT03:   CP   T_SPIKES
            JR   C,CH_NO                ; there is floor there
CH_YES:     SCF
            RET
CH_NO:      OR   A
            RET

START_CDOWN:
            XOR  A
            LD   (CIDX),A
            LD   (RUNPH),A
            LD   A,6
            LD   (PSTATE),A
            LD   A,(PY)
            LD   (CL_BASE),A
            LD   A,(CD_FACE)
            LD   (PFACE),A              ; he ends up facing the floor he is hanging from
            ; falls through into UPD_CDOWN
UPD_CDOWN:  LD   A,(CIDX)
            CP   5
            JR   Z,CD_LETGO
            LD   E,A
            LD   D,0
            LD   HL,CD_FRAME
            ADD  HL,DE
            LD   A,(HL)
            LD   (PFRAME),A
            LD   HL,CD_DY
            ADD  HL,DE
            LD   B,(HL)
            LD   A,(CL_BASE)
            ADD  A,B
            LD   (PY),A
            LD   A,(CD_HX)
            CALL APPROACH_X
            LD   A,(CIDX)
            INC  A
            LD   (CIDX),A
            RET
CD_LETGO:   LD   A,(PY)                 ; let go: drop (feet line = 3 mod 8 so landing lines line up)
            AND  $F8
            ADD  A,2
            LD   (PY),A
            XOR  A
            LD   (FALLN),A
            INC  A
            LD   (PSTATE),A
            LD   A,FR_FALL
            LD   (PFRAME),A
            RET

CD_FRAME:   DEFB FR_CLIMB3,8,7,6,6
CD_DY:      DEFB 4,12,26,42,42

; APPROACH_X - A = target x: move PX towards it by at most 8 px
APPROACH_X: LD   B,A
            LD   A,(PX)
            CP   B
            RET  Z
            JR   C,AX_MORE
            SUB  B
            CP   9
            JR   C,AX_SNAP
            LD   A,(PX)
            SUB  8
            LD   (PX),A
            RET
AX_MORE:    LD   D,A
            LD   A,B
            SUB  D
            CP   9
            JR   C,AX_SNAP
            LD   A,D
            ADD  A,8
            LD   (PX),A
            RET
AX_SNAP:    LD   A,B
            LD   (PX),A
            RET

; ---------------------------------------------------------------------------
; Level exit
; ---------------------------------------------------------------------------
CHECK_EXIT: LD   A,(PSTATE)
            OR   A
            RET  NZ
            LD   A,(PX)
            ADD  A,8
            RLCA
            RLCA
            RLCA
            AND  7
            LD   B,A
            LD   A,(PROW)
            LD   C,A
            CALL GET_TILE
            CP   T_EXIT
            RET  NZ
            LD   A,1
            LD   (WINFLAG),A
            RET

; DO_WIN - "LEVEL COMPLETE" screen, wait for A, then start the level again
DO_WIN:     XOR  A
DW_CLR:     PUSH AF
            CALL SET_BANK
            LD   HL,VRAM
            LD   DE,VRAM+1
            LD   BC,2047
            LD   (HL),0
            LDIR
            POP  AF
            INC  A
            CP   3
            JR   NZ,DW_CLR
            LD   A,1
            CALL SET_BANK
            LD   A,(CUR_LEVEL)
            ADD  A,'1'
            LD   (STR_WIN1+6),A         ; "LEVEL n COMPLETE"
            LD   A,(CUR_LEVEL)
            INC  A
            CP   LEVEL_COUNT
            LD   HL,STR_WIN1
            LD   B,8
            JR   NZ,DW_TXT
            CALL DRAW_INTRO_IMG         ; that was the last level: the palace picture and "YOU ESCAPED"
            LD   HL,STR_WIN3
            LD   B,10
            LD   A,45
            CALL PRINT_AT
            LD   HL,STR_WIN2
            LD   B,12
            LD   A,55
            CALL PRINT_AT
            JR   DW_SND
DW_TXT:     LD   A,16
            CALL PRINT_AT
            LD   HL,STR_WIN2
            LD   B,12
            LD   A,36
            CALL PRINT_AT
DW_SND:     LD   HL,S_WIN
            CALL PLAY_SEQ
DW_REL:     CALL WAIT_FRAME             ; wait for A to be let go, then pressed
            LD   A,(KEYROW_A)
            BIT  KEY_A_BIT,A
            JR   Z,DW_REL
DW_KEY:     CALL WAIT_FRAME
            LD   A,(KEYROW_A)
            BIT  KEY_A_BIT,A
            JR   NZ,DW_KEY
            XOR  A
            LD   (WINFLAG),A
            INC  A
            LD   (JPREV),A              ; (A is still down: do not count it as a jump press)
            LD   A,(CUR_LEVEL)          ; next level, or round to the first again
            INC  A
            CP   LEVEL_COUNT
            JR   C,DW_NEXT
            XOR  A
DW_NEXT:    CALL SET_LEVEL
            JP   RESET_FIGHT

; ---------------------------------------------------------------------------
; Chompers: every chomper cycles open -> half -> SHUT -> half -> open over 16 frames, each one
; offset by column*5 frames.  Standing in one while it is shut is fatal.
; ---------------------------------------------------------------------------
CHECK_CHOMP:
            LD   A,(CHOMP_T)
            INC  A
            AND  15
            LD   (CHOMP_T),A
            XOR  A
            LD   (CC_I),A
CC_LOOP:    LD   A,(CC_I)
            LD   E,A
            LD   D,0
            LD   HL,ROOM_MAP
            ADD  HL,DE
            LD   A,(HL)
            AND  $3F
            CP   T_CHOMP0
            JR   C,CC_NEXT
            CP   T_CHOMP2+1
            JR   NC,CC_NEXT
            LD   A,(CC_I)               ; phase = (frame + column*5) mod 16
            AND  7
            LD   B,A
            ADD  A,A
            ADD  A,A
            ADD  A,B
            LD   B,A
            LD   A,(CHOMP_T)
            ADD  A,B
            AND  15
            LD   B,0                    ; B = jaw state 0 open, 1 half, 2 shut
            CP   8
            JR   C,CC_SET
            INC  B
            CP   9
            JR   C,CC_SET               ; phase 8: half closed
            INC  B
            CP   12
            JR   C,CC_SET
            DEC  B
            CP   13
            JR   C,CC_SET
            LD   B,0
CC_SET:     LD   A,T_CHOMP0
            ADD  A,B
            LD   B,A                    ; B = wanted tile
            LD   A,(HL)
            AND  $3F
            CP   B
            JR   Z,CC_NEXT
            LD   A,(HL)
            AND  $C0
            OR   B
            LD   (HL),A
            LD   A,(CC_I)
            AND  7
            LD   B,A
            LD   A,(CC_I)
            RRCA
            RRCA
            RRCA
            AND  3
            LD   C,A
            CALL DRAW_CELL
CC_NEXT:    LD   A,(CC_I)
            INC  A
            LD   (CC_I),A
            CP   24
            JR   NZ,CC_LOOP
            LD   A,(PSTATE)             ; on the ground in a shut chomper: dead
            OR   A
            RET  NZ
            LD   A,(PFS)
            CP   FS_DEAD
            RET  Z
            LD   A,(PX)
            ADD  A,8
            RLCA
            RLCA
            RLCA
            AND  7
            LD   B,A
            LD   A,(PROW)
            LD   C,A
            CALL GET_TILE
            CP   T_CHOMP2
            RET  NZ
            XOR  A
            LD   (PHP),A
            LD   (PTMR),A
            LD   (PSWORD),A
            LD   A,FS_DEAD
            LD   (PFS),A
            LD   A,FR_DEAD
            LD   (PFRAME),A
            LD   A,SND_DEATH
            JP   REQ_SND

; ---------------------------------------------------------------------------
; Gates and plates (all gates in a room move together: GATE_LVL 0 = shut .. 5 = fully up)
; ---------------------------------------------------------------------------
CHECK_GATES:
            LD   A,(PSTATE)             ; is he standing on a plate?
            OR   A
            JR   NZ,GT_TIMER
            LD   A,(PX)
            ADD  A,8
            RLCA
            RLCA
            RLCA
            AND  7
            LD   B,A
            LD   A,(PROW)
            LD   C,A
            PUSH BC
            CALL GET_TILE
            POP  BC
            CP   T_PLATE
            JR   Z,GT_PRESS
            CP   T_PLATEON
            JR   NZ,GT_TIMER
            LD   A,PLATE_HOLD           ; standing on a pressed plate keeps the gates up
            LD   (GATE_HOLD),A
            JR   GT_TIMER
GT_PRESS:   LD   A,C                    ; press it: the plate sinks, the gates start to rise
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,B
            LD   E,A
            LD   D,0
            LD   HL,ROOM_MAP
            ADD  HL,DE
            LD   A,(HL)
            AND  $C0
            OR   T_PLATEON
            LD   (HL),A
            LD   A,5
            LD   (GATE_TGT),A
            LD   A,PLATE_HOLD
            LD   (GATE_HOLD),A
            CALL DRAW_CELL
            LD   A,SND_GATE
            CALL REQ_SND
GT_TIMER:   LD   A,(GATE_TGT)
            OR   A
            JR   Z,GT_STEP
            LD   A,(GATE_LVL)
            CP   5
            JR   NZ,GT_STEP
            LD   A,(GATE_HOLD)
            OR   A
            JR   Z,GT_TRYCLOSE
            DEC  A
            LD   (GATE_HOLD),A
            JR   GT_STEP
GT_TRYCLOSE:
            CALL PRINCE_IN_GATE         ; never slam a gate on someone standing in it
            JR   C,GT_STEP
            XOR  A
            LD   (GATE_TGT),A
GT_STEP:    LD   A,(GATE_LVL)
            LD   B,A
            LD   A,(GATE_TGT)
            CP   B
            RET  Z
            JR   C,GT_DOWN
            INC  B
            JR   GT_SET
GT_DOWN:    DEC  B
GT_SET:     LD   A,B
            LD   (GATE_LVL),A
            CALL SET_GATES
            LD   A,SND_GATE
            CALL REQ_SND
            LD   A,(GATE_LVL)
            OR   A
            RET  NZ
            JP   RESET_PLATES           ; shut again: the plates pop back up

PRINCE_IN_GATE:
            LD   A,(PX)
            ADD  A,8
            RLCA
            RLCA
            RLCA
            AND  7
            LD   B,A
            LD   A,(PROW)
            LD   C,A
            CALL GET_TILE
            CP   T_GATE0
            JR   C,PG_NO
            CP   T_GATE5+1
            JR   NC,PG_NO
            SCF
            RET
PG_NO:      OR   A
            RET

; SET_GATES - every gate cell gets the current opening and is redrawn
SET_GATES:  XOR  A
            LD   (SG_I),A
SG_LOOP:    LD   A,(SG_I)
            LD   E,A
            LD   D,0
            LD   HL,ROOM_MAP
            ADD  HL,DE
            LD   A,(HL)
            AND  $3F
            CP   T_GATE0
            JR   C,SG_NEXT
            CP   T_GATE5+1
            JR   NC,SG_NEXT
            LD   A,(GATE_LVL)
            ADD  A,T_GATE0
            LD   (HL),A
            LD   A,(SG_I)
            AND  7
            LD   B,A
            LD   A,(SG_I)
            RRCA
            RRCA
            RRCA
            AND  3
            LD   C,A
            CALL DRAW_CELL
SG_NEXT:    LD   A,(SG_I)
            INC  A
            LD   (SG_I),A
            CP   24
            JR   NZ,SG_LOOP
            RET

; RESET_PLATES - pressed plates come back up
RESET_PLATES:
            XOR  A
            LD   (SG_I),A
RP_LOOP:    LD   A,(SG_I)
            LD   E,A
            LD   D,0
            LD   HL,ROOM_MAP
            ADD  HL,DE
            LD   A,(HL)
            AND  $3F
            CP   T_PLATEON
            JR   NZ,RP_NEXT
            LD   A,(HL)
            AND  $C0
            OR   T_PLATE
            LD   (HL),A
            LD   A,(SG_I)
            AND  7
            LD   B,A
            LD   A,(SG_I)
            RRCA
            RRCA
            RRCA
            AND  3
            LD   C,A
            CALL DRAW_CELL
RP_NEXT:    LD   A,(SG_I)
            INC  A
            LD   (SG_I),A
            CP   24
            JR   NZ,RP_LOOP
            RET

; CHECK_LOOSE - step on a loose tile and it crumbles 4 frames later (the tile becomes empty for good)
CHECK_LOOSE:
            LD   A,(LOOSE_ARM)
            OR   A
            JR   Z,CL_SCAN
            DEC  A
            LD   (LOOSE_ARM),A
            RET  NZ
            LD   A,(LOOSE_ROW)          ; the countdown ran out: tile (col,row) falls
            ADD  A,A
            ADD  A,A
            ADD  A,A
            LD   B,A
            LD   A,(LOOSE_COL)
            ADD  A,B
            LD   E,A
            LD   D,0
            LD   HL,ROOM_MAP
            ADD  HL,DE
            LD   A,(HL)
            AND  $C0
            LD   (HL),A
            LD   A,(CUR_ROOM)
            LD   E,A
            LD   D,0
            LD   HL,ROOM_FLAGS
            ADD  HL,DE
            SET  2,(HL)
            LD   A,(LOOSE_COL)
            LD   B,A
            LD   A,(LOOSE_ROW)
            LD   C,A
            CALL DRAW_CELL
            LD   A,SND_LOOSE
            JP   REQ_SND
CL_SCAN:    LD   A,(PSTATE)
            OR   A
            RET  NZ
            LD   A,(PX)
            ADD  A,8
            RLCA
            RLCA
            RLCA
            AND  7
            LD   (LOOSE_COL),A
            LD   B,A
            LD   A,(PROW)
            LD   (LOOSE_ROW),A
            LD   C,A
            CALL GET_TILE
            CP   T_LOOSE
            RET  NZ
            LD   A,4
            LD   (LOOSE_ARM),A
            RET

; TRY_DRINK - crouching on a tile with a potion: +1 HP (not when already at full health)
TRY_DRINK:  LD   A,(PHP)
            CP   3
            RET  NC
            LD   A,(PX)
            ADD  A,8
            RLCA
            RLCA
            RLCA
            AND  7
            LD   B,A
            LD   A,(PROW)
            LD   C,A
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,B
            LD   E,A
            LD   D,0
            LD   HL,ROOM_MAP
            ADD  HL,DE
            BIT  6,(HL)
            RET  Z
            RES  6,(HL)
            LD   A,(PHP)
            INC  A
            LD   (PHP),A
            LD   A,(CUR_ROOM)
            LD   E,A
            LD   D,0
            LD   HL,ROOM_FLAGS
            ADD  HL,DE
            SET  1,(HL)
            CALL DRAW_CELL
            LD   A,SND_POTION
            JP   REQ_SND

; ---------------------------------------------------------------------------
; Sound.  The speaker is driven by two latch bits (D0 and D5, opposite phases); everything
; else on the latch stays as the graphics mode needs it (8).  Effects are short and blocking.
; Sequence data = triples PITCH,COUNT,REPEAT (pitch 255 = noise burst of COUNT half-cycles,
; pitch 0 ends).  Delay per half-cycle = about 16*PITCH*REPEAT T-states.
; ---------------------------------------------------------------------------
REQ_SND:    LD   B,A                    ; keep the most important request of the frame
            LD   A,(SND_REQ)
            CP   B
            RET  NC
            LD   A,B
            LD   (SND_REQ),A
            RET

PLAY_SOUND: LD   A,(SND_REQ)
            OR   A
            RET  Z
            LD   E,A
            LD   D,0
            XOR  A
            LD   (SND_REQ),A
            LD   HL,SND_TBL
            ADD  HL,DE
            ADD  HL,DE
            LD   E,(HL)
            INC  HL
            LD   D,(HL)
            EX   DE,HL
PLAY_SEQ:   LD   A,(HL)
            OR   A
            RET  Z
            LD   B,A
            INC  HL
            LD   C,(HL)
            INC  HL
            LD   D,(HL)
            INC  HL
            PUSH HL
            LD   A,B
            CP   255
            JR   Z,PS_NOISE
            CALL BEEP
            JR   PS_NEXT
PS_NOISE:   CALL NOISE
PS_NEXT:    POP  HL
            JR   PLAY_SEQ

; BEEP - B = pitch (delay loop count), C = half-cycles, D = delay repeats
BEEP:       LD   A,(SND_MUTE)
            OR   A
            RET  NZ
            LD   E,9                    ; 8 | D0
BP_HC:      LD   A,E
            LD   (LATCH),A
            XOR  $21                    ; 9 <-> $28 (8 | D5)
            LD   E,A
            LD   H,D
BP_R:       LD   L,B
BP_W:       DEC  L
            JR   NZ,BP_W
            DEC  H
            JR   NZ,BP_R
            DEC  C
            JR   NZ,BP_HC
            LD   A,8
            LD   (LATCH),A
            RET

; NOISE - C = half-cycles of random length (own generator: the game's random numbers stay put)
NOISE:      LD   A,(SND_MUTE)
            OR   A
            RET  NZ
            LD   E,9
NZ_HC:      LD   A,E
            LD   (LATCH),A
            XOR  $21
            LD   E,A
            LD   A,(NSEED)
            LD   B,A
            ADD  A,A
            ADD  A,A
            ADD  A,B
            ADD  A,31
            LD   (NSEED),A
            RLCA
            RLCA
            RLCA
            AND  $3F
            ADD  A,6
            LD   B,A
NZ_D:       DJNZ NZ_D
            DEC  C
            JR   NZ,NZ_HC
            LD   A,8
            LD   (LATCH),A
            RET

; CHECK_MUTE - M toggles the sound on and off
CHECK_MUTE: LD   A,(KEYROW_M)
            BIT  KEY_M_BIT,A
            LD   A,0
            JR   NZ,CM_UP
            INC  A
CM_UP:      LD   B,A                    ; B = 1 while M is down
            LD   A,(MPREV)
            LD   C,A
            LD   A,B
            LD   (MPREV),A
            LD   A,C
            OR   A
            RET  NZ
            LD   A,B
            OR   A
            RET  Z
            LD   A,(SND_MUTE)
            XOR  1
            LD   (SND_MUTE),A
            RET

SND_TBL:    DEFW 0,S_STEP,S_GATE,S_LAND,S_DRAW,S_PARRY,S_HIT,S_LOOSE,S_FALLHURT,S_POTION,S_DEATH
S_STEP:     DEFB 70,5,1,0
S_GATE:     DEFB 45,8,1,0
S_LAND:     DEFB 190,14,2,0
S_DRAW:     DEFB 70,12,1, 50,14,1, 36,16,1, 0
S_PARRY:    DEFB 28,40,1, 20,30,1, 0
S_HIT:      DEFB 255,110,0, 0
S_LOOSE:    DEFB 255,90,0, 180,10,2, 0
S_FALLHURT: DEFB 255,70,0, 200,20,3, 0
S_POTION:   DEFB 60,30,1, 48,36,1, 36,44,1, 0
S_DEATH:    DEFB 70,40,2, 90,40,2, 110,50,2, 150,60,2, 210,70,2, 0
S_WIN:      DEFB 210,125,1, 166,158,1, 139,188,1, 103,251,1, 0
S_TITLE:    DEFB 166,100,1, 139,120,1, 103,200,1, 0

; ---------------------------------------------------------------------------
; Title screen
; ---------------------------------------------------------------------------
TITLE_SCREEN:
            LD   HL,TITLE_MAP           ; backdrop: ledge with torches and a door, brick wall below
            LD   DE,ROOM_MAP
            LD   BC,24
            LDIR
            CALL RENDER_ROOM
            LD   A,1                    ; the middle band is for the lettering
            CALL SET_BANK
            LD   HL,VRAM
            LD   DE,VRAM+1
            LD   BC,2047
            LD   (HL),0
            LDIR
            LD   HL,STR_T1
            LD   B,7
            LD   A,2
            CALL PRINT_BIG
            LD   HL,STR_T2
            LD   B,8
            LD   A,20
            CALL PRINT_AT
            LD   HL,STR_T3
            LD   B,3
            LD   A,32
            CALL PRINT_AT
            LD   HL,STR_T4
            LD   B,3
            LD   A,40
            CALL PRINT_AT
            LD   HL,STR_T5
            LD   B,9
            LD   A,48
            CALL PRINT_AT
            LD   HL,S_TITLE
            CALL PLAY_SEQ
            XOR  A
            LD   (TS_T),A
TS_REL:     CALL WAIT_FRAME             ; let go of A first
            LD   A,(KEYROW_A)
            BIT  KEY_A_BIT,A
            JR   Z,TS_REL
TS_WAIT:    CALL WAIT_FRAME
            CALL CHECK_MUTE
            CALL ANIM_TORCH             ; the two torches flicker on the title screen too
            LD   A,(TS_T)               ; blink "PRESS A TO START" about twice a second
            INC  A
            LD   (TS_T),A
            LD   HL,STR_T6
            AND  8
            JR   NZ,TS_SHOW
            LD   HL,STR_BLANK
TS_SHOW:    LD   B,8
            LD   A,56
            CALL PRINT_AT
            LD   A,(KEYROW_A)
            BIT  KEY_A_BIT,A
            JR   NZ,TS_WAIT
            LD   A,1
            LD   (JPREV),A              ; (A is still down: not a jump press)
            RET

; ---------------------------------------------------------------------------
; Intro picture: 256 x INTRO_LINES mono bitmap (generated by make_intro.py), blinking "PRESS A" underneath
; ---------------------------------------------------------------------------
INTRO_SCREEN:
            CALL DRAW_INTRO_IMG
            XOR  A
            LD   (TS_T),A
            JR   IN_REL
DRAW_INTRO_IMG:
            LD   HL,INTRO_Z0            ; the picture is stored ZX0-compressed, one chunk per video bank:
            XOR  A                      ; unpack a chunk into SHADOW (free here), then copy it into its bank
            CALL IS_UNZ
            LD   HL,INTRO_Z1
            LD   A,1
            CALL IS_UNZ
            LD   HL,INTRO_Z2
            LD   A,2                    ; (bank 2 stays selected: captions go under the picture)
IS_UNZ:     PUSH AF
            LD   DE,SHADOW
            CALL DZX0_STANDARD          ; HL = compressed data, DE = where to unpack
            POP  AF
            CALL SET_BANK
            LD   HL,SHADOW
            LD   DE,VRAM
            LD   BC,2048
            LDIR
            RET

; ---------------------------------------------------------------------------
; ZX0 decoder by Einar Saukas & Urusergi, "standard" version (68 bytes) - BSD 3-Clause (see zx0_src/LICENSE)
;   HL = source address (compressed data), DE = destination address
; ---------------------------------------------------------------------------
DZX0_STANDARD:
            LD   BC,$FFFF               ; preserve default offset 1
            PUSH BC
            INC  BC
            LD   A,$80
DZX0S_LITERALS:
            CALL DZX0S_ELIAS            ; obtain length
            LDIR                        ; copy literals
            ADD  A,A                    ; copy from last offset or new offset?
            JR   C,DZX0S_NEW_OFFSET
            CALL DZX0S_ELIAS            ; obtain length
DZX0S_COPY: EX   (SP),HL                ; preserve source, restore offset
            PUSH HL                     ; preserve offset
            ADD  HL,DE                  ; calculate destination - offset
            LDIR                        ; copy from offset
            POP  HL                     ; restore offset
            EX   (SP),HL                ; preserve offset, restore source
            ADD  A,A                    ; copy from literals or new offset?
            JR   NC,DZX0S_LITERALS
DZX0S_NEW_OFFSET:
            POP  BC                     ; discard last offset
            LD   C,$FE                  ; prepare negative offset
            CALL DZX0S_ELIAS_LOOP       ; obtain offset MSB
            INC  C
            RET  Z                      ; check end marker
            LD   B,C
            LD   C,(HL)                 ; obtain offset LSB
            INC  HL
            RR   B                      ; last offset bit becomes first length bit
            RR   C
            PUSH BC                     ; preserve new offset
            LD   BC,1                   ; obtain length
            CALL NC,DZX0S_ELIAS_BACKTRACK
            INC  BC
            JR   DZX0S_COPY
DZX0S_ELIAS:
            INC  C                      ; interlaced Elias gamma coding
DZX0S_ELIAS_LOOP:
            ADD  A,A
            JR   NZ,DZX0S_ELIAS_SKIP
            LD   A,(HL)                 ; load another group of 8 bits
            INC  HL
            RLA
DZX0S_ELIAS_SKIP:
            RET  C
DZX0S_ELIAS_BACKTRACK:
            ADD  A,A
            RL   C
            RL   B
            JR   DZX0S_ELIAS_LOOP

IN_REL:     CALL WAIT_FRAME             ; let go of A first
            LD   A,(KEYROW_A)
            BIT  KEY_A_BIT,A
            JR   Z,IN_REL
IN_WAIT:    CALL WAIT_FRAME
            CALL CHECK_MUTE
            LD   A,(TS_T)
            INC  A
            LD   (TS_T),A
            LD   HL,STR_T6
            AND  8
            JR   NZ,IN_SHOW
            LD   HL,STR_BLANK
IN_SHOW:    LD   B,8
            LD   A,54
            CALL PRINT_AT
            LD   A,(KEYROW_123)         ; 1 / 2 / 3 choose the start level
            LD   B,0
            BIT  4,A
            JR   Z,IN_LV
            INC  B
            BIT  1,A                    ; key 2 = D1 (D2 is unused on this row)
            JR   Z,IN_LV
            INC  B
            BIT  3,A
            JR   Z,IN_LV
            JR   IN_NOLV
IN_LV:      LD   A,B
            CP   LEVEL_COUNT
            JR   NC,IN_NOLV
            LD   (START_LV),A
IN_NOLV:    LD   A,(START_LV)
            ADD  A,'1'
            LD   (STR_LVHINT+16),A
            LD   HL,STR_LVHINT
            LD   B,7
            LD   A,44
            CALL PRINT_AT
            LD   A,(KEYROW_A)
            BIT  KEY_A_BIT,A
            JR   NZ,IN_WAIT
            RET

; PRINT_BIG - like PRINT_AT but every glyph is drawn double size (16 x 16)
PRINT_BIG:  LD   (PA_LINE),A
            LD   A,B
            LD   (PA_COL),A
PB_NEXT:    LD   A,(HL)
            OR   A
            RET  Z
            INC  HL
            PUSH HL
            CP   ' '
            JR   Z,PB_SP
            CP   '0'
            JR   C,PB_SP
            CP   'A'
            JR   NC,PB_LET
            SUB  '0'
            ADD  A,26
            JR   PB_GOT
PB_LET:     SUB  'A'
            JR   PB_GOT
PB_SP:      LD   A,36
PB_GOT:     LD   L,A
            LD   H,0
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            LD   DE,FONT
            ADD  HL,DE
            PUSH HL
            LD   A,(PA_LINE)
            LD   L,A
            LD   H,0
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            LD   DE,VRAM
            ADD  HL,DE
            LD   A,(PA_COL)
            LD   E,A
            LD   D,0
            ADD  HL,DE
            EX   DE,HL                  ; DE = destination
            POP  HL                     ; HL = glyph
            LD   B,8
PB_ROW:     LD   A,(HL)
            INC  HL
            PUSH HL
            PUSH BC
            CALL EXP8                   ; HL = the 8 bits doubled to 16
            LD   A,H
            LD   (DE),A
            INC  DE
            LD   A,L
            LD   (DE),A
            LD   A,E
            ADD  A,31
            LD   E,A
            JR   NC,PB_N1
            INC  D
PB_N1:      LD   A,H                    ; second copy on the next line
            LD   (DE),A
            INC  DE
            LD   A,L
            LD   (DE),A
            LD   A,E
            ADD  A,31
            LD   E,A
            JR   NC,PB_N2
            INC  D
PB_N2:      POP  BC
            POP  HL
            DJNZ PB_ROW
            LD   A,(PA_COL)
            INC  A
            INC  A
            LD   (PA_COL),A
            POP  HL
            JR   PB_NEXT

; EXP8 - A = 8 bits -> HL = 16 bits with every bit doubled
EXP8:       LD   C,A
            LD   HL,0
            LD   B,8
EX_L:       RL   C
            SBC  A,A
            AND  3
            ADD  HL,HL
            ADD  HL,HL
            OR   L
            LD   L,A
            DJNZ EX_L
            RET

TITLE_MAP:  DEFB T_FLOORL+T_TORCH,T_FLOOR,T_FLOOR,T_EXIT,T_FLOOR,T_FLOOR,T_FLOOR,T_FLOOR+T_TORCH
            DEFB T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY
            DEFB T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL
STR_T1:     DEFM "VZ PRINCE"
            DEFB 0
STR_T2:     DEFM "A DUNGEON ESCAPE"
            DEFB 0
STR_T3:     DEFM "Z X MOVE  A JUMP  S CROUCH"
            DEFB 0
STR_T4:     DEFM "D SWORD  A STRIKE  S PARRY"
            DEFB 0
STR_T5:     DEFM "M SOUND ON OFF"
            DEFB 0
STR_LVHINT: DEFM "1 2 3 FOR LEVEL 1"
            DEFB 0
STR_T6:     DEFM "PRESS A TO START"
            DEFB 0
STR_BLANK:  DEFM "                "
            DEFB 0

; PRINT_AT - HL = string (A-Z, 0-9, space; 0 ends), B = start byte column, A = first line in the
;            bank that is currently selected
PRINT_AT:   LD   (PA_LINE),A
            LD   A,B
            LD   (PA_COL),A
PA_NEXT:    LD   A,(HL)
            OR   A
            RET  Z
            INC  HL
            PUSH HL
            CP   ' '
            JR   Z,PA_SP
            CP   '0'
            JR   C,PA_SP
            CP   'A'
            JR   NC,PA_LET
            SUB  '0'
            ADD  A,26
            JR   PA_GOT
PA_LET:     SUB  'A'
            JR   PA_GOT
PA_SP:      LD   A,36
PA_GOT:     LD   L,A
            LD   H,0
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            LD   DE,FONT
            ADD  HL,DE
            PUSH HL                     ; glyph
            LD   A,(PA_LINE)
            LD   L,A
            LD   H,0
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            LD   DE,VRAM
            ADD  HL,DE
            LD   A,(PA_COL)
            LD   E,A
            LD   D,0
            ADD  HL,DE
            EX   DE,HL                  ; DE = destination
            POP  HL
            LD   B,8
PA_ROW:     LD   A,(HL)
            LD   (DE),A
            INC  HL
            LD   A,E
            ADD  A,32
            LD   E,A
            JR   NC,PA_NC
            INC  D
PA_NC:      DJNZ PA_ROW
            LD   A,(PA_COL)
            INC  A
            LD   (PA_COL),A
            POP  HL
            JR   PA_NEXT

STR_WIN1:   DEFM "LEVEL 1 COMPLETE"
            DEFB 0
STR_WIN3:   DEFM "YOU ESCAPED"
            DEFB 0
STR_WIN2:   DEFM "PRESS A"
            DEFB 0

; ---------------------------------------------------------------------------
; Fighting.  IX = the fighter acting, IY = his opponent.
; ---------------------------------------------------------------------------
RESET_FIGHT:
            CALL RESPAWN
            LD   A,3
            LD   (PHP),A
            XOR  A
            LD   (PTMR),A
            RET

FACE_OPP:   LD   A,(IY+E_X)
            CP   (IX+E_X)
            LD   A,0
            JR   NC,FO_SET
            INC  A
FO_SET:     LD   (IX+E_FACE),A
            RET

; DIST - A = |X(IX) - X(IY)|, carry set when the opponent is on the left
DIST:       LD   A,(IY+E_X)
            SUB  (IX+E_X)
            RET  NC
            NEG
            SCF
            RET

; FIGHT_MOVE - B = dx (signed): step if there is floor and he stays MIN_SEP away
FIGHT_MOVE: LD   A,B
            LD   (FM_DX),A
            CALL DIST
            LD   C,A
            LD   A,0
            RLA                         ; 1 if the opponent is on the left
            LD   D,A
            LD   A,(FM_DX)
            RLCA
            AND  1                      ; 1 if stepping left
            XOR  D
            JR   NZ,FM_FREE             ; stepping away: always fine
            LD   A,C
            CP   MIN_SEP+FSTEP
            RET  C                      ; would get too close
FM_FREE:    LD   A,(IX+E_X)
            LD   B,A
            LD   A,(FM_DX)
            ADD  A,B
            CP   MAXX+1
            RET  NC
            LD   (FM_NX),A
            ADD  A,8
            RLCA
            RLCA
            RLCA
            AND  7
            LD   B,A
            LD   A,(IX+E_ROW)
            LD   C,A
            CALL GET_TILE
            CP   T_FLOOR
            RET  C
            CP   T_SPIKES
            RET  NC
            CP   T_GATE0
            JR   C,FM_NOGATE
            CP   T_GATE5
            RET  C                      ; a closed gate is in the way
FM_NOGATE:  LD   A,(FM_NX)
            LD   (IX+E_X),A
            LD   A,(FM_DX)              ; show a step forward or a step back
            RLCA
            AND  1                      ; 1 = stepping left
            LD   B,A
            LD   A,(IX+E_FACE)          ; 1 = facing left
            XOR  B
            LD   A,FR_ADV
            JR   Z,FM_SF
            LD   A,FR_RETREAT
FM_SF:      LD   (IX+E_FRAME),A
            RET

; FIGHT_STRIKE - one tick of a strike: wind up (0,1), thrust (2) hits, recover (3)
FIGHT_STRIKE:
            LD   A,(IX+E_FI)
            CP   2
            JR   Z,FST_THRUST
            LD   (IX+E_FRAME),FR_ST1
            JR   FST_ADV
FST_THRUST: LD   (IX+E_FRAME),FR_ST2
            CALL TRY_HIT
FST_ADV:    INC  (IX+E_FI)
            LD   A,(IX+E_FI)
            CP   4
            RET  C
            LD   (IX+E_FS),FS_GARDE
            LD   (IX+E_FRAME),FR_GARDE
            RET

; TRY_HIT - the thrust of IX lands on IY unless he is parrying, dead or out of reach
TRY_HIT:    LD   A,(IY+E_FS)
            CP   FS_DEAD
            RET  Z
            CP   FS_PARRY
            JR   Z,TH_PARRY
            CALL DIST
            CP   HIT_RANGE+1
            RET  NC
            LD   A,SND_HIT
            CALL REQ_SND
            LD   A,(IY+E_HP)
            DEC  A
            LD   (IY+E_HP),A
            JR   Z,TH_DEAD
            LD   (IY+E_FS),FS_HURT
            LD   (IY+E_TMR),2
            LD   (IY+E_FRAME),FR_HURT
            LD   A,(IY+E_X)             ; recoil 4 px away from the attacker
            LD   B,A
            LD   A,(IX+E_FACE)
            OR   A
            LD   A,B
            JR   NZ,TH_L
            ADD  A,4
            JR   TH_S
TH_L:       SUB  4
TH_S:       CP   MAXX+1
            RET  NC
            LD   (IY+E_X),A
            RET
TH_PARRY:   CALL DIST                   ; blade met blade: a clink if he was within reach
            CP   HIT_RANGE+1
            RET  NC
            LD   A,SND_PARRY
            JP   REQ_SND
TH_DEAD:    PUSH IY                     ; the prince dying gets the death tune
            POP  HL
            LD   DE,P_ENT
            OR   A
            SBC  HL,DE
            LD   A,SND_DEATH
            CALL Z,REQ_SND
            LD   (IY+E_FS),FS_DEAD
            LD   (IY+E_TMR),0
            LD   (IY+E_FRAME),FR_DEAD
            RET

; PRINCE_FIGHT - controls while the sword is out (or while hurt / dead)
PRINCE_FIGHT:
            LD   IX,P_ENT
            LD   IY,G_ENT
            LD   A,(PFS)
            CP   FS_DEAD
            JP   Z,PF_DEAD
            CP   FS_HURT
            JP   Z,PF_HURT
            CALL FACE_OPP
            LD   A,(PFS)
            CP   FS_STRIKE
            JP   Z,FIGHT_STRIKE
            CP   FS_DRAW
            JP   Z,PF_DRAW
            CP   FS_SHEATH
            JP   Z,PF_SHEATH
            LD   A,(KEYS)
            BIT  3,A
            JR   Z,PF_NOSH
            LD   (IX+E_FS),FS_SHEATH    ; D again: put the sword away (2 frames)
            LD   (IX+E_FI),0
            LD   (IX+E_FRAME),FR_DRAW2
            LD   A,SND_DRAW
            JP   REQ_SND
PF_NOSH:    BIT  2,A
            JR   Z,PF_NOST
            LD   (IX+E_FS),FS_STRIKE    ; A: strike
            LD   (IX+E_FI),0
            JP   FIGHT_STRIKE
PF_NOST:    BIT  4,A
            JR   Z,PF_MV
            LD   (IX+E_FS),FS_PARRY     ; S held: parry
            LD   (IX+E_FRAME),FR_PARRY
            RET
PF_MV:      LD   (IX+E_FS),FS_GARDE
            LD   (IX+E_FRAME),FR_GARDE
            AND  3
            LD   B,FSTEP
            CP   2
            JR   Z,PF_GO
            LD   B,256-FSTEP
            CP   1
            JR   Z,PF_GO
            LD   A,3                    ; no key: the next step starts the cycle again at ADV / RETREAT
            LD   (PSWSTEP),A
            RET
PF_GO:      CALL FIGHT_MOVE
            LD   HL,PSWSTEP
            JP   STEP_ANIM

; STEP_ANIM - after FIGHT_MOVE (IX = fighter, HL = its step-phase counter): turn the single ADV / RETREAT frame into a walk
; cycle ADV|RETREAT, pass A, GARDE, pass B.  Does nothing when he did not move (FIGHT_MOVE left GARDE).
STEP_ANIM:  LD   A,(IX+E_FRAME)
            CP   FR_GARDE
            RET  Z
            LD   A,(HL)
            INC  A
            AND  3
            LD   (HL),A
            RET  Z
            LD   B,FR_SWA
            CP   1
            JR   Z,PF_STF
            LD   B,FR_GARDE
            CP   2
            JR   Z,PF_STF
            LD   B,FR_SWB
PF_STF:     LD   (IX+E_FRAME),B
            RET
PF_DRAW:    INC  (IX+E_FI)              ; draw: DRAW1 (set by D), DRAW2, then en garde
            LD   A,(IX+E_FI)
            CP   1
            LD   (IX+E_FRAME),FR_DRAW2
            RET  Z
            LD   (IX+E_FS),FS_GARDE
            LD   (IX+E_FRAME),FR_GARDE
            RET
PF_SHEATH:  INC  (IX+E_FI)              ; sheathe: DRAW2 (set by D), DRAW1, then stand
            LD   A,(IX+E_FI)
            CP   1
            LD   (IX+E_FRAME),FR_DRAW1
            RET  Z
            XOR  A
            LD   (PSWORD),A
            LD   (PFS),A
            LD   (PFRAME),A
            RET
PF_HURT:    DEC  (IX+E_TMR)
            RET  NZ
            XOR  A
            LD   (PFS),A
            LD   A,(PSWORD)
            OR   A
            LD   A,0
            JR   Z,PF_HF
            LD   A,FR_GARDE
PF_HF:      LD   (PFRAME),A
            RET
PF_DEAD:    INC  (IX+E_TMR)
            LD   A,(PTMR)
            CP   24
            RET  C
            JP   RESET_FIGHT

; GUARD_STEP - the guard's brain, once per game frame
GUARD_STEP: LD   A,(G_ACTIVE)
            OR   A
            RET  Z
            LD   IX,G_ENT
            LD   IY,P_ENT
            LD   A,(GFS)
            CP   FS_DEAD
            JR   NZ,GS_ALIVE
            LD   A,(CUR_ROOM)           ; remember the kill for this room
            LD   E,A
            LD   D,0
            LD   HL,ROOM_FLAGS
            ADD  HL,DE
            SET  0,(HL)
            RET
GS_ALIVE:
            CP   FS_HURT
            JP   Z,GS_HURT
            CALL FACE_OPP
            LD   A,(GFS)
            CP   FS_STRIKE
            JP   Z,FIGHT_STRIKE
            CP   FS_PARRY
            JP   Z,GS_PARHOLD
            LD   A,(PSTATE)             ; only fights a prince on the ground, same floor
            OR   A
            JP   NZ,GS_IDLE
            LD   A,(PROW)
            LD   B,A
            LD   A,(GROW)
            CP   B
            JP   NZ,GS_IDLE
            LD   A,(PFS)
            CP   FS_DEAD
            JR   Z,GS_IDLE
            CALL DIST
            CP   ENGAGE
            JR   NC,GS_IDLE
            CP   WALK_RANGE
            JR   C,GS_CLOSE
            CALL RAND8                  ; too far to hit: close in 3 times out of 4
            AND  3
            JR   Z,GS_IDLE
            LD   B,FSTEP
            LD   A,(GFACE)
            OR   A
            JR   Z,GS_MV
            LD   B,256-FSTEP
GS_MV:      LD   (IX+E_FS),FS_GARDE
            LD   (IX+E_FRAME),FR_GARDE
            CALL FIGHT_MOVE
            LD   HL,GSWSTEP
            JP   STEP_ANIM
GS_CLOSE:   LD   A,(PFS)                ; in reach: parry a strike half the time
            CP   FS_STRIKE
            JR   NZ,GS_NOPAR
            CALL RAND8
            AND  1
            JR   Z,GS_NOPAR
            LD   (IX+E_FS),FS_PARRY
            LD   (IX+E_TMR),3
            LD   (IX+E_FRAME),FR_PARRY
            RET
GS_NOPAR:   CALL RAND8
            AND  7
            CP   2
            JR   C,GS_STRIKE            ; 2 in 8: lunge
            CP   3
            JR   Z,GS_RETREAT           ; 1 in 8: step back
            JR   GS_IDLE
GS_STRIKE:  LD   (IX+E_FS),FS_STRIKE
            LD   (IX+E_FI),0
            JP   FIGHT_STRIKE
GS_RETREAT: LD   B,256-FSTEP
            LD   A,(GFACE)
            OR   A
            JR   Z,GS_RMV
            LD   B,FSTEP
GS_RMV:     LD   (IX+E_FS),FS_GARDE
            LD   (IX+E_FRAME),FR_GARDE
            CALL FIGHT_MOVE
            LD   HL,GSWSTEP
            JP   STEP_ANIM
GS_IDLE:    LD   (IX+E_FS),FS_GARDE
            LD   (IX+E_FRAME),FR_GARDE
            LD   A,3                    ; standing still: the next walk starts at ADV again
            LD   (GSWSTEP),A
            RET
GS_PARHOLD: LD   A,(IX+E_TMR)
            OR   A
            JR   Z,GS_IDLE
            DEC  A
            LD   (IX+E_TMR),A
            RET
GS_HURT:    DEC  (IX+E_TMR)
            RET  NZ
            JR   GS_IDLE

RAND8:      LD   A,(SEED)               ; x*5+17 mod 256, high bits returned
            LD   B,A
            ADD  A,A
            ADD  A,A
            ADD  A,B
            ADD  A,17
            LD   (SEED),A
            RLCA
            RLCA
            RLCA
            RET

; DRAW_STATUS - hit-point pips in the bottom corners (prince left, guard right)
DRAW_STATUS:
            LD   A,2
            CALL SET_BANK
            LD   HL,VRAM+56*32          ; a dark box behind each set of pips, nothing else
            CALL CLEAR_BOX
            LD   HL,VRAM+56*32+28
            CALL CLEAR_BOX
            LD   A,(PHP)
            LD   B,A
            LD   DE,VRAM+56*32
DST_P:      LD   A,B
            OR   A
            JR   Z,DST_G
            PUSH BC
            PUSH DE
            LD   HL,PIP_L
            CALL DRAW_PIP
            POP  DE
            POP  BC
            INC  DE
            DJNZ DST_P
DST_G:      LD   A,(GHP)
            LD   B,A
            LD   DE,VRAM+56*32+31
DST_Q:      LD   A,B
            OR   A
            RET  Z
            PUSH BC
            PUSH DE
            LD   HL,PIP_R
            CALL DRAW_PIP
            POP  DE
            POP  BC
            DEC  DE
            DJNZ DST_Q
            RET
; CLEAR_BOX - HL = top-left byte: clear 4 bytes x 8 lines
CLEAR_BOX:  LD   B,8
            LD   DE,29
CB_L:       LD   (HL),0
            INC  HL
            LD   (HL),0
            INC  HL
            LD   (HL),0
            INC  HL
            LD   (HL),0
            ADD  HL,DE
            DJNZ CB_L
            RET
DRAW_PIP:   LD   B,8
DP_L:       LD   A,(HL)
            LD   (DE),A
            INC  HL
            LD   A,E
            ADD  A,32
            LD   E,A
            JR   NC,DP_N
            INC  D
DP_N:       DJNZ DP_L
            RET
PIP_L:      DEFB $80,$C0,$E0,$F0,$F8,$FC,$FE,$FE
PIP_R:      DEFB $01,$03,$07,$0F,$1F,$3F,$7F,$7F

; ---------------------------------------------------------------------------
; Room 1 (8 x 3)
; ---------------------------------------------------------------------------
ROOM_MAP:   DEFS 24         ; the current room's tiles (copied from the level data by LOAD_ROOM)

; ---------------------------------------------------------------------------
; Variables (RAM).  P_ENT / G_ENT: X,Y,FACE,FRAME,FS,FI,HP,TMR,ROW,BL,BR,BT,BB
; ---------------------------------------------------------------------------
P_ENT:      DEFB 0,0,0,0,0,0,3,0,1,0,0,0,0
G_ENT:      DEFB 100,82,1,9,0,0,3,0,1,0,0,0,0
PX          EQU P_ENT+E_X
PY          EQU P_ENT+E_Y
PFACE       EQU P_ENT+E_FACE
PFRAME      EQU P_ENT+E_FRAME
PFS         EQU P_ENT+E_FS
PFI         EQU P_ENT+E_FI
PHP         EQU P_ENT+E_HP
PTMR        EQU P_ENT+E_TMR
PROW        EQU P_ENT+E_ROW
GX          EQU G_ENT+E_X
GY          EQU G_ENT+E_Y
GFACE       EQU G_ENT+E_FACE
GFRAME      EQU G_ENT+E_FRAME
GFS         EQU G_ENT+E_FS
GFI         EQU G_ENT+E_FI
GHP         EQU G_ENT+E_HP
GTMR        EQU G_ENT+E_TMR
GROW        EQU G_ENT+E_ROW

CUR_BANK:   DEFB 0
CUR_LEVEL:  DEFB 0
LVL_START:  DEFW 0          ; -> this level's start data (room, X, row)
LVL_ROOMS:  DEFW 0          ; -> this level's first room (32 bytes each)
CHOMP_T:    DEFB 0
CC_I:       DEFB 0
SND_REQ:    DEFB 0          ; most important sound asked for this frame
SND_MUTE:   DEFB 0
MPREV:      DEFB 0
NSEED:      DEFB 91
TS_T:       DEFB 0
GATE_LVL:   DEFB 0          ; 0 = gates shut .. 5 = fully raised
GATE_TGT:   DEFB 0
GATE_HOLD:  DEFB 0          ; frames left before they come down
SG_I:       DEFB 0
LOOSE_ARM:  DEFB 0          ; frames until the loose tile under him falls (0 = not armed)
LOOSE_COL:  DEFB 0
LOOSE_ROW:  DEFB 0
LR_FL:      DEFB 0
FALLN:      DEFB 0          ; floor lines passed in the current fall
CD_HX:      DEFB 0
CD_FACE:    DEFB 0
WINFLAG:    DEFB 0
TORCH_T:    DEFB 0          ; frame counter for the torch flicker
TORCH_PTR:  DEFW TORCH_BMP  ; flame picture currently used when a torch is drawn
START_LV:   DEFB 0          ; level chosen on the intro screen (keys 1-3)
PA_LINE:    DEFB 0
PA_COL:     DEFB 0
RUNPH:      DEFB 0          ; 0 stand, 1-2 run start-up, 3 running, 4-5 stopping
TURNTO:     DEFB 0
TIDX:       DEFB 0
LTMR:       DEFB 0          ; landing crouch frames left
JSPD:       DEFB 0          ; forward px per frame in the current jump
MV_STEP:    DEFB 0
CUR_ROOM:   DEFB 0
NEIGH_L:    DEFB 255
NEIGH_R:    DEFB 255
NEIGH_U:    DEFB 255
NEIGH_D:    DEFB 255
G_ACTIVE:   DEFB 0          ; 1 = this room has a guard
GKIND:      DEFB 0          ; 0 = guard, 1 = skeleton (room attribute kind=1)
ROOM_FLAGS: DEFS 32         ; per room: bit 0 guard killed, bit 1 potion drunk, bit 2 loose tile fallen
RR_ROW:     DEFB 0
KEYS:       DEFB 0
JPREV:      DEFB 0
DPREV:      DEFB 0
PSTATE:     DEFB 0          ; 0 ground, 1 falling, 2 jumping, 3 climbing, 4 turning, 5 landing, 6 hanging down
PSWORD:     DEFB 0          ; 1 = sword drawn
JMOVE:      DEFB 0
JIDX:       DEFB 0
CIDX:       DEFB 0
CL_BASE:    DEFB 0
CL_HX:      DEFB 0
CL_FX:      DEFB 0
CL_DIR:     DEFB 0
CG_CEN:     DEFB 0
CG_C:       DEFB 0
CG_TC:      DEFB 0
CG_B:       DEFB 0
NEWX:       DEFB 0
SEED:       DEFB 77
FM_DX:      DEFB 0
FM_NX:      DEFB 0
ER_L:       DEFB 0
ER_R:       DEFB 0
ER_T:       DEFB 0
ER_B:       DEFB 0
ER_C0:      DEFB 0
ER_C1:      DEFB 0
ER_R0:      DEFB 0
ER_R1:      DEFB 0
ER_C:       DEFB 0
SP_X:       DEFB 0
SP_Y:       DEFB 0
SP_FLIP:    DEFB 0
DS_W:       DEFB 0
DS_N:       DEFB 0
DS_XO:      DEFB 0
DS_SRC:     DEFW 0
DS_DEST:    DEFW 0
DS_Y:       DEFB 0
DS_BANK:    DEFB 0
DS_S:       DEFB 0
DS_D0:      DEFB 0
DS_HM:      DEFB 0
DS_BL:      DEFB 0
DS_BR:      DEFB 0
DS_BT:      DEFB 0
DS_BB:      DEFB 0
MBUF:       DEFS 16
IBUF:       DEFS 16
DRAW_BASE:  DEFW VRAM       ; where DRAW_CELL / DRAW_SPRITE write: VRAM, or SHADOW while composing
DS_MODE:    DEFB 0          ; 0 draw to the screen, 1 box only, 2 draw to SHADOW (one bank row)
DS_ROW:     DEFB 0
PSWSTEP:    DEFB 0          ; sword-walk step phase 0..3 (prince)
GSWSTEP:    DEFB 0          ; same for the guard / skeleton
DIRTY:      DEFS 3          ; per bank row: bit mask of the cells to rebuild this frame
US_R:       DEFB 0
US_M:       DEFB 0

            INCLUDE "_tiles.inc"
            INCLUDE "_sprites.inc"
            INCLUDE "_levels.inc"
            INCLUDE "_font.inc"
            INCLUDE "_intro.inc"

PROG_END:
SHADOW      EQU PROG_END    ; 2 KB RAM copy of one bank (64 lines x 32 bytes) right after the program: cells are composed here, not saved in the .VZ
