# gen_swstep_skel.py - append SKEL_SWSTEPA/B to skel.txt (the hand-edited skeleton file is never regenerated).
# Upper body = the existing SKEL_GARDE (same skull, ribs and sword); legs = single-pixel bones in two "feet passing" poses.
def grab(name):
    rows=[];on=False
    for l in open("skel.txt").read().replace("\r","").split("\n"):
        if l.startswith("["):
            if on: break
            on=l.startswith("["+name+" ")
        elif on and l.strip(): rows.append(l)
    return rows
have=open("skel.txt").read()
g=grab("SKEL_GARDE"); W=len(g[0])
def legs(left,right,lfoot,rfoot):
    # left/right: x of the bone for rows 21-25, 26-33, 34-39;  feet: (x0,x1) at rows 40-41
    out=[]
    for y in range(21,42):
        r=["."]*W
        if y<=39:
            band=0 if y<=25 else (1 if y<=33 else 2)
            r[left[band]]="#"; r[right[band]]="#"
        else:
            for x in range(lfoot[0],lfoot[1]+1): r[x]="#"
            for x in range(rfoot[0],rfoot[1]+1): r[x]="#"
        out.append("".join(r))
    return out
NEW={"SKEL_SWSTEPA":legs((2,3,4),(7,6,6),(3,6),(5,8)),      # legs together, feet passing
     "SKEL_SWSTEPB":legs((2,3,3),(7,7,8),(2,5),(7,10))}     # narrow stance, front foot a little ahead
add=""
for n,l in NEW.items():
    if "["+n+" " in have: continue
    add+="[%s xo=0 yo=0]\n%s\n\n"%(n,"\n".join(g[:21]+l))
if add: open("skel.txt","a").write(add)
print("added" if add else "already there")
