import re,sys,hashlib,json
from z80 import Z80Machine
base="pop12"
sym={}
for ln in open(base+".sym"):
    m_=re.match(r"(\w+)\s+EQU\s+([0-9A-F]+)H",ln.strip())
    if m_: sym[m_.group(1)]=int(m_.group(2),16)
m=Z80Machine()
m.set_memory_block(0x7B00,open(base+".bin","rb").read())
m.memory[sym["TITLE_SCREEN"]]=0xC9; m.memory[sym["INTRO_SCREEN"]]=0xC9
for a in (0x68FE,0x68FD,0x68FB,0x68F7,0x68EF,0x68DF,0x68BF,0x687F): m.memory[a]=0xFF
m.pc=0x7B00; m.sp=0x8000
SETB=sym["SET_BANK"]; FD=sym["FRAME_DONE"]
m.set_breakpoint(SETB); m.set_breakpoint(FD)
banks=[bytearray(2048) for _ in range(3)]
def poke(n,v): m.memory[sym[n]]=v
def keys(left=False,right=False,a=False,d=False,s=False):
    v=0xFF
    if left: v&=~(1<<4)
    if right: v&=~(1<<1)
    m.memory[0x68FB]=v
    w=0xFF
    if a: w&=~(1<<4)
    if d: w&=~(1<<3)
    if s: w&=~(1<<1)
    m.memory[0x68FD]=w
chunk=0; ticks=0
def pump():
    global chunk,ticks
    for _ in range(600000):
        chunk+=1
        m.memory[0x6800]=0x80 if chunk&1 else 0x00
        m.ticks_to_stop=1500
        m.run()
        ticks+=1500-max(0,m.ticks_to_stop) if False else 0
        if m.pc==SETB:
            old=m.memory[sym["CUR_BANK"]]; new=m.a
            banks[old][:]=bytes(m.memory[0x7000:0x7800]); m.memory[0x7000:0x7800]=bytes(banks[new])
            m.step_over_breakpoint()
        elif m.pc==FD:
            m.step_over_breakpoint(); return
    raise SystemExit("never finished")
def vram():
    cur=m.memory[sym["CUR_BANK"]]; banks[cur][:]=bytes(m.memory[0x7000:0x7800])
    return b"".join(bytes(b) for b in banks)
pump()
exp=open("intro_expected.bin","rb").read()
FDa=sym["FRAME_DONE"]
for nm in ("DRAW_INTRO_IMG",):
    m.sp-=2; m.memory[m.sp]=FDa&255; m.memory[m.sp+1]=FDa>>8; m.pc=sym[nm]
    pump()
v=vram()
bad=[i for i in range(6144) if v[i]!=exp[i]]
print("intro picture: %d of 6144 bytes differ from the original uncompressed picture"%len(bad))
assert not bad, "first differences at %s"%bad[:10]
assert m.memory[sym["CUR_BANK"]]==2, "bank 2 must stay selected for the captions"
print("INTRO ZX0 TEST OK (identical picture)")
