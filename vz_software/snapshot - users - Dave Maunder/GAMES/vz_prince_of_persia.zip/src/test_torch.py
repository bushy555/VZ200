import re
from z80 import Z80Machine
from PIL import Image
sym={}
for ln in open("pop12.sym"):
    m_=re.match(r"(\w+)\s+EQU\s+([0-9A-F]+)H",ln.strip())
    if m_: sym[m_.group(1)]=int(m_.group(2),16)
m=Z80Machine()
print("tick attrs:",[n for n in dir(m) if 'tick' in n.lower()])
m.set_memory_block(0x7B00,open("pop12.bin","rb").read())
m.memory[sym["TITLE_SCREEN"]]=0xC9   # tests start in the game, not on the title
m.memory[sym["INTRO_SCREEN"]]=0xC9   # ... nor on the intro picture
for a in (0x68FE,0x68FD,0x68FB,0x68F7,0x68EF,0x68DF,0x68BF,0x687F): m.memory[a]=0xFF
m.pc=0x7B00; m.sp=0x8000
SETB=sym["SET_BANK"]; FD=sym["FRAME_DONE"]
m.set_breakpoint(SETB); m.set_breakpoint(FD)
banks=[bytearray(2048) for _ in range(3)]
def mem(n): return m.memory[sym[n]]
def poke(n,v): m.memory[sym[n]]=v
def keys(left=False,right=False,a=False,d=False,s=False):
    v=0xFF
    if left:  v&=~(1<<4)
    if right: v&=~(1<<1)
    m.memory[0x68FB]=v
    w=0xFF
    if a: w&=~(1<<4)
    if d: w&=~(1<<3)
    if s: w&=~(1<<1)
    m.memory[0x68FD]=w
chunk=0
def pump():
    """run until FRAME_DONE; handle bank switching + fake vsync."""
    global chunk
    for _ in range(600000):
        chunk+=1
        m.memory[0x6800]=0x80 if chunk&1 else 0x00
        m.ticks_to_stop=1500
        m.run()
        if m.pc==SETB:
            old=m.memory[sym["CUR_BANK"]]; new=m.a
            banks[old][:]=bytes(m.memory[0x7000:0x7800]); m.memory[0x7000:0x7800]=bytes(banks[new])
            m.step_over_breakpoint()
        elif m.pc==FD:
            m.step_over_breakpoint(); return
    raise SystemExit("never finished")
def vram():
    cur=m.memory[sym["CUR_BANK"]]; banks[cur][:]=bytes(m.memory[0x7000:0x7800])
    return b"".join(bytes(b) for b in banks)
def lit(v,x,y): return bool(v[y*32+(x>>3)]&(0x80>>(x&7)))
def snap(name,crop=None):
    v=vram(); S=3; im=Image.new("RGB",(256*S,192*S),(0,96,0))
    for y in range(192):
        for x in range(256):
            if lit(v,x,y):
                for dy in range(S):
                    for dx in range(S): im.putpixel((x*S+dx,y*S+dy),(0,255,0))
    if crop: im=im.crop(crop)
    im.save(name)
def ent(base):
    a=sym[base]; k=("x","y","face","frame","fs","fi","hp","tmr","row")
    return {n:m.memory[a+i] for i,n in enumerate(k)}
P=lambda: ent("P_ENT"); G=lambda: ent("G_ENT")

pump()
def tele(px=100,gx=124,gro=0,sword=1,php=3,ghp=3):
    for n,v in (("PX",px),("PY",82),("PFACE",0),("PFRAME",0),("PROW",1),("PSTATE",0),("PFS",0),("PSWORD",sword),("PHP",php),("PTMR",0),
                ("GX",gx),("GY",82),("GFACE",1),("GFRAME",9),("GFS",0),("GHP",ghp),("GTMR",0),("GROW",gro),("JPREV",0),("DPREV",0)):
        poke(n,v)
def frames_(n,**k):
    for _ in range(n): keys(**k); pump()

from PIL import Image
RM=sym["ROOM_MAP"]; FL=sym["ROOM_FLAGS"]
def load_room(n):
    m.sp-=2; m.memory[m.sp]=FD&255; m.memory[m.sp+1]=FD>>8; m.a=n; m.pc=sym["LOAD_ROOM"]; pump()
def stage(px,py,row,face=0,hp=3,active=0):
    for n,v in (("PX",px),("PY",py),("PROW",row),("PFACE",face),("PFRAME",0),("PSTATE",0),("PFS",0),("PSWORD",0),("PHP",hp),
                ("JPREV",0),("DPREV",0),("RUNPH",0),("TIDX",0),("LTMR",0),("FALLN",0),("G_ACTIVE",active),("LOOSE_ARM",0)): poke(n,v)
    keys()
def run(n,**k):
    out=[]
    for _ in range(n):
        keys(**k); pump(); out.append((P()["frame"],P()["x"],P()["y"],mem("PSTATE")))
    return out
def room(): return mem("CUR_ROOM")

from PIL import Image
CH0,CH1,CH2=16,17,18
def call(label,a=None):
    m.sp-=2; m.memory[m.sp]=FD&255; m.memory[m.sp+1]=FD>>8
    if a is not None: m.a=a
    m.pc=sym[label]; pump()
def set_level(n): call("SET_LEVEL",n); call("RESPAWN")
def room(): return mem("CUR_ROOM")
def tile(col,row): return m.memory[RM+row*8+col]&0x3F
def freeze_guard(): poke("G_ACTIVE",0)
pump()
# ================= 1) chomper behaviour =================
# ================= animated torch flames =================
from PIL import Image
import hashlib
set_level(0); load_room(0); stage(60,82,1,active=0)
def shot():
    snap("/tmp/torch_t.png",(0,0,768,576)); return Image.open("/tmp/torch_t.png").convert("RGB")
def torch_crop(im,col,row):                       # flame area of a torch cell (cell is 96x192 px on the 768x576 snapshot)
    return im.crop((col*96+24,row*192+60,col*96+72,row*192+100)).tobytes()
frames=[]; seq=[]
for i in range(24):
    keys(); pump(); im=shot(); frames.append(im)
    seq.append(hashlib.md5(torch_crop(im,1,0)+torch_crop(im,7,0)).hexdigest()[:6])
distinct=sorted(set(seq)); print("flame pictures seen in 24 frames:",len(distinct),"-> sequence",seq[:8])
assert len(distinct)==3                           # exactly the three flame pictures
# the cycle repeats every 8 frames (pictures 0,1,0,2, each held for 2 frames)
assert all(seq[i]==seq[i+8] for i in range(16)),seq
# nothing but the flames changes: everything outside the torch cells is identical in every frame
def outside(im):
    im=im.copy()
    for (c,r) in ((1,0),(7,0),(0,1)):
        im.paste((0,0,0),(c*96+16,r*192+40,c*96+80,r*192+120))
    return im.tobytes()
assert len({outside(f) for f in frames})==1
# the prince standing right in front of a torch is drawn over the flame, never punched through
stage(1*32+8+4,18,0,active=0)
for _ in range(12): keys(); pump()
im=shot(); lit=sum(1 for p in im.crop((96+10,0,96+86,192)).getdata() if p==(0,255,0))
print("prince beside torch: lit pixels in the cell",lit); assert lit>150
print("ALL TORCH TESTS OK")
