import re
from z80 import Z80Machine
from PIL import Image
sym={}
for ln in open("pop12.sym"):
    m_=re.match(r"(\w+)\s+EQU\s+([0-9A-F]+)H",ln.strip())
    if m_: sym[m_.group(1)]=int(m_.group(2),16)
m=Z80Machine()
print("tick attrs:",[n for n in dir(m) if 'tick' in n.lower()])
m.set_memory_block(0x7B00,open("pop12.bin","rb").read())
m.memory[sym["TITLE_SCREEN"]]=0xC9   # tests start in the game, not on the title
m.memory[sym["INTRO_SCREEN"]]=0xC9   # ... nor on the intro picture
for a in (0x68FE,0x68FD,0x68FB,0x68F7,0x68EF,0x68DF,0x68BF,0x687F): m.memory[a]=0xFF
m.pc=0x7B00; m.sp=0x8000
SETB=sym["SET_BANK"]; FD=sym["FRAME_DONE"]
m.set_breakpoint(SETB); m.set_breakpoint(FD)
banks=[bytearray(2048) for _ in range(3)]
def mem(n): return m.memory[sym[n]]
def poke(n,v): m.memory[sym[n]]=v
def keys(left=False,right=False,a=False,d=False,s=False):
    v=0xFF
    if left:  v&=~(1<<4)
    if right: v&=~(1<<1)
    m.memory[0x68FB]=v
    w=0xFF
    if a: w&=~(1<<4)
    if d: w&=~(1<<3)
    if s: w&=~(1<<1)
    m.memory[0x68FD]=w
chunk=0
def pump():
    """run until FRAME_DONE; handle bank switching + fake vsync."""
    global chunk
    for _ in range(600000):
        chunk+=1
        m.memory[0x6800]=0x80 if chunk&1 else 0x00
        m.ticks_to_stop=1500
        m.run()
        if m.pc==SETB:
            old=m.memory[sym["CUR_BANK"]]; new=m.a
            banks[old][:]=bytes(m.memory[0x7000:0x7800]); m.memory[0x7000:0x7800]=bytes(banks[new])
            m.step_over_breakpoint()
        elif m.pc==FD:
            m.step_over_breakpoint(); return
    raise SystemExit("never finished")
def vram():
    cur=m.memory[sym["CUR_BANK"]]; banks[cur][:]=bytes(m.memory[0x7000:0x7800])
    return b"".join(bytes(b) for b in banks)
def lit(v,x,y): return bool(v[y*32+(x>>3)]&(0x80>>(x&7)))
def snap(name,crop=None):
    v=vram(); S=3; im=Image.new("RGB",(256*S,192*S),(0,96,0))
    for y in range(192):
        for x in range(256):
            if lit(v,x,y):
                for dy in range(S):
                    for dx in range(S): im.putpixel((x*S+dx,y*S+dy),(0,255,0))
    if crop: im=im.crop(crop)
    im.save(name)
def ent(base):
    a=sym[base]; k=("x","y","face","frame","fs","fi","hp","tmr","row")
    return {n:m.memory[a+i] for i,n in enumerate(k)}
P=lambda: ent("P_ENT"); G=lambda: ent("G_ENT")

pump()
def tele(px=100,gx=124,gro=0,sword=1,php=3,ghp=3):
    for n,v in (("PX",px),("PY",82),("PFACE",0),("PFRAME",0),("PROW",1),("PSTATE",0),("PFS",0),("PSWORD",sword),("PHP",php),("PTMR",0),
                ("GX",gx),("GY",82),("GFACE",1),("GFRAME",9),("GFS",0),("GHP",ghp),("GTMR",0),("GROW",gro),("JPREV",0),("DPREV",0)):
        poke(n,v)
def frames_(n,**k):
    for _ in range(n): keys(**k); pump()

def room(): return mem("CUR_ROOM")
def at(px,py,prow,face=0,sword=0):
    for n,v in (("PX",px),("PY",py),("PROW",prow),("PFACE",face),("PFRAME",0),("PSTATE",0),("PFS",0),("PSWORD",sword),("JPREV",0),("DPREV",0),("RUNPH",0),("TIDX",0),("LTMR",0)): poke(n,v)
def hold(n,**k):
    for _ in range(n): keys(**k); pump()
    keys()
from PIL import Image
shots=[]
def grab():
    snap("_t.png",(0,0,768,576)); shots.append(Image.open("_t.png").copy())
pump()
print("start: room",room(),"prince",P()["x"],P()["row"],"guard active",mem("G_ACTIVE"),"guard x",G()["x"]); assert room()==0 and mem("G_ACTIVE")==1
# 1) off the right edge of room 0 into room 1, and back
at(200,82,1); poke("GROW",0); hold(10,right=True)
print("right exit  -> room",room(),"px",P()["x"],"row",P()["row"],"guard",mem("G_ACTIVE"),G()["x"]); assert room()==1 and P()["x"]<=40 and mem("G_ACTIVE")==1
grab()
hold(12,left=True)
print("left exit   -> room",room(),"px",P()["x"]); assert room()==0 and P()["x"]>=200
# 2) run off the top platform of room 0: arrive in room 1 on an empty cell and drop to the floor
at(220,18,0); hold(5,right=True)
for i in range(12): pump()
print("drop in     -> room",room(),"row",P()["row"],"py",P()["y"],"state",mem("PSTATE")); assert room()==1 and P()["row"]==1 and P()["y"]==82 and mem("PSTATE")==0
# 3) room 1 -> room 2, walk into the pit, fall out of the bottom into room 3
at(210,82,1); poke("GROW",0); hold(8,right=True); assert room()==2,room()
grab()
hold(10,right=True)
trace=[]
for i in range(60):
    keys(right=(i<25)); pump(); trace.append((room(),P()["y"],P()["row"],mem("PSTATE")))
    if room()==3 and mem("PSTATE")==0: break
keys()
print("   fall trace (room,py,row,state):",[t for k,t in enumerate(trace) if k%3==0 or t[0]==3][:14])
print("fall -> room 3: room",room(),"row",P()["row"],"py",P()["y"],"px",P()["x"]); assert room()==3 and P()["row"]==0 and P()["y"]==18 and mem("PSTATE")==0
grab()
# 4) climb up out of the top of room 3 into room 2 (row 2 floor beside the gap)
at(100,18,0,face=1); poke("GROW",0)
keys(a=True); pump(); keys()
tr=[]
for i in range(11): pump(); tr.append((room(),P()["x"],P()["y"],P()["frame"]))
    # grab a frame while hanging / pulling up
    # (screens captured below)
print("climb up    -> room",room(),"px",P()["x"],"py",P()["y"],"row",P()["row"],"state",mem("PSTATE")); print("   trace (room,x,y,frame):",tr)
assert room()==2 and P()["row"]==2 and P()["y"]==146 and P()["x"]==84 and mem("PSTATE")==0
grab()
# 5) a kill is remembered: back in room 1 kill the guard, leave, come back
at(12,82,1,face=1); hold(3,left=True)          # room 2 -> room 1 (left edge)
assert room()==1,room()
at(140,82,1,sword=1); poke("GHP",1); poke("GROW",0); poke("GX",168)
keys(a=True); pump(); keys(); hold(5)
print("kill guard  -> guard fs",G()["fs"],"hp",G()["hp"]); assert G()["fs"]==5
at(210,82,1); hold(8,right=True); assert room()==2
at(12,82,1,face=1); hold(3,left=True); assert room()==1,room()
print("return to 1 -> guard fs",G()["fs"],"frame",G()["frame"],"flags",m.memory[sym["ROOM_FLAGS"]:sym["ROOM_FLAGS"]+4].hex()); assert G()["fs"]==5 and G()["frame"]==15
grab()
# 6) restarting the level from another room: back to the start room, kills forgotten
assert room()==1
m.sp-=2; m.memory[m.sp]=FD&255; m.memory[m.sp+1]=FD>>8; m.pc=sym["RESPAWN"]; pump()
print("restart     -> room",room(),"prince",P()["x"],P()["row"],"flags",m.memory[sym["ROOM_FLAGS"]:sym["ROOM_FLAGS"]+4].hex(),"guard",mem("G_ACTIVE"),G()["fs"],G()["hp"])
assert room()==0 and P()["x"]==40 and P()["row"]==1 and m.memory[sym["ROOM_FLAGS"]+1]==0 and mem("G_ACTIVE")==1 and G()["hp"]==3
# 7) dying to the guard restarts the level too
at(100,82,1); poke("PHP",1); poke("GROW",1)
died=False
for i in range(250):
    keys(); pump()
    if P()["fs"]==5: died=True
    if died and P()["fs"]==0 and P()["hp"]==3: break
print("death       -> room",room(),"prince",P()["x"],P()["row"],"hp",P()["hp"]); assert died and room()==0 and P()["hp"]==3 and P()["x"]==40
W=sum(i.width for i in shots[:3]); 
# montage: first 6 shots in a 3x2 grid
cols=3; rows=2; w,h=shots[0].size
M=Image.new("RGB",(cols*w//2+ (cols-1)*6, rows*h//2+6),(0,0,0))
for k,im in enumerate(shots[:6]):
    t=im.resize((w//2,h//2),Image.NEAREST); M.paste(t,((k%cols)*(w//2+6),(k//cols)*(h//2+6)))
M.save("rooms_montage.png"); print("ALL ROOM TESTS OK")
