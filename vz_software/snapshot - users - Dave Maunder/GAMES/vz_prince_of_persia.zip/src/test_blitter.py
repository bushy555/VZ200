import re
from z80 import Z80Machine
from PIL import Image
sym={}
for ln in open("pop12.sym"):
    m_=re.match(r"(\w+)\s+EQU\s+([0-9A-F]+)H",ln.strip())
    if m_: sym[m_.group(1)]=int(m_.group(2),16)
m=Z80Machine()
print("tick attrs:",[n for n in dir(m) if 'tick' in n.lower()])
m.set_memory_block(0x7B00,open("pop12.bin","rb").read())
m.memory[sym["TITLE_SCREEN"]]=0xC9   # tests start in the game, not on the title
m.memory[sym["INTRO_SCREEN"]]=0xC9   # ... nor on the intro picture
for a in (0x68FE,0x68FD,0x68FB,0x68F7,0x68EF,0x68DF,0x68BF,0x687F): m.memory[a]=0xFF
m.pc=0x7B00; m.sp=0x8000
SETB=sym["SET_BANK"]; FD=sym["FRAME_DONE"]
m.set_breakpoint(SETB); m.set_breakpoint(FD)
banks=[bytearray(2048) for _ in range(3)]
def mem(n): return m.memory[sym[n]]
def poke(n,v): m.memory[sym[n]]=v
def keys(left=False,right=False,a=False,d=False,s=False):
    v=0xFF
    if left:  v&=~(1<<4)
    if right: v&=~(1<<1)
    m.memory[0x68FB]=v
    w=0xFF
    if a: w&=~(1<<4)
    if d: w&=~(1<<3)
    if s: w&=~(1<<1)
    m.memory[0x68FD]=w
chunk=0
def pump():
    """run until FRAME_DONE; handle bank switching + fake vsync."""
    global chunk
    for _ in range(600000):
        chunk+=1
        m.memory[0x6800]=0x80 if chunk&1 else 0x00
        m.ticks_to_stop=1500
        m.run()
        if m.pc==SETB:
            old=m.memory[sym["CUR_BANK"]]; new=m.a
            banks[old][:]=bytes(m.memory[0x7000:0x7800]); m.memory[0x7000:0x7800]=bytes(banks[new])
            m.step_over_breakpoint()
        elif m.pc==FD:
            m.step_over_breakpoint(); return
    raise SystemExit("never finished")
def vram():
    cur=m.memory[sym["CUR_BANK"]]; banks[cur][:]=bytes(m.memory[0x7000:0x7800])
    return b"".join(bytes(b) for b in banks)
def lit(v,x,y): return bool(v[y*32+(x>>3)]&(0x80>>(x&7)))
def snap(name,crop=None):
    v=vram(); S=3; im=Image.new("RGB",(256*S,192*S),(0,96,0))
    for y in range(192):
        for x in range(256):
            if lit(v,x,y):
                for dy in range(S):
                    for dx in range(S): im.putpixel((x*S+dx,y*S+dy),(0,255,0))
    if crop: im=im.crop(crop)
    im.save(name)
def ent(base):
    a=sym[base]; k=("x","y","face","frame","fs","fi","hp","tmr","row")
    return {n:m.memory[a+i] for i,n in enumerate(k)}
P=lambda: ent("P_ENT"); G=lambda: ent("G_ENT")
pump()                                   # first loop pass
# ---------------------------------------------------------------- parse sprite data
frames={}; cur=None
for ln in open("_sprites.inc"):
    ln=ln.strip()
    mm=re.match(r"(\w+):$",ln)
    if mm and not ln.startswith(";"): cur=[mm.group(1),[]]; frames[cur[0]]=cur[1]; continue
    if ln.startswith("DEFB") and cur: cur[1].append([int(t.strip()[1:],16) if t.strip().startswith("$") else int(t.strip()) for t in ln[4:].split(",")])
def expected(name,x,y,flip):
    rows=frames[name]; W,H,XO,YO=rows[0]; XO=XO-256 if XO>127 else XO
    img=[];msk=[]
    for r in rows[1:]:
        ib=r[:W]; mb=r[W:]
        bi=[(b>>(7-k))&1 for b in ib for k in range(8)]; bm=[(b>>(7-k))&1 for b in mb for k in range(8)]
        if flip: bi=bi[::-1]; bm=bm[::-1]
        img.append(bi); msk.append(bm)
    xo=(16-XO-8*W) if flip else XO
    left=max(0,min(x+xo,255-8*W)); top=(y+YO)&255
    return left,top,img,msk,W
def call_sprite(name,x,y,flip):
    for b in banks: b[:]=bytes(2048)
    m.memory[0x7000:0x7800]=bytes(banks[0]); poke("CUR_BANK",0)
    poke("SP_X",x); poke("SP_Y",y); poke("SP_FLIP",flip)
    ret=FD; m.sp-=2; m.memory[m.sp]=ret&255; m.memory[m.sp+1]=ret>>8
    m.hl=frames_addr[name]; m.pc=sym["DRAW_SPRITE"]
    pump()
# label addresses: parse from sym
frames_addr={n:sym[n] for n in frames if n in sym}
ok=0; bad=0
for name in ("PRINCE_STAND","PRINCE_STRIKE2","PRINCE_PARRY","GUARD_GARDE","PRINCE_DEAD","PRINCE_TURN2","PRINCE_CLIMB3","PRINCE_CROUCH","GUARD_RETREAT","PRINCE_DRAW2","PRINCE_FALL"):
    for flip in (0,1):
        for x in (10,41,67,100,131,226):
            for y in (20,50,100):
                call_sprite(name,x,y,flip); v=vram()
                left,top,img,msk,W=expected(name,x,y,flip)
                errs=0
                for i,(ri,rm) in enumerate(zip(img,msk)):
                    for k,(bi,bm) in enumerate(zip(ri,rm)):
                        px,py=left+k,top+i
                        if px>255 or py>191: continue
                        if bi and not lit(v,px,py): errs+=1
                        if bm and not bi and lit(v,px,py): errs+=1
                if errs: bad+=1; print("MISMATCH",name,"flip",flip,"x",x,"y",y,"errors",errs)
                else: ok+=1
print("blitter reference check: %d ok, %d bad"%(ok,bad)); assert bad==0
