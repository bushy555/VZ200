# gen_swstep.py - draw the sword-walk step frames with prince_gen's body model and append them to sprites.txt
# (and to sprites_old.txt as blank placeholders so prince_gen.py keeps regenerating them).
import os,sys,re
os.environ.setdefault("PRINCE_ARMS","dither")
src=open("prince_gen.py").read().rsplit("\nmain()",1)[0]
g={}; exec(compile(src,"prince_gen.py","exec"),g)
pose=g["pose"]; POSES=g["POSES"]; render_frame=g["render_frame"]
NEW={
 "PRINCE_SWSTEPA": pose((8,21),3,arm_far=(-26,100),arm_near=(68,20),leg_far=(-5,6),leg_near=(11,8),sword=(4,19)),
 "PRINCE_SWSTEPB": pose((8,21),4,arm_far=(-26,100),arm_near=(67,21),leg_far=(6,10),leg_near=(-6,6),sword=(4,19)),
}
if "--preview" in sys.argv:
    from PIL import Image
    ref=[l for l in open("sprites.txt").read().split("\n")]
    def grab(name):
        i=ref.index([l for l in ref if l.startswith("["+name+" ")][0]); rows=[]
        for l in ref[i+1:]:
            if l.startswith("[") or not l.strip(): break
            rows.append(l)
        return rows
    sets=[("GARDE",grab("PRINCE_GARDE")),("ADVANCE",grab("PRINCE_ADVANCE")),("RETREAT",grab("PRINCE_RETREAT"))]
    for n in NEW:
        w=len(grab("PRINCE_GARDE")[0]); h=len(grab("PRINCE_GARDE"))
        POSES[n]=NEW[n]
        pix=render_frame(dict(name=n,rows=["."*w]*h))
        sets.append((n[7:],["".join("#" if v else "." for v in r) for r in pix]))
    S=6; W=max(len(r[1][0]) for r in sets); H=len(sets[0][1])
    im=Image.new("RGB",(len(sets)*(W*S+12),H*S+4),(24,24,24))
    for k,(nm,rows) in enumerate(sets):
        for y,r in enumerate(rows):
            for x,ch in enumerate(r):
                col=(0,255,0) if ch=="#" else (0,70,0)
                for dy in range(S):
                    for dx in range(S): im.putpixel((k*(W*S+12)+x*S+dx,y*S+dy),col)
    im.save("/tmp/swstep_preview.png"); print("preview",[s[0] for s in sets]); sys.exit()
