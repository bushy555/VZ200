#!/usr/bin/env python3
"""art_tool.py - edit the game's art in any paint program.

  python3 art_tool.py export-sprites   [sprites.txt  sprites_sheet.png]   -> a PNG sheet + sprites_sheet.json
  python3 art_tool.py import-sprites   [sprites_sheet.png  sprites.txt]    <- paint on the sheet, bring it back
  python3 art_tool.py export-tiles     [tiles.txt    tiles_sheet.png]
  python3 art_tool.py import-tiles     [tiles_sheet.png  tiles.txt]
  python3 art_tool.py preview-levels   [levels.txt   level_preview.png]    -> every room drawn with your tiles/sprites

On the sheets: bright green (or white) = lit pixel, dark = off.  Anything dimmer than that (the faint grid every
8 pixels, the reference box, the labels) is ignored on import, so leave it alone or paint over it.
After importing, run make_sprites.py / make_tiles.py (or build.py) as usual.
"""
import sys, json, os
from PIL import Image, ImageDraw, ImageFont

LIT=(0,255,0); DARK=(0,96,0); GRID=(0,125,0); BOX=(60,150,60); GUTTER=(24,24,24)

# ------------------------------------------------------------------ text files
def read_sections(path):
    pre=[]; secs=[]; cur=None
    for ln in open(path):
        ln=ln.rstrip("\r\n")
        if ln.startswith("["):
            cur=dict(head=ln,rows=[]); secs.append(cur); continue
        if cur is None: pre.append(ln); continue
        if ln.strip(): cur["rows"].append(ln)
    return pre,secs
def write_sections(path,pre,secs):
    with open(path,"w") as f:
        for ln in pre: f.write(ln+"\n")
        for s in secs:
            f.write(s["head"]+"\n")
            for r in s["rows"]: f.write(r+"\n")
            f.write("\n")
def name_of(head): return head[1:head.index("]")].split()[0]
def attr(head,key,default=0):
    for t in head[1:head.index("]")].split()[1:]:
        k,_,v=t.partition("=")
        if k==key: return int(v)
    return default

# ------------------------------------------------------------------ sheets
def export_sheet(txt,png,scale,maxw,boxes=None,tile_mode=False):
    pre,secs=read_sections(txt)
    font=ImageFont.load_default()
    placed=[]; x=8; y=8; rowh=0
    for s in secs:
        w=len(s["rows"][0]); h=len(s["rows"])
        if x+w*scale+8>maxw: x=8; y+=rowh+26; rowh=0
        placed.append(dict(name=name_of(s["head"]),head=s["head"],x=x,y=y+14,w=w,h=h)); x+=w*scale+14; rowh=max(rowh,h*scale+14)
    H=y+rowh+30
    im=Image.new("RGB",(maxw,H),GUTTER); d=ImageDraw.Draw(im)
    for p,s in zip(placed,secs):
        d.text((p["x"],p["y"]-12),p["name"],fill=(220,220,220),font=font)
        for yy,row in enumerate(s["rows"]):
            for xx,ch in enumerate(row):
                d.rectangle([p["x"]+xx*scale,p["y"]+yy*scale,p["x"]+xx*scale+scale-1,p["y"]+yy*scale+scale-1],fill=LIT if ch=="#" else DARK)
        # faint byte grid (every 8 px) and, for sprites, the 16x42 reference box
        for xx in range(0,p["w"]+1,8):
            for yy in range(p["h"]*scale):
                px=p["x"]+xx*scale
                if px<maxw and im.getpixel((px-1 if xx==p["w"] else px,p["y"]+yy))==DARK: im.putpixel((px-1 if xx==p["w"] else px,p["y"]+yy),GRID)
        if not tile_mode:
            xo=attr(p["head"],"xo"); yo=attr(p["head"],"yo")
            bx0,by0=(0-xo)*scale,(0-yo)*scale; bx1,by1=bx0+16*scale-1,by0+42*scale-1
            for xx in range(bx0,bx1+1):
                for yy in (by0,by1):
                    X,Y=p["x"]+xx,p["y"]+yy
                    if 0<=xx<p["w"]*scale and 0<=yy<p["h"]*scale and im.getpixel((X,Y)) in (DARK,GRID): im.putpixel((X,Y),BOX)
            for yy in range(by0,by1+1):
                for xx in (bx0,bx1):
                    X,Y=p["x"]+xx,p["y"]+yy
                    if 0<=xx<p["w"]*scale and 0<=yy<p["h"]*scale and im.getpixel((X,Y)) in (DARK,GRID): im.putpixel((X,Y),BOX)
    im.save(png)
    json.dump(dict(scale=scale,sheet_width=maxw,items=[dict(name=p["name"],x=p["x"],y=p["y"],w=p["w"],h=p["h"]) for p in placed]),open(os.path.splitext(png)[0]+".json","w"),indent=1)
    print("wrote",png,"(%d frames, %dx%d)"%(len(secs),im.width,im.height),"and",os.path.splitext(png)[0]+".json")
def import_sheet(png,txt):
    meta=json.load(open(os.path.splitext(png)[0]+".json")); sc=meta["scale"]
    im=Image.open(png).convert("RGB")
    pre,secs=read_sections(txt)
    items={it["name"]:it for it in meta["items"]}; changed=0
    for s in secs:
        it=items[name_of(s["head"])]
        rows=[]
        for yy in range(it["h"]):
            r=""
            for xx in range(it["w"]):
                px=im.getpixel((it["x"]+xx*sc+sc//2,it["y"]+yy*sc+sc//2))
                r+="#" if px[1]>175 else "."
            rows.append(r)
        if rows!=s["rows"]: changed+=1
        s["rows"]=rows
    write_sections(txt,pre,secs); print("imported",png,"->",txt,"(%d of %d frames changed)"%(changed,len(secs)))

# ------------------------------------------------------------------ level preview
POTION=[0x18,0x18,0x3C,0x7E,0xFF,0xD7,0xFF,0xFF,0x7E]
def tile_art(path):
    pre,secs=read_sections(path); order=[]; art={}
    for s in secs:
        n=name_of(s["head"]); g=[[1 if c=="#" else 0 for c in r] for r in s["rows"]]; art[n]=g
        if not n.startswith("TORCH"): order.append(n)
    return order,art
def sprite_art(path):
    pre,secs=read_sections(path); fr={}
    for i,s in enumerate(secs):
        fr[name_of(s["head"])]=dict(rows=[[1 if c=="#" else 0 for c in r] for r in s["rows"]],xo=attr(s["head"],"xo"),yo=attr(s["head"],"yo"))
    return fr
def parse_levels(path):
    levels=[]; cl=None; cr=None
    for ln in open(path):
        ln=ln.rstrip("\r\n")
        if not ln.strip() or ln.lstrip().startswith(";"): continue
        if ln.lower().startswith("[level"): cl=dict(start=None,rooms=[]); levels.append(cl); continue
        if ln.lower().startswith("start"): cl["start"]=[int(v) for v in ln.split("=")[1].split(",")]; continue
        if ln.startswith("[room"):
            t=ln[1:ln.index("]")].split(); cr=dict(n=int(t[1]),links={},guard=None,rows=[])
            for a in t[2:]:
                k,v=a.split("=")
                if k=="guard": cr["guard"]=None if v=="-" else tuple(int(z) for z in v.split(","))
                else: cr["links"][k]=v
            cl["rooms"].append(cr); continue
        cr["rows"].append(ln)
    return levels
def preview_levels(levels_txt,png,tiles_txt="tiles.txt",sprites_txt="sprites.txt"):
    order,art=tile_art(tiles_txt); fr=sprite_art(sprites_txt); levels=parse_levels(levels_txt)
    ids={n:i+1 for i,n in enumerate(order)}
    torch=art.get("TORCH")
    def blit(canvas,g,x0,y0,fl=False,dither=False):
        W=len(g[0]);
        for y,row in enumerate(g):
            for x,v in enumerate(row):
                if v:
                    xx=(W-1-x) if fl else x
                    if dither and y>=9 and x<=12 and (x+y)%2: continue
                    X,Y=x0+xx,y0+y
                    if 0<=X<256 and 0<=Y<192: canvas[Y][X]=1
    def sprite(canvas,name,px,py,flip,dither=False):
        f=fr[name]; g=f["rows"]; W=len(g[0]); xo=f["xo"]
        if flip: xo=16-xo-W
        x0=max(0,min(px+xo,256-W))
        blit(canvas,g,x0,py+f["yo"],flip,dither)
    def tile(ch,r,row,col):
        left=r["rows"][row][col-1] if col>0 else ("=" if r["links"].get("L","-")!="-" else ".")
        right=r["rows"][row][col+1] if col<7 else "#"
        m={".":None,"t":None,"^":"SPIKES","P":"PILLAR","E":"EXIT","L":"LOOSE","v":"PLATE","G":"GATE0","C":"CHOMP0"}
        if ch=="#": return "WALL" if right=="#" else "WALLR"
        if ch in "=+o": return "FLOOR" if left in "=P+EoLvGC" else "FLOORL"
        return m.get(ch)
    font=ImageFont.load_default(); sheets=[]
    for li,lv in enumerate(levels):
        rooms=lv["rooms"]; per=4; rows_n=(len(rooms)+per-1)//per
        sheet=Image.new("RGB",(per*268+8,rows_n*214+28),(10,10,10)); d=ImageDraw.Draw(sheet)
        d.text((8,6),"LEVEL %d   (%d rooms; start = room %d col %d row %d)"%(li+1,len(rooms),*lv["start"]),fill=(230,230,230),font=font)
        for ri,r in enumerate(rooms):
            cv=[[0]*256 for _ in range(192)]
            for row in range(3):
                for col in range(8):
                    ch=r["rows"][row][col]; nm=tile(ch,r,row,col)
                    if nm: blit(cv,art[nm],col*32,row*64)
                    if ch=="t" or ch=="+":
                        if torch: blit(cv,torch,col*32,row*64)
                    if ch=="o":
                        for k,b in enumerate(POTION):
                            for bit in range(8):
                                if b&(0x80>>bit): cv[row*64+41+k][col*32+16+bit]=1
            if r["guard"]:
                gc,gr=r["guard"]; sprite(cv,"PRINCE_GARDE",gc*32+8,gr*64+18,True,True)
            if lv["start"][0]==r["n"]:
                sprite(cv,"PRINCE_STAND",lv["start"][1]*32+8,lv["start"][2]*64+18,False)
            img=Image.new("RGB",(256,192),DARK); px=img.load()
            for y in range(192):
                for x in range(256):
                    if cv[y][x]: px[x,y]=LIT
            ox=8+(ri%per)*268; oy=24+(ri//per)*214
            sheet.paste(img,(ox,oy+12))
            lk=r["links"]; d.text((ox,oy),"room %d   L=%s R=%s U=%s D=%s%s"%(r["n"],lk.get("L","-"),lk.get("R","-"),lk.get("U","-"),lk.get("D","-"),"   guard" if r["guard"] else ""),fill=(200,230,200),font=font)
        sheets.append(sheet)
    W=max(s.width for s in sheets); H=sum(s.height for s in sheets)
    out=Image.new("RGB",(W,H),(10,10,10)); y=0
    for s in sheets: out.paste(s,(0,y)); y+=s.height
    out.save(png); print("wrote",png,"(%d levels, %d rooms)"%(len(levels),sum(len(l["rooms"]) for l in levels)))

def main(a):
    if not a or a[0] in("-h","--help"): print(__doc__); return
    c=a[0]; r=a[1:]
    if c=="export-sprites": export_sheet(r[0] if r else "sprites.txt",r[1] if len(r)>1 else "sprites_sheet.png",6,1500)
    elif c=="import-sprites": import_sheet(r[0] if r else "sprites_sheet.png",r[1] if len(r)>1 else "sprites.txt")
    elif c=="export-tiles": export_sheet(r[0] if r else "tiles.txt",r[1] if len(r)>1 else "tiles_sheet.png",4,1300,tile_mode=True)
    elif c=="import-tiles": import_sheet(r[0] if r else "tiles_sheet.png",r[1] if len(r)>1 else "tiles.txt")
    elif c=="preview-levels": preview_levels(r[0] if r else "levels.txt",r[1] if len(r)>1 else "level_preview.png")
    else: print(__doc__)
if __name__=="__main__": main(sys.argv[1:])
