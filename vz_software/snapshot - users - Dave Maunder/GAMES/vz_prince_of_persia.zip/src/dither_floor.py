#!/usr/bin/env python3
"""dither_floor.py - tiles_hatch.txt -> tiles.txt: the floor top drawn as a dithered plane instead of hatch lines.
(tiles.txt is the game's art and is already dithered; tiles_hatch.txt is the earlier hatch-line version, kept for reference.)

The floor lines at rows 52,54,56,58 become a checkerboard fill of the same width (rows 52-59), keeping the solid back edge (row 50), the
front lip (row 60) and the front edge (row 63).  Pressure plates are redrawn on the dithered floor.
The hatch floor can still be built:  python3 build.py --tiles tiles_hatch.txt --name VZPRINCEH
"""
import sys
src=sys.argv[1] if len(sys.argv)>1 else "tiles_hatch.txt"
dst=sys.argv[2] if len(sys.argv)>2 else "tiles.txt"
SL=3
lines=open(src).read().split("\n")
res=[];i=0
def plate(front_y,fh,depth,x0=6,x1=19):
    g=[[0]*32 for _ in range(64)]
    for y in (50,60,63):
        for x in range(32): g[y][x]=1
    for y in range(52,60):
        for x in range(32):
            if (x+y)%2==0: g[y][x]=1
    top=front_y-fh-depth
    for y in range(top-1,front_y+1):
        if y in (50,60,63): continue
        for x in range(x0-1,32): g[y][x]=0
    for y in range(front_y-fh+1,front_y+1):
        for x in range(x0,x1+1): g[y][x]=1
    for k,y in enumerate(range(front_y-fh,top-1,-1)):
        s=(k+1)*SL
        for x in range(x0+s,x1+s+1):
            if x<32 and ((x+y)%2==0 or x in (x0+s,x1+s) or y==top): g[y][x]=1
    return ["".join("#" if v else "." for v in r) for r in g]
PLATES={"PLATE":plate(58,2,4),"PLATEON":plate(59,1,1)}
while i<len(lines):
    ln=lines[i]
    if ln.startswith("[") and ln[1:-1].strip() not in ("TORCH","TORCH2","TORCH3","SPIKES"):
        name=ln[1:-1].strip(); res.append(ln); i+=1
        rows=[]; j=i
        while j<len(lines) and not lines[j].startswith("["): rows.append(lines[j]); j+=1
        art=[k for k,r in enumerate(rows) if r.strip() and not r.startswith(";")]
        if len(art)==64:
            g=[[1 if c=="#" else 0 for c in rows[k]] for k in art]
            if name in PLATES: new=PLATES[name]; g=[[1 if c=="#" else 0 for c in r] for r in new]
            else:
                for y in (52,54,56,58):
                    if any(g[y+1]): continue                 # not a plain hatch pair (plates etc.)
                    ext=[g[y][x] for x in range(32)]
                    if not any(ext): continue
                    for x in range(32):
                        g[y][x]=1 if ext[x] and (x+y)%2==0 else 0
                        g[y+1][x]=1 if ext[x] and (x+y+1)%2==0 else 0
            for n,k in enumerate(art): rows[k]="".join("#" if v else "." for v in g[n])
        res+=rows; i=j
    else: res.append(ln); i+=1
open(dst,"w").write("\n".join(res)); print("wrote",dst)
