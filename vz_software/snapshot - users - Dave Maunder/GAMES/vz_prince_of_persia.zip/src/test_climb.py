import re
from z80 import Z80Machine
from PIL import Image
sym={}
for ln in open("pop12.sym"):
    m=re.match(r"(\w+)\s+EQU\s+([0-9A-F]+)H",ln.strip())
    if m: sym[m.group(1)]=int(m.group(2),16)
m=Z80Machine()
m.set_memory_block(0x7B00,open("pop12.bin","rb").read())
m.memory[sym["TITLE_SCREEN"]]=0xC9   # tests start in the game, not on the title
m.memory[sym["INTRO_SCREEN"]]=0xC9   # ... nor on the intro picture
for a in (0x68FE,0x68FD,0x68FB,0x68F7,0x68EF,0x68DF,0x68BF,0x687F): m.memory[a]=0xFF
m.pc=0x7B00; m.sp=0x8000
SETB=sym["SET_BANK"]; FD=sym["FRAME_DONE"]
m.set_breakpoint(SETB); m.set_breakpoint(FD)
banks=[bytearray(2048) for _ in range(3)]
def mem(n): return m.memory[sym[n]]
def keys(left=False,right=False,a=False):
    m.memory[0x68FD]=0xFF&~(1<<4) if a else 0xFF
    v=0xFF
    if left:  v&=~(1<<4)
    if right: v&=~(1<<1)
    m.memory[0x68FB]=v
chunk=0
def run_until_frame():
    global chunk
    for _ in range(400000):
        chunk+=1
        m.memory[0x6800]=0x80 if chunk&1 else 0x00     # fake vsync toggling
        m.ticks_to_stop=1500
        m.run()
        if m.pc==SETB:
            old=m.memory[sym["CUR_BANK"]]; new=m.a
            banks[old][:]=bytes(m.memory[0x7000:0x7800])
            m.memory[0x7000:0x7800]=bytes(banks[new])
            m.step_over_breakpoint()
        elif m.pc==FD:
            m.step_over_breakpoint(); return True
    raise SystemExit("frame never finished")
def state(): return dict(px=mem("PX"),py=mem("PY"),row=mem("PROW"),face=mem("PFACE"),fr=mem("PFRAME"),st=mem("PSTATE"))
def snap(name):
    # flush current window into its bank, then render all three
    cur=m.memory[sym["CUR_BANK"]]; banks[cur][:]=bytes(m.memory[0x7000:0x7800])
    v=b"".join(bytes(b) for b in banks)
    S=3; im=Image.new("RGB",(256*S,192*S),(0,96,0))
    for y in range(192):
        for x in range(256):
            if v[y*32+(x>>3)]&(0x80>>(x&7)):
                for dy in range(S):
                    for dx in range(S): im.putpixel((x*S+dx,y*S+dy),(0,255,0))
    im.save(name)

run_until_frame()
def tele(x,y,row,face=0):
    m.memory[sym["GROW"]]=0
    for n,v in (("PX",x),("PY",y),("PROW",row),("PFACE",face),("PSTATE",0),("PFRAME",0),("JPREV",0)):
        m.memory[sym[n]]=v
def press_a(tag,x,y,row,face,frames=11,shots=()):
    tele(x,y,row,face); keys(); run_until_frame()
    keys(a=True); run_until_frame(); keys()
    tr=[(mem("PX"),mem("PY"),mem("PFRAME"))]
    for i in range(frames):
        run_until_frame(); tr.append((mem("PX"),mem("PY"),mem("PFRAME")))
        if i in shots: snap("t_%s_%d.png"%(tag,i))
    print(tag,"->",state()); print("   trace (px,py,frame):",tr)
    return state()
# 1) climb onto the top platform from the left of the pillar (facing right)
s=press_a("climbR",76,82,1,0,shots=(1,3,5,6,7))
assert (s["px"],s["py"],s["row"],s["st"])==(92,18,0,0),s
# 2) too far from the edge -> plain hop, stays on row 1
s=press_a("hopfar",60,82,1,0); assert s["row"]==1 and s["py"]==82,s
# 3) ceiling above (pillar column) -> plain hop
s=press_a("ceiling",100,82,1,0); assert s["row"]==1 and s["py"]==82,s
# 4) facing left: put a floor at (1,0) so there is a ledge to the left of the gap at (2,0)
m.memory[sym["ROOM_MAP"]+1]=3
s=press_a("climbL",66,82,1,1,shots=(3,6))
assert (s["px"],s["py"],s["row"],s["st"])==(52,18,0,0),s
# 5) top row: nothing above -> hop
s=press_a("toprow",150,18,0,0); assert s["row"]==0 and s["py"]==18,s
print("ALL OK")
