import re
from z80 import Z80Machine
from PIL import Image
sym={}
for ln in open("pop12.sym"):
    m_=re.match(r"(\w+)\s+EQU\s+([0-9A-F]+)H",ln.strip())
    if m_: sym[m_.group(1)]=int(m_.group(2),16)
m=Z80Machine()
print("tick attrs:",[n for n in dir(m) if 'tick' in n.lower()])
m.set_memory_block(0x7B00,open("pop12.bin","rb").read())
m.memory[sym["TITLE_SCREEN"]]=0xC9   # tests start in the game, not on the title
m.memory[sym["INTRO_SCREEN"]]=0xC9   # ... nor on the intro picture
for a in (0x68FE,0x68FD,0x68FB,0x68F7,0x68EF,0x68DF,0x68BF,0x687F): m.memory[a]=0xFF
m.pc=0x7B00; m.sp=0x8000
SETB=sym["SET_BANK"]; FD=sym["FRAME_DONE"]
m.set_breakpoint(SETB); m.set_breakpoint(FD)
banks=[bytearray(2048) for _ in range(3)]
def mem(n): return m.memory[sym[n]]
def poke(n,v): m.memory[sym[n]]=v
def keys(left=False,right=False,a=False,d=False,s=False):
    v=0xFF
    if left:  v&=~(1<<4)
    if right: v&=~(1<<1)
    m.memory[0x68FB]=v
    w=0xFF
    if a: w&=~(1<<4)
    if d: w&=~(1<<3)
    if s: w&=~(1<<1)
    m.memory[0x68FD]=w
chunk=0
def pump():
    """run until FRAME_DONE; handle bank switching + fake vsync."""
    global chunk
    for _ in range(600000):
        chunk+=1
        m.memory[0x6800]=0x80 if chunk&1 else 0x00
        m.ticks_to_stop=1500
        m.run()
        if m.pc==SETB:
            old=m.memory[sym["CUR_BANK"]]; new=m.a
            banks[old][:]=bytes(m.memory[0x7000:0x7800]); m.memory[0x7000:0x7800]=bytes(banks[new])
            m.step_over_breakpoint()
        elif m.pc==FD:
            m.step_over_breakpoint(); return
    raise SystemExit("never finished")
def vram():
    cur=m.memory[sym["CUR_BANK"]]; banks[cur][:]=bytes(m.memory[0x7000:0x7800])
    return b"".join(bytes(b) for b in banks)
def lit(v,x,y): return bool(v[y*32+(x>>3)]&(0x80>>(x&7)))
def snap(name,crop=None):
    v=vram(); S=3; im=Image.new("RGB",(256*S,192*S),(0,96,0))
    for y in range(192):
        for x in range(256):
            if lit(v,x,y):
                for dy in range(S):
                    for dx in range(S): im.putpixel((x*S+dx,y*S+dy),(0,255,0))
    if crop: im=im.crop(crop)
    im.save(name)
def ent(base):
    a=sym[base]; k=("x","y","face","frame","fs","fi","hp","tmr","row")
    return {n:m.memory[a+i] for i,n in enumerate(k)}
P=lambda: ent("P_ENT"); G=lambda: ent("G_ENT")

pump()
def tele(px=100,gx=124,gro=0,sword=1,php=3,ghp=3):
    for n,v in (("PX",px),("PY",82),("PFACE",0),("PFRAME",0),("PROW",1),("PSTATE",0),("PFS",0),("PSWORD",sword),("PHP",php),("PTMR",0),
                ("GX",gx),("GY",82),("GFACE",1),("GFRAME",9),("GFS",0),("GHP",ghp),("GTMR",0),("GROW",gro),("JPREV",0),("DPREV",0)):
        poke(n,v)
def frames_(n,**k):
    for _ in range(n): keys(**k); pump()

from PIL import Image
RM=sym["ROOM_MAP"]; FL=sym["ROOM_FLAGS"]
def load_room(n):
    m.sp-=2; m.memory[m.sp]=FD&255; m.memory[m.sp+1]=FD>>8; m.a=n; m.pc=sym["LOAD_ROOM"]; pump()
def stage(px,py,row,face=0,hp=3,active=0):
    for n,v in (("PX",px),("PY",py),("PROW",row),("PFACE",face),("PFRAME",0),("PSTATE",0),("PFS",0),("PSWORD",0),("PHP",hp),
                ("JPREV",0),("DPREV",0),("RUNPH",0),("TIDX",0),("LTMR",0),("FALLN",0),("G_ACTIVE",active),("LOOSE_ARM",0)): poke(n,v)
    keys()
def run(n,**k):
    out=[]
    for _ in range(n):
        keys(**k); pump(); out.append((P()["frame"],P()["x"],P()["y"],mem("PSTATE")))
    return out
def room(): return mem("CUR_ROOM")

PS=sym["PLAY_SOUND"]; BPH=sym["BP_HC"]; NZH=sym["NZ_HC"]
m.set_breakpoint(PS); m.set_breakpoint(BPH); m.set_breakpoint(NZH)
log={"req":[], "beep":0, "noise":0, "states":set()}
def pump():
    global chunk
    for _ in range(900000):
        chunk+=1
        m.memory[0x6800]=0x80 if chunk&1 else 0x00
        m.ticks_to_stop=1500
        m.run()
        pc=m.pc
        if pc==SETB:
            old=m.memory[sym["CUR_BANK"]]; new=m.a
            banks[old][:]=bytes(m.memory[0x7000:0x7800]); m.memory[0x7000:0x7800]=bytes(banks[new])
            m.step_over_breakpoint()
        elif pc==PS:
            log["req"].append(mem("SND_REQ")); m.step_over_breakpoint()
        elif pc==BPH:
            log["beep"]+=1; log["states"].add(m.e); m.step_over_breakpoint()
        elif pc==NZH:
            log["noise"]+=1; m.step_over_breakpoint()
        elif pc==FD:
            m.step_over_breakpoint(); return
    raise SystemExit("never finished")
def reqs(n,**k):
    log["req"].clear(); out=[]
    for _ in range(n):
        log["req"].clear(); keys(**k); pump(); out.append(log["req"][-1] if log["req"] else 0)
    return out
pump()
ids=dict(STEP=1,GATE=2,LAND=3,DRAW=4,PARRY=5,HIT=6,LOOSE=7,FALLHURT=8,POTION=9,DEATH=10)
# -- footsteps while running
stage(20,82,1,active=0); r=reqs(8,right=True); print("run   ->",r); assert ids["STEP"] in r
# -- draw / sheathe
stage(60,82,1,active=0); keys(); pump(); r=reqs(1,d=True); print("draw  ->",r); assert r==[ids["DRAW"]]
reqs(4); r=reqs(1,d=True); print("sheathe ->",r); assert r==[ids["DRAW"]]
# -- sword: a hit, a parried strike, a killing blow
for n,v in (("PX",100),("PY",82),("PROW",1),("PFACE",0),("PSWORD",1),("PFS",0),("PHP",3),("GX",124),("GY",82),("GFACE",1),("GFS",0),("GFRAME",9),("GHP",3),("GROW",0),("G_ACTIVE",1)): poke(n,v)
keys(); pump(); r=reqs(1,a=True)+reqs(4); print("hit   ->",r); assert ids["HIT"] in r
for n,v in (("PFS",0),("GFS",0),("GHP",3),("GX",124)): poke(n,v)
pump(); log["req"].clear(); keys(a=True); pump(); keys(); got=[]
for _ in range(5): poke("GFS",3); log["req"].clear(); pump(); got.append(log["req"][-1])
print("parry ->",got); assert ids["PARRY"] in got
# -- landing after a one-row fall, a hurt landing, a fatal one
stage(72,18,0,face=1,active=0); poke("PSTATE",1); poke("FALLN",0); r=reqs(14); print("fall 1 row ->",[x for x in r if x]); assert ids["LAND"] in r
m.memory[RM+8+2]=0; m.memory[RM+16+2]=3
stage(72,18,0,face=1,active=0); poke("PSTATE",1); r=reqs(30); print("fall 2 rows ->",[x for x in r if x]); assert ids["FALLHURT"] in r
stage(72,18,0,face=1,active=0); poke("PSTATE",1); poke("FALLN",1); r=reqs(30); print("fall 3 rows ->",[x for x in r if x]); assert ids["DEATH"] in r
# -- potion, loose floor, gate/plate
load_room(1); stage(72,82,1,hp=1,active=0); pump(); r=reqs(1,s=True); print("potion ->",r); assert r==[ids["POTION"]]
stage(152,18,0,active=0); r=reqs(8); print("loose tile ->",[x for x in r if x]); assert ids["LOOSE"] in r
load_room(4); stage(8,18,0,active=0); r=reqs(12,right=True); print("plate/gate ->",[x for x in r if x]); assert ids["GATE"] in r
# -- the prince dying to the guard plays the death tune; the guard dying does not
load_room(0)
for n,v in (("PX",100),("PY",82),("PROW",1),("PFACE",0),("PSWORD",0),("PFS",0),("PHP",1),("GX",124),("GROW",1),("G_ACTIVE",1),("PSTATE",0)): poke(n,v)
seen=[]
for _ in range(120):
    keys(); log["req"].clear(); pump(); seen.append(log["req"][-1])
    if ids["DEATH"] in seen: break
print("killed by the guard ->",[x for x in seen if x]); assert ids["DEATH"] in seen
load_room(0)
for n,v in (("PX",100),("PY",82),("PROW",1),("PFACE",0),("PSWORD",1),("PFS",0),("PHP",3),("GX",124),("GROW",0),("G_ACTIVE",1),("GHP",1),("GFS",0),("PSTATE",0)): poke(n,v)
keys(a=True); log["req"].clear(); pump(); keys(); got=[]
for _ in range(5): log["req"].clear(); pump(); got.append(log["req"][-1])
print("killing the guard ->",got); assert ids["HIT"] in got and ids["DEATH"] not in got
# -- speaker activity: half-cycle counts of the real routines, then mute
def count_for(request):
    log["beep"]=0; log["noise"]=0; log["states"].clear()
    poke("SND_REQ",request)
    # run the PLAY_SOUND routine directly
    m.sp-=2; m.memory[m.sp]=FD&255; m.memory[m.sp+1]=FD>>8; m.pc=PS
    for _ in range(900000):
        m.memory[0x6800]=0x80 if (chunk&1) else 0; m.ticks_to_stop=1500; m.run()
        pc=m.pc
        if pc==PS: m.step_over_breakpoint()
        elif pc==BPH: log["beep"]+=1; log["states"].add(m.e); m.step_over_breakpoint()
        elif pc==NZH: log["noise"]+=1; m.step_over_breakpoint()
        elif pc==FD: m.step_over_breakpoint(); break
    return log["beep"],log["noise"],sorted(log["states"])
poke("SND_MUTE",0)
b,n,st=count_for(ids["STEP"]);   print("step  sound: tone half-cycles",b,"noise",n,"latch phases",st); assert (b,n)==(5,0) and st==[9,0x28]
b,n,st=count_for(ids["LAND"]);   print("land  sound: tone half-cycles",b,"noise",n); assert (b,n)==(14,0)
b,n,st=count_for(ids["HIT"]);    print("hit   sound: tone half-cycles",b,"noise",n); assert (b,n)==(0,110)
b,n,st=count_for(ids["DEATH"]);  print("death tune:  tone half-cycles",b); assert b==40+40+50+60+70
poke("SND_MUTE",1); b,n,st=count_for(ids["DEATH"]); print("muted: tone",b,"noise",n); assert (b,n)==(0,0)
# the M key toggles the mute flag
poke("SND_MUTE",0); poke("MPREV",0)
m.memory[0x68EF]=0xFF&~(1<<5); pump(); m.memory[0x68EF]=0xFF; pump(); a1=mem("SND_MUTE")
m.memory[0x68EF]=0xFF&~(1<<5); pump(); m.memory[0x68EF]=0xFF; pump(); a2=mem("SND_MUTE")
print("M key: mute flag",a1,"then",a2); assert (a1,a2)==(1,0)
print("ALL SOUND TESTS OK")
