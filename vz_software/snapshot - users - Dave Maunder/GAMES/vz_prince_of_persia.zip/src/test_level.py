import re
from z80 import Z80Machine
from PIL import Image
sym={}
for ln in open("pop12.sym"):
    m_=re.match(r"(\w+)\s+EQU\s+([0-9A-F]+)H",ln.strip())
    if m_: sym[m_.group(1)]=int(m_.group(2),16)
m=Z80Machine()
print("tick attrs:",[n for n in dir(m) if 'tick' in n.lower()])
m.set_memory_block(0x7B00,open("pop12.bin","rb").read())
m.memory[sym["TITLE_SCREEN"]]=0xC9   # tests start in the game, not on the title
m.memory[sym["INTRO_SCREEN"]]=0xC9   # ... nor on the intro picture
for a in (0x68FE,0x68FD,0x68FB,0x68F7,0x68EF,0x68DF,0x68BF,0x687F): m.memory[a]=0xFF
m.pc=0x7B00; m.sp=0x8000
SETB=sym["SET_BANK"]; FD=sym["FRAME_DONE"]
m.set_breakpoint(SETB); m.set_breakpoint(FD)
banks=[bytearray(2048) for _ in range(3)]
def mem(n): return m.memory[sym[n]]
def poke(n,v): m.memory[sym[n]]=v
def keys(left=False,right=False,a=False,d=False,s=False):
    v=0xFF
    if left:  v&=~(1<<4)
    if right: v&=~(1<<1)
    m.memory[0x68FB]=v
    w=0xFF
    if a: w&=~(1<<4)
    if d: w&=~(1<<3)
    if s: w&=~(1<<1)
    m.memory[0x68FD]=w
chunk=0
def pump():
    """run until FRAME_DONE; handle bank switching + fake vsync."""
    global chunk
    for _ in range(600000):
        chunk+=1
        m.memory[0x6800]=0x80 if chunk&1 else 0x00
        m.ticks_to_stop=1500
        m.run()
        if m.pc==SETB:
            old=m.memory[sym["CUR_BANK"]]; new=m.a
            banks[old][:]=bytes(m.memory[0x7000:0x7800]); m.memory[0x7000:0x7800]=bytes(banks[new])
            m.step_over_breakpoint()
        elif m.pc==FD:
            m.step_over_breakpoint(); return
    raise SystemExit("never finished")
def vram():
    cur=m.memory[sym["CUR_BANK"]]; banks[cur][:]=bytes(m.memory[0x7000:0x7800])
    return b"".join(bytes(b) for b in banks)
def lit(v,x,y): return bool(v[y*32+(x>>3)]&(0x80>>(x&7)))
def snap(name,crop=None):
    v=vram(); S=3; im=Image.new("RGB",(256*S,192*S),(0,96,0))
    for y in range(192):
        for x in range(256):
            if lit(v,x,y):
                for dy in range(S):
                    for dx in range(S): im.putpixel((x*S+dx,y*S+dy),(0,255,0))
    if crop: im=im.crop(crop)
    im.save(name)
def ent(base):
    a=sym[base]; k=("x","y","face","frame","fs","fi","hp","tmr","row")
    return {n:m.memory[a+i] for i,n in enumerate(k)}
P=lambda: ent("P_ENT"); G=lambda: ent("G_ENT")

pump()
def tele(px=100,gx=124,gro=0,sword=1,php=3,ghp=3):
    for n,v in (("PX",px),("PY",82),("PFACE",0),("PFRAME",0),("PROW",1),("PSTATE",0),("PFS",0),("PSWORD",sword),("PHP",php),("PTMR",0),
                ("GX",gx),("GY",82),("GFACE",1),("GFRAME",9),("GFS",0),("GHP",ghp),("GTMR",0),("GROW",gro),("JPREV",0),("DPREV",0)):
        poke(n,v)
def frames_(n,**k):
    for _ in range(n): keys(**k); pump()

from PIL import Image
def load_room(n):
    m.sp-=2; m.memory[m.sp]=FD&255; m.memory[m.sp+1]=FD>>8; m.a=n; m.pc=sym["LOAD_ROOM"]; pump()
def stage(px,py,row,face=0,gro=0,active=None):
    for n,v in (("PX",px),("PY",py),("PROW",row),("PFACE",face),("PFRAME",0),("PSTATE",0),("PFS",0),("PSWORD",0),("PHP",3),("GROW",gro),
                ("JPREV",0),("DPREV",0),("RUNPH",0),("TIDX",0),("LTMR",0),("FALLN",0)): poke(n,v)
    if active is not None: poke("G_ACTIVE",active)
    keys()
def run(n,**k):
    out=[]
    for _ in range(n):
        keys(**k); pump(); out.append((P()["frame"],P()["x"],P()["y"],mem("PSTATE")))
    return out
def room(): return mem("CUR_ROOM")
pump()
# ============ 1) fall damage ============
ROOMMAP=sym["ROOM_MAP"]
# (a) one row: safe
stage(72,18,0,face=1); poke("PSTATE",1); poke("FALLN",0); poke("GROW",0)
for _ in range(20): keys(); pump()
print("fall 1 row  -> hp",P()["hp"],"row",P()["row"],"state",mem("PSTATE")); assert P()["hp"]==3 and P()["row"]==1
# (b) two rows (make column 2: empty at rows 0-1, floor on row 2): -1 HP and a longer landing crouch
m.memory[ROOMMAP+8+2]=0; m.memory[ROOMMAP+16+2]=3
stage(72,18,0,face=1); poke("PSTATE",1)
fr=[]
for _ in range(30): keys(); pump(); fr.append((P()["frame"],mem("PSTATE")))
print("fall 2 rows -> hp",P()["hp"],"row",P()["row"],"py",P()["y"],"crouch ticks",sum(1 for f in fr if f[0]==27)); assert P()["hp"]==2 and P()["row"]==2 and P()["y"]==146
assert sum(1 for f in fr if f[0]==27)>=4
# (c) three rows: fatal, then the fight machinery restarts the level
stage(72,18,0,face=1); poke("PSTATE",1); poke("FALLN",1)
died=False
for _ in range(60):
    keys(); pump()
    if P()["fs"]==5: died=True; hp_at_death=P()["hp"]; break
print("fall 3 rows -> dead",died,"hp",P()["hp"],"frame",P()["frame"]); assert died and P()["hp"]==0 and P()["frame"]==15
for _ in range(40): keys(); pump()
print("   then restart -> room",room(),"hp",P()["hp"]); assert room()==0 and P()["hp"]==3
# ============ 2) climbing down ============
# (a) gap on the left: top ledge of room 1, hang from its left end and drop onto the floor of row 1
load_room(1); stage(100,18,0,face=1,active=0)
seq=run(1,s=True); seq+=run(14,s=True)
frames=[a[0] for a in seq]
print("hang down L frames",frames); 
assert frames[:5]==[34,8,7,6,6] and 32 in frames and 27 in frames
for _ in range(6): keys(); pump()
print("   ->",P(),"state",mem("PSTATE")); assert P()["row"]==1 and P()["y"]==82 and P()["hp"]==3 and P()["face"]==0
# (b) gap on the right: pillar end of room 0's row-1 floor; give the pit a floor on row 2 to land on
load_room(0); m.memory[ROOMMAP+16+4]=3
stage(108,82,1,face=0,gro=0,active=0)
seq=run(15,s=True); frames=[a[0] for a in seq]
print("hang down R frames",frames)
assert frames[:5]==[34,8,7,6,6] and 32 in frames
for _ in range(6): keys(); pump()
print("   ->",P()); assert P()["row"]==2 and P()["y"]==146 and P()["hp"]==3 and P()["face"]==1
# (c) not at an edge: S just crouches
stage(40,82,1,face=0); load_room(0); stage(40,82,1,face=0,active=0); r=run(2,s=True); print("crouch mid-floor",[a[0] for a in r]); assert [a[0] for a in r]==[26,26]
# ============ 3) the exit ============
def spin(n):
    global chunk
    for _ in range(n):
        chunk+=1; m.memory[0x6800]=0x80 if chunk&1 else 0x00; m.ticks_to_stop=1500; m.run()
        if m.pc==SETB:
            old=m.memory[sym["CUR_BANK"]]; new=m.a
            banks[old][:]=bytes(m.memory[0x7000:0x7800]); m.memory[0x7000:0x7800]=bytes(banks[new]); m.step_over_breakpoint()
load_room(7); stage(184,146,2,face=0,active=0)
keys(); m.memory[sym["PSTATE"]]=0
for _ in range(3): keys(); 
pump_done=False
keys()
# walk onto the door: the frame that sees him standing in it enters the win screen and waits for A
for i in range(12):
    keys(right=True)
    chunk+=0
    for _ in range(4000):
        chunk+=1; m.memory[0x6800]=0x80 if chunk&1 else 0x00; m.ticks_to_stop=1500; m.run()
        if m.pc==SETB:
            old=m.memory[sym["CUR_BANK"]]; new=m.a
            banks[old][:]=bytes(m.memory[0x7000:0x7800]); m.memory[0x7000:0x7800]=bytes(banks[new]); m.step_over_breakpoint()
        elif m.pc==FD: m.step_over_breakpoint(); break
        if mem("WINFLAG")==0 and False: pass
        if mem("WINFLAG")==1 and chunk%7==0:
            spin(200); break
    if mem("WINFLAG")==1: break
print("exit reached: WINFLAG",mem("WINFLAG")); assert mem("WINFLAG")==1
keys(); spin(3000)
v=vram(); lit_px=sum(bin(b).count("1") for b in v[64*32:128*32])
print("win screen: lit pixels in the middle bank",lit_px); assert lit_px>150
snap("win.png",(0,100,768,400))
keys(a=True); spin(300); keys()
for _ in range(3): pump()
print("after A -> room",room(),"win flag",mem("WINFLAG"),"prince",P()["x"],P()["row"]); assert room()==0 and mem("WINFLAG")==0 and P()["x"]==40
print("   (the exit moved us to level",mem("CUR_LEVEL")+1,"- switching back to level 1 for the scripted walk)")
assert mem("CUR_LEVEL")==1
m.sp-=2; m.memory[m.sp]=FD&255; m.memory[m.sp+1]=FD>>8; m.a=0; m.pc=sym["SET_LEVEL"]; pump()
m.sp-=2; m.memory[m.sp]=FD&255; m.memory[m.sp+1]=FD>>8; m.pc=sym["RESPAWN"]; pump()

# ============ 4) a scripted run through the second half of the level ============
def hold_until(cond,maxn=60,**k):
    for i in range(maxn):
        keys(**k); pump()
        if cond(): return i+1
    raise SystemExit("condition never met: "+str(P())+" room "+str(room()))
load_room(3); stage(180,18,0,face=0,active=0)
hold_until(lambda: room()==4,right=True); print("3 -> 4: prince x",P()["x"])
poke("G_ACTIVE",0)
hold_until(lambda: P()["x"]>=84,right=True)                    # run up to the spikes gap (col 3)
keys(right=True,a=True); pump(); keys()                          # running jump
for _ in range(12): pump()
print("jumped the spikes: x",P()["x"],"row",P()["row"],"state",mem("PSTATE"),"hp",P()["hp"]); assert room()==4 and P()["x"]>=140 and mem("PSTATE")==0 and P()["hp"]==3
hold_until(lambda: room()==5,right=True); print("4 -> 5: prince x",P()["x"]); poke("G_ACTIVE",0)
stage(170,18,0,face=0,active=0)                                  # under the gap in the room above, facing its right-hand floor
keys(a=True); pump(); keys()
for _ in range(11): pump()
print("climb up 5 -> 6: room",room(),"row",P()["row"],"x",P()["x"],"y",P()["y"]); assert room()==6 and P()["row"]==2 and P()["y"]==146
hold_until(lambda: room()==7,right=True); print("6 -> 7: prince x",P()["x"]); poke("G_ACTIVE",0)
for i in range(80):
    keys(right=True)
    for _ in range(4000):
        chunk+=1; m.memory[0x6800]=0x80 if chunk&1 else 0x00; m.ticks_to_stop=1500; m.run()
        if m.pc==SETB:
            old=m.memory[sym["CUR_BANK"]]; new=m.a
            banks[old][:]=bytes(m.memory[0x7000:0x7800]); m.memory[0x7000:0x7800]=bytes(banks[new]); m.step_over_breakpoint()
        elif m.pc==FD: m.step_over_breakpoint(); break
        if mem("WINFLAG")==1: break
    if mem("WINFLAG")==1: break
print("reached the exit door in room",room(),"-> WINFLAG",mem("WINFLAG")); assert mem("WINFLAG")==1 and room()==7
print("ALL STEP-8 TESTS OK")
