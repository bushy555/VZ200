# VZ PRINCE - a Prince-of-Persia-style game for the VZ200 (256x192 mono, Z80)

Runs from $7B00 (32 KB layout: RAM to $FFFF, stack and a 256-byte table page at $FE00).  ~29 KB of code and data, then a 2 KB off-screen buffer (SHADOW, right after the program, not saved in the .VZ); about 2 KB free (after the ZX0 intro saved 1.4 KB).
`python3 build.py` -> `VZPRINCE.VZ`.   `python3 build.py --tests` also runs every test (needs `pip install z80 pillow` and pasmo).

## Controls
On the intro picture: 1 / 2 / 3 choose the start level (skeletons are in level 3), A starts.
Z / X move - A jump (with Z/X: running jump) / strike with sword - S crouch (at a ledge: climb down; on a potion: drink)
D draw / sheathe sword - S parry (sword out) - M sound on/off.  Stand near a ledge and press A to grab it and climb.

## Files
| file | what it is |
|---|---|
| `pop12.asm` | the whole engine (assemble with pasmo; it INCLUDEs the generated `_*.inc` files) |
| `tiles.txt`  | (also the 3 torch pictures `TORCH`, `TORCH2`, `TORCH3`: the engine flickers the wall torches through them, sequence 0,1,0,2, every second frame) |
| `tiles.txt`  | 32x64 tile art (`#` = lit).  Section order = tile id; floor-type tiles must stay before SPIKES |
| `prince_gen.py`, `sprites_classic.txt` | the prince's frames are DRAWN by `prince_gen.py` from a small body model (turban, face, vest, baggy trousers; every pose is a few joint angles in the script) into `sprites.txt`. `sprites_classic.txt` is the earlier blocky art (`python3 build.py --sprites sprites_classic.txt`) |
| `sprites.txt`| prince frames 16x42 and wider, `[NAME xo= yo=]`; frames 9-18 are also built as dithered guard frames |
| `levels.txt` | levels and rooms as ASCII (legend at the top of the file) |
| `make_*.py`  | generators: txt -> `_tiles.inc`, `_sprites.inc`, `_levels.inc`, `_font.inc` |
| `intro_src.png`, `make_intro.py` | the palace picture shown before the title: any image is scaled to 256x171, dithered and written to `_intro.inc` |
| `skel.txt`, `skeletonize.py` | skeleton fighter frames with stick-figure legs (made from the sword-fight frames 9-18; edit freely, re-running the script overwrites them). `skel_hollow.txt` is the earlier hollow-legged version (`python3 build.py --skel skel_hollow.txt`). A room header with `kind=1` turns its guard into a skeleton (4 hits instead of 3) |
| `decor.txt` | the two cracked-brick wall-detail pictures (24x14); the engine scatters them on back walls with a stable pseudo-random pattern |
| `dither_floor.py`, `tiles_hatch.txt` | the floor is drawn as a dithered plane (in `tiles.txt`). `tiles_hatch.txt` is the earlier hatch-line floor; build it with `python3 build.py --tiles tiles_hatch.txt --name VZPRINCEH` |
| `art_tool.py`| export the art to PNG sheets for any paint program, import it back, preview whole levels as pictures |
| `build.py`   | generators + pasmo + `.vz` writer |
| `test_ending.py` | the last level's exit shows the palace picture with YOU ESCAPED, then the game goes round to level 1 |
| `test_*.py`  | emulator tests (z80 package): blitter pixel-exactness, rooms, fight, jump, climb, animation, items, gates, sound, title, chompers/levels |

## Drawing your own art
    python3 art_tool.py export-sprites      # -> sprites_sheet.png (+ .json): every frame, 6x, byte grid, reference box
    (paint in any editor: bright green or white = lit, dark = off; the faint grid/box/labels are ignored)
    python3 art_tool.py import-sprites      # -> sprites.txt
    python3 build.py
Same for `export-tiles` / `import-tiles`.  `python3 art_tool.py preview-levels` draws every room of every level.
Frames can be any width (multiple of 8) and height; `xo`/`yo` place the art relative to the 16x42 reference box (the box
is what collision uses; left-facing frames are mirrored about its centre).  Keep frame ORDER: the engine addresses frames by
index (the FR_ constants in the asm: 0 stand, 1-4 run, 5 jump, 6 hang, 7-8 climb, 9-18 sword fight, 19+ locomotion).

## Memory map
$7B00 code+data (to ~$EFCE) | SHADOW 2 KB buffer right after it | $FE00 mirror table (256 B, built at start) + stack grows down from there | $7000-$77FF video window (banked via port 32).

## Things I could NOT check without real hardware - please test these first
1. **Video init** (port 32 = 28/29/30 selects the bank; latch $6800 rewritten with 8) was copied from your Lode Runner notes.  `VIDEO_INIT`/`SET_BANK`.
2. **Frame wait** polls bit 7 of $6800 as the vsync flag (waits for it to fall, `FRAME_VBL` = 1 per frame).  If the game runs far too fast or hangs, the polarity/flag is wrong - `WAIT_FRAME`.
3. **Keyboard rows**: Z,X = $68FB bits 4,1; A,D,S = $68FD bits 4,3,1; M = $68EF bit 5 (all active low).
4. **Sound**: the speaker is driven by latch bits D0 and D5 in opposite phase (values 9 and $28).  If it is silent or buzzy, change the two values in `BEEP`/`NOISE`.  Pitches are by calculation, not by ear: edit the tables at `SND_TBL`.
5. **Speed**: about 50-68 ms of work per frame (measured in T-states in the emulator) + 1 vsync = roughly 11-14 fps.
6. Tile/sprite data are plain RAM reads, so any VZ with RAM $8000-$FFFF should run it; the stack page at $FE00 needs the 32 KB layout.

## Known limits / ideas
No falling spikes or mirrors, guards ignore plates/chompers, gates reset when you leave the room (so every gate has a second plate on its far side, otherwise you could not come back through it - `test_backtrack.py`), one potion and one loose
tile per room persist (flags), up to 32 rooms per level.  Levels 2 and 3 are proven solvable by scripted bots, not by playing.


## Release 13 changes
* **Flicker-free sprites** (`UPDATE_SCREEN`): the cells touched by the old and new boxes of the prince and the guard are built in RAM (`SHADOW`: tile, guard, prince) and copied to the screen in one quick pass. Sprites are never blank on screen, so the thin horizontal sword no longer vanishes. Pictures are pixel-identical to the old method (`cmp_run.py`); about 7 ms more work per frame, same 80 ms vsync period.
* **Sword-drawn walking** now animates: ADVANCE/RETREAT, step A (`FR_SWA`), GARDE, step B (`FR_SWB`). The two new frames are drawn by `gen_swstep.py` / `prince_gen.py` (frames 35 and 36, appended so existing frame numbers are unchanged).
* **Key 2** on the intro picture fixed (row $68F7 bit 1).
* `pop13_full.asm` is the whole program in ONE file (data includes expanded); `test_swwalk.py` tests the new walk.
* **Guards and skeletons now walk with the sword out too** (same cycle as the prince, `STEP_ANIM`, frames 35/36 mapped to guard/skeleton table entries 10/11). The skeleton step frames are appended to skel.txt by `gen_swstep_skel.py` (skel.txt is hand-edited and is never regenerated). `test_guardwalk.py` covers it.\n* **ZX0-compressed intro / ending picture**: make_intro.py now writes the 256x171 picture as 3 ZX0 chunks (one per video bank, 2048 bytes each when unpacked; 5472 -> 3952 bytes). The game unpacks each chunk into SHADOW with `DZX0_STANDARD` (Einar Saukas & Urusergi, BSD-3, 68 bytes) and copies it into its bank - a bank is only 2 KB and ZX0 needs to read back its own output, so it cannot unpack straight into the screen. `test_intro_zx0.py` proves the picture is bit-identical to the old uncompressed one. The compressor is found as ./zx0(.exe), on the PATH, or built from ./zx0_src with a C compiler (cc/gcc/clang); if none exists, the existing _intro.inc is kept. `make_intro_uncompressed.py` is the old version.
* **Dithered bricks** (like the Apple ][ original): tiles.txt now has checkerboard-dithered brick faces on WALL, WALLR and PILLAR (outlines and mortar unchanged). `brick_dither.py` makes the variants from a solid-brick tile file; the previous solid-brick art is kept as `tiles_solid_bricks.txt` (build it with `python3 build.py --tiles tiles_solid_bricks.txt --name VZPRINCES`).
