import re,sys,hashlib,json
from z80 import Z80Machine
base="pop12"
sym={}
for ln in open(base+".sym"):
    m_=re.match(r"(\w+)\s+EQU\s+([0-9A-F]+)H",ln.strip())
    if m_: sym[m_.group(1)]=int(m_.group(2),16)
m=Z80Machine()
m.set_memory_block(0x7B00,open(base+".bin","rb").read())
m.memory[sym["TITLE_SCREEN"]]=0xC9; m.memory[sym["INTRO_SCREEN"]]=0xC9
for a in (0x68FE,0x68FD,0x68FB,0x68F7,0x68EF,0x68DF,0x68BF,0x687F): m.memory[a]=0xFF
m.pc=0x7B00; m.sp=0x8000
SETB=sym["SET_BANK"]; FD=sym["FRAME_DONE"]
m.set_breakpoint(SETB); m.set_breakpoint(FD)
banks=[bytearray(2048) for _ in range(3)]
def poke(n,v): m.memory[sym[n]]=v
def keys(left=False,right=False,a=False,d=False,s=False):
    v=0xFF
    if left: v&=~(1<<4)
    if right: v&=~(1<<1)
    m.memory[0x68FB]=v
    w=0xFF
    if a: w&=~(1<<4)
    if d: w&=~(1<<3)
    if s: w&=~(1<<1)
    m.memory[0x68FD]=w
chunk=0; ticks=0
def pump():
    global chunk,ticks
    for _ in range(600000):
        chunk+=1
        m.memory[0x6800]=0x80 if chunk&1 else 0x00
        m.ticks_to_stop=1500
        m.run()
        ticks+=1500-max(0,m.ticks_to_stop) if False else 0
        if m.pc==SETB:
            old=m.memory[sym["CUR_BANK"]]; new=m.a
            banks[old][:]=bytes(m.memory[0x7000:0x7800]); m.memory[0x7000:0x7800]=bytes(banks[new])
            m.step_over_breakpoint()
        elif m.pc==FD:
            m.step_over_breakpoint(); return
    raise SystemExit("never finished")
def vram():
    cur=m.memory[sym["CUR_BANK"]]; banks[cur][:]=bytes(m.memory[0x7000:0x7800])
    return b"".join(bytes(b) for b in banks)
pump()
def stage(kind):
    for n,v in (("PX",30),("PY",82),("PFACE",0),("PFRAME",9),("PROW",1),("PSTATE",0),("PFS",0),("PSWORD",1),("PHP",3),("PTMR",0),
                ("G_ACTIVE",1),("GX",120),("GY",82),("GFACE",1),("GFRAME",9),("GFS",0),("GHP",3),("GTMR",0),("GROW",1),("GKIND",kind),("JPREV",0),("DPREV",0)):
        poke(n,v)
    keys()
for kind,name in ((0,"guard"),(1,"skeleton")):
    stage(kind); pump()
    seen=[]
    for i in range(90):
        keys(); pump(); seen.append(m.memory[sym["GFRAME"]])
        if m.memory[sym["GX"]]<75: break
    print(name,"frames while closing in:",seen[:24],"... guard x",m.memory[sym["GX"]])
    assert 35 in seen and 36 in seen and 10 in seen, name+" must cycle ADV, SWA, GARDE, SWB"
    assert all(f in (9,10,35,36,16,11,12,13,14,17,18) for f in seen), name+" frame out of range"
    assert not any(seen[i]==seen[i+1]==35 for i in range(len(seen)-1)), "no stuck frame"
print("GUARD WALK OK")
