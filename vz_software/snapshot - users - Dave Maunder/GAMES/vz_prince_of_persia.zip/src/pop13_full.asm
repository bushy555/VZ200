; ============================================================================
; POP12 - Prince-of-Persia style engine for the VZ200, 256x192 mono (Aus)
; Step 12: CHOMPERS (jaws slam every 16 frames, deadly while shut) and several LEVELS: the exit door
;         leads to the next level in levels.txt; after the last one the game starts over.
; Step 11: SOUND (speaker bits on the latch; short blocking effects played after each frame is drawn;
;         M toggles mute) and a TITLE SCREEN (big lettering, controls, blinking prompt, jingle).
; Step 10: GATES and PRESSURE PLATES.  A plate opens every gate in the room (6 frames up), they hold
;         ~11 s, then slam shut - never on someone standing in a doorway.  Closed gates block both fighters.
; Step 9: HEALTH POTIONS (crouch on one with S to drink: +1 HP) and LOOSE FLOOR tiles (they crumble ~4
;         frames after you step on them; kills/potions/collapses are remembered per room).
; Step 8: FALL DAMAGE (1 row safe, 2 rows -1 HP, 3+ rows fatal), CLIMBING DOWN (hang from a ledge,
;         S at an edge, then drop), a LEVEL EXIT door with a 'LEVEL COMPLETE' screen, and an
;         8-room level in levels.txt.
; Step 7: FULL ANIMATION SET - run start/stop, turn, crouch (S), landing, standing vs running
;         jump, fall frames, longer climb, sword draw/sheathe and retreat poses.
; Step 6: MULTI-ROOM LEVELS (levels.txt): walk/jump off a screen edge, fall into the room
;         below, climb up into the room above; guards per room, kills are remembered.
; Step 5: SWORD FIGHT.  A guard (simple AI) shares the room; D draws/sheathes the
;         sword; with it drawn: Z/X step, A strike, S hold = parry.  3 hit points
;         each (pips on the bottom strip); a death resets the fight.
;         Variable-size sprites (width/height/offset per frame), runtime mirroring.
; Earlier steps: room renderer, run, jump, ledge climb (see pop04).  Origin $7B00.
;
; Screen = 3 floor rows x 8 columns, each cell 32 px (4 bytes) x 64 lines, so
; one floor row == one video bank.
; Keys: Z = left, X = right, A = jump/strike, D = draw/sheathe sword, S = parry.
; ============================================================================

VRAM        EQU $7000
LATCH       EQU $6800
PORT_RES    EQU 32
ROOM_W      EQU 8
ROOM_H      EQU 3

KEYROW_ZX   EQU $68FB       ; row A2: V Z C SHFT X B = D5..D0 (active low)
KEY_Z_BIT   EQU 4
KEY_X_BIT   EQU 1
KEYROW_123  EQU $68F7       ; row A3: 4 1 3 2 5 = D5..D1 (active low)
KEYROW_A    EQU $68FD       ; row A1: F A D CTRL S G = D5..D0
KEY_A_BIT   EQU 4
KEY_D_BIT   EQU 3
KEY_S_BIT   EQU 1
KEYROW_M    EQU $68EF       ; row 4: M SPACE , - . N = D5..D0
KEY_M_BIT   EQU 5
SND_STEP    EQU 1           ; sound ids = priorities (a louder event overrides a quieter one)
SND_GATE    EQU 2
SND_LAND    EQU 3
SND_DRAW    EQU 4
SND_PARRY   EQU 5
SND_HIT     EQU 6
SND_LOOSE   EQU 7
SND_FALLHURT EQU 8
SND_POTION  EQU 9
SND_DEATH   EQU 10

STEP        EQU 4           ; pixels per game frame when running
FALLSTEP    EQU 8           ; pixels per frame when falling (must divide 64)
MAXX        EQU 239         ; reference-box left edge limit
SPR_H       EQU 42          ; height of the reference box (feet = top + SPR_H-1)
JUMP_LEN    EQU 8
FRAME_VBL   EQU 1           ; vsyncs waited after the work (work ~50-68 ms + 20 ms = ~12 fps)

; fighter record layout (prince = P_ENT, guard = G_ENT)
E_X         EQU 0           ; reference-box left edge (px)
E_Y         EQU 1           ; reference-box top line
E_FACE      EQU 2           ; 0 right, 1 left
E_FRAME     EQU 3
E_FS        EQU 4           ; fight state
E_FI        EQU 5           ; step within a strike
E_HP        EQU 6
E_TMR       EQU 7
E_ROW       EQU 8           ; floor row he stands on
E_BL        EQU 9           ; bounds of what was last drawn (for erasing)
E_BR        EQU 10
E_BT        EQU 11
E_BB        EQU 12

FS_GARDE    EQU 0
FS_STRIKE   EQU 2
FS_PARRY    EQU 3
FS_HURT     EQU 4
FS_DEAD     EQU 5
FR_GARDE    EQU 9
FR_ADV      EQU 10
FR_ST1      EQU 11
FR_ST2      EQU 12
FR_PARRY    EQU 13
FR_HURT     EQU 14
FR_DEAD     EQU 15
FR_RETREAT  EQU 16          ; frames 9-18 also exist as dithered guard copies
FR_DRAW1    EQU 17
FR_DRAW2    EQU 18
FR_RUNST1   EQU 19          ; locomotion frames
FR_RUNST2   EQU 20
FR_STOP1    EQU 21
FR_STOP2    EQU 22
FR_TURN1    EQU 23
FR_TURN2    EQU 24
FR_TURN3    EQU 25
FR_CROUCH   EQU 26
FR_LAND     EQU 27
FR_JWIND    EQU 28
FR_JRISE    EQU 29
FR_JAPEX    EQU 30
FR_JFALL    EQU 31
FR_FALL     EQU 32
FR_JUMPUP   EQU 33
FR_CLIMB3   EQU 34
FR_SWA      EQU 35          ; sword-drawn walk: feet passing, two phases
FR_SWB      EQU 36
FS_DRAW     EQU 1           ; drawing the sword (2 frames)
FS_SHEATH   EQU 6           ; putting it away (2 frames)
HIT_RANGE   EQU 30          ; centre-to-centre distance a lunge can reach
MIN_SEP     EQU 14          ; fighters cannot get closer than this
FSTEP       EQU 3           ; px per step with the sword out
ENGAGE      EQU 96          ; guard wakes up inside this distance
WALK_RANGE  EQU 30          ; guard stops closing in at this distance

REV_TBL     EQU $FE00       ; 256-byte bit-reverse table, built at start (page aligned, top of the 32 KB)
STACK_TOP   EQU $FE00       ; stack grows down from here (needs the 32 KB layout: RAM to $FFFF)
NONE        EQU 255
PLATE_HOLD  EQU 140         ; frames a gate stays up after its plate was pressed (~11 s)
T_POTION    EQU $40         ; tile decoration bit: a potion stands on this floor tile (T_TORCH = $80)
POTION_Y    EQU 41
DECOR_Y     EQU 14
POTION_H    EQU 9

            ORG $7B00

START:      DI
            LD   SP,STACK_TOP
            CALL VIDEO_INIT
            CALL INIT_REV
            CALL INTRO_SCREEN           ; the palace picture, then the title screen
            CALL TITLE_SCREEN
            LD   A,(START_LV)
            CALL SET_LEVEL              ; level 1 (or the one picked on the intro screen with keys 1-3)
            CALL RESET_FIGHT            ; loads the start room and draws it
            CALL DRAW_GUARD
            CALL DRAW_PRINCE

GAME_LOOP:  CALL WAIT_FRAME
            CALL READ_INPUT
            CALL CHECK_MUTE
            CALL UPDATE
            CALL CHECK_EXIT
            CALL CHECK_LOOSE
            CALL CHECK_GATES
            CALL CHECK_CHOMP
            LD   A,(WINFLAG)
            OR   A
            CALL NZ,DO_WIN
            CALL GUARD_STEP
            CALL UPDATE_SCREEN          ; torches, then compose the changed cells off-screen and copy them over
            CALL DRAW_STATUS
            CALL PLAY_SOUND             ; effects last: the picture is already up to date
FRAME_DONE: JR   GAME_LOOP

; ---------------------------------------------------------------------------
; Video
; ---------------------------------------------------------------------------
VIDEO_INIT: XOR  A
SET_BANK:   LD   (CUR_BANK),A           ; A = 0..2 -> lines 0-63/64-127/128-191
            ADD  A,28
            OUT  (PORT_RES),A
            LD   A,8
            LD   (LATCH),A
            RET

; wait for the start of vertical blank, FRAME_VBL times (bit 7 of $6800 = /FS)
WAIT_FRAME: LD   B,FRAME_VBL
WF_LOOP:    LD   A,(LATCH)
            BIT  7,A
            JR   Z,WF_LOOP
WF_BLANK:   LD   A,(LATCH)
            BIT  7,A
            JR   NZ,WF_BLANK
            DJNZ WF_LOOP
            RET

; build the 256-entry bit-reverse table used to mirror sprites
INIT_REV:   LD   HL,REV_TBL
            LD   C,0
IR_LOOP:    LD   A,C
            LD   D,0
            LD   B,8
IR_BIT:     RRA
            RL   D
            DJNZ IR_BIT
            LD   (HL),D
            INC  HL
            INC  C
            JR   NZ,IR_LOOP
            RET

; ---------------------------------------------------------------------------
; Input -> KEYS: bit0 left, bit1 right, bit2 A (press), bit3 D (press), bit4 S (held)
; ---------------------------------------------------------------------------
READ_INPUT: LD   A,(KEYROW_ZX)
            LD   B,A
            LD   C,0
            BIT  KEY_Z_BIT,B
            JR   NZ,RI_NOL
            SET  0,C
RI_NOL:     BIT  KEY_X_BIT,B
            JR   NZ,RI_NOR
            SET  1,C
RI_NOR:     LD   A,(KEYROW_A)
            LD   B,A
            BIT  KEY_S_BIT,B
            JR   NZ,RI_NOS
            SET  4,C
RI_NOS:     LD   A,0
            BIT  KEY_A_BIT,B
            JR   NZ,RI_A0
            LD   A,1
RI_A0:      LD   D,A
            LD   A,(JPREV)
            LD   E,A
            LD   A,D
            LD   (JPREV),A
            LD   A,E
            OR   A
            JR   NZ,RI_DK
            LD   A,D
            OR   A
            JR   Z,RI_DK
            SET  2,C
RI_DK:      LD   A,0
            BIT  KEY_D_BIT,B
            JR   NZ,RI_D0
            LD   A,1
RI_D0:      LD   D,A
            LD   A,(DPREV)
            LD   E,A
            LD   A,D
            LD   (DPREV),A
            LD   A,E
            OR   A
            JR   NZ,RI_DONE
            LD   A,D
            OR   A
            JR   Z,RI_DONE
            SET  3,C
RI_DONE:    LD   A,C
            LD   (KEYS),A
            RET

; ---------------------------------------------------------------------------
; Room renderer (from pop01)
; ---------------------------------------------------------------------------
RENDER_ROOM:
            XOR  A
            LD   (RR_ROW),A
RR_ROWLOOP: LD   A,(RR_ROW)
            CALL SET_BANK
            LD   HL,VRAM
            LD   DE,VRAM+1
            LD   BC,2047
            LD   (HL),0
            LDIR
            LD   A,(RR_ROW)
            ADD  A,A
            ADD  A,A
            ADD  A,A
            LD   E,A
            LD   D,0
            LD   HL,ROOM_MAP
            ADD  HL,DE
            LD   B,ROOM_W
            LD   C,0
RR_COL:     PUSH BC
            PUSH HL
            LD   A,(HL)
            LD   B,C
            CALL DRAW_TILE
            POP  HL
            POP  BC
            INC  HL
            INC  C
            DJNZ RR_COL
            LD   A,(RR_ROW)
            INC  A
            LD   (RR_ROW),A
            CP   ROOM_H
            JR   NZ,RR_ROWLOOP
            RET

; CELL_ADDR - A = line in bank (0..63), B = column -> HL = VRAM+line*32+col*4
CELL_ADDR:  LD   L,A
            LD   H,0
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            LD   A,B
            ADD  A,A
            ADD  A,A
            LD   E,A
            LD   D,0
            ADD  HL,DE
            LD   DE,(DRAW_BASE)         ; VRAM normally, SHADOW while composing
            ADD  HL,DE
            RET

; DRAW_TILE - A = tile id (bit 7 = torch), B = column, current bank
DRAW_TILE:  PUSH AF
            PUSH BC
            AND  $3F
            JR   Z,DT_DECO
            LD   L,A
            LD   H,0
            ADD  HL,HL
            ADD  HL,HL
            LD   DE,TILE_TBL
            ADD  HL,DE
            LD   E,(HL)
            INC  HL
            LD   D,(HL)
            INC  HL
            LD   A,(HL)
            INC  HL
            LD   C,(HL)
            PUSH DE
            PUSH BC
            CALL CELL_ADDR
            EX   DE,HL
            POP  BC
            LD   A,C
            POP  HL
DT_LINE:    LDI
            LDI
            LDI
            LDI
            EX   DE,HL
            LD   BC,28
            ADD  HL,BC
            EX   DE,HL
            DEC  A
            JR   NZ,DT_LINE
DT_DECO:    POP  BC
            POP  AF
            LD   C,A                    ; C = tile id (decoration bits)
            BIT  7,A
            JR   NZ,DT_NOWD             ; no wall detail behind a torch
            AND  $3F
            JR   Z,DT_WD1               ; an empty cell, or a plain floor tile (FLOOR..FLOORL), may get some
            CP   T_FLOOR
            JR   C,DT_NOWD
            CP   T_PILLAR
            JR   NC,DT_NOWD
DT_WD1:     LD   A,(CUR_ROOM)           ; pseudo-random but stable: hash of level, room, row, column
            LD   D,A
            ADD  A,A
            ADD  A,A
            ADD  A,D                    ; room*5
            LD   D,A
            LD   A,(CUR_BANK)
            LD   E,A
            ADD  A,A
            ADD  A,E                    ; row*3
            ADD  A,D
            LD   D,A
            LD   A,(CUR_LEVEL)
            ADD  A,A
            ADD  A,A
            ADD  A,D
            LD   D,A
            LD   A,B
            ADD  A,A
            ADD  A,A
            ADD  A,A
            SUB  B                      ; column*7
            ADD  A,D
            AND  7
            CP   3
            JR   NZ,DT_NOWD
            PUSH BC
            CALL DT_DECOR               ; B = column
            POP  BC
DT_NOWD:    BIT  7,C
            JR   Z,DT_NOTORCH
            PUSH BC
            LD   A,TORCH_Y              ; torch: 2 bytes wide at byte column 1
            CALL CELL_ADDR
            INC  HL
            LD   DE,(TORCH_PTR)         ; the current flame frame
            LD   B,TORCH_H
DT_TL:      LD   A,(DE)
            OR   (HL)
            LD   (HL),A
            INC  DE
            INC  HL
            LD   A,(DE)
            OR   (HL)
            LD   (HL),A
            INC  DE
            LD   A,L
            ADD  A,31
            LD   L,A
            JR   NC,DT_TNC
            INC  H
DT_TNC:     DJNZ DT_TL
            POP  BC
DT_NOTORCH: BIT  6,C
            RET  Z
            LD   A,POTION_Y             ; potion: 1 byte wide at byte column 2
            CALL CELL_ADDR
            INC  HL
            INC  HL
            LD   DE,POTION_BMP
            LD   B,POTION_H
DT_PL:      LD   A,(DE)
            OR   (HL)
            LD   (HL),A
            INC  DE
            LD   A,L
            ADD  A,32
            LD   L,A
            JR   NC,DT_PNC
            INC  H
DT_PNC:     DJNZ DT_PL
            RET

POTION_BMP: DEFB $18,$18,$3C,$7E,$FF,$D7,$FF,$FF,$7E

; ---------------------------------------------------------------------------
; Torch flames: every second frame the next flame picture (sequence 0,1,0,2) is stored over the flame of every
; torch in the room.  The sprites have just been erased and are drawn again afterwards, so nothing can be overdrawn.
; ---------------------------------------------------------------------------
ANIM_TORCH: LD   A,(TORCH_T)
            INC  A
            LD   (TORCH_T),A
            AND  1
            RET  NZ
            LD   A,(TORCH_T)
            RRCA
            AND  3
            LD   E,A
            LD   D,0
            LD   HL,TORCH_SEQ
            ADD  HL,DE
            LD   A,(HL)
            ADD  A,A
            LD   E,A
            LD   HL,TORCH_FRAMES
            ADD  HL,DE
            LD   E,(HL)
            INC  HL
            LD   D,(HL)
            LD   (TORCH_PTR),DE
            LD   A,(CUR_BANK)
            PUSH AF
            LD   HL,ROOM_MAP
            LD   C,0                    ; row
AT_ROW:     LD   B,0                    ; column
AT_COL:     BIT  7,(HL)
            CALL NZ,AT_DRAW
            INC  HL
            INC  B
            LD   A,B
            CP   8
            JR   NZ,AT_COL
            INC  C
            LD   A,C
            CP   3
            JR   NZ,AT_ROW
            POP  AF
            JP   SET_BANK
AT_DRAW:    PUSH HL
            PUSH BC
            LD   A,C
            CALL SET_BANK
            LD   A,TORCH_Y
            CALL CELL_ADDR              ; B = column
            INC  HL
            LD   DE,(TORCH_PTR)
            LD   B,TORCH_H
AT_LINE:    LD   A,(DE)
            LD   (HL),A
            INC  DE
            INC  HL
            LD   A,(DE)
            LD   (HL),A
            INC  DE
            LD   A,L
            ADD  A,31
            LD   L,A
            JR   NC,AT_NC
            INC  H
AT_NC:      DJNZ AT_LINE
            POP  BC
            POP  HL
            RET
TORCH_SEQ:  DEFB 0,1,0,2
TORCH_FRAMES: DEFW TORCH_BMP,TORCH2_BMP,TORCH3_BMP

; wall detail: loose bricks / cracks on the dark back wall, 3 bytes wide x DECOR_H lines at byte column 1;
; the two pictures alternate with the cell's column
DT_DECOR:   PUSH BC
            LD   A,DECOR_Y
            CALL CELL_ADDR
            INC  HL
            POP  BC
            LD   DE,DECOR_BMP
            LD   A,B
            AND  1
            JR   Z,DD_GO
            LD   DE,DECOR_BMP+DECOR_H*3
DD_GO:      LD   B,DECOR_H
DD_LINE:    LD   C,3
DD_BYTE:    LD   A,(DE)
            OR   (HL)
            LD   (HL),A
            INC  DE
            INC  HL
            DEC  C
            JR   NZ,DD_BYTE
            LD   A,L
            ADD  A,29
            LD   L,A
            JR   NC,DD_NC
            INC  H
DD_NC:      DJNZ DD_LINE
            RET

; DRAW_CELL - B = column, C = row: clear that cell completely, redraw its tile
DRAW_CELL:  PUSH BC
            LD   A,C
            CALL SET_BANK
            POP  BC
            PUSH BC
            XOR  A
            CALL CELL_ADDR
            LD   B,64
            LD   DE,28
DC_CLR:     LD   (HL),0
            INC  HL
            LD   (HL),0
            INC  HL
            LD   (HL),0
            INC  HL
            LD   (HL),0
            INC  HL
            ADD  HL,DE
            DJNZ DC_CLR
            POP  BC
            LD   A,C
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,B
            LD   E,A
            LD   D,0
            LD   HL,ROOM_MAP
            ADD  HL,DE
            LD   A,(HL)
            JP   DRAW_TILE

; GET_TILE - B = column, C = row -> A = tile type (torch bit stripped)
GET_TILE:   LD   A,C
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,B
            LD   E,A
            LD   D,0
            LD   HL,ROOM_MAP
            ADD  HL,DE
            LD   A,(HL)
            AND  $3F
            RET

; ---------------------------------------------------------------------------
; ERASE_AT - redraw every cell inside the pixel box ER_L..ER_R x ER_T..ER_B
; ---------------------------------------------------------------------------
ERASE_PRINCE:
            LD   A,(P_ENT+E_BL)
            LD   (ER_L),A
            LD   A,(P_ENT+E_BR)
            LD   (ER_R),A
            LD   A,(P_ENT+E_BT)
            LD   (ER_T),A
            LD   A,(P_ENT+E_BB)
            LD   (ER_B),A
            JR   ERASE_AT
ERASE_GUARD:
            LD   A,(G_ACTIVE)
            OR   A
            RET  Z
            LD   A,(G_ENT+E_BL)
            LD   (ER_L),A
            LD   A,(G_ENT+E_BR)
            LD   (ER_R),A
            LD   A,(G_ENT+E_BT)
            LD   (ER_T),A
            LD   A,(G_ENT+E_BB)
            LD   (ER_B),A
ERASE_AT:   LD   A,(ER_T)               ; clip the box to the screen
            CP   192
            JR   C,EA_TOPOK
            LD   A,(ER_B)               ; top is off-screen:
            CP   192
            RET  NC                     ;   all of it is -> nothing to erase
            XOR  A                      ;   or it wrapped over the top -> start at line 0
            LD   (ER_T),A
EA_TOPOK:   LD   A,(ER_B)
            CP   192
            JR   C,EA_GO
            LD   A,191
            LD   (ER_B),A
EA_GO:      LD   A,(ER_L)
            RLCA
            RLCA
            RLCA
            AND  7
            LD   (ER_C0),A
            LD   A,(ER_R)
            RLCA
            RLCA
            RLCA
            AND  7
            LD   (ER_C1),A
            LD   A,(ER_T)
            RLCA
            RLCA
            AND  3
            LD   (ER_R0),A
            LD   A,(ER_B)
            RLCA
            RLCA
            AND  3
            LD   (ER_R1),A
ER_ROW:     LD   A,(ER_C0)
            LD   (ER_C),A
ER_COL:     LD   A,(ER_C)
            LD   B,A
            LD   A,(ER_R0)
            LD   C,A
            CALL DRAW_CELL
            LD   A,(ER_C)
            INC  A
            LD   (ER_C),A
            LD   B,A
            LD   A,(ER_C1)
            CP   B
            JR   NC,ER_COL
            LD   A,(ER_R0)
            INC  A
            LD   (ER_R0),A
            LD   B,A
            LD   A,(ER_R1)
            CP   B
            JR   NC,ER_ROW
            RET

; ---------------------------------------------------------------------------
; DRAW_PRINCE / DRAW_GUARD - pick the frame and blit it; remember what it covered
; ---------------------------------------------------------------------------
DRAW_PRINCE:
            CALL SET_PRINCE_SPR
            CALL DRAW_SPRITE
STORE_P_BOX:
            LD   A,(DS_BL)
            LD   (P_ENT+E_BL),A
            LD   A,(DS_BR)
            LD   (P_ENT+E_BR),A
            LD   A,(DS_BT)
            LD   (P_ENT+E_BT),A
            LD   A,(DS_BB)
            LD   (P_ENT+E_BB),A
            RET

SET_PRINCE_SPR:
            LD   A,(PX)
            LD   (SP_X),A
            LD   A,(PY)
            LD   (SP_Y),A
            LD   A,(PFACE)
            LD   (SP_FLIP),A
            LD   A,(PFRAME)
            ADD  A,A
            LD   E,A
            LD   D,0
            LD   HL,PRINCE_TBL
            ADD  HL,DE
            LD   E,(HL)
            INC  HL
            LD   D,(HL)
            EX   DE,HL
            RET

DRAW_GUARD: LD   A,(G_ACTIVE)
            OR   A
            RET  Z
            CALL SET_GUARD_SPR
            CALL DRAW_SPRITE
STORE_G_BOX:
            LD   A,(DS_BL)
            LD   (G_ENT+E_BL),A
            LD   A,(DS_BR)
            LD   (G_ENT+E_BR),A
            LD   A,(DS_BT)
            LD   (G_ENT+E_BT),A
            LD   A,(DS_BB)
            LD   (G_ENT+E_BB),A
            RET

SET_GUARD_SPR:
            LD   A,(GX)
            LD   (SP_X),A
            LD   A,(GY)
            LD   (SP_Y),A
            LD   A,(GFACE)
            LD   (SP_FLIP),A
            LD   A,(GFRAME)
            CP   FR_SWA
            JR   C,SG_LOW
            SUB  FR_SWA-10              ; sword-walk frames sit at guard table entries 10, 11
            JR   SG_IDX
SG_LOW:     SUB  FR_GARDE
SG_IDX:     ADD  A,A
            LD   E,A
            LD   D,0
            LD   HL,GUARD_TBL
            LD   A,(GKIND)
            OR   A
            JR   Z,DG_TBL
            LD   HL,SKEL_TBL
DG_TBL:     ADD  HL,DE
            LD   E,(HL)
            INC  HL
            LD   D,(HL)
            EX   DE,HL
            RET

; ---------------------------------------------------------------------------
; UPDATE_SCREEN - flicker-free redraw.  The cells touched by the old and new boxes of the prince and the guard are
; built in the RAM copy of a bank (SHADOW: tile + guard + prince), then copied to the screen in one quick pass,
; so a sprite is never missing from the screen while it is being redrawn.
; ---------------------------------------------------------------------------
UPDATE_SCREEN:
            CALL ANIM_TORCH
            XOR  A
            LD   (DIRTY),A
            LD   (DIRTY+1),A
            LD   (DIRTY+2),A
            LD   A,(P_ENT+E_BL)         ; old boxes
            LD   (ER_L),A
            LD   A,(P_ENT+E_BR)
            LD   (ER_R),A
            LD   A,(P_ENT+E_BT)
            LD   (ER_T),A
            LD   A,(P_ENT+E_BB)
            LD   (ER_B),A
            CALL MARK_BOX
            LD   A,(G_ACTIVE)
            OR   A
            JR   Z,US_NOG1
            LD   A,(G_ENT+E_BL)
            LD   (ER_L),A
            LD   A,(G_ENT+E_BR)
            LD   (ER_R),A
            LD   A,(G_ENT+E_BT)
            LD   (ER_T),A
            LD   A,(G_ENT+E_BB)
            LD   (ER_B),A
            CALL MARK_BOX
US_NOG1:    LD   A,1                    ; new boxes (box only, nothing drawn)
            LD   (DS_MODE),A
            CALL SET_PRINCE_SPR
            CALL DRAW_SPRITE
            CALL STORE_P_BOX
            LD   A,(P_ENT+E_BL)
            LD   (ER_L),A
            LD   A,(P_ENT+E_BR)
            LD   (ER_R),A
            LD   A,(P_ENT+E_BT)
            LD   (ER_T),A
            LD   A,(P_ENT+E_BB)
            LD   (ER_B),A
            CALL MARK_BOX
            LD   A,(G_ACTIVE)
            OR   A
            JR   Z,US_NOG2
            CALL SET_GUARD_SPR
            CALL DRAW_SPRITE
            CALL STORE_G_BOX
            LD   A,(G_ENT+E_BL)
            LD   (ER_L),A
            LD   A,(G_ENT+E_BR)
            LD   (ER_R),A
            LD   A,(G_ENT+E_BT)
            LD   (ER_T),A
            LD   A,(G_ENT+E_BB)
            LD   (ER_B),A
            CALL MARK_BOX
US_NOG2:    LD   A,2                    ; compose into SHADOW, one bank row at a time
            LD   (DS_MODE),A
            LD   HL,SHADOW
            LD   (DRAW_BASE),HL
            XOR  A
            LD   (US_R),A
US_ROW:     LD   A,(US_R)
            LD   E,A
            LD   D,0
            LD   HL,DIRTY
            ADD  HL,DE
            LD   A,(HL)
            OR   A
            JP   Z,US_NEXTROW
            LD   (US_M),A
            LD   (DS_ROW),A             ; (overwritten below; keeps A free)
            LD   A,(US_R)
            LD   (DS_ROW),A
            LD   B,0                    ; tiles of the dirty cells
US_TC:      LD   A,(US_M)
            LD   C,A
            LD   A,B
            CALL US_BITTEST             ; Z clear if column B is dirty
            JR   Z,US_TNEXT
            PUSH BC
            LD   A,(US_R)
            LD   C,A
            CALL DRAW_CELL              ; B = column, C = row
            POP  BC
US_TNEXT:   INC  B
            LD   A,B
            CP   8
            JR   NZ,US_TC
            LD   A,(G_ACTIVE)           ; guard, then prince on top
            OR   A
            JR   Z,US_NOG3
            CALL SET_GUARD_SPR
            CALL DRAW_SPRITE
US_NOG3:    CALL SET_PRINCE_SPR
            CALL DRAW_SPRITE
            LD   A,(US_R)               ; copy the dirty cells to the screen
            CALL SET_BANK
            LD   B,0
US_CC:      LD   A,(US_M)
            LD   C,A
            LD   A,B
            CALL US_BITTEST
            JR   Z,US_CNEXT
            PUSH BC
            CALL COPY_CELL
            POP  BC
US_CNEXT:   INC  B
            LD   A,B
            CP   8
            JR   NZ,US_CC
US_NEXTROW: LD   A,(US_R)
            INC  A
            LD   (US_R),A
            CP   3
            JP   NZ,US_ROW
            XOR  A
            LD   (DS_MODE),A
            LD   HL,VRAM
            LD   (DRAW_BASE),HL
            RET

; A = column, C = mask byte -> Z set if that column's bit is clear
US_BITTEST: LD   D,A
            LD   A,C
            INC  D
US_BT1:     DEC  D
            JR   Z,US_BT2
            RRCA
            JR   US_BT1
US_BT2:     AND  1
            RET

; COPY_CELL - B = column: SHADOW cell -> screen cell (64 lines of 4 bytes, current bank)
COPY_CELL:  LD   A,B
            ADD  A,A
            ADD  A,A
            LD   C,A
            LD   B,0
            LD   HL,SHADOW
            ADD  HL,BC
            LD   DE,VRAM
            EX   DE,HL
            ADD  HL,BC
            EX   DE,HL                  ; HL = shadow, DE = screen
            LD   A,64
CC_LINE:    LDI
            LDI
            LDI
            LDI
            LD   BC,28
            ADD  HL,BC
            EX   DE,HL
            ADD  HL,BC
            EX   DE,HL
            DEC  A
            JR   NZ,CC_LINE
            RET

; MARK_BOX - set the DIRTY bits of every cell inside the pixel box ER_L..ER_R x ER_T..ER_B (clipped like ERASE_AT)
MARK_BOX:   LD   A,(ER_T)
            CP   192
            JR   C,MB_TOPOK
            LD   A,(ER_B)
            CP   192
            RET  NC
            XOR  A
            LD   (ER_T),A
MB_TOPOK:   LD   A,(ER_B)
            CP   192
            JR   C,MB_GO
            LD   A,191
            LD   (ER_B),A
MB_GO:      LD   A,(ER_L)
            RLCA
            RLCA
            RLCA
            AND  7
            LD   B,A                    ; B = first column
            LD   A,(ER_R)
            RLCA
            RLCA
            RLCA
            AND  7
            SUB  B
            INC  A
            LD   C,A                    ; C = column count
            XOR  A
MB_M1:      SCF
            RLA
            DEC  C
            JR   NZ,MB_M1               ; A = 2^count - 1
            INC  B
MB_M2:      DEC  B
            JR   Z,MB_M3
            ADD  A,A
            JR   MB_M2
MB_M3:      LD   E,A                    ; E = column mask
            LD   A,(ER_T)
            RLCA
            RLCA
            AND  3
            LD   C,A                    ; C = first row
            LD   A,(ER_B)
            RLCA
            RLCA
            AND  3
            SUB  C
            INC  A
            LD   B,A                    ; B = row count
            LD   HL,DIRTY
            LD   D,0
            PUSH BC
            LD   B,0
            ADD  HL,BC
            POP  BC
MB_ROW:     LD   A,(HL)
            OR   E
            LD   (HL),A
            INC  HL
            DJNZ MB_ROW
            RET

; ---------------------------------------------------------------------------
; DRAW_SPRITE - HL = frame: DEFB W,H,XO,YO then per line W image + W mask bytes.
; Drawn at reference box (SP_X,SP_Y); SP_FLIP mirrors about the box centre.
; Per line: shift mask + image into line buffers, then dest = (dest & ~mask) | image.
; Leaves the pixel box it covered in DS_BL/BR/BT/BB.
; ---------------------------------------------------------------------------
DRAW_SPRITE:
            LD   A,(HL)
            LD   (DS_W),A
            INC  HL
            LD   A,(HL)
            LD   (DS_N),A
            INC  HL
            LD   A,(HL)
            LD   (DS_XO),A
            INC  HL
            LD   A,(HL)
            INC  HL
            LD   (DS_SRC),HL
            LD   B,A                    ; top line = SP_Y + YO
            LD   A,(SP_Y)
            ADD  A,B
            LD   (DS_Y),A
            LD   (DS_BT),A
            LD   B,A
            LD   A,(DS_N)
            ADD  A,B
            DEC  A
            LD   (DS_BB),A
            LD   A,(SP_FLIP)            ; effective x offset
            OR   A
            LD   A,(DS_XO)
            JR   Z,DS_XOK
            LD   B,A                    ; mirrored: 16 - xo - 8*W
            LD   A,(DS_W)
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,B
            NEG
            ADD  A,16
DS_XOK:     LD   L,A                    ; left = SP_X + signed offset
            LD   H,0
            OR   A
            JP   P,DS_XPOS
            DEC  H
DS_XPOS:    LD   A,(SP_X)
            LD   E,A
            LD   D,0
            ADD  HL,DE
            BIT  7,H
            JR   Z,DS_NONEG
            LD   HL,0
DS_NONEG:   LD   A,(DS_W)               ; clamp left to 255 - 8*W
            ADD  A,A
            ADD  A,A
            ADD  A,A
            LD   B,A
            LD   A,255
            SUB  B
            LD   C,A
            LD   A,H
            OR   A
            JR   NZ,DS_CLAMP
            LD   A,L
            CP   C
            JR   C,DS_LEFTOK
            JR   Z,DS_LEFTOK
DS_CLAMP:   LD   L,C
DS_LEFTOK:  LD   A,L
            LD   (DS_BL),A
            AND  7
            LD   (DS_S),A               ; bit shift 0..7
            LD   A,L
            RRCA
            RRCA
            RRCA
            AND  31
            LD   (DS_D0),A              ; first destination byte
            LD   B,A
            LD   A,(DS_W)
            ADD  A,B
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,7
            LD   (DS_BR),A              ; right edge of the last byte written
            LD   A,(DS_S)               ; hi-part mask and the rotate entry point
            LD   E,A
            LD   D,0
            LD   HL,HM_TBL
            ADD  HL,DE
            LD   A,(HL)
            LD   (DS_HM),A
            LD   HL,ROT_END
            OR   A
            SBC  HL,DE
            LD   (ROT_TRAMP+1),HL
            LD   A,(DS_MODE)            ; 1 = only work out the box
            CP   1
            RET  Z
            LD   A,255
            LD   (DS_BANK),A
DS_LINE:    LD   A,(DS_Y)
            LD   B,A
            CP   192
            JP   NC,DS_NEXT             ; off the top or bottom: clip this line
            RLCA
            RLCA
            AND  3
            LD   C,A
            LD   A,(DS_MODE)            ; 2 = draw into SHADOW, only the lines of bank row DS_ROW
            OR   A
            JR   Z,DS_SCREEN
            LD   A,(DS_ROW)
            CP   C
            JP   NZ,DS_NEXT
            JR   DS_SAME
DS_SCREEN:  LD   A,(DS_BANK)
            CP   C
            JR   Z,DS_SAME
            LD   A,C
            LD   (DS_BANK),A
            CALL SET_BANK
DS_SAME:    LD   A,B                    ; destination pointer for this line
            AND  63
            LD   L,A
            LD   H,0
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            LD   DE,(DRAW_BASE)
            ADD  HL,DE
            LD   A,(DS_D0)
            LD   E,A
            LD   D,0
            ADD  HL,DE
            LD   (DS_DEST),HL
            LD   HL,(DS_SRC)            ; ---- mask bytes
            LD   A,(DS_W)
            LD   B,A
            LD   E,A
            LD   D,0
            ADD  HL,DE
            LD   IX,MBUF
            LD   A,(SP_FLIP)
            OR   A
            JR   Z,DS_MN
            ADD  HL,DE
            DEC  HL
            CALL SHIFT_FLIP
            JR   DS_MD
DS_MN:      CALL SHIFT_NORM
DS_MD:      LD   HL,(DS_SRC)            ; ---- image bytes
            LD   A,(DS_W)
            LD   B,A
            LD   E,A
            LD   D,0
            LD   IX,IBUF
            LD   A,(SP_FLIP)
            OR   A
            JR   Z,DS_IN
            ADD  HL,DE
            DEC  HL
            CALL SHIFT_FLIP
            JR   DS_APPLY
DS_IN:      CALL SHIFT_NORM
DS_APPLY:   LD   HL,(DS_DEST)
            LD   DE,MBUF
            LD   IY,IBUF
            LD   A,(DS_W)
            INC  A
            LD   B,A
AP_LOOP:    LD   A,(DE)
            CPL
            AND  (HL)
            OR   (IY+0)
            LD   (HL),A
            INC  HL
            INC  DE
            INC  IY
            DJNZ AP_LOOP
DS_NEXT:    LD   HL,(DS_SRC)            ; next source line = + 2*W
            LD   A,(DS_W)
            ADD  A,A
            LD   E,A
            LD   D,0
            ADD  HL,DE
            LD   (DS_SRC),HL
            LD   A,(DS_Y)
            INC  A
            LD   (DS_Y),A
            LD   A,(DS_N)
            DEC  A
            LD   (DS_N),A
            JP   NZ,DS_LINE
            RET

; SHIFT_NORM / SHIFT_FLIP: HL = first byte (flip: last byte, walking down), B = W,
; IX = output buffer (W+1 bytes).  Shifts the line right by DS_S bits.
SHIFT_NORM: LD   C,0
SN_LOOP:    LD   A,(HL)
            INC  HL
            CALL ROT_TRAMP
            LD   E,A
            LD   A,(DS_HM)
            AND  E
            OR   C
            LD   (IX+0),A
            INC  IX
            LD   A,(DS_HM)
            CPL
            AND  E
            LD   C,A
            DJNZ SN_LOOP
            LD   (IX+0),C
            RET
SHIFT_FLIP: LD   C,0
SF_LOOP:    LD   A,(HL)
            DEC  HL
            LD   E,A
            LD   D,REV_TBL/256
            LD   A,(DE)
            CALL ROT_TRAMP
            LD   E,A
            LD   A,(DS_HM)
            AND  E
            OR   C
            LD   (IX+0),A
            INC  IX
            LD   A,(DS_HM)
            CPL
            AND  E
            LD   C,A
            DJNZ SF_LOOP
            LD   (IX+0),C
            RET

ROT_TRAMP:  JP   0                      ; operand patched to ROT_END - shift
            RRCA
            RRCA
            RRCA
            RRCA
            RRCA
            RRCA
            RRCA
ROT_END:    RET
HM_TBL:     DEFB $FF,$7F,$3F,$1F,$0F,$07,$03,$01

; ---------------------------------------------------------------------------
; Game logic
; ---------------------------------------------------------------------------
; RESPAWN - restart the level: forget kills, prince to the start position, load the start room
RESPAWN:    LD   HL,ROOM_FLAGS
            LD   B,32
RS_CLR:     LD   (HL),0
            INC  HL
            DJNZ RS_CLR
            XOR  A
            LD   (PFACE),A
            LD   (PFRAME),A
            LD   (PSTATE),A
            LD   (PFS),A
            LD   (PSWORD),A
            LD   (RUNPH),A
            LD   (FALLN),A
            LD   HL,(LVL_START)         ; this level's start: room, X, floor row
            INC  HL
            INC  HL
            LD   A,(HL)                 ; floor row
            LD   (PROW),A
            RRCA
            RRCA
            AND  $C0
            ADD  A,18
            LD   (PY),A
            LD   HL,(LVL_START)
            INC  HL
            LD   A,(HL)
            LD   (PX),A
            LD   HL,(LVL_START)
            LD   A,(HL)
            JP   LOAD_ROOM

; SET_LEVEL - A = level number (0-based): point at its start data and its rooms
SET_LEVEL:  LD   (CUR_LEVEL),A
            ADD  A,A
            LD   E,A
            LD   D,0
            LD   HL,LEVEL_TBL
            ADD  HL,DE
            LD   E,(HL)
            INC  HL
            LD   D,(HL)
            LD   (LVL_START),DE
            INC  DE
            INC  DE
            INC  DE
            LD   (LVL_ROOMS),DE
            RET

; LOAD_ROOM - A = room number: copy its tiles + links, place its guard, draw it
LOAD_ROOM:  LD   (CUR_ROOM),A
            LD   L,A
            LD   H,0
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL                  ; room*32
            LD   DE,(LVL_ROOMS)
            ADD  HL,DE
            LD   DE,ROOM_MAP
            LD   BC,24
            LDIR
            LD   DE,NEIGH_L             ; L,R,U,D
            LD   BC,4
            LDIR
            LD   A,(HL)                 ; guard column
            INC  HL
            LD   B,(HL)                 ; guard row
            INC  HL
            PUSH AF
            LD   A,(HL)                 ; guard kind: 0 guard, 1 skeleton
            LD   (GKIND),A
            POP  AF
            CP   NONE
            JR   Z,LR_NOGUARD
            LD   C,A
            LD   A,1
            LD   (G_ACTIVE),A
            LD   A,C
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,8
            LD   (GX),A                 ; column*32 + 8
            LD   A,B
            LD   (GROW),A
            RRCA
            RRCA
            AND  $C0
            ADD  A,18
            LD   (GY),A
            LD   A,1
            LD   (GFACE),A
            XOR  A
            LD   (GFI),A
            LD   (GTMR),A
            LD   A,(CUR_ROOM)           ; killed before?
            LD   E,A
            LD   D,0
            LD   HL,ROOM_FLAGS
            ADD  HL,DE
            LD   A,(HL)
            AND  1
            JR   NZ,LR_DEAD
            LD   A,FR_GARDE
            LD   (GFRAME),A
            XOR  A
            LD   (GFS),A
            LD   A,(GKIND)
            OR   A
            LD   A,3
            JR   Z,LR_HP
            INC  A                      ; a skeleton takes 4 hits
LR_HP:      LD   (GHP),A
            JR   LR_DRAW
LR_DEAD:    LD   A,FS_DEAD
            LD   (GFS),A
            LD   A,FR_DEAD
            LD   (GFRAME),A
            XOR  A
            LD   (GHP),A
            JR   LR_DRAW
LR_NOGUARD: XOR  A
            LD   (G_ACTIVE),A
            LD   (GHP),A
LR_DRAW:    LD   A,(CUR_ROOM)           ; apply what happened here before: potion drunk (bit 1),
            LD   E,A                    ; loose tile already fallen (bit 2)
            LD   D,0
            LD   HL,ROOM_FLAGS
            ADD  HL,DE
            LD   A,(HL)
            LD   (LR_FL),A
            XOR  A
            LD   (LOOSE_ARM),A
            LD   (GATE_LVL),A          ; gates start shut in every room
            LD   (GATE_TGT),A
            LD   (GATE_HOLD),A
            LD   HL,ROOM_MAP
            LD   B,24
LR_FIX:     LD   A,(LR_FL)
            BIT  1,A
            JR   Z,LR_NOPOT
            RES  6,(HL)
LR_NOPOT:   LD   A,(LR_FL)
            BIT  2,A
            JR   Z,LR_NOLS
            LD   A,(HL)
            AND  $3F
            CP   T_LOOSE
            JR   NZ,LR_NOLS
            LD   A,(HL)
            AND  $C0                    ; fallen: empty, keep any decoration
            LD   (HL),A
LR_NOLS:    INC  HL
            DJNZ LR_FIX
            LD   A,200                  ; nothing of either sprite is on the new screen yet
            LD   (P_ENT+E_BT),A
            LD   (P_ENT+E_BB),A
            LD   (G_ENT+E_BT),A
            LD   (G_ENT+E_BB),A
            JP   RENDER_ROOM

; EDGE_CHECK - after a horizontal move: leave through the left/right edge if there is a room there
EDGE_CHECK: LD   A,(PX)
            CP   232
            JR   C,EC_LEFT
            LD   A,(NEIGH_R)
            CP   NONE
            RET  Z
            CALL LOAD_ROOM
            LD   A,8
            LD   (PX),A
            RET
EC_LEFT:    CP   5
            RET  NC
            LD   A,(NEIGH_L)
            CP   NONE
            RET  Z
            CALL LOAD_ROOM
            LD   A,228
            LD   (PX),A
            RET

; GET_TILE_X - like GET_TILE, but row 255 (= "above row 0") reads row 2 of the room above
GET_TILE_X: LD   A,C
            CP   255
            JP   NZ,GET_TILE
            LD   A,(NEIGH_U)
            LD   L,A
            LD   H,0
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            LD   DE,(LVL_ROOMS)
            ADD  HL,DE
            LD   DE,16
            ADD  HL,DE
            LD   E,B
            LD   D,0
            ADD  HL,DE
            LD   A,(HL)
            AND  $3F
            RET

UPDATE:     LD   A,(PSTATE)
            OR   A
            JR   Z,UPD_GROUND
            CP   1
            JP   Z,UPD_FALL
            CP   2
            JP   Z,UPD_JUMP
            CP   3
            JP   Z,UPD_CLIMB
            CP   4
            JP   Z,UPD_TURN
            CP   5
            JP   Z,UPD_LAND
            JP   UPD_CDOWN

; ---- on the ground ---------------------------------------------------------
UPD_GROUND: LD   A,(PSWORD)             ; sword out (or hurt/dead): fight controls
            OR   A
            JP   NZ,PRINCE_FIGHT
            LD   A,(PFS)
            CP   FS_HURT
            JP   NC,PRINCE_FIGHT
            LD   A,(KEYS)
            BIT  3,A                    ; D = draw the sword
            JR   Z,UG_NODRAW
            LD   A,1
            LD   (PSWORD),A
            LD   A,FS_DRAW
            LD   (PFS),A
            XOR  A
            LD   (PFI),A
            LD   (RUNPH),A
            LD   A,FR_DRAW1
            LD   (PFRAME),A
            LD   A,SND_DRAW
            JP   REQ_SND
UG_NODRAW:  LD   A,(KEYS)
            BIT  2,A                    ; jump pressed?
            JR   Z,UG_WALK
            AND  3
            CP   1
            JR   Z,UJ_L
            CP   2
            JR   Z,UJ_R
            CALL CAN_GRAB               ; ledge beside us one row up?
            JP   C,START_CLIMB
            XOR  A                      ; no: straight up hop
            LD   (JMOVE),A
            JR   UJ_GO
UJ_L:       LD   A,1
            LD   (PFACE),A
            LD   (JMOVE),A
            JR   UJ_GO
UJ_R:       XOR  A
            LD   (PFACE),A
            LD   A,1
            LD   (JMOVE),A
UJ_GO:      XOR  A
            LD   (JIDX),A
            LD   A,(RUNPH)              ; mid-run: running jump (8 px/frame); else standing jump (5)
            LD   B,5
            OR   A
            JR   Z,UJ_SPD
            CP   4
            JR   NC,UJ_SPD
            LD   B,8
UJ_SPD:     LD   A,B
            LD   (JSPD),A
            XOR  A
            LD   (RUNPH),A
            LD   A,2
            LD   (PSTATE),A
            JP   UPD_JUMP
UG_WALK:    LD   A,(KEYS)
            AND  3
            JP   Z,UG_RELEASE
            CP   3
            JP   Z,UG_RELEASE
            LD   B,0                    ; B = the way the key points
            CP   1
            JR   NZ,UW_FACE
            LD   B,1
UW_FACE:    LD   A,(PFACE)
            CP   B
            JR   Z,UW_SAME
            LD   A,B                    ; opposite key: turn around on the spot
            LD   (TURNTO),A
            XOR  A
            LD   (TIDX),A
            LD   (RUNPH),A
            LD   A,4
            LD   (PSTATE),A
            JP   UPD_TURN
UW_SAME:    LD   A,(RUNPH)              ; 0 stand, 1-2 start-up, 3 running, 4-5 stopping
            OR   A
            JR   Z,UW_P1
            CP   4
            JR   NC,UW_P1
            CP   3
            JR   Z,UW_RUN
            INC  A
            JR   UW_SETP
UW_P1:      LD   A,1
UW_SETP:    LD   (RUNPH),A
UW_RUN:     LD   A,(RUNPH)
            LD   E,A
            LD   D,0
            LD   HL,STEP_TBL
            ADD  HL,DE
            LD   A,(HL)
            CALL MOVE_FACING
            JR   C,UG_BLOCKED
            LD   A,(RUNPH)
            CP   1
            LD   B,FR_RUNST1
            JR   Z,UW_FR
            CP   2
            LD   B,FR_RUNST2
            JR   Z,UW_FR
            LD   A,(PFRAME)             ; running: cycle frames 1..4
            CP   4
            JR   NC,UW_F1
            OR   A
            JR   Z,UW_F1
            INC  A
            JR   UW_FS
UW_F1:      LD   A,1
UW_FS:      LD   B,A
UW_FR:      LD   A,B
            LD   (PFRAME),A
            CP   1                      ; footfalls on run frames 1 and 3
            JR   Z,UW_STEP
            CP   3
            JR   NZ,UG_FOOT
UW_STEP:    LD   A,SND_STEP
            CALL REQ_SND
            JR   UG_FOOT
UG_BLOCKED: XOR  A
            LD   (RUNPH),A
            LD   (PFRAME),A
            JR   UG_FOOT
UG_RELEASE: LD   A,(RUNPH)
            OR   A
            JR   Z,UG_IDLE
            CP   5
            JR   Z,UG_IDLE
            CP   4
            JR   Z,UR_S2
            LD   A,4                    ; was running: slide to a stop over 2 frames
            LD   (RUNPH),A
            LD   A,FR_STOP1
            LD   (PFRAME),A
            LD   A,3
            CALL MOVE_FACING
            JR   UG_FOOT
UR_S2:      LD   A,5
            LD   (RUNPH),A
            LD   A,FR_STOP2
            LD   (PFRAME),A
            LD   A,2
            CALL MOVE_FACING
            JR   UG_FOOT
UG_IDLE:    XOR  A
            LD   (RUNPH),A
            LD   (PFRAME),A
            LD   A,(KEYS)               ; S held with the sword away: climb down at an edge, else crouch
            BIT  4,A
            JR   Z,UG_FOOT
            CALL CAN_HANGDOWN
            JP   C,START_CDOWN
            CALL TRY_DRINK
            LD   A,FR_CROUCH
            LD   (PFRAME),A
UG_FOOT:    LD   A,(PX)                 ; floor under the centre of the body?
            ADD  A,8
            RLCA
            RLCA
            RLCA
            AND  7
            LD   B,A
            LD   A,(PROW)
            LD   C,A
            CALL GET_TILE
            CP   T_FLOOR
            JR   C,UG_LEDGE
            CP   T_SPIKES
            RET  C
UG_LEDGE:   LD   A,1
            LD   (PSTATE),A
            XOR  A
            LD   (RUNPH),A
            LD   (FALLN),A
            LD   A,FR_FALL
            LD   (PFRAME),A
            RET

; MOVE_FACING - A = pixels: step that far the way he faces.  Carry set if a wall stopped him.
MOVE_FACING:
            LD   (MV_STEP),A
            LD   A,(PFACE)
            OR   A
            LD   A,(PX)
            JR   NZ,MF_LEFT
            LD   B,A
            LD   A,(MV_STEP)
            ADD  A,B
            CP   MAXX+1
            JR   C,MF_TRY
            LD   A,MAXX
            JR   MF_TRY
MF_LEFT:    LD   B,A
            LD   A,(MV_STEP)
            LD   C,A
            LD   A,B
            SUB  C
            JR   NC,MF_TRY
            XOR  A
MF_TRY:     LD   (NEWX),A
            ADD  A,4                    ; left probe
            CALL PROBE_WALL
            RET  C
            LD   A,(NEWX)
            ADD  A,11                   ; right probe
            CALL PROBE_WALL
            RET  C
            LD   A,(NEWX)
            LD   (PX),A
            CALL EDGE_CHECK
            OR   A
            RET

; turning on the spot: 3 frames (the facing flips on the middle one), then straight on with the walk
UPD_TURN:   LD   A,(TIDX)
            CP   3
            JR   C,UT_SHOW
            XOR  A
            LD   (PSTATE),A
            LD   (PFRAME),A
            JP   UPD_GROUND
UT_SHOW:    LD   E,A
            LD   D,0
            LD   HL,TURN_FR
            ADD  HL,DE
            LD   A,(HL)
            LD   (PFRAME),A
            LD   A,(TIDX)
            CP   1
            JR   NZ,UT_NOF
            LD   A,(TURNTO)
            LD   (PFACE),A
UT_NOF:     LD   A,(TIDX)
            INC  A
            LD   (TIDX),A
            RET

; landing crouch: LTMR frames, then back to normal control
UPD_LAND:   LD   A,(LTMR)
            DEC  A
            LD   (LTMR),A
            RET  NZ
            XOR  A
            LD   (PSTATE),A
            LD   (PFRAME),A
            JP   UPD_GROUND

STEP_TBL:   DEFB 0,2,3,4,0,0            ; pixels per frame by run phase
TURN_FR:    DEFB FR_TURN1,FR_TURN2,FR_TURN3
JUMP_FR:    DEFB FR_JWIND,FR_JRISE,FR_JRISE,FR_JAPEX,FR_JAPEX,FR_JFALL,FR_JFALL,FR_JFALL

; PROBE_WALL - A = x pixel, row PROW: carry set if that cell is a wall
PROBE_WALL: RLCA
            RLCA
            RLCA
            AND  7
            LD   B,A
            LD   A,(PROW)
            LD   C,A
            CALL GET_TILE
            CP   T_WALL
            JR   Z,PW_HIT
            CP   T_WALLR
            JR   Z,PW_HIT
            CP   T_GATE0
            JR   C,PW_OK
            CP   T_GATE5
            JR   C,PW_HIT               ; a gate that is not fully up blocks
PW_OK:      OR   A                      ; clear carry
            RET
PW_HIT:     SCF
            RET

; ---- jumping: JUMP_LEN frames of vertical arc, JSTEP px forward per frame ----
UPD_JUMP:   LD   A,(JIDX)
            LD   E,A
            LD   D,0
            LD   HL,JUMP_FR
            ADD  HL,DE
            LD   A,(HL)
            LD   (PFRAME),A
            LD   HL,JUMP_DY
            ADD  HL,DE
            LD   B,(HL)
            LD   A,(PY)
            ADD  A,B                    ; signed step
            LD   (PY),A
            LD   A,(JMOVE)
            OR   A
            JR   Z,UJ_NOX
            LD   A,(PFACE)
            OR   A
            LD   A,(PX)
            JR   NZ,UJ_LEFTX
            LD   B,A
            LD   A,(JSPD)
            ADD  A,B
            CP   MAXX+1
            JR   C,UJ_TX
            LD   A,MAXX
            JR   UJ_TX
UJ_LEFTX:   LD   B,A
            LD   A,(JSPD)
            LD   C,A
            LD   A,B
            SUB  C
            JR   NC,UJ_TX
            XOR  A
UJ_TX:      LD   (NEWX),A
            ADD  A,4
            CALL PROBE_WALL
            JR   C,UJ_NOX               ; blocked by a wall: carry on straight up/down
            LD   A,(NEWX)
            ADD  A,11
            CALL PROBE_WALL
            JR   C,UJ_NOX
            LD   A,(NEWX)
            LD   (PX),A
            CALL EDGE_CHECK
UJ_NOX:     LD   A,(JIDX)
            INC  A
            LD   (JIDX),A
            CP   JUMP_LEN
            RET  C
            XOR  A                      ; arc finished: floor here? else fall
            LD   (PSTATE),A
            CALL UG_FOOT
            LD   A,(PSTATE)
            OR   A
            RET  NZ                     ; no floor: falling
            LD   A,5                    ; landed: a one-frame crouch
            LD   (PSTATE),A
            LD   A,1
            LD   (LTMR),A
            LD   A,FR_LAND
            LD   (PFRAME),A
            LD   A,SND_LAND
            JP   REQ_SND

JUMP_DY:    DEFB 248,251,254,255,1,2,5,8   ; -8 -5 -2 -1 +1 +2 +5 +8  (net 0)

; ---- ledge grab ---------------------------------------------------------------
; CAN_GRAB: carry set if the prince can jump up and grab a ledge.  Needs: a row
; above, open air (empty cell) directly above him, a floor in the next column in
; the direction he faces, and him standing within 16 px of that edge.
; Sets CL_HX (x while hanging), CL_FX (x when standing on top), CL_DIR.
CAN_GRAB:   LD   A,(PROW)
            OR   A
            JR   NZ,CG_OK
            LD   A,(NEIGH_U)            ; top row: only if there is a room above
            CP   NONE
            JP   Z,CG_NO
CG_OK:
            LD   A,(PX)
            ADD  A,8
            LD   (CG_CEN),A
            RLCA
            RLCA
            RLCA
            AND  7
            LD   (CG_C),A
            LD   A,(PFACE)
            LD   (CL_DIR),A
            OR   A
            JR   NZ,CG_LEFT
            LD   A,(CG_C)               ; facing right: target column c+1
            INC  A
            CP   ROOM_W
            JR   NC,CG_NO
            LD   (CG_TC),A
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,A                    ; boundary = TC*32
            LD   (CG_B),A
            SUB  16
            LD   B,A
            LD   A,(CG_CEN)
            CP   B
            JR   C,CG_NO                ; too far from the edge
            LD   A,(CG_B)
            SUB  10
            LD   (CL_HX),A
            ADD  A,6
            LD   (CL_FX),A
            JR   CG_TILES
CG_LEFT:    LD   A,(CG_C)               ; facing left: target column c-1
            OR   A
            JR   Z,CG_NO
            DEC  A
            LD   (CG_TC),A
            LD   A,(CG_C)
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,A                    ; boundary = c*32
            LD   (CG_B),A
            ADD  A,17
            LD   B,A
            LD   A,(CG_CEN)
            CP   B
            JR   NC,CG_NO
            LD   A,(CG_B)
            SUB  5
            LD   (CL_HX),A
            SUB  7
            LD   (CL_FX),A
CG_TILES:   LD   A,(PROW)
            DEC  A
            LD   C,A                    ; row above
            LD   A,(CG_TC)
            LD   B,A
            PUSH BC
            CALL GET_TILE_X             ; target must be a walkable floor
            POP  BC
            CP   T_FLOOR
            JR   C,CG_NO
            CP   T_SPIKES
            JR   NC,CG_NO
            LD   A,(CG_C)
            LD   B,A
            CALL GET_TILE_X             ; cell above us must be open air
            OR   A
            JR   NZ,CG_NO
            SCF
            RET
CG_NO:      OR   A
            RET

START_CLIMB:
            XOR  A
            LD   (CIDX),A
            LD   (RUNPH),A
            LD   A,3
            LD   (PSTATE),A
            LD   A,(PROW)
            OR   A
            JR   NZ,SC_SAME
            LD   A,(NEIGH_U)            ; climbing out of the top: switch to the room above and
            CALL LOAD_ROOM              ; carry on one screen (192 lines) lower, hanging off its floor
            LD   A,3
            LD   (PROW),A               ; (the climb ends one row up = row 2)
            LD   A,(PY)
            ADD  A,192
            LD   (PY),A
SC_SAME:    LD   A,(PY)
            LD   (CL_BASE),A
            ; falls through into UPD_CLIMB

; ---- climbing: jump up, hang, pull up (8 game frames) -----------------------------
UPD_CLIMB:  LD   A,(CIDX)
            CP   8
            JP   Z,UC_FINISH
            LD   E,A
            LD   D,0
            LD   HL,CL_FRAME
            ADD  HL,DE
            LD   A,(HL)
            LD   (PFRAME),A
            LD   HL,CL_DY
            ADD  HL,DE
            LD   B,(HL)                 ; height above the starting line
            LD   A,(CL_BASE)
            SUB  B
            LD   (PY),A
            LD   A,(CIDX)
            CP   2
            JR   C,UC_APPROACH
            CP   5
            JR   C,UC_AT_HX
            CP   7
            JR   Z,UC_AT_FX
            SUB  5                      ; steps 5,6: slide onto the floor
            LD   E,A
            LD   D,0
            LD   A,(CL_DIR)
            OR   A
            LD   HL,CL_OFF_R
            JR   Z,UC_OFFR
            LD   HL,CL_OFF_L
UC_OFFR:    ADD  HL,DE
            LD   A,(CL_HX)
            ADD  A,(HL)
            LD   (PX),A
            JR   UC_NEXT
UC_AT_FX:   LD   A,(CL_FX)
            LD   (PX),A
            JR   UC_NEXT
UC_AT_HX:   LD   A,(CL_HX)
            LD   (PX),A
            JR   UC_NEXT
UC_APPROACH:LD   A,(CL_HX)              ; steps 0,1: move to the hang position
            LD   B,A
            LD   A,(PX)
            CP   B
            JR   Z,UC_NEXT
            JR   C,UC_MORE
            SUB  B
            CP   9
            JR   C,UC_SNAP
            LD   A,(PX)
            SUB  8
            LD   (PX),A
            JR   UC_NEXT
UC_MORE:    LD   D,A
            LD   A,B
            SUB  D
            CP   9
            JR   C,UC_SNAP
            LD   A,D
            ADD  A,8
            LD   (PX),A
            JR   UC_NEXT
UC_SNAP:    LD   A,B
            LD   (PX),A
UC_NEXT:    LD   A,(CIDX)
            INC  A
            LD   (CIDX),A
            RET
UC_FINISH:  LD   A,(CL_FX)              ; standing on the upper floor
            LD   (PX),A
            LD   A,(CL_BASE)
            SUB  64
            LD   (PY),A
            LD   A,(PROW)
            DEC  A
            LD   (PROW),A
            XOR  A
            LD   (PSTATE),A
            LD   (PFRAME),A
            RET

; frame / rise-above-start for climb steps 0..6
CL_FRAME:   DEFB FR_JUMPUP,FR_JUMPUP,6,6,6,7,8,FR_CLIMB3
CL_DY:      DEFB 10,18,22,22,22,38,52,60
CL_OFF_R:   DEFB 2,4
CL_OFF_L:   DEFB 253,251                ; -3,-5

; ---- falling ----------------------------------------------------------------
UPD_FALL:   LD   A,FR_FALL
            LD   (PFRAME),A
            LD   A,(PY)
            ADD  A,FALLSTEP
            LD   (PY),A
            ADD  A,SPR_H-1              ; A = feet line
            CP   192
            JR   C,UF_ON
            LD   A,(NEIGH_D)            ; fell out of the bottom: room below?
            CP   NONE
            JP   Z,RESPAWN
            CALL LOAD_ROOM
            LD   A,(PY)
            SUB  192                    ; keep falling from just above its top (wraps, drawn clipped)
            LD   (PY),A
            RET
UF_ON:      LD   C,A
            AND  63
            CP   59                     ; walkway line inside a row
            RET  NZ
            LD   HL,FALLN               ; one more floor line passed
            INC  (HL)
            LD   A,C
            RLCA
            RLCA
            AND  3
            LD   C,A                    ; C = row under the feet
            LD   A,(PX)
            ADD  A,8
            RLCA
            RLCA
            RLCA
            AND  7
            LD   B,A
            PUSH BC
            CALL GET_TILE
            POP  BC
            CP   T_SPIKES
            JP   Z,RESPAWN
            CP   T_FLOOR
            RET  C
            CP   T_SPIKES
            RET  NC
            LD   A,C                    ; land on this floor
            LD   (PROW),A
            RRCA
            RRCA
            AND  $C0                    ; row*64
            ADD  A,18
            LD   (PY),A
            LD   A,(FALLN)              ; rows fallen: 1 = safe, 2 = -1 HP, 3+ = fatal
            CP   2
            LD   B,2                    ; B = landing crouch frames
            JR   C,UF_LAND
            CP   3
            JR   NC,UF_KILL
            LD   A,(PHP)
            DEC  A
            LD   (PHP),A
            JR   Z,UF_KILL
            LD   B,5                    ; hurt: a longer crouch
UF_LAND:    LD   A,5
            LD   (PSTATE),A
            LD   A,B
            LD   (LTMR),A
            LD   A,FR_LAND
            LD   (PFRAME),A
            LD   A,B                    ; a hurt landing sounds worse
            CP   5
            LD   A,SND_LAND
            JR   NZ,UF_SND
            LD   A,SND_FALLHURT
UF_SND:     JP   REQ_SND
UF_KILL:    LD   A,SND_DEATH
            CALL REQ_SND
            XOR  A
            LD   (PHP),A
            LD   (PSTATE),A
            LD   (PTMR),A
            LD   A,FS_DEAD
            LD   (PFS),A
            LD   A,FR_DEAD
            LD   (PFRAME),A
            RET

; ---------------------------------------------------------------------------
; Climbing down: S at a floor edge with open air in front -> hang from the ledge, let go
; ---------------------------------------------------------------------------
; CAN_HANGDOWN - carry set if he stands within 16 px of an edge he faces, with a gap beyond it.
; Sets CD_HX (x while hanging) and CD_FACE (he hangs facing back towards the floor).
CAN_HANGDOWN:
            LD   A,(PROW)
            CP   2
            JR   NZ,CH_OK
            LD   A,(NEIGH_D)            ; bottom row: only if there is a room below
            CP   NONE
            JP   Z,CH_NO
CH_OK:      LD   A,(PX)
            ADD  A,8
            LD   (CG_CEN),A
            RLCA
            RLCA
            RLCA
            AND  7
            LD   (CG_C),A
            LD   A,(PFACE)
            OR   A
            JR   NZ,CH_LEFT
            LD   A,(CG_C)               ; facing right: the gap cell is c+1
            INC  A
            CP   ROOM_W
            JR   NC,CH_NO
            LD   (CG_TC),A
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,A
            LD   (CG_B),A               ; edge = (c+1)*32
            SUB  16
            LD   B,A
            LD   A,(CG_CEN)
            CP   B
            JR   C,CH_NO                ; too far from the edge
            LD   A,(CG_B)
            SUB  5
            LD   (CD_HX),A
            LD   A,1
            LD   (CD_FACE),A
            JR   CH_TILES
CH_LEFT:    LD   A,(CG_C)               ; facing left: the gap cell is c-1
            OR   A
            JR   Z,CH_NO
            DEC  A
            LD   (CG_TC),A
            LD   A,(CG_C)
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,A
            LD   (CG_B),A               ; edge = c*32
            ADD  A,17
            LD   B,A
            LD   A,(CG_CEN)
            CP   B
            JR   NC,CH_NO
            LD   A,(CG_B)
            SUB  10
            LD   (CD_HX),A
            XOR  A
            LD   (CD_FACE),A
CH_TILES:   LD   A,(PROW)
            LD   C,A
            LD   A,(CG_TC)
            LD   B,A
            CALL GET_TILE               ; the cell beyond the edge must be open (not floor, not wall)
            CP   T_FLOOR
            JR   NC,CH_NOT03
            CP   T_WALL
            JR   Z,CH_NO
            CP   T_WALLR
            JR   Z,CH_NO
            JR   CH_YES
CH_NOT03:   CP   T_SPIKES
            JR   C,CH_NO                ; there is floor there
CH_YES:     SCF
            RET
CH_NO:      OR   A
            RET

START_CDOWN:
            XOR  A
            LD   (CIDX),A
            LD   (RUNPH),A
            LD   A,6
            LD   (PSTATE),A
            LD   A,(PY)
            LD   (CL_BASE),A
            LD   A,(CD_FACE)
            LD   (PFACE),A              ; he ends up facing the floor he is hanging from
            ; falls through into UPD_CDOWN
UPD_CDOWN:  LD   A,(CIDX)
            CP   5
            JR   Z,CD_LETGO
            LD   E,A
            LD   D,0
            LD   HL,CD_FRAME
            ADD  HL,DE
            LD   A,(HL)
            LD   (PFRAME),A
            LD   HL,CD_DY
            ADD  HL,DE
            LD   B,(HL)
            LD   A,(CL_BASE)
            ADD  A,B
            LD   (PY),A
            LD   A,(CD_HX)
            CALL APPROACH_X
            LD   A,(CIDX)
            INC  A
            LD   (CIDX),A
            RET
CD_LETGO:   LD   A,(PY)                 ; let go: drop (feet line = 3 mod 8 so landing lines line up)
            AND  $F8
            ADD  A,2
            LD   (PY),A
            XOR  A
            LD   (FALLN),A
            INC  A
            LD   (PSTATE),A
            LD   A,FR_FALL
            LD   (PFRAME),A
            RET

CD_FRAME:   DEFB FR_CLIMB3,8,7,6,6
CD_DY:      DEFB 4,12,26,42,42

; APPROACH_X - A = target x: move PX towards it by at most 8 px
APPROACH_X: LD   B,A
            LD   A,(PX)
            CP   B
            RET  Z
            JR   C,AX_MORE
            SUB  B
            CP   9
            JR   C,AX_SNAP
            LD   A,(PX)
            SUB  8
            LD   (PX),A
            RET
AX_MORE:    LD   D,A
            LD   A,B
            SUB  D
            CP   9
            JR   C,AX_SNAP
            LD   A,D
            ADD  A,8
            LD   (PX),A
            RET
AX_SNAP:    LD   A,B
            LD   (PX),A
            RET

; ---------------------------------------------------------------------------
; Level exit
; ---------------------------------------------------------------------------
CHECK_EXIT: LD   A,(PSTATE)
            OR   A
            RET  NZ
            LD   A,(PX)
            ADD  A,8
            RLCA
            RLCA
            RLCA
            AND  7
            LD   B,A
            LD   A,(PROW)
            LD   C,A
            CALL GET_TILE
            CP   T_EXIT
            RET  NZ
            LD   A,1
            LD   (WINFLAG),A
            RET

; DO_WIN - "LEVEL COMPLETE" screen, wait for A, then start the level again
DO_WIN:     XOR  A
DW_CLR:     PUSH AF
            CALL SET_BANK
            LD   HL,VRAM
            LD   DE,VRAM+1
            LD   BC,2047
            LD   (HL),0
            LDIR
            POP  AF
            INC  A
            CP   3
            JR   NZ,DW_CLR
            LD   A,1
            CALL SET_BANK
            LD   A,(CUR_LEVEL)
            ADD  A,'1'
            LD   (STR_WIN1+6),A         ; "LEVEL n COMPLETE"
            LD   A,(CUR_LEVEL)
            INC  A
            CP   LEVEL_COUNT
            LD   HL,STR_WIN1
            LD   B,8
            JR   NZ,DW_TXT
            CALL DRAW_INTRO_IMG         ; that was the last level: the palace picture and "YOU ESCAPED"
            LD   HL,STR_WIN3
            LD   B,10
            LD   A,45
            CALL PRINT_AT
            LD   HL,STR_WIN2
            LD   B,12
            LD   A,55
            CALL PRINT_AT
            JR   DW_SND
DW_TXT:     LD   A,16
            CALL PRINT_AT
            LD   HL,STR_WIN2
            LD   B,12
            LD   A,36
            CALL PRINT_AT
DW_SND:     LD   HL,S_WIN
            CALL PLAY_SEQ
DW_REL:     CALL WAIT_FRAME             ; wait for A to be let go, then pressed
            LD   A,(KEYROW_A)
            BIT  KEY_A_BIT,A
            JR   Z,DW_REL
DW_KEY:     CALL WAIT_FRAME
            LD   A,(KEYROW_A)
            BIT  KEY_A_BIT,A
            JR   NZ,DW_KEY
            XOR  A
            LD   (WINFLAG),A
            INC  A
            LD   (JPREV),A              ; (A is still down: do not count it as a jump press)
            LD   A,(CUR_LEVEL)          ; next level, or round to the first again
            INC  A
            CP   LEVEL_COUNT
            JR   C,DW_NEXT
            XOR  A
DW_NEXT:    CALL SET_LEVEL
            JP   RESET_FIGHT

; ---------------------------------------------------------------------------
; Chompers: every chomper cycles open -> half -> SHUT -> half -> open over 16 frames, each one
; offset by column*5 frames.  Standing in one while it is shut is fatal.
; ---------------------------------------------------------------------------
CHECK_CHOMP:
            LD   A,(CHOMP_T)
            INC  A
            AND  15
            LD   (CHOMP_T),A
            XOR  A
            LD   (CC_I),A
CC_LOOP:    LD   A,(CC_I)
            LD   E,A
            LD   D,0
            LD   HL,ROOM_MAP
            ADD  HL,DE
            LD   A,(HL)
            AND  $3F
            CP   T_CHOMP0
            JR   C,CC_NEXT
            CP   T_CHOMP2+1
            JR   NC,CC_NEXT
            LD   A,(CC_I)               ; phase = (frame + column*5) mod 16
            AND  7
            LD   B,A
            ADD  A,A
            ADD  A,A
            ADD  A,B
            LD   B,A
            LD   A,(CHOMP_T)
            ADD  A,B
            AND  15
            LD   B,0                    ; B = jaw state 0 open, 1 half, 2 shut
            CP   8
            JR   C,CC_SET
            INC  B
            CP   9
            JR   C,CC_SET               ; phase 8: half closed
            INC  B
            CP   12
            JR   C,CC_SET
            DEC  B
            CP   13
            JR   C,CC_SET
            LD   B,0
CC_SET:     LD   A,T_CHOMP0
            ADD  A,B
            LD   B,A                    ; B = wanted tile
            LD   A,(HL)
            AND  $3F
            CP   B
            JR   Z,CC_NEXT
            LD   A,(HL)
            AND  $C0
            OR   B
            LD   (HL),A
            LD   A,(CC_I)
            AND  7
            LD   B,A
            LD   A,(CC_I)
            RRCA
            RRCA
            RRCA
            AND  3
            LD   C,A
            CALL DRAW_CELL
CC_NEXT:    LD   A,(CC_I)
            INC  A
            LD   (CC_I),A
            CP   24
            JR   NZ,CC_LOOP
            LD   A,(PSTATE)             ; on the ground in a shut chomper: dead
            OR   A
            RET  NZ
            LD   A,(PFS)
            CP   FS_DEAD
            RET  Z
            LD   A,(PX)
            ADD  A,8
            RLCA
            RLCA
            RLCA
            AND  7
            LD   B,A
            LD   A,(PROW)
            LD   C,A
            CALL GET_TILE
            CP   T_CHOMP2
            RET  NZ
            XOR  A
            LD   (PHP),A
            LD   (PTMR),A
            LD   (PSWORD),A
            LD   A,FS_DEAD
            LD   (PFS),A
            LD   A,FR_DEAD
            LD   (PFRAME),A
            LD   A,SND_DEATH
            JP   REQ_SND

; ---------------------------------------------------------------------------
; Gates and plates (all gates in a room move together: GATE_LVL 0 = shut .. 5 = fully up)
; ---------------------------------------------------------------------------
CHECK_GATES:
            LD   A,(PSTATE)             ; is he standing on a plate?
            OR   A
            JR   NZ,GT_TIMER
            LD   A,(PX)
            ADD  A,8
            RLCA
            RLCA
            RLCA
            AND  7
            LD   B,A
            LD   A,(PROW)
            LD   C,A
            PUSH BC
            CALL GET_TILE
            POP  BC
            CP   T_PLATE
            JR   Z,GT_PRESS
            CP   T_PLATEON
            JR   NZ,GT_TIMER
            LD   A,PLATE_HOLD           ; standing on a pressed plate keeps the gates up
            LD   (GATE_HOLD),A
            JR   GT_TIMER
GT_PRESS:   LD   A,C                    ; press it: the plate sinks, the gates start to rise
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,B
            LD   E,A
            LD   D,0
            LD   HL,ROOM_MAP
            ADD  HL,DE
            LD   A,(HL)
            AND  $C0
            OR   T_PLATEON
            LD   (HL),A
            LD   A,5
            LD   (GATE_TGT),A
            LD   A,PLATE_HOLD
            LD   (GATE_HOLD),A
            CALL DRAW_CELL
            LD   A,SND_GATE
            CALL REQ_SND
GT_TIMER:   LD   A,(GATE_TGT)
            OR   A
            JR   Z,GT_STEP
            LD   A,(GATE_LVL)
            CP   5
            JR   NZ,GT_STEP
            LD   A,(GATE_HOLD)
            OR   A
            JR   Z,GT_TRYCLOSE
            DEC  A
            LD   (GATE_HOLD),A
            JR   GT_STEP
GT_TRYCLOSE:
            CALL PRINCE_IN_GATE         ; never slam a gate on someone standing in it
            JR   C,GT_STEP
            XOR  A
            LD   (GATE_TGT),A
GT_STEP:    LD   A,(GATE_LVL)
            LD   B,A
            LD   A,(GATE_TGT)
            CP   B
            RET  Z
            JR   C,GT_DOWN
            INC  B
            JR   GT_SET
GT_DOWN:    DEC  B
GT_SET:     LD   A,B
            LD   (GATE_LVL),A
            CALL SET_GATES
            LD   A,SND_GATE
            CALL REQ_SND
            LD   A,(GATE_LVL)
            OR   A
            RET  NZ
            JP   RESET_PLATES           ; shut again: the plates pop back up

PRINCE_IN_GATE:
            LD   A,(PX)
            ADD  A,8
            RLCA
            RLCA
            RLCA
            AND  7
            LD   B,A
            LD   A,(PROW)
            LD   C,A
            CALL GET_TILE
            CP   T_GATE0
            JR   C,PG_NO
            CP   T_GATE5+1
            JR   NC,PG_NO
            SCF
            RET
PG_NO:      OR   A
            RET

; SET_GATES - every gate cell gets the current opening and is redrawn
SET_GATES:  XOR  A
            LD   (SG_I),A
SG_LOOP:    LD   A,(SG_I)
            LD   E,A
            LD   D,0
            LD   HL,ROOM_MAP
            ADD  HL,DE
            LD   A,(HL)
            AND  $3F
            CP   T_GATE0
            JR   C,SG_NEXT
            CP   T_GATE5+1
            JR   NC,SG_NEXT
            LD   A,(GATE_LVL)
            ADD  A,T_GATE0
            LD   (HL),A
            LD   A,(SG_I)
            AND  7
            LD   B,A
            LD   A,(SG_I)
            RRCA
            RRCA
            RRCA
            AND  3
            LD   C,A
            CALL DRAW_CELL
SG_NEXT:    LD   A,(SG_I)
            INC  A
            LD   (SG_I),A
            CP   24
            JR   NZ,SG_LOOP
            RET

; RESET_PLATES - pressed plates come back up
RESET_PLATES:
            XOR  A
            LD   (SG_I),A
RP_LOOP:    LD   A,(SG_I)
            LD   E,A
            LD   D,0
            LD   HL,ROOM_MAP
            ADD  HL,DE
            LD   A,(HL)
            AND  $3F
            CP   T_PLATEON
            JR   NZ,RP_NEXT
            LD   A,(HL)
            AND  $C0
            OR   T_PLATE
            LD   (HL),A
            LD   A,(SG_I)
            AND  7
            LD   B,A
            LD   A,(SG_I)
            RRCA
            RRCA
            RRCA
            AND  3
            LD   C,A
            CALL DRAW_CELL
RP_NEXT:    LD   A,(SG_I)
            INC  A
            LD   (SG_I),A
            CP   24
            JR   NZ,RP_LOOP
            RET

; CHECK_LOOSE - step on a loose tile and it crumbles 4 frames later (the tile becomes empty for good)
CHECK_LOOSE:
            LD   A,(LOOSE_ARM)
            OR   A
            JR   Z,CL_SCAN
            DEC  A
            LD   (LOOSE_ARM),A
            RET  NZ
            LD   A,(LOOSE_ROW)          ; the countdown ran out: tile (col,row) falls
            ADD  A,A
            ADD  A,A
            ADD  A,A
            LD   B,A
            LD   A,(LOOSE_COL)
            ADD  A,B
            LD   E,A
            LD   D,0
            LD   HL,ROOM_MAP
            ADD  HL,DE
            LD   A,(HL)
            AND  $C0
            LD   (HL),A
            LD   A,(CUR_ROOM)
            LD   E,A
            LD   D,0
            LD   HL,ROOM_FLAGS
            ADD  HL,DE
            SET  2,(HL)
            LD   A,(LOOSE_COL)
            LD   B,A
            LD   A,(LOOSE_ROW)
            LD   C,A
            CALL DRAW_CELL
            LD   A,SND_LOOSE
            JP   REQ_SND
CL_SCAN:    LD   A,(PSTATE)
            OR   A
            RET  NZ
            LD   A,(PX)
            ADD  A,8
            RLCA
            RLCA
            RLCA
            AND  7
            LD   (LOOSE_COL),A
            LD   B,A
            LD   A,(PROW)
            LD   (LOOSE_ROW),A
            LD   C,A
            CALL GET_TILE
            CP   T_LOOSE
            RET  NZ
            LD   A,4
            LD   (LOOSE_ARM),A
            RET

; TRY_DRINK - crouching on a tile with a potion: +1 HP (not when already at full health)
TRY_DRINK:  LD   A,(PHP)
            CP   3
            RET  NC
            LD   A,(PX)
            ADD  A,8
            RLCA
            RLCA
            RLCA
            AND  7
            LD   B,A
            LD   A,(PROW)
            LD   C,A
            ADD  A,A
            ADD  A,A
            ADD  A,A
            ADD  A,B
            LD   E,A
            LD   D,0
            LD   HL,ROOM_MAP
            ADD  HL,DE
            BIT  6,(HL)
            RET  Z
            RES  6,(HL)
            LD   A,(PHP)
            INC  A
            LD   (PHP),A
            LD   A,(CUR_ROOM)
            LD   E,A
            LD   D,0
            LD   HL,ROOM_FLAGS
            ADD  HL,DE
            SET  1,(HL)
            CALL DRAW_CELL
            LD   A,SND_POTION
            JP   REQ_SND

; ---------------------------------------------------------------------------
; Sound.  The speaker is driven by two latch bits (D0 and D5, opposite phases); everything
; else on the latch stays as the graphics mode needs it (8).  Effects are short and blocking.
; Sequence data = triples PITCH,COUNT,REPEAT (pitch 255 = noise burst of COUNT half-cycles,
; pitch 0 ends).  Delay per half-cycle = about 16*PITCH*REPEAT T-states.
; ---------------------------------------------------------------------------
REQ_SND:    LD   B,A                    ; keep the most important request of the frame
            LD   A,(SND_REQ)
            CP   B
            RET  NC
            LD   A,B
            LD   (SND_REQ),A
            RET

PLAY_SOUND: LD   A,(SND_REQ)
            OR   A
            RET  Z
            LD   E,A
            LD   D,0
            XOR  A
            LD   (SND_REQ),A
            LD   HL,SND_TBL
            ADD  HL,DE
            ADD  HL,DE
            LD   E,(HL)
            INC  HL
            LD   D,(HL)
            EX   DE,HL
PLAY_SEQ:   LD   A,(HL)
            OR   A
            RET  Z
            LD   B,A
            INC  HL
            LD   C,(HL)
            INC  HL
            LD   D,(HL)
            INC  HL
            PUSH HL
            LD   A,B
            CP   255
            JR   Z,PS_NOISE
            CALL BEEP
            JR   PS_NEXT
PS_NOISE:   CALL NOISE
PS_NEXT:    POP  HL
            JR   PLAY_SEQ

; BEEP - B = pitch (delay loop count), C = half-cycles, D = delay repeats
BEEP:       LD   A,(SND_MUTE)
            OR   A
            RET  NZ
            LD   E,9                    ; 8 | D0
BP_HC:      LD   A,E
            LD   (LATCH),A
            XOR  $21                    ; 9 <-> $28 (8 | D5)
            LD   E,A
            LD   H,D
BP_R:       LD   L,B
BP_W:       DEC  L
            JR   NZ,BP_W
            DEC  H
            JR   NZ,BP_R
            DEC  C
            JR   NZ,BP_HC
            LD   A,8
            LD   (LATCH),A
            RET

; NOISE - C = half-cycles of random length (own generator: the game's random numbers stay put)
NOISE:      LD   A,(SND_MUTE)
            OR   A
            RET  NZ
            LD   E,9
NZ_HC:      LD   A,E
            LD   (LATCH),A
            XOR  $21
            LD   E,A
            LD   A,(NSEED)
            LD   B,A
            ADD  A,A
            ADD  A,A
            ADD  A,B
            ADD  A,31
            LD   (NSEED),A
            RLCA
            RLCA
            RLCA
            AND  $3F
            ADD  A,6
            LD   B,A
NZ_D:       DJNZ NZ_D
            DEC  C
            JR   NZ,NZ_HC
            LD   A,8
            LD   (LATCH),A
            RET

; CHECK_MUTE - M toggles the sound on and off
CHECK_MUTE: LD   A,(KEYROW_M)
            BIT  KEY_M_BIT,A
            LD   A,0
            JR   NZ,CM_UP
            INC  A
CM_UP:      LD   B,A                    ; B = 1 while M is down
            LD   A,(MPREV)
            LD   C,A
            LD   A,B
            LD   (MPREV),A
            LD   A,C
            OR   A
            RET  NZ
            LD   A,B
            OR   A
            RET  Z
            LD   A,(SND_MUTE)
            XOR  1
            LD   (SND_MUTE),A
            RET

SND_TBL:    DEFW 0,S_STEP,S_GATE,S_LAND,S_DRAW,S_PARRY,S_HIT,S_LOOSE,S_FALLHURT,S_POTION,S_DEATH
S_STEP:     DEFB 70,5,1,0
S_GATE:     DEFB 45,8,1,0
S_LAND:     DEFB 190,14,2,0
S_DRAW:     DEFB 70,12,1, 50,14,1, 36,16,1, 0
S_PARRY:    DEFB 28,40,1, 20,30,1, 0
S_HIT:      DEFB 255,110,0, 0
S_LOOSE:    DEFB 255,90,0, 180,10,2, 0
S_FALLHURT: DEFB 255,70,0, 200,20,3, 0
S_POTION:   DEFB 60,30,1, 48,36,1, 36,44,1, 0
S_DEATH:    DEFB 70,40,2, 90,40,2, 110,50,2, 150,60,2, 210,70,2, 0
S_WIN:      DEFB 210,125,1, 166,158,1, 139,188,1, 103,251,1, 0
S_TITLE:    DEFB 166,100,1, 139,120,1, 103,200,1, 0

; ---------------------------------------------------------------------------
; Title screen
; ---------------------------------------------------------------------------
TITLE_SCREEN:
            LD   HL,TITLE_MAP           ; backdrop: ledge with torches and a door, brick wall below
            LD   DE,ROOM_MAP
            LD   BC,24
            LDIR
            CALL RENDER_ROOM
            LD   A,1                    ; the middle band is for the lettering
            CALL SET_BANK
            LD   HL,VRAM
            LD   DE,VRAM+1
            LD   BC,2047
            LD   (HL),0
            LDIR
            LD   HL,STR_T1
            LD   B,7
            LD   A,2
            CALL PRINT_BIG
            LD   HL,STR_T2
            LD   B,8
            LD   A,20
            CALL PRINT_AT
            LD   HL,STR_T3
            LD   B,3
            LD   A,32
            CALL PRINT_AT
            LD   HL,STR_T4
            LD   B,3
            LD   A,40
            CALL PRINT_AT
            LD   HL,STR_T5
            LD   B,9
            LD   A,48
            CALL PRINT_AT
            LD   HL,S_TITLE
            CALL PLAY_SEQ
            XOR  A
            LD   (TS_T),A
TS_REL:     CALL WAIT_FRAME             ; let go of A first
            LD   A,(KEYROW_A)
            BIT  KEY_A_BIT,A
            JR   Z,TS_REL
TS_WAIT:    CALL WAIT_FRAME
            CALL CHECK_MUTE
            CALL ANIM_TORCH             ; the two torches flicker on the title screen too
            LD   A,(TS_T)               ; blink "PRESS A TO START" about twice a second
            INC  A
            LD   (TS_T),A
            LD   HL,STR_T6
            AND  8
            JR   NZ,TS_SHOW
            LD   HL,STR_BLANK
TS_SHOW:    LD   B,8
            LD   A,56
            CALL PRINT_AT
            LD   A,(KEYROW_A)
            BIT  KEY_A_BIT,A
            JR   NZ,TS_WAIT
            LD   A,1
            LD   (JPREV),A              ; (A is still down: not a jump press)
            RET

; ---------------------------------------------------------------------------
; Intro picture: 256 x INTRO_LINES mono bitmap (generated by make_intro.py), blinking "PRESS A" underneath
; ---------------------------------------------------------------------------
INTRO_SCREEN:
            CALL DRAW_INTRO_IMG
            XOR  A
            LD   (TS_T),A
            JR   IN_REL
DRAW_INTRO_IMG:
            LD   HL,INTRO_Z0            ; the picture is stored ZX0-compressed, one chunk per video bank:
            XOR  A                      ; unpack a chunk into SHADOW (free here), then copy it into its bank
            CALL IS_UNZ
            LD   HL,INTRO_Z1
            LD   A,1
            CALL IS_UNZ
            LD   HL,INTRO_Z2
            LD   A,2                    ; (bank 2 stays selected: captions go under the picture)
IS_UNZ:     PUSH AF
            LD   DE,SHADOW
            CALL DZX0_STANDARD          ; HL = compressed data, DE = where to unpack
            POP  AF
            CALL SET_BANK
            LD   HL,SHADOW
            LD   DE,VRAM
            LD   BC,2048
            LDIR
            RET

; ---------------------------------------------------------------------------
; ZX0 decoder by Einar Saukas & Urusergi, "standard" version (68 bytes) - BSD 3-Clause (see zx0_src/LICENSE)
;   HL = source address (compressed data), DE = destination address
; ---------------------------------------------------------------------------
DZX0_STANDARD:
            LD   BC,$FFFF               ; preserve default offset 1
            PUSH BC
            INC  BC
            LD   A,$80
DZX0S_LITERALS:
            CALL DZX0S_ELIAS            ; obtain length
            LDIR                        ; copy literals
            ADD  A,A                    ; copy from last offset or new offset?
            JR   C,DZX0S_NEW_OFFSET
            CALL DZX0S_ELIAS            ; obtain length
DZX0S_COPY: EX   (SP),HL                ; preserve source, restore offset
            PUSH HL                     ; preserve offset
            ADD  HL,DE                  ; calculate destination - offset
            LDIR                        ; copy from offset
            POP  HL                     ; restore offset
            EX   (SP),HL                ; preserve offset, restore source
            ADD  A,A                    ; copy from literals or new offset?
            JR   NC,DZX0S_LITERALS
DZX0S_NEW_OFFSET:
            POP  BC                     ; discard last offset
            LD   C,$FE                  ; prepare negative offset
            CALL DZX0S_ELIAS_LOOP       ; obtain offset MSB
            INC  C
            RET  Z                      ; check end marker
            LD   B,C
            LD   C,(HL)                 ; obtain offset LSB
            INC  HL
            RR   B                      ; last offset bit becomes first length bit
            RR   C
            PUSH BC                     ; preserve new offset
            LD   BC,1                   ; obtain length
            CALL NC,DZX0S_ELIAS_BACKTRACK
            INC  BC
            JR   DZX0S_COPY
DZX0S_ELIAS:
            INC  C                      ; interlaced Elias gamma coding
DZX0S_ELIAS_LOOP:
            ADD  A,A
            JR   NZ,DZX0S_ELIAS_SKIP
            LD   A,(HL)                 ; load another group of 8 bits
            INC  HL
            RLA
DZX0S_ELIAS_SKIP:
            RET  C
DZX0S_ELIAS_BACKTRACK:
            ADD  A,A
            RL   C
            RL   B
            JR   DZX0S_ELIAS_LOOP

IN_REL:     CALL WAIT_FRAME             ; let go of A first
            LD   A,(KEYROW_A)
            BIT  KEY_A_BIT,A
            JR   Z,IN_REL
IN_WAIT:    CALL WAIT_FRAME
            CALL CHECK_MUTE
            LD   A,(TS_T)
            INC  A
            LD   (TS_T),A
            LD   HL,STR_T6
            AND  8
            JR   NZ,IN_SHOW
            LD   HL,STR_BLANK
IN_SHOW:    LD   B,8
            LD   A,54
            CALL PRINT_AT
            LD   A,(KEYROW_123)         ; 1 / 2 / 3 choose the start level
            LD   B,0
            BIT  4,A
            JR   Z,IN_LV
            INC  B
            BIT  1,A                    ; key 2 = D1 (D2 is unused on this row)
            JR   Z,IN_LV
            INC  B
            BIT  3,A
            JR   Z,IN_LV
            JR   IN_NOLV
IN_LV:      LD   A,B
            CP   LEVEL_COUNT
            JR   NC,IN_NOLV
            LD   (START_LV),A
IN_NOLV:    LD   A,(START_LV)
            ADD  A,'1'
            LD   (STR_LVHINT+16),A
            LD   HL,STR_LVHINT
            LD   B,7
            LD   A,44
            CALL PRINT_AT
            LD   A,(KEYROW_A)
            BIT  KEY_A_BIT,A
            JR   NZ,IN_WAIT
            RET

; PRINT_BIG - like PRINT_AT but every glyph is drawn double size (16 x 16)
PRINT_BIG:  LD   (PA_LINE),A
            LD   A,B
            LD   (PA_COL),A
PB_NEXT:    LD   A,(HL)
            OR   A
            RET  Z
            INC  HL
            PUSH HL
            CP   ' '
            JR   Z,PB_SP
            CP   '0'
            JR   C,PB_SP
            CP   'A'
            JR   NC,PB_LET
            SUB  '0'
            ADD  A,26
            JR   PB_GOT
PB_LET:     SUB  'A'
            JR   PB_GOT
PB_SP:      LD   A,36
PB_GOT:     LD   L,A
            LD   H,0
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            LD   DE,FONT
            ADD  HL,DE
            PUSH HL
            LD   A,(PA_LINE)
            LD   L,A
            LD   H,0
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            LD   DE,VRAM
            ADD  HL,DE
            LD   A,(PA_COL)
            LD   E,A
            LD   D,0
            ADD  HL,DE
            EX   DE,HL                  ; DE = destination
            POP  HL                     ; HL = glyph
            LD   B,8
PB_ROW:     LD   A,(HL)
            INC  HL
            PUSH HL
            PUSH BC
            CALL EXP8                   ; HL = the 8 bits doubled to 16
            LD   A,H
            LD   (DE),A
            INC  DE
            LD   A,L
            LD   (DE),A
            LD   A,E
            ADD  A,31
            LD   E,A
            JR   NC,PB_N1
            INC  D
PB_N1:      LD   A,H                    ; second copy on the next line
            LD   (DE),A
            INC  DE
            LD   A,L
            LD   (DE),A
            LD   A,E
            ADD  A,31
            LD   E,A
            JR   NC,PB_N2
            INC  D
PB_N2:      POP  BC
            POP  HL
            DJNZ PB_ROW
            LD   A,(PA_COL)
            INC  A
            INC  A
            LD   (PA_COL),A
            POP  HL
            JR   PB_NEXT

; EXP8 - A = 8 bits -> HL = 16 bits with every bit doubled
EXP8:       LD   C,A
            LD   HL,0
            LD   B,8
EX_L:       RL   C
            SBC  A,A
            AND  3
            ADD  HL,HL
            ADD  HL,HL
            OR   L
            LD   L,A
            DJNZ EX_L
            RET

TITLE_MAP:  DEFB T_FLOORL+T_TORCH,T_FLOOR,T_FLOOR,T_EXIT,T_FLOOR,T_FLOOR,T_FLOOR,T_FLOOR+T_TORCH
            DEFB T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY
            DEFB T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL
STR_T1:     DEFM "VZ PRINCE"
            DEFB 0
STR_T2:     DEFM "A DUNGEON ESCAPE"
            DEFB 0
STR_T3:     DEFM "Z X MOVE  A JUMP  S CROUCH"
            DEFB 0
STR_T4:     DEFM "D SWORD  A STRIKE  S PARRY"
            DEFB 0
STR_T5:     DEFM "M SOUND ON OFF"
            DEFB 0
STR_LVHINT: DEFM "1 2 3 FOR LEVEL 1"
            DEFB 0
STR_T6:     DEFM "PRESS A TO START"
            DEFB 0
STR_BLANK:  DEFM "                "
            DEFB 0

; PRINT_AT - HL = string (A-Z, 0-9, space; 0 ends), B = start byte column, A = first line in the
;            bank that is currently selected
PRINT_AT:   LD   (PA_LINE),A
            LD   A,B
            LD   (PA_COL),A
PA_NEXT:    LD   A,(HL)
            OR   A
            RET  Z
            INC  HL
            PUSH HL
            CP   ' '
            JR   Z,PA_SP
            CP   '0'
            JR   C,PA_SP
            CP   'A'
            JR   NC,PA_LET
            SUB  '0'
            ADD  A,26
            JR   PA_GOT
PA_LET:     SUB  'A'
            JR   PA_GOT
PA_SP:      LD   A,36
PA_GOT:     LD   L,A
            LD   H,0
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            LD   DE,FONT
            ADD  HL,DE
            PUSH HL                     ; glyph
            LD   A,(PA_LINE)
            LD   L,A
            LD   H,0
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            ADD  HL,HL
            LD   DE,VRAM
            ADD  HL,DE
            LD   A,(PA_COL)
            LD   E,A
            LD   D,0
            ADD  HL,DE
            EX   DE,HL                  ; DE = destination
            POP  HL
            LD   B,8
PA_ROW:     LD   A,(HL)
            LD   (DE),A
            INC  HL
            LD   A,E
            ADD  A,32
            LD   E,A
            JR   NC,PA_NC
            INC  D
PA_NC:      DJNZ PA_ROW
            LD   A,(PA_COL)
            INC  A
            LD   (PA_COL),A
            POP  HL
            JR   PA_NEXT

STR_WIN1:   DEFM "LEVEL 1 COMPLETE"
            DEFB 0
STR_WIN3:   DEFM "YOU ESCAPED"
            DEFB 0
STR_WIN2:   DEFM "PRESS A"
            DEFB 0

; ---------------------------------------------------------------------------
; Fighting.  IX = the fighter acting, IY = his opponent.
; ---------------------------------------------------------------------------
RESET_FIGHT:
            CALL RESPAWN
            LD   A,3
            LD   (PHP),A
            XOR  A
            LD   (PTMR),A
            RET

FACE_OPP:   LD   A,(IY+E_X)
            CP   (IX+E_X)
            LD   A,0
            JR   NC,FO_SET
            INC  A
FO_SET:     LD   (IX+E_FACE),A
            RET

; DIST - A = |X(IX) - X(IY)|, carry set when the opponent is on the left
DIST:       LD   A,(IY+E_X)
            SUB  (IX+E_X)
            RET  NC
            NEG
            SCF
            RET

; FIGHT_MOVE - B = dx (signed): step if there is floor and he stays MIN_SEP away
FIGHT_MOVE: LD   A,B
            LD   (FM_DX),A
            CALL DIST
            LD   C,A
            LD   A,0
            RLA                         ; 1 if the opponent is on the left
            LD   D,A
            LD   A,(FM_DX)
            RLCA
            AND  1                      ; 1 if stepping left
            XOR  D
            JR   NZ,FM_FREE             ; stepping away: always fine
            LD   A,C
            CP   MIN_SEP+FSTEP
            RET  C                      ; would get too close
FM_FREE:    LD   A,(IX+E_X)
            LD   B,A
            LD   A,(FM_DX)
            ADD  A,B
            CP   MAXX+1
            RET  NC
            LD   (FM_NX),A
            ADD  A,8
            RLCA
            RLCA
            RLCA
            AND  7
            LD   B,A
            LD   A,(IX+E_ROW)
            LD   C,A
            CALL GET_TILE
            CP   T_FLOOR
            RET  C
            CP   T_SPIKES
            RET  NC
            CP   T_GATE0
            JR   C,FM_NOGATE
            CP   T_GATE5
            RET  C                      ; a closed gate is in the way
FM_NOGATE:  LD   A,(FM_NX)
            LD   (IX+E_X),A
            LD   A,(FM_DX)              ; show a step forward or a step back
            RLCA
            AND  1                      ; 1 = stepping left
            LD   B,A
            LD   A,(IX+E_FACE)          ; 1 = facing left
            XOR  B
            LD   A,FR_ADV
            JR   Z,FM_SF
            LD   A,FR_RETREAT
FM_SF:      LD   (IX+E_FRAME),A
            RET

; FIGHT_STRIKE - one tick of a strike: wind up (0,1), thrust (2) hits, recover (3)
FIGHT_STRIKE:
            LD   A,(IX+E_FI)
            CP   2
            JR   Z,FST_THRUST
            LD   (IX+E_FRAME),FR_ST1
            JR   FST_ADV
FST_THRUST: LD   (IX+E_FRAME),FR_ST2
            CALL TRY_HIT
FST_ADV:    INC  (IX+E_FI)
            LD   A,(IX+E_FI)
            CP   4
            RET  C
            LD   (IX+E_FS),FS_GARDE
            LD   (IX+E_FRAME),FR_GARDE
            RET

; TRY_HIT - the thrust of IX lands on IY unless he is parrying, dead or out of reach
TRY_HIT:    LD   A,(IY+E_FS)
            CP   FS_DEAD
            RET  Z
            CP   FS_PARRY
            JR   Z,TH_PARRY
            CALL DIST
            CP   HIT_RANGE+1
            RET  NC
            LD   A,SND_HIT
            CALL REQ_SND
            LD   A,(IY+E_HP)
            DEC  A
            LD   (IY+E_HP),A
            JR   Z,TH_DEAD
            LD   (IY+E_FS),FS_HURT
            LD   (IY+E_TMR),2
            LD   (IY+E_FRAME),FR_HURT
            LD   A,(IY+E_X)             ; recoil 4 px away from the attacker
            LD   B,A
            LD   A,(IX+E_FACE)
            OR   A
            LD   A,B
            JR   NZ,TH_L
            ADD  A,4
            JR   TH_S
TH_L:       SUB  4
TH_S:       CP   MAXX+1
            RET  NC
            LD   (IY+E_X),A
            RET
TH_PARRY:   CALL DIST                   ; blade met blade: a clink if he was within reach
            CP   HIT_RANGE+1
            RET  NC
            LD   A,SND_PARRY
            JP   REQ_SND
TH_DEAD:    PUSH IY                     ; the prince dying gets the death tune
            POP  HL
            LD   DE,P_ENT
            OR   A
            SBC  HL,DE
            LD   A,SND_DEATH
            CALL Z,REQ_SND
            LD   (IY+E_FS),FS_DEAD
            LD   (IY+E_TMR),0
            LD   (IY+E_FRAME),FR_DEAD
            RET

; PRINCE_FIGHT - controls while the sword is out (or while hurt / dead)
PRINCE_FIGHT:
            LD   IX,P_ENT
            LD   IY,G_ENT
            LD   A,(PFS)
            CP   FS_DEAD
            JP   Z,PF_DEAD
            CP   FS_HURT
            JP   Z,PF_HURT
            CALL FACE_OPP
            LD   A,(PFS)
            CP   FS_STRIKE
            JP   Z,FIGHT_STRIKE
            CP   FS_DRAW
            JP   Z,PF_DRAW
            CP   FS_SHEATH
            JP   Z,PF_SHEATH
            LD   A,(KEYS)
            BIT  3,A
            JR   Z,PF_NOSH
            LD   (IX+E_FS),FS_SHEATH    ; D again: put the sword away (2 frames)
            LD   (IX+E_FI),0
            LD   (IX+E_FRAME),FR_DRAW2
            LD   A,SND_DRAW
            JP   REQ_SND
PF_NOSH:    BIT  2,A
            JR   Z,PF_NOST
            LD   (IX+E_FS),FS_STRIKE    ; A: strike
            LD   (IX+E_FI),0
            JP   FIGHT_STRIKE
PF_NOST:    BIT  4,A
            JR   Z,PF_MV
            LD   (IX+E_FS),FS_PARRY     ; S held: parry
            LD   (IX+E_FRAME),FR_PARRY
            RET
PF_MV:      LD   (IX+E_FS),FS_GARDE
            LD   (IX+E_FRAME),FR_GARDE
            AND  3
            LD   B,FSTEP
            CP   2
            JR   Z,PF_GO
            LD   B,256-FSTEP
            CP   1
            JR   Z,PF_GO
            LD   A,3                    ; no key: the next step starts the cycle again at ADV / RETREAT
            LD   (PSWSTEP),A
            RET
PF_GO:      CALL FIGHT_MOVE
            LD   HL,PSWSTEP
            JP   STEP_ANIM

; STEP_ANIM - after FIGHT_MOVE (IX = fighter, HL = its step-phase counter): turn the single ADV / RETREAT frame into a walk
; cycle ADV|RETREAT, pass A, GARDE, pass B.  Does nothing when he did not move (FIGHT_MOVE left GARDE).
STEP_ANIM:  LD   A,(IX+E_FRAME)
            CP   FR_GARDE
            RET  Z
            LD   A,(HL)
            INC  A
            AND  3
            LD   (HL),A
            RET  Z
            LD   B,FR_SWA
            CP   1
            JR   Z,PF_STF
            LD   B,FR_GARDE
            CP   2
            JR   Z,PF_STF
            LD   B,FR_SWB
PF_STF:     LD   (IX+E_FRAME),B
            RET
PF_DRAW:    INC  (IX+E_FI)              ; draw: DRAW1 (set by D), DRAW2, then en garde
            LD   A,(IX+E_FI)
            CP   1
            LD   (IX+E_FRAME),FR_DRAW2
            RET  Z
            LD   (IX+E_FS),FS_GARDE
            LD   (IX+E_FRAME),FR_GARDE
            RET
PF_SHEATH:  INC  (IX+E_FI)              ; sheathe: DRAW2 (set by D), DRAW1, then stand
            LD   A,(IX+E_FI)
            CP   1
            LD   (IX+E_FRAME),FR_DRAW1
            RET  Z
            XOR  A
            LD   (PSWORD),A
            LD   (PFS),A
            LD   (PFRAME),A
            RET
PF_HURT:    DEC  (IX+E_TMR)
            RET  NZ
            XOR  A
            LD   (PFS),A
            LD   A,(PSWORD)
            OR   A
            LD   A,0
            JR   Z,PF_HF
            LD   A,FR_GARDE
PF_HF:      LD   (PFRAME),A
            RET
PF_DEAD:    INC  (IX+E_TMR)
            LD   A,(PTMR)
            CP   24
            RET  C
            JP   RESET_FIGHT

; GUARD_STEP - the guard's brain, once per game frame
GUARD_STEP: LD   A,(G_ACTIVE)
            OR   A
            RET  Z
            LD   IX,G_ENT
            LD   IY,P_ENT
            LD   A,(GFS)
            CP   FS_DEAD
            JR   NZ,GS_ALIVE
            LD   A,(CUR_ROOM)           ; remember the kill for this room
            LD   E,A
            LD   D,0
            LD   HL,ROOM_FLAGS
            ADD  HL,DE
            SET  0,(HL)
            RET
GS_ALIVE:
            CP   FS_HURT
            JP   Z,GS_HURT
            CALL FACE_OPP
            LD   A,(GFS)
            CP   FS_STRIKE
            JP   Z,FIGHT_STRIKE
            CP   FS_PARRY
            JP   Z,GS_PARHOLD
            LD   A,(PSTATE)             ; only fights a prince on the ground, same floor
            OR   A
            JP   NZ,GS_IDLE
            LD   A,(PROW)
            LD   B,A
            LD   A,(GROW)
            CP   B
            JP   NZ,GS_IDLE
            LD   A,(PFS)
            CP   FS_DEAD
            JR   Z,GS_IDLE
            CALL DIST
            CP   ENGAGE
            JR   NC,GS_IDLE
            CP   WALK_RANGE
            JR   C,GS_CLOSE
            CALL RAND8                  ; too far to hit: close in 3 times out of 4
            AND  3
            JR   Z,GS_IDLE
            LD   B,FSTEP
            LD   A,(GFACE)
            OR   A
            JR   Z,GS_MV
            LD   B,256-FSTEP
GS_MV:      LD   (IX+E_FS),FS_GARDE
            LD   (IX+E_FRAME),FR_GARDE
            CALL FIGHT_MOVE
            LD   HL,GSWSTEP
            JP   STEP_ANIM
GS_CLOSE:   LD   A,(PFS)                ; in reach: parry a strike half the time
            CP   FS_STRIKE
            JR   NZ,GS_NOPAR
            CALL RAND8
            AND  1
            JR   Z,GS_NOPAR
            LD   (IX+E_FS),FS_PARRY
            LD   (IX+E_TMR),3
            LD   (IX+E_FRAME),FR_PARRY
            RET
GS_NOPAR:   CALL RAND8
            AND  7
            CP   2
            JR   C,GS_STRIKE            ; 2 in 8: lunge
            CP   3
            JR   Z,GS_RETREAT           ; 1 in 8: step back
            JR   GS_IDLE
GS_STRIKE:  LD   (IX+E_FS),FS_STRIKE
            LD   (IX+E_FI),0
            JP   FIGHT_STRIKE
GS_RETREAT: LD   B,256-FSTEP
            LD   A,(GFACE)
            OR   A
            JR   Z,GS_RMV
            LD   B,FSTEP
GS_RMV:     LD   (IX+E_FS),FS_GARDE
            LD   (IX+E_FRAME),FR_GARDE
            CALL FIGHT_MOVE
            LD   HL,GSWSTEP
            JP   STEP_ANIM
GS_IDLE:    LD   (IX+E_FS),FS_GARDE
            LD   (IX+E_FRAME),FR_GARDE
            LD   A,3                    ; standing still: the next walk starts at ADV again
            LD   (GSWSTEP),A
            RET
GS_PARHOLD: LD   A,(IX+E_TMR)
            OR   A
            JR   Z,GS_IDLE
            DEC  A
            LD   (IX+E_TMR),A
            RET
GS_HURT:    DEC  (IX+E_TMR)
            RET  NZ
            JR   GS_IDLE

RAND8:      LD   A,(SEED)               ; x*5+17 mod 256, high bits returned
            LD   B,A
            ADD  A,A
            ADD  A,A
            ADD  A,B
            ADD  A,17
            LD   (SEED),A
            RLCA
            RLCA
            RLCA
            RET

; DRAW_STATUS - hit-point pips in the bottom corners (prince left, guard right)
DRAW_STATUS:
            LD   A,2
            CALL SET_BANK
            LD   HL,VRAM+56*32          ; a dark box behind each set of pips, nothing else
            CALL CLEAR_BOX
            LD   HL,VRAM+56*32+28
            CALL CLEAR_BOX
            LD   A,(PHP)
            LD   B,A
            LD   DE,VRAM+56*32
DST_P:      LD   A,B
            OR   A
            JR   Z,DST_G
            PUSH BC
            PUSH DE
            LD   HL,PIP_L
            CALL DRAW_PIP
            POP  DE
            POP  BC
            INC  DE
            DJNZ DST_P
DST_G:      LD   A,(GHP)
            LD   B,A
            LD   DE,VRAM+56*32+31
DST_Q:      LD   A,B
            OR   A
            RET  Z
            PUSH BC
            PUSH DE
            LD   HL,PIP_R
            CALL DRAW_PIP
            POP  DE
            POP  BC
            DEC  DE
            DJNZ DST_Q
            RET
; CLEAR_BOX - HL = top-left byte: clear 4 bytes x 8 lines
CLEAR_BOX:  LD   B,8
            LD   DE,29
CB_L:       LD   (HL),0
            INC  HL
            LD   (HL),0
            INC  HL
            LD   (HL),0
            INC  HL
            LD   (HL),0
            ADD  HL,DE
            DJNZ CB_L
            RET
DRAW_PIP:   LD   B,8
DP_L:       LD   A,(HL)
            LD   (DE),A
            INC  HL
            LD   A,E
            ADD  A,32
            LD   E,A
            JR   NC,DP_N
            INC  D
DP_N:       DJNZ DP_L
            RET
PIP_L:      DEFB $80,$C0,$E0,$F0,$F8,$FC,$FE,$FE
PIP_R:      DEFB $01,$03,$07,$0F,$1F,$3F,$7F,$7F

; ---------------------------------------------------------------------------
; Room 1 (8 x 3)
; ---------------------------------------------------------------------------
ROOM_MAP:   DEFS 24         ; the current room's tiles (copied from the level data by LOAD_ROOM)

; ---------------------------------------------------------------------------
; Variables (RAM).  P_ENT / G_ENT: X,Y,FACE,FRAME,FS,FI,HP,TMR,ROW,BL,BR,BT,BB
; ---------------------------------------------------------------------------
P_ENT:      DEFB 0,0,0,0,0,0,3,0,1,0,0,0,0
G_ENT:      DEFB 100,82,1,9,0,0,3,0,1,0,0,0,0
PX          EQU P_ENT+E_X
PY          EQU P_ENT+E_Y
PFACE       EQU P_ENT+E_FACE
PFRAME      EQU P_ENT+E_FRAME
PFS         EQU P_ENT+E_FS
PFI         EQU P_ENT+E_FI
PHP         EQU P_ENT+E_HP
PTMR        EQU P_ENT+E_TMR
PROW        EQU P_ENT+E_ROW
GX          EQU G_ENT+E_X
GY          EQU G_ENT+E_Y
GFACE       EQU G_ENT+E_FACE
GFRAME      EQU G_ENT+E_FRAME
GFS         EQU G_ENT+E_FS
GFI         EQU G_ENT+E_FI
GHP         EQU G_ENT+E_HP
GTMR        EQU G_ENT+E_TMR
GROW        EQU G_ENT+E_ROW

CUR_BANK:   DEFB 0
CUR_LEVEL:  DEFB 0
LVL_START:  DEFW 0          ; -> this level's start data (room, X, row)
LVL_ROOMS:  DEFW 0          ; -> this level's first room (32 bytes each)
CHOMP_T:    DEFB 0
CC_I:       DEFB 0
SND_REQ:    DEFB 0          ; most important sound asked for this frame
SND_MUTE:   DEFB 0
MPREV:      DEFB 0
NSEED:      DEFB 91
TS_T:       DEFB 0
GATE_LVL:   DEFB 0          ; 0 = gates shut .. 5 = fully raised
GATE_TGT:   DEFB 0
GATE_HOLD:  DEFB 0          ; frames left before they come down
SG_I:       DEFB 0
LOOSE_ARM:  DEFB 0          ; frames until the loose tile under him falls (0 = not armed)
LOOSE_COL:  DEFB 0
LOOSE_ROW:  DEFB 0
LR_FL:      DEFB 0
FALLN:      DEFB 0          ; floor lines passed in the current fall
CD_HX:      DEFB 0
CD_FACE:    DEFB 0
WINFLAG:    DEFB 0
TORCH_T:    DEFB 0          ; frame counter for the torch flicker
TORCH_PTR:  DEFW TORCH_BMP  ; flame picture currently used when a torch is drawn
START_LV:   DEFB 0          ; level chosen on the intro screen (keys 1-3)
PA_LINE:    DEFB 0
PA_COL:     DEFB 0
RUNPH:      DEFB 0          ; 0 stand, 1-2 run start-up, 3 running, 4-5 stopping
TURNTO:     DEFB 0
TIDX:       DEFB 0
LTMR:       DEFB 0          ; landing crouch frames left
JSPD:       DEFB 0          ; forward px per frame in the current jump
MV_STEP:    DEFB 0
CUR_ROOM:   DEFB 0
NEIGH_L:    DEFB 255
NEIGH_R:    DEFB 255
NEIGH_U:    DEFB 255
NEIGH_D:    DEFB 255
G_ACTIVE:   DEFB 0          ; 1 = this room has a guard
GKIND:      DEFB 0          ; 0 = guard, 1 = skeleton (room attribute kind=1)
ROOM_FLAGS: DEFS 32         ; per room: bit 0 guard killed, bit 1 potion drunk, bit 2 loose tile fallen
RR_ROW:     DEFB 0
KEYS:       DEFB 0
JPREV:      DEFB 0
DPREV:      DEFB 0
PSTATE:     DEFB 0          ; 0 ground, 1 falling, 2 jumping, 3 climbing, 4 turning, 5 landing, 6 hanging down
PSWORD:     DEFB 0          ; 1 = sword drawn
JMOVE:      DEFB 0
JIDX:       DEFB 0
CIDX:       DEFB 0
CL_BASE:    DEFB 0
CL_HX:      DEFB 0
CL_FX:      DEFB 0
CL_DIR:     DEFB 0
CG_CEN:     DEFB 0
CG_C:       DEFB 0
CG_TC:      DEFB 0
CG_B:       DEFB 0
NEWX:       DEFB 0
SEED:       DEFB 77
FM_DX:      DEFB 0
FM_NX:      DEFB 0
ER_L:       DEFB 0
ER_R:       DEFB 0
ER_T:       DEFB 0
ER_B:       DEFB 0
ER_C0:      DEFB 0
ER_C1:      DEFB 0
ER_R0:      DEFB 0
ER_R1:      DEFB 0
ER_C:       DEFB 0
SP_X:       DEFB 0
SP_Y:       DEFB 0
SP_FLIP:    DEFB 0
DS_W:       DEFB 0
DS_N:       DEFB 0
DS_XO:      DEFB 0
DS_SRC:     DEFW 0
DS_DEST:    DEFW 0
DS_Y:       DEFB 0
DS_BANK:    DEFB 0
DS_S:       DEFB 0
DS_D0:      DEFB 0
DS_HM:      DEFB 0
DS_BL:      DEFB 0
DS_BR:      DEFB 0
DS_BT:      DEFB 0
DS_BB:      DEFB 0
MBUF:       DEFS 16
IBUF:       DEFS 16
DRAW_BASE:  DEFW VRAM       ; where DRAW_CELL / DRAW_SPRITE write: VRAM, or SHADOW while composing
DS_MODE:    DEFB 0          ; 0 draw to the screen, 1 box only, 2 draw to SHADOW (one bank row)
DS_ROW:     DEFB 0
PSWSTEP:    DEFB 0          ; sword-walk step phase 0..3 (prince)
GSWSTEP:    DEFB 0          ; same for the guard / skeleton
DIRTY:      DEFS 3          ; per bank row: bit mask of the cells to rebuild this frame
US_R:       DEFB 0
US_M:       DEFB 0

; ======== begin _tiles.inc (generated data) ========
; GENERATED by make_tiles.py from tiles.txt - edit the art there.
; Tiles are 4 bytes wide (32 px).  Each tile stores only its non-blank lines;
; TILE_TBL entry = DEFW bitmap, DEFB first_line, DEFB line_count.

T_EMPTY  EQU 0
T_WALL    EQU 1
T_WALLR   EQU 2
T_FLOOR   EQU 3
T_FLOORL  EQU 4
T_PILLAR  EQU 5
T_LOOSE   EQU 6
T_PLATE   EQU 7
T_PLATEON EQU 8
T_EXIT    EQU 9
T_GATE0   EQU 10
T_GATE1   EQU 11
T_GATE2   EQU 12
T_GATE3   EQU 13
T_GATE4   EQU 14
T_GATE5   EQU 15
T_CHOMP0  EQU 16
T_CHOMP1  EQU 17
T_CHOMP2  EQU 18
T_SPIKES  EQU 19
T_TORCH  EQU $80      ; add to any tile id to overlay a wall torch
TORCH_Y   EQU 21
TORCH_H   EQU 24

TILE_TBL:
        DEFW 0
        DEFB 0,0      ; id 0 = empty (never read)
        DEFW TILE_WALL
        DEFB 0,63   ; WALL
        DEFW TILE_WALLR
        DEFB 0,64   ; WALLR
        DEFW TILE_FLOOR
        DEFB 50,14   ; FLOOR
        DEFW TILE_FLOORL
        DEFB 54,10   ; FLOORL
        DEFW TILE_PILLAR
        DEFB 0,64   ; PILLAR
        DEFW TILE_LOOSE
        DEFB 50,14   ; LOOSE
        DEFW TILE_PLATE
        DEFB 50,14   ; PLATE
        DEFW TILE_PLATEON
        DEFB 50,14   ; PLATEON
        DEFW TILE_EXIT
        DEFB 4,60   ; EXIT
        DEFW TILE_GATE0
        DEFB 0,64   ; GATE0
        DEFW TILE_GATE1
        DEFB 0,64   ; GATE1
        DEFW TILE_GATE2
        DEFB 0,64   ; GATE2
        DEFW TILE_GATE3
        DEFB 0,64   ; GATE3
        DEFW TILE_GATE4
        DEFB 0,64   ; GATE4
        DEFW TILE_GATE5
        DEFB 0,64   ; GATE5
        DEFW TILE_CHOMP0
        DEFB 0,64   ; CHOMP0
        DEFW TILE_CHOMP1
        DEFB 0,64   ; CHOMP1
        DEFW TILE_CHOMP2
        DEFB 0,64   ; CHOMP2
        DEFW TILE_SPIKES
        DEFB 40,23   ; SPIKES

TILE_WALL:  ; id 1, lines 0..62
        DEFB $3F,$FF,$FF,$F8
        DEFB $7F,$D5,$55,$54
        DEFB $C0,$6A,$AA,$AA
        DEFB $CF,$D5,$55,$56
        DEFB $DA,$AA,$AA,$AA
        DEFB $D5,$55,$55,$56
        DEFB $DA,$AA,$AA,$AA
        DEFB $F5,$55,$55,$56
        DEFB $AA,$AA,$AA,$AA
        DEFB $D5,$55,$55,$56
        DEFB $AA,$AA,$AA,$AA
        DEFB $D5,$55,$55,$56
        DEFB $AA,$AA,$AA,$AA
        DEFB $D5,$55,$55,$56
        DEFB $AA,$AA,$AA,$AA
        DEFB $D5,$55,$55,$56
        DEFB $AA,$AA,$AA,$AA
        DEFB $D5,$55,$55,$56
        DEFB $6A,$AA,$AA,$AC
        DEFB $3F,$FF,$FF,$F8
        DEFB $00,$00,$00,$00
        DEFB $3F,$F0,$3F,$F8
        DEFB $7F,$A8,$7F,$AC
        DEFB $C0,$54,$C0,$56
        DEFB $CF,$AC,$CF,$AA
        DEFB $D5,$54,$D5,$56
        DEFB $DA,$AC,$DA,$AA
        DEFB $D5,$54,$D5,$56
        DEFB $AA,$AC,$AA,$AA
        DEFB $D5,$54,$D5,$56
        DEFB $AA,$AC,$AA,$AA
        DEFB $D5,$54,$D5,$56
        DEFB $AA,$AC,$AA,$AA
        DEFB $D5,$54,$D5,$56
        DEFB $AA,$AC,$AA,$AA
        DEFB $D5,$54,$D5,$56
        DEFB $AA,$AC,$AA,$AA
        DEFB $D5,$54,$D5,$56
        DEFB $AA,$AC,$AA,$AA
        DEFB $55,$58,$55,$54
        DEFB $3F,$F0,$3F,$F8
        DEFB $00,$00,$00,$00
        DEFB $3F,$FF,$FF,$F8
        DEFB $7F,$D5,$55,$54
        DEFB $C0,$6A,$AA,$AA
        DEFB $CF,$D5,$55,$56
        DEFB $DA,$AA,$AA,$AA
        DEFB $D5,$55,$55,$56
        DEFB $DA,$AA,$AA,$AA
        DEFB $F5,$55,$55,$56
        DEFB $AA,$AA,$AA,$AA
        DEFB $D5,$55,$55,$56
        DEFB $AA,$AA,$AA,$AA
        DEFB $D5,$55,$55,$56
        DEFB $AA,$AA,$AA,$AA
        DEFB $D5,$55,$55,$56
        DEFB $AA,$AA,$AA,$AA
        DEFB $D5,$55,$55,$56
        DEFB $AA,$AA,$AA,$AA
        DEFB $D5,$55,$55,$56
        DEFB $AA,$AA,$AA,$AA
        DEFB $55,$55,$55,$54
        DEFB $3F,$FF,$FF,$F8
TILE_WALLR:  ; id 2, lines 0..63
        DEFB $3F,$FF,$FE,$B6
        DEFB $7F,$D5,$56,$49
        DEFB $C0,$6A,$AA,$B6
        DEFB $CF,$D5,$56,$49
        DEFB $DA,$AA,$AA,$B6
        DEFB $D5,$55,$56,$49
        DEFB $DA,$AA,$AA,$B6
        DEFB $F5,$55,$56,$49
        DEFB $AA,$AA,$AA,$B6
        DEFB $D5,$55,$56,$49
        DEFB $AA,$AA,$AA,$B6
        DEFB $D5,$55,$56,$49
        DEFB $AA,$AA,$AA,$B6
        DEFB $D5,$55,$56,$49
        DEFB $AA,$AA,$AA,$B6
        DEFB $D5,$55,$56,$49
        DEFB $AA,$AA,$AA,$B6
        DEFB $D5,$55,$56,$49
        DEFB $6A,$AA,$AA,$B4
        DEFB $3F,$FF,$FE,$41
        DEFB $00,$00,$00,$16
        DEFB $3F,$F0,$3E,$49
        DEFB $7F,$A8,$7E,$B6
        DEFB $C0,$54,$C0,$49
        DEFB $CF,$AC,$CE,$B6
        DEFB $D5,$54,$D6,$49
        DEFB $DA,$AC,$DA,$B6
        DEFB $D5,$54,$D6,$49
        DEFB $AA,$AC,$AA,$B6
        DEFB $D5,$54,$D6,$49
        DEFB $AA,$AC,$AA,$B6
        DEFB $D5,$54,$D6,$49
        DEFB $AA,$AC,$AA,$B6
        DEFB $D5,$54,$D6,$49
        DEFB $AA,$AC,$AA,$B6
        DEFB $D5,$54,$D6,$49
        DEFB $AA,$AC,$AA,$B6
        DEFB $D5,$54,$D6,$49
        DEFB $AA,$AC,$AA,$B6
        DEFB $55,$58,$56,$48
        DEFB $3F,$F0,$3E,$A2
        DEFB $00,$00,$00,$09
        DEFB $3F,$FF,$FE,$B6
        DEFB $7F,$D5,$56,$49
        DEFB $C0,$6A,$AA,$B6
        DEFB $CF,$D5,$56,$49
        DEFB $DA,$AA,$AA,$B6
        DEFB $D5,$55,$56,$49
        DEFB $DA,$AA,$AA,$B6
        DEFB $F5,$55,$56,$49
        DEFB $AA,$AA,$AA,$B6
        DEFB $D5,$55,$56,$49
        DEFB $AA,$AA,$AA,$B6
        DEFB $D5,$55,$56,$49
        DEFB $AA,$AA,$AA,$B6
        DEFB $D5,$55,$56,$49
        DEFB $AA,$AA,$AA,$B6
        DEFB $D5,$55,$56,$49
        DEFB $AA,$AA,$AA,$B6
        DEFB $D5,$55,$56,$49
        DEFB $AA,$AA,$AA,$B6
        DEFB $55,$55,$56,$48
        DEFB $3F,$FF,$FE,$A2
        DEFB $00,$00,$00,$09
TILE_FLOOR:  ; id 3, lines 50..63
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$00,$00,$00
        DEFB $AA,$AA,$AA,$AA
        DEFB $55,$55,$55,$55
        DEFB $AA,$AA,$AA,$AA
        DEFB $55,$55,$55,$55
        DEFB $AA,$AA,$AA,$AA
        DEFB $55,$55,$55,$55
        DEFB $AA,$AA,$AA,$AA
        DEFB $55,$55,$55,$55
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $FF,$FF,$FF,$FF
TILE_FLOORL:  ; id 4, lines 54..63
        DEFB $00,$00,$00,$02
        DEFB $00,$00,$00,$01
        DEFB $00,$00,$00,$AA
        DEFB $00,$00,$01,$55
        DEFB $00,$00,$2A,$AA
        DEFB $00,$00,$55,$55
        DEFB $00,$3F,$FF,$FF
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $FF,$FF,$FF,$FF
TILE_PILLAR:  ; id 5, lines 0..63
        DEFB $07,$FF,$F2,$48
        DEFB $05,$FD,$55,$B0
        DEFB $06,$02,$B2,$48
        DEFB $06,$7D,$55,$B0
        DEFB $06,$AA,$B2,$48
        DEFB $06,$D5,$55,$B0
        DEFB $06,$AA,$B2,$48
        DEFB $05,$55,$55,$B0
        DEFB $06,$AA,$B2,$48
        DEFB $05,$55,$55,$B0
        DEFB $06,$AA,$B2,$48
        DEFB $03,$55,$55,$A0
        DEFB $01,$FF,$F2,$08
        DEFB $00,$00,$00,$B0
        DEFB $01,$FF,$F2,$48
        DEFB $03,$FD,$55,$B0
        DEFB $06,$02,$B2,$48
        DEFB $06,$7D,$55,$B0
        DEFB $06,$AA,$B2,$48
        DEFB $06,$D5,$55,$B0
        DEFB $06,$AA,$B2,$48
        DEFB $05,$55,$55,$B0
        DEFB $06,$AA,$B2,$48
        DEFB $05,$55,$55,$B0
        DEFB $06,$AA,$B2,$48
        DEFB $03,$55,$55,$A0
        DEFB $01,$FF,$F2,$08
        DEFB $00,$00,$00,$B0
        DEFB $01,$FF,$F2,$48
        DEFB $03,$FD,$55,$B0
        DEFB $06,$02,$B2,$48
        DEFB $06,$7D,$55,$B0
        DEFB $06,$AA,$B2,$48
        DEFB $06,$D5,$55,$B0
        DEFB $06,$AA,$B2,$48
        DEFB $05,$55,$55,$B0
        DEFB $06,$AA,$B2,$48
        DEFB $05,$55,$55,$B0
        DEFB $06,$AA,$B2,$48
        DEFB $03,$55,$55,$A0
        DEFB $01,$FF,$F2,$08
        DEFB $00,$00,$00,$B0
        DEFB $01,$FF,$F2,$48
        DEFB $03,$FD,$55,$B0
        DEFB $06,$02,$B2,$48
        DEFB $06,$7D,$55,$B0
        DEFB $06,$AA,$B2,$48
        DEFB $06,$D5,$55,$B0
        DEFB $06,$AA,$B2,$48
        DEFB $05,$55,$55,$B0
        DEFB $FA,$AA,$B2,$4F
        DEFB $05,$55,$55,$B0
        DEFB $FA,$AA,$B2,$4F
        DEFB $05,$55,$55,$A0
        DEFB $FF,$FF,$F2,$0F
        DEFB $00,$00,$00,$B0
        DEFB $FF,$FF,$FA,$4F
        DEFB $00,$00,$05,$B0
        DEFB $FF,$FF,$FA,$4F
        DEFB $15,$55,$56,$00
        DEFB $EA,$AA,$AB,$FF
        DEFB $1F,$FF,$FE,$00
        DEFB $00,$00,$00,$00
        DEFB $FF,$FF,$FF,$FF
TILE_LOOSE:  ; id 6, lines 50..63
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$00,$00,$00
        DEFB $2A,$AA,$AA,$A4
        DEFB $15,$55,$55,$30
        DEFB $2A,$AA,$A9,$88
        DEFB $15,$55,$19,$54
        DEFB $2A,$A8,$CA,$A8
        DEFB $15,$46,$55,$54
        DEFB $2A,$62,$AA,$A8
        DEFB $13,$15,$55,$54
        DEFB $3B,$FE,$E7,$7C
        DEFB $07,$80,$07,$00
        DEFB $00,$00,$00,$00
        DEFB $FF,$FF,$FF,$FF
TILE_PLATE:  ; id 7, lines 50..63
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$00,$00,$00
        DEFB $A8,$00,$07,$FF
        DEFB $50,$00,$35,$55
        DEFB $A8,$01,$AA,$A8
        DEFB $50,$0D,$55,$40
        DEFB $A8,$6A,$AA,$00
        DEFB $53,$FF,$F0,$00
        DEFB $AB,$FF,$F0,$00
        DEFB $55,$55,$55,$55
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $FF,$FF,$FF,$FF
TILE_PLATEON:  ; id 8, lines 50..63
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$00,$00,$00
        DEFB $AA,$AA,$AA,$AA
        DEFB $55,$55,$55,$55
        DEFB $AA,$AA,$AA,$AA
        DEFB $55,$55,$55,$55
        DEFB $A8,$00,$00,$00
        DEFB $50,$0F,$FF,$C0
        DEFB $A8,$6A,$AA,$00
        DEFB $53,$FF,$F0,$00
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $FF,$FF,$FF,$FF
TILE_EXIT:  ; id 9, lines 4..63
        DEFB $1F,$FF,$FF,$F8
        DEFB $1F,$CC,$CE,$E8
        DEFB $13,$73,$33,$78
        DEFB $13,$73,$33,$78
        DEFB $1F,$CC,$CE,$E8
        DEFB $1F,$CC,$CE,$E8
        DEFB $1F,$FF,$FF,$F8
        DEFB $17,$55,$57,$58
        DEFB $1F,$EA,$AA,$E8
        DEFB $17,$55,$57,$F8
        DEFB $1A,$EA,$AA,$E8
        DEFB $1F,$FF,$FF,$F8
        DEFB $17,$40,$02,$E8
        DEFB $17,$40,$02,$E8
        DEFB $12,$40,$02,$48
        DEFB $12,$40,$02,$48
        DEFB $17,$40,$02,$E8
        DEFB $17,$40,$02,$E8
        DEFB $12,$40,$1E,$48
        DEFB $12,$40,$1E,$48
        DEFB $17,$40,$1A,$E8
        DEFB $17,$40,$16,$E8
        DEFB $12,$40,$1A,$48
        DEFB $12,$40,$16,$48
        DEFB $17,$40,$7E,$E8
        DEFB $17,$40,$7E,$E8
        DEFB $12,$40,$7A,$48
        DEFB $12,$40,$56,$48
        DEFB $17,$40,$7A,$E8
        DEFB $17,$40,$56,$E8
        DEFB $12,$41,$FE,$48
        DEFB $12,$41,$FE,$48
        DEFB $17,$41,$FA,$E8
        DEFB $17,$41,$56,$E8
        DEFB $12,$41,$FA,$48
        DEFB $12,$41,$56,$48
        DEFB $17,$47,$FE,$E8
        DEFB $17,$47,$FE,$E8
        DEFB $12,$47,$FA,$48
        DEFB $12,$45,$56,$48
        DEFB $17,$47,$FA,$E8
        DEFB $17,$45,$56,$E8
        DEFB $12,$5F,$FE,$48
        DEFB $12,$5F,$FE,$48
        DEFB $17,$5F,$FA,$E8
        DEFB $17,$7F,$FE,$E8
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$00,$00,$00
        DEFB $AA,$AA,$AA,$AA
        DEFB $55,$55,$55,$55
        DEFB $AA,$AA,$AA,$AA
        DEFB $55,$55,$55,$55
        DEFB $AA,$AA,$AA,$AA
        DEFB $55,$55,$55,$55
        DEFB $AA,$AA,$AA,$AA
        DEFB $55,$55,$55,$55
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $FF,$FF,$FF,$FF
TILE_GATE0:  ; id 10, lines 0..63
        DEFB $00,$0A,$AA,$AA
        DEFB $00,$55,$55,$55
        DEFB $0A,$AA,$AA,$AA
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$00,$00,$00
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$67,$E0
        DEFB $07,$E6,$7F,$E0
        DEFB $07,$C7,$FE,$E0
        DEFB $07,$FF,$E6,$E0
        DEFB $07,$DE,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$67,$E0
        DEFB $07,$E6,$7F,$E0
        DEFB $07,$C7,$FE,$E0
        DEFB $07,$FF,$E6,$E0
        DEFB $07,$DE,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $FF,$FF,$FF,$FF
        DEFB $07,$C6,$66,$E0
        DEFB $AF,$EE,$EE,$EA
        DEFB $57,$D7,$77,$55
        DEFB $AF,$EE,$EF,$AA
        DEFB $57,$D7,$7D,$55
        DEFB $AF,$EF,$EA,$AA
        DEFB $57,$DF,$55,$55
        DEFB $AF,$EA,$AA,$AA
        DEFB $55,$55,$55,$55
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $FF,$FF,$FF,$FF
TILE_GATE1:  ; id 11, lines 0..63
        DEFB $00,$0A,$AA,$AA
        DEFB $00,$55,$55,$55
        DEFB $0A,$AA,$AA,$AA
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$00,$00,$00
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$67,$E0
        DEFB $07,$E6,$7F,$E0
        DEFB $07,$C7,$FE,$E0
        DEFB $07,$FF,$E6,$E0
        DEFB $07,$DE,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$67,$E0
        DEFB $07,$E6,$7F,$E0
        DEFB $07,$C7,$FE,$E0
        DEFB $07,$FF,$E6,$E0
        DEFB $07,$DE,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $FF,$FF,$FF,$FF
        DEFB $07,$C0,$00,$E0
        DEFB $AF,$EA,$AA,$EA
        DEFB $57,$D5,$55,$55
        DEFB $AF,$EA,$AA,$AA
        DEFB $57,$D5,$55,$55
        DEFB $AF,$EA,$AA,$AA
        DEFB $57,$D5,$55,$55
        DEFB $AF,$EA,$AA,$AA
        DEFB $55,$55,$55,$55
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $FF,$FF,$FF,$FF
TILE_GATE2:  ; id 12, lines 0..63
        DEFB $00,$0A,$AA,$AA
        DEFB $00,$55,$55,$55
        DEFB $0A,$AA,$AA,$AA
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$00,$00,$00
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$67,$E0
        DEFB $07,$E6,$7F,$E0
        DEFB $07,$C7,$FE,$E0
        DEFB $07,$FF,$E6,$E0
        DEFB $07,$DE,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E4,$44,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $FF,$FF,$FF,$FF
        DEFB $07,$C0,$00,$E0
        DEFB $AF,$EA,$AA,$EA
        DEFB $57,$D5,$55,$55
        DEFB $AF,$EA,$AA,$AA
        DEFB $57,$D5,$55,$55
        DEFB $AF,$EA,$AA,$AA
        DEFB $57,$D5,$55,$55
        DEFB $AF,$EA,$AA,$AA
        DEFB $55,$55,$55,$55
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $FF,$FF,$FF,$FF
TILE_GATE3:  ; id 13, lines 0..63
        DEFB $00,$0A,$AA,$AA
        DEFB $00,$55,$55,$55
        DEFB $0A,$AA,$AA,$AA
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$00,$00,$00
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$67,$E0
        DEFB $07,$E6,$7F,$E0
        DEFB $07,$C7,$FE,$E0
        DEFB $07,$FF,$E6,$E0
        DEFB $07,$DE,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E4,$44,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $FF,$FF,$FF,$FF
        DEFB $07,$C0,$00,$E0
        DEFB $AF,$EA,$AA,$EA
        DEFB $57,$D5,$55,$55
        DEFB $AF,$EA,$AA,$AA
        DEFB $57,$D5,$55,$55
        DEFB $AF,$EA,$AA,$AA
        DEFB $57,$D5,$55,$55
        DEFB $AF,$EA,$AA,$AA
        DEFB $55,$55,$55,$55
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $FF,$FF,$FF,$FF
TILE_GATE4:  ; id 14, lines 0..63
        DEFB $00,$0A,$AA,$AA
        DEFB $00,$55,$55,$55
        DEFB $0A,$AA,$AA,$AA
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$00,$00,$00
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E4,$44,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $FF,$FF,$FF,$FF
        DEFB $07,$C0,$00,$E0
        DEFB $AF,$EA,$AA,$EA
        DEFB $57,$D5,$55,$55
        DEFB $AF,$EA,$AA,$AA
        DEFB $57,$D5,$55,$55
        DEFB $AF,$EA,$AA,$AA
        DEFB $57,$D5,$55,$55
        DEFB $AF,$EA,$AA,$AA
        DEFB $55,$55,$55,$55
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $FF,$FF,$FF,$FF
TILE_GATE5:  ; id 15, lines 0..63
        DEFB $00,$0A,$AA,$AA
        DEFB $00,$55,$55,$55
        DEFB $0A,$AA,$AA,$AA
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$00,$00,$00
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $07,$E6,$66,$E0
        DEFB $07,$C6,$66,$E0
        DEFB $07,$E4,$44,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $07,$E0,$00,$E0
        DEFB $07,$C0,$00,$E0
        DEFB $FF,$FF,$FF,$FF
        DEFB $07,$C0,$00,$E0
        DEFB $AF,$EA,$AA,$EA
        DEFB $57,$D5,$55,$55
        DEFB $AF,$EA,$AA,$AA
        DEFB $57,$D5,$55,$55
        DEFB $AF,$EA,$AA,$AA
        DEFB $57,$D5,$55,$55
        DEFB $AF,$EA,$AA,$AA
        DEFB $55,$55,$55,$55
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $FF,$FF,$FF,$FF
TILE_CHOMP0:  ; id 16, lines 0..63
        DEFB $00,$0A,$AA,$AA
        DEFB $00,$55,$55,$55
        DEFB $0A,$AA,$AA,$AA
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$00,$00,$00
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FA,$80
        DEFB $00,$7F,$FB,$00
        DEFB $00,$7F,$B8,$80
        DEFB $00,$7B,$91,$00
        DEFB $00,$39,$00,$80
        DEFB $00,$30,$01,$00
        DEFB $00,$00,$00,$80
        DEFB $00,$00,$01,$00
        DEFB $00,$00,$00,$80
        DEFB $00,$00,$01,$00
        DEFB $00,$00,$00,$80
        DEFB $00,$00,$01,$00
        DEFB $00,$00,$00,$80
        DEFB $00,$00,$01,$00
        DEFB $00,$00,$00,$80
        DEFB $00,$00,$01,$00
        DEFB $00,$00,$00,$80
        DEFB $00,$00,$01,$00
        DEFB $00,$00,$00,$80
        DEFB $00,$00,$01,$00
        DEFB $00,$00,$00,$80
        DEFB $00,$00,$01,$00
        DEFB $00,$00,$04,$80
        DEFB $00,$00,$07,$00
        DEFB $00,$00,$6E,$80
        DEFB $00,$06,$EF,$00
        DEFB $00,$4E,$FE,$80
        DEFB $00,$6F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$7F,$FF,$00
        DEFB $AA,$FF,$FE,$AA
        DEFB $55,$7F,$FF,$55
        DEFB $AA,$FF,$FE,$AA
        DEFB $55,$7F,$FD,$55
        DEFB $AA,$FF,$EA,$AA
        DEFB $55,$7D,$55,$55
        DEFB $AA,$EA,$AA,$AA
        DEFB $55,$55,$55,$55
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $FF,$FF,$FF,$FF
TILE_CHOMP1:  ; id 17, lines 0..63
        DEFB $00,$0A,$AA,$AA
        DEFB $00,$55,$55,$55
        DEFB $0A,$AA,$AA,$AA
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$00,$00,$00
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FA,$80
        DEFB $00,$7F,$FB,$00
        DEFB $00,$7F,$B8,$80
        DEFB $00,$7B,$91,$00
        DEFB $00,$39,$00,$80
        DEFB $00,$30,$01,$00
        DEFB $00,$00,$00,$80
        DEFB $00,$00,$01,$00
        DEFB $00,$00,$00,$80
        DEFB $00,$00,$05,$00
        DEFB $00,$00,$06,$80
        DEFB $00,$00,$6F,$00
        DEFB $00,$06,$EE,$80
        DEFB $00,$4E,$FF,$00
        DEFB $00,$6F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$7F,$FF,$00
        DEFB $AA,$FF,$FE,$AA
        DEFB $55,$7F,$FF,$55
        DEFB $AA,$FF,$FE,$AA
        DEFB $55,$7F,$FD,$55
        DEFB $AA,$FF,$EA,$AA
        DEFB $55,$7D,$55,$55
        DEFB $AA,$EA,$AA,$AA
        DEFB $55,$55,$55,$55
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $FF,$FF,$FF,$FF
TILE_CHOMP2:  ; id 18, lines 0..63
        DEFB $00,$0A,$AA,$AA
        DEFB $00,$55,$55,$55
        DEFB $0A,$AA,$AA,$AA
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$00,$00,$00
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FB,$00
        DEFB $00,$7F,$FA,$80
        DEFB $00,$7F,$B9,$00
        DEFB $00,$7B,$90,$80
        DEFB $00,$39,$05,$00
        DEFB $00,$30,$06,$80
        DEFB $00,$00,$6F,$00
        DEFB $00,$06,$EE,$80
        DEFB $00,$4E,$FF,$00
        DEFB $00,$6F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $00,$7F,$FE,$80
        DEFB $00,$7F,$FF,$00
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$7F,$FF,$00
        DEFB $AA,$FF,$FE,$AA
        DEFB $55,$7F,$FF,$55
        DEFB $AA,$FF,$FE,$AA
        DEFB $55,$7F,$FD,$55
        DEFB $AA,$FF,$EA,$AA
        DEFB $55,$7D,$55,$55
        DEFB $AA,$EA,$AA,$AA
        DEFB $55,$55,$55,$55
        DEFB $FF,$FF,$FF,$FF
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $FF,$FF,$FF,$FF
TILE_SPIKES:  ; id 19, lines 40..62
        DEFB $00,$00,$00,$08
        DEFB $00,$00,$00,$08
        DEFB $00,$00,$02,$08
        DEFB $00,$00,$02,$08
        DEFB $00,$00,$82,$0A
        DEFB $00,$00,$82,$08
        DEFB $00,$20,$82,$8E
        DEFB $00,$20,$82,$0C
        DEFB $08,$20,$A3,$8E
        DEFB $08,$20,$83,$0C
        DEFB $A8,$28,$E3,$8E
        DEFB $48,$20,$C3,$0C
        DEFB $AA,$38,$E3,$8E
        DEFB $48,$30,$C3,$0F
        DEFB $AE,$38,$E3,$F0
        DEFB $4C,$30,$C3,$80
        DEFB $AE,$38,$FC,$00
        DEFB $4C,$31,$E0,$00
        DEFB $AE,$3E,$00,$00
        DEFB $4C,$F0,$00,$00
        DEFB $AF,$00,$00,$00
        DEFB $58,$00,$00,$00
        DEFB $A0,$00,$00,$00

; torch pictures: frame 0 is the static torch, 2 and 3 are the extra flame frames the engine cycles through
TORCH_BMP:   ; 2 bytes wide, drawn at byte column 1 of the cell
        DEFB $00,$00
        DEFB $01,$00
        DEFB $02,$00
        DEFB $02,$80
        DEFB $05,$00
        DEFB $0A,$80
        DEFB $15,$40
        DEFB $2A,$A0
        DEFB $15,$40
        DEFB $0F,$C0
        DEFB $07,$80
        DEFB $07,$80
        DEFB $07,$80
        DEFB $0F,$C0
        DEFB $03,$00
        DEFB $0F,$C0
        DEFB $03,$00
        DEFB $03,$00
        DEFB $03,$00
        DEFB $03,$00
        DEFB $03,$00
        DEFB $03,$00
        DEFB $03,$00
        DEFB $03,$00
TORCH2_BMP:   ; 2 bytes wide, drawn at byte column 1 of the cell
        DEFB $00,$80
        DEFB $01,$00
        DEFB $02,$80
        DEFB $02,$80
        DEFB $05,$00
        DEFB $0A,$80
        DEFB $15,$40
        DEFB $2A,$A0
        DEFB $15,$40
        DEFB $0F,$C0
        DEFB $07,$80
        DEFB $07,$80
        DEFB $07,$80
        DEFB $0F,$C0
        DEFB $03,$00
        DEFB $0F,$C0
        DEFB $03,$00
        DEFB $03,$00
        DEFB $03,$00
        DEFB $03,$00
        DEFB $03,$00
        DEFB $03,$00
        DEFB $03,$00
        DEFB $03,$00
TORCH3_BMP:   ; 2 bytes wide, drawn at byte column 1 of the cell
        DEFB $00,$00
        DEFB $00,$00
        DEFB $00,$00
        DEFB $02,$00
        DEFB $05,$00
        DEFB $0A,$80
        DEFB $15,$40
        DEFB $2A,$A0
        DEFB $15,$40
        DEFB $0F,$C0
        DEFB $07,$80
        DEFB $07,$80
        DEFB $07,$80
        DEFB $0F,$C0
        DEFB $03,$00
        DEFB $0F,$C0
        DEFB $03,$00
        DEFB $03,$00
        DEFB $03,$00
        DEFB $03,$00
        DEFB $03,$00
        DEFB $03,$00
        DEFB $03,$00
        DEFB $03,$00
DECOR_H    EQU 14
DECOR_BMP:   ; two pictures, 3 bytes per line
        DEFB $1F,$FF,$FE
        DEFB $04,$00,$80
        DEFB $04,$00,$80
        DEFB $04,$00,$80
        DEFB $05,$FE,$FE
        DEFB $01,$40,$08
        DEFB $00,$40,$08
        DEFB $00,$40,$08
        DEFB $3E,$3F,$FE
        DEFB $04,$01,$00
        DEFB $04,$01,$00
        DEFB $04,$81,$00
        DEFB $04,$00,$00
        DEFB $00,$00,$00
        DEFB $3F,$FF,$F0
        DEFB $08,$08,$00
        DEFB $08,$08,$00
        DEFB $08,$08,$00
        DEFB $29,$FF,$FE
        DEFB $00,$04,$80
        DEFB $00,$80,$80
        DEFB $00,$80,$80
        DEFB $3F,$FF,$FE
        DEFB $08,$01,$00
        DEFB $08,$01,$00
        DEFB $08,$01,$00
        DEFB $08,$01,$00
        DEFB $00,$00,$00
; ======== end _tiles.inc ========
; ======== begin _sprites.inc (generated data) ========
; GENERATED by make_sprites.py from sprites.txt - edit the art there.
; Frame = DEFB W(bytes),H(lines),XO(signed px),YO(px)  then per line W image bytes + W mask bytes.

PRINCE_TBL:   ; one entry per frame (facing right; the engine mirrors at draw time)
        DEFW PRINCE_STAND
        DEFW PRINCE_RUN1
        DEFW PRINCE_RUN2
        DEFW PRINCE_RUN3
        DEFW PRINCE_RUN4
        DEFW PRINCE_JUMP
        DEFW PRINCE_HANG
        DEFW PRINCE_CLIMB1
        DEFW PRINCE_CLIMB2
        DEFW PRINCE_GARDE
        DEFW PRINCE_ADVANCE
        DEFW PRINCE_STRIKE1
        DEFW PRINCE_STRIKE2
        DEFW PRINCE_PARRY
        DEFW PRINCE_HURT
        DEFW PRINCE_DEAD
        DEFW PRINCE_RETREAT
        DEFW PRINCE_DRAW1
        DEFW PRINCE_DRAW2
        DEFW PRINCE_RUNSTART1
        DEFW PRINCE_RUNSTART2
        DEFW PRINCE_RUNSTOP1
        DEFW PRINCE_RUNSTOP2
        DEFW PRINCE_TURN1
        DEFW PRINCE_TURN2
        DEFW PRINCE_TURN3
        DEFW PRINCE_CROUCH
        DEFW PRINCE_LAND
        DEFW PRINCE_JWIND
        DEFW PRINCE_JRISE
        DEFW PRINCE_JAPEX
        DEFW PRINCE_JFALL
        DEFW PRINCE_FALL
        DEFW PRINCE_JUMPUP
        DEFW PRINCE_CLIMB3
        DEFW PRINCE_SWSTEPA
        DEFW PRINCE_SWSTEPB

GUARD_TBL:    ; guard frames = prince frames 9.. (frame number - 9), body area dithered
        DEFW GUARD_GARDE
        DEFW GUARD_ADVANCE
        DEFW GUARD_STRIKE1
        DEFW GUARD_STRIKE2
        DEFW GUARD_PARRY
        DEFW GUARD_HURT
        DEFW GUARD_DEAD
        DEFW GUARD_RETREAT
        DEFW GUARD_DRAW1
        DEFW GUARD_DRAW2
        DEFW GUARD_SWSTEPA
        DEFW GUARD_SWSTEPB

SKEL_TBL:     ; skeleton frames, same order as GUARD_TBL (room attribute kind=1), not dithered
        DEFW SKEL_GARDE
        DEFW SKEL_ADVANCE
        DEFW SKEL_STRIKE1
        DEFW SKEL_STRIKE2
        DEFW SKEL_PARRY
        DEFW SKEL_HURT
        DEFW SKEL_DEAD
        DEFW SKEL_RETREAT
        DEFW SKEL_DRAW1
        DEFW SKEL_DRAW2
        DEFW SKEL_SWSTEPA
        DEFW SKEL_SWSTEPB

PRINCE_STAND:
        DEFB 2,42,0,0
        DEFB $00,$00,$07,$E0
        DEFB $03,$C0,$0F,$F0
        DEFB $07,$E0,$1F,$F0
        DEFB $0F,$E0,$1F,$F0
        DEFB $0F,$E0,$1F,$F8
        DEFB $07,$70,$1F,$F8
        DEFB $03,$F0,$0F,$F8
        DEFB $01,$E0,$07,$F8
        DEFB $00,$40,$0F,$F0
        DEFB $05,$20,$1F,$F8
        DEFB $0A,$90,$1F,$FC
        DEFB $0D,$58,$1F,$FC
        DEFB $0C,$90,$1F,$FC
        DEFB $0D,$50,$1F,$F8
        DEFB $0C,$90,$1F,$F8
        DEFB $0D,$40,$1F,$F8
        DEFB $0E,$A0,$1F,$F0
        DEFB $0E,$40,$1F,$F0
        DEFB $08,$A0,$1F,$F8
        DEFB $07,$50,$1F,$F8
        DEFB $07,$20,$1F,$F8
        DEFB $0F,$50,$1F,$F8
        DEFB $0F,$A0,$1F,$F8
        DEFB $07,$D0,$1F,$F8
        DEFB $07,$E0,$0F,$F8
        DEFB $07,$E0,$0F,$F0
        DEFB $07,$E0,$0F,$F0
        DEFB $07,$E0,$0F,$F0
        DEFB $07,$E0,$1F,$F0
        DEFB $0B,$E0,$1F,$F0
        DEFB $0B,$E0,$1F,$F0
        DEFB $0B,$E0,$1F,$F0
        DEFB $0B,$E0,$1F,$F0
        DEFB $03,$E0,$1F,$F0
        DEFB $03,$E0,$0F,$F0
        DEFB $05,$E0,$0F,$F0
        DEFB $05,$E0,$0F,$F0
        DEFB $05,$E0,$0F,$F0
        DEFB $05,$E0,$0F,$F0
        DEFB $05,$E0,$0F,$F0
        DEFB $05,$E0,$0F,$FC
        DEFB $06,$F8,$0F,$FC
PRINCE_RUN1:
        DEFB 2,42,0,0
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$FC
        DEFB $00,$78,$01,$FE
        DEFB $00,$FC,$03,$FE
        DEFB $01,$FC,$03,$FE
        DEFB $01,$FC,$03,$FF
        DEFB $00,$EE,$03,$FF
        DEFB $00,$7E,$01,$FF
        DEFB $00,$7C,$01,$FF
        DEFB $00,$98,$07,$FE
        DEFB $03,$40,$07,$FC
        DEFB $02,$A0,$0F,$FE
        DEFB $07,$54,$0F,$FE
        DEFB $07,$28,$0F,$FE
        DEFB $07,$90,$1F,$FC
        DEFB $0F,$A8,$1F,$FF
        DEFB $0F,$D5,$3F,$FF
        DEFB $19,$CA,$3F,$FF
        DEFB $06,$E5,$3F,$FF
        DEFB $1F,$60,$3F,$FF
        DEFB $1F,$80,$7F,$F0
        DEFB $3F,$C0,$7F,$E0
        DEFB $1F,$C0,$FF,$F0
        DEFB $5F,$E0,$FF,$F8
        DEFB $EF,$F0,$FF,$FC
        DEFB $F7,$F8,$FF,$FC
        DEFB $FB,$F8,$FF,$FE
        DEFB $FD,$FC,$FF,$FF
        DEFB $F8,$FE,$FF,$FF
        DEFB $F0,$7E,$FD,$FF
        DEFB $E0,$3E,$F8,$FF
        DEFB $C0,$1F,$F0,$7F
        DEFB $80,$1F,$E0,$3F
        DEFB $00,$0F,$C0,$3F
        DEFB $00,$07,$00,$1F
        DEFB $00,$07,$00,$0F
        DEFB $00,$03,$00,$0F
        DEFB $00,$03,$00,$07
        DEFB $00,$01,$00,$07
PRINCE_RUN2:
        DEFB 2,42,0,0
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$FC
        DEFB $00,$78,$01,$FE
        DEFB $00,$FC,$03,$FE
        DEFB $01,$FC,$03,$FE
        DEFB $01,$FC,$03,$FF
        DEFB $00,$EE,$03,$FF
        DEFB $00,$7E,$01,$FF
        DEFB $00,$3C,$03,$FF
        DEFB $01,$88,$07,$FE
        DEFB $03,$20,$07,$FC
        DEFB $02,$50,$0F,$FE
        DEFB $06,$AC,$0F,$FE
        DEFB $05,$4C,$1F,$FE
        DEFB $0C,$98,$1F,$FF
        DEFB $09,$5D,$1F,$FF
        DEFB $0A,$BA,$3F,$FF
        DEFB $15,$75,$3F,$FF
        DEFB $02,$60,$3F,$FF
        DEFB $15,$60,$7F,$F0
        DEFB $32,$A0,$7F,$F8
        DEFB $24,$B0,$7F,$FE
        DEFB $2A,$BC,$7F,$FF
        DEFB $35,$BE,$7F,$FF
        DEFB $3B,$BF,$7F,$FF
        DEFB $3F,$7F,$7F,$FF
        DEFB $3F,$7F,$7F,$FF
        DEFB $3F,$1F,$7F,$FF
        DEFB $3F,$1F,$7F,$FF
        DEFB $3F,$3E,$7F,$FF
        DEFB $3E,$3E,$7F,$FF
        DEFB $3E,$3C,$7F,$FF
        DEFB $3E,$78,$7F,$FE
        DEFB $3C,$78,$7F,$FC
        DEFB $3C,$F8,$7F,$FE
        DEFB $3C,$FC,$7F,$FE
        DEFB $3C,$00,$FF,$FE
        DEFB $78,$00,$FE,$00
        DEFB $78,$00,$FC,$00
        DEFB $78,$00,$FC,$00
PRINCE_RUN3:
        DEFB 2,42,0,0
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$FC
        DEFB $00,$78,$01,$FE
        DEFB $00,$FC,$03,$FE
        DEFB $01,$FC,$03,$FE
        DEFB $01,$FC,$03,$FF
        DEFB $00,$EE,$03,$FF
        DEFB $00,$7E,$01,$FF
        DEFB $00,$7C,$01,$FF
        DEFB $00,$98,$07,$FE
        DEFB $03,$40,$07,$FC
        DEFB $02,$A0,$0F,$FE
        DEFB $05,$4C,$0F,$FE
        DEFB $04,$AC,$0F,$FE
        DEFB $01,$58,$0F,$FE
        DEFB $02,$B8,$0F,$FF
        DEFB $05,$75,$1F,$FF
        DEFB $0A,$FA,$1F,$FF
        DEFB $04,$E5,$1F,$FF
        DEFB $09,$60,$3F,$FF
        DEFB $15,$80,$7F,$F0
        DEFB $2B,$80,$7F,$C0
        DEFB $17,$80,$FF,$F0
        DEFB $4F,$A0,$FF,$F8
        DEFB $FF,$70,$FF,$FC
        DEFB $FE,$F8,$FF,$FC
        DEFB $FD,$F8,$FF,$FE
        DEFB $FD,$FC,$FF,$FF
        DEFB $F8,$FE,$FF,$FF
        DEFB $F0,$7E,$FD,$FF
        DEFB $E0,$3E,$F8,$FF
        DEFB $C0,$1F,$F0,$7F
        DEFB $80,$1F,$E0,$3F
        DEFB $00,$0F,$C0,$3F
        DEFB $00,$07,$00,$1F
        DEFB $00,$07,$00,$0F
        DEFB $00,$03,$00,$0F
        DEFB $00,$03,$00,$07
        DEFB $00,$01,$00,$07
PRINCE_RUN4:
        DEFB 2,42,0,0
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$FC
        DEFB $00,$78,$01,$FE
        DEFB $00,$FC,$03,$FE
        DEFB $01,$FC,$03,$FE
        DEFB $01,$FC,$03,$FF
        DEFB $00,$EE,$03,$FF
        DEFB $00,$7E,$01,$FF
        DEFB $00,$3C,$03,$FF
        DEFB $01,$88,$07,$FE
        DEFB $03,$20,$07,$FC
        DEFB $02,$50,$0F,$FC
        DEFB $07,$28,$0F,$FC
        DEFB $07,$90,$1F,$FC
        DEFB $0F,$A8,$1F,$FF
        DEFB $0F,$D5,$1F,$FF
        DEFB $0F,$CA,$3F,$FF
        DEFB $11,$E5,$3F,$FF
        DEFB $0E,$60,$3F,$FF
        DEFB $1F,$80,$7F,$F0
        DEFB $3F,$E0,$7F,$F8
        DEFB $3F,$F0,$7F,$FE
        DEFB $3F,$FC,$7F,$FF
        DEFB $1F,$FE,$7F,$FF
        DEFB $2F,$FF,$7F,$FF
        DEFB $31,$FF,$7F,$FF
        DEFB $3E,$7F,$7F,$FF
        DEFB $3F,$1F,$7F,$FF
        DEFB $3F,$1F,$7F,$FF
        DEFB $3F,$3E,$7F,$FF
        DEFB $3E,$3E,$7F,$FF
        DEFB $3E,$3C,$7F,$FF
        DEFB $3E,$78,$7F,$FE
        DEFB $3C,$78,$7F,$FC
        DEFB $3C,$F8,$7F,$FE
        DEFB $3C,$FC,$7F,$FE
        DEFB $3C,$00,$FF,$FE
        DEFB $78,$00,$FE,$00
        DEFB $78,$00,$FC,$00
        DEFB $78,$00,$FC,$00
PRINCE_JUMP:
        DEFB 2,42,0,0
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$FC
        DEFB $00,$78,$01,$FE
        DEFB $00,$FC,$03,$FE
        DEFB $01,$FC,$03,$FE
        DEFB $01,$FC,$03,$FF
        DEFB $00,$EE,$03,$FF
        DEFB $00,$7E,$01,$FF
        DEFB $00,$3C,$03,$FF
        DEFB $01,$80,$03,$FF
        DEFB $01,$2A,$07,$FF
        DEFB $03,$55,$0F,$FF
        DEFB $07,$2A,$0F,$FF
        DEFB $07,$80,$1F,$FF
        DEFB $0F,$FC,$1F,$FE
        DEFB $0F,$F8,$3F,$FE
        DEFB $1F,$F0,$3F,$FC
        DEFB $01,$F0,$3F,$F8
        DEFB $1E,$E0,$7F,$F8
        DEFB $3F,$40,$7F,$F0
        DEFB $3F,$80,$FF,$E0
        DEFB $BF,$C0,$FF,$F0
        DEFB $BF,$E0,$FF,$F8
        DEFB $DF,$F0,$FF,$FC
        DEFB $EF,$F8,$FF,$FC
        DEFB $F7,$F8,$FF,$FE
        DEFB $F3,$FC,$FF,$FF
        DEFB $C0,$FE,$FF,$FF
        DEFB $80,$7E,$E1,$FF
        DEFB $00,$3E,$C0,$FF
        DEFB $00,$1F,$00,$7F
        DEFB $00,$0F,$00,$3F
        DEFB $00,$0F,$00,$1F
        DEFB $00,$07,$00,$1F
        DEFB $00,$07,$00,$0F
        DEFB $00,$03,$00,$0F
        DEFB $00,$03,$00,$07
        DEFB $00,$01,$00,$07
PRINCE_HANG:
        DEFB 2,42,0,0
        DEFB $00,$A0,$01,$F0
        DEFB $00,$40,$01,$F0
        DEFB $00,$A0,$03,$F0
        DEFB $01,$40,$07,$F0
        DEFB $03,$E0,$0F,$F0
        DEFB $07,$E0,$1F,$F0
        DEFB $0F,$E0,$1F,$F0
        DEFB $0F,$E0,$1F,$F8
        DEFB $07,$F0,$1F,$F8
        DEFB $03,$F0,$0F,$F8
        DEFB $01,$E0,$07,$F8
        DEFB $01,$C0,$0F,$F0
        DEFB $07,$E0,$1F,$F8
        DEFB $0F,$F0,$1F,$F8
        DEFB $0F,$F0,$1F,$F8
        DEFB $0F,$F0,$1F,$F8
        DEFB $0F,$F0,$1F,$F8
        DEFB $0F,$F0,$1F,$F8
        DEFB $0F,$F0,$1F,$F8
        DEFB $0F,$F0,$1F,$F8
        DEFB $0E,$70,$1F,$F8
        DEFB $0D,$B0,$1F,$F8
        DEFB $0B,$D0,$1F,$F8
        DEFB $07,$E0,$1F,$F8
        DEFB $07,$E0,$0F,$F0
        DEFB $07,$E0,$0F,$F0
        DEFB $07,$E0,$0F,$F8
        DEFB $07,$F0,$0F,$F8
        DEFB $07,$F0,$0F,$F8
        DEFB $07,$F0,$1F,$F8
        DEFB $0B,$F0,$1F,$F8
        DEFB $0B,$F0,$1F,$F8
        DEFB $0B,$F0,$1F,$F8
        DEFB $0B,$F0,$1F,$F8
        DEFB $0B,$F0,$3F,$F8
        DEFB $1D,$F0,$3F,$F8
        DEFB $1D,$E0,$7F,$F8
        DEFB $3D,$E0,$7F,$F0
        DEFB $3D,$E0,$FF,$F0
        DEFB $7D,$E0,$FF,$F0
        DEFB $00,$00,$FF,$F0
        DEFB $00,$00,$00,$00
PRINCE_CLIMB1:
        DEFB 2,42,0,0
        DEFB $00,$08,$00,$3C
        DEFB $00,$10,$00,$7C
        DEFB $00,$28,$03,$FC
        DEFB $01,$90,$07,$FC
        DEFB $03,$20,$0F,$F8
        DEFB $07,$50,$0F,$F8
        DEFB $06,$A0,$0F,$FC
        DEFB $02,$48,$0F,$FC
        DEFB $00,$A8,$07,$FC
        DEFB $00,$40,$01,$FC
        DEFB $00,$A0,$03,$F0
        DEFB $01,$40,$0F,$F8
        DEFB $04,$90,$0F,$FC
        DEFB $05,$58,$0F,$FC
        DEFB $06,$38,$1F,$FC
        DEFB $0F,$F8,$1F,$FC
        DEFB $0F,$F0,$1F,$FC
        DEFB $0F,$F0,$1F,$F8
        DEFB $0F,$F0,$1F,$F8
        DEFB $0E,$F0,$1F,$F8
        DEFB $09,$30,$1F,$F8
        DEFB $07,$D0,$1F,$F8
        DEFB $0F,$E0,$1F,$F8
        DEFB $0F,$E0,$1F,$F0
        DEFB $0F,$E0,$1F,$F0
        DEFB $0F,$E0,$1F,$F0
        DEFB $0F,$E0,$1F,$F0
        DEFB $0F,$C0,$1F,$F0
        DEFB $0F,$C0,$1F,$E0
        DEFB $0F,$C0,$1F,$F8
        DEFB $0F,$D0,$1F,$F8
        DEFB $0F,$D0,$1F,$F8
        DEFB $0F,$D0,$1F,$F8
        DEFB $0F,$D0,$1F,$F8
        DEFB $0F,$B0,$1F,$F8
        DEFB $0F,$A0,$1F,$F8
        DEFB $0F,$40,$3F,$F0
        DEFB $1F,$00,$3F,$E0
        DEFB $00,$00,$3F,$80
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
PRINCE_CLIMB2:
        DEFB 2,42,0,0
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$FC
        DEFB $00,$78,$01,$FE
        DEFB $00,$FC,$03,$FE
        DEFB $01,$FC,$03,$FE
        DEFB $01,$FC,$03,$FF
        DEFB $00,$EE,$03,$FF
        DEFB $00,$7E,$01,$FF
        DEFB $00,$7C,$03,$FF
        DEFB $01,$98,$07,$FE
        DEFB $03,$40,$07,$FC
        DEFB $02,$A0,$0F,$F8
        DEFB $07,$50,$0F,$FC
        DEFB $07,$28,$0F,$FF
        DEFB $07,$95,$1F,$FF
        DEFB $0F,$CA,$1F,$FF
        DEFB $0F,$E5,$3F,$FF
        DEFB $19,$F2,$3F,$FF
        DEFB $16,$60,$3F,$FF
        DEFB $0F,$80,$3F,$F8
        DEFB $1F,$F0,$3F,$FF
        DEFB $1F,$FE,$3F,$FF
        DEFB $1F,$FF,$3F,$FF
        DEFB $1F,$FF,$7F,$FF
        DEFB $2F,$FF,$7F,$FF
        DEFB $31,$FF,$7F,$FF
        DEFB $3E,$0F,$7F,$FF
        DEFB $3F,$0F,$7F,$9F
        DEFB $3F,$0F,$7F,$9F
        DEFB $3F,$0F,$7F,$9F
        DEFB $3F,$0F,$7F,$9F
        DEFB $3F,$0E,$7F,$BF
        DEFB $3E,$1E,$7F,$BF
        DEFB $3E,$1F,$7F,$3F
        DEFB $3E,$1F,$7F,$3F
        DEFB $3C,$09,$7F,$3F
        DEFB $3C,$00,$7E,$1F
        DEFB $3C,$00,$7E,$00
        DEFB $38,$00,$7E,$00
PRINCE_GARDE:
        DEFB 3,42,0,0
        DEFB $00,$00,$00,$03,$F0,$00
        DEFB $01,$E0,$00,$07,$F8,$00
        DEFB $03,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$FC,$00
        DEFB $03,$B8,$00,$0F,$FC,$00
        DEFB $01,$F8,$00,$07,$FC,$00
        DEFB $01,$F0,$00,$03,$FC,$00
        DEFB $00,$20,$00,$03,$F8,$00
        DEFB $01,$40,$00,$0F,$F0,$00
        DEFB $04,$A0,$00,$0F,$FE,$0E
        DEFB $05,$54,$04,$0F,$FF,$FE
        DEFB $06,$2A,$AC,$0F,$FF,$FF
        DEFB $07,$95,$57,$0F,$FF,$FF
        DEFB $07,$E2,$AC,$0F,$FF,$FF
        DEFB $07,$F0,$00,$1F,$FF,$FE
        DEFB $0F,$F0,$00,$1F,$F8,$00
        DEFB $0E,$70,$00,$1F,$FC,$00
        DEFB $0D,$B8,$00,$1F,$FC,$00
        DEFB $0B,$D0,$00,$1F,$FC,$00
        DEFB $07,$E0,$00,$1F,$F8,$00
        DEFB $07,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$1F,$FC,$00
        DEFB $0B,$F8,$00,$1F,$FC,$00
        DEFB $0B,$F8,$00,$1F,$FC,$00
        DEFB $0D,$F8,$00,$3F,$FE,$00
        DEFB $1D,$FC,$00,$3F,$FE,$00
        DEFB $1E,$FC,$00,$3F,$FE,$00
        DEFB $1E,$FC,$00,$3F,$FF,$00
        DEFB $1F,$7E,$00,$3F,$FF,$00
        DEFB $1F,$7E,$00,$7F,$FF,$00
        DEFB $3F,$3E,$00,$7F,$FF,$00
        DEFB $3E,$3E,$00,$7F,$FF,$00
        DEFB $3C,$1E,$00,$FF,$7F,$00
        DEFB $7C,$1E,$00,$FE,$3F,$00
        DEFB $78,$1E,$00,$FE,$3F,$80
        DEFB $78,$0F,$00,$FC,$3F,$80
        DEFB $F0,$0F,$00,$FC,$1F,$80
        DEFB $E0,$07,$00,$FC,$1F,$F0
        DEFB $F8,$07,$E0,$FC,$0F,$F0
        DEFB $F8,$07,$E0,$FC,$0F,$F0
PRINCE_ADVANCE:
        DEFB 3,42,0,0
        DEFB $00,$00,$00,$00,$00,$00
        DEFB $00,$00,$00,$03,$F0,$00
        DEFB $01,$E0,$00,$07,$F8,$00
        DEFB $03,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$FC,$00
        DEFB $03,$B8,$00,$0F,$FC,$00
        DEFB $01,$F8,$00,$07,$FC,$00
        DEFB $00,$F0,$00,$03,$FC,$00
        DEFB $00,$00,$00,$07,$F8,$00
        DEFB $02,$40,$00,$0F,$FC,$00
        DEFB $04,$A8,$00,$0F,$FF,$8E
        DEFB $06,$55,$04,$0F,$FF,$FF
        DEFB $07,$2A,$AB,$0F,$FF,$FF
        DEFB $07,$85,$56,$0F,$FF,$FF
        DEFB $07,$F0,$02,$0F,$FF,$FF
        DEFB $07,$F8,$00,$0F,$FC,$07
        DEFB $07,$F8,$00,$0F,$FC,$00
        DEFB $06,$70,$00,$0F,$FC,$00
        DEFB $05,$B8,$00,$0F,$FC,$00
        DEFB $03,$D0,$00,$0F,$FC,$00
        DEFB $07,$E0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$FC,$00
        DEFB $07,$F8,$00,$1F,$FC,$00
        DEFB $0B,$F8,$00,$3F,$FE,$00
        DEFB $1D,$FC,$00,$3F,$FE,$00
        DEFB $1D,$FC,$00,$3F,$FF,$00
        DEFB $1E,$FE,$00,$3F,$FF,$00
        DEFB $1F,$7E,$00,$7F,$FF,$80
        DEFB $3F,$3F,$00,$7F,$FF,$80
        DEFB $3F,$3F,$00,$7F,$FF,$80
        DEFB $3E,$1F,$00,$FF,$FF,$80
        DEFB $7E,$0F,$00,$FF,$3F,$C0
        DEFB $7C,$0F,$80,$FF,$1F,$C0
        DEFB $F8,$07,$80,$FE,$1F,$C0
        DEFB $F0,$07,$80,$FC,$0F,$C0
        DEFB $F0,$03,$80,$F8,$0F,$E0
        DEFB $E0,$03,$C0,$F8,$07,$E0
        DEFB $C0,$01,$C0,$F0,$07,$FC
        DEFB $E0,$01,$F8,$F8,$03,$FC
        DEFB $F0,$00,$F8,$F8,$03,$FC
PRINCE_STRIKE1:
        DEFB 3,42,0,0
        DEFB $00,$00,$00,$01,$F8,$00
        DEFB $00,$F0,$00,$03,$FC,$00
        DEFB $01,$F8,$00,$07,$FC,$00
        DEFB $03,$F8,$00,$07,$FC,$00
        DEFB $03,$F8,$00,$07,$FE,$00
        DEFB $01,$DC,$00,$07,$FE,$03
        DEFB $00,$FC,$01,$03,$FE,$07
        DEFB $00,$78,$02,$01,$FE,$07
        DEFB $00,$10,$02,$00,$FC,$3F
        DEFB $00,$40,$1C,$07,$F8,$3F
        DEFB $02,$A0,$0C,$0F,$FE,$FE
        DEFB $06,$54,$54,$0F,$FF,$FE
        DEFB $07,$2A,$A0,$0F,$FF,$FE
        DEFB $07,$95,$40,$0F,$FF,$F0
        DEFB $07,$E2,$80,$0F,$FF,$E0
        DEFB $07,$F8,$00,$0F,$FF,$C0
        DEFB $07,$F8,$00,$0F,$FC,$00
        DEFB $06,$78,$00,$0F,$FC,$00
        DEFB $05,$B0,$00,$0F,$FC,$00
        DEFB $03,$D0,$00,$0F,$F8,$00
        DEFB $07,$E0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$1F,$FC,$00
        DEFB $0B,$F8,$00,$1F,$FC,$00
        DEFB $0B,$F8,$00,$1F,$FE,$00
        DEFB $0D,$FC,$00,$1F,$FE,$00
        DEFB $0D,$FC,$00,$3F,$FE,$00
        DEFB $1E,$FC,$00,$3F,$FF,$00
        DEFB $1F,$7E,$00,$3F,$FF,$00
        DEFB $1F,$7E,$00,$3F,$FF,$00
        DEFB $1F,$3E,$00,$3F,$FF,$00
        DEFB $1F,$3E,$00,$7F,$FF,$00
        DEFB $3E,$1E,$00,$7F,$FF,$00
        DEFB $3E,$1E,$00,$7F,$3F,$80
        DEFB $3C,$1F,$00,$FF,$3F,$80
        DEFB $7C,$0F,$00,$FE,$3F,$80
        DEFB $78,$0F,$00,$FE,$1F,$80
        DEFB $70,$07,$00,$FC,$1F,$80
        DEFB $F0,$07,$00,$FE,$0F,$F0
        DEFB $FC,$07,$E0,$FE,$0F,$F0
        DEFB $FC,$03,$E0,$FE,$0F,$F0
PRINCE_STRIKE2:
        DEFB 5,42,0,0
        DEFB $00,$00,$00,$00,$00,$00,$00,$00,$00,$00
        DEFB $00,$00,$00,$00,$00,$00,$00,$00,$00,$00
        DEFB $00,$00,$00,$00,$00,$00,$00,$00,$00,$00
        DEFB $00,$00,$00,$00,$00,$00,$00,$00,$00,$00
        DEFB $00,$00,$00,$00,$00,$00,$7E,$00,$00,$00
        DEFB $00,$3C,$00,$00,$00,$00,$FF,$00,$00,$00
        DEFB $00,$7E,$00,$00,$00,$01,$FF,$00,$00,$00
        DEFB $00,$FE,$00,$00,$00,$01,$FF,$00,$00,$00
        DEFB $00,$FE,$00,$00,$00,$01,$FF,$80,$00,$00
        DEFB $00,$77,$00,$00,$00,$01,$FF,$80,$00,$00
        DEFB $00,$3F,$00,$00,$00,$00,$FF,$80,$00,$00
        DEFB $00,$1E,$00,$00,$00,$00,$FF,$80,$00,$00
        DEFB $00,$40,$00,$00,$00,$01,$FF,$E1,$C0,$00
        DEFB $00,$95,$40,$80,$00,$03,$FF,$FF,$C0,$FF
        DEFB $01,$AA,$AA,$80,$7F,$03,$FF,$FF,$C0,$FF
        DEFB $01,$95,$55,$80,$00,$03,$FF,$FF,$C0,$FF
        DEFB $01,$C0,$00,$80,$00,$07,$FF,$FF,$C0,$00
        DEFB $03,$FE,$00,$00,$00,$07,$FF,$01,$C0,$00
        DEFB $03,$FC,$00,$00,$00,$07,$FF,$00,$00,$00
        DEFB $03,$FC,$00,$00,$00,$0F,$FE,$00,$00,$00
        DEFB $06,$7C,$00,$00,$00,$0F,$FE,$00,$00,$00
        DEFB $05,$98,$00,$00,$00,$0F,$FE,$00,$00,$00
        DEFB $03,$E8,$00,$00,$00,$0F,$FC,$00,$00,$00
        DEFB $07,$F0,$00,$00,$00,$3F,$FC,$00,$00,$00
        DEFB $17,$F8,$00,$00,$00,$7F,$FF,$00,$00,$00
        DEFB $37,$FE,$00,$00,$00,$FF,$FF,$80,$00,$00
        DEFB $77,$FF,$00,$00,$00,$FF,$FF,$C0,$00,$00
        DEFB $FB,$FF,$80,$00,$00,$FF,$FF,$E0,$00,$00
        DEFB $FC,$FF,$C0,$00,$00,$FF,$FF,$F0,$00,$00
        DEFB $FE,$3F,$E0,$00,$00,$FF,$FF,$F0,$00,$00
        DEFB $FC,$0F,$E0,$00,$00,$FF,$7F,$F0,$00,$00
        DEFB $F0,$03,$E0,$00,$00,$FE,$1F,$F0,$00,$00
        DEFB $E0,$03,$E0,$00,$00,$F8,$07,$F0,$00,$00
        DEFB $80,$01,$E0,$00,$00,$F0,$07,$F0,$00,$00
        DEFB $00,$01,$E0,$00,$00,$C0,$03,$F0,$00,$00
        DEFB $00,$01,$E0,$00,$00,$00,$03,$F0,$00,$00
        DEFB $00,$01,$E0,$00,$00,$00,$03,$F0,$00,$00
        DEFB $00,$00,$E0,$00,$00,$00,$03,$F0,$00,$00
        DEFB $00,$00,$E0,$00,$00,$00,$01,$FC,$00,$00
        DEFB $00,$00,$F8,$00,$00,$00,$01,$FE,$00,$00
        DEFB $00,$00,$FC,$00,$00,$00,$01,$FE,$00,$00
        DEFB $00,$00,$48,$00,$00,$00,$01,$FE,$00,$00
PRINCE_PARRY:
        DEFB 3,42,0,0
        DEFB $00,$00,$08,$03,$F0,$3C
        DEFB $01,$E0,$10,$07,$F8,$3C
        DEFB $03,$F0,$10,$0F,$F8,$38
        DEFB $07,$F0,$10,$0F,$F8,$38
        DEFB $07,$F0,$10,$0F,$FC,$38
        DEFB $03,$B8,$10,$0F,$FC,$38
        DEFB $01,$F8,$10,$07,$FC,$38
        DEFB $00,$F0,$10,$03,$FC,$38
        DEFB $01,$20,$10,$07,$F8,$38
        DEFB $02,$40,$10,$0F,$FC,$FC
        DEFB $04,$A8,$78,$0F,$FC,$FC
        DEFB $05,$50,$50,$0F,$FF,$FC
        DEFB $06,$AA,$A0,$0F,$FF,$F8
        DEFB $07,$15,$40,$0F,$FF,$F0
        DEFB $07,$CA,$00,$0F,$FF,$E0
        DEFB $07,$E4,$00,$1F,$FF,$00
        DEFB $0F,$F0,$00,$1F,$FE,$00
        DEFB $06,$70,$00,$1F,$F8,$00
        DEFB $05,$B0,$00,$1F,$F8,$00
        DEFB $0B,$D0,$00,$1F,$F8,$00
        DEFB $07,$E0,$00,$1F,$F8,$00
        DEFB $07,$E0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$1F,$F8,$00
        DEFB $0B,$F0,$00,$1F,$F8,$00
        DEFB $0B,$F0,$00,$1F,$FC,$00
        DEFB $0B,$F8,$00,$1F,$FC,$00
        DEFB $0D,$F8,$00,$1F,$FC,$00
        DEFB $0D,$F8,$00,$1F,$FC,$00
        DEFB $0E,$F8,$00,$1F,$FC,$00
        DEFB $0E,$F8,$00,$1F,$FC,$00
        DEFB $0E,$F8,$00,$3F,$FC,$00
        DEFB $1F,$78,$00,$3F,$FC,$00
        DEFB $1F,$78,$00,$3F,$FC,$00
        DEFB $1E,$78,$00,$3F,$FC,$00
        DEFB $1E,$78,$00,$7F,$FC,$00
        DEFB $3C,$78,$00,$7F,$FC,$00
        DEFB $3C,$38,$00,$7E,$FC,$00
        DEFB $3C,$38,$00,$7E,$7E,$00
        DEFB $3C,$3C,$00,$7F,$FF,$80
        DEFB $3F,$3F,$00,$7F,$FF,$80
PRINCE_HURT:
        DEFB 3,42,0,0
        DEFB $00,$00,$00,$1F,$80,$00
        DEFB $0F,$00,$00,$3F,$C0,$00
        DEFB $1F,$80,$00,$7F,$C0,$00
        DEFB $3F,$80,$00,$7F,$C0,$00
        DEFB $3F,$80,$00,$7F,$E0,$00
        DEFB $1D,$C0,$00,$7F,$E0,$00
        DEFB $0F,$C0,$00,$3F,$E0,$00
        DEFB $07,$80,$00,$1F,$E0,$00
        DEFB $00,$00,$00,$0F,$E0,$00
        DEFB $05,$40,$00,$3F,$F0,$00
        DEFB $12,$A0,$00,$3F,$F0,$00
        DEFB $15,$20,$00,$3F,$F0,$00
        DEFB $1A,$80,$00,$3F,$F0,$00
        DEFB $1D,$40,$00,$3F,$F0,$00
        DEFB $1E,$A0,$00,$3F,$F8,$00
        DEFB $1F,$50,$00,$3F,$FF,$00
        DEFB $0F,$AA,$00,$3F,$FF,$80
        DEFB $1E,$55,$00,$3F,$FF,$E0
        DEFB $0D,$A2,$C0,$3F,$FF,$E0
        DEFB $0B,$D1,$80,$1F,$FF,$E0
        DEFB $07,$E1,$40,$1F,$FB,$E0
        DEFB $07,$E0,$40,$0F,$F3,$F0
        DEFB $07,$E0,$20,$0F,$F8,$F8
        DEFB $07,$F0,$10,$0F,$F8,$7C
        DEFB $07,$F0,$18,$0F,$F8,$3C
        DEFB $07,$F0,$08,$1F,$F8,$3E
        DEFB $0B,$F0,$04,$1F,$F8,$1F
        DEFB $0B,$F0,$02,$3F,$F8,$0F
        DEFB $1B,$F0,$02,$3F,$F8,$07
        DEFB $1D,$F0,$01,$3F,$F8,$07
        DEFB $1D,$F0,$00,$3F,$F8,$03
        DEFB $1D,$F0,$00,$3F,$F8,$00
        DEFB $1D,$F0,$00,$3F,$F8,$00
        DEFB $1E,$F0,$00,$7F,$F8,$00
        DEFB $3E,$F0,$00,$7F,$F8,$00
        DEFB $3C,$F0,$00,$7F,$F8,$00
        DEFB $3C,$F0,$00,$FF,$F8,$00
        DEFB $78,$F0,$00,$FF,$F8,$00
        DEFB $78,$F0,$00,$FD,$F8,$00
        DEFB $70,$70,$00,$FF,$F8,$00
        DEFB $7C,$70,$00,$FF,$FE,$00
        DEFB $7E,$7C,$00,$FF,$FE,$00
PRINCE_DEAD:
        DEFB 5,16,248,26
        DEFB $00,$00,$00,$00,$00,$00,$00,$00,$00,$00
        DEFB $00,$00,$00,$00,$00,$00,$00,$00,$00,$00
        DEFB $00,$00,$00,$00,$00,$00,$01,$F8,$00,$00
        DEFB $00,$00,$F0,$00,$00,$00,$1F,$F8,$00,$00
        DEFB $00,$0F,$F0,$00,$00,$00,$3F,$F8,$00,$00
        DEFB $00,$1F,$E0,$00,$00,$E0,$3F,$F9,$E0,$00
        DEFB $40,$1E,$00,$C0,$00,$FF,$FF,$FB,$F0,$00
        DEFB $FF,$E1,$F1,$E0,$00,$FF,$FF,$FF,$F8,$00
        DEFB $FF,$FF,$F3,$F0,$00,$FF,$FF,$FF,$F8,$00
        DEFB $FF,$FF,$F7,$F0,$00,$FF,$FF,$FF,$F8,$00
        DEFB $FF,$E0,$0E,$F0,$00,$FF,$FF,$FF,$F8,$00
        DEFB $FF,$FF,$FF,$F0,$00,$FF,$FF,$FF,$F8,$00
        DEFB $FF,$FF,$F7,$E0,$00,$FF,$FF,$FF,$FB,$80
        DEFB $F8,$7F,$F3,$01,$00,$FF,$FF,$FF,$F3,$FF
        DEFB $00,$00,$00,$01,$FE,$FC,$FF,$FF,$83,$FF
        DEFB $00,$00,$00,$01,$00,$00,$00,$00,$03,$FF
PRINCE_RETREAT:
        DEFB 3,42,0,0
        DEFB $00,$00,$00,$07,$E0,$00
        DEFB $03,$C0,$00,$0F,$F0,$00
        DEFB $07,$E0,$00,$1F,$F0,$00
        DEFB $0F,$E0,$00,$1F,$F0,$00
        DEFB $0F,$E0,$00,$1F,$F8,$00
        DEFB $07,$70,$00,$1F,$F8,$00
        DEFB $03,$F0,$00,$0F,$F8,$00
        DEFB $03,$E0,$00,$07,$F8,$00
        DEFB $00,$40,$00,$07,$F0,$00
        DEFB $01,$20,$00,$1F,$F8,$00
        DEFB $0A,$90,$00,$1F,$F8,$00
        DEFB $09,$40,$00,$1F,$F8,$00
        DEFB $0C,$A0,$00,$1F,$F8,$00
        DEFB $0E,$50,$00,$1F,$FF,$F8
        DEFB $0F,$2A,$90,$3F,$FF,$FF
        DEFB $1F,$95,$5F,$3F,$FF,$FF
        DEFB $0F,$CA,$B0,$3F,$FF,$FF
        DEFB $0E,$70,$10,$1F,$FF,$F8
        DEFB $0D,$B0,$00,$1F,$F8,$38
        DEFB $0B,$D0,$00,$1F,$F8,$00
        DEFB $07,$E0,$00,$1F,$F8,$00
        DEFB $07,$E0,$00,$0F,$F0,$00
        DEFB $07,$E0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$3F,$F8,$00
        DEFB $17,$F0,$00,$3F,$F8,$00
        DEFB $17,$F0,$00,$7F,$F8,$00
        DEFB $3B,$F0,$00,$7F,$F8,$00
        DEFB $3B,$F0,$00,$7F,$F8,$00
        DEFB $3B,$F0,$00,$FF,$F8,$00
        DEFB $7B,$F0,$00,$FF,$F8,$00
        DEFB $7B,$F0,$00,$FF,$F8,$00
        DEFB $7D,$F0,$00,$FF,$F8,$00
        DEFB $F9,$F0,$00,$FF,$F8,$00
        DEFB $F9,$F0,$00,$FF,$F8,$00
        DEFB $F1,$E0,$00,$FF,$F8,$00
        DEFB $E1,$E0,$00,$FB,$F0,$00
        DEFB $C1,$E0,$00,$F3,$F0,$00
        DEFB $C1,$E0,$00,$E3,$F0,$00
        DEFB $81,$E0,$00,$F3,$F0,$00
        DEFB $E1,$E0,$00,$F3,$F0,$00
        DEFB $C1,$E0,$00,$F3,$FC,$00
        DEFB $00,$F8,$00,$E3,$FC,$00
PRINCE_DRAW1:
        DEFB 3,42,0,0
        DEFB $00,$00,$00,$03,$F0,$00
        DEFB $01,$E0,$00,$07,$F8,$00
        DEFB $03,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$FC,$00
        DEFB $03,$B8,$00,$0F,$FC,$00
        DEFB $01,$F8,$00,$07,$FC,$00
        DEFB $00,$F0,$00,$03,$FC,$00
        DEFB $01,$20,$00,$07,$F8,$00
        DEFB $02,$40,$00,$0F,$FC,$00
        DEFB $04,$98,$00,$0F,$FC,$00
        DEFB $05,$58,$00,$0F,$FC,$00
        DEFB $04,$98,$00,$0F,$FC,$00
        DEFB $05,$58,$00,$0F,$FC,$00
        DEFB $04,$98,$00,$0F,$FC,$00
        DEFB $01,$58,$00,$0F,$FC,$00
        DEFB $02,$80,$00,$0F,$FC,$00
        DEFB $05,$50,$00,$0F,$FC,$00
        DEFB $04,$A8,$00,$1F,$FE,$00
        DEFB $0B,$14,$00,$1F,$FF,$00
        DEFB $07,$CE,$00,$1F,$FF,$00
        DEFB $07,$EC,$00,$0F,$FF,$00
        DEFB $07,$F2,$00,$0F,$FF,$00
        DEFB $07,$F2,$00,$0F,$FF,$80
        DEFB $07,$F3,$00,$1F,$FF,$80
        DEFB $0B,$F1,$00,$1F,$FF,$80
        DEFB $0B,$F1,$00,$1F,$FB,$C0
        DEFB $0B,$F0,$80,$1F,$FF,$C0
        DEFB $0D,$F8,$80,$1F,$FD,$C0
        DEFB $0D,$F8,$80,$1F,$FD,$E0
        DEFB $0D,$F8,$40,$1F,$FD,$E0
        DEFB $0E,$F8,$00,$1F,$FC,$E0
        DEFB $0E,$F8,$00,$3F,$FC,$00
        DEFB $1E,$F8,$00,$3F,$FC,$00
        DEFB $1F,$78,$00,$3F,$FC,$00
        DEFB $1E,$78,$00,$3F,$FC,$00
        DEFB $1E,$78,$00,$3F,$FC,$00
        DEFB $1E,$78,$00,$7F,$FC,$00
        DEFB $3C,$78,$00,$7F,$FC,$00
        DEFB $3C,$38,$00,$7E,$FC,$00
        DEFB $3C,$38,$00,$7F,$FF,$80
        DEFB $3F,$3F,$00,$7F,$FF,$80
PRINCE_DRAW2:
        DEFB 3,42,0,0
        DEFB $00,$00,$00,$03,$F0,$00
        DEFB $01,$E0,$00,$07,$F8,$00
        DEFB $03,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$FC,$00
        DEFB $03,$B8,$00,$0F,$FC,$03
        DEFB $01,$F8,$01,$07,$FC,$07
        DEFB $00,$F0,$03,$03,$FC,$07
        DEFB $00,$20,$02,$07,$F8,$0F
        DEFB $02,$50,$04,$0F,$F8,$1F
        DEFB $04,$A0,$0C,$0F,$F8,$3E
        DEFB $06,$50,$18,$0F,$FC,$7E
        DEFB $07,$28,$2C,$0F,$FF,$FE
        DEFB $07,$95,$50,$0F,$FF,$FE
        DEFB $07,$CA,$A0,$0F,$FF,$F8
        DEFB $07,$E5,$00,$0F,$FF,$F0
        DEFB $07,$F8,$00,$0F,$FF,$80
        DEFB $06,$70,$00,$0F,$FC,$00
        DEFB $05,$B0,$00,$0F,$F8,$00
        DEFB $03,$D0,$00,$0F,$F8,$00
        DEFB $07,$E0,$00,$0F,$F8,$00
        DEFB $07,$E0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$1F,$F8,$00
        DEFB $0B,$F0,$00,$1F,$FC,$00
        DEFB $0B,$F8,$00,$1F,$FC,$00
        DEFB $0B,$F8,$00,$1F,$FC,$00
        DEFB $0D,$F8,$00,$1F,$FC,$00
        DEFB $0D,$F8,$00,$1F,$FE,$00
        DEFB $0E,$FC,$00,$3F,$FE,$00
        DEFB $1E,$FC,$00,$3F,$FE,$00
        DEFB $1F,$7C,$00,$3F,$FE,$00
        DEFB $1F,$7C,$00,$3F,$FE,$00
        DEFB $1F,$3C,$00,$3F,$FE,$00
        DEFB $1E,$3C,$00,$7F,$FE,$00
        DEFB $3E,$3C,$00,$7F,$7E,$00
        DEFB $3C,$3C,$00,$7F,$7E,$00
        DEFB $3C,$1C,$00,$7E,$7E,$00
        DEFB $38,$1C,$00,$FE,$3F,$00
        DEFB $78,$1E,$00,$FE,$3F,$80
        DEFB $7C,$1F,$00,$FF,$3F,$E0
        DEFB $7E,$0F,$C0,$FF,$3F,$E0
PRINCE_RUNSTART1:
        DEFB 2,42,0,0
        DEFB $00,$00,$03,$F0
        DEFB $01,$E0,$07,$F8
        DEFB $03,$F0,$0F,$F8
        DEFB $07,$F0,$0F,$F8
        DEFB $07,$F0,$0F,$FC
        DEFB $03,$B8,$0F,$FC
        DEFB $01,$F8,$07,$FC
        DEFB $00,$F0,$03,$FC
        DEFB $00,$20,$07,$F8
        DEFB $02,$40,$0F,$F8
        DEFB $04,$90,$0F,$FC
        DEFB $05,$48,$0F,$FC
        DEFB $04,$A8,$1F,$FC
        DEFB $0E,$48,$1F,$FC
        DEFB $0E,$A0,$1F,$FC
        DEFB $0E,$40,$1F,$F0
        DEFB $0E,$A0,$1F,$F8
        DEFB $0E,$50,$1F,$F8
        DEFB $09,$20,$1F,$F8
        DEFB $07,$50,$1F,$FC
        DEFB $0F,$A8,$1F,$FC
        DEFB $0F,$90,$1F,$FC
        DEFB $0F,$C8,$1F,$FC
        DEFB $0F,$E0,$1F,$FC
        DEFB $0F,$E0,$1F,$F0
        DEFB $07,$E0,$1F,$F0
        DEFB $07,$E0,$0F,$F0
        DEFB $07,$E0,$0F,$F0
        DEFB $07,$E0,$0F,$F0
        DEFB $07,$E0,$1F,$F0
        DEFB $0B,$E0,$1F,$F0
        DEFB $0B,$E0,$1F,$F0
        DEFB $0B,$E0,$1F,$F0
        DEFB $0B,$E0,$1F,$F0
        DEFB $0D,$E0,$1F,$F0
        DEFB $0D,$E0,$1F,$F0
        DEFB $0D,$E0,$1F,$F0
        DEFB $0D,$E0,$1F,$F0
        DEFB $0D,$E0,$1F,$F0
        DEFB $0D,$E0,$1F,$F0
        DEFB $0D,$E0,$1F,$FC
        DEFB $0D,$F8,$1F,$FC
PRINCE_RUNSTART2:
        DEFB 2,42,0,0
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$01,$F8
        DEFB $00,$F0,$03,$FC
        DEFB $01,$F8,$07,$FC
        DEFB $03,$F8,$07,$FC
        DEFB $03,$F8,$07,$FE
        DEFB $01,$DC,$07,$FE
        DEFB $00,$FC,$03,$FE
        DEFB $00,$F8,$03,$FE
        DEFB $01,$10,$07,$FC
        DEFB $02,$A0,$0F,$FC
        DEFB $05,$48,$0F,$FC
        DEFB $04,$98,$0F,$FC
        DEFB $01,$58,$0F,$FC
        DEFB $02,$B8,$0F,$FC
        DEFB $05,$30,$0F,$FC
        DEFB $02,$78,$0F,$FE
        DEFB $05,$74,$0F,$FF
        DEFB $02,$7A,$0F,$FF
        DEFB $05,$25,$0F,$FF
        DEFB $02,$42,$0F,$FF
        DEFB $05,$41,$3F,$E7
        DEFB $1A,$40,$3F,$E3
        DEFB $19,$40,$3F,$E0
        DEFB $1C,$C0,$3F,$F8
        DEFB $1F,$B0,$7F,$F8
        DEFB $3F,$B0,$7F,$F8
        DEFB $3F,$70,$7F,$FC
        DEFB $3F,$78,$7F,$FC
        DEFB $3E,$F8,$FF,$FC
        DEFB $7E,$F8,$FF,$FE
        DEFB $7E,$FC,$FF,$FE
        DEFB $7C,$FC,$FF,$FE
        DEFB $FC,$7C,$FF,$FE
        DEFB $F8,$7C,$FE,$FE
        DEFB $F0,$3C,$FC,$FE
        DEFB $E0,$3C,$F8,$7E
        DEFB $C0,$3C,$F0,$7E
        DEFB $80,$1C,$E0,$7F
        DEFB $80,$1E,$F0,$3F
        DEFB $E0,$1F,$F0,$3F
        DEFB $C0,$0F,$F0,$3F
PRINCE_RUNSTOP1:
        DEFB 2,42,0,0
        DEFB $00,$00,$0F,$C0
        DEFB $07,$80,$1F,$E0
        DEFB $0F,$C0,$3F,$E0
        DEFB $1F,$C0,$3F,$E0
        DEFB $1F,$C0,$3F,$F0
        DEFB $0E,$E0,$3F,$F0
        DEFB $07,$E0,$1F,$F0
        DEFB $03,$C0,$0F,$F0
        DEFB $04,$80,$0F,$E0
        DEFB $01,$40,$0F,$F0
        DEFB $02,$A0,$3F,$F0
        DEFB $15,$20,$3F,$F0
        DEFB $12,$60,$3F,$F0
        DEFB $15,$60,$3F,$F0
        DEFB $02,$60,$3F,$F8
        DEFB $05,$70,$1F,$F8
        DEFB $0A,$F0,$1F,$F8
        DEFB $04,$70,$1F,$F8
        DEFB $02,$B0,$0F,$F8
        DEFB $04,$D0,$0F,$F8
        DEFB $02,$60,$0F,$F8
        DEFB $05,$60,$0F,$FC
        DEFB $02,$68,$0F,$FC
        DEFB $00,$E0,$1F,$FC
        DEFB $0D,$E0,$1F,$F0
        DEFB $0F,$E0,$1F,$FC
        DEFB $0F,$E8,$1F,$FC
        DEFB $0F,$D8,$1F,$FC
        DEFB $0F,$D8,$1F,$FC
        DEFB $0F,$D8,$1F,$FE
        DEFB $0F,$DC,$1F,$FE
        DEFB $0F,$DC,$1F,$FE
        DEFB $0F,$BC,$1F,$FE
        DEFB $0F,$BC,$1F,$FE
        DEFB $0F,$BC,$1F,$FE
        DEFB $0F,$BC,$1F,$FE
        DEFB $0F,$3C,$1F,$FE
        DEFB $0F,$1C,$1F,$FF
        DEFB $0F,$1E,$1F,$BF
        DEFB $0F,$1E,$1F,$BF
        DEFB $0E,$0F,$1F,$FF
        DEFB $0F,$CF,$1F,$FF
PRINCE_RUNSTOP2:
        DEFB 2,42,0,0
        DEFB $00,$00,$07,$E0
        DEFB $03,$C0,$0F,$F0
        DEFB $07,$E0,$1F,$F0
        DEFB $0F,$E0,$1F,$F0
        DEFB $0F,$E0,$1F,$F8
        DEFB $07,$70,$1F,$F8
        DEFB $03,$F0,$0F,$F8
        DEFB $01,$E0,$07,$F8
        DEFB $02,$40,$0F,$F0
        DEFB $05,$20,$1F,$F8
        DEFB $0A,$90,$1F,$F8
        DEFB $09,$50,$1F,$F8
        DEFB $0A,$90,$1F,$F8
        DEFB $09,$50,$1F,$F8
        DEFB $0A,$90,$1F,$F8
        DEFB $0D,$50,$1F,$F8
        DEFB $0C,$90,$1F,$F8
        DEFB $0D,$50,$1F,$F8
        DEFB $0C,$90,$1F,$F8
        DEFB $0A,$50,$1F,$F8
        DEFB $06,$A0,$1F,$F8
        DEFB $06,$40,$0F,$F0
        DEFB $06,$A0,$0F,$F0
        DEFB $07,$40,$0F,$F0
        DEFB $07,$80,$0F,$F0
        DEFB $07,$E0,$0F,$F0
        DEFB $07,$E0,$0F,$F0
        DEFB $07,$E0,$0F,$F0
        DEFB $07,$E0,$0F,$F0
        DEFB $03,$E0,$0F,$F0
        DEFB $03,$E0,$07,$F0
        DEFB $03,$E0,$07,$F0
        DEFB $03,$E0,$07,$F0
        DEFB $03,$E0,$07,$F0
        DEFB $03,$E0,$0F,$F0
        DEFB $05,$E0,$0F,$F0
        DEFB $05,$E0,$0F,$F0
        DEFB $05,$E0,$0F,$F0
        DEFB $05,$E0,$0F,$F0
        DEFB $05,$E0,$0F,$F0
        DEFB $05,$E0,$0F,$FC
        DEFB $06,$F8,$0F,$FC
PRINCE_TURN1:
        DEFB 2,42,0,0
        DEFB $00,$00,$07,$E0
        DEFB $03,$C0,$0F,$F0
        DEFB $07,$E0,$1F,$F0
        DEFB $0F,$E0,$1F,$F0
        DEFB $0F,$E0,$1F,$F8
        DEFB $07,$70,$1F,$F8
        DEFB $03,$F0,$0F,$F8
        DEFB $01,$E0,$07,$F8
        DEFB $00,$40,$0F,$F0
        DEFB $05,$20,$1F,$F8
        DEFB $0A,$90,$1F,$F8
        DEFB $09,$50,$1F,$F8
        DEFB $0C,$90,$1F,$F8
        DEFB $0D,$50,$1F,$F8
        DEFB $0C,$90,$1F,$F8
        DEFB $0D,$50,$1F,$F8
        DEFB $0C,$90,$1F,$F8
        DEFB $0D,$50,$1F,$F8
        DEFB $0C,$A0,$1F,$F8
        DEFB $0A,$40,$1F,$F0
        DEFB $06,$A0,$1F,$F0
        DEFB $07,$40,$0F,$F0
        DEFB $07,$20,$0F,$F0
        DEFB $07,$80,$0F,$F0
        DEFB $07,$C0,$0F,$F0
        DEFB $07,$E0,$0F,$F0
        DEFB $07,$E0,$0F,$F0
        DEFB $07,$E0,$0F,$F0
        DEFB $07,$E0,$0F,$F0
        DEFB $03,$E0,$0F,$F0
        DEFB $03,$E0,$07,$F0
        DEFB $03,$E0,$07,$F0
        DEFB $03,$E0,$07,$F0
        DEFB $03,$E0,$07,$F0
        DEFB $03,$E0,$0F,$F0
        DEFB $05,$E0,$0F,$F0
        DEFB $05,$E0,$0F,$F0
        DEFB $05,$E0,$0F,$F0
        DEFB $05,$E0,$0F,$F0
        DEFB $05,$E0,$0F,$F0
        DEFB $05,$E0,$0F,$FC
        DEFB $06,$F8,$0F,$FC
PRINCE_TURN2:
        DEFB 2,42,0,0
        DEFB $00,$00,$07,$F0
        DEFB $03,$E0,$0F,$F8
        DEFB $07,$F0,$1F,$FC
        DEFB $0F,$F8,$1F,$FC
        DEFB $0F,$F8,$1F,$FC
        DEFB $06,$B0,$1F,$FC
        DEFB $07,$F0,$0F,$F8
        DEFB $03,$E0,$0F,$F8
        DEFB $03,$C0,$1F,$F8
        DEFB $0B,$D0,$3F,$FC
        DEFB $1F,$F8,$3F,$FC
        DEFB $1D,$B8,$7F,$FE
        DEFB $3D,$BC,$7F,$FE
        DEFB $3B,$DC,$7F,$FE
        DEFB $3B,$DC,$7F,$FE
        DEFB $3B,$DC,$7F,$FE
        DEFB $37,$EC,$7F,$FE
        DEFB $37,$EC,$7F,$FE
        DEFB $37,$EC,$7F,$FE
        DEFB $37,$EC,$7F,$FE
        DEFB $37,$EC,$7F,$FE
        DEFB $35,$EC,$7F,$FE
        DEFB $35,$EC,$7F,$FE
        DEFB $0D,$F0,$7F,$FE
        DEFB $1D,$F8,$3F,$FC
        DEFB $1E,$F8,$3F,$FC
        DEFB $1E,$F8,$3F,$FC
        DEFB $1E,$F8,$3F,$FC
        DEFB $1E,$F8,$3F,$FC
        DEFB $1E,$F8,$3F,$FC
        DEFB $1E,$F8,$3F,$FC
        DEFB $1E,$F8,$3F,$FC
        DEFB $1E,$F8,$3F,$FC
        DEFB $1E,$F8,$3F,$FC
        DEFB $1E,$F8,$3F,$FC
        DEFB $1E,$78,$3F,$FC
        DEFB $1E,$78,$3F,$FC
        DEFB $1E,$78,$3F,$FC
        DEFB $1E,$78,$3F,$FC
        DEFB $1E,$78,$3F,$FC
        DEFB $0E,$70,$3F,$FC
        DEFB $1E,$78,$3F,$FC
PRINCE_TURN3:
        DEFB 2,42,0,0
        DEFB $00,$00,$07,$E0
        DEFB $03,$C0,$0F,$F0
        DEFB $07,$E0,$1F,$F0
        DEFB $0F,$E0,$1F,$F0
        DEFB $0F,$E0,$1F,$F8
        DEFB $07,$70,$1F,$F8
        DEFB $03,$F0,$0F,$F8
        DEFB $01,$E0,$07,$F8
        DEFB $00,$40,$0F,$F0
        DEFB $05,$20,$1F,$F8
        DEFB $0A,$90,$1F,$F8
        DEFB $09,$50,$1F,$F8
        DEFB $0C,$90,$1F,$F8
        DEFB $0D,$50,$1F,$F8
        DEFB $0C,$90,$1F,$F8
        DEFB $0D,$50,$1F,$F8
        DEFB $0C,$90,$1F,$F8
        DEFB $0D,$50,$1F,$F8
        DEFB $0C,$90,$1F,$F8
        DEFB $0A,$40,$1F,$F8
        DEFB $06,$A0,$1F,$F0
        DEFB $06,$40,$0F,$F0
        DEFB $07,$20,$0F,$F0
        DEFB $07,$40,$0F,$F0
        DEFB $07,$80,$0F,$F0
        DEFB $07,$E0,$0F,$F0
        DEFB $07,$E0,$0F,$F0
        DEFB $07,$E0,$0F,$F0
        DEFB $07,$E0,$0F,$F0
        DEFB $07,$E0,$0F,$F0
        DEFB $03,$E0,$0F,$F0
        DEFB $03,$E0,$07,$F0
        DEFB $03,$E0,$07,$F0
        DEFB $03,$E0,$07,$F0
        DEFB $03,$E0,$07,$F0
        DEFB $03,$E0,$0F,$F0
        DEFB $05,$E0,$0F,$F0
        DEFB $01,$C0,$0F,$F0
        DEFB $01,$C0,$03,$E0
        DEFB $01,$C0,$03,$E0
        DEFB $01,$C0,$03,$FC
        DEFB $01,$F8,$03,$FC
PRINCE_CROUCH:
        DEFB 2,42,0,0
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$03,$F0
        DEFB $01,$E0,$07,$F8
        DEFB $03,$F0,$0F,$F8
        DEFB $07,$F0,$0F,$F8
        DEFB $07,$F0,$0F,$FC
        DEFB $03,$B8,$0F,$FC
        DEFB $01,$F8,$07,$FC
        DEFB $00,$F0,$07,$FC
        DEFB $02,$20,$0F,$F8
        DEFB $04,$80,$1F,$F0
        DEFB $0D,$40,$1F,$F0
        DEFB $0C,$A0,$1F,$F8
        DEFB $0E,$50,$3F,$FC
        DEFB $1F,$28,$3F,$FF
        DEFB $1F,$95,$7F,$FF
        DEFB $3F,$CA,$7F,$FF
        DEFB $37,$C5,$FF,$FF
        DEFB $48,$48,$FF,$FF
        DEFB $3F,$81,$FF,$FF
        DEFB $7F,$F8,$FF,$FF
        DEFB $7F,$FF,$FF,$FF
        DEFB $7F,$FF,$FF,$FF
        DEFB $7F,$FF,$FF,$FF
        DEFB $3F,$FF,$FF,$FF
        DEFB $00,$FF,$7F,$FF
        DEFB $00,$1F,$01,$FF
        DEFB $00,$1E,$00,$3F
        DEFB $00,$1E,$00,$3F
        DEFB $00,$1E,$00,$7F
        DEFB $00,$3C,$00,$7F
        DEFB $00,$3C,$00,$7E
PRINCE_LAND:
        DEFB 2,42,0,0
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$FC
        DEFB $00,$78,$01,$FE
        DEFB $00,$FC,$03,$FE
        DEFB $01,$FC,$03,$FE
        DEFB $01,$FC,$03,$FF
        DEFB $00,$EE,$03,$FF
        DEFB $00,$7E,$01,$FF
        DEFB $00,$7C,$01,$FF
        DEFB $00,$88,$07,$FE
        DEFB $03,$50,$07,$FC
        DEFB $02,$A8,$0F,$FE
        DEFB $07,$54,$0F,$FF
        DEFB $07,$AA,$0F,$FF
        DEFB $07,$D5,$1F,$FF
        DEFB $0F,$E2,$1F,$FF
        DEFB $0F,$F1,$3F,$FF
        DEFB $19,$F0,$3F,$FB
        DEFB $06,$E0,$3F,$F8
        DEFB $1F,$60,$3F,$F0
        DEFB $1F,$80,$7F,$F0
        DEFB $3F,$C0,$7F,$F0
        DEFB $1F,$E0,$7F,$F8
        DEFB $1F,$F0,$3F,$FC
        DEFB $0F,$F8,$3F,$FE
        DEFB $07,$FC,$1F,$FF
        DEFB $03,$FE,$0F,$FF
        DEFB $01,$FE,$07,$FF
        DEFB $00,$7F,$03,$FF
        DEFB $00,$BF,$01,$FF
        DEFB $00,$BE,$01,$FF
        DEFB $00,$BC,$01,$FF
        DEFB $00,$7C,$03,$FE
        DEFB $01,$78,$03,$FE
        DEFB $01,$78,$07,$FC
        DEFB $02,$F0,$07,$FC
        DEFB $02,$E0,$07,$F8
PRINCE_JWIND:
        DEFB 2,42,0,0
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$01,$F8
        DEFB $00,$F0,$03,$FC
        DEFB $01,$F8,$07,$FC
        DEFB $03,$F8,$07,$FC
        DEFB $03,$F8,$07,$FE
        DEFB $01,$DC,$07,$FE
        DEFB $00,$FC,$03,$FE
        DEFB $00,$78,$03,$FE
        DEFB $01,$30,$0F,$FC
        DEFB $06,$50,$0F,$F8
        DEFB $04,$A0,$0F,$FC
        DEFB $01,$48,$1F,$FC
        DEFB $0A,$98,$1F,$FC
        DEFB $05,$38,$1F,$FC
        DEFB $0A,$70,$1F,$FC
        DEFB $04,$F0,$7F,$F8
        DEFB $2A,$E0,$7F,$F8
        DEFB $14,$C0,$7F,$F0
        DEFB $09,$40,$FF,$E0
        DEFB $55,$80,$FF,$F0
        DEFB $49,$E0,$FF,$FC
        DEFB $53,$F8,$FF,$FF
        DEFB $0B,$FE,$FF,$FF
        DEFB $07,$FF,$1F,$FF
        DEFB $07,$FF,$0F,$FF
        DEFB $00,$FF,$0F,$FF
        DEFB $00,$3F,$01,$FF
        DEFB $00,$1E,$00,$7F
        DEFB $00,$3E,$00,$7F
        DEFB $00,$3C,$00,$7F
        DEFB $00,$3C,$00,$7E
        DEFB $00,$38,$00,$FE
        DEFB $00,$78,$00,$FC
        DEFB $00,$78,$00,$FC
PRINCE_JRISE:
        DEFB 2,42,0,0
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$01,$F8
        DEFB $00,$F0,$03,$FC
        DEFB $01,$F8,$07,$FC
        DEFB $03,$F8,$07,$FC
        DEFB $03,$F8,$07,$FF
        DEFB $01,$D9,$07,$FF
        DEFB $00,$E2,$03,$FF
        DEFB $00,$15,$03,$FF
        DEFB $01,$2A,$07,$FF
        DEFB $02,$54,$07,$FF
        DEFB $02,$A0,$0F,$FE
        DEFB $07,$4C,$0F,$FE
        DEFB $07,$9C,$0F,$FE
        DEFB $07,$F8,$1F,$FE
        DEFB $0F,$F8,$1F,$FC
        DEFB $0F,$F0,$1F,$FC
        DEFB $0D,$F0,$3F,$F8
        DEFB $12,$60,$3F,$F8
        DEFB $0F,$A0,$3F,$F0
        DEFB $1F,$80,$3F,$F0
        DEFB $1F,$C0,$3F,$F0
        DEFB $1F,$E0,$3F,$F8
        DEFB $1F,$F0,$FF,$F8
        DEFB $6F,$F0,$FF,$FC
        DEFB $77,$F8,$FF,$FE
        DEFB $7B,$FC,$FF,$FE
        DEFB $FD,$FC,$FF,$FF
        DEFB $FC,$FE,$FF,$FF
        DEFB $FC,$7E,$FF,$FF
        DEFB $F8,$3E,$FE,$FF
        DEFB $F0,$3E,$FC,$7F
        DEFB $F0,$3C,$F8,$7F
        DEFB $C0,$3C,$F8,$7E
        DEFB $80,$3C,$E0,$FE
        DEFB $00,$78,$C0,$FE
        DEFB $00,$78,$00,$FC
        DEFB $00,$78,$00,$FC
        DEFB $00,$78,$00,$FF
        DEFB $00,$7E,$00,$FF
        DEFB $00,$2E,$00,$FF
PRINCE_JAPEX:
        DEFB 2,42,0,0
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$03,$FC
        DEFB $01,$F8,$07,$FC
        DEFB $03,$F8,$07,$FC
        DEFB $03,$F8,$07,$FE
        DEFB $01,$DC,$07,$FE
        DEFB $00,$FC,$03,$FE
        DEFB $00,$78,$01,$FF
        DEFB $00,$02,$03,$FF
        DEFB $01,$55,$07,$FF
        DEFB $02,$AA,$0F,$FF
        DEFB $06,$54,$0F,$FF
        DEFB $07,$02,$0F,$FF
        DEFB $07,$BD,$0F,$FF
        DEFB $07,$F8,$1F,$FF
        DEFB $0F,$F8,$1F,$FC
        DEFB $0F,$F0,$1F,$FC
        DEFB $0D,$F0,$1F,$F8
        DEFB $02,$60,$1F,$F8
        DEFB $0F,$80,$3F,$F0
        DEFB $1F,$E0,$3F,$FC
        DEFB $1F,$F8,$3F,$FF
        DEFB $1F,$FE,$3F,$FF
        DEFB $0F,$FF,$3F,$FF
        DEFB $07,$FF,$1F,$FF
        DEFB $01,$FF,$0F,$FF
        DEFB $00,$3F,$03,$FF
        DEFB $00,$5F,$00,$FF
        DEFB $00,$1F,$00,$FF
        DEFB $00,$3E,$00,$FF
        DEFB $00,$7C,$01,$FF
        DEFB $00,$F8,$01,$FE
        DEFB $00,$F0,$03,$FC
        DEFB $01,$F8,$0F,$FC
        DEFB $06,$F8,$0F,$FC
        DEFB $03,$20,$0F,$FC
PRINCE_JFALL:
        DEFB 2,42,0,0
        DEFB $00,$00,$03,$F0
        DEFB $01,$E0,$07,$F8
        DEFB $03,$F0,$0F,$F8
        DEFB $07,$F0,$0F,$F8
        DEFB $07,$F0,$0F,$FC
        DEFB $03,$B8,$0F,$FC
        DEFB $01,$F8,$07,$FC
        DEFB $00,$F0,$03,$FC
        DEFB $00,$00,$03,$F8
        DEFB $01,$40,$0F,$FC
        DEFB $04,$A8,$0F,$FF
        DEFB $05,$55,$7F,$FF
        DEFB $2E,$2A,$FF,$FF
        DEFB $5F,$81,$FF,$FF
        DEFB $2F,$F0,$FF,$FB
        DEFB $5F,$F0,$FF,$F8
        DEFB $8F,$F0,$FF,$F8
        DEFB $0E,$F0,$DF,$F8
        DEFB $09,$30,$1F,$F8
        DEFB $07,$D0,$1F,$F8
        DEFB $0F,$E0,$1F,$F8
        DEFB $0F,$E0,$1F,$F8
        DEFB $0F,$F0,$1F,$F8
        DEFB $07,$F0,$1F,$FC
        DEFB $07,$F8,$1F,$FC
        DEFB $0B,$F8,$3F,$FE
        DEFB $1D,$FC,$3F,$FE
        DEFB $1D,$FC,$3F,$FF
        DEFB $1E,$FE,$3F,$FF
        DEFB $1F,$7E,$3F,$FF
        DEFB $1F,$7E,$3F,$FF
        DEFB $1F,$3E,$7F,$FF
        DEFB $3F,$3C,$FF,$FF
        DEFB $7E,$3C,$FF,$FE
        DEFB $7C,$7C,$FF,$FE
        DEFB $F8,$78,$FE,$FE
        DEFB $F0,$78,$FC,$FC
        DEFB $E0,$78,$F8,$FC
        DEFB $C0,$70,$F8,$FC
        DEFB $F0,$78,$F8,$FE
        DEFB $F0,$7C,$F8,$FE
        DEFB $00,$6C,$F8,$FE
PRINCE_FALL:
        DEFB 2,42,0,0
        DEFB $00,$2A,$00,$FF
        DEFB $00,$44,$07,$FF
        DEFB $03,$E8,$0F,$FE
        DEFB $07,$F4,$1F,$FE
        DEFB $0F,$E8,$1F,$FE
        DEFB $0F,$F0,$1F,$FC
        DEFB $07,$F8,$1F,$FC
        DEFB $03,$F0,$0F,$FC
        DEFB $01,$E0,$07,$F8
        DEFB $01,$C0,$0F,$F0
        DEFB $07,$E0,$1F,$F8
        DEFB $0F,$F0,$1F,$F8
        DEFB $0F,$F0,$1F,$F8
        DEFB $0F,$F0,$1F,$F8
        DEFB $0F,$F0,$1F,$F8
        DEFB $0F,$F0,$1F,$F8
        DEFB $0F,$F0,$1F,$F8
        DEFB $0F,$F0,$1F,$F8
        DEFB $0E,$70,$1F,$F8
        DEFB $0D,$B0,$1F,$F8
        DEFB $0B,$D0,$1F,$F8
        DEFB $07,$E0,$1F,$F8
        DEFB $07,$E0,$0F,$F0
        DEFB $07,$E0,$0F,$F0
        DEFB $07,$E0,$0F,$F0
        DEFB $07,$E0,$0F,$F0
        DEFB $07,$E0,$0F,$F0
        DEFB $07,$E0,$0F,$F0
        DEFB $03,$E0,$0F,$F0
        DEFB $03,$E0,$07,$F0
        DEFB $03,$E0,$07,$F0
        DEFB $03,$E0,$07,$F0
        DEFB $03,$E0,$07,$F0
        DEFB $03,$E0,$1F,$F0
        DEFB $0D,$E0,$1F,$F0
        DEFB $0D,$E0,$1F,$F0
        DEFB $0D,$E0,$1F,$F0
        DEFB $0D,$E0,$1F,$F0
        DEFB $0D,$E0,$1F,$F0
        DEFB $0D,$E0,$1F,$F0
        DEFB $0D,$E0,$1F,$F0
        DEFB $0D,$E0,$1F,$F0
PRINCE_JUMPUP:
        DEFB 2,42,0,0
        DEFB $00,$A0,$03,$F8
        DEFB $01,$50,$07,$F8
        DEFB $03,$E0,$0F,$F8
        DEFB $07,$E0,$1F,$F0
        DEFB $0F,$E0,$1F,$F0
        DEFB $0F,$E0,$1F,$F8
        DEFB $07,$F0,$1F,$F8
        DEFB $03,$F0,$0F,$F8
        DEFB $01,$E0,$07,$F8
        DEFB $01,$C0,$0F,$F0
        DEFB $07,$E0,$1F,$F8
        DEFB $0F,$F0,$1F,$F8
        DEFB $0F,$F0,$1F,$F8
        DEFB $0F,$F0,$1F,$F8
        DEFB $0F,$F0,$1F,$F8
        DEFB $0F,$F0,$1F,$F8
        DEFB $0F,$F0,$1F,$F8
        DEFB $0F,$F0,$1F,$F8
        DEFB $0E,$70,$1F,$F8
        DEFB $0D,$B0,$1F,$F8
        DEFB $0B,$D0,$1F,$F8
        DEFB $07,$E0,$1F,$F8
        DEFB $07,$E0,$0F,$F0
        DEFB $07,$E0,$0F,$F8
        DEFB $07,$F0,$0F,$F8
        DEFB $07,$F0,$0F,$F8
        DEFB $07,$F0,$1F,$F8
        DEFB $0B,$F0,$1F,$F8
        DEFB $0B,$F0,$1F,$F8
        DEFB $0B,$F0,$1F,$F8
        DEFB $0B,$F0,$1F,$F8
        DEFB $0B,$F0,$1F,$F8
        DEFB $0D,$F0,$1F,$F8
        DEFB $0D,$F0,$3F,$F8
        DEFB $1B,$E0,$3F,$F8
        DEFB $1B,$E0,$7F,$F0
        DEFB $3B,$C0,$7F,$F0
        DEFB $37,$C0,$7F,$E0
        DEFB $37,$80,$FF,$E0
        DEFB $77,$80,$FF,$C0
        DEFB $6F,$00,$FF,$C0
        DEFB $EF,$80,$FF,$C0
PRINCE_CLIMB3:
        DEFB 2,42,0,0
        DEFB $00,$00,$00,$00
        DEFB $00,$00,$01,$F8
        DEFB $00,$F0,$03,$FC
        DEFB $01,$F8,$07,$FC
        DEFB $03,$F8,$07,$FC
        DEFB $03,$F8,$07,$FE
        DEFB $01,$DC,$07,$FE
        DEFB $00,$FC,$03,$FE
        DEFB $00,$78,$01,$FE
        DEFB $00,$30,$07,$FC
        DEFB $02,$80,$0F,$F8
        DEFB $06,$40,$0F,$F0
        DEFB $06,$A0,$0F,$F8
        DEFB $06,$50,$0F,$FC
        DEFB $07,$28,$1F,$FF
        DEFB $0F,$D5,$1F,$FF
        DEFB $0F,$EA,$1F,$FF
        DEFB $0F,$F4,$1F,$FF
        DEFB $0D,$F8,$1F,$FF
        DEFB $02,$61,$1F,$FF
        DEFB $0F,$A0,$1F,$F3
        DEFB $0F,$C0,$3F,$F0
        DEFB $1F,$C0,$3F,$F0
        DEFB $1F,$E0,$3F,$F8
        DEFB $0F,$F0,$3F,$F8
        DEFB $17,$F0,$3F,$FC
        DEFB $17,$F8,$3F,$FC
        DEFB $1B,$F8,$3F,$FE
        DEFB $1D,$FC,$3F,$FE
        DEFB $1E,$FC,$3F,$FF
        DEFB $1F,$7E,$7F,$FF
        DEFB $3F,$7E,$7F,$FF
        DEFB $3F,$3C,$7F,$FF
        DEFB $3F,$7C,$7F,$FE
        DEFB $3E,$7C,$7F,$FE
        DEFB $3C,$78,$7F,$FE
        DEFB $3C,$78,$7F,$FC
        DEFB $3C,$F0,$FF,$FC
        DEFB $78,$F0,$FF,$F8
        DEFB $78,$E0,$FD,$FC
        DEFB $78,$F8,$FD,$FE
        DEFB $78,$FC,$FD,$FE
PRINCE_SWSTEPA:
        DEFB 3,42,0,0
        DEFB $00,$00,$00,$03,$F0,$00
        DEFB $01,$E0,$00,$07,$F8,$00
        DEFB $03,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$FC,$00
        DEFB $03,$B8,$00,$0F,$FC,$00
        DEFB $01,$F8,$00,$07,$FC,$00
        DEFB $01,$F0,$00,$03,$FC,$00
        DEFB $00,$20,$00,$03,$F8,$00
        DEFB $01,$40,$00,$0F,$F0,$00
        DEFB $04,$A0,$00,$0F,$FE,$0E
        DEFB $05,$54,$04,$0F,$FF,$FF
        DEFB $06,$2A,$AD,$0F,$FF,$FF
        DEFB $07,$85,$54,$0F,$FF,$FF
        DEFB $07,$F0,$04,$0F,$FF,$FE
        DEFB $07,$F0,$00,$1F,$F8,$0E
        DEFB $0F,$F0,$00,$1F,$F8,$00
        DEFB $0E,$70,$00,$1F,$FC,$00
        DEFB $0D,$B8,$00,$1F,$FC,$00
        DEFB $0B,$D0,$00,$1F,$FC,$00
        DEFB $07,$E0,$00,$1F,$F8,$00
        DEFB $07,$E0,$00,$0F,$F0,$00
        DEFB $07,$E0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$F8,$00
        DEFB $03,$F0,$00,$0F,$F8,$00
        DEFB $03,$F0,$00,$07,$F8,$00
        DEFB $03,$F0,$00,$07,$F8,$00
        DEFB $03,$F0,$00,$0F,$F8,$00
        DEFB $05,$F0,$00,$0F,$F8,$00
        DEFB $05,$F0,$00,$0F,$FC,$00
        DEFB $05,$F8,$00,$0F,$FC,$00
        DEFB $05,$F0,$00,$1F,$FC,$00
        DEFB $0E,$F0,$00,$1F,$F8,$00
        DEFB $0E,$F0,$00,$1F,$F8,$00
        DEFB $0E,$F0,$00,$1F,$F8,$00
        DEFB $0E,$F0,$00,$1F,$F8,$00
        DEFB $0E,$F0,$00,$1F,$F8,$00
        DEFB $0E,$F0,$00,$1F,$F8,$00
        DEFB $0E,$70,$00,$1F,$F8,$00
        DEFB $0E,$70,$00,$1F,$FE,$00
        DEFB $0F,$7C,$00,$1F,$FE,$00
PRINCE_SWSTEPB:
        DEFB 3,42,0,0
        DEFB $00,$00,$00,$03,$F0,$00
        DEFB $01,$E0,$00,$07,$F8,$00
        DEFB $03,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$FC,$00
        DEFB $03,$B8,$00,$0F,$FC,$00
        DEFB $01,$F8,$00,$07,$FC,$00
        DEFB $00,$F0,$00,$03,$FC,$00
        DEFB $01,$20,$00,$07,$F8,$00
        DEFB $02,$40,$00,$0F,$F0,$00
        DEFB $04,$A0,$00,$0F,$FE,$0E
        DEFB $05,$54,$04,$0F,$FF,$FE
        DEFB $06,$2A,$AC,$0F,$FF,$FF
        DEFB $07,$85,$57,$0F,$FF,$FF
        DEFB $07,$F2,$0C,$0F,$FF,$FF
        DEFB $07,$F8,$00,$1F,$FF,$1E
        DEFB $0F,$F0,$00,$1F,$FC,$00
        DEFB $06,$70,$00,$1F,$FC,$00
        DEFB $05,$B8,$00,$1F,$FC,$00
        DEFB $0B,$D0,$00,$1F,$FC,$00
        DEFB $07,$E0,$00,$1F,$F8,$00
        DEFB $07,$E0,$00,$0F,$F0,$00
        DEFB $07,$E0,$00,$0F,$F0,$00
        DEFB $07,$E0,$00,$1F,$F0,$00
        DEFB $0F,$E0,$00,$1F,$F0,$00
        DEFB $0F,$E0,$00,$1F,$F0,$00
        DEFB $0F,$E0,$00,$1F,$F8,$00
        DEFB $0F,$D0,$00,$1F,$F8,$00
        DEFB $0F,$D0,$00,$1F,$F8,$00
        DEFB $0F,$D0,$00,$1F,$F8,$00
        DEFB $0F,$D0,$00,$1F,$F8,$00
        DEFB $0F,$D0,$00,$1F,$F8,$00
        DEFB $0F,$B0,$00,$1F,$F8,$00
        DEFB $0F,$A0,$00,$1F,$F8,$00
        DEFB $0F,$A0,$00,$1F,$F0,$00
        DEFB $0F,$60,$00,$1F,$F0,$00
        DEFB $0F,$60,$00,$1F,$F0,$00
        DEFB $0F,$60,$00,$1F,$F0,$00
        DEFB $0E,$C0,$00,$1F,$F0,$00
        DEFB $0E,$C0,$00,$1F,$E0,$00
        DEFB $0E,$C0,$00,$3F,$F8,$00
        DEFB $1F,$F0,$00,$3F,$F8,$00
GUARD_GARDE:
        DEFB 3,42,0,0
        DEFB $00,$00,$00,$03,$F0,$00
        DEFB $01,$E0,$00,$07,$F8,$00
        DEFB $03,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$FC,$00
        DEFB $03,$B8,$00,$0F,$FC,$00
        DEFB $01,$F8,$00,$07,$FC,$00
        DEFB $01,$F0,$00,$03,$FC,$00
        DEFB $00,$20,$00,$03,$F8,$00
        DEFB $01,$40,$00,$0F,$F0,$00
        DEFB $00,$A0,$00,$0F,$FE,$0E
        DEFB $05,$54,$04,$0F,$FF,$FE
        DEFB $02,$2A,$AC,$0F,$FF,$FF
        DEFB $05,$15,$57,$0F,$FF,$FF
        DEFB $02,$A2,$AC,$0F,$FF,$FF
        DEFB $05,$50,$00,$1F,$FF,$FE
        DEFB $0A,$A0,$00,$1F,$F8,$00
        DEFB $04,$50,$00,$1F,$FC,$00
        DEFB $08,$A8,$00,$1F,$FC,$00
        DEFB $01,$50,$00,$1F,$FC,$00
        DEFB $02,$A0,$00,$1F,$F8,$00
        DEFB $05,$50,$00,$0F,$F8,$00
        DEFB $02,$A0,$00,$0F,$F8,$00
        DEFB $05,$50,$00,$1F,$FC,$00
        DEFB $0A,$A8,$00,$1F,$FC,$00
        DEFB $01,$50,$00,$1F,$FC,$00
        DEFB $08,$A8,$00,$3F,$FE,$00
        DEFB $15,$54,$00,$3F,$FE,$00
        DEFB $0A,$AC,$00,$3F,$FE,$00
        DEFB $14,$54,$00,$3F,$FF,$00
        DEFB $0A,$2E,$00,$3F,$FF,$00
        DEFB $15,$56,$00,$7F,$FF,$00
        DEFB $2A,$2E,$00,$7F,$FF,$00
        DEFB $14,$16,$00,$7F,$FF,$00
        DEFB $28,$0E,$00,$FF,$7F,$00
        DEFB $54,$16,$00,$FE,$3F,$00
        DEFB $28,$0E,$00,$FE,$3F,$80
        DEFB $50,$07,$00,$FC,$3F,$80
        DEFB $A0,$0F,$00,$FC,$1F,$80
        DEFB $40,$07,$00,$FC,$1F,$F0
        DEFB $A8,$07,$E0,$FC,$0F,$F0
        DEFB $50,$07,$E0,$FC,$0F,$F0
GUARD_ADVANCE:
        DEFB 3,42,0,0
        DEFB $00,$00,$00,$00,$00,$00
        DEFB $00,$00,$00,$03,$F0,$00
        DEFB $01,$E0,$00,$07,$F8,$00
        DEFB $03,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$FC,$00
        DEFB $03,$B8,$00,$0F,$FC,$00
        DEFB $01,$F8,$00,$07,$FC,$00
        DEFB $00,$F0,$00,$03,$FC,$00
        DEFB $00,$00,$00,$07,$F8,$00
        DEFB $02,$00,$00,$0F,$FC,$00
        DEFB $04,$00,$00,$0F,$FF,$8E
        DEFB $02,$05,$04,$0F,$FF,$FF
        DEFB $05,$02,$AB,$0F,$FF,$FF
        DEFB $02,$85,$56,$0F,$FF,$FF
        DEFB $05,$50,$02,$0F,$FF,$FF
        DEFB $02,$A8,$00,$0F,$FC,$07
        DEFB $05,$50,$00,$0F,$FC,$00
        DEFB $02,$20,$00,$0F,$FC,$00
        DEFB $05,$10,$00,$0F,$FC,$00
        DEFB $02,$80,$00,$0F,$FC,$00
        DEFB $05,$40,$00,$0F,$F8,$00
        DEFB $02,$A0,$00,$0F,$F8,$00
        DEFB $05,$50,$00,$0F,$FC,$00
        DEFB $02,$A8,$00,$1F,$FC,$00
        DEFB $01,$50,$00,$3F,$FE,$00
        DEFB $08,$AC,$00,$3F,$FE,$00
        DEFB $15,$54,$00,$3F,$FF,$00
        DEFB $0A,$AE,$00,$3F,$FF,$00
        DEFB $15,$56,$00,$7F,$FF,$80
        DEFB $2A,$2F,$00,$7F,$FF,$80
        DEFB $15,$17,$00,$7F,$FF,$80
        DEFB $2A,$0F,$00,$FF,$FF,$80
        DEFB $54,$07,$00,$FF,$3F,$C0
        DEFB $28,$0F,$80,$FF,$1F,$C0
        DEFB $50,$07,$80,$FE,$1F,$C0
        DEFB $A0,$07,$80,$FC,$0F,$C0
        DEFB $50,$03,$80,$F8,$0F,$E0
        DEFB $A0,$03,$C0,$F8,$07,$E0
        DEFB $40,$01,$C0,$F0,$07,$FC
        DEFB $A0,$01,$F8,$F8,$03,$FC
        DEFB $50,$00,$F8,$F8,$03,$FC
GUARD_STRIKE1:
        DEFB 3,42,0,0
        DEFB $00,$00,$00,$01,$F8,$00
        DEFB $00,$F0,$00,$03,$FC,$00
        DEFB $01,$F8,$00,$07,$FC,$00
        DEFB $03,$F8,$00,$07,$FC,$00
        DEFB $03,$F8,$00,$07,$FE,$00
        DEFB $01,$DC,$00,$07,$FE,$03
        DEFB $00,$FC,$01,$03,$FE,$07
        DEFB $00,$78,$02,$01,$FE,$07
        DEFB $00,$10,$02,$00,$FC,$3F
        DEFB $00,$40,$1C,$07,$F8,$3F
        DEFB $02,$A0,$0C,$0F,$FE,$FE
        DEFB $04,$54,$54,$0F,$FF,$FE
        DEFB $02,$2A,$A0,$0F,$FF,$FE
        DEFB $05,$15,$40,$0F,$FF,$F0
        DEFB $02,$A2,$80,$0F,$FF,$E0
        DEFB $05,$50,$00,$0F,$FF,$C0
        DEFB $02,$A8,$00,$0F,$FC,$00
        DEFB $04,$50,$00,$0F,$FC,$00
        DEFB $00,$A0,$00,$0F,$FC,$00
        DEFB $01,$50,$00,$0F,$F8,$00
        DEFB $02,$A0,$00,$0F,$F8,$00
        DEFB $05,$50,$00,$0F,$F8,$00
        DEFB $02,$A0,$00,$0F,$F8,$00
        DEFB $05,$50,$00,$1F,$FC,$00
        DEFB $0A,$A8,$00,$1F,$FC,$00
        DEFB $01,$50,$00,$1F,$FE,$00
        DEFB $08,$AC,$00,$1F,$FE,$00
        DEFB $05,$54,$00,$3F,$FE,$00
        DEFB $0A,$AC,$00,$3F,$FF,$00
        DEFB $15,$56,$00,$3F,$FF,$00
        DEFB $0A,$2E,$00,$3F,$FF,$00
        DEFB $15,$16,$00,$3F,$FF,$00
        DEFB $0A,$2E,$00,$7F,$FF,$00
        DEFB $14,$16,$00,$7F,$FF,$00
        DEFB $2A,$0E,$00,$7F,$3F,$80
        DEFB $14,$17,$00,$FF,$3F,$80
        DEFB $28,$0F,$00,$FE,$3F,$80
        DEFB $50,$07,$00,$FE,$1F,$80
        DEFB $20,$07,$00,$FC,$1F,$80
        DEFB $50,$07,$00,$FE,$0F,$F0
        DEFB $A8,$07,$E0,$FE,$0F,$F0
        DEFB $54,$03,$E0,$FE,$0F,$F0
GUARD_STRIKE2:
        DEFB 5,42,0,0
        DEFB $00,$00,$00,$00,$00,$00,$00,$00,$00,$00
        DEFB $00,$00,$00,$00,$00,$00,$00,$00,$00,$00
        DEFB $00,$00,$00,$00,$00,$00,$00,$00,$00,$00
        DEFB $00,$00,$00,$00,$00,$00,$00,$00,$00,$00
        DEFB $00,$00,$00,$00,$00,$00,$7E,$00,$00,$00
        DEFB $00,$3C,$00,$00,$00,$00,$FF,$00,$00,$00
        DEFB $00,$7E,$00,$00,$00,$01,$FF,$00,$00,$00
        DEFB $00,$FE,$00,$00,$00,$01,$FF,$00,$00,$00
        DEFB $00,$FE,$00,$00,$00,$01,$FF,$80,$00,$00
        DEFB $00,$57,$00,$00,$00,$01,$FF,$80,$00,$00
        DEFB $00,$2F,$00,$00,$00,$00,$FF,$80,$00,$00
        DEFB $00,$16,$00,$00,$00,$00,$FF,$80,$00,$00
        DEFB $00,$00,$00,$00,$00,$01,$FF,$E1,$C0,$00
        DEFB $00,$15,$40,$80,$00,$03,$FF,$FF,$C0,$FF
        DEFB $00,$AA,$AA,$80,$7F,$03,$FF,$FF,$C0,$FF
        DEFB $01,$15,$55,$80,$00,$03,$FF,$FF,$C0,$FF
        DEFB $00,$80,$00,$80,$00,$07,$FF,$FF,$C0,$00
        DEFB $01,$56,$00,$00,$00,$07,$FF,$01,$C0,$00
        DEFB $02,$AC,$00,$00,$00,$07,$FF,$00,$00,$00
        DEFB $01,$54,$00,$00,$00,$0F,$FE,$00,$00,$00
        DEFB $02,$2C,$00,$00,$00,$0F,$FE,$00,$00,$00
        DEFB $05,$10,$00,$00,$00,$0F,$FE,$00,$00,$00
        DEFB $02,$A8,$00,$00,$00,$0F,$FC,$00,$00,$00
        DEFB $05,$50,$00,$00,$00,$3F,$FC,$00,$00,$00
        DEFB $02,$A8,$00,$00,$00,$7F,$FF,$00,$00,$00
        DEFB $15,$56,$00,$00,$00,$FF,$FF,$80,$00,$00
        DEFB $22,$AF,$00,$00,$00,$FF,$FF,$C0,$00,$00
        DEFB $51,$57,$80,$00,$00,$FF,$FF,$E0,$00,$00
        DEFB $A8,$AF,$C0,$00,$00,$FF,$FF,$F0,$00,$00
        DEFB $54,$17,$E0,$00,$00,$FF,$FF,$F0,$00,$00
        DEFB $A8,$0F,$E0,$00,$00,$FF,$7F,$F0,$00,$00
        DEFB $50,$03,$E0,$00,$00,$FE,$1F,$F0,$00,$00
        DEFB $A0,$03,$E0,$00,$00,$F8,$07,$F0,$00,$00
        DEFB $00,$01,$E0,$00,$00,$F0,$07,$F0,$00,$00
        DEFB $00,$01,$E0,$00,$00,$C0,$03,$F0,$00,$00
        DEFB $00,$01,$E0,$00,$00,$00,$03,$F0,$00,$00
        DEFB $00,$01,$E0,$00,$00,$00,$03,$F0,$00,$00
        DEFB $00,$00,$E0,$00,$00,$00,$03,$F0,$00,$00
        DEFB $00,$00,$E0,$00,$00,$00,$01,$FC,$00,$00
        DEFB $00,$00,$F8,$00,$00,$00,$01,$FE,$00,$00
        DEFB $00,$00,$FC,$00,$00,$00,$01,$FE,$00,$00
        DEFB $00,$00,$48,$00,$00,$00,$01,$FE,$00,$00
GUARD_PARRY:
        DEFB 3,42,0,0
        DEFB $00,$00,$08,$03,$F0,$3C
        DEFB $01,$E0,$10,$07,$F8,$3C
        DEFB $03,$F0,$10,$0F,$F8,$38
        DEFB $07,$F0,$10,$0F,$F8,$38
        DEFB $07,$F0,$10,$0F,$FC,$38
        DEFB $03,$B8,$10,$0F,$FC,$38
        DEFB $01,$F8,$10,$07,$FC,$38
        DEFB $00,$F0,$10,$03,$FC,$38
        DEFB $01,$20,$10,$07,$F8,$38
        DEFB $00,$40,$10,$0F,$FC,$FC
        DEFB $00,$A8,$78,$0F,$FC,$FC
        DEFB $05,$50,$50,$0F,$FF,$FC
        DEFB $02,$AA,$A0,$0F,$FF,$F8
        DEFB $05,$15,$40,$0F,$FF,$F0
        DEFB $02,$8A,$00,$0F,$FF,$E0
        DEFB $05,$44,$00,$1F,$FF,$00
        DEFB $0A,$A0,$00,$1F,$FE,$00
        DEFB $04,$50,$00,$1F,$F8,$00
        DEFB $00,$A0,$00,$1F,$F8,$00
        DEFB $01,$50,$00,$1F,$F8,$00
        DEFB $02,$A0,$00,$1F,$F8,$00
        DEFB $05,$40,$00,$0F,$F8,$00
        DEFB $02,$A0,$00,$0F,$F8,$00
        DEFB $05,$50,$00,$0F,$F8,$00
        DEFB $02,$A0,$00,$1F,$F8,$00
        DEFB $01,$50,$00,$1F,$F8,$00
        DEFB $0A,$A0,$00,$1F,$FC,$00
        DEFB $01,$50,$00,$1F,$FC,$00
        DEFB $08,$A8,$00,$1F,$FC,$00
        DEFB $05,$50,$00,$1F,$FC,$00
        DEFB $0A,$A8,$00,$1F,$FC,$00
        DEFB $04,$50,$00,$1F,$FC,$00
        DEFB $0A,$A8,$00,$3F,$FC,$00
        DEFB $15,$50,$00,$3F,$FC,$00
        DEFB $0A,$28,$00,$3F,$FC,$00
        DEFB $14,$50,$00,$3F,$FC,$00
        DEFB $0A,$28,$00,$7F,$FC,$00
        DEFB $14,$50,$00,$7F,$FC,$00
        DEFB $28,$28,$00,$7E,$FC,$00
        DEFB $14,$10,$00,$7E,$7E,$00
        DEFB $28,$2C,$00,$7F,$FF,$80
        DEFB $15,$17,$00,$7F,$FF,$80
GUARD_HURT:
        DEFB 3,42,0,0
        DEFB $00,$00,$00,$1F,$80,$00
        DEFB $0F,$00,$00,$3F,$C0,$00
        DEFB $1F,$80,$00,$7F,$C0,$00
        DEFB $3F,$80,$00,$7F,$C0,$00
        DEFB $3F,$80,$00,$7F,$E0,$00
        DEFB $1D,$C0,$00,$7F,$E0,$00
        DEFB $0F,$C0,$00,$3F,$E0,$00
        DEFB $07,$80,$00,$1F,$E0,$00
        DEFB $00,$00,$00,$0F,$E0,$00
        DEFB $05,$40,$00,$3F,$F0,$00
        DEFB $02,$A0,$00,$3F,$F0,$00
        DEFB $15,$00,$00,$3F,$F0,$00
        DEFB $0A,$80,$00,$3F,$F0,$00
        DEFB $15,$40,$00,$3F,$F0,$00
        DEFB $0A,$A0,$00,$3F,$F8,$00
        DEFB $15,$50,$00,$3F,$FF,$00
        DEFB $0A,$AA,$00,$3F,$FF,$80
        DEFB $14,$55,$00,$3F,$FF,$E0
        DEFB $08,$A2,$C0,$3F,$FF,$E0
        DEFB $01,$51,$80,$1F,$FF,$E0
        DEFB $02,$A1,$40,$1F,$FB,$E0
        DEFB $05,$40,$40,$0F,$F3,$F0
        DEFB $02,$A0,$20,$0F,$F8,$F8
        DEFB $05,$50,$10,$0F,$F8,$7C
        DEFB $02,$A0,$18,$0F,$F8,$3C
        DEFB $05,$50,$08,$1F,$F8,$3E
        DEFB $0A,$A0,$04,$1F,$F8,$1F
        DEFB $01,$50,$02,$3F,$F8,$0F
        DEFB $0A,$A0,$02,$3F,$F8,$07
        DEFB $15,$50,$01,$3F,$F8,$07
        DEFB $08,$A0,$00,$3F,$F8,$03
        DEFB $15,$50,$00,$3F,$F8,$00
        DEFB $08,$A0,$00,$3F,$F8,$00
        DEFB $14,$50,$00,$7F,$F8,$00
        DEFB $2A,$A0,$00,$7F,$F8,$00
        DEFB $14,$50,$00,$7F,$F8,$00
        DEFB $28,$A0,$00,$FF,$F8,$00
        DEFB $50,$50,$00,$FF,$F8,$00
        DEFB $28,$A0,$00,$FD,$F8,$00
        DEFB $50,$50,$00,$FF,$F8,$00
        DEFB $28,$20,$00,$FF,$FE,$00
        DEFB $54,$54,$00,$FF,$FE,$00
GUARD_DEAD:
        DEFB 5,16,248,26
        DEFB $00,$00,$00,$00,$00,$00,$00,$00,$00,$00
        DEFB $00,$00,$00,$00,$00,$00,$00,$00,$00,$00
        DEFB $00,$00,$00,$00,$00,$00,$01,$F8,$00,$00
        DEFB $00,$00,$F0,$00,$00,$00,$1F,$F8,$00,$00
        DEFB $00,$0F,$F0,$00,$00,$00,$3F,$F8,$00,$00
        DEFB $00,$1F,$E0,$00,$00,$E0,$3F,$F9,$E0,$00
        DEFB $40,$1E,$00,$C0,$00,$FF,$FF,$FB,$F0,$00
        DEFB $FF,$E1,$F1,$E0,$00,$FF,$FF,$FF,$F8,$00
        DEFB $FF,$FF,$F3,$F0,$00,$FF,$FF,$FF,$F8,$00
        DEFB $55,$57,$F7,$F0,$00,$FF,$FF,$FF,$F8,$00
        DEFB $AA,$A0,$0E,$F0,$00,$FF,$FF,$FF,$F8,$00
        DEFB $55,$57,$FF,$F0,$00,$FF,$FF,$FF,$F8,$00
        DEFB $AA,$AF,$F7,$E0,$00,$FF,$FF,$FF,$FB,$80
        DEFB $50,$57,$F3,$01,$00,$FF,$FF,$FF,$F3,$FF
        DEFB $00,$00,$00,$01,$FE,$FC,$FF,$FF,$83,$FF
        DEFB $00,$00,$00,$01,$00,$00,$00,$00,$03,$FF
GUARD_RETREAT:
        DEFB 3,42,0,0
        DEFB $00,$00,$00,$07,$E0,$00
        DEFB $03,$C0,$00,$0F,$F0,$00
        DEFB $07,$E0,$00,$1F,$F0,$00
        DEFB $0F,$E0,$00,$1F,$F0,$00
        DEFB $0F,$E0,$00,$1F,$F8,$00
        DEFB $07,$70,$00,$1F,$F8,$00
        DEFB $03,$F0,$00,$0F,$F8,$00
        DEFB $03,$E0,$00,$07,$F8,$00
        DEFB $00,$40,$00,$07,$F0,$00
        DEFB $01,$00,$00,$1F,$F8,$00
        DEFB $0A,$80,$00,$1F,$F8,$00
        DEFB $01,$40,$00,$1F,$F8,$00
        DEFB $08,$A0,$00,$1F,$F8,$00
        DEFB $04,$50,$00,$1F,$FF,$F8
        DEFB $0A,$2A,$90,$3F,$FF,$FF
        DEFB $15,$15,$5F,$3F,$FF,$FF
        DEFB $0A,$8A,$B0,$3F,$FF,$FF
        DEFB $04,$50,$10,$1F,$FF,$F8
        DEFB $08,$A0,$00,$1F,$F8,$38
        DEFB $01,$50,$00,$1F,$F8,$00
        DEFB $02,$A0,$00,$1F,$F8,$00
        DEFB $05,$40,$00,$0F,$F0,$00
        DEFB $02,$A0,$00,$0F,$F8,$00
        DEFB $05,$50,$00,$3F,$F8,$00
        DEFB $02,$A0,$00,$3F,$F8,$00
        DEFB $15,$50,$00,$7F,$F8,$00
        DEFB $2A,$A0,$00,$7F,$F8,$00
        DEFB $11,$50,$00,$7F,$F8,$00
        DEFB $2A,$A0,$00,$FF,$F8,$00
        DEFB $51,$50,$00,$FF,$F8,$00
        DEFB $2A,$A0,$00,$FF,$F8,$00
        DEFB $55,$50,$00,$FF,$F8,$00
        DEFB $A8,$A0,$00,$FF,$F8,$00
        DEFB $51,$50,$00,$FF,$F8,$00
        DEFB $A0,$A0,$00,$FF,$F8,$00
        DEFB $41,$40,$00,$FB,$F0,$00
        DEFB $80,$A0,$00,$F3,$F0,$00
        DEFB $41,$40,$00,$E3,$F0,$00
        DEFB $80,$A0,$00,$F3,$F0,$00
        DEFB $41,$40,$00,$F3,$F0,$00
        DEFB $80,$A0,$00,$F3,$FC,$00
        DEFB $00,$50,$00,$E3,$FC,$00
GUARD_DRAW1:
        DEFB 3,42,0,0
        DEFB $00,$00,$00,$03,$F0,$00
        DEFB $01,$E0,$00,$07,$F8,$00
        DEFB $03,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$FC,$00
        DEFB $03,$B8,$00,$0F,$FC,$00
        DEFB $01,$F8,$00,$07,$FC,$00
        DEFB $00,$F0,$00,$03,$FC,$00
        DEFB $01,$20,$00,$07,$F8,$00
        DEFB $00,$40,$00,$0F,$FC,$00
        DEFB $00,$88,$00,$0F,$FC,$00
        DEFB $05,$50,$00,$0F,$FC,$00
        DEFB $00,$88,$00,$0F,$FC,$00
        DEFB $05,$50,$00,$0F,$FC,$00
        DEFB $00,$88,$00,$0F,$FC,$00
        DEFB $01,$50,$00,$0F,$FC,$00
        DEFB $02,$80,$00,$0F,$FC,$00
        DEFB $05,$50,$00,$0F,$FC,$00
        DEFB $00,$A8,$00,$1F,$FE,$00
        DEFB $01,$14,$00,$1F,$FF,$00
        DEFB $02,$8E,$00,$1F,$FF,$00
        DEFB $05,$44,$00,$0F,$FF,$00
        DEFB $02,$A2,$00,$0F,$FF,$00
        DEFB $05,$52,$00,$0F,$FF,$80
        DEFB $02,$A3,$00,$1F,$FF,$80
        DEFB $01,$51,$00,$1F,$FF,$80
        DEFB $0A,$A1,$00,$1F,$FB,$C0
        DEFB $01,$50,$80,$1F,$FF,$C0
        DEFB $08,$A8,$80,$1F,$FD,$C0
        DEFB $05,$50,$80,$1F,$FD,$E0
        DEFB $08,$A8,$40,$1F,$FD,$E0
        DEFB $04,$50,$00,$1F,$FC,$E0
        DEFB $0A,$A8,$00,$3F,$FC,$00
        DEFB $14,$50,$00,$3F,$FC,$00
        DEFB $0A,$28,$00,$3F,$FC,$00
        DEFB $14,$50,$00,$3F,$FC,$00
        DEFB $0A,$28,$00,$3F,$FC,$00
        DEFB $14,$50,$00,$7F,$FC,$00
        DEFB $28,$28,$00,$7F,$FC,$00
        DEFB $14,$10,$00,$7E,$FC,$00
        DEFB $28,$28,$00,$7F,$FF,$80
        DEFB $15,$17,$00,$7F,$FF,$80
GUARD_DRAW2:
        DEFB 3,42,0,0
        DEFB $00,$00,$00,$03,$F0,$00
        DEFB $01,$E0,$00,$07,$F8,$00
        DEFB $03,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$FC,$00
        DEFB $03,$B8,$00,$0F,$FC,$03
        DEFB $01,$F8,$01,$07,$FC,$07
        DEFB $00,$F0,$03,$03,$FC,$07
        DEFB $00,$20,$02,$07,$F8,$0F
        DEFB $00,$50,$04,$0F,$F8,$1F
        DEFB $00,$A0,$0C,$0F,$F8,$3E
        DEFB $04,$50,$18,$0F,$FC,$7E
        DEFB $02,$28,$2C,$0F,$FF,$FE
        DEFB $05,$15,$50,$0F,$FF,$FE
        DEFB $02,$8A,$A0,$0F,$FF,$F8
        DEFB $05,$45,$00,$0F,$FF,$F0
        DEFB $02,$A8,$00,$0F,$FF,$80
        DEFB $04,$50,$00,$0F,$FC,$00
        DEFB $00,$A0,$00,$0F,$F8,$00
        DEFB $01,$50,$00,$0F,$F8,$00
        DEFB $02,$A0,$00,$0F,$F8,$00
        DEFB $05,$40,$00,$0F,$F8,$00
        DEFB $02,$A0,$00,$0F,$F8,$00
        DEFB $05,$50,$00,$1F,$F8,$00
        DEFB $0A,$A0,$00,$1F,$FC,$00
        DEFB $01,$50,$00,$1F,$FC,$00
        DEFB $0A,$A8,$00,$1F,$FC,$00
        DEFB $05,$50,$00,$1F,$FC,$00
        DEFB $08,$A8,$00,$1F,$FE,$00
        DEFB $04,$54,$00,$3F,$FE,$00
        DEFB $0A,$AC,$00,$3F,$FE,$00
        DEFB $15,$54,$00,$3F,$FE,$00
        DEFB $0A,$2C,$00,$3F,$FE,$00
        DEFB $15,$14,$00,$3F,$FE,$00
        DEFB $0A,$2C,$00,$7F,$FE,$00
        DEFB $14,$14,$00,$7F,$7E,$00
        DEFB $28,$2C,$00,$7F,$7E,$00
        DEFB $14,$14,$00,$7E,$7E,$00
        DEFB $28,$0C,$00,$FE,$3F,$00
        DEFB $50,$16,$00,$FE,$3F,$80
        DEFB $28,$0F,$00,$FF,$3F,$E0
        DEFB $54,$07,$C0,$FF,$3F,$E0
GUARD_SWSTEPA:
        DEFB 3,42,0,0
        DEFB $00,$00,$00,$03,$F0,$00
        DEFB $01,$E0,$00,$07,$F8,$00
        DEFB $03,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$FC,$00
        DEFB $03,$B8,$00,$0F,$FC,$00
        DEFB $01,$F8,$00,$07,$FC,$00
        DEFB $01,$F0,$00,$03,$FC,$00
        DEFB $00,$20,$00,$03,$F8,$00
        DEFB $01,$40,$00,$0F,$F0,$00
        DEFB $00,$A0,$00,$0F,$FE,$0E
        DEFB $05,$54,$04,$0F,$FF,$FF
        DEFB $02,$2A,$AD,$0F,$FF,$FF
        DEFB $05,$05,$54,$0F,$FF,$FF
        DEFB $02,$A0,$04,$0F,$FF,$FE
        DEFB $05,$50,$00,$1F,$F8,$0E
        DEFB $0A,$A0,$00,$1F,$F8,$00
        DEFB $04,$50,$00,$1F,$FC,$00
        DEFB $08,$A8,$00,$1F,$FC,$00
        DEFB $01,$50,$00,$1F,$FC,$00
        DEFB $02,$A0,$00,$1F,$F8,$00
        DEFB $05,$40,$00,$0F,$F0,$00
        DEFB $02,$A0,$00,$0F,$F8,$00
        DEFB $05,$50,$00,$0F,$F8,$00
        DEFB $02,$A0,$00,$0F,$F8,$00
        DEFB $01,$50,$00,$0F,$F8,$00
        DEFB $02,$A0,$00,$07,$F8,$00
        DEFB $01,$50,$00,$07,$F8,$00
        DEFB $02,$A0,$00,$0F,$F8,$00
        DEFB $05,$50,$00,$0F,$F8,$00
        DEFB $00,$A0,$00,$0F,$FC,$00
        DEFB $05,$50,$00,$0F,$FC,$00
        DEFB $00,$A0,$00,$1F,$FC,$00
        DEFB $04,$50,$00,$1F,$F8,$00
        DEFB $0A,$A0,$00,$1F,$F8,$00
        DEFB $04,$50,$00,$1F,$F8,$00
        DEFB $0A,$A0,$00,$1F,$F8,$00
        DEFB $04,$50,$00,$1F,$F8,$00
        DEFB $0A,$A0,$00,$1F,$F8,$00
        DEFB $04,$50,$00,$1F,$F8,$00
        DEFB $0A,$20,$00,$1F,$FE,$00
        DEFB $05,$54,$00,$1F,$FE,$00
GUARD_SWSTEPB:
        DEFB 3,42,0,0
        DEFB $00,$00,$00,$03,$F0,$00
        DEFB $01,$E0,$00,$07,$F8,$00
        DEFB $03,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$F8,$00
        DEFB $07,$F0,$00,$0F,$FC,$00
        DEFB $03,$B8,$00,$0F,$FC,$00
        DEFB $01,$F8,$00,$07,$FC,$00
        DEFB $00,$F0,$00,$03,$FC,$00
        DEFB $01,$20,$00,$07,$F8,$00
        DEFB $00,$40,$00,$0F,$F0,$00
        DEFB $00,$A0,$00,$0F,$FE,$0E
        DEFB $05,$54,$04,$0F,$FF,$FE
        DEFB $02,$2A,$AC,$0F,$FF,$FF
        DEFB $05,$05,$57,$0F,$FF,$FF
        DEFB $02,$A2,$0C,$0F,$FF,$FF
        DEFB $05,$50,$00,$1F,$FF,$1E
        DEFB $0A,$A0,$00,$1F,$FC,$00
        DEFB $04,$50,$00,$1F,$FC,$00
        DEFB $00,$A8,$00,$1F,$FC,$00
        DEFB $01,$50,$00,$1F,$FC,$00
        DEFB $02,$A0,$00,$1F,$F8,$00
        DEFB $05,$40,$00,$0F,$F0,$00
        DEFB $02,$A0,$00,$0F,$F0,$00
        DEFB $05,$40,$00,$1F,$F0,$00
        DEFB $0A,$A0,$00,$1F,$F0,$00
        DEFB $05,$40,$00,$1F,$F0,$00
        DEFB $0A,$A0,$00,$1F,$F8,$00
        DEFB $05,$50,$00,$1F,$F8,$00
        DEFB $0A,$80,$00,$1F,$F8,$00
        DEFB $05,$50,$00,$1F,$F8,$00
        DEFB $0A,$80,$00,$1F,$F8,$00
        DEFB $05,$50,$00,$1F,$F8,$00
        DEFB $0A,$A0,$00,$1F,$F8,$00
        DEFB $05,$00,$00,$1F,$F8,$00
        DEFB $0A,$A0,$00,$1F,$F0,$00
        DEFB $05,$40,$00,$1F,$F0,$00
        DEFB $0A,$20,$00,$1F,$F0,$00
        DEFB $05,$40,$00,$1F,$F0,$00
        DEFB $0A,$80,$00,$1F,$F0,$00
        DEFB $04,$40,$00,$1F,$E0,$00
        DEFB $0A,$80,$00,$3F,$F8,$00
        DEFB $15,$50,$00,$3F,$F8,$00
SKEL_GARDE:
        DEFB 3,42,0,0
        DEFB $1F,$00,$00,$3F,$80,$00
        DEFB $1F,$00,$00,$7F,$80,$00
        DEFB $3F,$00,$00,$7F,$80,$00
        DEFB $33,$00,$00,$7F,$80,$00
        DEFB $31,$00,$00,$7F,$80,$00
        DEFB $3F,$00,$00,$7F,$80,$00
        DEFB $2A,$00,$00,$7F,$80,$00
        DEFB $06,$00,$00,$7F,$00,$00
        DEFB $06,$00,$00,$FF,$C0,$0F
        DEFB $7F,$80,$06,$FF,$C0,$3F
        DEFB $7F,$80,$1E,$FF,$C0,$7F
        DEFB $88,$80,$38,$FF,$C1,$FF
        DEFB $88,$80,$E0,$FF,$E3,$FC
        DEFB $FF,$C1,$C0,$FF,$FF,$F0
        DEFB $84,$27,$00,$FF,$FF,$E0
        DEFB $81,$02,$00,$FF,$FF,$80
        DEFB $FF,$B8,$00,$FF,$FF,$00
        DEFB $88,$98,$00,$FF,$FC,$00
        DEFB $88,$80,$00,$DD,$FC,$00
        DEFB $00,$00,$00,$FF,$C0,$00
        DEFB $3E,$00,$00,$7F,$80,$00
        DEFB $21,$00,$00,$7F,$80,$00
        DEFB $21,$00,$00,$73,$80,$00
        DEFB $21,$00,$00,$73,$80,$00
        DEFB $21,$00,$00,$73,$80,$00
        DEFB $21,$00,$00,$7B,$80,$00
        DEFB $11,$00,$00,$7B,$80,$00
        DEFB $11,$00,$00,$3B,$80,$00
        DEFB $11,$00,$00,$3B,$80,$00
        DEFB $11,$00,$00,$3B,$C0,$00
        DEFB $10,$80,$00,$3B,$C0,$00
        DEFB $10,$80,$00,$39,$C0,$00
        DEFB $10,$80,$00,$39,$E0,$00
        DEFB $10,$40,$00,$79,$E0,$00
        DEFB $20,$40,$00,$78,$F0,$00
        DEFB $20,$20,$00,$70,$F0,$00
        DEFB $20,$20,$00,$70,$70,$00
        DEFB $20,$20,$00,$70,$70,$00
        DEFB $20,$20,$00,$70,$70,$00
        DEFB $20,$20,$00,$F8,$FC,$00
        DEFB $F0,$78,$00,$F8,$FC,$00
        DEFB $F0,$78,$00,$F8,$FC,$00
SKEL_ADVANCE:
        DEFB 3,42,0,0
        DEFB $1F,$00,$00,$3F,$80,$00
        DEFB $1F,$00,$00,$7F,$80,$00
        DEFB $3F,$00,$00,$7F,$80,$00
        DEFB $33,$00,$00,$7F,$80,$00
        DEFB $31,$00,$00,$7F,$80,$00
        DEFB $3F,$00,$00,$7F,$80,$00
        DEFB $2A,$00,$00,$7F,$80,$00
        DEFB $06,$00,$00,$7F,$00,$0F
        DEFB $06,$00,$06,$FF,$C0,$3F
        DEFB $7F,$80,$1E,$FF,$C0,$7F
        DEFB $7F,$80,$38,$FF,$C1,$FF
        DEFB $88,$80,$E0,$FF,$E3,$FC
        DEFB $88,$41,$C0,$FF,$FF,$F0
        DEFB $FF,$E7,$00,$FF,$FF,$E0
        DEFB $81,$02,$00,$FF,$FF,$80
        DEFB $88,$B8,$00,$FF,$FF,$00
        DEFB $FF,$98,$00,$FF,$FC,$00
        DEFB $88,$80,$00,$FF,$FC,$00
        DEFB $48,$80,$00,$FD,$C0,$00
        DEFB $00,$00,$00,$FF,$C0,$00
        DEFB $3E,$00,$00,$7F,$80,$00
        DEFB $21,$00,$00,$7F,$80,$00
        DEFB $21,$00,$00,$73,$80,$00
        DEFB $21,$00,$00,$73,$80,$00
        DEFB $21,$00,$00,$73,$80,$00
        DEFB $21,$00,$00,$7B,$80,$00
        DEFB $11,$00,$00,$7B,$C0,$00
        DEFB $10,$80,$00,$3B,$C0,$00
        DEFB $11,$00,$00,$3B,$C0,$00
        DEFB $10,$80,$00,$7B,$E0,$00
        DEFB $20,$40,$00,$79,$E0,$00
        DEFB $20,$40,$00,$70,$F0,$00
        DEFB $20,$20,$00,$70,$F8,$00
        DEFB $20,$10,$00,$F0,$78,$00
        DEFB $40,$10,$00,$F0,$3C,$00
        DEFB $40,$08,$00,$E0,$3C,$00
        DEFB $40,$08,$00,$E0,$1C,$00
        DEFB $40,$08,$00,$E0,$1E,$00
        DEFB $40,$04,$00,$E0,$1E,$00
        DEFB $40,$04,$00,$F0,$1F,$80
        DEFB $E0,$0F,$00,$F0,$1F,$80
        DEFB $E0,$0F,$00,$F0,$1F,$80
SKEL_STRIKE1:
        DEFB 3,42,0,0
        DEFB $1F,$00,$00,$3F,$80,$00
        DEFB $1F,$00,$00,$7F,$80,$00
        DEFB $3F,$00,$00,$7F,$81,$C0
        DEFB $33,$00,$80,$7F,$83,$C0
        DEFB $31,$01,$80,$7F,$87,$C0
        DEFB $3F,$03,$00,$7F,$8F,$C0
        DEFB $2A,$06,$00,$7F,$9F,$80
        DEFB $06,$0C,$00,$7F,$3F,$00
        DEFB $06,$18,$00,$FF,$FE,$00
        DEFB $7F,$B0,$00,$FF,$FC,$00
        DEFB $7F,$E0,$00,$FF,$F8,$00
        DEFB $88,$40,$00,$FF,$F0,$00
        DEFB $88,$80,$00,$FF,$E0,$00
        DEFB $FF,$80,$00,$FF,$C0,$00
        DEFB $88,$80,$00,$FF,$C0,$00
        DEFB $88,$80,$00,$FF,$C0,$00
        DEFB $FF,$80,$00,$FF,$C0,$00
        DEFB $48,$80,$00,$FF,$C0,$00
        DEFB $48,$80,$00,$FD,$C0,$00
        DEFB $00,$00,$00,$FF,$C0,$00
        DEFB $3E,$00,$00,$7F,$80,$00
        DEFB $21,$00,$00,$7F,$80,$00
        DEFB $21,$00,$00,$73,$80,$00
        DEFB $21,$00,$00,$73,$80,$00
        DEFB $21,$00,$00,$73,$80,$00
        DEFB $21,$00,$00,$7B,$80,$00
        DEFB $11,$00,$00,$7B,$80,$00
        DEFB $11,$00,$00,$3B,$80,$00
        DEFB $11,$00,$00,$3B,$80,$00
        DEFB $11,$00,$00,$3B,$C0,$00
        DEFB $10,$80,$00,$3B,$C0,$00
        DEFB $10,$80,$00,$39,$C0,$00
        DEFB $10,$80,$00,$39,$E0,$00
        DEFB $10,$40,$00,$79,$E0,$00
        DEFB $20,$40,$00,$78,$F0,$00
        DEFB $20,$20,$00,$70,$F0,$00
        DEFB $20,$20,$00,$70,$70,$00
        DEFB $20,$20,$00,$70,$70,$00
        DEFB $20,$20,$00,$70,$70,$00
        DEFB $20,$20,$00,$F8,$FC,$00
        DEFB $F0,$78,$00,$F8,$FC,$00
        DEFB $F0,$78,$00,$F8,$FC,$00
SKEL_STRIKE2:
        DEFB 5,42,0,0
        DEFB $00,$7C,$00,$00,$00,$00,$FE,$00,$00,$00
        DEFB $00,$7C,$00,$00,$00,$01,$FE,$00,$00,$00
        DEFB $00,$FC,$00,$00,$00,$01,$FE,$00,$00,$00
        DEFB $00,$CC,$00,$00,$00,$01,$FE,$00,$00,$00
        DEFB $00,$C4,$00,$00,$00,$01,$FE,$00,$00,$00
        DEFB $00,$FC,$00,$00,$00,$01,$FE,$00,$00,$00
        DEFB $00,$A8,$00,$00,$00,$01,$FE,$00,$00,$00
        DEFB $00,$18,$00,$00,$00,$01,$FC,$00,$00,$00
        DEFB $00,$18,$00,$00,$00,$03,$FF,$00,$00,$00
        DEFB $01,$FE,$00,$00,$00,$03,$FF,$00,$00,$00
        DEFB $01,$FE,$00,$00,$00,$03,$FF,$00,$00,$00
        DEFB $01,$22,$00,$00,$00,$07,$FF,$C0,$00,$00
        DEFB $02,$10,$80,$00,$00,$07,$FF,$F0,$00,$00
        DEFB $03,$FF,$E0,$00,$00,$07,$FF,$FC,$00,$00
        DEFB $02,$22,$A8,$00,$00,$07,$FF,$FC,$1C,$03
        DEFB $02,$22,$20,$08,$01,$07,$FF,$FF,$FF,$FF
        DEFB $03,$FE,$0F,$FF,$FF,$07,$FF,$7F,$FF,$FF
        DEFB $02,$22,$00,$00,$00,$07,$FF,$1F,$FF,$FF
        DEFB $02,$22,$00,$00,$00,$07,$77,$00,$00,$00
        DEFB $00,$00,$00,$00,$00,$07,$FF,$00,$00,$00
        DEFB $00,$F8,$00,$00,$00,$01,$FE,$00,$00,$00
        DEFB $00,$84,$00,$00,$00,$01,$FE,$00,$00,$00
        DEFB $00,$84,$00,$00,$00,$01,$CE,$00,$00,$00
        DEFB $00,$84,$00,$00,$00,$01,$CE,$00,$00,$00
        DEFB $00,$84,$00,$00,$00,$01,$CF,$00,$00,$00
        DEFB $00,$82,$00,$00,$00,$01,$EF,$80,$00,$00
        DEFB $00,$41,$00,$00,$00,$01,$E7,$C0,$00,$00
        DEFB $00,$40,$80,$00,$00,$01,$E3,$C0,$00,$00
        DEFB $00,$80,$80,$00,$00,$01,$E1,$E0,$00,$00
        DEFB $00,$80,$40,$00,$00,$03,$C1,$F0,$00,$00
        DEFB $01,$00,$20,$00,$00,$03,$C0,$F8,$00,$00
        DEFB $01,$00,$10,$00,$00,$07,$80,$78,$00,$00
        DEFB $02,$00,$10,$00,$00,$07,$80,$3C,$00,$00
        DEFB $02,$00,$08,$00,$00,$0F,$00,$3C,$00,$00
        DEFB $04,$00,$08,$00,$00,$0F,$00,$1C,$00,$00
        DEFB $04,$00,$08,$00,$00,$1E,$00,$1C,$00,$00
        DEFB $08,$00,$08,$00,$00,$1E,$00,$1C,$00,$00
        DEFB $08,$00,$08,$00,$00,$3C,$00,$1C,$00,$00
        DEFB $10,$00,$08,$00,$00,$3C,$00,$1C,$00,$00
        DEFB $10,$00,$08,$00,$00,$FC,$00,$7E,$00,$00
        DEFB $78,$00,$3C,$00,$00,$FC,$00,$7E,$00,$00
        DEFB $78,$00,$3C,$00,$00,$FC,$00,$7E,$00,$00
SKEL_PARRY:
        DEFB 3,42,0,0
        DEFB $1F,$00,$00,$3F,$80,$00
        DEFB $1F,$00,$00,$7F,$80,$00
        DEFB $3F,$00,$00,$7F,$87,$00
        DEFB $33,$02,$00,$7F,$8F,$00
        DEFB $31,$06,$00,$7F,$8F,$00
        DEFB $3F,$04,$00,$7F,$8F,$00
        DEFB $2A,$04,$00,$7F,$8F,$00
        DEFB $06,$06,$00,$7F,$0F,$00
        DEFB $06,$06,$00,$FF,$CF,$00
        DEFB $7F,$84,$00,$FF,$CF,$00
        DEFB $7F,$84,$00,$FF,$CE,$00
        DEFB $88,$84,$00,$FF,$CE,$00
        DEFB $88,$84,$00,$FF,$CE,$00
        DEFB $FF,$84,$00,$FF,$EE,$00
        DEFB $88,$44,$00,$FF,$FE,$00
        DEFB $84,$24,$00,$FF,$FE,$00
        DEFB $FF,$E4,$00,$FF,$FE,$00
        DEFB $84,$14,$00,$FF,$FE,$00
        DEFB $88,$B4,$00,$DF,$FE,$00
        DEFB $00,$1C,$00,$FF,$FE,$00
        DEFB $3E,$00,$00,$7F,$BE,$00
        DEFB $21,$00,$00,$7F,$80,$00
        DEFB $21,$00,$00,$73,$80,$00
        DEFB $21,$00,$00,$73,$80,$00
        DEFB $21,$00,$00,$73,$80,$00
        DEFB $21,$00,$00,$7B,$80,$00
        DEFB $11,$00,$00,$7B,$80,$00
        DEFB $11,$00,$00,$3B,$80,$00
        DEFB $11,$00,$00,$3B,$80,$00
        DEFB $11,$00,$00,$3B,$C0,$00
        DEFB $10,$80,$00,$3B,$C0,$00
        DEFB $10,$80,$00,$39,$C0,$00
        DEFB $10,$80,$00,$39,$E0,$00
        DEFB $10,$40,$00,$79,$E0,$00
        DEFB $20,$40,$00,$78,$F0,$00
        DEFB $20,$20,$00,$70,$F0,$00
        DEFB $20,$20,$00,$70,$70,$00
        DEFB $20,$20,$00,$70,$70,$00
        DEFB $20,$20,$00,$70,$70,$00
        DEFB $20,$20,$00,$F8,$FC,$00
        DEFB $F0,$78,$00,$F8,$FC,$00
        DEFB $F0,$78,$00,$F8,$FC,$00
SKEL_HURT:
        DEFB 3,42,0,0
        DEFB $3E,$00,$00,$7F,$00,$00
        DEFB $3E,$00,$00,$FF,$00,$00
        DEFB $7E,$00,$00,$FF,$00,$00
        DEFB $E6,$00,$00,$FF,$E0,$00
        DEFB $E2,$C0,$00,$FF,$E0,$00
        DEFB $FF,$C0,$00,$FF,$E0,$00
        DEFB $AA,$80,$00,$FF,$E0,$00
        DEFB $CD,$80,$00,$FF,$C0,$00
        DEFB $C6,$00,$00,$FF,$C0,$00
        DEFB $FF,$00,$00,$FF,$80,$00
        DEFB $FF,$00,$00,$FF,$80,$00
        DEFB $91,$00,$00,$FF,$C0,$00
        DEFB $88,$80,$00,$FF,$C0,$00
        DEFB $FF,$80,$00,$FF,$E0,$00
        DEFB $91,$40,$00,$FF,$F0,$00
        DEFB $91,$20,$00,$FF,$F8,$00
        DEFB $FF,$10,$00,$FF,$FC,$00
        DEFB $91,$08,$00,$FF,$BE,$00
        DEFB $91,$04,$00,$FB,$9F,$00
        DEFB $00,$02,$00,$FF,$8F,$00
        DEFB $7C,$00,$00,$FF,$07,$00
        DEFB $42,$00,$00,$FF,$00,$00
        DEFB $42,$00,$00,$E7,$00,$00
        DEFB $42,$00,$00,$E7,$00,$00
        DEFB $42,$00,$00,$E7,$00,$00
        DEFB $42,$00,$00,$FF,$00,$00
        DEFB $72,$00,$00,$FF,$00,$00
        DEFB $12,$00,$00,$FF,$80,$00
        DEFB $11,$00,$00,$3F,$80,$00
        DEFB $11,$00,$00,$3B,$80,$00
        DEFB $11,$00,$00,$3B,$80,$00
        DEFB $11,$00,$00,$3B,$80,$00
        DEFB $11,$00,$00,$3B,$C0,$00
        DEFB $10,$80,$00,$3B,$C0,$00
        DEFB $10,$80,$00,$39,$E0,$00
        DEFB $10,$40,$00,$39,$E0,$00
        DEFB $10,$40,$00,$38,$E0,$00
        DEFB $10,$40,$00,$38,$E0,$00
        DEFB $10,$40,$00,$38,$E0,$00
        DEFB $10,$40,$00,$7F,$F8,$00
        DEFB $3C,$F0,$00,$7F,$F8,$00
        DEFB $3C,$F0,$00,$7F,$F8,$00
SKEL_DEAD:
        DEFB 5,16,248,26
        DEFB $00,$00,$00,$00,$00,$00,$00,$00,$00,$00
        DEFB $00,$00,$00,$00,$00,$00,$00,$00,$00,$00
        DEFB $00,$00,$00,$00,$00,$00,$00,$00,$7F,$C0
        DEFB $00,$00,$00,$3F,$80,$00,$1F,$FF,$FF,$C0
        DEFB $00,$0F,$FF,$D2,$80,$00,$1F,$FF,$FF,$C0
        DEFB $00,$09,$24,$95,$80,$FF,$FF,$FF,$FF,$C0
        DEFB $FF,$F9,$24,$92,$80,$FF,$FF,$FF,$FF,$C0
        DEFB $92,$49,$3E,$92,$80,$FF,$FF,$FF,$FF,$C0
        DEFB $92,$49,$41,$92,$80,$FF,$FF,$FF,$FF,$C0
        DEFB $92,$49,$3E,$92,$80,$FF,$FF,$FF,$FF,$C0
        DEFB $92,$49,$24,$BF,$80,$FF,$FF,$FF,$FF,$C0
        DEFB $92,$49,$24,$C0,$00,$FF,$FF,$FF,$FF,$C0
        DEFB $92,$49,$24,$C0,$00,$FF,$FF,$FF,$E0,$00
        DEFB $92,$49,$24,$C0,$00,$FF,$FF,$FF,$E7,$FF
        DEFB $FF,$FF,$FF,$C3,$FF,$FF,$FF,$FF,$E7,$FF
        DEFB $00,$00,$00,$00,$00,$FF,$FF,$FF,$E7,$FF
SKEL_RETREAT:
        DEFB 3,42,0,0
        DEFB $1F,$00,$00,$3F,$80,$00
        DEFB $1F,$00,$00,$7F,$80,$00
        DEFB $3F,$00,$00,$7F,$80,$00
        DEFB $33,$00,$00,$7F,$80,$00
        DEFB $31,$00,$00,$7F,$80,$00
        DEFB $3F,$00,$00,$7F,$80,$00
        DEFB $2A,$00,$00,$7F,$80,$00
        DEFB $06,$00,$00,$7F,$00,$00
        DEFB $06,$00,$00,$FF,$C0,$00
        DEFB $7F,$80,$00,$FF,$C0,$00
        DEFB $7F,$80,$00,$FF,$C0,$3E
        DEFB $88,$80,$1C,$FF,$C0,$FE
        DEFB $88,$80,$54,$FF,$E3,$FE
        DEFB $FF,$C1,$E0,$FF,$EF,$FE
        DEFB $88,$46,$80,$FF,$EF,$F0
        DEFB $81,$02,$00,$FF,$FF,$C0
        DEFB $FF,$F8,$00,$FF,$FF,$00
        DEFB $88,$B0,$00,$FF,$FC,$00
        DEFB $88,$80,$00,$DD,$F8,$00
        DEFB $00,$00,$00,$FF,$C0,$00
        DEFB $3E,$00,$00,$7F,$80,$00
        DEFB $21,$00,$00,$7F,$80,$00
        DEFB $21,$00,$00,$73,$80,$00
        DEFB $21,$00,$00,$73,$80,$00
        DEFB $21,$00,$00,$73,$80,$00
        DEFB $21,$00,$00,$7B,$80,$00
        DEFB $11,$00,$00,$7B,$80,$00
        DEFB $11,$00,$00,$3B,$80,$00
        DEFB $11,$00,$00,$3B,$80,$00
        DEFB $11,$00,$00,$7B,$80,$00
        DEFB $21,$00,$00,$7B,$80,$00
        DEFB $21,$00,$00,$73,$80,$00
        DEFB $21,$00,$00,$73,$80,$00
        DEFB $21,$00,$00,$F3,$80,$00
        DEFB $41,$00,$00,$F3,$C0,$00
        DEFB $40,$80,$00,$E3,$C0,$00
        DEFB $40,$80,$00,$E1,$C0,$00
        DEFB $40,$80,$00,$E1,$C0,$00
        DEFB $40,$80,$00,$E1,$C0,$00
        DEFB $40,$80,$00,$F3,$F0,$00
        DEFB $E1,$E0,$00,$F3,$F0,$00
        DEFB $E1,$E0,$00,$F3,$F0,$00
SKEL_DRAW1:
        DEFB 3,42,0,0
        DEFB $1F,$00,$00,$3F,$80,$00
        DEFB $1F,$00,$00,$7F,$80,$00
        DEFB $3F,$00,$00,$7F,$80,$00
        DEFB $33,$00,$00,$7F,$80,$00
        DEFB $31,$00,$00,$7F,$80,$00
        DEFB $3F,$00,$00,$7F,$80,$00
        DEFB $2A,$00,$00,$7F,$80,$00
        DEFB $06,$00,$00,$7F,$00,$00
        DEFB $06,$00,$00,$FF,$C0,$00
        DEFB $7F,$80,$00,$FF,$C0,$00
        DEFB $7F,$80,$00,$FF,$C0,$00
        DEFB $88,$80,$00,$FF,$C0,$00
        DEFB $88,$80,$00,$FF,$C0,$00
        DEFB $FF,$80,$00,$FF,$C0,$00
        DEFB $88,$80,$00,$FF,$C0,$00
        DEFB $88,$80,$00,$FF,$E0,$00
        DEFB $FF,$C0,$00,$FF,$E0,$00
        DEFB $88,$40,$00,$FF,$E0,$00
        DEFB $44,$40,$00,$FF,$E0,$00
        DEFB $00,$C0,$00,$FF,$E0,$00
        DEFB $1F,$00,$00,$7F,$E0,$00
        DEFB $21,$C0,$00,$7F,$E0,$00
        DEFB $20,$40,$00,$73,$F0,$00
        DEFB $21,$E0,$00,$73,$F8,$00
        DEFB $21,$10,$00,$73,$FC,$00
        DEFB $21,$08,$00,$7B,$BE,$00
        DEFB $11,$04,$00,$7B,$9F,$00
        DEFB $11,$02,$00,$3B,$8F,$00
        DEFB $11,$00,$00,$3B,$87,$00
        DEFB $11,$00,$00,$3B,$C0,$00
        DEFB $10,$80,$00,$3B,$C0,$00
        DEFB $10,$80,$00,$39,$C0,$00
        DEFB $10,$80,$00,$39,$E0,$00
        DEFB $10,$40,$00,$79,$E0,$00
        DEFB $20,$40,$00,$78,$F0,$00
        DEFB $20,$20,$00,$70,$F0,$00
        DEFB $20,$20,$00,$70,$70,$00
        DEFB $20,$20,$00,$70,$70,$00
        DEFB $20,$20,$00,$70,$70,$00
        DEFB $20,$20,$00,$F8,$FC,$00
        DEFB $F0,$78,$00,$F8,$FC,$00
        DEFB $F0,$78,$00,$F8,$FC,$00
SKEL_DRAW2:
        DEFB 3,42,0,0
        DEFB $1F,$00,$00,$3F,$80,$00
        DEFB $1F,$00,$00,$7F,$80,$00
        DEFB $3F,$00,$00,$7F,$80,$00
        DEFB $33,$00,$00,$7F,$80,$00
        DEFB $31,$00,$00,$7F,$80,$00
        DEFB $3F,$00,$00,$7F,$80,$3C
        DEFB $2A,$00,$18,$7F,$80,$3C
        DEFB $06,$00,$18,$7F,$00,$FC
        DEFB $06,$00,$60,$FF,$C1,$FC
        DEFB $7F,$80,$C0,$FF,$C3,$F0
        DEFB $7F,$81,$80,$FF,$E7,$E0
        DEFB $88,$43,$00,$FF,$FF,$C0
        DEFB $84,$26,$00,$FF,$FF,$80
        DEFB $FF,$FC,$00,$FF,$FF,$00
        DEFB $88,$B8,$00,$FF,$FE,$00
        DEFB $88,$98,$00,$FF,$FC,$00
        DEFB $FF,$80,$00,$FF,$FC,$00
        DEFB $88,$80,$00,$FF,$C0,$00
        DEFB $48,$80,$00,$FD,$C0,$00
        DEFB $00,$00,$00,$FF,$C0,$00
        DEFB $3E,$00,$00,$7F,$80,$00
        DEFB $21,$00,$00,$7F,$80,$00
        DEFB $21,$00,$00,$73,$80,$00
        DEFB $21,$00,$00,$73,$80,$00
        DEFB $21,$00,$00,$73,$80,$00
        DEFB $21,$00,$00,$7B,$80,$00
        DEFB $11,$00,$00,$7B,$80,$00
        DEFB $11,$00,$00,$3B,$80,$00
        DEFB $11,$00,$00,$3B,$80,$00
        DEFB $11,$00,$00,$3B,$C0,$00
        DEFB $10,$80,$00,$3B,$C0,$00
        DEFB $10,$80,$00,$39,$C0,$00
        DEFB $10,$80,$00,$39,$E0,$00
        DEFB $10,$40,$00,$79,$E0,$00
        DEFB $20,$40,$00,$78,$F0,$00
        DEFB $20,$20,$00,$70,$F0,$00
        DEFB $20,$20,$00,$70,$70,$00
        DEFB $20,$20,$00,$70,$70,$00
        DEFB $20,$20,$00,$70,$70,$00
        DEFB $20,$20,$00,$F8,$FC,$00
        DEFB $F0,$78,$00,$F8,$FC,$00
        DEFB $F0,$78,$00,$F8,$FC,$00
SKEL_SWSTEPA:
        DEFB 3,42,0,0
        DEFB $1F,$00,$00,$3F,$80,$00
        DEFB $1F,$00,$00,$7F,$80,$00
        DEFB $3F,$00,$00,$7F,$80,$00
        DEFB $33,$00,$00,$7F,$80,$00
        DEFB $31,$00,$00,$7F,$80,$00
        DEFB $3F,$00,$00,$7F,$80,$00
        DEFB $2A,$00,$00,$7F,$80,$00
        DEFB $06,$00,$00,$7F,$00,$00
        DEFB $06,$00,$00,$FF,$C0,$0F
        DEFB $7F,$80,$06,$FF,$C0,$3F
        DEFB $7F,$80,$1E,$FF,$C0,$7F
        DEFB $88,$80,$38,$FF,$C1,$FF
        DEFB $88,$80,$E0,$FF,$E3,$FC
        DEFB $FF,$C1,$C0,$FF,$FF,$F0
        DEFB $84,$27,$00,$FF,$FF,$E0
        DEFB $81,$02,$00,$FF,$FF,$80
        DEFB $FF,$B8,$00,$FF,$FF,$00
        DEFB $88,$98,$00,$FF,$FC,$00
        DEFB $88,$80,$00,$DD,$FC,$00
        DEFB $00,$00,$00,$FF,$C0,$00
        DEFB $3E,$00,$00,$7F,$80,$00
        DEFB $21,$00,$00,$7F,$80,$00
        DEFB $21,$00,$00,$73,$80,$00
        DEFB $21,$00,$00,$73,$80,$00
        DEFB $21,$00,$00,$73,$80,$00
        DEFB $21,$00,$00,$7F,$80,$00
        DEFB $12,$00,$00,$7F,$80,$00
        DEFB $12,$00,$00,$3F,$00,$00
        DEFB $12,$00,$00,$3F,$00,$00
        DEFB $12,$00,$00,$3F,$00,$00
        DEFB $12,$00,$00,$3F,$00,$00
        DEFB $12,$00,$00,$3F,$00,$00
        DEFB $12,$00,$00,$3F,$00,$00
        DEFB $12,$00,$00,$3F,$00,$00
        DEFB $0A,$00,$00,$3F,$00,$00
        DEFB $0A,$00,$00,$1F,$00,$00
        DEFB $0A,$00,$00,$1F,$00,$00
        DEFB $0A,$00,$00,$1F,$00,$00
        DEFB $0A,$00,$00,$1F,$00,$00
        DEFB $0A,$00,$00,$3F,$C0,$00
        DEFB $1F,$80,$00,$3F,$C0,$00
        DEFB $1F,$80,$00,$3F,$C0,$00
SKEL_SWSTEPB:
        DEFB 3,42,0,0
        DEFB $1F,$00,$00,$3F,$80,$00
        DEFB $1F,$00,$00,$7F,$80,$00
        DEFB $3F,$00,$00,$7F,$80,$00
        DEFB $33,$00,$00,$7F,$80,$00
        DEFB $31,$00,$00,$7F,$80,$00
        DEFB $3F,$00,$00,$7F,$80,$00
        DEFB $2A,$00,$00,$7F,$80,$00
        DEFB $06,$00,$00,$7F,$00,$00
        DEFB $06,$00,$00,$FF,$C0,$0F
        DEFB $7F,$80,$06,$FF,$C0,$3F
        DEFB $7F,$80,$1E,$FF,$C0,$7F
        DEFB $88,$80,$38,$FF,$C1,$FF
        DEFB $88,$80,$E0,$FF,$E3,$FC
        DEFB $FF,$C1,$C0,$FF,$FF,$F0
        DEFB $84,$27,$00,$FF,$FF,$E0
        DEFB $81,$02,$00,$FF,$FF,$80
        DEFB $FF,$B8,$00,$FF,$FF,$00
        DEFB $88,$98,$00,$FF,$FC,$00
        DEFB $88,$80,$00,$DD,$FC,$00
        DEFB $00,$00,$00,$FF,$C0,$00
        DEFB $3E,$00,$00,$7F,$80,$00
        DEFB $21,$00,$00,$7F,$80,$00
        DEFB $21,$00,$00,$73,$80,$00
        DEFB $21,$00,$00,$73,$80,$00
        DEFB $21,$00,$00,$73,$80,$00
        DEFB $21,$00,$00,$7B,$80,$00
        DEFB $11,$00,$00,$7B,$80,$00
        DEFB $11,$00,$00,$3B,$80,$00
        DEFB $11,$00,$00,$3B,$80,$00
        DEFB $11,$00,$00,$3B,$80,$00
        DEFB $11,$00,$00,$3B,$80,$00
        DEFB $11,$00,$00,$3B,$80,$00
        DEFB $11,$00,$00,$3B,$80,$00
        DEFB $11,$00,$00,$3B,$C0,$00
        DEFB $10,$80,$00,$3B,$C0,$00
        DEFB $10,$80,$00,$39,$C0,$00
        DEFB $10,$80,$00,$39,$C0,$00
        DEFB $10,$80,$00,$39,$C0,$00
        DEFB $10,$80,$00,$39,$C0,$00
        DEFB $10,$80,$00,$7F,$F0,$00
        DEFB $3D,$E0,$00,$7F,$F0,$00
        DEFB $3D,$E0,$00,$7F,$F0,$00
; ======== end _sprites.inc ========
; ======== begin _levels.inc (generated data) ========
; GENERATED by make_levels.py from levels.txt - edit the levels there.
; Each level: DEFB start room, start X (px), start floor row; then 32 bytes per room =
;   24 tiles (row-major) + L,R,U,D room (255 none) + guard col,row (255 none) + guard kind (0 guard, 1 skeleton) + 1 spare

LEVEL_COUNT EQU 3
LEVEL_TBL:  DEFW LEVEL_0, LEVEL_1, LEVEL_2

LEVEL_0:    DEFB 0,40,1       ; level 1: start room, prince X (px), floor row
; ---- level 1 room 0
        DEFB T_WALLR,T_EMPTY+T_TORCH,T_EMPTY,T_FLOORL,T_FLOOR,T_FLOOR,T_FLOOR,T_FLOOR+T_TORCH      ; #t.====+
        DEFB T_FLOORL+T_TORCH,T_FLOOR,T_FLOOR,T_PILLAR,T_EMPTY,T_FLOORL,T_FLOOR,T_FLOOR      ; +==P.===
        DEFB T_WALL,T_WALL,T_WALL,T_WALLR,T_SPIKES,T_WALLR,T_EMPTY,T_WALL      ; ####^#.#
        DEFB 255,1,255,255, 3,1, 0,0
; ---- level 1 room 1
        DEFB T_EMPTY,T_EMPTY,T_EMPTY,T_FLOORL,T_FLOOR,T_LOOSE,T_FLOOR,T_FLOOR      ; ...==L==
        DEFB T_FLOOR,T_FLOOR+T_TORCH,T_FLOOR+T_POTION,T_FLOOR,T_FLOOR,T_FLOOR,T_FLOOR+T_TORCH,T_FLOOR      ; =+o===+=
        DEFB T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL      ; ########
        DEFB 0,2,255,255, 5,1, 0,0
; ---- level 1 room 2
        DEFB T_EMPTY+T_TORCH,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY+T_TORCH      ; t......t
        DEFB T_FLOOR,T_FLOOR,T_FLOOR,T_EMPTY,T_EMPTY,T_EMPTY,T_FLOORL,T_FLOOR      ; ===...==
        DEFB T_FLOOR,T_FLOOR,T_FLOOR,T_EMPTY,T_EMPTY,T_EMPTY,T_FLOORL,T_FLOOR      ; ===...==
        DEFB 1,255,255,3, 255,255, 0,0
; ---- level 1 room 3
        DEFB T_EMPTY+T_TORCH,T_EMPTY,T_FLOORL,T_FLOOR,T_FLOOR,T_FLOOR,T_FLOOR,T_FLOOR      ; t.======
        DEFB T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY      ; ........
        DEFB T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL      ; ########
        DEFB 255,4,2,255, 6,0, 0,0
; ---- level 1 room 4
        DEFB T_FLOOR,T_PLATE,T_FLOOR,T_SPIKES,T_FLOORL,T_FLOOR,T_GATE0,T_PLATE      ; =v=^==Gv
        DEFB T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY      ; ........
        DEFB T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL      ; ########
        DEFB 3,5,255,255, 255,255, 0,0
; ---- level 1 room 5
        DEFB T_FLOOR+T_TORCH,T_FLOOR,T_FLOOR+T_POTION,T_FLOOR,T_FLOOR,T_FLOOR,T_FLOOR,T_FLOOR      ; +=o=====
        DEFB T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY      ; ........
        DEFB T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL      ; ########
        DEFB 4,255,6,255, 5,0, 0,0
; ---- level 1 room 6
        DEFB T_EMPTY+T_TORCH,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY+T_TORCH      ; t......t
        DEFB T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY      ; ........
        DEFB T_FLOORL,T_FLOOR,T_FLOOR,T_EMPTY,T_EMPTY,T_EMPTY,T_FLOORL,T_FLOOR      ; ===...==
        DEFB 255,7,255,5, 255,255, 0,0
; ---- level 1 room 7
        DEFB T_EMPTY+T_TORCH,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY+T_TORCH      ; t......t
        DEFB T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY      ; ........
        DEFB T_FLOOR,T_FLOOR,T_FLOOR,T_FLOOR,T_FLOOR,T_FLOOR,T_EXIT,T_FLOOR      ; ======E=
        DEFB 6,255,255,255, 3,2, 0,0

LEVEL_1:    DEFB 0,40,1       ; level 2: start room, prince X (px), floor row
; ---- level 2 room 0
        DEFB T_EMPTY+T_TORCH,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY+T_TORCH      ; t......t
        DEFB T_FLOORL,T_FLOOR+T_TORCH,T_FLOOR,T_FLOOR,T_CHOMP0,T_FLOOR,T_FLOOR+T_TORCH,T_FLOOR      ; =+==C=+=
        DEFB T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL      ; ########
        DEFB 255,1,255,255, 255,255, 0,0
; ---- level 2 room 1
        DEFB T_EMPTY+T_TORCH,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY+T_TORCH      ; t......t
        DEFB T_FLOOR,T_FLOOR,T_CHOMP0,T_FLOOR,T_CHOMP0,T_FLOOR,T_FLOOR,T_FLOOR      ; ==C=C===
        DEFB T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL      ; ########
        DEFB 0,2,255,255, 6,1, 0,0
; ---- level 2 room 2
        DEFB T_EMPTY+T_TORCH,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY+T_TORCH      ; t......t
        DEFB T_FLOOR,T_PLATE,T_FLOOR,T_GATE0,T_FLOOR,T_PLATE,T_FLOOR,T_FLOOR      ; =v=G=v==
        DEFB T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL      ; ########
        DEFB 1,3,255,255, 255,255, 0,0
; ---- level 2 room 3
        DEFB T_EMPTY+T_TORCH,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY+T_TORCH      ; t......t
        DEFB T_FLOOR,T_FLOOR,T_FLOOR,T_FLOOR+T_POTION,T_FLOOR,T_FLOOR,T_EXIT,T_FLOOR      ; ===o==E=
        DEFB T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL      ; ########
        DEFB 2,255,255,255, 4,1, 0,0

LEVEL_2:    DEFB 0,40,1       ; level 3: start room, prince X (px), floor row
; ---- level 3 room 0
        DEFB T_EMPTY+T_TORCH,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY+T_TORCH      ; t......t
        DEFB T_PLATE,T_FLOOR,T_CHOMP0,T_FLOOR,T_GATE0,T_PLATE,T_FLOOR+T_TORCH,T_FLOOR      ; v=C=Gv+=
        DEFB T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL,T_WALL      ; ########
        DEFB 255,1,255,255, 6,1, 1,0
; ---- level 3 room 1
        DEFB T_EMPTY+T_TORCH,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY+T_TORCH      ; t......t
        DEFB T_FLOOR,T_FLOOR+T_POTION,T_FLOOR,T_LOOSE,T_EMPTY,T_FLOORL,T_FLOOR,T_FLOOR      ; =o=L.===
        DEFB T_FLOOR,T_FLOOR,T_FLOOR,T_FLOOR,T_SPIKES,T_FLOORL,T_FLOOR,T_FLOOR      ; ====^===
        DEFB 0,2,255,255, 255,255, 0,0
; ---- level 3 room 2
        DEFB T_EMPTY+T_TORCH,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY,T_EMPTY+T_TORCH      ; t......t
        DEFB T_FLOOR,T_FLOOR,T_FLOOR,T_FLOOR,T_FLOOR,T_EMPTY,T_EMPTY,T_EMPTY      ; =====...
        DEFB T_FLOOR,T_FLOOR,T_FLOOR,T_FLOOR,T_FLOOR,T_EXIT,T_FLOOR,T_FLOOR      ; =====E==
        DEFB 1,255,255,255, 3,1, 1,0
; ======== end _levels.inc ========
; ======== begin _font.inc (generated data) ========
; GENERATED by make_text.py - 8 bytes per glyph, A-Z, 0-9, then a blank (index 36)
FONT:
        DEFB $38,$44,$44,$7C,$44,$44,$44,$00      ; A
        DEFB $78,$44,$44,$78,$44,$44,$78,$00      ; B
        DEFB $3C,$40,$40,$40,$40,$40,$3C,$00      ; C
        DEFB $78,$44,$44,$44,$44,$44,$78,$00      ; D
        DEFB $7C,$40,$40,$78,$40,$40,$7C,$00      ; E
        DEFB $7C,$40,$40,$78,$40,$40,$40,$00      ; F
        DEFB $3C,$40,$40,$4C,$44,$44,$38,$00      ; G
        DEFB $44,$44,$44,$7C,$44,$44,$44,$00      ; H
        DEFB $7C,$10,$10,$10,$10,$10,$7C,$00      ; I
        DEFB $1C,$08,$08,$08,$08,$48,$30,$00      ; J
        DEFB $44,$48,$50,$60,$50,$48,$44,$00      ; K
        DEFB $40,$40,$40,$40,$40,$40,$7C,$00      ; L
        DEFB $44,$6C,$54,$54,$44,$44,$44,$00      ; M
        DEFB $44,$64,$54,$4C,$44,$44,$44,$00      ; N
        DEFB $38,$44,$44,$44,$44,$44,$38,$00      ; O
        DEFB $78,$44,$44,$78,$40,$40,$40,$00      ; P
        DEFB $38,$44,$44,$44,$54,$48,$34,$00      ; Q
        DEFB $78,$44,$44,$78,$50,$48,$44,$00      ; R
        DEFB $3C,$40,$40,$38,$04,$04,$78,$00      ; S
        DEFB $7C,$10,$10,$10,$10,$10,$10,$00      ; T
        DEFB $44,$44,$44,$44,$44,$44,$38,$00      ; U
        DEFB $44,$44,$44,$44,$44,$28,$10,$00      ; V
        DEFB $44,$44,$44,$54,$54,$6C,$44,$00      ; W
        DEFB $44,$44,$28,$10,$28,$44,$44,$00      ; X
        DEFB $44,$44,$28,$10,$10,$10,$10,$00      ; Y
        DEFB $7C,$04,$08,$10,$20,$40,$7C,$00      ; Z
        DEFB $38,$44,$4C,$54,$64,$44,$38,$00      ; 0
        DEFB $10,$30,$10,$10,$10,$10,$38,$00      ; 1
        DEFB $38,$44,$04,$08,$10,$20,$7C,$00      ; 2
        DEFB $78,$04,$04,$38,$04,$04,$78,$00      ; 3
        DEFB $08,$18,$28,$48,$7C,$08,$08,$00      ; 4
        DEFB $7C,$40,$78,$04,$04,$44,$38,$00      ; 5
        DEFB $38,$40,$40,$78,$44,$44,$38,$00      ; 6
        DEFB $7C,$04,$08,$10,$20,$20,$20,$00      ; 7
        DEFB $38,$44,$44,$38,$44,$44,$38,$00      ; 8
        DEFB $38,$44,$44,$3C,$04,$04,$38,$00      ; 9
        DEFB 0,0,0,0,0,0,0,0      ; space
; ======== end _font.inc ========
; ======== begin _intro.inc (generated data) ========
; GENERATED by make_intro.py from intro_src.png - 256 x 171 picture, 3 ZX0-compressed chunks (one per video bank, 2048 bytes each when unpacked)
INTRO_LINES EQU 171
INTRO_Z0:
        DEFB $50,$16,$19,$98,$CC,$47,$34,$DC,$51,$C6,$33,$08,$9C,$66,$61,$19
        DEFB $8C,$C9,$87,$29,$89,$96,$66,$91,$99,$4C,$D1,$38,$57,$60,$CA,$63
        DEFB $31,$98,$3E,$41,$E9,$0E,$88,$42,$17,$A8,$58,$A9,$C2,$0F,$89,$2C
        DEFB $50,$E4,$C7,$91,$1E,$40,$B1,$12,$E2,$8E,$21,$A0,$26,$80,$F1,$2B
        DEFB $94,$36,$E6,$6F,$33,$7C,$D6,$71,$14,$D4,$CC,$A6,$79,$99,$8F,$CE
        DEFB $AF,$36,$30,$D6,$73,$33,$9D,$4E,$6D,$73,$61,$4A,$B7,$47,$36,$4C
        DEFB $CB,$67,$C3,$8D,$1D,$F8,$74,$9C,$C9,$E7,$87,$4E,$19,$F0,$F7,$83
        DEFB $CE,$19,$9C,$71,$C1,$DE,$0F,$78,$39,$E1,$E9,$6A,$A7,$9D,$1F,$70
        DEFB $77,$D3,$11,$CC,$0C,$62,$30,$E6,$33,$E6,$03,$DC,$0C,$C0,$73,$11
        DEFB $8C,$8E,$70,$33,$80,$CE,$03,$30,$18,$C4,$E1,$A8,$A7,$9C,$0C,$62
        DEFB $39,$80,$18,$B8,$66,$E3,$1C,$82,$31,$74,$21,$99,$8E,$C6,$32,$38
        DEFB $D8,$C6,$63,$1B,$1C,$68,$61,$C3,$8D,$84,$73,$30,$53,$98,$C6,$E3
        DEFB $17,$18,$94,$72,$C3,$C9,$8C,$94,$91,$F9,$70,$C8,$C3,$2E,$9C,$84
        DEFB $72,$22,$33,$0E,$2A,$39,$69,$EB,$47,$0E,$10,$19,$A5,$E1,$73,$96
        DEFB $8C,$4C,$C6,$65,$99,$81,$42,$66,$7A,$8F,$49,$96,$66,$73,$31,$CC
        DEFB $D6,$26,$99,$82,$46,$63,$13,$4C,$1C,$63,$7B,$99,$E6,$B6,$E7,$11
        DEFB $98,$86,$E7,$1C,$99,$23,$66,$18,$72,$2F,$FC,$21,$B3,$0F,$85,$17
        DEFB $24,$B9,$65,$E4,$1B,$1C,$6C,$41,$E2,$2D,$90,$33,$E0,$1F,$99,$66
        DEFB $CC,$9B,$34,$55,$CC,$B6,$79,$B8,$DA,$11,$67,$5F,$19,$DC,$F4,$E3
        DEFB $93,$9F,$FF,$95,$5A,$F9,$A6,$C6,$AF,$3B,$B8,$D5,$E1,$54,$57,$9C
        DEFB $9E,$6A,$F1,$45,$E7,$07,$3C,$19,$E0,$8C,$D9,$E3,$CE,$0E,$70,$79
        DEFB $E1,$FF,$A7,$2A,$37,$69,$F7,$83,$9C,$1C,$70,$73,$C1,$19,$63,$87
        DEFB $98,$39,$E1,$EB,$E6,$23,$31,$0C,$C8,$B0,$09,$E0,$CC,$46,$62,$39
        DEFB $88,$EC,$40,$00,$3A,$07,$FB,$12,$51,$4A,$62,$33,$03,$30,$17,$C3
        DEFB $31,$1C,$C4,$66,$6C,$21,$B1,$0E,$C4,$88,$22,$B8,$F0,$A3,$63,$0F
        DEFB $0F,$60,$8A,$25,$02,$48,$0B,$F0,$F0,$C6,$C6,$1E,$19,$40,$12,$81
        DEFB $61,$8F,$0C,$3E,$13,$48,$CE,$C3,$34,$76,$5B,$92,$33,$49,$99,$44
        DEFB $78,$01,$4F,$FF,$FF,$E8,$84,$7C,$66,$91,$92,$CC,$E1,$AA,$AF,$48
        DEFB $CD,$63,$33,$98,$1C,$A8,$C4,$E3,$10,$B6,$29,$C6,$35,$49,$CC,$C7
        DEFB $F0,$96,$A0,$00,$00,$1A,$90,$2E,$B1,$51,$B4,$C4,$B1,$79,$6B,$99
        DEFB $E2,$A3,$29,$98,$6C,$D1,$B2,$8D,$9C,$C3,$31,$E4,$78,$B2,$E6,$9F
        DEFB $39,$EA,$00,$FF,$52,$01,$D5,$87,$B8,$67,$C9,$1F,$33,$08,$C3,$93
        DEFB $31,$4D,$92,$2E,$E7,$CF,$1A,$BC,$F4,$D6,$43,$93,$8F,$5E,$39,$7C
        DEFB $2A,$40,$00,$65,$36,$16,$E0,$CF,$9C,$6F,$F1,$D9,$AA,$0E,$6F,$3F
        DEFB $38,$F7,$63,$67,$A7,$0E,$74,$A4,$30,$61,$33,$0A,$38,$1C,$F0,$71
        DEFB $00,$02,$49,$56,$00,$00,$98,$5F,$38,$38,$E0,$C1,$28,$E7,$4C,$0E
        DEFB $06,$31,$81,$11,$9C,$C6,$62,$18,$FA,$36,$20,$48,$19,$8E,$C3,$80
        DEFB $00,$37,$FF,$FF,$B0,$00,$06,$0F,$31,$19,$CC,$62,$68,$BD,$96,$E2
        DEFB $3B,$98,$10,$F1,$43,$63,$8A,$74,$0F,$5E,$49,$F1,$03,$14,$80,$07
        DEFB $FF,$FE,$94,$66,$80,$01,$C4,$E2,$8E,$84,$31,$E6,$1F,$F0,$82,$85
        DEFB $8C,$48,$B6,$66,$69,$99,$C6,$D4,$5B,$79,$AC,$C9,$0E,$16,$00,$7F
        DEFB $FF,$50,$86,$F8,$00,$90,$CC,$E3,$66,$99,$B0,$36,$E6,$B3,$99,$CE
        DEFB $6A,$FC,$39,$31,$CC,$8C,$14,$89,$FC,$28,$E0,$D8,$E0,$07,$FF,$45
        DEFB $86,$80,$12,$74,$87,$16,$91,$28,$A6,$D1,$61,$CC,$8C,$6F,$FE,$D9
        DEFB $93,$63,$18,$48,$89,$E6,$51,$39,$61,$40,$0F,$FF,$10,$69,$C0,$0D
        DEFB $36,$49,$92,$63,$24,$43,$99,$16,$65,$97,$BD,$03,$CE,$BE,$39,$70
        DEFB $C8,$15,$43,$97,$1E,$C6,$80,$3C,$08,$90,$00,$08,$02,$20,$F8,$08
        DEFB $8D,$78,$E9,$E3,$A0,$67,$9C,$40,$25,$72,$F7,$80,$88,$47,$18,$9D
        DEFB $E8,$B6,$53,$E1,$CE,$4F,$2A,$00,$FF,$F7,$6F,$EB,$EF,$ED,$BF,$FE
        DEFB $03,$56,$66,$73,$91,$9D,$1F,$87,$39,$1C,$F8,$24,$DC,$33,$39,$8C
        DEFB $C4,$9A,$A9,$68,$DC,$43,$88,$02,$C1,$14,$44,$89,$12,$29,$11,$16
        DEFB $80,$A1,$C2,$3B,$10,$70,$E3,$C3,$71,$0C,$C0,$00,$2B,$AF,$E2,$06
        DEFB $44,$CA,$33,$C4,$70,$A2,$50,$0F,$BE,$E5,$B5,$5D,$66,$56,$CF,$67
        DEFB $C0,$19,$C2,$14,$C1,$20,$4B,$41,$C2,$4E,$80,$00,$01,$91,$CE,$B3
        DEFB $34,$66,$23,$B1,$33,$4C,$50,$3F,$FF,$90,$20,$F0,$20,$B6,$CC,$F9
        DEFB $8D,$97,$68,$CE,$87,$10,$FF,$00,$64,$32,$C7,$98,$94,$98,$CC,$71
        DEFB $BA,$C0,$FF,$24,$06,$FC,$0E,$6C,$8F,$21,$32,$43,$11,$62,$98,$47
        DEFB $FF,$00,$1D,$30,$CC,$C4,$9A,$5B,$C6,$8C,$71,$01,$EC,$91,$30,$E0
        DEFB $C9,$24,$A8,$B1,$34,$DE,$04,$92,$B3,$21,$6A,$77,$4B,$30,$C0,$17
        DEFB $69,$00,$05,$8E,$38,$76,$80,$92,$2F,$63,$8F,$63,$03,$E0,$10,$00
        DEFB $17,$1F,$01,$98,$F1,$C9,$E8,$9E,$AE,$1D,$52,$18,$5A,$20,$54,$89
        DEFB $C7,$72,$38,$F8,$05,$E7,$23,$8A,$07,$6B,$66,$CD,$9B,$36,$DB,$36
        DEFB $6E,$D7,$8F,$C1,$4E,$CC,$F1,$D0,$1F,$CC,$8F,$00,$CD,$97,$53,$71
        DEFB $E1,$18,$84,$99,$66,$31,$90,$1F,$F9,$F7,$EF,$9F,$7E,$7D,$F3,$E7
        DEFB $CF,$1F,$E0,$23,$84,$61,$29,$43,$98,$86,$A3,$EF,$BF,$9A,$63,$28
        DEFB $CB,$4C,$17,$C9,$6A,$33,$28,$1F,$77,$F3,$D7,$FF,$BF,$76,$B6,$B4
        DEFB $7F,$13,$53,$45,$33,$30,$B6,$D2,$62,$4B,$E7,$DE,$8A,$C1,$1C,$DB
        DEFB $5D,$4A,$0B,$F9,$AE,$20,$3F,$FE,$A2,$81,$EF,$52,$BF,$FC,$FB,$CF
        DEFB $B8,$09,$E8,$19,$48,$27,$E6,$EA,$0F,$FD,$25,$A1,$00,$0B,$60,$0C
        DEFB $F4,$29,$EC,$E9,$A0,$7E,$FF,$3E,$79,$46,$1F,$9E,$7C,$F9,$EF,$FC
        DEFB $10,$8C,$91,$48,$93,$F9,$19,$9E,$DF,$82,$01,$04,$99,$B8,$18,$87
        DEFB $C6,$A8,$81,$FB,$6E,$A5,$CA,$0D,$93,$86,$8F,$1E,$3C,$DD,$B6,$0C
        DEFB $8C,$63,$31,$66,$9C,$B2,$1F,$3C,$68,$00,$00,$02,$DD,$F0,$C7,$63
        DEFB $63,$B2,$83,$FF,$AC,$C4,$DD,$EA,$B8,$F6,$4A,$F7,$06,$63,$E1,$AC
        DEFB $D7,$D2,$50,$A1,$DA,$7F,$3E,$17,$3C,$C4,$A6,$31,$E1,$D2,$87,$6E
        DEFB $F7,$EE,$CF,$B6,$C4,$C3,$13,$DF,$96,$BF,$82,$B3,$81,$88,$8B,$C3
        DEFB $64,$6E,$5E,$C0,$84,$A0,$0C,$84,$98,$89,$A8,$F1,$0E,$3E,$F1,$E7
        DEFB $4B,$FE,$CD,$99,$FB,$C7,$4F,$0F,$F9,$C1,$32,$91,$31,$67,$33,$69
        DEFB $E7,$87,$9D,$90,$7F,$99,$CF,$74,$B6,$3D,$C8,$66,$1F,$7B,$6B,$F3
        DEFB $EF,$EF,$0A,$F3,$AF,$DE,$B6,$71,$1D,$11,$6D,$95,$C1,$C1,$F9,$E9
        DEFB $CE,$C0,$2C,$E6,$9C,$F2,$27,$D6,$60,$6A,$C7,$7C,$31,$FB,$00,$9A
        DEFB $F9,$FE,$F9,$DF,$03,$F1,$8C,$F1,$E0,$3F,$18,$83,$7F,$E8,$BF,$C0
        DEFB $4A,$26,$8C,$E8,$0B,$88,$4C,$17,$AA,$EF,$3E,$A6,$F0,$00,$3F,$7C
        DEFB $92,$ED,$BF,$C0,$CF,$21,$D0,$86,$29,$17,$3E,$7D,$FB,$67,$32,$E4
        DEFB $96,$2B,$7F,$90,$6C,$41,$9D,$79,$8B,$C1,$59,$07,$FF,$7C,$EE,$F3
        DEFB $E0,$47,$93,$2A,$82,$43,$87,$9E,$3F,$FC,$86,$13,$76,$18,$99,$E7
        DEFB $CC,$8F,$7D,$0A,$B6,$A2,$43,$12,$FF,$B7,$F8,$54,$E9,$30,$E7,$DF
        DEFB $17,$BF,$AE,$DF,$FF,$5B,$31,$30,$C8,$13,$67,$88,$7E,$2F,$87,$E0
        DEFB $E7,$A1,$3E,$7E,$9F,$8B,$FC,$FC,$26,$61,$50,$57,$8E,$03,$F7,$AB
        DEFB $C0,$85,$82,$4D,$98,$D4,$11,$E3,$18,$BE,$2D,$61,$CF,$C0,$0A,$1D
        DEFB $8F,$1D,$B8,$06,$31,$31,$80,$13,$98,$4D,$E7,$D7,$FD,$60,$7F,$68
        DEFB $CC,$9E,$69,$F9,$21,$DF,$73,$ED,$02,$6C,$FE,$80,$BF,$EE,$B6,$76
        DEFB $0B,$11,$7A,$AD,$E2,$4C,$1F,$03,$C0,$20,$60,$A2,$29,$FA,$31,$F7
        DEFB $BE,$7F,$7F,$00,$94,$98,$03,$F9,$AE,$BF,$DF,$29,$99,$38,$E6,$F0
        DEFB $9F,$7F,$80,$00,$48,$6C,$98,$54,$A3,$6E,$A3,$EB,$3F,$EF,$7C,$6A
        DEFB $01,$02,$E7,$FB,$9F,$11,$B1,$85,$16,$98,$88,$7E,$00,$21,$21,$65
        DEFB $78,$A7,$31,$E6,$43,$F3,$FB,$EE,$FC,$90,$86,$00,$FC,$FE,$B3,$FE
        DEFB $19,$E1,$51,$47,$89,$0F,$FC,$12,$66,$68,$94,$59,$E2,$61,$FF,$B6
        DEFB $6F,$F8,$49,$89,$7F,$DF,$BF,$21,$C1,$7D,$33,$C9,$1F,$F8,$84,$92
        DEFB $30,$60,$F2,$27,$E6,$80,$FE,$3F,$F3,$E0,$16,$37,$0D,$FC,$F8,$04
        DEFB $91,$E0,$BD,$98,$BB,$F0,$18,$49,$B3,$64,$F4,$4F,$84,$C0,$7E,$7D
        DEFB $77,$60,$21,$61,$1F,$9F,$B9,$F0,$0C,$99,$A8,$1E,$94,$33,$60,$84
        DEFB $92,$70,$34,$88,$89,$CE,$40,$3F,$6F,$EF,$C0,$69,$0F,$EE,$B7,$61
        DEFB $0A,$C9,$20,$47,$64,$7F,$C0,$92,$3D,$74,$96,$51,$DA,$80,$88,$7B
        DEFB $7E,$08,$19,$CF,$FF,$E0,$05,$71,$15,$C3,$33,$3F,$21,$25,$79,$1C
        DEFB $48,$15,$C9,$40,$1F,$BD,$EF,$80,$D6,$80,$87,$0C,$E1,$E8,$2F,$B2
        DEFB $78,$03,$C0,$82,$78,$94,$F4,$17,$AA,$80,$AF,$02,$6E,$06,$FF,$B7
        DEFB $81,$19,$30,$1D,$30,$6F,$80,$24,$A2,$34,$D7,$71,$A9,$80,$0B,$6F
        DEFB $00,$49,$B1,$07,$CF,$7E,$8D,$BF,$2A,$E7,$5B,$46,$88,$C0,$69,$7D
        DEFB $10,$98,$19,$C9,$80,$0F,$3F,$7F,$8A,$EF,$BE,$49,$07,$C1,$30,$A3
        DEFB $74,$7F,$60,$88,$BC,$D7,$63,$B8,$96,$77,$FE,$29,$03,$D7,$25,$80
        DEFB $00,$73,$96,$0E,$64,$92,$3C,$18,$20,$11,$F0,$00,$A0,$FE,$26,$01
        DEFB $FE,$FF,$21,$92,$30,$08,$27,$40,$FF,$1A,$7C,$0C,$9E,$B9,$B0,$65
        DEFB $07,$BF,$76,$98,$03,$FF,$BD,$82,$39,$F1,$E7,$60,$58,$C2,$7E,$1C
        DEFB $D4,$E2,$81,$F7,$F6,$58,$89,$03,$EF,$27,$01,$73,$FF,$FE,$E3,$F7
        DEFB $55,$55,$80
INTRO_Z1:
        DEFB $89,$00,$A4,$3F,$4C,$00,$92,$33,$00,$0F,$FE,$F7,$00,$5A,$03,$7F
        DEFB $BD,$80,$03,$70,$00,$F2,$69,$DE,$3A,$7E,$2C,$C1,$16,$99,$01,$DF
        DEFB $F0,$38,$DF,$A2,$FB,$FC,$01,$74,$22,$61,$F8,$48,$7B,$7F,$1F,$FF
        DEFB $FF,$BA,$95,$FD,$CE,$E2,$DD,$B8,$EF,$C1,$64,$7F,$FF,$FF,$E2,$FC
        DEFB $88,$65,$4F,$A2,$F4,$20,$C2,$3C,$22,$F4,$1F,$88,$00,$5F,$BF,$C7
        DEFB $DE,$EB,$00,$80,$E2,$FF,$41,$B5,$70,$02,$3E,$76,$D8,$DE,$25,$00
        DEFB $05,$8E,$7F,$E0,$F3,$8B,$40,$FF,$DF,$00,$DF,$FA,$2C,$DF,$9F,$59
        DEFB $FC,$7F,$F3,$BF,$09,$C0,$3B,$0E,$B8,$01,$FB,$C0,$20,$8A,$62,$40
        DEFB $04,$E0,$FE,$7C,$1E,$A2,$BC,$28,$28,$40,$F2,$9D,$B0,$80,$66,$F2
        DEFB $24,$90,$20,$EF,$70,$22,$7B,$DC,$26,$2D,$41,$0B,$06,$62,$F2,$D6
        DEFB $D6,$E1,$01,$40,$A6,$3F,$60,$76,$BD,$69,$60,$F5,$F9,$BB,$BA,$D0
        DEFB $00,$98,$36,$AF,$BB,$62,$02,$E0,$86,$10,$64,$4A,$4B,$F0,$22,$03
        DEFB $60,$5C,$A2,$37,$F0,$6F,$2A,$D1,$51,$DE,$8E,$05,$28,$DD,$63,$03
        DEFB $55,$68,$D2,$FE,$73,$35,$AA,$57,$D3,$EA,$40,$1C,$18,$07,$F1,$55
        DEFB $2B,$70,$89,$1F,$C0,$39,$EC,$83,$3A,$AB,$22,$9F,$E2,$C0,$10,$0A
        DEFB $86,$0F,$FB,$AA,$D7,$E0,$68,$E0,$1A,$E0,$21,$82,$1A,$AC,$BF,$7F
        DEFB $80,$A0,$07,$80,$07,$F8,$D5,$57,$66,$1B,$52,$7E,$1A,$20,$20,$98
        DEFB $01,$E0,$3F,$FE,$80,$07,$80,$F9,$DB,$0D,$8F,$1E,$FF,$D0,$80,$B3
        DEFB $03,$0B,$9B,$0E,$03,$F9,$F6,$EC,$6B,$0C,$E2,$80,$87,$80,$FF,$4E
        DEFB $80,$39,$EC,$68,$3E,$D6,$8E,$99,$C3,$40,$03,$2E,$0F,$C0,$08,$84
        DEFB $0F,$C0,$F8,$85,$FD,$3C,$F0,$35,$5B,$80,$C0,$3A,$80,$64,$07,$D6
        DEFB $F0,$8D,$01,$A0,$99,$C1,$7F,$FF,$C0,$A0,$00,$68,$83,$AA,$07,$F8
        DEFB $D9,$E6,$E3,$C0,$68,$81,$3F,$5D,$DF,$D9,$39,$C0,$3A,$81,$90,$29
        DEFB $3F,$A4,$7F,$3A,$C1,$0F,$5A,$0C,$A4,$A0,$A1,$3F,$68,$01,$49,$8F
        DEFB $8E,$03,$90,$67,$B6,$DF,$1C,$40,$5B,$70,$D7,$13,$23,$8A,$80,$04
        DEFB $A2,$40,$CF,$02,$9E,$E5,$81,$C0,$B5,$01,$F7,$8C,$80,$7B,$F0,$70
        DEFB $C0,$BB,$81,$DC,$CA,$C0,$00,$A6,$D0,$9D,$1C,$97,$C0,$A9,$C0,$07
        DEFB $CE,$C0,$B9,$11,$01,$91,$01,$FE,$00,$CE,$9D,$CD,$B6,$7F,$40,$6B
        DEFB $39,$A8,$C0,$FC,$AA,$0C,$00,$06,$97,$81,$E2,$40,$11,$C0,$6E,$5C
        DEFB $81,$90,$0E,$A2,$F8,$D9,$17,$C0,$33,$67,$A5,$81,$1E,$2A,$01,$93
        DEFB $C0,$3A,$E9,$C1,$03,$A4,$80,$62,$00,$E0,$33,$1B,$8A,$80,$46,$76
        DEFB $C1,$91,$7F,$E8,$ED,$E0,$B9,$2F,$80,$B3,$86,$80,$D6,$24,$3C,$80
        DEFB $77,$00,$6A,$06,$DF,$C0,$80,$31,$C0,$B7,$83,$80,$DD,$C0,$B7,$50
        DEFB $00,$F1,$80,$B6,$03,$40,$4B,$19,$3A,$C0,$FC,$13,$38,$C9,$81,$81
        DEFB $80,$C0,$8C,$80,$1B,$F2,$00,$C0,$48,$8C,$07,$EC,$7B,$5C,$1F,$37
        DEFB $00,$E9,$C0,$FE,$DC,$80,$88,$07,$BE,$39,$00,$38,$80,$A1,$02,$A6
        DEFB $02,$24,$00,$D7,$BD,$5F,$C0,$BD,$80,$40,$E8,$01,$1D,$29,$E6,$FA
        DEFB $40,$80,$5A,$B0,$28,$01,$6A,$00,$98,$6D,$91,$01,$B8,$8E,$41,$03
        DEFB $80,$4B,$5D,$7A,$C0,$F8,$4A,$3F,$4A,$01,$A6,$D0,$E6,$7C,$80,$22
        DEFB $EE,$10,$26,$03,$7C,$8A,$C0,$4F,$5F,$01,$61,$80,$A6,$A7,$24,$02
        DEFB $7E,$F0,$81,$DC,$C0,$DD,$C0,$A0,$81,$B6,$A5,$7E,$A5,$80,$D3,$80
        DEFB $EA,$80,$08,$22,$01,$94,$7C,$69,$CC,$80,$97,$C0,$A9,$80,$08,$A0
        DEFB $D8,$A7,$FF,$47,$36,$C7,$C0,$29,$03,$7B,$D4,$F2,$33,$C0,$B2,$80
        DEFB $C0,$19,$87,$1B,$50,$00,$EF,$D4,$1E,$ED,$A5,$81,$7F,$F7,$01,$C0
        DEFB $89,$0F,$FD,$7E,$D4,$3F,$13,$F0,$CE,$C2,$80,$6E,$7F,$F7,$20,$C1
        DEFB $92,$7E,$9B,$0B,$20,$E5,$8F,$00,$9E,$38,$05,$00,$80,$18,$89,$0F
        DEFB $E0,$9D,$7A,$3F,$80,$DE,$00,$D5,$B5,$C0,$22,$01,$01,$7C,$1F,$E7
        DEFB $A8,$C0,$6B,$D4,$8A,$00,$7F,$4B,$60,$6E,$3C,$C1,$93,$FE,$EE,$CE
        DEFB $19,$81,$87,$0F,$9A,$C0,$00,$09,$81,$00,$FC,$18,$89,$1C,$1F,$22
        DEFB $7F,$80,$12,$A9,$01,$3C,$3A,$40,$97,$10,$A5,$81,$7E,$D0,$92,$01
        DEFB $78,$FE,$3E,$10,$8A,$7F,$F8,$80,$88,$22,$20,$29,$1F,$E1,$52,$44
        DEFB $26,$5F,$00,$FF,$82,$94,$92,$00,$88,$02,$87,$F8,$7C,$FF,$FF,$05
        DEFB $10,$1F,$E5,$55,$1F,$E2,$55,$88,$40,$69,$9F,$E0,$49,$29,$24,$39
        DEFB $88,$FF,$A8,$62,$4A,$D0,$83,$B4,$1E,$47,$F1,$21,$FF,$0A,$86,$E7
        DEFB $1F,$E6,$AA,$5F,$C9,$55,$6B,$54,$0F,$D5,$1F,$C5,$6A,$AA,$D8,$BF
        DEFB $15,$7F,$62,$3D,$B5,$6F,$08,$B4,$38,$02,$DC,$90,$2A,$E6,$7D,$C0
        DEFB $15,$DD,$7F,$E6,$B6,$D6,$BD,$1F,$8A,$C0,$1A,$3F,$FF,$6E,$7F,$95
        DEFB $00,$A7,$8B,$FF,$BF,$07,$9E,$D5,$5D,$3C,$41,$40,$D5,$F1,$86,$8D
        DEFB $9A,$50,$AF,$EA,$DB,$7B,$4A,$2F,$C9,$6B,$6C,$24,$A5,$54,$1F,$32
        DEFB $AE,$FB,$44,$24,$D1,$55,$60
INTRO_Z2:
        DEFB $5A,$00,$10,$A0,$00,$80,$9C,$FF,$02,$F8,$00,$04,$00,$08,$7F,$C0
        DEFB $00,$21,$88,$0F,$C0,$08,$80,$00,$96,$7F,$00,$0E,$4A,$00,$02,$88
        DEFB $C0,$8A,$10,$00,$61,$01,$BF,$E0,$E8,$C7,$84,$A6,$1F,$4A,$10,$02
        DEFB $44,$03,$80,$3F,$38,$FC,$84,$C1,$4A,$3D,$C8,$62,$AA,$55,$8F,$F1
        DEFB $14,$A9,$51,$0E,$E5,$21,$36,$C7,$D9,$29,$5F,$8B,$5E,$7F,$FF,$AB
        DEFB $FB,$0F,$FF,$D4,$AA,$A8,$00,$FF,$FE,$1D,$57,$BF,$F7,$FA,$41,$B1
        DEFB $FD,$E7,$81,$39,$FF,$F1,$25,$01,$05,$3F,$00,$49,$54,$94,$A8,$15
        DEFB $7F,$FD,$6D,$51,$42,$E0,$43,$E2,$02,$B5,$7F,$C1,$52,$BF,$48,$28
        DEFB $F9,$32,$FD,$6A,$46,$B4,$2B,$2A,$A5,$54,$0D,$FC,$42,$10,$A4,$20
        DEFB $11,$7C,$71,$B4,$B3,$14,$22,$47,$58,$1F,$68,$F7,$91,$36,$FC,$B0
        DEFB $AA,$D8,$5F,$1A,$14,$D5,$76,$F7,$82,$F0,$00,$01,$1B,$58,$01,$FC
        DEFB $02,$AB,$4D,$D1,$2C,$44,$A5,$A0,$C0,$A2,$07,$47,$FC,$48,$24,$44
        DEFB $3F,$80,$02,$52,$92,$8A,$81,$E1,$30,$85,$BF,$DA,$54,$80,$7C,$02
        DEFB $55,$43,$36,$BC,$22,$4E,$B0,$40,$09,$0B,$E0,$00,$FE,$A4,$5F,$9A
        DEFB $AB,$63,$C4,$16,$01,$50,$FE,$0A,$2A,$20,$CA,$7D,$C5,$72,$50,$6E
        DEFB $03,$C1,$52,$7F,$02,$05,$50,$3F,$05,$40,$54,$AA,$54,$38,$15,$9F
        DEFB $F9,$F6,$BF,$3D,$5E,$05,$B9,$6D,$7A,$8F,$1D,$BC,$C1,$B9,$07,$1B
        DEFB $02,$BF,$9A,$AD,$EE,$BF,$9B,$74,$BF,$77,$FF,$DD,$4C,$1F,$F9,$8E
        DEFB $F0,$00,$FC,$01,$04,$AE,$1A,$39,$0A,$B8,$AA,$41,$88,$05,$01,$28
        DEFB $9F,$8A,$12,$08,$53,$24,$96,$01,$48,$01,$42,$AC,$FC,$3C,$7F,$F9
        DEFB $A0,$FC,$08,$A2,$51,$94,$32,$07,$C0,$30,$01,$E8,$A9,$C0,$12,$3F
        DEFB $C1,$A2,$C6,$1F,$8A,$52,$85,$4F,$6A,$2A,$61,$F9,$CF,$3F,$F0,$50
        DEFB $FE,$92,$08,$55,$08,$73,$10,$D2,$8A,$14,$AE,$01,$0B,$06,$F0,$16
        DEFB $0F,$EA,$48,$F2,$7F,$29,$AD,$42,$B1,$55,$AA,$87,$C1,$C7,$BF,$F6
        DEFB $38,$FC,$06,$30,$1A,$90,$E4,$78,$FE,$3C,$3E,$47,$80,$1F,$E6,$1F
        DEFB $CF,$F1,$59,$28,$1F,$96,$55,$71,$15,$9A,$DB,$8F,$01,$C3,$CF,$FF
        DEFB $2C,$FE,$42,$1A,$8D,$88,$CC,$31,$FA,$00,$15,$65,$00,$7D,$DC,$00
        DEFB $A7,$5C,$65,$97,$41,$88,$40,$0A,$40,$00,$1C,$F7,$5A,$46,$06,$80
        DEFB $7E,$E3,$44,$54,$83,$CC,$07,$A0,$E8,$00,$A3,$00,$30,$17,$F8,$66
        DEFB $00,$88,$40,$E8,$3C,$E7,$C0,$68,$C8,$FC,$C0,$80,$09,$CA,$98,$01
        DEFB $D2,$26,$50,$02,$E1,$11,$21,$75,$14,$3F,$82,$52,$9C,$02,$AA,$D5
        DEFB $7E,$63,$8B,$96,$07,$D0,$FE,$30,$0A,$05,$07,$90,$F5,$65,$BA,$02
        DEFB $C0,$0A,$09,$FE,$69,$9E,$12,$1B,$5E,$D6,$C1,$DF,$7E,$FE,$06,$07
        DEFB $F3,$A8,$C9,$62,$18,$04,$00,$90,$30,$8A,$0C,$04,$6A,$05,$46,$2A
        DEFB $80,$5F,$94,$A2,$AB,$50,$61,$02,$1F,$CE,$3F,$C1,$8E,$E0,$7C,$D1
        DEFB $6E,$11,$22,$70,$FE,$09,$4E,$7F,$24,$06,$1F,$02,$9A,$51,$5A,$14
        DEFB $B5,$07,$F6,$7F,$01,$C1,$A0,$FC,$81,$7A,$0D,$19,$A0,$A9,$34,$08
        DEFB $8D,$61,$3F,$99,$49,$55,$54,$0F,$54,$87,$F1,$FC,$96,$E9,$7E,$FF
        DEFB $FF,$C1,$4F,$40,$06,$A2,$02,$C4,$A0,$8E,$24,$AA,$FF,$52,$88,$AB
        DEFB $10,$FF,$F0,$57,$C7,$0C,$FE,$FF,$F7,$C0,$22,$00,$12,$13,$3F,$E2
        DEFB $B8,$3F,$92,$AA,$A5,$55,$60,$96,$8E,$EB,$C0,$0F,$CF,$8A,$7E,$0A
        DEFB $80,$AE,$15,$52,$49,$25,$2A,$49,$24,$A4,$A9,$C0,$D8,$01,$E4,$02
        DEFB $95,$41,$D6,$A0,$A8,$58,$1F,$07,$0A,$DB,$AA,$FC,$10,$46,$90,$0B
        DEFB $DD,$F6,$DA,$D5,$B6,$DB,$5B,$7D,$B6,$F6,$1F,$D7,$81,$8C,$2E,$2F
        DEFB $D9,$0E,$F0,$EF,$C1,$20,$FD,$78,$F1,$FE,$6F,$F1,$7B,$2E,$E2,$D9
        DEFB $02,$02,$D7,$D0,$F9,$EB,$DF,$D8,$7F,$63,$EF,$F7,$92,$C0,$2B,$FC
        DEFB $DA,$0B,$A2,$D8,$DA,$07,$A6,$F9,$BD,$FE,$FE,$63,$FE,$54,$30,$C1
        DEFB $E0,$48,$0E,$A0,$FE,$F8,$F7,$7F,$BD,$E8,$FD,$BB,$BF,$FF,$7F,$FE
        DEFB $A9,$4A,$AA,$FE,$75,$83,$4B,$70,$A4,$3F,$12,$67,$EB,$6F,$55,$58
        DEFB $E7,$B9,$00,$D7,$FE,$19,$41,$56,$09,$49,$49,$50,$A9,$A8,$13,$56
        DEFB $B5,$AA,$A5,$58,$FE,$2A,$D5,$55,$B5,$AB,$B1,$B5,$AB,$56,$DB,$6A
        DEFB $D7,$46,$DA,$D5,$6A,$0E,$AA,$94,$E8,$A5,$2A,$AA,$95,$54,$AA,$55
        DEFB $2A,$85,$52,$AB,$13,$7E,$45,$E6,$A1,$2A,$90,$38,$54,$A9,$24,$95
        DEFB $29,$02,$4A,$25,$14,$E2,$81,$CC,$14,$A5,$7D,$85,$FB,$78,$A8,$84
        DEFB $50,$29,$48,$48,$FC,$50,$49,$24,$48,$90,$A0,$C4,$22,$44,$89,$22
        DEFB $45,$83,$21,$50,$42,$93,$E1,$3F,$8B,$87,$17,$A4,$4A,$94,$B7,$7B
        DEFB $AF,$D6,$B6,$C0,$FE,$AF,$B6,$DB,$B6,$D7,$41,$3B,$DD,$BB,$76,$DD
        DEFB $BA,$A0,$DE,$AF,$BB,$5A,$D4,$5F,$00,$AF,$77,$5B,$F6,$EB,$49,$4A
        DEFB $B4,$AA,$AA,$A1,$7C,$40,$78,$8C,$2E,$04,$0A,$52,$A5,$FB,$A1,$08
        DEFB $76,$A8,$A8,$A5,$54,$3F,$00,$69,$94,$AD,$15,$56,$80,$5A,$30,$4B
        DEFB $0D,$88,$F2,$86,$3F,$9A,$3A,$24,$80,$C0,$66,$09,$7E,$0A,$61,$22
        DEFB $14,$40,$A8,$12,$9D,$02,$02,$71,$DB,$AC,$E1,$88,$8E,$A4,$01,$CE
        DEFB $F5,$7E,$21,$44,$BF,$A1,$90,$EF,$01,$DF,$F0,$E5,$89,$28,$24,$44
        DEFB $A2,$81,$7C,$08,$24,$94,$A4,$88,$C3,$4A,$52,$4A,$7A,$12,$92,$A1
        DEFB $49,$10,$52,$57,$3F,$91,$41,$24,$24,$21,$2A,$B5,$54,$92,$92,$48
        DEFB $08,$FE,$4B,$97,$CD,$52,$55,$85,$21,$09,$21,$6D,$2D,$37,$58,$87
        DEFB $B7,$6D,$92,$2A,$7F,$10,$27,$DB,$92,$94,$91,$2A,$1B,$DA,$07,$AD
        DEFB $11,$7C,$4A,$95,$51,$2A,$A5,$44,$BD,$EA,$71,$1B,$A3,$5A,$C9,$CF
        DEFB $AD,$CE,$1F,$9C,$1D,$C1,$FF,$2F,$51,$25,$E9,$3B,$41,$F7,$55,$B7
        DEFB $BB,$8C,$55,$4E,$57,$F9,$CB,$98,$29,$59,$9C,$D9,$7F,$05,$0A,$E2
        DEFB $83,$21,$AA,$94,$8C,$24,$90,$8E,$81,$88,$92,$E9,$2F,$54,$86,$C7
        DEFB $27,$5D,$25,$4C,$49,$2C,$79,$49,$27,$01,$12,$82,$92,$D3,$C3,$2B
        DEFB $90,$FE,$55,$35,$55,$58
; ======== end _intro.inc ========

PROG_END:
SHADOW      EQU PROG_END    ; 2 KB RAM copy of one bank (64 lines x 32 bytes) right after the program: cells are composed here, not saved in the .VZ

