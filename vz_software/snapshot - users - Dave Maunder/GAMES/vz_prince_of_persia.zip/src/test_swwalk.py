import re,sys,hashlib,json
from z80 import Z80Machine
base="pop12"
sym={}
for ln in open(base+".sym"):
    m_=re.match(r"(\w+)\s+EQU\s+([0-9A-F]+)H",ln.strip())
    if m_: sym[m_.group(1)]=int(m_.group(2),16)
m=Z80Machine()
m.set_memory_block(0x7B00,open(base+".bin","rb").read())
m.memory[sym["TITLE_SCREEN"]]=0xC9; m.memory[sym["INTRO_SCREEN"]]=0xC9
for a in (0x68FE,0x68FD,0x68FB,0x68F7,0x68EF,0x68DF,0x68BF,0x687F): m.memory[a]=0xFF
m.pc=0x7B00; m.sp=0x8000
SETB=sym["SET_BANK"]; FD=sym["FRAME_DONE"]
m.set_breakpoint(SETB); m.set_breakpoint(FD)
banks=[bytearray(2048) for _ in range(3)]
def poke(n,v): m.memory[sym[n]]=v
def keys(left=False,right=False,a=False,d=False,s=False):
    v=0xFF
    if left: v&=~(1<<4)
    if right: v&=~(1<<1)
    m.memory[0x68FB]=v
    w=0xFF
    if a: w&=~(1<<4)
    if d: w&=~(1<<3)
    if s: w&=~(1<<1)
    m.memory[0x68FD]=w
chunk=0; ticks=0
def pump():
    global chunk,ticks
    for _ in range(600000):
        chunk+=1
        m.memory[0x6800]=0x80 if chunk&1 else 0x00
        m.ticks_to_stop=1500
        m.run()
        ticks+=1500-max(0,m.ticks_to_stop) if False else 0
        if m.pc==SETB:
            old=m.memory[sym["CUR_BANK"]]; new=m.a
            banks[old][:]=bytes(m.memory[0x7000:0x7800]); m.memory[0x7000:0x7800]=bytes(banks[new])
            m.step_over_breakpoint()
        elif m.pc==FD:
            m.step_over_breakpoint(); return
    raise SystemExit("never finished")
def vram():
    cur=m.memory[sym["CUR_BANK"]]; banks[cur][:]=bytes(m.memory[0x7000:0x7800])
    return b"".join(bytes(b) for b in banks)
pump()
def run(n,**k):
    out=[]
    for _ in range(n):
        keys(**k); pump(); out.append(m.memory[sym["PFRAME"]])
    return out
FR=dict(GARDE=9,ADV=10,RETREAT=16,SWA=35,SWB=36)
def setup(face):
    for n,v in (("PX",100),("PY",82),("PFACE",face),("PFRAME",9),("PROW",1),("PSTATE",0),("PFS",0),("PSWORD",1),("PHP",3),("PTMR",0),
                ("G_ACTIVE",1),("GX",200),("GY",82),("GFACE",1 if face==0 else 0),("GFRAME",9),("GFS",0),("GHP",3),("GTMR",0),("GROW",0),("JPREV",0),("DPREV",0)):
        poke(n,v)
    keys()
# guard far away to the right; prince faces right, walks right (advance) then left (retreat)
setup(0); pump()
fw=run(6,right=True); x1=m.memory[sym["PX"]]
print("advance frames:",fw)
assert FR["SWA"] in fw and FR["SWB"] in fw and FR["ADV"] in fw and FR["GARDE"] in fw, "advance cycle must show ADV, SWA, GARDE, SWB"
assert not any(fw[i]==fw[i+1] for i in range(len(fw)-1)), "every step frame must differ from the last"
setup(0); pump(); x1=m.memory[sym["PX"]]
bw=run(6,left=True); x2=m.memory[sym["PX"]]
print("retreat frames:",bw)
assert FR["SWA"] in bw and FR["SWB"] in bw and FR["RETREAT"] in bw and FR["GARDE"] in bw, "retreat cycle must show RETREAT, SWA, GARDE, SWB"
assert x2<x1, "retreat moves left"
assert not any(bw[i]==bw[i+1] for i in range(len(bw)-1)), "retreat frames animate too"
st=run(2); print("released:",st); assert st[-1]==FR["GARDE"], "back to en garde when the key is let go"
assert m.memory[sym["PSWORD"]]==1
print("ALL SWORD-WALK TESTS OK")
