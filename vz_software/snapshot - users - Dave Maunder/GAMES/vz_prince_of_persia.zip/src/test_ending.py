import re
from z80 import Z80Machine
from PIL import Image
sym={}
for ln in open("pop12.sym"):
    m_=re.match(r"(\w+)\s+EQU\s+([0-9A-F]+)H",ln.strip())
    if m_: sym[m_.group(1)]=int(m_.group(2),16)
m=Z80Machine()
print("tick attrs:",[n for n in dir(m) if 'tick' in n.lower()])
m.set_memory_block(0x7B00,open("pop12.bin","rb").read())
m.memory[sym["TITLE_SCREEN"]]=0xC9   # tests start in the game, not on the title
m.memory[sym["INTRO_SCREEN"]]=0xC9   # ... nor on the intro picture
for a in (0x68FE,0x68FD,0x68FB,0x68F7,0x68EF,0x68DF,0x68BF,0x687F): m.memory[a]=0xFF
m.pc=0x7B00; m.sp=0x8000
SETB=sym["SET_BANK"]; FD=sym["FRAME_DONE"]
m.set_breakpoint(SETB); m.set_breakpoint(FD)
banks=[bytearray(2048) for _ in range(3)]
def mem(n): return m.memory[sym[n]]
def poke(n,v): m.memory[sym[n]]=v
def keys(left=False,right=False,a=False,d=False,s=False):
    v=0xFF
    if left:  v&=~(1<<4)
    if right: v&=~(1<<1)
    m.memory[0x68FB]=v
    w=0xFF
    if a: w&=~(1<<4)
    if d: w&=~(1<<3)
    if s: w&=~(1<<1)
    m.memory[0x68FD]=w
chunk=0
def pump():
    """run until FRAME_DONE; handle bank switching + fake vsync."""
    global chunk
    for _ in range(600000):
        chunk+=1
        m.memory[0x6800]=0x80 if chunk&1 else 0x00
        m.ticks_to_stop=1500
        m.run()
        if m.pc==SETB:
            old=m.memory[sym["CUR_BANK"]]; new=m.a
            banks[old][:]=bytes(m.memory[0x7000:0x7800]); m.memory[0x7000:0x7800]=bytes(banks[new])
            m.step_over_breakpoint()
        elif m.pc==FD:
            m.step_over_breakpoint(); return
    raise SystemExit("never finished")
def vram():
    cur=m.memory[sym["CUR_BANK"]]; banks[cur][:]=bytes(m.memory[0x7000:0x7800])
    return b"".join(bytes(b) for b in banks)
def lit(v,x,y): return bool(v[y*32+(x>>3)]&(0x80>>(x&7)))
def snap(name,crop=None):
    v=vram(); S=3; im=Image.new("RGB",(256*S,192*S),(0,96,0))
    for y in range(192):
        for x in range(256):
            if lit(v,x,y):
                for dy in range(S):
                    for dx in range(S): im.putpixel((x*S+dx,y*S+dy),(0,255,0))
    if crop: im=im.crop(crop)
    im.save(name)
def ent(base):
    a=sym[base]; k=("x","y","face","frame","fs","fi","hp","tmr","row")
    return {n:m.memory[a+i] for i,n in enumerate(k)}
# ================= finishing the last level: the palace picture + "YOU ESCAPED", then round to level 1 =================
pump()                                                   # game running (intro and title are skipped)
def run_n(n):
    global chunk
    for _ in range(n):
        chunk+=1; m.memory[0x6800]=0x80 if chunk&1 else 0x00; m.ticks_to_stop=1500; m.run()
        if m.pc==SETB:
            old=m.memory[sym["CUR_BANK"]]; new=m.a
            banks[old][:]=bytes(m.memory[0x7000:0x7800]); m.memory[0x7000:0x7800]=bytes(banks[new]); m.step_over_breakpoint()
        elif m.pc==FD: m.step_over_breakpoint()
poke("CUR_LEVEL",2); poke("WINFLAG",1)
fd=sym["FRAME_DONE"]; m.sp-=2; m.memory[m.sp]=fd&255; m.memory[m.sp+1]=fd>>8; m.pc=sym["DO_WIN"]
run_n(2500)
v=vram(); pic=sum(bin(x).count("1") for x in v[:171*32]); cap=sum(bin(x).count("1") for x in v[172*32:190*32])
print("ending screen: picture pixels",pic,"caption pixels",cap); assert 8000<pic<30000 and cap>150
snap("ending.png",(0,0,768,576))
assert mem("WINFLAG")==1                                  # still waiting for A
m.memory[0x68FD]=0xEF; run_n(2500); m.memory[0x68FD]=0xFF   # A pressed
print("after A: WINFLAG",mem("WINFLAG"),"level",mem("CUR_LEVEL")+1); assert mem("WINFLAG")==0 and mem("CUR_LEVEL")==0
print("ALL ENDING TESTS OK")
