import re
from z80 import Z80Machine
from PIL import Image
sym={}
for ln in open("pop12.sym"):
    m_=re.match(r"(\w+)\s+EQU\s+([0-9A-F]+)H",ln.strip())
    if m_: sym[m_.group(1)]=int(m_.group(2),16)
m=Z80Machine()
print("tick attrs:",[n for n in dir(m) if 'tick' in n.lower()])
m.set_memory_block(0x7B00,open("pop12.bin","rb").read())
m.memory[sym["TITLE_SCREEN"]]=0xC9
m.memory[sym["INTRO_SCREEN"]]=0xC9   # ... nor on the intro picture
for a in (0x68FE,0x68FD,0x68FB,0x68F7,0x68EF,0x68DF,0x68BF,0x687F): m.memory[a]=0xFF
m.pc=0x7B00; m.sp=0x8000
SETB=sym["SET_BANK"]; FD=sym["FRAME_DONE"]
m.set_breakpoint(SETB); m.set_breakpoint(FD)
banks=[bytearray(2048) for _ in range(3)]
def mem(n): return m.memory[sym[n]]
def poke(n,v): m.memory[sym[n]]=v
def keys(left=False,right=False,a=False,d=False,s=False):
    v=0xFF
    if left:  v&=~(1<<4)
    if right: v&=~(1<<1)
    m.memory[0x68FB]=v
    w=0xFF
    if a: w&=~(1<<4)
    if d: w&=~(1<<3)
    if s: w&=~(1<<1)
    m.memory[0x68FD]=w
chunk=0
def pump():
    """run until FRAME_DONE; handle bank switching + fake vsync."""
    global chunk
    for _ in range(600000):
        chunk+=1
        m.memory[0x6800]=0x80 if chunk&1 else 0x00
        m.ticks_to_stop=1500
        m.run()
        if m.pc==SETB:
            old=m.memory[sym["CUR_BANK"]]; new=m.a
            banks[old][:]=bytes(m.memory[0x7000:0x7800]); m.memory[0x7000:0x7800]=bytes(banks[new])
            m.step_over_breakpoint()
        elif m.pc==FD:
            m.step_over_breakpoint(); return
    raise SystemExit("never finished")
def vram():
    cur=m.memory[sym["CUR_BANK"]]; banks[cur][:]=bytes(m.memory[0x7000:0x7800])
    return b"".join(bytes(b) for b in banks)
def lit(v,x,y): return bool(v[y*32+(x>>3)]&(0x80>>(x&7)))
def snap(name,crop=None):
    v=vram(); S=3; im=Image.new("RGB",(256*S,192*S),(0,96,0))
    for y in range(192):
        for x in range(256):
            if lit(v,x,y):
                for dy in range(S):
                    for dx in range(S): im.putpixel((x*S+dx,y*S+dy),(0,255,0))
    if crop: im=im.crop(crop)
    im.save(name)
def ent(base):
    a=sym[base]; k=("x","y","face","frame","fs","fi","hp","tmr","row")
    return {n:m.memory[a+i] for i,n in enumerate(k)}
P=lambda: ent("P_ENT"); G=lambda: ent("G_ENT")

pump()
def tele(px=100,gx=124,gro=0,sword=1,php=3,ghp=3):
    for n,v in (("PX",px),("PY",82),("PFACE",0),("PFRAME",0),("PROW",1),("PSTATE",0),("PFS",0),("PSWORD",sword),("PHP",php),("PTMR",0),
                ("GX",gx),("GY",82),("GFACE",1),("GFRAME",9),("GFS",0),("GHP",ghp),("GTMR",0),("GROW",gro),("JPREV",0),("DPREV",0)):
        poke(n,v)
def frames_(n,**k):
    for _ in range(n): keys(**k); pump()

from PIL import Image
RM=sym["ROOM_MAP"]; FL=sym["ROOM_FLAGS"]
def load_room(n):
    m.sp-=2; m.memory[m.sp]=FD&255; m.memory[m.sp+1]=FD>>8; m.a=n; m.pc=sym["LOAD_ROOM"]; pump()
def stage(px,py,row,face=0,hp=3,active=0):
    for n,v in (("PX",px),("PY",py),("PROW",row),("PFACE",face),("PFRAME",0),("PSTATE",0),("PFS",0),("PSWORD",0),("PHP",hp),
                ("JPREV",0),("DPREV",0),("RUNPH",0),("TIDX",0),("LTMR",0),("FALLN",0),("G_ACTIVE",active),("LOOSE_ARM",0)): poke(n,v)
    keys()
def run(n,**k):
    out=[]
    for _ in range(n):
        keys(**k); pump(); out.append((P()["frame"],P()["x"],P()["y"],mem("PSTATE")))
    return out
def room(): return mem("CUR_ROOM")

from PIL import Image
T_PLATE,T_PLATEON,T_GATE0,T_GATE5=7,8,10,15
def setv(**kw):
    for k,v in kw.items(): poke(k,v)
pump()
load_room(4); setv(G_ACTIVE=0)
print("room 4: plate",m.memory[RM+1],"gate",m.memory[RM+6]); assert m.memory[RM+1]==T_PLATE and m.memory[RM+6]==T_GATE0
# 1) a closed gate blocks the prince
stage(120,18,0); run(30,right=True)
print("closed gate -> prince stops at x",P()["x"],"room",room()); assert P()["x"]<=181 and room()==4
snaps=[]
def grab(): snap("_t.png",(0,0,768,576)); snaps.append(Image.open("_t.png").copy())
grab()
# 2) stepping on the plate: it sinks, the gates rise one step per frame
stage(8,18,0); setv(GATE_LVL=0,GATE_TGT=0,GATE_HOLD=0)
tr=[]
for i in range(16):
    keys(right=True); pump(); tr.append((m.memory[RM+1],mem("GATE_LVL"),m.memory[RM+6]))
    if i==9: grab()
print("plate pressed  (plate tile, gate level, gate tile):",sorted(set(tr),key=tr.index))
assert (T_PLATEON,5,T_GATE5) in tr and m.memory[RM+6]==T_GATE5
lv=[t[1] for t in tr]; assert lv==sorted(lv) and lv[-1]==5
# 3) with the gate up he walks straight through (and out of the room)
stage(170,18,0); setv(GATE_LVL=5,GATE_TGT=5,GATE_HOLD=100)
m.memory[RM+6]=T_GATE5
run(14,right=True); print("through the open gate -> x",P()["x"],"room",room()); assert P()["x"]>=216 or room()==5
# 4) after the hold time the gates come down and the plate pops back up
load_room(4); setv(G_ACTIVE=0); stage(60,18,0)
m.memory[RM+1]=T_PLATEON; m.memory[RM+6]=T_GATE5; setv(GATE_LVL=5,GATE_TGT=5,GATE_HOLD=3)
tr=[]
for i in range(14): keys(); pump(); tr.append((mem("GATE_HOLD"),mem("GATE_TGT"),mem("GATE_LVL")))
print("closing (hold,target,level):",tr); 
assert tr[-1][2]==0 and m.memory[RM+6]==T_GATE0 and m.memory[RM+1]==T_PLATE
grab()
# 5) never slammed on someone standing in the doorway
load_room(4); setv(G_ACTIVE=0); stage(184,18,0)
m.memory[RM+6]=T_GATE5; setv(GATE_LVL=5,GATE_TGT=5,GATE_HOLD=0)
for _ in range(12): keys(); pump()
print("prince in the doorway, hold over -> level",mem("GATE_LVL")); assert mem("GATE_LVL")==5
run(14,right=True)
for _ in range(10): keys(); pump()
print("after he walked out -> level",mem("GATE_LVL"),"x",P()["x"],"room",room())
# 6) standing on a pressed plate keeps refreshing the hold timer
load_room(4); setv(G_ACTIVE=0); stage(24,18,0); keys(); pump()
for _ in range(3): keys(); pump()
print("standing on the plate -> hold",mem("GATE_HOLD"),"level",mem("GATE_LVL")); assert mem("GATE_HOLD")>=139 and mem("GATE_LVL")>=2
# 7) the guard cannot walk through a closed gate either
load_room(4); setv(G_ACTIVE=1,GX=182,GY=18,GFACE=0,GFS=0)
poke("GROW",0); m.memory[G:=sym["G_ENT"]+8]=0
def move_guard(dx):
    m.sp-=2; m.memory[m.sp]=FD&255; m.memory[m.sp+1]=FD>>8
    m.ix=sym["G_ENT"]; m.iy=sym["P_ENT"]; m.b=dx; m.pc=sym["FIGHT_MOVE"]
    poke("PX",20); poke("PROW",0); pump()
x0=mem("GX"); move_guard(3); print("guard vs closed gate: x",x0,"->",mem("GX")); assert mem("GX")==x0
m.memory[RM+6]=T_GATE5; poke("GX",182); move_guard(3); print("guard vs open gate:   x 182 ->",mem("GX")); assert mem("GX")==185
# montage
w,h=snaps[0].size
M=Image.new("RGB",(len(snaps)*(w//2)+6*(len(snaps)-1),h//2),(0,0,0))
for k,im in enumerate(snaps): M.paste(im.resize((w//2,h//2),Image.NEAREST),(k*(w//2+6),0))
M.save("gates_montage.png"); print("ALL GATE TESTS OK")
