import re
from z80 import Z80Machine
from PIL import Image
sym={}
for ln in open("pop12.sym"):
    m_=re.match(r"(\w+)\s+EQU\s+([0-9A-F]+)H",ln.strip())
    if m_: sym[m_.group(1)]=int(m_.group(2),16)
m=Z80Machine()
print("tick attrs:",[n for n in dir(m) if 'tick' in n.lower()])
m.set_memory_block(0x7B00,open("pop12.bin","rb").read())
m.memory[sym["TITLE_SCREEN"]]=0xC9   # tests start in the game, not on the title
m.memory[sym["INTRO_SCREEN"]]=0xC9   # ... nor on the intro picture
for a in (0x68FE,0x68FD,0x68FB,0x68F7,0x68EF,0x68DF,0x68BF,0x687F): m.memory[a]=0xFF
m.pc=0x7B00; m.sp=0x8000
SETB=sym["SET_BANK"]; FD=sym["FRAME_DONE"]
m.set_breakpoint(SETB); m.set_breakpoint(FD)
banks=[bytearray(2048) for _ in range(3)]
def mem(n): return m.memory[sym[n]]
def poke(n,v): m.memory[sym[n]]=v
def keys(left=False,right=False,a=False,d=False,s=False):
    v=0xFF
    if left:  v&=~(1<<4)
    if right: v&=~(1<<1)
    m.memory[0x68FB]=v
    w=0xFF
    if a: w&=~(1<<4)
    if d: w&=~(1<<3)
    if s: w&=~(1<<1)
    m.memory[0x68FD]=w
chunk=0
def pump():
    """run until FRAME_DONE; handle bank switching + fake vsync."""
    global chunk
    for _ in range(600000):
        chunk+=1
        m.memory[0x6800]=0x80 if chunk&1 else 0x00
        m.ticks_to_stop=1500
        m.run()
        if m.pc==SETB:
            old=m.memory[sym["CUR_BANK"]]; new=m.a
            banks[old][:]=bytes(m.memory[0x7000:0x7800]); m.memory[0x7000:0x7800]=bytes(banks[new])
            m.step_over_breakpoint()
        elif m.pc==FD:
            m.step_over_breakpoint(); return
    raise SystemExit("never finished")
def vram():
    cur=m.memory[sym["CUR_BANK"]]; banks[cur][:]=bytes(m.memory[0x7000:0x7800])
    return b"".join(bytes(b) for b in banks)
def lit(v,x,y): return bool(v[y*32+(x>>3)]&(0x80>>(x&7)))
def snap(name,crop=None):
    v=vram(); S=3; im=Image.new("RGB",(256*S,192*S),(0,96,0))
    for y in range(192):
        for x in range(256):
            if lit(v,x,y):
                for dy in range(S):
                    for dx in range(S): im.putpixel((x*S+dx,y*S+dy),(0,255,0))
    if crop: im=im.crop(crop)
    im.save(name)
def ent(base):
    a=sym[base]; k=("x","y","face","frame","fs","fi","hp","tmr","row")
    return {n:m.memory[a+i] for i,n in enumerate(k)}
P=lambda: ent("P_ENT"); G=lambda: ent("G_ENT")

pump()
def tele(px=100,gx=124,gro=0,sword=1,php=3,ghp=3):
    for n,v in (("PX",px),("PY",82),("PFACE",0),("PFRAME",0),("PROW",1),("PSTATE",0),("PFS",0),("PSWORD",sword),("PHP",php),("PTMR",0),
                ("GX",gx),("GY",82),("GFACE",1),("GFRAME",9),("GFS",0),("GHP",ghp),("GTMR",0),("GROW",gro),("JPREV",0),("DPREV",0)):
        poke(n,v)
def frames_(n,**k):
    for _ in range(n): keys(**k); pump()

from PIL import Image
def stage(px=40,py=82,row=1,face=0,sword=0,gro=0):
    for n,v in (("PX",px),("PY",py),("PFACE",face),("PFRAME",0),("PROW",row),("PSTATE",0),("PFS",0),("PSWORD",sword),("PHP",3),
                ("GROW",gro),("JPREV",0),("DPREV",0),("RUNPH",0),("TIDX",0),("LTMR",0),("GX",200),("GFS",0),("GFRAME",9),("GHP",3)): poke(n,v)
    keys()
def run(n,**k):
    out=[]
    for _ in range(n):
        keys(**k); pump(); out.append((P()["frame"],P()["x"],P()["face"],P()["y"],mem("PSTATE")))
    return out
strips={}
def film(tag,n,pre=None,**k):
    crops=[]
    for _ in range(n):
        keys(**k); pump(); snap("_f.png",(max(0,P()["x"]*3-60),130,min(768,P()["x"]*3+170),400)); crops.append(Image.open("_f.png").copy())
        if pre: pass
    strips[tag]=crops
pump(); poke("G_ACTIVE",1)
# 1) run: start-up (2 frames), then the 4-frame cycle; release: slide to a stop over 2 frames
stage(px=20); pump()
r=run(8,right=True); print("run   frames",[a[0] for a in r],"px",[a[1] for a in r])
assert [a[0] for a in r]==[19,20,1,2,3,4,1,2] and [r[i][1]-([20]+[a[1] for a in r])[i] for i in range(8)]==[2,3,4,4,4,4,4,4]
r2=run(4); print("stop  frames",[a[0] for a in r2],"px",[a[1] for a in r2])
assert [a[0] for a in r2]==[21,22,0,0] and r2[0][1]-r[-1][1]==3 and r2[1][1]-r2[0][1]==2 and r2[2][1]==r2[1][1]
# 2) turn on the spot: 3 frames, facing flips on the middle one, then he starts running the new way
stage(px=60); pump(); r=run(5,left=True); print("turn  frames",[a[0] for a in r],"face",[a[2] for a in r],"px",[a[1] for a in r])
assert [a[0] for a in r]==[23,24,25,19,20] and [a[2] for a in r]==[0,1,1,1,1] and r[0][1]==r[1][1]==r[2][1]==60 and r[3][1]<60
# 3) crouch with S (sword away)
stage(px=60); pump(); r=run(2,s=True); r3=run(1); print("crouch frames",[a[0] for a in r],"then",r3[0][0]); assert [a[0] for a in r]==[26,26] and r3[0][0]==0
# 4) jumps: standing jump (5 px/frame) vs running jump (8 px/frame), phase frames, landing crouch
def jump_seq(runph):
    stage(px=40); poke("PX",40); m.memory[sym["RUNPH"]]=runph; keys(right=True,a=True); pump(); keys()
    seq=[(P()["frame"],P()["x"])]
    for _ in range(9): pump(); seq.append((P()["frame"],P()["x"]))
    return seq
sj=jump_seq(0); print("standing jump frames",[a[0] for a in sj],"px",sj[-1][1])
assert [a[0] for a in sj][:9]==[28,29,29,30,30,31,31,27,0] and sj[-1][1]==80
rj=jump_seq(3); print("running  jump px",rj[-1][1]); assert rj[-1][1]==40+64 and [a[0] for a in rj][:9]==[28,29,29,30,30,31,31,27,0]
# 5) a fall: fall frame, then a 2-frame landing crouch
stage(px=96,py=18,row=0,face=1); pump(); fr=[]; 
for _ in range(14):
    keys(left=True); pump(); fr.append((P()["frame"],mem("PSTATE"),P()["row"],P()["y"]))
print("fall  frames",[a[0] for a in fr]); 
frames_only=[a[0] for a in fr]; assert 32 in frames_only and frames_only.count(27)>=2
land=[i for i,a in enumerate(fr) if a[0]==27]; assert fr[land[0]][3]==82 and fr[land[0]+1][0]==27
# 6) the ledge climb, now 8 poses
stage(px=76,face=0); pump(); keys(a=True); pump(); keys(); cl=[P()["frame"]]
for _ in range(10): pump(); cl.append(P()["frame"])
print("climb frames",cl); assert cl[:9]==[33,33,6,6,6,7,8,34,0] and P()["row"]==0
# 7) sword out: stepping towards the guard shows the advance pose, stepping away the retreat pose
stage(px=100,sword=1); poke("GX",124); poke("GROW",0); poke("PFS",0); pump(); pump()
rr=run(2,right=True); run(1); ra=run(2,left=True)
print("fight steps  toward",[a[0] for a in rr],"away",[a[0] for a in ra]); assert rr[0][0]==10 and ra[0][0]==16 and rr[1][0]==35 and ra[1][0]==35  # step cycle: ADV|RETREAT, then the passing frame
# filmstrips
def film(tag,setup,n,**k):
    setup(); pump(); crops=[]
    for i in range(n):
        kk=k(i) if callable(k) else k
        keys(**kk); pump(); x=P()["x"]
        snap("_f.png",(max(0,x*3-50),150,min(768,x*3+190),400)); crops.append(Image.open("_f.png").copy())
    return crops
rows=[]
rows.append(film("run",lambda: stage(px=14),11,**{}) if False else None)
def mk(tag,setup,n,keyf):
    setup(); pump(); cr=[]
    for i in range(n):
        keys(**keyf(i)); pump(); x=P()["x"]
        snap("_f.png",(max(0,min(x*3-50,768-240)),140,max(0,min(x*3-50,768-240))+240,420)); cr.append(Image.open("_f.png").copy())
    return cr
rows=[mk("run",lambda: stage(px=14),11,lambda i: dict(right=(i<8))),
      mk("turn",lambda: stage(px=70),6,lambda i: dict(left=(i<4))),
      mk("jump",lambda: (stage(px=40),m.memory.__setitem__(sym["RUNPH"],0)),10,lambda i: dict(right=(i==0),a=(i==0))),
      mk("climb",lambda: stage(px=76),10,lambda i: dict(a=(i==0)))]
w,h=rows[0][0].size; cols=11
M=Image.new("RGB",(cols*(w//2)+ (cols-1)*2, len(rows)*(h//2)+ (len(rows)-1)*2),(0,0,0))
for ri,row in enumerate(rows):
    for ci,im in enumerate(row):
        M.paste(im.resize((w//2,h//2),Image.NEAREST),(ci*(w//2+2),ri*(h//2+2)))
M.save("anim_strip.png"); print("strip",M.size)
print("ALL ANIMATION TESTS OK")
