#!/usr/bin/env python3
"""skeletonize.py - sprites.txt (frames 9..18, the sword-fight block) -> skel.txt

Turns the solid fighter poses into a skeleton: skull with eye sockets and a toothy jaw, ribcage, spine, pelvis, hollow
bone limbs; the sword arm and blade are kept.  skel.txt can be edited afterwards (same format as sprites.txt) -
re-running this script overwrites it.   python3 skeletonize.py                  stick-figure legs (the game's skeleton)  -> skel.txt
    python3 skeletonize.py --hollow        the earlier hollow bone legs              -> skel_hollow.txt
"""
import sys
args=[a for a in sys.argv[1:] if not a.startswith("--")]
STICK="--hollow" not in sys.argv             # default: stick-figure legs (single-pixel bones); --hollow = the earlier hollow bone legs
src=args[0] if len(args)>0 else "sprites.txt"
out=args[1] if len(args)>1 else ("skel.txt" if STICK else "skel_hollow.txt")
frames=[];cur=None
for ln in open(src):
    ln=ln.rstrip("\r\n")
    if ln.startswith(";"): continue
    if ln.startswith("["):
        p=ln[1:-1].split(); cur=dict(head=ln,name=p[0],attrs=" ".join(p[1:]),rows=[]); frames.append(cur); continue
    if cur is not None and ln.strip(): cur["rows"].append(ln)
FIRST,LAST=9,18
def runs(row):
    r=[];x=0
    while x<len(row):
        if row[x]=="#":
            a=x
            while x<len(row) and row[x]=="#": x+=1
            r.append((a,x-1))
        else: x+=1
    return r
def bonify(rows,dead=False):
    H=len(rows); W=len(rows[0]); g=[list(r) for r in rows]; o=[["."]*W for _ in range(H)]
    if dead:                                              # collapsed skeleton: outline + rib strokes
        for y in range(H):
            for x in range(W):
                if g[y][x]=="#":
                    edge=any(not(0<=y+dy<H and 0<=x+dx<W) or g[y+dy][x+dx]!="#" for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)))
                    if edge or x%3==0: o[y][x]="#"
        return ["".join(r) for r in o]
    top=next(y for y in range(H) if "#" in rows[y])
    for y in range(H):
        rel=y-top
        for (a,b) in runs(rows[y]):
            n=b-a+1
            if n<=3 and rel>=9 and not (rel>=28):         # sword, fingers, thin parts: keep
                for x in range(a,b+1): o[y][x]="#"
            elif rel<=6:                                  # skull: solid, with sockets and teeth added below
                for x in range(a,b+1): o[y][x]="#"
            elif rel<=8:                                  # neck: spine only
                c=(a+b)//2
                for x in (c,c+1): o[y][x]="#"
            elif rel<=19:                                 # ribcage: rib rows with a spine, open sides between
                k=(rel-9)%3
                if rel==9 or k==1:
                    for x in range(a,b+1): o[y][x]="#"
                else:
                    o[y][a]="#"; o[y][b]="#"; o[y][(a+b)//2]="#"
            elif rel<=27:                                 # pelvis / hips
                k=(rel-20)%2
                if rel in (20,27) or n<=4:
                    for x in range(a,b+1): o[y][x]="#"
                else:
                    o[y][a]="#"; o[y][b]="#"
                    if k==0: o[y][(a+b)//2]="#"
            else:                                         # legs: hollow bones
                if n>=3:
                    o[y][a]="#"; o[y][b]="#"
                    if (rel%4)==0:
                        for x in range(a,b+1): o[y][x]="#"   # joints
                else:
                    for x in range(a,b+1): o[y][x]="#"
    if STICK:                                            # style B: redraw hips and legs as single-pixel bones
        L0=top+20
        for y in range(L0,H):
            for x in range(W): o[y][x]="."
        prev=[]                                           # (centre) of the bones on the row above
        for y in range(L0,H):
            rel=y-top; cur=[]
            for (a,b) in runs(rows[y]):
                n=b-a+1
                if rel==20:                               # pelvis bar
                    c=(a+b)//2
                    for x in range(c-2,c+3): o[y][x]="#"
                    cur+=[c-2,c+2]
                elif n>=7 or (rel<=29 and n>=6):          # both legs still merged: two thigh bones
                    cur+=[a+1,b-1]
                else:
                    cur.append((a+b)//2)                  # one leg: a single line through its centre
            for c in cur:
                o[y][c]="#"
                if prev:                                  # join diagonals: fill towards the nearest bone above
                    p=min(prev,key=lambda q:abs(q-c))
                    for x in range(min(p,c),max(p,c)+1):
                        if abs(x-p)<=abs(x-c): o[y][x]="#" if abs(c-p)>1 else o[y][x]
                        if abs(c-p)>1 and min(p,c)<=x<=max(p,c) and abs(x-c)<=abs(c-p)//2: o[y][x]="#"
            if y==H-1 or y==H-2:                          # feet: short horizontal tick at the toes
                for (a,b) in runs(rows[y]):
                    for x in range(max(a,(a+b)//2-1),min(b,(a+b)//2+2)+1): o[y][x]="#"
            prev=cur
    # skull details: eye sockets (2x2, towards the face side), nose gap and teeth
    hr=[y for y in range(top,top+7) if "#" in rows[y]]
    if hr:
        a,b=runs(rows[top+3])[0] if runs(rows[top+3]) else (None,None)
        if a is not None:
            for dy in (3,4):
                for dx in (b-3,b-2): o[top+dy][dx]="."          # eye socket
                if b-6>=a+1:
                    for dx in (a+1,a+2): o[top+dy][dx]="."       # second socket (rear)
        r=runs(rows[top+6])
        if r:
            a,b=r[0]
            for x in range(a,b+1):
                if (x-a)%2==1: o[top+6][x]="."                   # teeth gaps
    return ["".join(r) for r in o]
with open(out,"w") as f:
    f.write("; skeleton frames (same order as the guard frames 9..18).  GENERATED by skeletonize.py, then free to edit.\n")
    for fr in frames[FIRST:LAST+1]:
        name=fr["name"].replace("PRINCE","SKEL")
        rows=bonify(fr["rows"],dead=fr["name"]=="PRINCE_DEAD")
        f.write("[%s %s]\n"%(name,fr["attrs"]))
        for r in rows: f.write(r+"\n")
        f.write("\n")
print("wrote",out,len(frames[FIRST:LAST+1]),"frames")
