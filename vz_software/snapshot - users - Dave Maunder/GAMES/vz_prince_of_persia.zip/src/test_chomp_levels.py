import re
from z80 import Z80Machine
from PIL import Image
sym={}
for ln in open("pop12.sym"):
    m_=re.match(r"(\w+)\s+EQU\s+([0-9A-F]+)H",ln.strip())
    if m_: sym[m_.group(1)]=int(m_.group(2),16)
m=Z80Machine()
print("tick attrs:",[n for n in dir(m) if 'tick' in n.lower()])
m.set_memory_block(0x7B00,open("pop12.bin","rb").read())
m.memory[sym["TITLE_SCREEN"]]=0xC9   # tests start in the game, not on the title
m.memory[sym["INTRO_SCREEN"]]=0xC9   # ... nor on the intro picture
for a in (0x68FE,0x68FD,0x68FB,0x68F7,0x68EF,0x68DF,0x68BF,0x687F): m.memory[a]=0xFF
m.pc=0x7B00; m.sp=0x8000
SETB=sym["SET_BANK"]; FD=sym["FRAME_DONE"]
m.set_breakpoint(SETB); m.set_breakpoint(FD)
banks=[bytearray(2048) for _ in range(3)]
def mem(n): return m.memory[sym[n]]
def poke(n,v): m.memory[sym[n]]=v
def keys(left=False,right=False,a=False,d=False,s=False):
    v=0xFF
    if left:  v&=~(1<<4)
    if right: v&=~(1<<1)
    m.memory[0x68FB]=v
    w=0xFF
    if a: w&=~(1<<4)
    if d: w&=~(1<<3)
    if s: w&=~(1<<1)
    m.memory[0x68FD]=w
chunk=0
def pump():
    """run until FRAME_DONE; handle bank switching + fake vsync."""
    global chunk
    for _ in range(600000):
        chunk+=1
        m.memory[0x6800]=0x80 if chunk&1 else 0x00
        m.ticks_to_stop=1500
        m.run()
        if m.pc==SETB:
            old=m.memory[sym["CUR_BANK"]]; new=m.a
            banks[old][:]=bytes(m.memory[0x7000:0x7800]); m.memory[0x7000:0x7800]=bytes(banks[new])
            m.step_over_breakpoint()
        elif m.pc==FD:
            m.step_over_breakpoint(); return
    raise SystemExit("never finished")
def vram():
    cur=m.memory[sym["CUR_BANK"]]; banks[cur][:]=bytes(m.memory[0x7000:0x7800])
    return b"".join(bytes(b) for b in banks)
def lit(v,x,y): return bool(v[y*32+(x>>3)]&(0x80>>(x&7)))
def snap(name,crop=None):
    v=vram(); S=3; im=Image.new("RGB",(256*S,192*S),(0,96,0))
    for y in range(192):
        for x in range(256):
            if lit(v,x,y):
                for dy in range(S):
                    for dx in range(S): im.putpixel((x*S+dx,y*S+dy),(0,255,0))
    if crop: im=im.crop(crop)
    im.save(name)
def ent(base):
    a=sym[base]; k=("x","y","face","frame","fs","fi","hp","tmr","row")
    return {n:m.memory[a+i] for i,n in enumerate(k)}
P=lambda: ent("P_ENT"); G=lambda: ent("G_ENT")

pump()
def tele(px=100,gx=124,gro=0,sword=1,php=3,ghp=3):
    for n,v in (("PX",px),("PY",82),("PFACE",0),("PFRAME",0),("PROW",1),("PSTATE",0),("PFS",0),("PSWORD",sword),("PHP",php),("PTMR",0),
                ("GX",gx),("GY",82),("GFACE",1),("GFRAME",9),("GFS",0),("GHP",ghp),("GTMR",0),("GROW",gro),("JPREV",0),("DPREV",0)):
        poke(n,v)
def frames_(n,**k):
    for _ in range(n): keys(**k); pump()

from PIL import Image
RM=sym["ROOM_MAP"]; FL=sym["ROOM_FLAGS"]
def load_room(n):
    m.sp-=2; m.memory[m.sp]=FD&255; m.memory[m.sp+1]=FD>>8; m.a=n; m.pc=sym["LOAD_ROOM"]; pump()
def stage(px,py,row,face=0,hp=3,active=0):
    for n,v in (("PX",px),("PY",py),("PROW",row),("PFACE",face),("PFRAME",0),("PSTATE",0),("PFS",0),("PSWORD",0),("PHP",hp),
                ("JPREV",0),("DPREV",0),("RUNPH",0),("TIDX",0),("LTMR",0),("FALLN",0),("G_ACTIVE",active),("LOOSE_ARM",0)): poke(n,v)
    keys()
def run(n,**k):
    out=[]
    for _ in range(n):
        keys(**k); pump(); out.append((P()["frame"],P()["x"],P()["y"],mem("PSTATE")))
    return out
def room(): return mem("CUR_ROOM")

from PIL import Image
CH0,CH1,CH2=16,17,18
def call(label,a=None):
    m.sp-=2; m.memory[m.sp]=FD&255; m.memory[m.sp+1]=FD>>8
    if a is not None: m.a=a
    m.pc=sym[label]; pump()
def set_level(n): call("SET_LEVEL",n); call("RESPAWN")
def room(): return mem("CUR_ROOM")
def tile(col,row): return m.memory[RM+row*8+col]&0x3F
def freeze_guard(): poke("G_ACTIVE",0)
pump()
# ================= 1) chomper behaviour =================
set_level(1); freeze_guard()
print("level 2 room 0: chomper at (4,1) =",tile(4,1)); assert tile(4,1)==CH0
seq=[]
for i in range(34):
    stage(8,18,0,active=0) if False else None
    keys(); pump(); seq.append(tile(4,1)-CH0)
print("jaw cycle over 34 frames:",seq)
per=[i for i in range(1,34) if seq[i]==2 and seq[i-1]!=2]
assert set(seq)=={0,1,2} and per and (len(per)<2 or per[1]-per[0]==16)
shut_runs=[len(r) for r in "".join(map(str,seq)).split("0") if "2" in r]; print("   shut for",shut_runs,"frames at a time")
# stand in the doorway of the jaws: dies when they shut, safe while open
def stand_in(col,hold_for,t0=None):
    stage(col*32+8,82,1,active=0)
    if t0 is not None: poke("CHOMP_T",t0)
    for i in range(hold_for):
        keys(); pump()
        if P()["fs"]==5: return i
    return None
died=stand_in(4,40); print("standing in the jaws: died after",died,"frames, hp",P()["hp"],"frame",P()["frame"]); assert died is not None and P()["hp"]==0 and P()["frame"]==15
# right after the jaws open there are several frames of safety
safe=None
for t0 in range(16):
    stage(4*32+8,82,1,active=0); poke("CHOMP_T",t0); survived=0
    for i in range(6):
        keys(); pump()
        if P()["fs"]==5: break
        survived+=1
    if survived==6: safe=t0; break
print("a safe window exists (start phase",safe,")"); assert safe is not None
# in the air or landing (not on the ground) the jaws do nothing
stage(4*32+8,82,1,active=0); poke("PSTATE",5); poke("LTMR",60)
for i in range(30): keys(); pump()
print("in a landing crouch inside the jaws for 30 frames -> alive:",P()["fs"]!=5); assert P()["fs"]!=5
# can the corridor be passed? brute-force the timing: hold right through the chomper
ok=[];bad=[]
for t0 in range(16):
    stage(48,82,1,active=0); poke("CHOMP_T",t0); dead=False
    for i in range(24):
        keys(right=True); pump()
        if P()["fs"]==5: dead=True; break
    (bad if dead else ok).append(t0)
print("running straight through room 0's chomper: survives for",len(ok),"of 16 start phases, killed for",len(bad)); assert ok and bad
# ================= 2) level 2, room by room =================
def spin(nchunks):
    global chunk
    for _ in range(nchunks):
        chunk+=1; m.memory[0x6800]=0x80 if chunk&1 else 0x00; m.ticks_to_stop=1500; m.run()
        if m.pc==SETB:
            old=m.memory[sym["CUR_BANK"]]; new=m.a
            banks[old][:]=bytes(m.memory[0x7000:0x7800]); m.memory[0x7000:0x7800]=bytes(banks[new]); m.step_over_breakpoint()

def walk_to_exit(maxframes=90,**k):
    for fr in range(maxframes):
        keys(**k)
        for _ in range(6000):
            spin(1)
            if mem("WINFLAG")==1: return fr+1
            if m.pc==FD: m.step_over_breakpoint(); break
    return None
def run_until(cond,maxn=80,**k):
    for i in range(maxn):
        keys(**k); pump()
        if cond(): return i+1
    return None
load_room(1); freeze_guard()
def try_room1(t0,pause):
    stage(8,82,1,active=0); poke("CHOMP_T",t0); paused=0; stopped=False
    for i in range(90):
        k=dict(right=True)
        if P()["x"]+8>=100 and not stopped and P()["x"]+8<128 and pause>0:
            stopped=True
        if stopped and paused<pause: k=dict(); paused+=1
        keys(**k); pump()
        if P()["fs"]==5: return "dead"
        if P()["x"]>=216 or room()!=1: return "through"
    return "stuck"
straight=[try_room1(t0,0) for t0 in range(16)]
print("room 1, running straight through: through for",straight.count("through"),"of 16 timings (the two jaws are out of step on purpose)")
assert straight.count("through")==0 and straight.count("dead")>0
solved=[(t0,k) for t0 in range(16) for k in (4,8,12) if try_room1(t0,k)=="through"]
print("room 1 with a pause in the safe cell between the jaws: works for",len(solved),"(start phase, pause) combinations, e.g.",solved[:3]); assert solved
load_room(2); freeze_guard(); stage(8,82,1,active=0)
n=run_until(lambda: room()==3,right=True,maxn=70)
print("room 2 plate+gate: reached room 3 after",n,"frames, hp",P()["hp"]); assert n and P()["hp"]==3
load_room(3); stage(8,82,1,active=0); poke("G_ACTIVE",1); print("room 3 guard at x",mem("GX")); assert mem("G_ACTIVE")==1 and mem("GX")==4*32+8
freeze_guard()
n=walk_to_exit(80,right=True); print("level 2 exit reached after",n,"frames"); assert n
# ================= 3) level 3, room by room =================
poke("WINFLAG",0)
set_level(2); freeze_guard()
print("level 3 start: room",room(),"x",P()["x"])
ok=[]
for t0 in range(16):
    stage(40,82,1,active=0); poke("CHOMP_T",t0); poke("GATE_LVL",0); poke("GATE_TGT",0); poke("GATE_HOLD",0)
    m.memory[RM+0]=m.memory[RM+0]; dead=False
    load_room(0); freeze_guard(); stage(40,82,1,active=0); poke("CHOMP_T",t0)
    n=run_until(lambda: P()["x"]<=20,left=True,maxn=12)           # onto the plate at column 0
    plate=tile(0,1)
    for i in range(60):
        keys(right=True); pump()
        if P()["fs"]==5: dead=True; break
        if room()==1: break
    if not dead and room()==1: ok.append(t0)
print("room 0 (plate, chomper, gate): through for",len(ok),"of 16 phases; plate pressed:",plate==8); assert ok and plate==8
# room 1: potion, loose floor, then a one-cell gap.  find a take-off point for the running jump
load_room(1); freeze_guard(); lands=[]
for px in range(60,110,2):
    load_room(1); freeze_guard(); stage(px,82,1,active=0); poke("RUNPH",3)
    keys(right=True,a=True); pump(); keys()
    for i in range(14): pump()
    if P()["row"]==1 and P()["x"]>=152 and P()["hp"]==3 and mem("PSTATE")==0: lands.append(px)
print("room 1 running jumps from x=",lands[:4],"... (",len(lands),"take-off points clear the gap )"); assert lands
# ... and if the loose tile goes, he drops one row onto the lower floor, unhurt
load_room(1); freeze_guard(); stage(88,82,1,active=0)
for i in range(20): keys(); pump()
for i in range(10): keys(right=(i<3)); pump()
print("loose tile gone ->",tile(3,1)==0,"; he is on row",P()["row"],"hp",P()["hp"])
# room 2: hang down from the end of the upper floor onto the exit
load_room(2); freeze_guard(); stage(140,82,1,face=0,active=0)
n=walk_to_exit(40,s=True); print("room 2: S at the edge -> hang, drop onto the exit door after",n,"frames; hp",P()["hp"]); assert n and P()["hp"]==3
# ================= 4) level progression =================
poke("WINFLAG",0)
def finish_level(level,rm,px,py,row):
    set_level(level); load_room(rm); freeze_guard(); stage(px,py,row,active=0)
    for _ in range(40):
        keys()
        for _ in range(4000):
            chunk_=0; spin(1)
            if mem("WINFLAG")==1: break
            if m.pc==FD: m.step_over_breakpoint(); break
        if mem("WINFLAG")==1: break
    assert mem("WINFLAG")==1,"never reached the exit of level %d"%(level+1)
    keys(); spin(3000)
    txt=bytes(m.memory[sym["STR_WIN1"]:sym["STR_WIN1"]+16]).decode()
    snap("win_l%d.png"%(level+1),(0,150,768,380))
    keys(a=True); spin(400); keys()
    for _ in range(4): pump()
    return txt,mem("CUR_LEVEL")
for lvl,(rm,px,py,row) in enumerate([(7,184,146,2),(3,184,82,1),(2,152,146,2)]):
    txt,now=finish_level(lvl,rm,px,py,row)
    exp=(lvl+1)%3
    print("exit of level",lvl+1,"-> banner %r, now on level"%txt,now+1); assert now==exp and txt=="LEVEL %d COMPLETE"%(lvl+1)
print("ALL CHOMPER + LEVEL TESTS OK")
