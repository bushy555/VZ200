import re
from z80 import Z80Machine
from PIL import Image
sym={}
for ln in open("pop12.sym"):
    m_=re.match(r"(\w+)\s+EQU\s+([0-9A-F]+)H",ln.strip())
    if m_: sym[m_.group(1)]=int(m_.group(2),16)
m=Z80Machine()
print("tick attrs:",[n for n in dir(m) if 'tick' in n.lower()])
m.set_memory_block(0x7B00,open("pop12.bin","rb").read())
m.memory[sym["TITLE_SCREEN"]]=0xC9   # tests start in the game, not on the title
m.memory[sym["INTRO_SCREEN"]]=0xC9   # ... nor on the intro picture
for a in (0x68FE,0x68FD,0x68FB,0x68F7,0x68EF,0x68DF,0x68BF,0x687F): m.memory[a]=0xFF
m.pc=0x7B00; m.sp=0x8000
SETB=sym["SET_BANK"]; FD=sym["FRAME_DONE"]
m.set_breakpoint(SETB); m.set_breakpoint(FD)
banks=[bytearray(2048) for _ in range(3)]
def mem(n): return m.memory[sym[n]]
def poke(n,v): m.memory[sym[n]]=v
def keys(left=False,right=False,a=False,d=False,s=False):
    v=0xFF
    if left:  v&=~(1<<4)
    if right: v&=~(1<<1)
    m.memory[0x68FB]=v
    w=0xFF
    if a: w&=~(1<<4)
    if d: w&=~(1<<3)
    if s: w&=~(1<<1)
    m.memory[0x68FD]=w
chunk=0
def pump():
    """run until FRAME_DONE; handle bank switching + fake vsync."""
    global chunk
    for _ in range(600000):
        chunk+=1
        m.memory[0x6800]=0x80 if chunk&1 else 0x00
        m.ticks_to_stop=1500
        m.run()
        if m.pc==SETB:
            old=m.memory[sym["CUR_BANK"]]; new=m.a
            banks[old][:]=bytes(m.memory[0x7000:0x7800]); m.memory[0x7000:0x7800]=bytes(banks[new])
            m.step_over_breakpoint()
        elif m.pc==FD:
            m.step_over_breakpoint(); return
    raise SystemExit("never finished")
def vram():
    cur=m.memory[sym["CUR_BANK"]]; banks[cur][:]=bytes(m.memory[0x7000:0x7800])
    return b"".join(bytes(b) for b in banks)
def lit(v,x,y): return bool(v[y*32+(x>>3)]&(0x80>>(x&7)))
def snap(name,crop=None):
    v=vram(); S=3; im=Image.new("RGB",(256*S,192*S),(0,96,0))
    for y in range(192):
        for x in range(256):
            if lit(v,x,y):
                for dy in range(S):
                    for dx in range(S): im.putpixel((x*S+dx,y*S+dy),(0,255,0))
    if crop: im=im.crop(crop)
    im.save(name)
def ent(base):
    a=sym[base]; k=("x","y","face","frame","fs","fi","hp","tmr","row")
    return {n:m.memory[a+i] for i,n in enumerate(k)}
P=lambda: ent("P_ENT"); G=lambda: ent("G_ENT")

pump()
def tele(px=100,gx=124,gro=0,sword=1,php=3,ghp=3):
    for n,v in (("PX",px),("PY",82),("PFACE",0),("PFRAME",0),("PROW",1),("PSTATE",0),("PFS",0),("PSWORD",sword),("PHP",php),("PTMR",0),
                ("GX",gx),("GY",82),("GFACE",1),("GFRAME",9),("GFS",0),("GHP",ghp),("GTMR",0),("GROW",gro),("JPREV",0),("DPREV",0)):
        poke(n,v)
def frames_(n,**k):
    for _ in range(n): keys(**k); pump()

from PIL import Image
RM=sym["ROOM_MAP"]; FL=sym["ROOM_FLAGS"]
def load_room(n):
    m.sp-=2; m.memory[m.sp]=FD&255; m.memory[m.sp+1]=FD>>8; m.a=n; m.pc=sym["LOAD_ROOM"]; pump()
def stage(px,py,row,face=0,hp=3,active=0):
    for n,v in (("PX",px),("PY",py),("PROW",row),("PFACE",face),("PFRAME",0),("PSTATE",0),("PFS",0),("PSWORD",0),("PHP",hp),
                ("JPREV",0),("DPREV",0),("RUNPH",0),("TIDX",0),("LTMR",0),("FALLN",0),("G_ACTIVE",active),("LOOSE_ARM",0)): poke(n,v)
    keys()
def run(n,**k):
    out=[]
    for _ in range(n):
        keys(**k); pump(); out.append((P()["frame"],P()["x"],P()["y"],mem("PSTATE")))
    return out
def room(): return mem("CUR_ROOM")
pump()
snaps=[]
def grab(): snap("_t.png",(0,0,768,576)); snaps.append(Image.open("_t.png").copy())
# ======== potions ========
load_room(1)
print("potion tile (room 1, col 2, row 1): map byte",hex(m.memory[RM+8+2])); assert m.memory[RM+8+2]&0x40
stage(72,82,1,hp=1); pump(); grab()
run(1,s=True)
print("drink at hp 1 -> hp",P()["hp"],"map byte",hex(m.memory[RM+8+2]),"room flags",hex(m.memory[FL+1])); assert P()["hp"]==2 and not m.memory[RM+8+2]&0x40 and m.memory[FL+1]&2
run(2,s=True); print("second crouch (potion gone) -> hp",P()["hp"]); assert P()["hp"]==2
grab()
load_room(0); load_room(1)
print("re-enter room 1 -> potion bit",bool(m.memory[RM+8+2]&0x40)); assert not m.memory[RM+8+2]&0x40
# full health: the potion is kept for later
load_room(5); stage(72,18,0,hp=3)
print("room 5 potion at (2,0): byte",hex(m.memory[RM+2])); assert m.memory[RM+2]&0x40
run(3,s=True); print("crouch at full health -> hp",P()["hp"],"potion still there:",bool(m.memory[RM+2]&0x40)); assert P()["hp"]==3 and m.memory[RM+2]&0x40
# ======== loose floor ========
load_room(1)
print("loose tile (5,0):",m.memory[RM+5]); assert m.memory[RM+5]==6
stage(112,18,0)                      # standing on col 3: not the loose tile
run(6); print("next to it -> still loose:",m.memory[RM+5]==6); assert m.memory[RM+5]==6
stage(152,18,0)                      # centre in col 5
tr=[]
for i in range(14):
    keys(); pump(); tr.append((m.memory[RM+5],mem("LOOSE_ARM"),P()["row"],mem("PSTATE"),P()["y"]))
    if i==1: grab()
    if i==6: grab()
print("step on it   (tile, armed, row, state, y):",tr)
assert tr[0][1]==4 and m.memory[RM+5]==0 and P()["row"]==1 and P()["y"]==82 and P()["hp"]==3 and m.memory[FL+1]&4
grab()
load_room(0); load_room(1)
print("re-enter room 1 -> tile (5,0) is",m.memory[RM+5]); assert m.memory[RM+5]==0
# restarting the level brings everything back
m.sp-=2; m.memory[m.sp]=FD&255; m.memory[m.sp+1]=FD>>8; m.pc=sym["RESPAWN"]; pump()
load_room(1)
print("after a level restart: loose",m.memory[RM+5],"potion bit",bool(m.memory[RM+8+2]&0x40)); assert m.memory[RM+5]==6 and m.memory[RM+8+2]&0x40
# montage
w,h=snaps[0].size
M=Image.new("RGB",(3*(w//2)+12,2*(h//2)+6),(0,0,0))
for k,im in enumerate(snaps[:6]): M.paste(im.resize((w//2,h//2),Image.NEAREST),((k%3)*(w//2+6),(k//3)*(h//2+6)))
M.save("items_montage.png"); print("ALL ITEM TESTS OK")
