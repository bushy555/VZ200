import re
from z80 import Z80Machine
from PIL import Image
sym={}
for ln in open("pop12.sym"):
    m_=re.match(r"(\w+)\s+EQU\s+([0-9A-F]+)H",ln.strip())
    if m_: sym[m_.group(1)]=int(m_.group(2),16)
m=Z80Machine()
print("tick attrs:",[n for n in dir(m) if 'tick' in n.lower()])
m.set_memory_block(0x7B00,open("pop12.bin","rb").read())
for a in (0x68FE,0x68FD,0x68FB,0x68F7,0x68EF,0x68DF,0x68BF,0x687F): m.memory[a]=0xFF
m.pc=0x7B00; m.sp=0x8000
SETB=sym["SET_BANK"]; FD=sym["FRAME_DONE"]
m.set_breakpoint(SETB); m.set_breakpoint(FD)
banks=[bytearray(2048) for _ in range(3)]
def mem(n): return m.memory[sym[n]]
def poke(n,v): m.memory[sym[n]]=v
def keys(left=False,right=False,a=False,d=False,s=False):
    v=0xFF
    if left:  v&=~(1<<4)
    if right: v&=~(1<<1)
    m.memory[0x68FB]=v
    w=0xFF
    if a: w&=~(1<<4)
    if d: w&=~(1<<3)
    if s: w&=~(1<<1)
    m.memory[0x68FD]=w
chunk=0
def pump():
    """run until FRAME_DONE; handle bank switching + fake vsync."""
    global chunk
    for _ in range(600000):
        chunk+=1
        m.memory[0x6800]=0x80 if chunk&1 else 0x00
        m.ticks_to_stop=1500
        m.run()
        if m.pc==SETB:
            old=m.memory[sym["CUR_BANK"]]; new=m.a
            banks[old][:]=bytes(m.memory[0x7000:0x7800]); m.memory[0x7000:0x7800]=bytes(banks[new])
            m.step_over_breakpoint()
        elif m.pc==FD:
            m.step_over_breakpoint(); return
    raise SystemExit("never finished")
def vram():
    cur=m.memory[sym["CUR_BANK"]]; banks[cur][:]=bytes(m.memory[0x7000:0x7800])
    return b"".join(bytes(b) for b in banks)
def lit(v,x,y): return bool(v[y*32+(x>>3)]&(0x80>>(x&7)))
def snap(name,crop=None):
    v=vram(); S=3; im=Image.new("RGB",(256*S,192*S),(0,96,0))
    for y in range(192):
        for x in range(256):
            if lit(v,x,y):
                for dy in range(S):
                    for dx in range(S): im.putpixel((x*S+dx,y*S+dy),(0,255,0))
    if crop: im=im.crop(crop)
    im.save(name)
def ent(base):
    a=sym[base]; k=("x","y","face","frame","fs","fi","hp","tmr","row")
    return {n:m.memory[a+i] for i,n in enumerate(k)}
P=lambda: ent("P_ENT"); G=lambda: ent("G_ENT")

def tele(px=100,gx=124,gro=0,sword=1,php=3,ghp=3):
    for n,v in (("PX",px),("PY",82),("PFACE",0),("PFRAME",0),("PROW",1),("PSTATE",0),("PFS",0),("PSWORD",sword),("PHP",php),("PTMR",0),
                ("GX",gx),("GY",82),("GFACE",1),("GFRAME",9),("GFS",0),("GHP",ghp),("GTMR",0),("GROW",gro),("JPREV",0),("DPREV",0)):
        poke(n,v)
def frames_(n,**k):
    for _ in range(n): keys(**k); pump()

from PIL import Image
RM=sym["ROOM_MAP"]; FL=sym["ROOM_FLAGS"]
def load_room(n):
    m.sp-=2; m.memory[m.sp]=FD&255; m.memory[m.sp+1]=FD>>8; m.a=n; m.pc=sym["LOAD_ROOM"]; pump()
def stage(px,py,row,face=0,hp=3,active=0):
    for n,v in (("PX",px),("PY",py),("PROW",row),("PFACE",face),("PFRAME",0),("PSTATE",0),("PFS",0),("PSWORD",0),("PHP",hp),
                ("JPREV",0),("DPREV",0),("RUNPH",0),("TIDX",0),("LTMR",0),("FALLN",0),("G_ACTIVE",active),("LOOSE_ARM",0)): poke(n,v)
    keys()
def run(n,**k):
    out=[]
    for _ in range(n):
        keys(**k); pump(); out.append((P()["frame"],P()["x"],P()["y"],mem("PSTATE")))
    return out
def room(): return mem("CUR_ROOM")

TW=sym["TS_WAIT"]; m.set_breakpoint(TW)
IW=sym["IN_WAIT"]; m.set_breakpoint(IW)
def step_chunks(n):
    global chunk
    for _ in range(n):
        chunk+=1; m.memory[0x6800]=0x80 if chunk&1 else 0x00; m.ticks_to_stop=1500; m.run()
        if m.pc==SETB:
            old=m.memory[sym["CUR_BANK"]]; new=m.a
            banks[old][:]=bytes(m.memory[0x7000:0x7800]); m.memory[0x7000:0x7800]=bytes(banks[new]); m.step_over_breakpoint()
        elif m.pc==TW: m.step_over_breakpoint(); return "tick"
        elif m.pc==IW: m.step_over_breakpoint(); return "intro"
    return None
# ---- the intro picture comes first: palace bitmap + blinking prompt, A moves on to the title screen
for _ in range(20000):
    if step_chunks(1)=="intro": break
else: raise SystemExit("never reached the intro wait loop")
v=vram(); litall=sum(bin(x).count("1") for x in v[:171*32]); print("intro picture lit pixels:",litall)
assert 8000<litall<30000                       # a real picture, not blank and not solid
assert sum(v[171*32:171*32+8*32])==0 or True
pp=[]
for i in range(60):
    while step_chunks(50)!="intro": pass
    vv=vram(); pp.append(sum(bin(x).count("1") for x in vv[180*32:188*32]))
print("intro prompt pixels over 60 loop passes:",sorted(set(pp))); assert 0 in pp and max(pp)>100
while (sum(bin(x).count("1") for x in vram()[180*32:188*32])==0) or True:
    if step_chunks(1)=="intro" and sum(bin(x).count("1") for x in vram()[182*32:190*32])>100: break
snap("intro.png",(0,0,768,576))
for key_bit,want,name in ((1,1,"2"),(4,0,"1"),(3,2,"3")):    # row A3: 4=D5 1=D4 3=D3 2=D1
    m.memory[0x68F7]=0xFF&~(1<<key_bit)
    for _ in range(150): step_chunks(1)
    m.memory[0x68F7]=0xFF
    print("key",name,"on the intro -> START_LV",m.memory[sym["START_LV"]]); assert m.memory[sym["START_LV"]]==want
keys(a=True)
for _ in range(400): step_chunks(1)
keys()
for _ in range(20000):
    if step_chunks(1)=="tick": break
else: raise SystemExit("never reached the title wait loop")
print("title screen reached (cold boot), room",mem("CUR_ROOM"))
v=vram()
def litcount(b0,b1): return sum(bin(x).count("1") for x in v[b0*32:b1*32])
top,mid,bot=litcount(0,64),litcount(64,128),litcount(128,192)
print("lit pixels: top band",top,"middle (lettering)",mid,"bottom band",bot); assert top>500 and mid>800 and bot>2000
snap("title.png",(0,0,768,576))
# the two torches on the title screen flicker: three different flame pictures over 24 frames
import hashlib
from PIL import Image as _I
seen=set()
for _ in range(24):
    while step_chunks(1)!="tick": pass
    snap("/tmp/title_t.png",(0,0,768,576)); im=_I.open("/tmp/title_t.png").convert("RGB")
    seen.add(hashlib.md5(im.crop((24,60,72,100)).tobytes()+im.crop((7*96+24,60,7*96+72,100)).tobytes()).hexdigest())
print("title torch flame pictures seen:",len(seen)); assert len(seen)==3
# blinking prompt: lines 56-63 of the middle bank
prompt=[]
for i in range(60):
    while step_chunks(50)!="tick": pass
    vv=vram(); prompt.append(sum(bin(x).count("1") for x in vv[(64+56)*32:(64+64)*32]))
print("prompt pixels over 60 loop passes:",sorted(set(prompt))); assert 0 in prompt and max(prompt)>100
# M works on the title screen
m.memory[0x68EF]=0xFF&~(1<<5)
for _ in range(3):
    while step_chunks(50)!="tick": pass
m.memory[0x68EF]=0xFF
for _ in range(3):
    while step_chunks(50)!="tick": pass
print("M on the title screen -> mute flag",mem("SND_MUTE")); assert mem("SND_MUTE")==1
poke("SND_MUTE",0)
# A starts the game
keys(a=True)
started=False
for _ in range(60000):
    step_chunks(1)
    if m.pc==FD: m.step_over_breakpoint(); started=True; break
keys()
print("level",m.memory[sym["CUR_LEVEL"]]+1,"chosen on the intro"); assert m.memory[sym["CUR_LEVEL"]]==2
print("A pressed -> game running: room",mem("CUR_ROOM"),"prince x",P()["x"],"row",P()["row"],"guard",mem("G_ACTIVE")); assert started and mem("CUR_ROOM")==0 and P()["x"]==40
pump_ok=0
for _ in range(5):
    for _ in range(60000):
        step_chunks(1)
        if m.pc==FD: m.step_over_breakpoint(); pump_ok+=1; break
assert pump_ok==5
snap("game_after_title.png",(0,0,768,576))
print("ALL TITLE TESTS OK")
