import re
from z80 import Z80Machine
from PIL import Image
sym={}
for ln in open("pop12.sym"):
    m_=re.match(r"(\w+)\s+EQU\s+([0-9A-F]+)H",ln.strip())
    if m_: sym[m_.group(1)]=int(m_.group(2),16)
m=Z80Machine()
print("tick attrs:",[n for n in dir(m) if 'tick' in n.lower()])
m.set_memory_block(0x7B00,open("pop12.bin","rb").read())
m.memory[sym["TITLE_SCREEN"]]=0xC9   # tests start in the game, not on the title
m.memory[sym["INTRO_SCREEN"]]=0xC9   # ... nor on the intro picture
for a in (0x68FE,0x68FD,0x68FB,0x68F7,0x68EF,0x68DF,0x68BF,0x687F): m.memory[a]=0xFF
m.pc=0x7B00; m.sp=0x8000
SETB=sym["SET_BANK"]; FD=sym["FRAME_DONE"]
m.set_breakpoint(SETB); m.set_breakpoint(FD)
banks=[bytearray(2048) for _ in range(3)]
def mem(n): return m.memory[sym[n]]
def poke(n,v): m.memory[sym[n]]=v
def keys(left=False,right=False,a=False,d=False,s=False):
    v=0xFF
    if left:  v&=~(1<<4)
    if right: v&=~(1<<1)
    m.memory[0x68FB]=v
    w=0xFF
    if a: w&=~(1<<4)
    if d: w&=~(1<<3)
    if s: w&=~(1<<1)
    m.memory[0x68FD]=w
chunk=0
def pump():
    """run until FRAME_DONE; handle bank switching + fake vsync."""
    global chunk
    for _ in range(600000):
        chunk+=1
        m.memory[0x6800]=0x80 if chunk&1 else 0x00
        m.ticks_to_stop=1500
        m.run()
        if m.pc==SETB:
            old=m.memory[sym["CUR_BANK"]]; new=m.a
            banks[old][:]=bytes(m.memory[0x7000:0x7800]); m.memory[0x7000:0x7800]=bytes(banks[new])
            m.step_over_breakpoint()
        elif m.pc==FD:
            m.step_over_breakpoint(); return
    raise SystemExit("never finished")
def vram():
    cur=m.memory[sym["CUR_BANK"]]; banks[cur][:]=bytes(m.memory[0x7000:0x7800])
    return b"".join(bytes(b) for b in banks)
def lit(v,x,y): return bool(v[y*32+(x>>3)]&(0x80>>(x&7)))
def snap(name,crop=None):
    v=vram(); S=3; im=Image.new("RGB",(256*S,192*S),(0,96,0))
    for y in range(192):
        for x in range(256):
            if lit(v,x,y):
                for dy in range(S):
                    for dx in range(S): im.putpixel((x*S+dx,y*S+dy),(0,255,0))
    if crop: im=im.crop(crop)
    im.save(name)
def ent(base):
    a=sym[base]; k=("x","y","face","frame","fs","fi","hp","tmr","row")
    return {n:m.memory[a+i] for i,n in enumerate(k)}
P=lambda: ent("P_ENT"); G=lambda: ent("G_ENT")

pump()
def tele(px=100,gx=124,gro=0,sword=1,php=3,ghp=3):
    for n,v in (("PX",px),("PY",82),("PFACE",0),("PFRAME",0),("PROW",1),("PSTATE",0),("PFS",0),("PSWORD",sword),("PHP",php),("PTMR",0),
                ("GX",gx),("GY",82),("GFACE",1),("GFRAME",9),("GFS",0),("GHP",ghp),("GTMR",0),("GROW",gro),("JPREV",0),("DPREV",0)):
        poke(n,v)
def frames_(n,**k):
    for _ in range(n): keys(**k); pump()
# 1) D draws the sword
tele(sword=0); keys(); pump(); keys(d=True); pump(); keys()
seq=[P()["frame"]]
for i in range(3): pump(); seq.append(P()["frame"])
print("draw sword  -> frames",seq); assert seq[:3]==[17,18,9] and mem("PSWORD")==1
keys(d=True); pump(); keys(); seq=[P()["frame"]]
for i in range(3): pump(); seq.append(P()["frame"])
print("sheathe     -> frames",seq); assert seq[:3]==[18,17,0] and mem("PSWORD")==0
# 2) a strike in reach hurts the guard (guard frozen: GROW=0 keeps his AI idle)
tele(); pump(); keys(a=True); pump(); keys()
tr=[]
for i in range(5): pump(); tr.append((P()["fs"],P()["frame"],G()["hp"],G()["fs"]))
print("strike in reach (prince fs,frame, guard hp,fs):",tr); assert G()["hp"]==2 and G()["x"]==128
snap("t5_hit.png",(150,150,700,450))
# 3) out of reach: no damage
tele(gx=150); pump(); keys(a=True); pump(); keys(); frames_(6)
print("strike out of reach -> guard hp",G()["hp"]); assert G()["hp"]==3
# 4) a parrying guard blocks it
tele(); pump(); keys(a=True); poke("GFS",3); pump(); keys()
for i in range(5): poke("GFS",3); pump()
print("strike vs parry     -> guard hp",G()["hp"]); assert G()["hp"]==3
# 5) killing blow: guard stays down
tele(ghp=1); pump(); keys(a=True); pump(); keys(); frames_(5)
print("killing blow        ->",G()); assert G()["hp"]==0 and G()["fs"]==5 and G()["frame"]==15
frames_(20); assert G()["fs"]==5; snap("t5_dead_guard.png",(0,150,768,576))
# 6) cannot walk into the guard
tele(px=80,gx=124); pump(); frames_(15,right=True)
print("walk into guard     -> gap",G()["x"]-P()["x"]); assert G()["x"]-P()["x"]>=14
# 7) the guard fights back (unarmed prince, guard awake on the same row)
tele(px=100,gx=124,gro=1,sword=0); pump(); hp=[]
for i in range(120):
    keys(); pump(); hp.append(P()["hp"])
    if P()["hp"]<3 and len(hp)>0 and "snap" not in globals().get("done",""): 
        snap("t5_hurt.png",(150,150,700,450)); done="snap"
print("guard attacks       -> prince hp trace",sorted(set(hp),reverse=True),"final state",P()); assert min(hp)<3
# 8) death resets the fight
tele(px=100,gx=124,gro=1,sword=0,php=1); pump(); died=False; reset=False
for i in range(200):
    keys(); pump()
    if P()["fs"]==5: died=True
    if died and P()["fs"]==0 and P()["hp"]==3: reset=True; break
print("death -> reset      ->",died,reset,P(),"guard",G()); assert died and reset and P()["x"]==40
# 9) a whole fight with the sword: prince strikes whenever the guard is in reach
tele(px=100,gx=124,gro=1,sword=1); pump()
log=[]
for i in range(300):
    gap=abs(G()["x"]-P()["x"])
    keys(a=(gap<=28 and P()["fs"]==0), right=(gap>28), s=(G()["fs"]==2 and gap<=30 and i%5==0)); pump()
    if i%25==0: log.append((i,P()["hp"],G()["hp"],gap))
    if G()["hp"]==0 or P()["hp"]==0: break
print("auto fight log (frame, prince hp, guard hp, gap):",log,"-> ended at",i,"P",P()["hp"],"G",G()["hp"])
snap("t5_fight.png",(120,150,720,480))
print("ALL FIGHT TESTS OK")
