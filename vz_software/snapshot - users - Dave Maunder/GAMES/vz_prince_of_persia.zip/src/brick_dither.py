# brick_dither.py - tiles.txt -> tiles_dither_<style>.txt : brick faces dithered like the Apple ][ original.
# Edge pixels (lit pixels touching a dark one) keep their outline; the inside of every brick is replaced by a dither:
#   checker = 50% checkerboard   light = ordered dither, about 75% lit (closest in tone to the Apple bricks)
import sys
styles={"checker":lambda x,y:(x+y)%2==0,
        "light":lambda x,y:((x%2==0 and y%2==0)==False) and not (x%4==1 and y%4==1) if False else ((x+y)%2==0 or (x%2==0 and y%4==1)),
        "sparse":lambda x,y:(x%2==0 and y%2==0) or (x%2==1 and y%2==1 and (x//2+y//2)%2==0)}
def conv(lines,start,fn,xmax=32):
    # rows of one tile section: lines[start:start+64]
    g=[list(l) for l in lines[start:start+64]]
    H=len(g); W=32
    out=[r[:] for r in g]
    for y in range(H):
        for x in range(min(W,xmax)):
            if g[y][x]!="#": continue
            nb=[(x+1,y),(x-1,y),(x,y+1),(x,y-1)]
            edge=any(not(0<=a<W and 0<=b<H) or g[b][a]!="#" for a,b in nb)
            if not edge: out[y][x]="#" if fn(x,y) else "."
    return ["".join(r) for r in out]
def run(src,dst,style,names=("WALL","WALLR","PILLAR")):
    fn=styles[style]; L=open(src).read().replace("\r","").split("\n"); res=L[:]
    for i,l in enumerate(L):
        if l.startswith("[") and l[1:-1] in names:
            n=l[1:-1]
            # the section's art starts on the next line and is 64 rows (blank rows are kept as '.' rows or empty lines)
            body=L[i+1:i+65]
            if len(body)<64 or any(len(r)!=32 for r in body): print("skip",n,"(unexpected shape)"); continue
            res[i+1:i+65]=conv(L,i+1,fn,23 if n=="WALLR" else 32)
    open(dst,"w").write("\n".join(res))
if __name__=="__main__":
    for st in styles: run("tiles.txt","tiles_dither_%s.txt"%st,st); print("wrote tiles_dither_%s.txt"%st)
