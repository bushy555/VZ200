import re
from z80 import Z80Machine
from PIL import Image
sym={}
for ln in open("pop12.sym"):
    m=re.match(r"(\w+)\s+EQU\s+([0-9A-F]+)H",ln.strip())
    if m: sym[m.group(1)]=int(m.group(2),16)
m=Z80Machine()
m.set_memory_block(0x7B00,open("pop12.bin","rb").read())
m.memory[sym["TITLE_SCREEN"]]=0xC9   # tests start in the game, not on the title
m.memory[sym["INTRO_SCREEN"]]=0xC9   # ... nor on the intro picture
for a in (0x68FE,0x68FD,0x68FB,0x68F7,0x68EF,0x68DF,0x68BF,0x687F): m.memory[a]=0xFF
m.pc=0x7B00; m.sp=0x8000
SETB=sym["SET_BANK"]; FD=sym["FRAME_DONE"]
m.set_breakpoint(SETB); m.set_breakpoint(FD)
banks=[bytearray(2048) for _ in range(3)]
def mem(n): return m.memory[sym[n]]
def keys(left=False,right=False,a=False):
    m.memory[0x68FD]=0xFF&~(1<<4) if a else 0xFF
    v=0xFF
    if left:  v&=~(1<<4)
    if right: v&=~(1<<1)
    m.memory[0x68FB]=v
chunk=0
def run_until_frame():
    global chunk
    for _ in range(400000):
        chunk+=1
        m.memory[0x6800]=0x80 if chunk&1 else 0x00     # fake vsync toggling
        m.ticks_to_stop=1500
        m.run()
        if m.pc==SETB:
            old=m.memory[sym["CUR_BANK"]]; new=m.a
            banks[old][:]=bytes(m.memory[0x7000:0x7800])
            m.memory[0x7000:0x7800]=bytes(banks[new])
            m.step_over_breakpoint()
        elif m.pc==FD:
            m.step_over_breakpoint(); return True
    raise SystemExit("frame never finished")
def state(): return dict(px=mem("PX"),py=mem("PY"),row=mem("PROW"),face=mem("PFACE"),fr=mem("PFRAME"),st=mem("PSTATE"))
def snap(name):
    # flush current window into its bank, then render all three
    cur=m.memory[sym["CUR_BANK"]]; banks[cur][:]=bytes(m.memory[0x7000:0x7800])
    v=b"".join(bytes(b) for b in banks)
    S=3; im=Image.new("RGB",(256*S,192*S),(0,96,0))
    for y in range(192):
        for x in range(256):
            if v[y*32+(x>>3)]&(0x80>>(x&7)):
                for dy in range(S):
                    for dx in range(S): im.putpixel((x*S+dx,y*S+dy),(0,255,0))
    im.save(name)

run_until_frame()
def tele(x,y,row,face=0):
    m.memory[sym["GROW"]]=0
    for n,v in (("PX",x),("PY",y),("PROW",row),("PFACE",face),("PSTATE",0),("PFRAME",0),("JPREV",0)):
        m.memory[sym[n]]=v
def jump(tag,x,y,row,face,left,right,frames=12,shots=(),runph=3):
    tele(x,y,row,face); keys(); run_until_frame(); tele(x,y,row,face); m.memory[sym["RUNPH"]]=runph
    keys(left,right,True); run_until_frame()      # press A with the direction
    keys()
    ys=[state()["py"]]
    for i in range(frames):
        run_until_frame(); s=state(); ys.append(s["py"])
        if i in shots: snap("t_%s_%d.png"%(tag,i))
    print(tag,"->",state(),"py trace",ys)
    return state()
# 1) running jump over the pit from the ledge side: expect to land on the far floor (px 168, row 1)
s=jump("over",104,82,1,0,False,True,shots=(2,3,4))
assert s["st"]==0 and s["row"]==1 and s["px"]==168,s
# 2) too early: lands in the pit, falls onto the spikes, respawns
s=jump("short",64,82,1,0,False,True,frames=20)
print("short jump ends at",s)
# 3) standing jump straight up: same spot afterwards
s=jump("hop",64,82,1,0,False,False)
assert s["px"]==64 and s["py"]==82 and s["st"]==0,s
# 4) jump on the top row: sprite must never wrap above the screen
s=jump("top",140,18,0,0,False,True)
# 5) left-facing running jump back over the pit
s=jump("back",180,82,1,1,True,False,frames=12)
print("back jump lands",s)
print("ALL JUMP TESTS OK")
