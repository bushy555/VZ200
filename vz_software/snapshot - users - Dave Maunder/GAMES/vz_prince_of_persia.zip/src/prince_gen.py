#!/usr/bin/env python3
"""prince_gen.py - draws the prince's frames from a small body model (turban, face, vest, baggy trousers, bare arms and feet)
and writes them into sprites.txt (same frame order, names and canvas sizes as before).

    python3 prince_gen.py                 # sprites_old.txt (original blocky art) -> sprites.txt with the new frames
    python3 prince_gen.py --sheet out.png # also write a contact sheet (old above new)

Every pose is a handful of angles (degrees; limbs: 0 = hanging straight down, positive = swung forward/right) -
edit POSES below and re-run.  Tones: lit = white clothes, 'dither' = skin (arms, feet).
"""
import sys, math
import numpy as np
from PIL import Image, ImageDraw
SS=8                                   # supersampling for clean shapes
import os
ARMS=os.environ.get('PRINCE_ARMS','solid')   # 'dither' = bare orange arms drawn as a 50% dither, like the original

# ---------------------------------------------------------------- body model
TORSO=12.0; THIGH=10.0; SHIN=10.0; UARM=6.2; FARM=6.0; NECK=1.2

class Canvas:
    def __init__(s,w,h): s.w=w; s.h=h; s.pix=np.zeros((h,w),dtype=np.uint8)
    def mask(s,drawfn):
        im=Image.new("L",(s.w*SS,s.h*SS),0); d=ImageDraw.Draw(im); drawfn(d)
        a=np.asarray(im.resize((s.w,s.h),Image.BOX)).astype(float)
        return a>=110
    def paint(s,m,tone="solid",halo=False):
        if halo:
            h=m.copy()
            h[1:,:]|=m[:-1,:]; h[:-1,:]|=m[1:,:]; h[:,1:]|=m[:,:-1]; h[:,:-1]|=m[:,1:]
            s.pix[h&~m]=0
        if tone=="solid": s.pix[m]=1
        elif tone=="erase": s.pix[m]=0
        elif tone=="dither":
            yy,xx=np.indices(s.pix.shape); on=((xx+yy)%2==0)
            s.pix[m]=0; s.pix[m&on]=1
def P(x,y): return (x*SS,y*SS)
def capsule(d,p0,p1,r0,r1):
    (x0,y0),(x1,y1)=p0,p1; dx,dy=x1-x0,y1-y0; L=math.hypot(dx,dy) or 1; nx,ny=-dy/L,dx/L
    d.polygon([P(x0+nx*r0,y0+ny*r0),P(x1+nx*r1,y1+ny*r1),P(x1-nx*r1,y1-ny*r1),P(x0-nx*r0,y0-ny*r0)],fill=255)
    for (x,y,r) in ((x0,y0,r0),(x1,y1,r1)): d.ellipse([P(x-r,y-r),P(x+r,y+r)],fill=255)
def ell(d,c,rx,ry): d.ellipse([P(c[0]-rx,c[1]-ry),P(c[0]+rx,c[1]+ry)],fill=255)
def poly(d,pts): d.polygon([P(*p) for p in pts],fill=255)
def dirv(deg): a=math.radians(deg); return (math.sin(a),math.cos(a))      # 0 = down, + = forward (right)


HEAD=[ "..####..",
       ".######.",
       "#######.",
       "#######.",
       ".###.###",
       "..######",
       "...####.",
       "....##.."]
HEAD_FRONT=[ "..#####..",
             ".#######.",
             "#########",
             "#########",
             ".##.#.##.",
             ".#######.",
             "..#####..",
             "...###..."]
def stamp(c,tpl,x,y,flip=False):
    for j,row in enumerate(tpl):
        for i,ch in enumerate(row):
            xx=x+(len(row)-1-i if flip else i); yy=y+j
            if 0<=xx<c.w and 0<=yy<c.h: c.pix[yy,xx]=1 if ch=="#" else c.pix[yy,xx]

def draw_prince(w,h,pose,front=False):
    c=Canvas(w,h); px,py=pose["p"]; lean=pose.get("lean",0); tilt=pose.get("tilt",0)
    if w==16 and lean>0 and not pose.get("keepx"): px=px-lean*0.09
    td=(math.sin(math.radians(lean)),-math.cos(math.radians(lean)))        # torso direction (pelvis -> neck), 0 = up
    pel=(px,py); neck=(px+td[0]*TORSO,py+td[1]*TORSO); sh=(px+td[0]*(TORSO-1.6),py+td[1]*(TORSO-1.6))
    hd=(neck[0]+math.sin(math.radians(lean+tilt))*4.6,neck[1]-math.cos(math.radians(lean+tilt))*4.6)
    def limb(root,a1,f1,l1,l2):
        k=(root[0]+dirv(a1)[0]*l1,root[1]+dirv(a1)[1]*l1); a2=a1-f1 if l1>=THIGH-0.1 else a1+f1
        e=(k[0]+dirv(a2)[0]*l2,k[1]+dirv(a2)[1]*l2); return k,e,a2
    hip=(px,py+0.8)
    # legs: (thigh angle, knee flex) ; shin = thigh - flex
    legs={}
    for nm in ("far","near"):
        t,f=pose["leg_"+nm]; k,a,a2=limb(hip,t,f,THIGH,SHIN); legs[nm]=(k,a,a2)
    arms={}
    for nm in ("far","near"):
        a1,fl=pose["arm_"+nm]; e,hnd,a2=limb(sh,a1,fl,UARM,FARM); arms[nm]=(e,hnd)
    foot_len=pose.get("foot",3.4)
    def leg_parts(nm,halo):
        k,a,a2=legs[nm]
        toe=(a[0]+foot_len*pose.get("foot_dir",1)*math.cos(math.radians(pose.get("foot_rot",0))),a[1]+0.6+foot_len*math.sin(math.radians(pose.get("foot_rot",0))))
        c.paint(c.mask(lambda d:(capsule(d,hip,k,3.3,2.5),capsule(d,k,a,2.3,1.4))),"solid",halo)
        c.paint(c.mask(lambda d:capsule(d,(a[0],a[1]-0.2),toe,1.15,0.9)),"solid",False)
    def arm_parts(nm,halo):
        e,hnd=arms[nm]
        c.paint(c.mask(lambda d:(capsule(d,sh,e,1.6,1.4),capsule(d,e,hnd,1.4,1.1),ell(d,hnd,1.2,1.2))),ARMS,halo)
    # layers, back to front
    if not front:
        arm_parts("far",False); leg_parts("far",False)
        if pose.get("armsback"): arm_parts("near",False)
        # torso + pelvis
        pp=(-td[1],td[0])
        c.paint(c.mask(lambda d:(poly(d,[(sh[0]+pp[0]*4.3,sh[1]+pp[1]*4.3),(neck[0]+pp[0]*2.0,neck[1]+pp[1]*2.0),(neck[0]-pp[0]*2.0,neck[1]-pp[1]*2.0),
                (sh[0]-pp[0]*3.8,sh[1]-pp[1]*3.8),(pel[0]-pp[0]*3.4,pel[1]-pp[1]*3.4),(pel[0]+pp[0]*3.6,pel[1]+pp[1]*3.6)]),ell(d,(px,py+1.2),4.0,3.2))),"solid",False)
        leg_parts("near",True)
        # head: hand-drawn template; its bottom row sits on the neck
        hx=int(round(neck[0]))-4+int(round(pose.get("headdx",0))); hy=int(round(neck[1]))-8+int(round(pose.get("headdy",0)))
        c.paint(c.mask(lambda d:capsule(d,(neck[0],neck[1]+1.0),(neck[0]+0.3,neck[1]-1.2),1.5,1.4)),"solid",False)
        stamp(c,HEAD,hx,hy)
        if not pose.get("armsback"): arm_parts("near",True)
    else:   # front view (turning): symmetrical, wider shoulders, two eyes, legs side by side
        for nm,sx in (("far",-2.6),("near",2.6)):
            top=(px+sx*0.8,py+1); k=(px+sx,py+THIGH); a=(px+sx*1.05,py+THIGH+SHIN)
            c.paint(c.mask(lambda d:(capsule(d,top,k,2.8,2.3),capsule(d,k,a,2.3,1.6))),"solid",True)
            c.paint(c.mask(lambda d:capsule(d,(a[0],a[1]),(a[0]+sx*0.5,a[1]+0.8),1.3,1.2)),"solid",False)
        c.paint(c.mask(lambda d:poly(d,[(px-4.2,sh[1]),(px+4.2,sh[1]),(px+2.6,py),(px-2.6,py)])),"solid",False)
        for sx in (-1,1):
            e=(px+sx*5.0,sh[1]+UARM*0.9); hnd=(px+sx*5.3,sh[1]+UARM+FARM*0.9)
            c.paint(c.mask(lambda d:(capsule(d,(px+sx*3.6,sh[1]+0.5),e,1.5,1.3),capsule(d,e,hnd,1.3,1.0),ell(d,hnd,1.15,1.15))),"solid",True)
        hx=int(round(px))-4; hy=int(round(neck[1]))-8
        c.paint(c.mask(lambda d:capsule(d,(px,neck[1]+1.0),(px,neck[1]-1.2),1.6,1.5)),"solid",False)
        stamp(c,HEAD_FRONT,hx,hy)
    # sword
    sw=pose.get("sword")
    if sw:
        ang,length=sw; e,hnd=arms["near"]; dx,dy=math.cos(math.radians(ang)),-math.sin(math.radians(ang))
        base=(hnd[0]+dx*1.2,hnd[1]+dy*1.2); tip=(hnd[0]+dx*length,hnd[1]+dy*length); gx_,gy_=-dy,dx
        c.paint(c.mask(lambda d:d.line([P(*base),P(*tip)],fill=255,width=int(0.9*SS))),"solid",False)
        c.paint(c.mask(lambda d:d.line([P(base[0]-gx_*2.0,base[1]-gy_*2.0),P(base[0]+gx_*2.0,base[1]+gy_*2.0)],fill=255,width=int(0.9*SS))),"solid",False)
    return c.pix

# ---------------------------------------------------------------- poses  (p = pelvis position; angles in degrees)
def pose(p,lean=0,arm_far=(-4,6),arm_near=(3,8),leg_far=(-3,0),leg_near=(1,0),**kw):
    d=dict(p=p,lean=lean,arm_far=arm_far,arm_near=arm_near,leg_far=leg_far,leg_near=leg_near); d.update(kw); return d
POSES={
 "PRINCE_STAND":    pose((8,21),2,arm_far=(-8,6),arm_near=(9,10),leg_far=(-5,0),leg_near=(4,0)),
 "PRINCE_RUN1":     pose((8,22),24,arm_far=(-38,10),arm_near=(24,62),leg_far=(-34,40),leg_near=(40,14)),
 "PRINCE_RUN2":     pose((8,22.6),26,arm_far=(30,64),arm_near=(-30,14),leg_far=(62,90),leg_near=(-6,6)),
 "PRINCE_RUN3":     pose((8,22),24,arm_far=(24,62),arm_near=(-38,10),leg_far=(40,14),leg_near=(-34,40)),
 "PRINCE_RUN4":     pose((8,22.6),26,arm_far=(-30,14),arm_near=(30,64),leg_far=(-6,6),leg_near=(62,90)),
 "PRINCE_JUMP":     pose((8,20.5),30,arm_far=(-40,30),arm_near=(95,20),leg_far=(-52,46),leg_near=(46,22)),
 "PRINCE_HANG":     pose((8,26),0,arm_far=(168,4),arm_near=(176,0),leg_far=(-8,24),leg_near=(6,10),armsback=True),
 "PRINCE_CLIMB1":   pose((8,27),6,arm_far=(150,20),arm_near=(168,-10),leg_far=(10,40),leg_near=(-4,16)),
 "PRINCE_CLIMB2":   pose((8,24),22,arm_far=(60,50),arm_near=(40,62),leg_far=(-6,6),leg_near=(74,92)),
 "PRINCE_GARDE":    pose((8,21),3,arm_far=(-26,100),arm_near=(66,22),leg_far=(-16,8),leg_near=(24,10),sword=(4,19)),
 "PRINCE_ADVANCE":  pose((8,21),6,arm_far=(-26,100),arm_near=(70,18),leg_far=(-20,10),leg_near=(32,12),sword=(4,19)),
 "PRINCE_STRIKE1":  pose((8,21),8,arm_far=(-30,60),arm_near=(62,52),leg_far=(-14,10),leg_near=(26,12),sword=(56,17)),
 "PRINCE_STRIKE2":  pose((8,24),20,arm_far=(-44,30),arm_near=(84,4),leg_far=(-52,4),leg_near=(58,52),sword=(1,26)),
 "PRINCE_PARRY":    pose((8,21),4,arm_far=(-26,56),arm_near=(52,66),leg_far=(-10,8),leg_near=(16,10),sword=(84,16)),
 "PRINCE_HURT":     pose((8,21),-8,tilt=-10,arm_far=(-20,30),arm_near=(40,20),leg_far=(-14,6),leg_near=(10,6),sword=(-55,14)),
 "PRINCE_RETREAT":  pose((8,21),-2,arm_far=(-28,58),arm_near=(44,40),leg_far=(-26,6),leg_near=(8,10),sword=(2,16)),
 "PRINCE_DRAW1":    pose((8,21),4,arm_far=(-20,40),arm_near=(-8,70),leg_far=(-10,6),leg_near=(14,8),sword=(-70,12)),
 "PRINCE_DRAW2":    pose((8,21),6,arm_far=(-26,50),arm_near=(50,56),leg_far=(-12,8),leg_near=(20,10),sword=(58,15)),
 "PRINCE_RUNSTART1":pose((8,21),8,arm_far=(-12,10),arm_near=(10,14),leg_far=(-6,0),leg_near=(8,6)),
 "PRINCE_RUNSTART2":pose((8,21.5),13,arm_far=(24,20),arm_near=(-26,30),leg_far=(24,10),leg_near=(-18,16)),
 "PRINCE_RUNSTOP1": pose((8,21),-6,arm_far=(14,20),arm_near=(-10,16),leg_far=(18,4),leg_near=(-6,2)),
 "PRINCE_RUNSTOP2": pose((8,21),-1,arm_far=(-4,8),arm_near=(4,10),leg_far=(-4,0),leg_near=(3,0)),
 "PRINCE_TURN1":    pose((8,21),0,arm_far=(-6,8),arm_near=(6,10),leg_far=(-3,0),leg_near=(3,0)),
 "PRINCE_TURN2":    None,   # front view
 "PRINCE_TURN3":    pose((8,21),0,arm_far=(-5,6),arm_near=(5,8),leg_far=(-2,0),leg_near=(2,0)),
 "PRINCE_CROUCH":   pose((6.5,31),24,arm_far=(30,34),arm_near=(44,30),leg_far=(86,100),leg_near=(80,96)),
 "PRINCE_LAND":     pose((8,26),24,arm_far=(-36,30),arm_near=(52,36),leg_far=(34,64),leg_near=(46,70)),
 "PRINCE_JWIND":    pose((7,28),26,arm_far=(-46,16),arm_near=(-38,24),leg_far=(58,80),leg_near=(66,86)),
 "PRINCE_JRISE":    pose((8,22),20,arm_far=(-30,20),arm_near=(120,10),leg_far=(-26,22),leg_near=(40,52)),
 "PRINCE_JAPEX":    pose((8,19),16,arm_far=(70,20),arm_near=(104,12),leg_far=(52,102),leg_near=(66,108)),
 "PRINCE_JFALL":    pose((8,21),6,arm_far=(-60,16),arm_near=(76,14),leg_far=(-12,24),leg_near=(30,44)),
 "PRINCE_FALL":     pose((8,22),0,arm_far=(146,16),arm_near=(166,6),leg_far=(-5,8),leg_near=(5,4),armsback=True),
 "PRINCE_JUMPUP":   pose((8,22),0,arm_far=(166,4),arm_near=(176,0),leg_far=(-6,24),leg_near=(8,30),armsback=True),
 "PRINCE_CLIMB3":   pose((8,22),14,arm_far=(30,40),arm_near=(46,50),leg_far=(-10,6),leg_near=(34,52)),
 "PRINCE_SWSTEPA": pose((8,21),3,arm_far=(-26,100),arm_near=(68,20),leg_far=(-5,6),leg_near=(11,8),sword=(4,19)),
 "PRINCE_SWSTEPB": pose((8,21),4,arm_far=(-26,100),arm_near=(67,21),leg_far=(6,10),leg_near=(-6,6),sword=(4,19)),
}
ALIGN={"PRINCE_HANG":"top","PRINCE_CLIMB1":"top","PRINCE_FALL":"top","PRINCE_JUMPUP":"top"}

def load(path):
    frames=[];cur=None;pre=[]
    for ln in open(path).read().split("\n"):
        if ln.startswith(";") and cur is None: pre.append(ln); continue
        if ln.startswith("["):
            parts=ln[1:-1].split(); cur=dict(head=ln,name=parts[0],rows=[]); frames.append(cur); continue
        if cur is not None and ln.strip(): cur["rows"].append(ln)
    return pre,frames

def render_dead(w,h):
    c=Canvas(w,h)
    pel=(9.0,10.5)
    c.paint(c.mask(lambda d:(capsule(d,(pel[0],pel[1]),(pel[0]-9,pel[1]+1.5),2.6,1.8),capsule(d,(pel[0],pel[1]-1.2),(pel[0]-8,pel[1]-2.2),2.4,1.7))),"solid",False)       # legs trailing left (knees up a little)
    c.paint(c.mask(lambda d:poly(d,[(pel[0],pel[1]-3.4),(pel[0]+11,pel[1]-3.9),(pel[0]+11,pel[1]+3.2),(pel[0],pel[1]+3.4)])),"solid",False)                           # torso
    c.paint(c.mask(lambda d:d.line([P(pel[0]+1.5,pel[1]+0.2),P(pel[0]+10.5,pel[1]+0.2)],fill=255,width=int(0.9*SS))),"erase",False)
    c.paint(c.mask(lambda d:capsule(d,(pel[0]+3,pel[1]-4.5),(pel[0]+10,pel[1]-6.5),1.4,1.2)),"solid",True)                                                              # arm flung up/out
    # head lying, face up: the upright head template turned a quarter turn
    tpl=np.rot90(np.array([[1 if ch=="#" else 0 for ch in r] for r in HEAD]),-1)
    hx=int(pel[0]+11); hy=int(pel[1]-4)
    for j in range(tpl.shape[0]):
        for i in range(tpl.shape[1]):
            if tpl[j,i] and 0<=hx+i<w and 0<=hy+j<h: c.pix[hy+j,hx+i]=1
    for x in range(31,39): c.pix[14,x]=1                       # the sword on the floor
    c.pix[13,31]=1; c.pix[15,31]=1
    return c.pix

def render_frame(fr):
    w=len(fr["rows"][0]); h=len(fr["rows"]); nm=fr["name"]
    if nm=="PRINCE_DEAD": return render_dead(w,h)
    ps=POSES[nm]
    pix=draw_prince(w,h,ps,front=(ps is None) if False else False) if ps else None
    if ps is None:
        pix=draw_prince(w,h,pose((8,21)),front=True)
    ys=np.where(pix.any(axis=1))[0]
    if len(ys):
        if ALIGN.get(nm)=="top": sh=-ys[0]
        else: sh=(h-1)-ys[-1]
        if sh: pix=np.roll(pix,sh,axis=0)
        if sh>0: pix[:sh,:]=0
        elif sh<0: pix[sh:,:]=0
    return pix
def main():
    sheet=None; args=sys.argv[1:]
    if "--sheet" in args: sheet=args[args.index("--sheet")+1]
    pre,frames=load("sprites_old.txt")
    out=list(pre); news={}
    for fr in frames:
        pix=render_frame(fr)
        news[fr["name"]]=pix
        out.append(fr["head"])
        if pix is None: rows=fr["rows"]            # PRINCE_DEAD: handled separately below
        else: rows=["".join("#" if v else "." for v in r) for r in pix]
        out+=rows; out.append("")
    open("sprites.txt","w").write("\n".join(out))
    if sheet:
        S=5; cols=9; cell_w=44*S//2+8; 
        rowsN=(len(frames)+cols-1)//cols
        im=Image.new("RGB",(cols*(24*S+10),rowsN*(2*42*S+30)),(24,24,24)); d=ImageDraw.Draw(im)
        for i,fr in enumerate(frames):
            x0=(i%cols)*(24*S+10); y0=(i//cols)*(2*42*S+30)
            d.text((x0,y0),fr["name"].replace("PRINCE_",""),fill=(220,220,220))
            for row,rows in ((0,fr["rows"]),(1,None)):
                if row==1:
                    pix=news[fr["name"]]; rows=["".join("#" if v else "." for v in r) for r in pix] if pix is not None else fr["rows"]
                for yy,r in enumerate(rows):
                    for xx,ch in enumerate(r):
                        if xx>=24: break
                        col=(0,255,0) if ch=="#" else (0,70,0)
                        d.rectangle([x0+xx*S,y0+14+row*(42*S+4)+yy*S,x0+xx*S+S-1,y0+14+row*(42*S+4)+yy*S+S-1],fill=col)
        im.save(sheet)
main()
