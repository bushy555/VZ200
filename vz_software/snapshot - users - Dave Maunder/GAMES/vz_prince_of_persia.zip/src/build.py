#!/usr/bin/env python3
"""build.py - regenerate the data files, assemble, write the .vz

    python3 build.py                      # builds pop12.asm -> VZPRINCE.VZ
    python3 build.py --asm pop12.asm --name MYGAME --out MYGAME.VZ
    python3 build.py --skel skel_hollow.txt --name VZPRINCEA   # the earlier hollow-legged skeleton (default skel.txt = stick-figure legs)
    python3 build.py --tiles tiles_hatch.txt --name VZPRINCEH    # the earlier hatch-line floor (default tiles.txt = dithered floor)
    python3 build.py --sprites sprites_classic.txt --name VZPRINCEC   # the earlier blocky prince art
    python3 build.py --tests              # also run every test_*.py (needs:  pip install z80 pillow)

Needs pasmo on the path.  The generators turn the editable text files into the .inc files the assembler includes:
    tiles.txt -> _tiles.inc      sprites.txt -> _sprites.inc      levels.txt -> _levels.inc      (font) -> _font.inc      intro_src.png -> _intro.inc
"""
import subprocess, sys, os, re, glob
def run(*cmd,**kw):
    r=subprocess.run(cmd,capture_output=True,text=True,**kw)
    return r
def main(argv):
    asm="pop12.asm"; name="VZPRINCE"; out=None; tests=False
    it=iter(argv)
    for a in it:
        if a=="--asm": asm=next(it)
        elif a=="--name": name=next(it)
        elif a=="--out": out=next(it)
        elif a=="--tests": tests=True
        elif a=="--skel": os.environ["SKEL_FILE"]=next(it)
        elif a=="--tiles": os.environ["TILES_FILE"]=next(it)
        elif a=="--sprites": os.environ["SPRITES_FILE"]=next(it)
        else: print(__doc__); return 1
    out=out or (name+".VZ")
    for g in ("make_tiles.py","make_sprites.py","make_text.py","make_levels.py","make_intro.py"):
        r=run(sys.executable,g)
        print(r.stdout.strip() or g)
        if r.returncode: print(r.stderr); return 1
    base=os.path.splitext(asm)[0]
    r=run("pasmo","--bin",asm,base+".bin",base+".sym")
    if r.returncode or "ERROR" in r.stdout+r.stderr:
        print(r.stdout+r.stderr); return 1
    body=open(base+".bin","rb").read()
    hdr=b"VZF0"+name.encode()[:16].ljust(17,b"\0")+bytes([0xF1,0x00,0x7B])
    open(out,"wb").write(hdr+body)
    sym={m.group(1):int(m.group(2),16) for m in (re.match(r"(\w+)\s+EQU\s+([0-9A-F]+)H",l.strip()) for l in open(base+".sym")) if m}
    end=sym["PROG_END"]
    print("%s: %d bytes, loads at $7B00, ends at $%X; %d bytes free below the stack/table page at $FE00 (after the 2 KB SHADOW buffer at $%X)"%(out,len(body),end,0xFE00-end-2048,end))
    if end+2048>0xFE00: print("!! program + 2 KB SHADOW buffer run into the stack page"); return 1
    if tests:
        bad=0
        for t in sorted(glob.glob("test_*.py")):
            r=run(sys.executable,t); last=(r.stdout.strip().splitlines() or ["(no output)"])[-1]
            ok=r.returncode==0              # every test asserts, so a clean exit means it passed
            print("  %-22s %s"%(t,"ok   "+last[:60] if ok else "FAIL "+last[:60])); bad+=0 if ok else 1
        return 1 if bad else 0
    return 0
if __name__=="__main__": sys.exit(main(sys.argv[1:]))
