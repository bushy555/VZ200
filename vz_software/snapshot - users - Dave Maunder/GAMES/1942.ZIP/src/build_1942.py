#!/usr/bin/env python3
"""Build 1942.asm / 1942.VZ for the VZ200/VZ300 (needs pasmo and pillow-free)."""
import subprocess, sys, struct, re
import gendata as g
import music

def blit_code():
    out = []
    for part, (lo, hi) in (("P1", (0, 64)), ("P2", (64, 128))):
        out.append("BLIT_%s:  ld (SAVESP),sp" % part)
        for j in range(lo, hi):
            row = 63 - (j >> 1)
            half = j & 1
            sp = 0x7000 + 32*row + (24 if half == 0 else 12)
            out.append("BP%d:     ld sp,0            ; src patched each frame" % j)
            out.append("        pop bc\n        pop de\n        pop hl\n        pop af\n        pop ix\n        pop iy")
            out.append("        ld sp,0%04Xh" % sp)
            out.append("        push bc\n        push de\n        push hl\n        push af\n        push ix\n        push iy")
        out.append("        ld sp,(SAVESP)\n        ret\n")
    # patcher
    out.append("PATCH_BLIT: ld hl,(W0)\n        ld de,-1534\n        add hl,de\n        ld de,12")
    for j in range(128):
        out.append("        ld (BP%d+1),hl" % j)
        if j != 127:
            out.append("        add hl,de")
    out.append("        ret")
    return "\n".join(out)

VARS = [("rngseed",1),("tick",1),("kheld",1),("joyon",1),("srow",1),("W0",2),
        ("scrollc",1),("px",1),("py",1),("plstate",1),("plexp",1),("invuln",1),("loopt",1),
        ("loops",1),("lives",1),("firecd",1),("inkeys",1),("stage",1),("wavecnt",1),
        ("spawncd",1),("dirty",1),("gover",1),("nsaved",1),("savep",2),("ds_x",1),("ds_h",1),
        ("ds_skip",1),("ds_rows",1),("ds_tab",2),("pr_w",1),("pr_h",1),("t1",1),("t2",1),
        ("t3",1),("SAVESP",2),("SCORE",6),("HISCORE",6),("STAGEBUF",2),("LOOPSTR",3),
        ("mcnt",1),("t4",1),("t5",1),("kills",1),("bossact",1),("bossx",1),("bossy",1),("bosshp",1),("bossdir",1),("bossfire",1),("bossexp",1),("bossnum",1),("txtn",1),("txtp",2),("gocnt",1),("TXTSAVE",150),("MUSVARS",40),("ENEMS",32),("PBULS",9),("EBULS",12),("SAVEBUF",16*40)]
def vars_block(P):
    out, off = [], 0
    skip = set()
    if 'MUSIC' not in P['flags']: skip |= {'mcnt', 'MUSVARS'}
    if 'BOSS' not in P['flags']: skip |= {'kills','bossact','bossx','bossy','bosshp','bossdir','bossfire','bossexp','bossnum'}
    for n, s in VARS:
        if n in skip: continue
        if n == 'SAVEBUF': s = P['slots'] * 40
        out.append("%-9s equ VARS+%d" % (n, off)); off += s
    out.append("VEND      equ VARS+%d" % off)
    return "\n".join(out)

def strline(t): return ",".join("0%02Xh" % b for b in g.text_idx(t))

def preprocess(text, flags):
    """;#IF FLAG / ;#ELSE / ;#END blocks (not nested)."""
    out, keep, stack = [], True, None
    for line in text.split("\n"):
        s = line.strip()
        if s.startswith(";#IF "):
            stack = s[5:].strip() in flags; keep = stack
        elif s == ";#ELSE":
            keep = not stack
        elif s == ";#END":
            keep = True; stack = None
        elif keep:
            out.append(line)
    return "\n".join(out)

# org   = load/run address, limit = last usable RAM address of the target machine
PROFILES = {
    # 32KB cartridge (e.g. Ben Venn SD Loader): everything, full pixel precision
    "full":  dict(flags={"MUSIC", "BOSS"}, height=192, step=1, precise=set(), slots=16, out="1942",
                  org=0x8000, limit=0xFFFF),
    # 16KB at $8000-$BFFF, no music / boss
    "lite":  dict(flags=set(), height=112, step=2, precise={"PL0","PLL","PLR"}, slots=11, out="1942_16K",
                  org=0x8000, limit=0xBFFF),
    # VZ300 18KB RAM map: starts at $7B00 (just above the BASIC system variables), no music / boss
    "vz300": dict(flags=set(), height=128, step=2, precise={"PL0","PL1","PL2","PLL","PLR"}, slots=11,
                  out="1942_VZ300", org=0x7B00, limit=0xBFFF),
    # VZ300 18KB RAM map WITH the intro music (no boss): short 96-row map, only the plane's
    # normal frame keeps 1-pixel precision
    "vz300music": dict(flags={"MUSIC"}, height=96, step=2, precise={"PL0"}, slots=11,
                  out="1942_VZ300_MUSIC", org=0x7B00, limit=0xBFFF),
    # VZ200 + 16KB RAM pack: $7B00-$CFFF, WITH intro music and the boss
    "vz200": dict(flags={"MUSIC", "BOSS"}, height=160, step=2, precise={"PL0","PLL","PLR"}, slots=14,
                  out="1942_VZ200_RAMPACK", org=0x7B00, limit=0xCFFF),
}

def build(profile="full"):
    P = PROFILES[profile]
    g.SHIFT_STEP = P["step"]; g.PRECISE = P["precise"]; g.set_height(P["height"])
    order = ['PL0','PL1','PL2','PLL','PLR','EN0','ENL','ENR','EX0','EX1','EX2','PB','EB']
    if "BOSS" in P["flags"]:
        order += ['BS0','BS1','BS2','BS3','BS4','BS5']
    g.SPR_ORDER = order
    t = preprocess(open("template.asm").read(), P["flags"])
    big = []
    for ch in "1942":
        big += g.big_glyph(ch)
    rep = {
        "@MAPH@": str(g.H),
        "@BLIT@": blit_code(),
        "@STR_PRESS@": strline("PRESS SPACE TO START"),
        "@STR_K1@": strline("Q UP     A DOWN"),
        "@STR_K2@": strline("M LEFT  , RIGHT"),
        "@STR_K3@": strline("SPACE FIRE N LOOP"),
        "@STR_JOY_OFF@": strline("J  JOYSTICK OFF  "),
        "@STR_JOY_ON@": strline("J  JOYSTICK ON   "),
        "@STR_GAMEOVER@": strline("GAME OVER"),
        "@ICON@": g.db_lines(g.icon_bytes()),
        "@BIGDIGITS@": g.db_lines(big),
        "@FONT_Y@": g.db_lines(g.font_bytes(g.YELLOW), 5),
        "@PANEL@": g.db_lines(g.panel_image(), 8),
        "@SPRITES@": g.sprite_asm(),
        "@MAP@": g.db_lines(g.map_block(), 24),
        "@VARS@": vars_block(P),
        "@PITCH@": g.db_lines(music.pitch_table()),
        "@MUSDATA@": music.music_asm(),
    }
    t = t.replace("@SAMPLE@", music.sample_code()).replace("@ORG@", str(P["org"]))
    for k, v in rep.items():
        t = t.replace(k, v)
    name = P["out"]
    open(name + ".asm", "w").write(t)
    r = subprocess.run(["pasmo", "--bin", name + ".asm", name + ".bin", name + ".sym"], capture_output=True, text=True)
    if r.returncode:
        print(r.stdout, r.stderr); sys.exit(1)
    body = open(name + ".bin", "rb").read()
    vzname = P["out"].replace("_", " ").encode().ljust(16, b" ")[:16] + b"\x00"
    hdr = b"VZF0" + vzname + b"\xF1" + struct.pack("<H", P["org"])
    open(name + ".VZ", "wb").write(hdr + body)
    syms = {}
    for line in open(name + ".sym"):
        p = line.split()
        if len(p) >= 3 and p[1] == "EQU": syms[p[0]] = int(p[2].rstrip("Hh"), 16)
    top = syms["STACKTOP"] - 1
    print("%s.VZ  %d bytes  ($%04X-$%04X code+data), vars/stack to $%04X, limit $%04X -> %s" % (
        name, len(hdr)+len(body), P["org"], P["org"]+len(body)-1, top, P["limit"],
        "FITS, %d bytes spare" % (P["limit"]-top) if top <= P["limit"] else "OVER by %d bytes" % (top-P["limit"])))
    return top <= P["limit"]

if __name__ == "__main__":
    build(sys.argv[1] if len(sys.argv) > 1 else "full")
