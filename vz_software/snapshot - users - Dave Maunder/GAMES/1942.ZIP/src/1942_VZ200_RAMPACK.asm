; =====================================================================
;  1942  -  vertical scrolling air-combat shooter for the VZ200 / VZ300
;  MODE(1) 128x64, 4 colour (CSS0: green / yellow / blue / red)
;
;  Build : python3 build_1942.py   (generates this file, assembles it with
;          pasmo and wraps the result as 1942.VZ)
;  Load  : binary file, loads and runs at $8000 (needs RAM $8000-$CBFF,
;          i.e. a 32KB cartridge such as the Ben Venn SD Loader)
;
;  KEYS     Q up   A down   M left   , right   SPACE fire   N loop
;  JOYSTICK port $2E / $2B directions + button 1 = fire, button 2 ($2D/$27) = loop
;           (enable with J on the title screen - keyboard always works)
;
;  HOW THE SCREEN IS DRAWN (no snow)
;   The 6847 corrupts the picture ("snow") whenever the Z80 touches video RAM
;   while the VDG is fetching display data.  So video RAM is ONLY written
;   right after the field-sync (FS, bit 7 of $6800) falling edge, i.e. from the
;   end of the active display through the bottom border, retrace and top
;   border.  Everything else is done in RAM:
;     * the whole land/sea picture lives in a RAM map (96x(192+64) pixels)
;     * sprites are drawn INTO that map (saving what was under them), so the
;       map window for the current scroll position is the finished back buffer
;     * at the vsync edge the back buffer is copied to $7000 by an unrolled
;       POP/PUSH blitter (about 13.5 T-states per byte) whose source addresses
;       are patched each frame by PATCH_BLIT
;   The map is stored "word reversed" (see gendata.map_block) so that POP
;   (ascending) / PUSH (descending) walk the picture in the right order.
; =====================================================================

VRAM        equ 7000h
LATCH       equ 6800h
MAPH        equ 160              ; scrolling map height in rows
MAPROWS     equ MAPH+64
TOPEND      equ MAPDATA+MAPROWS*24-2 ; address of image word 0 (row 0, col 0)
WRAPW0      equ TOPEND-24*(MAPH-1)
SCROLL_DIV  equ 2                   ; frames per one-row scroll step
EXP_TICKS   equ 5
BOSS_KILLS  equ 20                 ; enemy planes shot down before the boss arrives
TXTROW      equ 27                  ; GAME OVER text position inside the playfield
TXTCOL      equ 11
MAXE        equ 4
MAXPB       equ 3
MAXEB       equ 3
SLOT        equ 40                  ; bytes per sprite save slot
IDX_R       equ 28                  ; font index of the letter R

            org 31488

; ---------------------------------------------------------------------
START:      di
            ld sp,STACKTOP
            ld hl,VARS              ; RAM powers up (or is left after unpacking) full of
            ld de,VARS+1            ; garbage: clear every game variable first
            ld bc,VEND-VARS-1
            ld (hl),0
            ldir
            ld a,08h                ; MODE(1), CSS0, speaker idle
            ld (LATCH),a
            ld a,55h
            ld (rngseed),a
            xor a
            ld (joyon),a
            ld (nsaved),a           ; no sprites drawn yet
            ld hl,SAVEBUF
            ld (savep),hl
            ld hl,HISCORE
            ld b,6
st_hi:      ld (hl),a
            inc hl
            djnz st_hi
MAIN:       call SHOW_TITLE
            call NEW_GAME
            call GAME_LOOP
            call GAME_OVER
            jr MAIN

; ---------------------------------------------------------------------
; WAITVS - wait for the falling edge of FS (bit 7 of $6800)
; ---------------------------------------------------------------------
WAITVS:     ld a,(LATCH)
            rlca
            jr nc,WAITVS            ; still in the low (blank) phase: wait for high
wv2:        ld a,(LATCH)
            rlca
            jr c,wv2                ; wait for high -> low edge
            ret

; ---------------------------------------------------------------------
; RND - 8 bit pseudo random in A (clobbers B)
; ---------------------------------------------------------------------
RND:        ld a,(rngseed)
            ld b,a
            rrca
            rrca
            rrca
            xor 1Fh
            add a,b
            sbc a,255
            ld (rngseed),a
            ret

; ---------------------------------------------------------------------
; BEEP  B = cycles, C = pitch delay.  The speaker is driven differentially by
; latch bits 0 and 5 (01 = +1, 20 = -1, both or neither = 0), graphics bits kept.
; ---------------------------------------------------------------------
BEEP:       ld a,09h                ; speaker +1 (bit 0)
            ld (LATCH),a
            ld d,c
bp2:        dec d
            jr nz,bp2
            ld a,28h                ; speaker -1 (bit 5)
            ld (LATCH),a
            ld d,c
bp3:        dec d
            jr nz,bp3
            djnz BEEP
            ld a,08h                ; back to idle (graphics bits only)
            ld (LATCH),a
            ret
SFX_FIRE:   ld b,4
            ld c,5
            jp BEEP
SFX_EXPL:   ld b,14
            ld a,(tick)
            and 7
            add a,3
            ld c,a
            jp BEEP

; ---------------------------------------------------------------------
; READ_INPUT -> (inkeys): b0 up b1 down b2 left b3 right b4 fire b5 loop
; ---------------------------------------------------------------------
READ_INPUT: ld c,0
            ld a,(68FEh)            ; row A0: Q = $10
            and 10h
            jr nz,ri1
            set 0,c
ri1:        ld a,(68FDh)            ; row A1: A = $10
            and 10h
            jr nz,ri2
            set 1,c
ri2:        ld a,(68EFh)            ; row A4: M=$20 SPACE=$10 ,=$08 N=$01
            ld b,a
            and 20h
            jr nz,ri3
            set 2,c
ri3:        ld a,b
            and 08h
            jr nz,ri4
            set 3,c
ri4:        ld a,b
            and 10h
            jr nz,ri5
            set 4,c
ri5:        ld a,b
            and 01h
            jr nz,ri6
            set 5,c
ri6:        ld a,(joyon)
            or a
            jr z,ri9
            in a,(2Eh)              ; joystick 1 : b0 up b1 down b2 left b3 right b4 fire (active low)
            ld b,a
            in a,(2Bh)              ; joystick 2
            and b
            ld b,a
            bit 0,b
            jr nz,rj1
            set 0,c
rj1:        bit 1,b
            jr nz,rj2
            set 1,c
rj2:        bit 2,b
            jr nz,rj3
            set 2,c
rj3:        bit 3,b
            jr nz,rj4
            set 3,c
rj4:        bit 4,b
            jr nz,rj5
            set 4,c
rj5:        in a,(2Dh)              ; second button (arm) = loop
            ld b,a
            in a,(27h)
            and b
            bit 4,a
            jr nz,ri9
            set 5,c
ri9:        ld a,c
            ld (inkeys),a
            ret

; ---------------------------------------------------------------------
; Direct-to-VRAM helpers (call only right after WAITVS and keep them short)
; ---------------------------------------------------------------------
; PUT_RECT  HL=src, DE=vram dest, B=rows, C=width in bytes
PUT_RECT:   ld a,b
            ld (pr_h),a
            ld a,c
            ld (pr_w),a
pr_row:     push de
            ld a,(pr_w)
            ld c,a
            ld b,0
            ldir
            pop de
            push hl
            ld hl,32
            add hl,de
            ex de,hl
            pop hl
            ld a,(pr_h)
            dec a
            ld (pr_h),a
            jr nz,pr_row
            ret
; PUTCHAR  A=glyph index, DE=vram dest, IX=font table
PUTCHAR:    ld l,a
            add a,a
            add a,a
            add a,l
            ld c,a
            ld b,0
            push ix
            pop hl
            add hl,bc
            ld b,5
            ld c,1
            jp PUT_RECT
; PRINT_STR  HL = indices terminated by $FF, DE = vram dest, IX = font
PRINT_STR:  ld a,(hl)
            cp 0FFh
            ret z
            push hl
            push de
            call PUTCHAR
            pop de
            pop hl
            inc hl
            inc de
            jr PRINT_STR
; PRINT_IDX  HL = indices, B = count, DE = vram dest, IX = font
PRINT_IDX:  ld a,(hl)
            push bc
            push hl
            push de
            call PUTCHAR
            pop de
            pop hl
            pop bc
            inc hl
            inc de
            djnz PRINT_IDX
            ret
; PANEL_ROWS HL=src DE=dst B=rows (8 bytes per row)
PANEL_ROWS: push bc
            ld bc,8
            ldir
            ld a,e
            add a,24
            ld e,a
            jr nc,pnr2
            inc d
pnr2:       pop bc
            djnz PANEL_ROWS
            ret
; PRINT_LINE  HL=text, DE=vram, IX=font : waits for vsync first
PRINT_LINE: push hl
            push de
            call WAITVS
            pop de
            pop hl
            jp PRINT_STR

; ---------------------------------------------------------------------
; Title screen
; ---------------------------------------------------------------------
SHOW_TITLE: ld hl,VRAM
            ld b,4
tt_fill:    push bc
            push hl
            call WAITVS
            pop hl
            ld d,h
            ld e,l
            inc de
            ld (hl),0AAh
            ld bc,511
            ldir
            ex de,hl                ; HL = start of next 512 byte block
            pop bc
            djnz tt_fill
            call WAITVS             ; big "1942" logo
            ld hl,BIGDIGITS
            ld de,VRAM+6*32+12
            ld c,4
tt_logo:    push bc
            push hl
            push de
            ld b,10
            ld c,2
            call PUT_RECT
            pop de
            pop hl
            ld bc,20
            add hl,bc
            inc de
            inc de
            pop bc
            dec c
            jr nz,tt_logo
            ld ix,FONT_Y
            ld hl,STR_PRESS
            ld de,VRAM+22*32+6
            call PRINT_LINE
            ld ix,FONT_Y
            ld hl,STR_K1
            ld de,VRAM+46*32+7
            call PRINT_LINE
            ld hl,STR_K2
            ld de,VRAM+52*32+7
            call PRINT_LINE
            ld hl,STR_K3
            ld de,VRAM+58*32+7
            call PRINT_LINE
            call DRAW_OPTS
            xor a
            ld (kheld),a
            call MUS_INIT
tl_loop:
            call MUS_TICK           ; ~16 ms of music, then poll the keys
            ld hl,rngseed
            inc (hl)
            ld c,0
            ld a,(687Fh)            ; J
            and 20h
            jr nz,tl_a
            set 0,c
tl_a:       ld a,(68EFh)            ; SPACE
            and 10h
            jr nz,tl_c
            set 2,c
tl_c:       ld a,(joyon)
            or a
            jr z,tl_d
            in a,(2Eh)
            bit 4,a
            jr nz,tl_d
            set 2,c
tl_d:       ld a,c
            or a
            jr z,tl_rel
            ld a,(kheld)
            or a
            jr nz,tl_loop
            ld a,1
            ld (kheld),a
            bit 2,c
            ret nz                  ; start the game
            bit 0,c
            jr z,tl_loop
            ld a,(joyon)
            xor 1
            ld (joyon),a
            call DRAW_OPTS
            jr tl_loop
tl_rel:     xor a
            ld (kheld),a
            jr tl_loop

DRAW_OPTS:  ld ix,FONT_Y
            ld hl,STR_JOY_OFF
            ld a,(joyon)
            or a
            jr z,do1
            ld hl,STR_JOY_ON
do1:        ld de,VRAM+34*32+6
            jp PRINT_LINE

; ---------------------------------------------------------------------
; New game
; ---------------------------------------------------------------------
NEW_GAME:   call TXT_RESTORE        ; put back the map under the last game's text/sprites
            call RESTORE_SPRITES
            xor a
            ld (kills),a
            ld (bossact),a
            ld (bossnum),a
            ld (gocnt),a
            ld (plstate),a
            ld (gover),a
            ld (loopt),a
            ld (firecd),a
            ld (wavecnt),a
            ld (tick),a
            ld (srow),a
            ld a,3
            ld (lives),a
            ld (loops),a
            ld a,1
            ld (stage),a
            xor a
            ld (STAGEBUF),a
            inc a
            ld (STAGEBUF+1),a
            ld a,44
            ld (px),a
            ld a,50
            ld (py),a
            ld a,100
            ld (invuln),a
            ld a,60
            ld (spawncd),a
            ld a,SCROLL_DIV
            ld (scrollc),a
            ld hl,TOPEND
            ld (W0),hl
            ld hl,SAVEBUF
            ld (savep),hl
            ld hl,SCORE
            ld b,6
ng1:        ld (hl),0
            inc hl
            djnz ng1
            ld hl,ENEMS
            ld de,ENEMS+1
            ld bc,32+9+12-1
            ld (hl),0
            ldir
            call WAITVS             ; HUD panel (static labels + divider) in two vblanks
            ld hl,PANELIMG
            ld de,VRAM+24
            ld b,32
            call PANEL_ROWS
            call WAITVS
            ld b,32
            call PANEL_ROWS         ; HL/DE continue where they stopped
            ld a,1Fh
            ld (dirty),a
            ret

; ---------------------------------------------------------------------
; Main game loop
; ---------------------------------------------------------------------
GAME_LOOP:  call RESTORE_SPRITES
            call READ_INPUT
            call UPDATE_ALL
            call DRAW_ALL
            call PATCH_BLIT
            call WAITVS
            call PRESENT
            ld a,(gover)
            or a
            jr z,GAME_LOOP
            ret

PRESENT:    call BLIT_P1
            call BLIT_P2
            jp PANEL_UPDATE

PANEL_UPDATE:
            ld a,(dirty)
            or a
            ret z
            ld hl,dirty
            bit 0,a
            jr z,pu1
            res 0,(hl)
            ld hl,SCORE
            ld b,6
            ld de,VRAM+7*32+25
            ld ix,FONT_Y
            jp PRINT_IDX
pu1:        bit 1,a
            jr z,pu2
            res 1,(hl)
            ld hl,HISCORE
            ld b,6
            ld de,VRAM+20*32+25
            ld ix,FONT_Y
            jp PRINT_IDX
pu2:        bit 2,a
            jr z,pu3
            res 2,(hl)
            ld hl,STAGEBUF
            ld b,2
            ld de,VRAM+33*32+25
            ld ix,FONT_Y
            jp PRINT_IDX
pu3:        bit 3,a
            jr z,pu4
            res 3,(hl)
            jp DRAW_LIVES
pu4:        res 4,(hl)
            jp DRAW_LOOPS

DRAW_LIVES: ld c,0
dlv1:       ld a,c
            ld hl,lives
            cp (hl)
            ld hl,ICON
            jr c,dlv2
            ld hl,ICONBLANK
dlv2:       push hl
            ld hl,VRAM+41*32+25
            ld a,c
            add a,a
            ld e,a
            ld d,0
            add hl,de
            ex de,hl
            pop hl
            push bc
            ld b,5
            ld c,2
            call PUT_RECT
            pop bc
            inc c
            ld a,c
            cp 3
            jr c,dlv1
            ret

DRAW_LOOPS: ld hl,LOOPSTR
            ld c,0
dlp1:       ld a,c
            push hl
            ld hl,loops
            cp (hl)
            pop hl
            ld a,10
            jr nc,dlp2
            ld a,IDX_R
dlp2:       ld (hl),a
            inc hl
            inc c
            ld a,c
            cp 3
            jr c,dlp1
            ld hl,LOOPSTR
            ld b,3
            ld de,VRAM+57*32+25
            ld ix,FONT_Y
            jp PRINT_IDX

; ---------------------------------------------------------------------
; Game over
; ---------------------------------------------------------------------
GAME_OVER:  call UPDATE_HI
            ld a,2
            ld (dirty),a
            ld (plstate),a          ; 2 = player gone
            xor a
            ld (bossact),a
            ld (gocnt),a
            ld (kheld),a
go_frame:   call TXT_RESTORE        ; undo in reverse order: the text was drawn last
            call RESTORE_SPRITES    ; the world keeps scrolling behind the text
            ld hl,tick
            inc (hl)
            call UPD_SCROLL
            call UPD_ENEMIES
            call UPD_EBULLETS
            call SPAWN_LOGIC
            call DRAW_ALL
            call DRAW_TXT
            call PATCH_BLIT
            call WAITVS
            call PRESENT
            ld a,(gocnt)
            cp 120
            jr nc,go_chk
            inc a
            ld (gocnt),a
            jr go_frame
go_chk:     ld a,(68EFh)            ; SPACE: must be released, then pressed
            and 10h
            jr z,go_pressed
            ld a,1
            ld (kheld),a
            jr go_frame
go_pressed: ld a,(kheld)
            or a
            jr z,go_frame
go4:        ld a,(68EFh)            ; wait for release before the title screen
            and 10h
            jr z,go4
            ret

; TXT_RESTORE - undo DRAW_TXT (LIFO)
TXT_RESTORE:
            ld a,(txtn)
            or a
            ret z
            ld b,a
            ld hl,(txtp)
txr1:       dec hl
            ld a,(hl)               ; original byte
            dec hl
            ld d,(hl)
            dec hl
            ld e,(hl)
            ld (de),a
            djnz txr1
            xor a
            ld (txtn),a
            ld hl,TXTSAVE
            ld (txtp),hl
            ret

; DRAW_TXT - OR the red "GAME OVER" glyph pixels into the map window
; (so the scrolling background stays visible around the letters)
DRAW_TXT:   ld hl,TXTSAVE
            ld (txtp),hl
            xor a
            ld (txtn),a
            ld a,TXTROW
            ld (t1),a               ; current row y
            xor a
            ld (t2),a               ; glyph row 0..4
dtx_row:    ld a,(t1)
            call MUL24
            ex de,hl
            ld hl,(W0)
            or a
            sbc hl,de               ; W0 - 24*y
            ld de,-9
            add hl,de               ; address of the first character byte
            ex de,hl
            ld a,1
            ld (t3),a               ; parity of the byte column
            ld hl,STR_GAMEOVER
dtx_ch:     ld a,(hl)
            cp 0FFh
            jr z,dtx_next
            push hl
            ld l,a
            add a,a
            add a,a
            add a,l                 ; 5 * glyph index
            ld hl,t2
            add a,(hl)
            ld l,a
            ld h,0
            push de
            ld de,FONT_Y
            add hl,de
            pop de
            ld a,(hl)               ; glyph row byte (yellow on blue)
            and 55h                 ; keep the set pixels
            ld b,a
            add a,a
            or b
            ld b,a                  ; B = both bits of each set pixel (red)
            ld hl,(txtp)
            ld a,(de)
            ld (hl),e
            inc hl
            ld (hl),d
            inc hl
            ld (hl),a               ; save the original byte
            inc hl
            ld (txtp),hl
            or b                    ; OR the text pixels in place
            ld (de),a
            ld hl,txtn
            inc (hl)
            pop hl
            inc hl
            ld a,(t3)
            or a
            jr nz,dtx_odd
            inc de
            ld a,1
            ld (t3),a
            jr dtx_ch
dtx_odd:    dec de
            dec de
            dec de
            xor a
            ld (t3),a
            jr dtx_ch
dtx_next:   ld hl,t1
            inc (hl)
            ld hl,t2
            inc (hl)
            ld a,(hl)
            cp 5
            jr c,dtx_row
            ret

UPDATE_HI:  ld hl,SCORE
            ld de,HISCORE
            ld b,6
uh1:        ld a,(de)
            cp (hl)
            jr c,uh_new
            jr nz,uh_done
            inc hl
            inc de
            djnz uh1
uh_done:    ret
uh_new:     ld hl,SCORE
            ld de,HISCORE
            ld bc,6
            ldir
            ret

; ---------------------------------------------------------------------
; Update
; ---------------------------------------------------------------------
UPDATE_ALL: ld hl,tick
            inc (hl)
            call UPD_SCROLL
            call UPD_PLAYER
            call UPD_PBULLETS
            call UPD_ENEMIES
            call UPD_BOSS
            call UPD_EBULLETS
            call SPAWN_LOGIC
            jp COLLISIONS

UPD_SCROLL: ld hl,scrollc
            dec (hl)
            ret nz
            ld (hl),SCROLL_DIV
            ld a,(srow)
            or a
            jr z,us_wrap
            dec a
            ld (srow),a
            ld hl,(W0)
            ld de,24
            add hl,de
            ld (W0),hl
            ret
us_wrap:    ld a,MAPH-1
            ld (srow),a
            ld hl,WRAPW0
            ld (W0),hl
            ret

UPD_PLAYER: ld a,(firecd)
            or a
            jr z,up0
            dec a
            ld (firecd),a
up0:        ld a,(invuln)
            or a
            jr z,up1
            dec a
            ld (invuln),a
up1:        ld a,(loopt)
            or a
            jr z,up2
            dec a
            ld (loopt),a
up2:        ld a,(plstate)
            or a
            jr z,up_alive
            ld hl,plexp
            dec (hl)
            ret nz
            ld a,(lives)
            or a
            jr nz,up_resp
            ld a,1
            ld (gover),a
            ret
up_resp:    xor a
            ld (plstate),a
            ld a,44
            ld (px),a
            ld a,50
            ld (py),a
            ld a,120
            ld (invuln),a
            ret
up_alive:   ld a,(inkeys)
            ld b,a
            bit 2,b
            jr z,upr
            ld a,(px)
            or a
            jr z,upr
            dec a
            ld (px),a
upr:        bit 3,b
            jr z,upu
            ld a,(px)
            cp 87
            jr nc,upu
            inc a
            ld (px),a
upu:        bit 0,b
            jr z,upd
            ld a,(py)
            or a
            jr z,upd
            dec a
            ld (py),a
upd:        bit 1,b
            jr z,upf
            ld a,(py)
            cp 56
            jr nc,upf
            inc a
            ld (py),a
upf:        bit 4,b
            jr z,upl
            ld a,(firecd)
            or a
            jr nz,upl
            call FIRE_PB
upl:        bit 5,b
            ret z
            ld a,(loopt)
            or a
            ret nz
            ld a,(loops)
            or a
            ret z
            dec a
            ld (loops),a
            ld a,48
            ld (loopt),a
            ld hl,dirty
            set 4,(hl)
            ret

FIRE_PB:    push bc
            ld hl,PBULS
            ld b,MAXPB
fp1:        ld a,(hl)
            or a
            jr z,fp2
            inc hl
            inc hl
            inc hl
            djnz fp1
            pop bc
            ret
fp2:        ld (hl),1
            inc hl
            ld a,(px)
            ld (hl),a
            inc hl
            ld a,(py)
            sub 2
            ld (hl),a
            ld a,8
            ld (firecd),a
            call SFX_FIRE
            pop bc
            ret

UPD_PBULLETS:
            ld ix,PBULS
            ld b,MAXPB
upb:        ld a,(ix+0)
            or a
            jr z,upbn
            ld a,(ix+2)
            sub 2
            ld (ix+2),a
            bit 7,a
            jr z,upbn
            cp 0FFh
            jr z,upbn
            ld (ix+0),0
upbn:       ld de,3
            add ix,de
            djnz upb
            ret

UPD_ENEMIES:
            ld ix,ENEMS
            ld b,MAXE
ue_loop:    ld a,(ix+0)
            or a
            jp z,ue_next
            cp 1
            jp z,ue_alive
            dec (ix+4)              ; exploding
            jp nz,ue_next
            inc (ix+0)
            ld a,(ix+0)
            cp 5
            jr nc,ue_free
            ld (ix+4),EXP_TICKS
            jp ue_next
ue_free:    ld (ix+0),0
            jp ue_next
ue_alive:   ld a,(tick)
            and 3
            cp 3
            jr z,ue_noy
            inc (ix+2)
ue_noy:     ld (ix+6),0
            ld a,(ix+3)
            or a
            jr z,ue_xdone
            cp 1
            jr nz,ue_t2
            ld a,(ix+2)
            bit 7,a
            jr nz,ue_xdone          ; not on screen yet
            inc (ix+4)              ; type 1: sway
            ld a,(ix+4)
            rrca
            rrca
            and 0Fh
            ld e,a
            ld d,0
            ld hl,SWAYTAB
            add hl,de
            ld a,(hl)
            ld (ix+6),a
            jr ue_dx
ue_t2:      ld a,(ix+2)             ; type 2: dive at the player
            bit 7,a
            jr nz,ue_xdone
            cp 8
            jr c,ue_xdone
            ld a,(tick)
            and 1
            jr nz,ue_xdone
            inc (ix+2)
            ld a,(px)
            cp (ix+1)
            jr z,ue_xdone
            ld a,1
            jr nc,ue_t2s
            ld a,0FFh
ue_t2s:     ld (ix+6),a
ue_dx:      ld a,(ix+1)
            add a,(ix+6)
            bit 7,a
            jr z,ue_c1
            xor a
ue_c1:      cp 88
            jr c,ue_c2
            ld a,87
ue_c2:      ld (ix+1),a
ue_xdone:   ld a,(ix+2)
            bit 7,a
            jr nz,ue_shoot
            cp 64
            jr c,ue_shoot
            ld (ix+0),0
            jr ue_next
ue_shoot:   dec (ix+5)
            jr nz,ue_next
            call ENEMY_FIRE
ue_next:    ld de,8
            add ix,de
            dec b
            jp nz,ue_loop
            ret

ENEMY_FIRE: push bc
            call RND
            and 7Fh
            add a,70
            ld (ix+5),a
            ld a,(ix+2)
            bit 7,a
            jr nz,ef_ret
            cp 40
            jr nc,ef_ret
            ld hl,EBULS
            ld b,MAXEB
ef1:        ld a,(hl)
            or a
            jr z,ef_found
            inc hl
            inc hl
            inc hl
            inc hl
            djnz ef1
ef_ret:     pop bc
            ret
ef_found:   ld (hl),1
            inc hl
            ld a,(ix+1)
            ld (hl),a
            inc hl
            ld a,(ix+2)
            add a,6
            ld (hl),a
            inc hl
            ld a,(ix+3)
            or a
            jr z,ef_dx0
            ld a,(px)
            cp (ix+1)
            jr z,ef_dx0
            ld a,1
            jr nc,ef_sdx
            ld a,0FFh
ef_sdx:     ld (hl),a
            jr ef_ret
ef_dx0:     ld (hl),0
            jr ef_ret

UPD_EBULLETS:
            ld ix,EBULS
            ld b,MAXEB
ueb:        ld a,(ix+0)
            or a
            jr z,uebn
            ld a,(tick)
            and 3
            jr z,ueb_x
            inc (ix+2)
ueb_x:      ld a,(tick)
            and 1
            jr nz,ueb_y
            ld a,(ix+1)
            add a,(ix+3)
            cp 88
            jr nc,ueb_kill
            ld (ix+1),a
ueb_y:      ld a,(ix+2)
            bit 7,a
            jr nz,uebn
            cp 64
            jr c,uebn
ueb_kill:   ld (ix+0),0
uebn:       ld de,4
            add ix,de
            djnz ueb
            ret

SPAWN_LOGIC:
            ld a,(bossact)
            or a
            ret nz                  ; no ordinary waves during the boss fight
            ld a,(kills)
            cp BOSS_KILLS
            jr c,sl_norm
            ld ix,ENEMS             ; boss is due: wait for clear skies
            ld b,MAXE
sl_chk:     ld a,(ix+0)
            or a
            ret nz
            ld de,8
            add ix,de
            djnz sl_chk
            jp BOSS_START
sl_norm:    ld hl,spawncd
            dec (hl)
            ret nz
            ld ix,ENEMS
            ld b,MAXE
            ld c,0
sl1:        ld a,(ix+0)
            or a
            jr nz,sl2
            inc c
sl2:        ld de,8
            add ix,de
            djnz sl1
            ld a,c
            or a
            jr nz,sl3
            ld a,20
            ld (spawncd),a
            ret
sl3:        ld (t5),a               ; free slots
            cp 3
            jr c,sl4
            ld a,3
sl4:        ld (t1),a               ; formation size
            call RND
            and 3Fh
            cp 56
            jr c,sl5
            sub 56
sl5:        add a,8
            ld (t2),a               ; x of first plane
            call RND
            and 3
            cp 3
            jr nz,sl6
            ld a,1
sl6:        ld c,a
            ld a,(stage)
            cp 2
            jr nc,sl7
            ld a,c
            cp 2
            jr nz,sl7
            ld c,1
sl7:        ld a,c
            ld (t3),a               ; type
            xor a
            ld (t4),a               ; formation 0: three abreast
            call RND
            and 3
            jr nz,sl_fill
            ld a,1                  ; 1 time in 4: a FILE of bombers, one after another,
            ld (t4),a               ; lined up on the player's position
            ld a,(px)
            ld (t2),a
            ld a,(stage)
            cp 2
            ld a,0
            jr c,sl_ft
            call RND
            and 2                   ; straight or diving
sl_ft:      ld (t3),a
            ld a,(t5)
            cp 5
            jr c,sl_fn
            ld a,4
sl_fn:      ld (t1),a
sl_fill:    ld ix,ENEMS
            ld b,MAXE
            ld c,0                  ; formation index
sl8:        ld a,(ix+0)
            or a
            jr nz,sl9
            ld a,(t1)
            cp c
            jr z,sl_done
            ld (ix+0),1
            ld a,(t4)
            or a
            jr nz,sl_file
            ld a,c
            add a,a
            add a,a
            ld e,a
            add a,a
            add a,e                 ; 12*c
            ld e,a
            ld a,(t2)
            add a,e
            ld (ix+1),a
            ld (ix+2),0F8h          ; y = -8
            jr sl_com
sl_file:    ld a,(t2)
            ld (ix+1),a
            ld a,c
            add a,a
            ld e,a
            add a,a
            add a,a
            add a,a
            sub e                   ; 14*c rows apart
            ld e,a
            ld a,0F8h
            sub e
            ld (ix+2),a
sl_com:     ld a,(t3)
            ld (ix+3),a
            ld (ix+4),0
            ld a,c
            add a,a
            add a,a
            add a,a
            add a,60
            ld (ix+5),a
            ld (ix+6),0
            inc c
sl9:        ld de,8
            add ix,de
            djnz sl8
sl_done:
            call RND
            and 3Fh
            ld (t1),a
            ld a,(stage)
            ld b,a
            add a,a
            add a,b
            add a,a                 ; stage*6
            cp 50
            jr c,sl_c2
            ld a,50
sl_c2:      ld b,a
            ld a,130
            sub b
            ld hl,t1
            add a,(hl)
            ld (spawncd),a
            ret

; ---------------------------------------------------------------------
; Boss
; ---------------------------------------------------------------------
BOSS_START: ld a,1
            ld (bossact),a
            ld a,34
            ld (bossx),a
            ld a,0F0h
            ld (bossy),a
            ld a,1
            ld (bossdir),a
            ld a,90
            ld (bossfire),a
            ld a,(bossnum)
            cp 10
            jr c,bs1
            ld a,10
bs1:        ld b,a
            add a,a
            add a,a
            add a,b                 ; 5 * boss number
            add a,20
            ld (bosshp),a
            ld b,12
            ld c,40
            jp BEEP                 ; low warning rumble

UPD_BOSS:   ld a,(bossact)
            or a
            ret z
            cp 2
            jr z,ubd
            ld a,(bossy)
            cp 4
            jr z,ub_mv
            ld a,(tick)             ; fly in slowly
            and 1
            ret nz
            ld hl,bossy
            inc (hl)
            ret
ub_mv:      ld a,(tick)
            and 1
            jr nz,ub_fire
            ld a,(bossx)
            ld hl,bossdir
            add a,(hl)
            ld (bossx),a
            cp 69
            jr c,ub_l
            ld a,0FFh
            ld (bossdir),a
            jr ub_fire
ub_l:       or a
            jr nz,ub_fire
            ld a,1
            ld (bossdir),a
ub_fire:    ld hl,bossfire
            dec (hl)
            ret nz
            ld a,(stage)
            ld b,a
            add a,a
            add a,b
            cp 31
            jr c,ub_f2
            ld a,30
ub_f2:      ld b,a
            ld a,70
            sub b
            ld (bossfire),a
            jp BOSS_FIRE
ubd:        ld hl,bossexp           ; exploding
            dec (hl)
            jr z,ub_done
            ld a,(hl)
            and 15
            ret nz
            jp SFX_EXPL
ub_done:    ld b,5                  ; +5000
ub_sc:      push bc
            ld a,10
            call ADD_SCORE
            pop bc
            djnz ub_sc
            xor a
            ld (kills),a
            ld (bossact),a
            ld hl,bossnum
            inc (hl)
            ld a,90
            ld (spawncd),a
            jp NEXT_STAGE

; BOSS_FIRE - a volley of three bullets (left, straight, right)
BOSS_FIRE:  ld c,0FFh
bf_loop:    ld hl,EBULS
            ld b,MAXEB
bf1:        ld a,(hl)
            or a
            jr z,bf_found
            inc hl
            inc hl
            inc hl
            inc hl
            djnz bf1
            ret
bf_found:   ld (hl),1
            inc hl
            ld a,(bossx)
            add a,9
            ld (hl),a
            inc hl
            ld a,(bossy)
            add a,14
            ld (hl),a
            inc hl
            ld (hl),c
            inc c
            ld a,c
            cp 2
            jr nz,bf_loop
            ret

NEXT_STAGE: ld a,(stage)
            cp 99
            jr z,ns1
            inc a
            ld (stage),a
ns1:        ld b,0
ns2:        sub 10
            jr c,ns3
            inc b
            jr ns2
ns3:        add a,10
            ld c,a
            ld a,b
            ld (STAGEBUF),a
            ld a,c
            ld (STAGEBUF+1),a
            ld a,(loops)
            cp 3
            jr nc,ns4
            inc a
            ld (loops),a
ns4:        ld hl,dirty
            set 2,(hl)
            set 4,(hl)
            ret

ADD_SCORE:  ld b,4
            ld hl,SCORE+3
asc1:       add a,(hl)
            cp 10
            jr c,asc2
            sub 10
            ld (hl),a
            ld a,1
            dec hl
            djnz asc1
            ret
asc2:       ld (hl),a
            ld hl,dirty
            set 0,(hl)
            ret

COLLISIONS: ld iy,PBULS             ; player bullets vs enemies
            ld c,MAXPB
cb1:        ld a,(iy+0)
            or a
            jp z,cb_next
            ld ix,ENEMS
            ld b,MAXE
cb2:        ld a,(ix+0)
            cp 1
            jr nz,cb2n
            ld a,(iy+1)
            sub (ix+1)
            jr nc,cb3
            neg
cb3:        cp 7
            jr nc,cb2n
            ld a,(iy+2)
            sub (ix+2)
            add a,1
            cp 8
            jr nc,cb2n
            ld (iy+0),0
            ld (ix+0),2
            ld (ix+4),EXP_TICKS
            push bc
            ld a,1
            call ADD_SCORE
            ld hl,kills
            inc (hl)
            call SFX_EXPL
            pop bc
            jp cb_next
cb2n:       ld de,8
            add ix,de
            djnz cb2
            ld a,(bossact)          ; this bullet against the boss
            cp 1
            jp nz,cb_next
            ld a,(bossy)
            bit 7,a
            jp nz,cb_next
            ld a,(iy+1)
            ld hl,bossx
            sub (hl)
            add a,8
            cp 35
            jp nc,cb_next
            ld a,(iy+2)
            ld hl,bossy
            sub (hl)
            add a,1
            cp 17
            jp nc,cb_next
            ld (iy+0),0
            ld hl,bosshp
            dec (hl)
            jr nz,cb_bhit
            ld a,2                  ; boss destroyed
            ld (bossact),a
            ld a,60
            ld (bossexp),a
cb_bhit:    push bc
            ld b,2
            ld c,3
            call BEEP
            pop bc
cb_next:    ld de,3
            add iy,de
            dec c
            jp nz,cb1
            ld a,(plstate)          ; player vs enemies / enemy bullets
            or a
            ret nz
            ld a,(invuln)
            ld b,a
            ld a,(loopt)
            or b
            ret nz
            ld ix,ENEMS
            ld b,MAXE
cp1:        ld a,(ix+0)
            cp 1
            jr nz,cp1n
            ld a,(px)
            sub (ix+1)
            jr nc,cp2
            neg
cp2:        cp 8
            jr nc,cp1n
            ld a,(py)
            sub (ix+2)
            jr nc,cp3
            neg
cp3:        cp 7
            jr nc,cp1n
            ld (ix+0),2
            ld (ix+4),EXP_TICKS
            jp PLAYER_HIT
cp1n:       ld de,8
            add ix,de
            djnz cp1
            ld a,(bossact)          ; player against the boss
            cp 1
            jr nz,cp_nb
            ld a,(px)
            ld hl,bossx
            sub (hl)
            add a,8
            cp 35
            jr nc,cp_nb
            ld a,(py)
            ld hl,bossy
            sub (hl)
            add a,7
            cp 23
            jr nc,cp_nb
            jp PLAYER_HIT
cp_nb:
            ld ix,EBULS
            ld b,MAXEB
cq1:        ld a,(ix+0)
            or a
            jr z,cq1n
            ld a,(ix+1)
            ld hl,px
            sub (hl)
            add a,3
            cp 7
            jr nc,cq1n
            ld a,(ix+2)
            ld hl,py
            sub (hl)
            add a,1
            cp 9
            jr nc,cq1n
            ld (ix+0),0
            jp PLAYER_HIT
cq1n:       ld de,4
            add ix,de
            djnz cq1
            ret

PLAYER_HIT: ld a,1
            ld (plstate),a
            ld a,60
            ld (plexp),a
            ld hl,lives
            dec (hl)
            ld hl,dirty
            set 3,(hl)
            jp SFX_EXPL

; ---------------------------------------------------------------------
; Sprite engine
; ---------------------------------------------------------------------
DRAW_ALL:
            call DRAW_BOSS
            ld ix,ENEMS
            ld b,MAXE
da1:        ld a,(ix+0)
            or a
            jr z,da1n
            cp 1
            jr nz,da_exp
            ld a,(ix+6)
            or a
            ld hl,SPR_EN0
            jr z,da_dr
            bit 7,a
            ld hl,SPR_ENR
            jr z,da_dr
            ld hl,SPR_ENL
            jr da_dr
da_exp:     sub 2
            add a,a
            ld e,a
            ld d,0
            ld hl,EXPTAB
            add hl,de
            ld e,(hl)
            inc hl
            ld d,(hl)
            ex de,hl
da_dr:      push bc
            ld b,(ix+1)
            ld c,(ix+2)
            call DRAW_SPRITE
            pop bc
da1n:       ld de,8
            add ix,de
            djnz da1
            ld ix,PBULS
            ld b,MAXPB
da2:        ld a,(ix+0)
            or a
            jr z,da2n
            push bc
            ld hl,SPR_PB
            ld b,(ix+1)
            ld c,(ix+2)
            call DRAW_SPRITE
            pop bc
da2n:       ld de,3
            add ix,de
            djnz da2
            ld ix,EBULS
            ld b,MAXEB
da3:        ld a,(ix+0)
            or a
            jr z,da3n
            push bc
            ld hl,SPR_EB
            ld b,(ix+1)
            ld c,(ix+2)
            call DRAW_SPRITE
            pop bc
da3n:       ld de,4
            add ix,de
            djnz da3
            ld a,(plstate)          ; player last (on top)
            cp 2
            ret z                   ; game over: no player
            or a
            jr nz,da_pexp
            ld a,(invuln)
            or a
            jr z,da_pshow
            ld a,(tick)
            and 2
            ret z                   ; blink while invulnerable
da_pshow:   ld a,(loopt)
            or a
            jr nz,da_lp
            ld a,(inkeys)           ; banking: the wing on the side we turn towards drops away
            and 0Ch
            ld e,0
            cp 04h
            jr nz,da_b2
            ld e,3                  ; diving left: left wing removed
            jr da_pf
da_b2:      cp 08h
            jr nz,da_pf
            ld e,4                  ; diving right: right wing removed
            jr da_pf
da_lp:      rrca
            rrca
            rrca
            and 1Fh
            ld e,a
            ld d,0
            ld hl,LOOPFR
            add hl,de
            ld e,(hl)
da_pf:      ld a,e
            add a,a
            ld e,a
            ld d,0
            ld hl,PLTAB
            add hl,de
            ld e,(hl)
            inc hl
            ld d,(hl)
            ex de,hl
da_pdr:     ld a,(px)
            ld b,a
            ld a,(py)
            ld c,a
            jp DRAW_SPRITE
da_pexp:    ld a,(plexp)
            ld hl,SPR_EX0
            cp 40
            jr nc,da_pdr
            ld hl,SPR_EX1
            cp 20
            jr nc,da_pdr
            ld hl,SPR_EX2
            jr da_pdr

DRAW_BOSS:  ld a,(bossact)
            or a
            ret z
            cp 2
            jr z,db_exp
            ld hl,BOSSTAB
            ld b,6
db1:        push bc
            push hl
            ld a,(bossx)
            add a,(hl)
            ld d,a
            inc hl
            ld a,(bossy)
            add a,(hl)
            ld e,a
            inc hl
            ld c,(hl)
            inc hl
            ld h,(hl)
            ld l,c
            ld b,d
            ld c,e
            call DRAW_SPRITE
            pop hl
            ld de,4
            add hl,de
            pop bc
            djnz db1
            ret
db_exp:     xor a                   ; three overlapping explosions over the wreck
            ld (t1),a
dbe1:       ld a,(bossexp)
            rrca
            rrca
            rrca
            and 3
            ld hl,t1
            add a,(hl)
dbe2:       cp 3
            jr c,dbe3
            sub 3
            jr dbe2
dbe3:       add a,a
            ld e,a
            ld d,0
            ld hl,EXPTAB
            add hl,de
            ld e,(hl)
            inc hl
            ld d,(hl)
            push de                 ; sprite descriptor
            ld a,(t1)
            add a,a
            ld e,a
            ld d,0
            ld hl,BEXPOFF
            add hl,de
            ld a,(bossx)
            add a,(hl)
            ld b,a
            inc hl
            ld a,(bossy)
            add a,(hl)
            ld c,a
            pop hl
            call DRAW_SPRITE
            ld hl,t1
            inc (hl)
            ld a,(hl)
            cp 3
            jr c,dbe1
            ret

; MUL24  A = y (0..63)  ->  HL = 24*y   (clobbers DE)
MUL24:      ld l,a
            ld h,0
            add hl,hl
            add hl,hl
            add hl,hl               ; 8y
            ld d,h
            ld e,l
            add hl,hl               ; 16y
            add hl,de               ; 24y
            ret

; DRAW_SPRITE  HL = descriptor, B = x pixel (0..87), C = y row (signed)
DRAW_SPRITE:
            ld a,b
            ld (ds_x),a
            ld a,(hl)
            ld (ds_h),a
            inc hl
            ld (ds_tab),hl
            ld a,c
            ld d,0
            bit 7,a
            jr z,dsy1
            neg
            ld d,a                  ; rows hidden above the screen
            ld a,(ds_h)
            sub d
            ret z
            ret c
            ld e,a
            ld c,0
            jr dsy2
dsy1:       ld a,(ds_h)
            ld e,a
dsy2:       ld a,c
            cp 64
            ret nc
            add a,e
            cp 65
            jr c,dsy3
            ld a,64
            sub c
            ld e,a
dsy3:       ld a,d
            ld (ds_skip),a
            ld a,e
            ld (ds_rows),a
            ld a,c                  ; dest = W0 - 24*y - 2*(x>>3)
            call MUL24
            ex de,hl
            ld hl,(W0)
            or a
            sbc hl,de
            ld a,(ds_x)
            rrca
            rrca
            rrca
            and 1Fh
            add a,a
            ld e,a
            ld d,0
            or a
            sbc hl,de
            ex de,hl                ; DE = destination of first visible row
            ld a,(ds_x)             ; data pointer for this pixel shift
            and 7
            add a,a
            ld l,a
            ld h,0
            ld bc,(ds_tab)
            add hl,bc
            ld c,(hl)
            inc hl
            ld b,(hl)
            ld h,b
            ld l,c
            ld a,(ds_skip)
            or a
            jr z,dsd1
            ld b,a
dssk:       ld a,l
            add a,8
            ld l,a
            jr nc,dssk2
            inc h
dssk2:      djnz dssk
dsd1:       push hl
            ld hl,(savep)
            ld (hl),e
            inc hl
            ld (hl),d
            inc hl
            ld a,(ds_rows)
            ld (hl),a
            inc hl
            ld b,h
            ld c,l                  ; BC = save data pointer
            push bc
            ld bc,SLOT-3
            add hl,bc
            ld (savep),hl
            pop bc
            ld hl,nsaved
            inc (hl)
            pop hl                  ; HL = sprite data
dsrow:      ld a,(de)               ; image byte 0 at A
            ld (bc),a
            inc bc
            and (hl)
            inc hl
            or (hl)
            inc hl
            ld (de),a
            inc de
            ld a,(de)               ; byte 1 at A+1
            ld (bc),a
            inc bc
            and (hl)
            inc hl
            or (hl)
            inc hl
            ld (de),a
            dec de
            dec de
            dec de
            ld a,(de)               ; byte 2 at A-2
            ld (bc),a
            inc bc
            and (hl)
            inc hl
            or (hl)
            inc hl
            ld (de),a
            inc de
            ld a,(de)               ; byte 3 at A-1
            ld (bc),a
            inc bc
            and (hl)
            inc hl
            or (hl)
            inc hl
            ld (de),a
            ld a,e                  ; next row is 24 bytes lower
            sub 23
            ld e,a
            jr nc,dsr2
            dec d
dsr2:       ld a,(ds_rows)
            dec a
            ld (ds_rows),a
            jr nz,dsrow
            ret

; RESTORE_SPRITES - put back the background under last frame's sprites (LIFO)
RESTORE_SPRITES:
            ld a,(nsaved)
            or a
            ret z
            ld b,a
            ld hl,(savep)
rs_slot:    ld de,-SLOT
            add hl,de
            push hl
            push bc
            ld e,(hl)
            inc hl
            ld d,(hl)
            inc hl
            ld b,(hl)               ; rows
            inc hl
rs_row:     ld a,(hl)
            inc hl
            ld (de),a
            inc de
            ld a,(hl)
            inc hl
            ld (de),a
            dec de
            dec de
            dec de
            ld a,(hl)
            inc hl
            ld (de),a
            inc de
            ld a,(hl)
            inc hl
            ld (de),a
            ld a,e
            sub 23
            ld e,a
            jr nc,rs_r2
            dec d
rs_r2:      djnz rs_row
            pop bc
            pop hl
            djnz rs_slot
            ld hl,SAVEBUF
            ld (savep),hl
            xor a
            ld (nsaved),a
            ret


; ---------------------------------------------------------------------
; 4 channel 1-bit music engine (title screen only)
;  Each channel is a square wave from a 16 bit phase accumulator; the four
;  channels are time-sliced into the speaker latch (+1/-1 on bits 0/5), so the
;  speaker's own low-pass filtering mixes them.  One call to MUS_TICK renders
;  SAMPLE_ITERS*2 samples (~16 ms) after advancing the note streams.
;  Streams: pairs of (note,duration in ticks); note = MIDI number (24..96),
;  0 = rest, $FE = noise (random pitch every tick), $FF = loop to the start.
;  ch0 phase HL/step DE, ch1 HL'/DE', ch2 IX/BC, ch3 IY/BC'.
; ---------------------------------------------------------------------
SAMPLE_ITERS equ 100
MCH         equ MUSVARS             ; 4 x 10 bytes: ptr,remain,kind,step,phase,start

MUS_INIT:   ld hl,MCH
            ld de,MCH+1
            ld bc,39
            ld (hl),0
            ldir
            ld hl,MUSSTARTS
            ld ix,MCH
            ld b,4
mi1:        ld e,(hl)
            inc hl
            ld d,(hl)
            inc hl
            ld (ix+0),e
            ld (ix+1),d
            ld (ix+8),e
            ld (ix+9),d
            ld (ix+2),1
            ld de,10
            add ix,de
            djnz mi1
            ret

MUS_TICK:   ld ix,MCH
            ld b,4
mt_ch:      dec (ix+2)
            jr nz,mt_chk
            ld l,(ix+0)
            ld h,(ix+1)
            ld a,(hl)
            cp 0FFh
            jr nz,mt_nf
            ld l,(ix+8)             ; end of stream: loop
            ld h,(ix+9)
            ld a,(hl)
mt_nf:      inc hl
            ld c,(hl)
            inc hl
            ld (ix+0),l
            ld (ix+1),h
            ld (ix+2),c
            ld (ix+3),0
            or a
            jr z,mt_rest
            cp 0FEh
            jr z,mt_noise
            sub 24
            add a,a
            ld e,a
            ld d,0
            ld hl,PITCHTAB
            add hl,de
            ld e,(hl)
            inc hl
            ld d,(hl)
            ld (ix+4),e
            ld (ix+5),d
            jr mt_chk
mt_rest:    ld (ix+4),0
            ld (ix+5),0
            ld (ix+6),0
            ld (ix+7),0
            jr mt_chk
mt_noise:   ld (ix+3),1
mt_chk:     ld a,(ix+3)
            or a
            jr z,mt_nx
            push bc
            call RND
            ld (ix+4),a
            call RND
            or 40h
            ld (ix+5),a
            pop bc
mt_nx:      ld de,10
            add ix,de
            djnz mt_ch
            ld hl,(MCH+6)           ; load the phase/step registers
            ld de,(MCH+4)
            exx
            ld hl,(MCH+16)
            ld de,(MCH+14)
            ld bc,(MCH+34)
            exx
            ld bc,(MCH+24)
            ld ix,(MCH+26)
            ld iy,(MCH+36)
            ld a,SAMPLE_ITERS
            ld (mcnt),a
ml_loop:
            add hl,de
            ld a,h
            add a,a
            sbc a,a
            and 21h
            xor 28h
            ld (LATCH),a
            add ix,bc
            push ix
            pop af
            add a,a
            sbc a,a
            and 21h
            xor 28h
            ld (LATCH),a
            exx
            add hl,de
            ld a,h
            add a,a
            sbc a,a
            and 21h
            xor 28h
            ld (LATCH),a
            add iy,bc
            push iy
            pop af
            add a,a
            sbc a,a
            and 21h
            xor 28h
            ld (LATCH),a
            exx
            add hl,de
            ld a,h
            add a,a
            sbc a,a
            and 21h
            xor 28h
            ld (LATCH),a
            add ix,bc
            push ix
            pop af
            add a,a
            sbc a,a
            and 21h
            xor 28h
            ld (LATCH),a
            exx
            add hl,de
            ld a,h
            add a,a
            sbc a,a
            and 21h
            xor 28h
            ld (LATCH),a
            add iy,bc
            push iy
            pop af
            add a,a
            sbc a,a
            and 21h
            xor 28h
            ld (LATCH),a
            exx
            ld a,(mcnt)
            dec a
            ld (mcnt),a
            jp nz,ml_loop
            ld (MCH+6),hl
            ld (MCH+26),ix
            ld (MCH+36),iy
            exx
            ld (MCH+16),hl
            exx
            ld a,08h
            ld (LATCH),a
            ret

; ---------------------------------------------------------------------
; Unrolled blitter - generated by build_1942.py
; ---------------------------------------------------------------------
BLIT_P1:  ld (SAVESP),sp
BP0:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,077F8h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP1:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,077ECh
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP2:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,077D8h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP3:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,077CCh
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP4:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,077B8h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP5:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,077ACh
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP6:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07798h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP7:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0778Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP8:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07778h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP9:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0776Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP10:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07758h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP11:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0774Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP12:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07738h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP13:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0772Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP14:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07718h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP15:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0770Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP16:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,076F8h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP17:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,076ECh
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP18:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,076D8h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP19:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,076CCh
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP20:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,076B8h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP21:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,076ACh
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP22:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07698h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP23:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0768Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP24:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07678h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP25:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0766Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP26:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07658h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP27:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0764Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP28:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07638h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP29:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0762Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP30:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07618h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP31:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0760Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP32:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,075F8h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP33:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,075ECh
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP34:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,075D8h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP35:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,075CCh
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP36:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,075B8h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP37:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,075ACh
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP38:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07598h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP39:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0758Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP40:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07578h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP41:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0756Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP42:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07558h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP43:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0754Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP44:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07538h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP45:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0752Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP46:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07518h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP47:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0750Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP48:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,074F8h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP49:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,074ECh
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP50:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,074D8h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP51:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,074CCh
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP52:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,074B8h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP53:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,074ACh
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP54:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07498h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP55:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0748Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP56:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07478h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP57:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0746Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP58:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07458h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP59:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0744Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP60:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07438h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP61:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0742Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP62:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07418h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP63:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0740Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
        ld sp,(SAVESP)
        ret

BLIT_P2:  ld (SAVESP),sp
BP64:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,073F8h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP65:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,073ECh
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP66:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,073D8h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP67:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,073CCh
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP68:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,073B8h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP69:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,073ACh
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP70:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07398h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP71:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0738Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP72:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07378h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP73:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0736Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP74:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07358h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP75:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0734Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP76:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07338h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP77:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0732Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP78:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07318h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP79:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0730Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP80:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,072F8h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP81:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,072ECh
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP82:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,072D8h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP83:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,072CCh
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP84:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,072B8h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP85:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,072ACh
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP86:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07298h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP87:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0728Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP88:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07278h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP89:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0726Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP90:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07258h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP91:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0724Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP92:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07238h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP93:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0722Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP94:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07218h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP95:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0720Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP96:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,071F8h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP97:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,071ECh
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP98:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,071D8h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP99:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,071CCh
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP100:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,071B8h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP101:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,071ACh
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP102:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07198h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP103:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0718Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP104:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07178h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP105:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0716Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP106:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07158h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP107:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0714Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP108:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07138h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP109:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0712Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP110:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07118h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP111:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0710Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP112:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,070F8h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP113:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,070ECh
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP114:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,070D8h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP115:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,070CCh
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP116:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,070B8h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP117:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,070ACh
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP118:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07098h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP119:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0708Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP120:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07078h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP121:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0706Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP122:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07058h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP123:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0704Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP124:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07038h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP125:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0702Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP126:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,07018h
        push bc
        push de
        push hl
        push af
        push ix
        push iy
BP127:     ld sp,0            ; src patched each frame
        pop bc
        pop de
        pop hl
        pop af
        pop ix
        pop iy
        ld sp,0700Ch
        push bc
        push de
        push hl
        push af
        push ix
        push iy
        ld sp,(SAVESP)
        ret

PATCH_BLIT: ld hl,(W0)
        ld de,-1534
        add hl,de
        ld de,12
        ld (BP0+1),hl
        add hl,de
        ld (BP1+1),hl
        add hl,de
        ld (BP2+1),hl
        add hl,de
        ld (BP3+1),hl
        add hl,de
        ld (BP4+1),hl
        add hl,de
        ld (BP5+1),hl
        add hl,de
        ld (BP6+1),hl
        add hl,de
        ld (BP7+1),hl
        add hl,de
        ld (BP8+1),hl
        add hl,de
        ld (BP9+1),hl
        add hl,de
        ld (BP10+1),hl
        add hl,de
        ld (BP11+1),hl
        add hl,de
        ld (BP12+1),hl
        add hl,de
        ld (BP13+1),hl
        add hl,de
        ld (BP14+1),hl
        add hl,de
        ld (BP15+1),hl
        add hl,de
        ld (BP16+1),hl
        add hl,de
        ld (BP17+1),hl
        add hl,de
        ld (BP18+1),hl
        add hl,de
        ld (BP19+1),hl
        add hl,de
        ld (BP20+1),hl
        add hl,de
        ld (BP21+1),hl
        add hl,de
        ld (BP22+1),hl
        add hl,de
        ld (BP23+1),hl
        add hl,de
        ld (BP24+1),hl
        add hl,de
        ld (BP25+1),hl
        add hl,de
        ld (BP26+1),hl
        add hl,de
        ld (BP27+1),hl
        add hl,de
        ld (BP28+1),hl
        add hl,de
        ld (BP29+1),hl
        add hl,de
        ld (BP30+1),hl
        add hl,de
        ld (BP31+1),hl
        add hl,de
        ld (BP32+1),hl
        add hl,de
        ld (BP33+1),hl
        add hl,de
        ld (BP34+1),hl
        add hl,de
        ld (BP35+1),hl
        add hl,de
        ld (BP36+1),hl
        add hl,de
        ld (BP37+1),hl
        add hl,de
        ld (BP38+1),hl
        add hl,de
        ld (BP39+1),hl
        add hl,de
        ld (BP40+1),hl
        add hl,de
        ld (BP41+1),hl
        add hl,de
        ld (BP42+1),hl
        add hl,de
        ld (BP43+1),hl
        add hl,de
        ld (BP44+1),hl
        add hl,de
        ld (BP45+1),hl
        add hl,de
        ld (BP46+1),hl
        add hl,de
        ld (BP47+1),hl
        add hl,de
        ld (BP48+1),hl
        add hl,de
        ld (BP49+1),hl
        add hl,de
        ld (BP50+1),hl
        add hl,de
        ld (BP51+1),hl
        add hl,de
        ld (BP52+1),hl
        add hl,de
        ld (BP53+1),hl
        add hl,de
        ld (BP54+1),hl
        add hl,de
        ld (BP55+1),hl
        add hl,de
        ld (BP56+1),hl
        add hl,de
        ld (BP57+1),hl
        add hl,de
        ld (BP58+1),hl
        add hl,de
        ld (BP59+1),hl
        add hl,de
        ld (BP60+1),hl
        add hl,de
        ld (BP61+1),hl
        add hl,de
        ld (BP62+1),hl
        add hl,de
        ld (BP63+1),hl
        add hl,de
        ld (BP64+1),hl
        add hl,de
        ld (BP65+1),hl
        add hl,de
        ld (BP66+1),hl
        add hl,de
        ld (BP67+1),hl
        add hl,de
        ld (BP68+1),hl
        add hl,de
        ld (BP69+1),hl
        add hl,de
        ld (BP70+1),hl
        add hl,de
        ld (BP71+1),hl
        add hl,de
        ld (BP72+1),hl
        add hl,de
        ld (BP73+1),hl
        add hl,de
        ld (BP74+1),hl
        add hl,de
        ld (BP75+1),hl
        add hl,de
        ld (BP76+1),hl
        add hl,de
        ld (BP77+1),hl
        add hl,de
        ld (BP78+1),hl
        add hl,de
        ld (BP79+1),hl
        add hl,de
        ld (BP80+1),hl
        add hl,de
        ld (BP81+1),hl
        add hl,de
        ld (BP82+1),hl
        add hl,de
        ld (BP83+1),hl
        add hl,de
        ld (BP84+1),hl
        add hl,de
        ld (BP85+1),hl
        add hl,de
        ld (BP86+1),hl
        add hl,de
        ld (BP87+1),hl
        add hl,de
        ld (BP88+1),hl
        add hl,de
        ld (BP89+1),hl
        add hl,de
        ld (BP90+1),hl
        add hl,de
        ld (BP91+1),hl
        add hl,de
        ld (BP92+1),hl
        add hl,de
        ld (BP93+1),hl
        add hl,de
        ld (BP94+1),hl
        add hl,de
        ld (BP95+1),hl
        add hl,de
        ld (BP96+1),hl
        add hl,de
        ld (BP97+1),hl
        add hl,de
        ld (BP98+1),hl
        add hl,de
        ld (BP99+1),hl
        add hl,de
        ld (BP100+1),hl
        add hl,de
        ld (BP101+1),hl
        add hl,de
        ld (BP102+1),hl
        add hl,de
        ld (BP103+1),hl
        add hl,de
        ld (BP104+1),hl
        add hl,de
        ld (BP105+1),hl
        add hl,de
        ld (BP106+1),hl
        add hl,de
        ld (BP107+1),hl
        add hl,de
        ld (BP108+1),hl
        add hl,de
        ld (BP109+1),hl
        add hl,de
        ld (BP110+1),hl
        add hl,de
        ld (BP111+1),hl
        add hl,de
        ld (BP112+1),hl
        add hl,de
        ld (BP113+1),hl
        add hl,de
        ld (BP114+1),hl
        add hl,de
        ld (BP115+1),hl
        add hl,de
        ld (BP116+1),hl
        add hl,de
        ld (BP117+1),hl
        add hl,de
        ld (BP118+1),hl
        add hl,de
        ld (BP119+1),hl
        add hl,de
        ld (BP120+1),hl
        add hl,de
        ld (BP121+1),hl
        add hl,de
        ld (BP122+1),hl
        add hl,de
        ld (BP123+1),hl
        add hl,de
        ld (BP124+1),hl
        add hl,de
        ld (BP125+1),hl
        add hl,de
        ld (BP126+1),hl
        add hl,de
        ld (BP127+1),hl
        ret

; ---------------------------------------------------------------------
; Tables and data
; ---------------------------------------------------------------------
PITCHTAB:
        defb 0A6h,000h,0B0h,000h,0BBh,000h,0C6h,000h,0D2h,000h,0DEh,000h,0EBh,000h,0F9h,000h
        defb 008h,001h,018h,001h,029h,001h,03Ah,001h,04Dh,001h,061h,001h,076h,001h,08Ch,001h
        defb 0A3h,001h,0BCh,001h,0D7h,001h,0F3h,001h,010h,002h,030h,002h,051h,002h,074h,002h
        defb 09Ah,002h,0C1h,002h,0EBh,002h,018h,003h,047h,003h,079h,003h,0AEh,003h,0E6h,003h
        defb 021h,004h,060h,004h,0A2h,004h,0E9h,004h,034h,005h,083h,005h,0D7h,005h,030h,006h
        defb 08Eh,006h,0F1h,006h,05Bh,007h,0CBh,007h,042h,008h,0BFh,008h,045h,009h,0D2h,009h
        defb 067h,00Ah,006h,00Bh,0ADh,00Bh,05Fh,00Ch,01Bh,00Dh,0E3h,00Dh,0B6h,00Eh,096h,00Fh
        defb 084h,010h,07Fh,011h,089h,012h,0A3h,013h,0CEh,014h,00Bh,016h,05Bh,017h,0BEh,018h
        defb 037h,01Ah,0C6h,01Bh,06Dh,01Dh,02Dh,01Fh,007h,021h,0FEh,022h,013h,025h,047h,027h
        defb 09Dh,029h
MUSSTARTS:  defw MUS_CH0,MUS_CH1,MUS_CH2,MUS_CH3
MUS_CH0:
        defb 045h,01Ch,04Ah,01Ch,04Dh,01Ch,051h,01Ch,04Fh,02Ah,04Dh,00Eh,04Ah,01Ch,046h,01Ch
        defb 04Ch,01Ch,04Fh,01Ch,054h,01Ch,04Fh,01Ch,051h,02Ah,04Fh,00Eh,04Ch,01Ch,049h,01Ch
        defb 045h,01Ch,04Ah,01Ch,04Dh,01Ch,051h,01Ch,04Fh,01Ch,051h,01Ch,052h,01Ch,051h,01Ch
        defb 04Fh,01Ch,04Dh,01Ch,04Ch,01Ch,049h,01Ch,04Ah,054h,000h,01Ch,046h,01Ch,04Ah,01Ch
        defb 04Fh,038h,04Dh,01Ch,051h,01Ch,056h,038h,055h,01Ch,058h,01Ch,051h,038h,051h,054h
        defb 000h,01Ch,045h,01Ch,04Ah,01Ch,04Dh,01Ch,051h,01Ch,04Fh,02Ah,04Dh,00Eh,04Ah,01Ch
        defb 046h,01Ch,04Ch,01Ch,04Fh,01Ch,051h,01Ch,055h,01Ch,056h,054h,000h,01Ch,0FFh
MUS_CH1:
        defb 03Eh,007h,041h,007h,045h,007h,041h,007h,03Eh,007h,041h,007h,045h,007h,041h,007h
        defb 03Eh,007h,041h,007h,045h,007h,041h,007h,03Eh,007h,041h,007h,045h,007h,041h,007h
        defb 03Ah,007h,03Eh,007h,041h,007h,03Eh,007h,03Ah,007h,03Eh,007h,041h,007h,03Eh,007h
        defb 03Ah,007h,03Eh,007h,041h,007h,03Eh,007h,03Ah,007h,03Eh,007h,041h,007h,03Eh,007h
        defb 03Ch,007h,040h,007h,043h,007h,040h,007h,03Ch,007h,040h,007h,043h,007h,040h,007h
        defb 03Ch,007h,040h,007h,043h,007h,040h,007h,03Ch,007h,040h,007h,043h,007h,040h,007h
        defb 039h,007h,03Dh,007h,040h,007h,03Dh,007h,039h,007h,03Dh,007h,040h,007h,03Dh,007h
        defb 039h,007h,03Dh,007h,040h,007h,03Dh,007h,039h,007h,03Dh,007h,040h,007h,03Dh,007h
        defb 03Eh,007h,041h,007h,045h,007h,041h,007h,03Eh,007h,041h,007h,045h,007h,041h,007h
        defb 03Eh,007h,041h,007h,045h,007h,041h,007h,03Eh,007h,041h,007h,045h,007h,041h,007h
        defb 03Ah,007h,03Eh,007h,041h,007h,03Eh,007h,03Ah,007h,03Eh,007h,041h,007h,03Eh,007h
        defb 03Ah,007h,03Eh,007h,041h,007h,03Eh,007h,03Ah,007h,03Eh,007h,041h,007h,03Eh,007h
        defb 039h,007h,03Dh,007h,040h,007h,03Dh,007h,039h,007h,03Dh,007h,040h,007h,03Dh,007h
        defb 039h,007h,03Dh,007h,040h,007h,03Dh,007h,039h,007h,03Dh,007h,040h,007h,03Dh,007h
        defb 03Eh,007h,041h,007h,045h,007h,041h,007h,03Eh,007h,041h,007h,045h,007h,041h,007h
        defb 03Eh,007h,041h,007h,045h,007h,041h,007h,03Eh,007h,041h,007h,045h,007h,041h,007h
        defb 037h,007h,03Ah,007h,03Eh,007h,03Ah,007h,037h,007h,03Ah,007h,03Eh,007h,03Ah,007h
        defb 037h,007h,03Ah,007h,03Eh,007h,03Ah,007h,037h,007h,03Ah,007h,03Eh,007h,03Ah,007h
        defb 03Eh,007h,041h,007h,045h,007h,041h,007h,03Eh,007h,041h,007h,045h,007h,041h,007h
        defb 03Eh,007h,041h,007h,045h,007h,041h,007h,03Eh,007h,041h,007h,045h,007h,041h,007h
        defb 039h,007h,03Dh,007h,040h,007h,03Dh,007h,039h,007h,03Dh,007h,040h,007h,03Dh,007h
        defb 039h,007h,03Dh,007h,040h,007h,03Dh,007h,039h,007h,03Dh,007h,040h,007h,03Dh,007h
        defb 039h,007h,03Dh,007h,040h,007h,03Dh,007h,039h,007h,03Dh,007h,040h,007h,03Dh,007h
        defb 039h,007h,03Dh,007h,040h,007h,03Dh,007h,039h,007h,03Dh,007h,040h,007h,03Dh,007h
        defb 03Eh,007h,041h,007h,045h,007h,041h,007h,03Eh,007h,041h,007h,045h,007h,041h,007h
        defb 03Eh,007h,041h,007h,045h,007h,041h,007h,03Eh,007h,041h,007h,045h,007h,041h,007h
        defb 03Ah,007h,03Eh,007h,041h,007h,03Eh,007h,03Ah,007h,03Eh,007h,041h,007h,03Eh,007h
        defb 03Ah,007h,03Eh,007h,041h,007h,03Eh,007h,03Ah,007h,03Eh,007h,041h,007h,03Eh,007h
        defb 039h,007h,03Dh,007h,040h,007h,03Dh,007h,039h,007h,03Dh,007h,040h,007h,03Dh,007h
        defb 039h,007h,03Dh,007h,040h,007h,03Dh,007h,039h,007h,03Dh,007h,040h,007h,03Dh,007h
        defb 03Eh,007h,041h,007h,045h,007h,041h,007h,03Eh,007h,041h,007h,045h,007h,041h,007h
        defb 03Eh,007h,041h,007h,045h,007h,041h,007h,03Eh,007h,041h,007h,045h,007h,041h,007h
        defb 0FFh
MUS_CH2:
        defb 026h,015h,000h,007h,02Dh,015h,000h,007h,026h,015h,000h,007h,02Dh,015h,000h,007h
        defb 022h,015h,000h,007h,029h,015h,000h,007h,022h,015h,000h,007h,029h,015h,000h,007h
        defb 024h,015h,000h,007h,02Bh,015h,000h,007h,024h,015h,000h,007h,02Bh,015h,000h,007h
        defb 021h,015h,000h,007h,028h,015h,000h,007h,021h,015h,000h,007h,028h,015h,000h,007h
        defb 026h,015h,000h,007h,02Dh,015h,000h,007h,026h,015h,000h,007h,02Dh,015h,000h,007h
        defb 022h,015h,000h,007h,029h,015h,000h,007h,022h,015h,000h,007h,029h,015h,000h,007h
        defb 021h,015h,000h,007h,028h,015h,000h,007h,021h,015h,000h,007h,028h,015h,000h,007h
        defb 026h,015h,000h,007h,02Dh,015h,000h,007h,026h,015h,000h,007h,02Dh,015h,000h,007h
        defb 01Fh,015h,000h,007h,026h,015h,000h,007h,01Fh,015h,000h,007h,026h,015h,000h,007h
        defb 026h,015h,000h,007h,02Dh,015h,000h,007h,026h,015h,000h,007h,02Dh,015h,000h,007h
        defb 021h,015h,000h,007h,028h,015h,000h,007h,021h,015h,000h,007h,028h,015h,000h,007h
        defb 021h,015h,000h,007h,028h,015h,000h,007h,021h,015h,000h,007h,028h,015h,000h,007h
        defb 026h,015h,000h,007h,02Dh,015h,000h,007h,026h,015h,000h,007h,02Dh,015h,000h,007h
        defb 022h,015h,000h,007h,029h,015h,000h,007h,022h,015h,000h,007h,029h,015h,000h,007h
        defb 021h,015h,000h,007h,028h,015h,000h,007h,021h,015h,000h,007h,028h,015h,000h,007h
        defb 026h,015h,000h,007h,02Dh,015h,000h,007h,026h,015h,000h,007h,02Dh,015h,000h,007h
        defb 0FFh
MUS_CH3:
        defb 01Fh,009h,000h,013h,0FEh,007h,000h,015h,01Fh,009h,000h,013h,0FEh,007h,000h,015h
        defb 01Fh,009h,000h,013h,0FEh,007h,000h,015h,01Fh,009h,000h,013h,0FEh,007h,000h,015h
        defb 01Fh,009h,000h,013h,0FEh,007h,000h,015h,01Fh,009h,000h,013h,0FEh,007h,000h,015h
        defb 01Fh,009h,000h,013h,0FEh,007h,000h,015h,01Fh,009h,000h,013h,0FEh,007h,000h,015h
        defb 01Fh,009h,000h,013h,0FEh,007h,000h,015h,01Fh,009h,000h,013h,0FEh,007h,000h,015h
        defb 01Fh,009h,000h,013h,0FEh,007h,000h,015h,01Fh,009h,000h,013h,0FEh,007h,000h,015h
        defb 01Fh,009h,000h,013h,0FEh,007h,000h,015h,01Fh,009h,000h,013h,0FEh,007h,000h,015h
        defb 01Fh,009h,000h,013h,0FEh,007h,000h,015h,01Fh,009h,000h,013h,0FEh,007h,000h,015h
        defb 01Fh,009h,000h,013h,0FEh,007h,000h,015h,01Fh,009h,000h,013h,0FEh,007h,000h,015h
        defb 01Fh,009h,000h,013h,0FEh,007h,000h,015h,01Fh,009h,000h,013h,0FEh,007h,000h,015h
        defb 01Fh,009h,000h,013h,0FEh,007h,000h,015h,01Fh,009h,000h,013h,0FEh,007h,000h,015h
        defb 01Fh,009h,000h,013h,0FEh,007h,000h,015h,01Fh,009h,000h,013h,0FEh,007h,000h,015h
        defb 01Fh,009h,000h,013h,0FEh,007h,000h,015h,01Fh,009h,000h,013h,0FEh,007h,000h,015h
        defb 01Fh,009h,000h,013h,0FEh,007h,000h,015h,01Fh,009h,000h,013h,0FEh,007h,000h,015h
        defb 01Fh,009h,000h,013h,0FEh,007h,000h,015h,01Fh,009h,000h,013h,0FEh,007h,000h,015h
        defb 01Fh,009h,000h,013h,0FEh,007h,000h,015h,01Fh,009h,000h,013h,0FEh,007h,000h,015h
        defb 0FFh
SWAYTAB:    defb 0,1,1,1,1,0,0,0,0,0FFh,0FFh,0FFh,0FFh,0,0,0
LOOPFR:     defb 0,1,2,2,1,0,0,0
PLTAB:      defw SPR_PL0,SPR_PL1,SPR_PL2,SPR_PLL,SPR_PLR
BOSSTAB:    defb 0,0
            defw SPR_BS0
            defb 9,0
            defw SPR_BS1
            defb 18,0
            defw SPR_BS2
            defb 0,8
            defw SPR_BS3
            defb 9,8
            defw SPR_BS4
            defb 18,8
            defw SPR_BS5
BEXPOFF:    defb 4,2,14,6,8,10
EXPTAB:     defw SPR_EX0,SPR_EX1,SPR_EX2
STR_PRESS:  defb 01Ah,01Ch,00Fh,01Dh,01Dh,00Ah,01Dh,01Ah,00Bh,00Dh,00Fh,00Ah,01Eh,019h,00Ah,01Dh,01Eh,00Bh,01Ch,01Eh,0FFh
STR_K1:     defb 01Bh,00Ah,01Fh,01Ah,00Ah,00Ah,00Ah,00Ah,00Ah,00Bh,00Ah,00Eh,019h,021h,018h,0FFh
STR_K2:     defb 017h,00Ah,016h,00Fh,010h,01Eh,00Ah,00Ah,02Ah,00Ah,01Ch,013h,011h,012h,01Eh,0FFh
STR_K3:     defb 01Dh,01Ah,00Bh,00Dh,00Fh,00Ah,010h,013h,01Ch,00Fh,00Ah,018h,00Ah,016h,019h,019h,01Ah,0FFh
STR_JOY_OFF: defb 014h,00Ah,00Ah,014h,019h,023h,01Dh,01Eh,013h,00Dh,015h,00Ah,019h,010h,010h,00Ah,00Ah,0FFh
STR_JOY_ON:  defb 014h,00Ah,00Ah,014h,019h,023h,01Dh,01Eh,013h,00Dh,015h,00Ah,019h,018h,00Ah,00Ah,00Ah,0FFh
STR_GAMEOVER: defb 011h,00Bh,017h,00Fh,00Ah,019h,020h,00Fh,01Ch,0FFh
ICON:
        defb 069h,069h,055h,055h,069h,069h,0A9h,06Ah,0A5h,05Ah
ICONBLANK:  defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
BIGDIGITS:
        defb 0A5h,0AAh,0A5h,0AAh,055h,0AAh,055h,0AAh,0A5h,0AAh,0A5h,0AAh,0A5h,0AAh,0A5h,0AAh
        defb 055h,05Ah,055h,05Ah,055h,05Ah,055h,05Ah,05Ah,05Ah,05Ah,05Ah,055h,05Ah,055h,05Ah
        defb 0AAh,05Ah,0AAh,05Ah,055h,05Ah,055h,05Ah,05Ah,05Ah,05Ah,05Ah,05Ah,05Ah,05Ah,05Ah
        defb 055h,05Ah,055h,05Ah,0AAh,05Ah,0AAh,05Ah,0AAh,05Ah,0AAh,05Ah,055h,05Ah,055h,05Ah
        defb 0AAh,05Ah,0AAh,05Ah,055h,05Ah,055h,05Ah,05Ah,0AAh,05Ah,0AAh,055h,05Ah,055h,05Ah
FONT_Y:
        defb 056h,066h,066h,066h,056h
        defb 09Ah,05Ah,09Ah,09Ah,056h
        defb 056h,0A6h,056h,06Ah,056h
        defb 056h,0A6h,056h,0A6h,056h
        defb 066h,066h,056h,0A6h,0A6h
        defb 056h,06Ah,056h,0A6h,056h
        defb 056h,06Ah,056h,066h,056h
        defb 056h,0A6h,0A6h,09Ah,09Ah
        defb 056h,066h,056h,066h,056h
        defb 056h,066h,056h,0A6h,056h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh
        defb 09Ah,066h,056h,066h,066h
        defb 05Ah,066h,05Ah,066h,05Ah
        defb 096h,06Ah,06Ah,06Ah,096h
        defb 05Ah,066h,066h,066h,05Ah
        defb 056h,06Ah,05Ah,06Ah,056h
        defb 056h,06Ah,05Ah,06Ah,06Ah
        defb 096h,06Ah,066h,066h,096h
        defb 066h,066h,056h,066h,066h
        defb 056h,09Ah,09Ah,09Ah,056h
        defb 0A6h,0A6h,0A6h,066h,09Ah
        defb 066h,066h,05Ah,066h,066h
        defb 06Ah,06Ah,06Ah,06Ah,056h
        defb 066h,056h,056h,066h,066h
        defb 056h,066h,066h,066h,066h
        defb 09Ah,066h,066h,066h,09Ah
        defb 05Ah,066h,05Ah,06Ah,06Ah
        defb 09Ah,066h,066h,056h,096h
        defb 05Ah,066h,05Ah,066h,066h
        defb 096h,06Ah,09Ah,0A6h,05Ah
        defb 056h,09Ah,09Ah,09Ah,09Ah
        defb 066h,066h,066h,066h,056h
        defb 066h,066h,066h,066h,09Ah
        defb 066h,066h,056h,056h,066h
        defb 066h,066h,09Ah,066h,066h
        defb 066h,066h,09Ah,09Ah,09Ah
        defb 056h,0A6h,09Ah,06Ah,056h
        defb 0AAh,0AAh,056h,0AAh,0AAh
        defb 09Ah,09Ah,09Ah,0AAh,09Ah
        defb 0AAh,09Ah,0AAh,09Ah,0AAh
        defb 0AAh,056h,0AAh,056h,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,09Ah
        defb 0AAh,0AAh,0AAh,09Ah,06Ah
PANELIMG:
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,082h,082h,08Ah,00Ah,002h,0AAh,0AAh
        defb 05Ah,02Ah,02Ah,022h,022h,02Ah,0AAh,0AAh
        defb 05Ah,08Ah,02Ah,022h,00Ah,00Ah,0AAh,0AAh
        defb 05Ah,0A2h,02Ah,022h,022h,02Ah,0AAh,0AAh
        defb 05Ah,00Ah,082h,08Ah,022h,002h,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,022h,002h,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,022h,08Ah,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,002h,08Ah,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,022h,08Ah,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,022h,002h,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,082h,002h,08Ah,082h,002h,0AAh,0AAh
        defb 05Ah,02Ah,08Ah,022h,02Ah,02Ah,0AAh,0AAh
        defb 05Ah,08Ah,08Ah,002h,022h,00Ah,0AAh,0AAh
        defb 05Ah,0A2h,08Ah,022h,022h,02Ah,0AAh,0AAh
        defb 05Ah,00Ah,08Ah,022h,082h,002h,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,02Ah,08Ah,08Ah,00Ah,082h,0AAh,0AAh
        defb 05Ah,02Ah,022h,022h,022h,02Ah,0AAh,0AAh
        defb 05Ah,02Ah,022h,022h,00Ah,08Ah,0AAh,0AAh
        defb 05Ah,02Ah,022h,022h,02Ah,0A2h,0AAh,0AAh
        defb 05Ah,002h,08Ah,08Ah,02Ah,00Ah,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 05Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
; ---- sprite descriptors: height, then 8 pointers (one per pixel shift 0-7).
;      data per row = 4 bytes of (mask,data) pairs, in image-byte order.
SPR_PL0:  defb 8
        defw SPD_PL0_0,SPD_PL0_1,SPD_PL0_2,SPD_PL0_3,SPD_PL0_4,SPD_PL0_5,SPD_PL0_6,SPD_PL0_7
SPR_PL1:  defb 8
        defw SPD_PL1_0,SPD_PL1_0,SPD_PL1_2,SPD_PL1_2,SPD_PL1_4,SPD_PL1_4,SPD_PL1_6,SPD_PL1_6
SPR_PL2:  defb 8
        defw SPD_PL2_0,SPD_PL2_0,SPD_PL2_2,SPD_PL2_2,SPD_PL2_4,SPD_PL2_4,SPD_PL2_6,SPD_PL2_6
SPR_PLL:  defb 8
        defw SPD_PLL_0,SPD_PLL_1,SPD_PLL_2,SPD_PLL_3,SPD_PLL_4,SPD_PLL_5,SPD_PLL_6,SPD_PLL_7
SPR_PLR:  defb 8
        defw SPD_PLR_0,SPD_PLR_1,SPD_PLR_2,SPD_PLR_3,SPD_PLR_4,SPD_PLR_5,SPD_PLR_6,SPD_PLR_7
SPR_EN0:  defb 7
        defw SPD_EN0_0,SPD_EN0_0,SPD_EN0_2,SPD_EN0_2,SPD_EN0_4,SPD_EN0_4,SPD_EN0_6,SPD_EN0_6
SPR_ENL:  defb 7
        defw SPD_ENL_0,SPD_ENL_0,SPD_ENL_2,SPD_ENL_2,SPD_ENL_4,SPD_ENL_4,SPD_ENL_6,SPD_ENL_6
SPR_ENR:  defb 7
        defw SPD_ENR_0,SPD_ENR_0,SPD_ENR_2,SPD_ENR_2,SPD_ENR_4,SPD_ENR_4,SPD_ENR_6,SPD_ENR_6
SPR_EX0:  defb 6
        defw SPD_EX0_0,SPD_EX0_0,SPD_EX0_2,SPD_EX0_2,SPD_EX0_4,SPD_EX0_4,SPD_EX0_6,SPD_EX0_6
SPR_EX1:  defb 6
        defw SPD_EX1_0,SPD_EX1_0,SPD_EX1_2,SPD_EX1_2,SPD_EX1_4,SPD_EX1_4,SPD_EX1_6,SPD_EX1_6
SPR_EX2:  defb 6
        defw SPD_EX2_0,SPD_EX2_0,SPD_EX2_2,SPD_EX2_2,SPD_EX2_4,SPD_EX2_4,SPD_EX2_6,SPD_EX2_6
SPR_PB:  defb 2
        defw SPD_PB_0,SPD_PB_0,SPD_PB_2,SPD_PB_2,SPD_PB_4,SPD_PB_4,SPD_PB_6,SPD_PB_6
SPR_EB:  defb 2
        defw SPD_EB_0,SPD_EB_0,SPD_EB_2,SPD_EB_2,SPD_EB_4,SPD_EB_4,SPD_EB_6,SPD_EB_6
SPR_BS0:  defb 8
        defw SPD_BS0_0,SPD_BS0_0,SPD_BS0_2,SPD_BS0_2,SPD_BS0_4,SPD_BS0_4,SPD_BS0_6,SPD_BS0_6
SPR_BS1:  defb 8
        defw SPD_BS1_0,SPD_BS1_0,SPD_BS1_2,SPD_BS1_2,SPD_BS1_4,SPD_BS1_4,SPD_BS1_6,SPD_BS1_6
SPR_BS2:  defb 8
        defw SPD_BS2_0,SPD_BS2_0,SPD_BS2_2,SPD_BS2_2,SPD_BS2_4,SPD_BS2_4,SPD_BS2_6,SPD_BS2_6
SPR_BS3:  defb 8
        defw SPD_BS3_0,SPD_BS3_0,SPD_BS3_2,SPD_BS3_2,SPD_BS3_4,SPD_BS3_4,SPD_BS3_6,SPD_BS3_6
SPR_BS4:  defb 8
        defw SPD_BS4_0,SPD_BS4_0,SPD_BS4_2,SPD_BS4_2,SPD_BS4_4,SPD_BS4_4,SPD_BS4_6,SPD_BS4_6
SPR_BS5:  defb 8
        defw SPD_BS5_0,SPD_BS5_0,SPD_BS5_2,SPD_BS5_2,SPD_BS5_4,SPD_BS5_4,SPD_BS5_6,SPD_BS5_6
SPD_PL0_0:
        defb 000h,09Ah,000h,069h,03Fh,080h,0FFh,000h
        defb 000h,099h,000h,059h,03Fh,080h,0FFh,000h
        defb 000h,0D5h,000h,0D5h,03Fh,0C0h,0FFh,000h
        defb 000h,055h,000h,055h,03Fh,040h,0FFh,000h
        defb 000h,099h,000h,0D9h,03Fh,080h,0FFh,000h
        defb 000h,09Ah,000h,069h,03Fh,080h,0FFh,000h
        defb 000h,095h,000h,055h,03Fh,080h,0FFh,000h
        defb 000h,05Ah,000h,0A9h,03Fh,040h,0FFh,000h
SPD_PL0_1:
        defb 0C0h,026h,000h,09Ah,00Fh,060h,0FFh,000h
        defb 0C0h,026h,000h,056h,00Fh,060h,0FFh,000h
        defb 0C0h,035h,000h,075h,00Fh,070h,0FFh,000h
        defb 0C0h,015h,000h,055h,00Fh,050h,0FFh,000h
        defb 0C0h,026h,000h,076h,00Fh,060h,0FFh,000h
        defb 0C0h,026h,000h,09Ah,00Fh,060h,0FFh,000h
        defb 0C0h,025h,000h,055h,00Fh,060h,0FFh,000h
        defb 0C0h,016h,000h,0AAh,00Fh,050h,0FFh,000h
SPD_PL0_2:
        defb 0F0h,009h,000h,0A6h,003h,098h,0FFh,000h
        defb 0F0h,009h,000h,095h,003h,098h,0FFh,000h
        defb 0F0h,00Dh,000h,05Dh,003h,05Ch,0FFh,000h
        defb 0F0h,005h,000h,055h,003h,054h,0FFh,000h
        defb 0F0h,009h,000h,09Dh,003h,098h,0FFh,000h
        defb 0F0h,009h,000h,0A6h,003h,098h,0FFh,000h
        defb 0F0h,009h,000h,055h,003h,058h,0FFh,000h
        defb 0F0h,005h,000h,0AAh,003h,094h,0FFh,000h
SPD_PL0_3:
        defb 0FCh,002h,000h,069h,000h,0A6h,0FFh,000h
        defb 0FCh,002h,000h,065h,000h,066h,0FFh,000h
        defb 0FCh,003h,000h,057h,000h,057h,0FFh,000h
        defb 0FCh,001h,000h,055h,000h,055h,0FFh,000h
        defb 0FCh,002h,000h,067h,000h,066h,0FFh,000h
        defb 0FCh,002h,000h,069h,000h,0A6h,0FFh,000h
        defb 0FCh,002h,000h,055h,000h,056h,0FFh,000h
        defb 0FCh,001h,000h,06Ah,000h,0A5h,0FFh,000h
SPD_PL0_4:
        defb 0FFh,000h,000h,09Ah,000h,069h,03Fh,080h
        defb 0FFh,000h,000h,099h,000h,059h,03Fh,080h
        defb 0FFh,000h,000h,0D5h,000h,0D5h,03Fh,0C0h
        defb 0FFh,000h,000h,055h,000h,055h,03Fh,040h
        defb 0FFh,000h,000h,099h,000h,0D9h,03Fh,080h
        defb 0FFh,000h,000h,09Ah,000h,069h,03Fh,080h
        defb 0FFh,000h,000h,095h,000h,055h,03Fh,080h
        defb 0FFh,000h,000h,05Ah,000h,0A9h,03Fh,040h
SPD_PL0_5:
        defb 0FFh,000h,0C0h,026h,000h,09Ah,00Fh,060h
        defb 0FFh,000h,0C0h,026h,000h,056h,00Fh,060h
        defb 0FFh,000h,0C0h,035h,000h,075h,00Fh,070h
        defb 0FFh,000h,0C0h,015h,000h,055h,00Fh,050h
        defb 0FFh,000h,0C0h,026h,000h,076h,00Fh,060h
        defb 0FFh,000h,0C0h,026h,000h,09Ah,00Fh,060h
        defb 0FFh,000h,0C0h,025h,000h,055h,00Fh,060h
        defb 0FFh,000h,0C0h,016h,000h,0AAh,00Fh,050h
SPD_PL0_6:
        defb 0FFh,000h,0F0h,009h,000h,0A6h,003h,098h
        defb 0FFh,000h,0F0h,009h,000h,095h,003h,098h
        defb 0FFh,000h,0F0h,00Dh,000h,05Dh,003h,05Ch
        defb 0FFh,000h,0F0h,005h,000h,055h,003h,054h
        defb 0FFh,000h,0F0h,009h,000h,09Dh,003h,098h
        defb 0FFh,000h,0F0h,009h,000h,0A6h,003h,098h
        defb 0FFh,000h,0F0h,009h,000h,055h,003h,058h
        defb 0FFh,000h,0F0h,005h,000h,0AAh,003h,094h
SPD_PL0_7:
        defb 0FFh,000h,0FCh,002h,000h,069h,000h,0A6h
        defb 0FFh,000h,0FCh,002h,000h,065h,000h,066h
        defb 0FFh,000h,0FCh,003h,000h,057h,000h,057h
        defb 0FFh,000h,0FCh,001h,000h,055h,000h,055h
        defb 0FFh,000h,0FCh,002h,000h,067h,000h,066h
        defb 0FFh,000h,0FCh,002h,000h,069h,000h,0A6h
        defb 0FFh,000h,0FCh,002h,000h,055h,000h,056h
        defb 0FFh,000h,0FCh,001h,000h,06Ah,000h,0A5h
SPD_PL1_0:
        defb 0F0h,009h,003h,058h,0FFh,000h,0FFh,000h
        defb 0C0h,025h,000h,056h,0FFh,000h,0FFh,000h
        defb 0C0h,02Dh,000h,0DEh,0FFh,000h,0FFh,000h
        defb 0C0h,025h,000h,056h,0FFh,000h,0FFh,000h
        defb 0C0h,025h,000h,0D6h,0FFh,000h,0FFh,000h
        defb 0F0h,009h,003h,098h,0FFh,000h,0FFh,000h
        defb 0C0h,025h,000h,056h,0FFh,000h,0FFh,000h
        defb 0C0h,026h,000h,0A6h,0FFh,000h,0FFh,000h
SPD_PL1_2:
        defb 0FFh,000h,000h,095h,03Fh,080h,0FFh,000h
        defb 0FCh,002h,000h,055h,00Fh,060h,0FFh,000h
        defb 0FCh,002h,000h,0DDh,00Fh,0E0h,0FFh,000h
        defb 0FCh,002h,000h,055h,00Fh,060h,0FFh,000h
        defb 0FCh,002h,000h,05Dh,00Fh,060h,0FFh,000h
        defb 0FFh,000h,000h,099h,03Fh,080h,0FFh,000h
        defb 0FCh,002h,000h,055h,00Fh,060h,0FFh,000h
        defb 0FCh,002h,000h,06Ah,00Fh,060h,0FFh,000h
SPD_PL1_4:
        defb 0FFh,000h,0F0h,009h,003h,058h,0FFh,000h
        defb 0FFh,000h,0C0h,025h,000h,056h,0FFh,000h
        defb 0FFh,000h,0C0h,02Dh,000h,0DEh,0FFh,000h
        defb 0FFh,000h,0C0h,025h,000h,056h,0FFh,000h
        defb 0FFh,000h,0C0h,025h,000h,0D6h,0FFh,000h
        defb 0FFh,000h,0F0h,009h,003h,098h,0FFh,000h
        defb 0FFh,000h,0C0h,025h,000h,056h,0FFh,000h
        defb 0FFh,000h,0C0h,026h,000h,0A6h,0FFh,000h
SPD_PL1_6:
        defb 0FFh,000h,0FFh,000h,000h,095h,03Fh,080h
        defb 0FFh,000h,0FCh,002h,000h,055h,00Fh,060h
        defb 0FFh,000h,0FCh,002h,000h,0DDh,00Fh,0E0h
        defb 0FFh,000h,0FCh,002h,000h,055h,00Fh,060h
        defb 0FFh,000h,0FCh,002h,000h,05Dh,00Fh,060h
        defb 0FFh,000h,0FFh,000h,000h,099h,03Fh,080h
        defb 0FFh,000h,0FCh,002h,000h,055h,00Fh,060h
        defb 0FFh,000h,0FCh,002h,000h,06Ah,00Fh,060h
SPD_PL2_0:
        defb 0FCh,002h,00Fh,060h,0FFh,000h,0FFh,000h
        defb 0FCh,002h,00Fh,060h,0FFh,000h,0FFh,000h
        defb 0F0h,009h,003h,0D8h,0FFh,000h,0FFh,000h
        defb 0F0h,009h,003h,058h,0FFh,000h,0FFh,000h
        defb 0F0h,009h,003h,0D8h,0FFh,000h,0FFh,000h
        defb 0FCh,002h,00Fh,060h,0FFh,000h,0FFh,000h
        defb 0F0h,009h,003h,058h,0FFh,000h,0FFh,000h
        defb 0F0h,009h,003h,098h,0FFh,000h,0FFh,000h
SPD_PL2_2:
        defb 0FFh,000h,0C0h,026h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0C0h,026h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,000h,09Dh,03Fh,080h,0FFh,000h
        defb 0FFh,000h,000h,095h,03Fh,080h,0FFh,000h
        defb 0FFh,000h,000h,09Dh,03Fh,080h,0FFh,000h
        defb 0FFh,000h,0C0h,026h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,000h,095h,03Fh,080h,0FFh,000h
        defb 0FFh,000h,000h,099h,03Fh,080h,0FFh,000h
SPD_PL2_4:
        defb 0FFh,000h,0FCh,002h,00Fh,060h,0FFh,000h
        defb 0FFh,000h,0FCh,002h,00Fh,060h,0FFh,000h
        defb 0FFh,000h,0F0h,009h,003h,0D8h,0FFh,000h
        defb 0FFh,000h,0F0h,009h,003h,058h,0FFh,000h
        defb 0FFh,000h,0F0h,009h,003h,0D8h,0FFh,000h
        defb 0FFh,000h,0FCh,002h,00Fh,060h,0FFh,000h
        defb 0FFh,000h,0F0h,009h,003h,058h,0FFh,000h
        defb 0FFh,000h,0F0h,009h,003h,098h,0FFh,000h
SPD_PL2_6:
        defb 0FFh,000h,0FFh,000h,0C0h,026h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0C0h,026h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,000h,09Dh,03Fh,080h
        defb 0FFh,000h,0FFh,000h,000h,095h,03Fh,080h
        defb 0FFh,000h,0FFh,000h,000h,09Dh,03Fh,080h
        defb 0FFh,000h,0FFh,000h,0C0h,026h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,000h,095h,03Fh,080h
        defb 0FFh,000h,0FFh,000h,000h,099h,03Fh,080h
SPD_PLL_0:
        defb 0FCh,002h,000h,069h,03Fh,080h,0FFh,000h
        defb 0F0h,009h,000h,059h,03Fh,080h,0FFh,000h
        defb 0F0h,009h,000h,0D5h,03Fh,0C0h,0FFh,000h
        defb 0F0h,009h,000h,055h,03Fh,040h,0FFh,000h
        defb 0F0h,009h,000h,0D9h,03Fh,080h,0FFh,000h
        defb 0FCh,002h,000h,069h,03Fh,080h,0FFh,000h
        defb 0FCh,002h,000h,055h,03Fh,080h,0FFh,000h
        defb 0FFh,000h,000h,0A5h,03Fh,080h,0FFh,000h
SPD_PLL_1:
        defb 0FFh,000h,000h,09Ah,00Fh,060h,0FFh,000h
        defb 0FCh,002h,000h,056h,00Fh,060h,0FFh,000h
        defb 0FCh,002h,000h,075h,00Fh,070h,0FFh,000h
        defb 0FCh,002h,000h,055h,00Fh,050h,0FFh,000h
        defb 0FCh,002h,000h,076h,00Fh,060h,0FFh,000h
        defb 0FFh,000h,000h,09Ah,00Fh,060h,0FFh,000h
        defb 0FFh,000h,000h,095h,00Fh,060h,0FFh,000h
        defb 0FFh,000h,0C0h,029h,00Fh,060h,0FFh,000h
SPD_PLL_2:
        defb 0FFh,000h,0C0h,026h,003h,098h,0FFh,000h
        defb 0FFh,000h,000h,095h,003h,098h,0FFh,000h
        defb 0FFh,000h,000h,09Dh,003h,05Ch,0FFh,000h
        defb 0FFh,000h,000h,095h,003h,054h,0FFh,000h
        defb 0FFh,000h,000h,09Dh,003h,098h,0FFh,000h
        defb 0FFh,000h,0C0h,026h,003h,098h,0FFh,000h
        defb 0FFh,000h,0C0h,025h,003h,058h,0FFh,000h
        defb 0FFh,000h,0F0h,00Ah,003h,058h,0FFh,000h
SPD_PLL_3:
        defb 0FFh,000h,0F0h,009h,000h,0A6h,0FFh,000h
        defb 0FFh,000h,0C0h,025h,000h,066h,0FFh,000h
        defb 0FFh,000h,0C0h,027h,000h,057h,0FFh,000h
        defb 0FFh,000h,0C0h,025h,000h,055h,0FFh,000h
        defb 0FFh,000h,0C0h,027h,000h,066h,0FFh,000h
        defb 0FFh,000h,0F0h,009h,000h,0A6h,0FFh,000h
        defb 0FFh,000h,0F0h,009h,000h,056h,0FFh,000h
        defb 0FFh,000h,0FCh,002h,000h,096h,0FFh,000h
SPD_PLL_4:
        defb 0FFh,000h,0FCh,002h,000h,069h,03Fh,080h
        defb 0FFh,000h,0F0h,009h,000h,059h,03Fh,080h
        defb 0FFh,000h,0F0h,009h,000h,0D5h,03Fh,0C0h
        defb 0FFh,000h,0F0h,009h,000h,055h,03Fh,040h
        defb 0FFh,000h,0F0h,009h,000h,0D9h,03Fh,080h
        defb 0FFh,000h,0FCh,002h,000h,069h,03Fh,080h
        defb 0FFh,000h,0FCh,002h,000h,055h,03Fh,080h
        defb 0FFh,000h,0FFh,000h,000h,0A5h,03Fh,080h
SPD_PLL_5:
        defb 0FFh,000h,0FFh,000h,000h,09Ah,00Fh,060h
        defb 0FFh,000h,0FCh,002h,000h,056h,00Fh,060h
        defb 0FFh,000h,0FCh,002h,000h,075h,00Fh,070h
        defb 0FFh,000h,0FCh,002h,000h,055h,00Fh,050h
        defb 0FFh,000h,0FCh,002h,000h,076h,00Fh,060h
        defb 0FFh,000h,0FFh,000h,000h,09Ah,00Fh,060h
        defb 0FFh,000h,0FFh,000h,000h,095h,00Fh,060h
        defb 0FFh,000h,0FFh,000h,0C0h,029h,00Fh,060h
SPD_PLL_6:
        defb 0FFh,000h,0FFh,000h,0C0h,026h,003h,098h
        defb 0FFh,000h,0FFh,000h,000h,095h,003h,098h
        defb 0FFh,000h,0FFh,000h,000h,09Dh,003h,05Ch
        defb 0FFh,000h,0FFh,000h,000h,095h,003h,054h
        defb 0FFh,000h,0FFh,000h,000h,09Dh,003h,098h
        defb 0FFh,000h,0FFh,000h,0C0h,026h,003h,098h
        defb 0FFh,000h,0FFh,000h,0C0h,025h,003h,058h
        defb 0FFh,000h,0FFh,000h,0F0h,00Ah,003h,058h
SPD_PLL_7:
        defb 0FFh,000h,0FFh,000h,0F0h,009h,000h,0A6h
        defb 0FFh,000h,0FFh,000h,0C0h,025h,000h,066h
        defb 0FFh,000h,0FFh,000h,0C0h,027h,000h,057h
        defb 0FFh,000h,0FFh,000h,0C0h,025h,000h,055h
        defb 0FFh,000h,0FFh,000h,0C0h,027h,000h,066h
        defb 0FFh,000h,0FFh,000h,0F0h,009h,000h,0A6h
        defb 0FFh,000h,0FFh,000h,0F0h,009h,000h,056h
        defb 0FFh,000h,0FFh,000h,0FCh,002h,000h,096h
SPD_PLR_0:
        defb 000h,09Ah,00Fh,060h,0FFh,000h,0FFh,000h
        defb 000h,099h,003h,058h,0FFh,000h,0FFh,000h
        defb 000h,0D5h,003h,0D8h,0FFh,000h,0FFh,000h
        defb 000h,055h,003h,058h,0FFh,000h,0FFh,000h
        defb 000h,099h,003h,0D8h,0FFh,000h,0FFh,000h
        defb 000h,09Ah,00Fh,060h,0FFh,000h,0FFh,000h
        defb 000h,095h,00Fh,060h,0FFh,000h,0FFh,000h
        defb 000h,096h,03Fh,080h,0FFh,000h,0FFh,000h
SPD_PLR_1:
        defb 0C0h,026h,003h,098h,0FFh,000h,0FFh,000h
        defb 0C0h,026h,000h,056h,0FFh,000h,0FFh,000h
        defb 0C0h,035h,000h,076h,0FFh,000h,0FFh,000h
        defb 0C0h,015h,000h,056h,0FFh,000h,0FFh,000h
        defb 0C0h,026h,000h,076h,0FFh,000h,0FFh,000h
        defb 0C0h,026h,003h,098h,0FFh,000h,0FFh,000h
        defb 0C0h,025h,003h,058h,0FFh,000h,0FFh,000h
        defb 0C0h,025h,00Fh,0A0h,0FFh,000h,0FFh,000h
SPD_PLR_2:
        defb 0F0h,009h,000h,0A6h,0FFh,000h,0FFh,000h
        defb 0F0h,009h,000h,095h,03Fh,080h,0FFh,000h
        defb 0F0h,00Dh,000h,05Dh,03Fh,080h,0FFh,000h
        defb 0F0h,005h,000h,055h,03Fh,080h,0FFh,000h
        defb 0F0h,009h,000h,09Dh,03Fh,080h,0FFh,000h
        defb 0F0h,009h,000h,0A6h,0FFh,000h,0FFh,000h
        defb 0F0h,009h,000h,056h,0FFh,000h,0FFh,000h
        defb 0F0h,009h,003h,068h,0FFh,000h,0FFh,000h
SPD_PLR_3:
        defb 0FCh,002h,000h,069h,03Fh,080h,0FFh,000h
        defb 0FCh,002h,000h,065h,00Fh,060h,0FFh,000h
        defb 0FCh,003h,000h,057h,00Fh,060h,0FFh,000h
        defb 0FCh,001h,000h,055h,00Fh,060h,0FFh,000h
        defb 0FCh,002h,000h,067h,00Fh,060h,0FFh,000h
        defb 0FCh,002h,000h,069h,03Fh,080h,0FFh,000h
        defb 0FCh,002h,000h,055h,03Fh,080h,0FFh,000h
        defb 0FCh,002h,000h,05Ah,0FFh,000h,0FFh,000h
SPD_PLR_4:
        defb 0FFh,000h,000h,09Ah,00Fh,060h,0FFh,000h
        defb 0FFh,000h,000h,099h,003h,058h,0FFh,000h
        defb 0FFh,000h,000h,0D5h,003h,0D8h,0FFh,000h
        defb 0FFh,000h,000h,055h,003h,058h,0FFh,000h
        defb 0FFh,000h,000h,099h,003h,0D8h,0FFh,000h
        defb 0FFh,000h,000h,09Ah,00Fh,060h,0FFh,000h
        defb 0FFh,000h,000h,095h,00Fh,060h,0FFh,000h
        defb 0FFh,000h,000h,096h,03Fh,080h,0FFh,000h
SPD_PLR_5:
        defb 0FFh,000h,0C0h,026h,003h,098h,0FFh,000h
        defb 0FFh,000h,0C0h,026h,000h,056h,0FFh,000h
        defb 0FFh,000h,0C0h,035h,000h,076h,0FFh,000h
        defb 0FFh,000h,0C0h,015h,000h,056h,0FFh,000h
        defb 0FFh,000h,0C0h,026h,000h,076h,0FFh,000h
        defb 0FFh,000h,0C0h,026h,003h,098h,0FFh,000h
        defb 0FFh,000h,0C0h,025h,003h,058h,0FFh,000h
        defb 0FFh,000h,0C0h,025h,00Fh,0A0h,0FFh,000h
SPD_PLR_6:
        defb 0FFh,000h,0F0h,009h,000h,0A6h,0FFh,000h
        defb 0FFh,000h,0F0h,009h,000h,095h,03Fh,080h
        defb 0FFh,000h,0F0h,00Dh,000h,05Dh,03Fh,080h
        defb 0FFh,000h,0F0h,005h,000h,055h,03Fh,080h
        defb 0FFh,000h,0F0h,009h,000h,09Dh,03Fh,080h
        defb 0FFh,000h,0F0h,009h,000h,0A6h,0FFh,000h
        defb 0FFh,000h,0F0h,009h,000h,056h,0FFh,000h
        defb 0FFh,000h,0F0h,009h,003h,068h,0FFh,000h
SPD_PLR_7:
        defb 0FFh,000h,0FCh,002h,000h,069h,03Fh,080h
        defb 0FFh,000h,0FCh,002h,000h,065h,00Fh,060h
        defb 0FFh,000h,0FCh,003h,000h,057h,00Fh,060h
        defb 0FFh,000h,0FCh,001h,000h,055h,00Fh,060h
        defb 0FFh,000h,0FCh,002h,000h,067h,00Fh,060h
        defb 0FFh,000h,0FCh,002h,000h,069h,03Fh,080h
        defb 0FFh,000h,0FCh,002h,000h,055h,03Fh,080h
        defb 0FFh,000h,0FCh,002h,000h,05Ah,0FFh,000h
SPD_EN0_0:
        defb 0F0h,00Ah,003h,0E8h,0FFh,000h,0FFh,000h
        defb 0C0h,02Fh,000h,0FEh,0FFh,000h,0FFh,000h
        defb 000h,0AAh,000h,0EAh,03Fh,080h,0FFh,000h
        defb 000h,0FFh,000h,07Fh,03Fh,0C0h,0FFh,000h
        defb 000h,0BFh,000h,0FFh,03Fh,080h,0FFh,000h
        defb 0C0h,02Ah,000h,0EAh,0FFh,000h,0FFh,000h
        defb 0FCh,002h,00Fh,060h,0FFh,000h,0FFh,000h
SPD_EN0_2:
        defb 0FFh,000h,000h,0AEh,03Fh,080h,0FFh,000h
        defb 0FCh,002h,000h,0FFh,00Fh,0E0h,0FFh,000h
        defb 0F0h,00Ah,000h,0AEh,003h,0A8h,0FFh,000h
        defb 0F0h,00Fh,000h,0F7h,003h,0FCh,0FFh,000h
        defb 0F0h,00Bh,000h,0FFh,003h,0F8h,0FFh,000h
        defb 0FCh,002h,000h,0AEh,00Fh,0A0h,0FFh,000h
        defb 0FFh,000h,0C0h,026h,0FFh,000h,0FFh,000h
SPD_EN0_4:
        defb 0FFh,000h,0F0h,00Ah,003h,0E8h,0FFh,000h
        defb 0FFh,000h,0C0h,02Fh,000h,0FEh,0FFh,000h
        defb 0FFh,000h,000h,0AAh,000h,0EAh,03Fh,080h
        defb 0FFh,000h,000h,0FFh,000h,07Fh,03Fh,0C0h
        defb 0FFh,000h,000h,0BFh,000h,0FFh,03Fh,080h
        defb 0FFh,000h,0C0h,02Ah,000h,0EAh,0FFh,000h
        defb 0FFh,000h,0FCh,002h,00Fh,060h,0FFh,000h
SPD_EN0_6:
        defb 0FFh,000h,0FFh,000h,000h,0AEh,03Fh,080h
        defb 0FFh,000h,0FCh,002h,000h,0FFh,00Fh,0E0h
        defb 0FFh,000h,0F0h,00Ah,000h,0AEh,003h,0A8h
        defb 0FFh,000h,0F0h,00Fh,000h,0F7h,003h,0FCh
        defb 0FFh,000h,0F0h,00Bh,000h,0FFh,003h,0F8h
        defb 0FFh,000h,0FCh,002h,000h,0AEh,00Fh,0A0h
        defb 0FFh,000h,0FFh,000h,0C0h,026h,0FFh,000h
SPD_ENL_0:
        defb 0F0h,00Ah,003h,0E8h,0FFh,000h,0FFh,000h
        defb 0C0h,02Fh,000h,0FEh,0FFh,000h,0FFh,000h
        defb 000h,0AAh,000h,0EAh,0FFh,000h,0FFh,000h
        defb 000h,0FFh,000h,07Fh,03Fh,080h,0FFh,000h
        defb 000h,0AFh,000h,0FFh,03Fh,080h,0FFh,000h
        defb 0F0h,00Ah,000h,0EAh,0FFh,000h,0FFh,000h
        defb 0FCh,002h,00Fh,060h,0FFh,000h,0FFh,000h
SPD_ENL_2:
        defb 0FFh,000h,000h,0AEh,03Fh,080h,0FFh,000h
        defb 0FCh,002h,000h,0FFh,00Fh,0E0h,0FFh,000h
        defb 0F0h,00Ah,000h,0AEh,00Fh,0A0h,0FFh,000h
        defb 0F0h,00Fh,000h,0F7h,003h,0F8h,0FFh,000h
        defb 0F0h,00Ah,000h,0FFh,003h,0F8h,0FFh,000h
        defb 0FFh,000h,000h,0AEh,00Fh,0A0h,0FFh,000h
        defb 0FFh,000h,0C0h,026h,0FFh,000h,0FFh,000h
SPD_ENL_4:
        defb 0FFh,000h,0F0h,00Ah,003h,0E8h,0FFh,000h
        defb 0FFh,000h,0C0h,02Fh,000h,0FEh,0FFh,000h
        defb 0FFh,000h,000h,0AAh,000h,0EAh,0FFh,000h
        defb 0FFh,000h,000h,0FFh,000h,07Fh,03Fh,080h
        defb 0FFh,000h,000h,0AFh,000h,0FFh,03Fh,080h
        defb 0FFh,000h,0F0h,00Ah,000h,0EAh,0FFh,000h
        defb 0FFh,000h,0FCh,002h,00Fh,060h,0FFh,000h
SPD_ENL_6:
        defb 0FFh,000h,0FFh,000h,000h,0AEh,03Fh,080h
        defb 0FFh,000h,0FCh,002h,000h,0FFh,00Fh,0E0h
        defb 0FFh,000h,0F0h,00Ah,000h,0AEh,00Fh,0A0h
        defb 0FFh,000h,0F0h,00Fh,000h,0F7h,003h,0F8h
        defb 0FFh,000h,0F0h,00Ah,000h,0FFh,003h,0F8h
        defb 0FFh,000h,0FFh,000h,000h,0AEh,00Fh,0A0h
        defb 0FFh,000h,0FFh,000h,0C0h,026h,0FFh,000h
SPD_ENR_0:
        defb 0F0h,00Ah,003h,0E8h,0FFh,000h,0FFh,000h
        defb 0C0h,02Fh,000h,0FEh,0FFh,000h,0FFh,000h
        defb 0C0h,02Ah,000h,0EAh,03Fh,080h,0FFh,000h
        defb 000h,0BFh,000h,07Fh,03Fh,0C0h,0FFh,000h
        defb 000h,0BFh,000h,0FEh,03Fh,080h,0FFh,000h
        defb 0C0h,02Ah,003h,0E8h,0FFh,000h,0FFh,000h
        defb 0FCh,002h,00Fh,060h,0FFh,000h,0FFh,000h
SPD_ENR_2:
        defb 0FFh,000h,000h,0AEh,03Fh,080h,0FFh,000h
        defb 0FCh,002h,000h,0FFh,00Fh,0E0h,0FFh,000h
        defb 0FCh,002h,000h,0AEh,003h,0A8h,0FFh,000h
        defb 0F0h,00Bh,000h,0F7h,003h,0FCh,0FFh,000h
        defb 0F0h,00Bh,000h,0FFh,003h,0E8h,0FFh,000h
        defb 0FCh,002h,000h,0AEh,03Fh,080h,0FFh,000h
        defb 0FFh,000h,0C0h,026h,0FFh,000h,0FFh,000h
SPD_ENR_4:
        defb 0FFh,000h,0F0h,00Ah,003h,0E8h,0FFh,000h
        defb 0FFh,000h,0C0h,02Fh,000h,0FEh,0FFh,000h
        defb 0FFh,000h,0C0h,02Ah,000h,0EAh,03Fh,080h
        defb 0FFh,000h,000h,0BFh,000h,07Fh,03Fh,0C0h
        defb 0FFh,000h,000h,0BFh,000h,0FEh,03Fh,080h
        defb 0FFh,000h,0C0h,02Ah,003h,0E8h,0FFh,000h
        defb 0FFh,000h,0FCh,002h,00Fh,060h,0FFh,000h
SPD_ENR_6:
        defb 0FFh,000h,0FFh,000h,000h,0AEh,03Fh,080h
        defb 0FFh,000h,0FCh,002h,000h,0FFh,00Fh,0E0h
        defb 0FFh,000h,0FCh,002h,000h,0AEh,003h,0A8h
        defb 0FFh,000h,0F0h,00Bh,000h,0F7h,003h,0FCh
        defb 0FFh,000h,0F0h,00Bh,000h,0FFh,003h,0E8h
        defb 0FFh,000h,0FCh,002h,000h,0AEh,03Fh,080h
        defb 0FFh,000h,0FFh,000h,0C0h,026h,0FFh,000h
SPD_EX0_0:
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 0FCh,001h,0CFh,030h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,03Fh,040h,0FFh,000h,0FFh,000h
        defb 0FCh,003h,0CFh,010h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
SPD_EX0_2:
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0CCh,013h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0F3h,004h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0CCh,031h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
SPD_EX0_4:
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0FCh,001h,0CFh,030h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,03Fh,040h,0FFh,000h
        defb 0FFh,000h,0FCh,003h,0CFh,010h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
SPD_EX0_6:
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0CCh,013h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0F3h,004h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0CCh,031h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
SPD_EX1_0:
        defb 0F3h,00Ch,0F3h,004h,0FFh,000h,0FFh,000h
        defb 0FCh,001h,00Fh,0D0h,0FFh,000h,0FFh,000h
        defb 0C0h,01Dh,003h,05Ch,0FFh,000h,0FFh,000h
        defb 0F0h,00Dh,00Fh,0D0h,0FFh,000h,0FFh,000h
        defb 0FCh,001h,0CFh,030h,0FFh,000h,0FFh,000h
        defb 0F3h,00Ch,0F3h,004h,0FFh,000h,0FFh,000h
SPD_EX1_2:
        defb 0FFh,000h,03Fh,0C0h,03Fh,040h,0FFh,000h
        defb 0FFh,000h,0C0h,01Dh,0FFh,000h,0FFh,000h
        defb 0FCh,001h,000h,0D5h,03Fh,0C0h,0FFh,000h
        defb 0FFh,000h,000h,0DDh,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0CCh,013h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,03Fh,0C0h,03Fh,040h,0FFh,000h
SPD_EX1_4:
        defb 0FFh,000h,0F3h,00Ch,0F3h,004h,0FFh,000h
        defb 0FFh,000h,0FCh,001h,00Fh,0D0h,0FFh,000h
        defb 0FFh,000h,0C0h,01Dh,003h,05Ch,0FFh,000h
        defb 0FFh,000h,0F0h,00Dh,00Fh,0D0h,0FFh,000h
        defb 0FFh,000h,0FCh,001h,0CFh,030h,0FFh,000h
        defb 0FFh,000h,0F3h,00Ch,0F3h,004h,0FFh,000h
SPD_EX1_6:
        defb 0FFh,000h,0FFh,000h,03Fh,0C0h,03Fh,040h
        defb 0FFh,000h,0FFh,000h,0C0h,01Dh,0FFh,000h
        defb 0FFh,000h,0FCh,001h,000h,0D5h,03Fh,0C0h
        defb 0FFh,000h,0FFh,000h,000h,0DDh,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0CCh,013h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,03Fh,0C0h,03Fh,040h
SPD_EX2_0:
        defb 0CFh,010h,0FCh,003h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,03Fh,040h,0FFh,000h,0FFh,000h
        defb 03Fh,0C0h,0FFh,000h,03Fh,040h,0FFh,000h
        defb 0FCh,003h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 0CFh,010h,0FCh,001h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,03Fh,0C0h,0FFh,000h,0FFh,000h
SPD_EX2_2:
        defb 0FCh,001h,0FFh,000h,0CFh,030h,0FFh,000h
        defb 0FFh,000h,0F3h,004h,0FFh,000h,0FFh,000h
        defb 0F3h,00Ch,0FFh,000h,0F3h,004h,0FFh,000h
        defb 0FFh,000h,0CFh,030h,0FFh,000h,0FFh,000h
        defb 0FCh,001h,0FFh,000h,0CFh,010h,0FFh,000h
        defb 0FFh,000h,0F3h,00Ch,0FFh,000h,0FFh,000h
SPD_EX2_4:
        defb 0FFh,000h,0CFh,010h,0FCh,003h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,03Fh,040h,0FFh,000h
        defb 0FFh,000h,03Fh,0C0h,0FFh,000h,03Fh,040h
        defb 0FFh,000h,0FCh,003h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0CFh,010h,0FCh,001h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,03Fh,0C0h,0FFh,000h
SPD_EX2_6:
        defb 0FFh,000h,0FCh,001h,0FFh,000h,0CFh,030h
        defb 0FFh,000h,0FFh,000h,0F3h,004h,0FFh,000h
        defb 0FFh,000h,0F3h,00Ch,0FFh,000h,0F3h,004h
        defb 0FFh,000h,0FFh,000h,0CFh,030h,0FFh,000h
        defb 0FFh,000h,0FCh,001h,0FFh,000h,0CFh,010h
        defb 0FFh,000h,0FFh,000h,0F3h,00Ch,0FFh,000h
SPD_PB_0:
        defb 0CFh,030h,0FCh,003h,0FFh,000h,0FFh,000h
        defb 0CFh,030h,0FCh,003h,0FFh,000h,0FFh,000h
SPD_PB_2:
        defb 0FCh,003h,0FFh,000h,0CFh,030h,0FFh,000h
        defb 0FCh,003h,0FFh,000h,0CFh,030h,0FFh,000h
SPD_PB_4:
        defb 0FFh,000h,0CFh,030h,0FCh,003h,0FFh,000h
        defb 0FFh,000h,0CFh,030h,0FCh,003h,0FFh,000h
SPD_PB_6:
        defb 0FFh,000h,0FCh,003h,0FFh,000h,0CFh,030h
        defb 0FFh,000h,0FCh,003h,0FFh,000h,0CFh,030h
SPD_EB_0:
        defb 0FFh,000h,00Fh,070h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,00Fh,0D0h,0FFh,000h,0FFh,000h
SPD_EB_2:
        defb 0FFh,000h,0F0h,007h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0F0h,00Dh,0FFh,000h,0FFh,000h
SPD_EB_4:
        defb 0FFh,000h,0FFh,000h,00Fh,070h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,00Fh,0D0h,0FFh,000h
SPD_EB_6:
        defb 0FFh,000h,0FFh,000h,0F0h,007h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0F0h,00Dh,0FFh,000h
SPD_BS0_0:
        defb 0FFh,000h,0FFh,000h,03Fh,080h,0FFh,000h
        defb 0FFh,000h,0FCh,002h,03Fh,0C0h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,03Fh,080h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 0FCh,002h,000h,0AAh,03Fh,080h,0FFh,000h
        defb 0C0h,02Bh,000h,0FFh,03Fh,0C0h,0FFh,000h
        defb 000h,09Fh,000h,07Fh,03Fh,040h,0FFh,000h
        defb 000h,0BFh,000h,07Fh,03Fh,040h,0FFh,000h
SPD_BS0_2:
        defb 0FFh,000h,0FFh,000h,0F3h,008h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0C3h,02Ch,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0F3h,008h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0C0h,02Ah,003h,0A8h,0FFh,000h
        defb 0FCh,002h,000h,0BFh,003h,0FCh,0FFh,000h
        defb 0F0h,009h,000h,0F7h,003h,0F4h,0FFh,000h
        defb 0F0h,00Bh,000h,0F7h,003h,0F4h,0FFh,000h
SPD_BS0_4:
        defb 0FFh,000h,0FFh,000h,0FFh,000h,03Fh,080h
        defb 0FFh,000h,0FFh,000h,0FCh,002h,03Fh,0C0h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,03Fh,080h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0FCh,002h,000h,0AAh,03Fh,080h
        defb 0FFh,000h,0C0h,02Bh,000h,0FFh,03Fh,0C0h
        defb 0FFh,000h,000h,09Fh,000h,07Fh,03Fh,040h
        defb 0FFh,000h,000h,0BFh,000h,07Fh,03Fh,040h
SPD_BS0_6:
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0F3h,008h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0C3h,02Ch
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0F3h,008h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0C0h,02Ah,003h,0A8h
        defb 0FFh,000h,0FCh,002h,000h,0BFh,003h,0FCh
        defb 0FFh,000h,0F0h,009h,000h,0F7h,003h,0F4h
        defb 0FFh,000h,0F0h,00Bh,000h,0F7h,003h,0F4h
SPD_BS1_0:
        defb 000h,0ABh,000h,0FAh,03Fh,080h,0FFh,000h
        defb 000h,0FFh,000h,0FFh,03Fh,0C0h,0FFh,000h
        defb 000h,0FFh,000h,0FFh,03Fh,0C0h,0FFh,000h
        defb 000h,0AFh,000h,07Eh,03Fh,080h,0FFh,000h
        defb 000h,0AFh,000h,0FEh,03Fh,080h,0FFh,000h
        defb 000h,0FFh,000h,0FFh,03Fh,0C0h,0FFh,000h
        defb 000h,0FFh,000h,0FFh,03Fh,0C0h,0FFh,000h
        defb 000h,0FFh,000h,0FFh,03Fh,0C0h,0FFh,000h
SPD_BS1_2:
        defb 0F0h,00Ah,000h,0BFh,003h,0A8h,0FFh,000h
        defb 0F0h,00Fh,000h,0FFh,003h,0FCh,0FFh,000h
        defb 0F0h,00Fh,000h,0FFh,003h,0FCh,0FFh,000h
        defb 0F0h,00Ah,000h,0F7h,003h,0E8h,0FFh,000h
        defb 0F0h,00Ah,000h,0FFh,003h,0E8h,0FFh,000h
        defb 0F0h,00Fh,000h,0FFh,003h,0FCh,0FFh,000h
        defb 0F0h,00Fh,000h,0FFh,003h,0FCh,0FFh,000h
        defb 0F0h,00Fh,000h,0FFh,003h,0FCh,0FFh,000h
SPD_BS1_4:
        defb 0FFh,000h,000h,0ABh,000h,0FAh,03Fh,080h
        defb 0FFh,000h,000h,0FFh,000h,0FFh,03Fh,0C0h
        defb 0FFh,000h,000h,0FFh,000h,0FFh,03Fh,0C0h
        defb 0FFh,000h,000h,0AFh,000h,07Eh,03Fh,080h
        defb 0FFh,000h,000h,0AFh,000h,0FEh,03Fh,080h
        defb 0FFh,000h,000h,0FFh,000h,0FFh,03Fh,0C0h
        defb 0FFh,000h,000h,0FFh,000h,0FFh,03Fh,0C0h
        defb 0FFh,000h,000h,0FFh,000h,0FFh,03Fh,0C0h
SPD_BS1_6:
        defb 0FFh,000h,0F0h,00Ah,000h,0BFh,003h,0A8h
        defb 0FFh,000h,0F0h,00Fh,000h,0FFh,003h,0FCh
        defb 0FFh,000h,0F0h,00Fh,000h,0FFh,003h,0FCh
        defb 0FFh,000h,0F0h,00Ah,000h,0F7h,003h,0E8h
        defb 0FFh,000h,0F0h,00Ah,000h,0FFh,003h,0E8h
        defb 0FFh,000h,0F0h,00Fh,000h,0FFh,003h,0FCh
        defb 0FFh,000h,0F0h,00Fh,000h,0FFh,003h,0FCh
        defb 0FFh,000h,0F0h,00Fh,000h,0FFh,003h,0FCh
SPD_BS2_0:
        defb 03Fh,080h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 00Fh,0E0h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 03Fh,080h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 000h,0AAh,00Fh,0A0h,0FFh,000h,0FFh,000h
        defb 000h,0FFh,000h,0FAh,0FFh,000h,0FFh,000h
        defb 000h,07Fh,000h,07Dh,03Fh,080h,0FFh,000h
        defb 000h,07Fh,000h,07Fh,03Fh,080h,0FFh,000h
SPD_BS2_2:
        defb 0F3h,008h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 0F0h,00Eh,0FFh,000h,0FFh,000h,0FFh,000h
        defb 0F3h,008h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 0F0h,00Ah,000h,0AAh,0FFh,000h,0FFh,000h
        defb 0F0h,00Fh,000h,0FFh,00Fh,0A0h,0FFh,000h
        defb 0F0h,007h,000h,0F7h,003h,0D8h,0FFh,000h
        defb 0F0h,007h,000h,0F7h,003h,0F8h,0FFh,000h
SPD_BS2_4:
        defb 0FFh,000h,03Fh,080h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,00Fh,0E0h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,03Fh,080h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,000h,0AAh,00Fh,0A0h,0FFh,000h
        defb 0FFh,000h,000h,0FFh,000h,0FAh,0FFh,000h
        defb 0FFh,000h,000h,07Fh,000h,07Dh,03Fh,080h
        defb 0FFh,000h,000h,07Fh,000h,07Fh,03Fh,080h
SPD_BS2_6:
        defb 0FFh,000h,0F3h,008h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0F0h,00Eh,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0F3h,008h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0F0h,00Ah,000h,0AAh,0FFh,000h
        defb 0FFh,000h,0F0h,00Fh,000h,0FFh,00Fh,0A0h
        defb 0FFh,000h,0F0h,007h,000h,0F7h,003h,0D8h
        defb 0FFh,000h,0F0h,007h,000h,0F7h,003h,0F8h
SPD_BS3_0:
        defb 0C0h,02Fh,000h,0FFh,03Fh,0C0h,0FFh,000h
        defb 0F0h,00Ah,000h,0FFh,03Fh,0C0h,0FFh,000h
        defb 0FCh,002h,000h,0EAh,03Fh,0C0h,0FFh,000h
        defb 0FCh,002h,00Ch,0E2h,03Fh,0C0h,0FFh,000h
        defb 0FCh,002h,00Ch,062h,03Fh,040h,0FFh,000h
        defb 0FFh,000h,03Fh,080h,03Fh,080h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
SPD_BS3_2:
        defb 0FCh,002h,000h,0FFh,003h,0FCh,0FFh,000h
        defb 0FFh,000h,000h,0AFh,003h,0FCh,0FFh,000h
        defb 0FFh,000h,0C0h,02Eh,003h,0ACh,0FFh,000h
        defb 0FFh,000h,0C0h,02Eh,0C3h,02Ch,0FFh,000h
        defb 0FFh,000h,0C0h,026h,0C3h,024h,0FFh,000h
        defb 0FFh,000h,0F3h,008h,0F3h,008h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
SPD_BS3_4:
        defb 0FFh,000h,0C0h,02Fh,000h,0FFh,03Fh,0C0h
        defb 0FFh,000h,0F0h,00Ah,000h,0FFh,03Fh,0C0h
        defb 0FFh,000h,0FCh,002h,000h,0EAh,03Fh,0C0h
        defb 0FFh,000h,0FCh,002h,00Ch,0E2h,03Fh,0C0h
        defb 0FFh,000h,0FCh,002h,00Ch,062h,03Fh,040h
        defb 0FFh,000h,0FFh,000h,03Fh,080h,03Fh,080h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
SPD_BS3_6:
        defb 0FFh,000h,0FCh,002h,000h,0FFh,003h,0FCh
        defb 0FFh,000h,0FFh,000h,000h,0AFh,003h,0FCh
        defb 0FFh,000h,0FFh,000h,0C0h,02Eh,003h,0ACh
        defb 0FFh,000h,0FFh,000h,0C0h,02Eh,0C3h,02Ch
        defb 0FFh,000h,0FFh,000h,0C0h,026h,0C3h,024h
        defb 0FFh,000h,0FFh,000h,0F3h,008h,0F3h,008h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
SPD_BS4_0:
        defb 000h,0FFh,000h,0FFh,03Fh,0C0h,0FFh,000h
        defb 000h,0FFh,000h,0FFh,03Fh,0C0h,0FFh,000h
        defb 000h,0AFh,000h,0FEh,03Fh,080h,0FFh,000h
        defb 000h,0AFh,000h,0FEh,03Fh,080h,0FFh,000h
        defb 000h,0AFh,000h,07Eh,03Fh,080h,0FFh,000h
        defb 0C0h,02Fh,000h,07Eh,0FFh,000h,0FFh,000h
        defb 0F0h,00Bh,003h,0F8h,0FFh,000h,0FFh,000h
        defb 0F0h,00Bh,003h,0F8h,0FFh,000h,0FFh,000h
SPD_BS4_2:
        defb 0F0h,00Fh,000h,0FFh,003h,0FCh,0FFh,000h
        defb 0F0h,00Fh,000h,0FFh,003h,0FCh,0FFh,000h
        defb 0F0h,00Ah,000h,0FFh,003h,0E8h,0FFh,000h
        defb 0F0h,00Ah,000h,0FFh,003h,0E8h,0FFh,000h
        defb 0F0h,00Ah,000h,0F7h,003h,0E8h,0FFh,000h
        defb 0FCh,002h,000h,0F7h,00Fh,0E0h,0FFh,000h
        defb 0FFh,000h,000h,0BFh,03Fh,080h,0FFh,000h
        defb 0FFh,000h,000h,0BFh,03Fh,080h,0FFh,000h
SPD_BS4_4:
        defb 0FFh,000h,000h,0FFh,000h,0FFh,03Fh,0C0h
        defb 0FFh,000h,000h,0FFh,000h,0FFh,03Fh,0C0h
        defb 0FFh,000h,000h,0AFh,000h,0FEh,03Fh,080h
        defb 0FFh,000h,000h,0AFh,000h,0FEh,03Fh,080h
        defb 0FFh,000h,000h,0AFh,000h,07Eh,03Fh,080h
        defb 0FFh,000h,0C0h,02Fh,000h,07Eh,0FFh,000h
        defb 0FFh,000h,0F0h,00Bh,003h,0F8h,0FFh,000h
        defb 0FFh,000h,0F0h,00Bh,003h,0F8h,0FFh,000h
SPD_BS4_6:
        defb 0FFh,000h,0F0h,00Fh,000h,0FFh,003h,0FCh
        defb 0FFh,000h,0F0h,00Fh,000h,0FFh,003h,0FCh
        defb 0FFh,000h,0F0h,00Ah,000h,0FFh,003h,0E8h
        defb 0FFh,000h,0F0h,00Ah,000h,0FFh,003h,0E8h
        defb 0FFh,000h,0F0h,00Ah,000h,0F7h,003h,0E8h
        defb 0FFh,000h,0FCh,002h,000h,0F7h,00Fh,0E0h
        defb 0FFh,000h,0FFh,000h,000h,0BFh,03Fh,080h
        defb 0FFh,000h,0FFh,000h,000h,0BFh,03Fh,080h
SPD_BS5_0:
        defb 000h,0FFh,000h,0FEh,0FFh,000h,0FFh,000h
        defb 000h,0FFh,003h,0E8h,0FFh,000h,0FFh,000h
        defb 000h,0EAh,00Fh,0E0h,0FFh,000h,0FFh,000h
        defb 00Ch,0E2h,00Fh,0E0h,0FFh,000h,0FFh,000h
        defb 00Ch,062h,00Fh,060h,0FFh,000h,0FFh,000h
        defb 03Fh,080h,03Fh,080h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
SPD_BS5_2:
        defb 0F0h,00Fh,000h,0FFh,00Fh,0E0h,0FFh,000h
        defb 0F0h,00Fh,000h,0FEh,03Fh,080h,0FFh,000h
        defb 0F0h,00Eh,000h,0AEh,0FFh,000h,0FFh,000h
        defb 0F0h,00Eh,0C0h,02Eh,0FFh,000h,0FFh,000h
        defb 0F0h,006h,0C0h,026h,0FFh,000h,0FFh,000h
        defb 0F3h,008h,0F3h,008h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
SPD_BS5_4:
        defb 0FFh,000h,000h,0FFh,000h,0FEh,0FFh,000h
        defb 0FFh,000h,000h,0FFh,003h,0E8h,0FFh,000h
        defb 0FFh,000h,000h,0EAh,00Fh,0E0h,0FFh,000h
        defb 0FFh,000h,00Ch,0E2h,00Fh,0E0h,0FFh,000h
        defb 0FFh,000h,00Ch,062h,00Fh,060h,0FFh,000h
        defb 0FFh,000h,03Fh,080h,03Fh,080h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
SPD_BS5_6:
        defb 0FFh,000h,0F0h,00Fh,000h,0FFh,00Fh,0E0h
        defb 0FFh,000h,0F0h,00Fh,000h,0FEh,03Fh,080h
        defb 0FFh,000h,0F0h,00Eh,000h,0AEh,0FFh,000h
        defb 0FFh,000h,0F0h,00Eh,0C0h,02Eh,0FFh,000h
        defb 0FFh,000h,0F0h,006h,0C0h,026h,0FFh,000h
        defb 0FFh,000h,0F3h,008h,0F3h,008h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
        defb 0FFh,000h,0FFh,000h,0FFh,000h,0FFh,000h
MAPDATA:
        defb 0AAh,0AAh,01Ah,0AAh,000h,000h,000h,000h,000h,000h,000h,000h,055h,000h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,05Ah,0AAh,004h,004h,004h,004h,004h,004h,004h,004h,044h,004h,0AAh,0A5h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,01Ah,0AAh,000h,000h,000h,000h,000h,000h,000h,000h,000h,000h,0AAh,091h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,06Ah,0AAh,040h,040h,040h,040h,040h,040h,040h,040h,040h,040h,0A9h,040h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,000h,011h,000h,000h,000h,000h,000h,000h,000h,000h,0A9h,000h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,004h,056h,004h,004h,004h,004h,004h,004h,004h,004h,0A4h,004h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,001h,0AAh,000h,000h,000h,000h,000h,000h,000h,000h,0A5h,000h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,045h,0AAh,040h,040h,040h,040h,040h,040h,040h,040h,0A4h,040h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,016h,0AAh,000h,000h,000h,000h,000h,000h,000h,000h,0A5h,000h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,05Ah,0AAh,004h,004h,004h,004h,004h,004h,004h,004h,0A4h,004h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,01Ah,0AAh,000h,000h,000h,000h,000h,000h,000h,000h,0A5h,000h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,040h,040h,040h,040h,040h,040h,040h,040h,0A9h,040h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,000h,001h,000h,000h,000h,000h,000h,000h,0A9h,000h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,004h,004h,004h,004h,004h,004h,004h,004h,0AAh,044h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,01Ah,0AAh,000h,000h,000h,000h,000h,000h,000h,000h,0AAh,095h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,05Ah,0AAh,040h,040h,040h,040h,040h,040h,040h,040h,0AAh,0A9h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,01Ah,0AAh,000h,000h,000h,000h,000h,000h,091h,000h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,006h,0AAh,004h,004h,004h,004h,004h,004h,0A5h,044h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,016h,0AAh,000h,000h,000h,000h,000h,000h,0AAh,050h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,046h,0AAh,040h,040h,040h,040h,040h,040h,0AAh,040h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,016h,0AAh,000h,000h,000h,000h,000h,000h,0AAh,050h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,006h,0AAh,004h,004h,004h,004h,004h,004h,0AAh,044h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,016h,0AAh,000h,000h,000h,000h,000h,000h,0AAh,050h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,046h,0AAh,040h,040h,040h,040h,040h,040h,0AAh,094h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,016h,0AAh,000h,000h,000h,000h,000h,000h,0AAh,0A5h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,05Ah,0AAh,004h,004h,004h,004h,004h,004h,0AAh,0A4h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,000h,001h,000h,000h,000h,000h,0AAh,0A9h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,044h,045h,040h,040h,040h,040h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,015h,05Ah,000h,000h,050h,000h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,05Ah,0AAh,004h,004h,044h,004h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,000h,001h,000h,000h,0AAh,0A9h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,040h,045h,040h,040h,0AAh,0A9h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,000h,001h,000h,000h,0AAh,0A9h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,095h,06Ah,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,004h,006h,044h,004h,0AAh,0A9h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,044h,05Ah,0AAh,0AAh
        defb 055h,0AAh,0AAh,0A9h,0AAh,0AAh,0AAh,0AAh,001h,016h,000h,000h,0AAh,0A9h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,050h,016h,0AAh,0AAh
        defb 044h,05Ah,0AAh,094h,0AAh,0AAh,0AAh,0AAh,045h,06Ah,040h,040h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,069h,0AAh,040h,045h,0AAh,0A9h
        defb 000h,015h,0AAh,050h,0AAh,0AAh,0AAh,0AAh,05Ah,0AAh,051h,011h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,015h,056h,000h,001h,0AAh,0A9h
        defb 004h,004h,0AAh,044h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0A5h,056h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,004h,045h,044h,004h,0AAh,0A9h
        defb 000h,000h,0AAh,050h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,000h,001h,000h,000h,0AAh,0A9h
        defb 040h,040h,0AAh,094h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,040h,040h,040h,040h,09Ah,0A4h
        defb 000h,001h,0AAh,0A5h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,000h,001h,000h,000h,055h,050h
        defb 004h,005h,0AAh,0A4h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,004h,004h,004h,004h,044h,044h
        defb 000h,016h,0AAh,0A5h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,000h,001h,000h,000h,000h,000h
        defb 040h,05Ah,0AAh,0A4h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,040h,040h,040h,040h,040h,040h
        defb 000h,01Ah,0AAh,0A5h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,000h,001h,000h,000h,000h,000h
        defb 044h,05Ah,0AAh,0A4h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,004h,004h,004h,004h,004h,004h
        defb 055h,06Ah,0AAh,0A9h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,000h,001h,000h,000h,000h,000h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,040h,045h,040h,040h,040h,040h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,000h,016h,000h,000h,000h,000h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,004h,006h,004h,004h,004h,004h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,000h,01Ah,000h,000h,000h,000h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,040h,05Ah,040h,040h,040h,040h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,001h,06Ah,000h,000h,000h,000h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,004h,06Ah,004h,004h,004h,004h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0A5h,055h,0AAh,0AAh,001h,06Ah,000h,000h,000h,000h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,05Ah,0AAh,054h,044h,0AAh,0AAh,040h,06Ah,040h,040h,040h,040h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,01Ah,0AAh,010h,000h,0AAh,0A9h,001h,06Ah,000h,000h,000h,000h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,05Ah,0AAh,044h,004h,0AAh,0A9h,005h,0AAh,004h,004h,004h,004h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,000h,001h,0AAh,0A9h,001h,0AAh,000h,000h,000h,000h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,040h,045h,0AAh,0AAh,045h,0AAh,040h,040h,040h,040h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,090h,001h,0AAh,0AAh,016h,0AAh,000h,000h,000h,000h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,05Ah,0AAh,0AAh,094h,005h,0AAh,0AAh,05Ah,0AAh,004h,004h,004h,004h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0A9h,016h,0AAh,0AAh,0A5h,015h,0AAh,0AAh,06Ah,0AAh,011h,011h,011h,011h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,054h,046h,0AAh,095h,0A5h,05Ah,0AAh,0AAh,0AAh,0AAh,055h,055h,055h,055h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,010h,016h,0AAh,091h,0AAh,0AAh,0AAh,0AAh,055h,06Ah,0AAh,0A5h,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,004h,005h,0AAh,044h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,000h,001h,0AAh,050h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,040h,045h,0AAh,040h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,000h,001h,0AAh,050h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,044h,006h,0AAh,094h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,055h,016h,0AAh,0A5h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0A9h,056h,0AAh,0AAh,0AAh,0AAh,055h,06Ah,0A9h,055h,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,011h,016h,055h,011h,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,004h,005h,044h,004h,0AAh,0A9h,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,056h,0AAh,000h,001h,000h,000h,0AAh,0A5h,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0A9h,06Ah,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,045h,05Ah,040h,040h,040h,040h,0AAh,0A4h,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,095h,015h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,001h,015h,000h,000h,000h,000h,0AAh,0A5h,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,05Ah,0AAh,094h,004h,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,004h,004h,004h,004h,004h,004h,0AAh,0A4h,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,016h,0AAh,090h,000h,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,000h,001h,000h,000h,000h,000h,0AAh,0A5h,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,046h,0AAh,094h,040h,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,040h,040h,040h,040h,040h,040h,0AAh,0A9h,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,001h,0AAh,090h,000h,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,000h,001h,000h,000h,050h,000h,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,004h,06Ah,094h,004h,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,004h,004h,004h,004h,044h,004h,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,000h,01Ah,090h,000h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,000h,001h,000h,000h,090h,000h,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,040h,05Ah,040h,040h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,040h,046h,040h,040h,0A4h,040h,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,000h,016h,050h,000h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,001h,01Ah,000h,000h,0A5h,000h,0A9h,05Ah,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,004h,006h,044h,004h,0AAh,0A9h,0AAh,0AAh,0AAh,0AAh,005h,06Ah,004h,004h,054h,004h,054h,045h,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,001h,016h,000h,000h,0AAh,0A9h,0AAh,0AAh,0AAh,0AAh,016h,0AAh,000h,000h,010h,000h,010h,001h,0AAh,0A9h
        defb 0AAh,0AAh,0AAh,0AAh,045h,05Ah,040h,040h,0AAh,0A9h,0AAh,0AAh,0AAh,0AAh,05Ah,0AAh,040h,040h,040h,040h,040h,040h,0AAh,0A9h
        defb 0AAh,0AAh,0AAh,0AAh,05Ah,0AAh,050h,001h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,01Ah,0AAh,000h,000h,000h,000h,000h,000h,0AAh,0A5h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0A4h,045h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,005h,0AAh,004h,004h,004h,004h,004h,004h,0AAh,0A4h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0A9h,056h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,001h,06Ah,000h,000h,000h,000h,000h,000h,0AAh,0A5h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,040h,05Ah,040h,040h,040h,040h,040h,040h,0AAh,0A4h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,000h,015h,000h,000h,000h,000h,000h,000h,0AAh,0A5h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,004h,005h,004h,004h,004h,004h,044h,004h,0AAh,0A9h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,000h,001h,000h,000h,000h,000h,000h,000h,0AAh,0A9h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,040h,040h,040h,040h,040h,040h,040h,040h,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,01Ah,0AAh,000h,000h,000h,000h,000h,000h,050h,000h,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,05Ah,0AAh,004h,004h,004h,004h,004h,004h,094h,004h,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,000h,001h,000h,000h,000h,000h,090h,000h,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,040h,040h,040h,040h,040h,040h,0A4h,040h,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,000h,001h,000h,000h,000h,000h,0A5h,000h,0AAh,0AAh
        defb 055h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,004h,046h,004h,004h,004h,004h,0A4h,004h,0AAh,0AAh
        defb 011h,05Ah,0AAh,0A5h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,001h,05Ah,000h,000h,000h,000h,0A5h,000h,0AAh,0AAh
        defb 040h,046h,0AAh,054h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,045h,0AAh,040h,040h,040h,040h,054h,040h,0AAh,0AAh
        defb 000h,016h,0A9h,010h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,05Ah,0AAh,000h,001h,000h,000h,010h,000h,0AAh,0A9h
        defb 004h,005h,094h,004h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,004h,005h,004h,004h,004h,004h,0AAh,0A4h
        defb 000h,001h,050h,000h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,000h,016h,000h,000h,000h,000h,0AAh,0A5h
        defb 040h,040h,040h,040h,0AAh,0A9h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,040h,046h,040h,040h,040h,040h,0AAh,0A4h
        defb 000h,000h,000h,000h,0AAh,0A5h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,000h,01Ah,000h,000h,000h,000h,0AAh,0A9h
        defb 004h,004h,004h,004h,0AAh,0A4h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,004h,05Ah,004h,004h,044h,004h,0AAh,0A9h
        defb 000h,000h,000h,000h,0AAh,090h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,000h,01Ah,000h,000h,000h,000h,0AAh,0A9h
        defb 040h,040h,040h,040h,0AAh,094h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,040h,05Ah,040h,040h,040h,040h,0AAh,0A9h
        defb 000h,000h,000h,000h,0AAh,090h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,001h,06Ah,000h,000h,000h,000h,0AAh,0A5h
        defb 004h,004h,004h,004h,0AAh,094h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,005h,0AAh,004h,004h,004h,004h,0AAh,0A4h
        defb 000h,000h,000h,000h,0AAh,090h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,016h,0AAh,000h,001h,000h,000h,0AAh,090h
        defb 040h,040h,040h,040h,0AAh,094h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,05Ah,0AAh,040h,045h,040h,040h,0AAh,094h
        defb 000h,000h,000h,000h,0AAh,090h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,001h,056h,000h,000h,0AAh,090h
        defb 004h,004h,004h,004h,0AAh,094h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,006h,0AAh,004h,004h,0AAh,094h
        defb 000h,000h,000h,000h,0AAh,050h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,01Ah,0AAh,011h,011h,0AAh,0A5h
        defb 040h,040h,040h,040h,0AAh,040h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,055h,055h,0AAh,0AAh
        defb 000h,000h,000h,000h,0A9h,000h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 004h,004h,004h,004h,0A9h,044h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 000h,000h,000h,000h,0A5h,000h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 040h,040h,040h,040h,0A4h,040h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 000h,000h,000h,000h,090h,000h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 004h,004h,004h,004h,094h,004h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0A9h,055h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 000h,000h,000h,000h,090h,000h,0AAh,0AAh,0AAh,0AAh,05Ah,0AAh,095h,011h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 040h,040h,040h,040h,094h,040h,0AAh,0AAh,0AAh,0AAh,05Ah,0AAh,044h,040h,0AAh,0A9h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 000h,000h,000h,000h,0A5h,000h,0AAh,0AAh,0AAh,0AAh,01Ah,0AAh,000h,000h,0AAh,0A5h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 004h,004h,004h,004h,0A5h,044h,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,004h,004h,0AAh,0A4h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 000h,011h,000h,000h,0AAh,050h,0AAh,0AAh,055h,05Ah,0AAh,0A9h,000h,001h,0AAh,0A9h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 040h,056h,040h,040h,0A5h,040h,0AAh,0AAh,044h,045h,0AAh,0A4h,040h,045h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 001h,0AAh,000h,000h,091h,000h,06Ah,0AAh,000h,001h,0AAh,090h,090h,001h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 004h,06Ah,004h,004h,094h,004h,05Ah,0AAh,004h,004h,06Ah,094h,094h,004h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 001h,06Ah,000h,000h,050h,000h,016h,0AAh,000h,000h,06Ah,050h,0A5h,011h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 040h,05Ah,040h,040h,040h,040h,045h,0AAh,040h,040h,0AAh,040h,0A5h,055h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 000h,01Ah,000h,000h,090h,000h,001h,0AAh,000h,000h,0AAh,050h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 004h,006h,004h,004h,0A4h,044h,004h,06Ah,004h,004h,0A9h,044h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 000h,016h,010h,000h,0A9h,055h,000h,016h,000h,000h,0A9h,000h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 044h,05Ah,054h,044h,06Ah,0AAh,040h,045h,040h,040h,0A9h,040h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 055h,06Ah,0A5h,055h,01Ah,0AAh,000h,001h,000h,000h,0A9h,000h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,005h,0AAh,004h,004h,004h,004h,0A9h,044h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,001h,06Ah,000h,000h,000h,000h,0A9h,000h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,040h,06Ah,040h,040h,040h,040h,0A9h,040h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,000h,01Ah,000h,000h,000h,000h,0A5h,000h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,004h,05Ah,004h,004h,004h,004h,094h,004h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,000h,016h,000h,000h,000h,000h,050h,000h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,040h,046h,040h,040h,040h,040h,040h,040h,0AAh,0A9h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,000h,016h,000h,000h,000h,000h,000h,000h,0AAh,0A5h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,004h,005h,004h,004h,004h,004h,004h,004h,0AAh,0A4h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,000h,001h,000h,000h,000h,000h,000h,000h,0AAh,090h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,040h,045h,040h,040h,040h,040h,040h,040h,0AAh,094h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,06Ah,0AAh,000h,001h,000h,000h,000h,000h,000h,000h,0AAh,050h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,06Ah,0AAh,004h,004h,004h,004h,004h,004h,004h,004h,0AAh,044h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,06Ah,0AAh,000h,001h,000h,000h,000h,000h,000h,000h,0AAh,050h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,05Ah,0AAh,040h,040h,040h,040h,040h,040h,040h,040h,0AAh,040h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,01Ah,0AAh,000h,000h,000h,000h,000h,000h,000h,000h,0AAh,050h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,05Ah,0AAh,004h,004h,004h,004h,004h,004h,004h,004h,0AAh,044h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,01Ah,0AAh,000h,000h,000h,000h,000h,000h,000h,000h,0AAh,090h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,05Ah,0AAh,040h,040h,040h,040h,040h,040h,040h,040h,0A9h,040h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,01Ah,0AAh,000h,000h,000h,000h,000h,000h,000h,000h,055h,000h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,05Ah,0AAh,004h,004h,004h,004h,004h,004h,004h,004h,044h,004h,0AAh,0A5h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,01Ah,0AAh,000h,000h,000h,000h,000h,000h,000h,000h,000h,000h,0AAh,091h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,06Ah,0AAh,040h,040h,040h,040h,040h,040h,040h,040h,040h,040h,0A9h,040h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,000h,011h,000h,000h,000h,000h,000h,000h,000h,000h,0A9h,000h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,004h,056h,004h,004h,004h,004h,004h,004h,004h,004h,0A4h,004h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,001h,0AAh,000h,000h,000h,000h,000h,000h,000h,000h,0A5h,000h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,045h,0AAh,040h,040h,040h,040h,040h,040h,040h,040h,0A4h,040h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,016h,0AAh,000h,000h,000h,000h,000h,000h,000h,000h,0A5h,000h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,05Ah,0AAh,004h,004h,004h,004h,004h,004h,004h,004h,0A4h,004h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,01Ah,0AAh,000h,000h,000h,000h,000h,000h,000h,000h,0A5h,000h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,040h,040h,040h,040h,040h,040h,040h,040h,0A9h,040h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,000h,001h,000h,000h,000h,000h,000h,000h,0A9h,000h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,004h,004h,004h,004h,004h,004h,004h,004h,0AAh,044h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,01Ah,0AAh,000h,000h,000h,000h,000h,000h,000h,000h,0AAh,095h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,05Ah,0AAh,040h,040h,040h,040h,040h,040h,040h,040h,0AAh,0A9h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,01Ah,0AAh,000h,000h,000h,000h,000h,000h,091h,000h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,006h,0AAh,004h,004h,004h,004h,004h,004h,0A5h,044h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,016h,0AAh,000h,000h,000h,000h,000h,000h,0AAh,050h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,046h,0AAh,040h,040h,040h,040h,040h,040h,0AAh,040h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,016h,0AAh,000h,000h,000h,000h,000h,000h,0AAh,050h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,006h,0AAh,004h,004h,004h,004h,004h,004h,0AAh,044h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,016h,0AAh,000h,000h,000h,000h,000h,000h,0AAh,050h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,046h,0AAh,040h,040h,040h,040h,040h,040h,0AAh,094h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,016h,0AAh,000h,000h,000h,000h,000h,000h,0AAh,0A5h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,05Ah,0AAh,004h,004h,004h,004h,004h,004h,0AAh,0A4h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,000h,001h,000h,000h,000h,000h,0AAh,0A9h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,044h,045h,040h,040h,040h,040h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,015h,05Ah,000h,000h,050h,000h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,05Ah,0AAh,004h,004h,044h,004h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,000h,001h,000h,000h,0AAh,0A9h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,040h,045h,040h,040h,0AAh,0A9h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,000h,001h,000h,000h,0AAh,0A9h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,095h,06Ah,0AAh,0AAh
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,004h,006h,044h,004h,0AAh,0A9h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,044h,05Ah,0AAh,0AAh
        defb 055h,0AAh,0AAh,0A9h,0AAh,0AAh,0AAh,0AAh,001h,016h,000h,000h,0AAh,0A9h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,050h,016h,0AAh,0AAh
        defb 044h,05Ah,0AAh,094h,0AAh,0AAh,0AAh,0AAh,045h,06Ah,040h,040h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,069h,0AAh,040h,045h,0AAh,0A9h
        defb 000h,015h,0AAh,050h,0AAh,0AAh,0AAh,0AAh,05Ah,0AAh,051h,011h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,015h,056h,000h,001h,0AAh,0A9h
        defb 004h,004h,0AAh,044h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0A5h,056h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,004h,045h,044h,004h,0AAh,0A9h
        defb 000h,000h,0AAh,050h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,000h,001h,000h,000h,0AAh,0A9h
        defb 040h,040h,0AAh,094h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,040h,040h,040h,040h,09Ah,0A4h
        defb 000h,001h,0AAh,0A5h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,000h,001h,000h,000h,055h,050h
        defb 004h,005h,0AAh,0A4h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,004h,004h,004h,004h,044h,044h
        defb 000h,016h,0AAh,0A5h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,000h,001h,000h,000h,000h,000h
        defb 040h,05Ah,0AAh,0A4h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,040h,040h,040h,040h,040h,040h
        defb 000h,01Ah,0AAh,0A5h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,000h,001h,000h,000h,000h,000h
        defb 044h,05Ah,0AAh,0A4h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,004h,004h,004h,004h,004h,004h
        defb 055h,06Ah,0AAh,0A9h,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,000h,001h,000h,000h,000h,000h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,040h,045h,040h,040h,040h,040h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,000h,016h,000h,000h,000h,000h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,004h,006h,004h,004h,004h,004h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,000h,01Ah,000h,000h,000h,000h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,040h,05Ah,040h,040h,040h,040h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,001h,06Ah,000h,000h,000h,000h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,004h,06Ah,004h,004h,004h,004h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0A5h,055h,0AAh,0AAh,001h,06Ah,000h,000h,000h,000h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,05Ah,0AAh,054h,044h,0AAh,0AAh,040h,06Ah,040h,040h,040h,040h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,01Ah,0AAh,010h,000h,0AAh,0A9h,001h,06Ah,000h,000h,000h,000h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,05Ah,0AAh,044h,004h,0AAh,0A9h,005h,0AAh,004h,004h,004h,004h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,06Ah,0AAh,000h,001h,0AAh,0A9h,001h,0AAh,000h,000h,000h,000h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,040h,045h,0AAh,0AAh,045h,0AAh,040h,040h,040h,040h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,090h,001h,0AAh,0AAh,016h,0AAh,000h,000h,000h,000h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,05Ah,0AAh,0AAh,094h,005h,0AAh,0AAh,05Ah,0AAh,004h,004h,004h,004h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0A9h,016h,0AAh,0AAh,0A5h,015h,0AAh,0AAh,06Ah,0AAh,011h,011h,011h,011h
        defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,054h,046h,0AAh,095h,0A5h,05Ah,0AAh,0AAh,0AAh,0AAh,055h,055h,055h,055h
; ---------------------------------------------------------------------
; RAM variables (not part of the file)
; ---------------------------------------------------------------------
VARS        equ $
rngseed   equ VARS+0
tick      equ VARS+1
kheld     equ VARS+2
joyon     equ VARS+3
srow      equ VARS+4
W0        equ VARS+5
scrollc   equ VARS+7
px        equ VARS+8
py        equ VARS+9
plstate   equ VARS+10
plexp     equ VARS+11
invuln    equ VARS+12
loopt     equ VARS+13
loops     equ VARS+14
lives     equ VARS+15
firecd    equ VARS+16
inkeys    equ VARS+17
stage     equ VARS+18
wavecnt   equ VARS+19
spawncd   equ VARS+20
dirty     equ VARS+21
gover     equ VARS+22
nsaved    equ VARS+23
savep     equ VARS+24
ds_x      equ VARS+26
ds_h      equ VARS+27
ds_skip   equ VARS+28
ds_rows   equ VARS+29
ds_tab    equ VARS+30
pr_w      equ VARS+32
pr_h      equ VARS+33
t1        equ VARS+34
t2        equ VARS+35
t3        equ VARS+36
SAVESP    equ VARS+37
SCORE     equ VARS+39
HISCORE   equ VARS+45
STAGEBUF  equ VARS+51
LOOPSTR   equ VARS+53
mcnt      equ VARS+56
t4        equ VARS+57
t5        equ VARS+58
kills     equ VARS+59
bossact   equ VARS+60
bossx     equ VARS+61
bossy     equ VARS+62
bosshp    equ VARS+63
bossdir   equ VARS+64
bossfire  equ VARS+65
bossexp   equ VARS+66
bossnum   equ VARS+67
txtn      equ VARS+68
txtp      equ VARS+69
gocnt     equ VARS+71
TXTSAVE   equ VARS+72
MUSVARS   equ VARS+222
ENEMS     equ VARS+262
PBULS     equ VARS+294
EBULS     equ VARS+303
SAVEBUF   equ VARS+315
VEND      equ VARS+875
STACKTOP    equ VEND+160
