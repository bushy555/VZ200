#!/usr/bin/env python3
"""Pack a built 1942 image with ZX0 into a self-extracting .VZ.
   usage: pack_zx0.py 1942_16K      (needs the zx0 compressor and pasmo)"""
import subprocess, sys, struct, re, os
name = sys.argv[1]
ORG = int(sys.argv[2], 16) if len(sys.argv) > 2 else 0x8000      # where the game lives
TOP = int(sys.argv[3], 16) if len(sys.argv) > 3 else 0xBFFF      # last RAM address: the packed blob ends here
ZX0 = os.environ.get("ZX0", "/home/claude/zx0src/zx0")
DZ = os.environ.get("DZX0", "/home/claude/zx0src/z80/dzx0_standard.asm")
# the 68-byte decompressor must run from outside the area being unpacked:
# free BASIC RAM below $8000, or - when the game starts at $7B00 - the video RAM
DZ_ADDR, STACK = (0x7C00, 0x7F00) if ORG >= 0x8000 else (0x7000, 0x7700)

body = open(name + ".bin", "rb").read()
end_dec = ORG + len(body) - 1
r = subprocess.run([ZX0, "-f", name + ".bin", name + ".zx0"], capture_output=True, text=True)
blob = open(name + ".zx0", "rb").read()
delta = int(re.search(r"delta (\d+)", r.stdout + r.stderr).group(1))
# decompressor, assembled at its run address
open("dz.asm", "w").write("        org %d\n" % DZ_ADDR + open(DZ).read())
subprocess.run(["pasmo", "--bin", "dz.asm", "dz.bin"], check=True)
dz = open("dz.bin", "rb").read()

def stub(x):
    s = (f"        org {x}\n"
         "        di\n"
         f"        ld hl,dzsrc\n        ld de,{DZ_ADDR}\n        ld bc,{len(dz)}\n        ldir\n"
         f"        ld sp,{STACK}\n"
         f"        ld hl,{ORG}\n        push hl                 ; decompressor 'ret' starts the game\n"
         f"        ld hl,blob\n        ld de,{ORG}\n"
         f"        jp {DZ_ADDR}\n"
         "dzsrc:  incbin \"dz.bin\"\n"
         "blob:   incbin \"%s.zx0\"\n" % name)
    return s
# the stub size is constant, so solve for the load address once
open("stub.asm", "w").write(stub(0x9000)); subprocess.run(["pasmo", "--bin", "stub.asm", "stub.bin"], check=True)
total = len(open("stub.bin", "rb").read())
x = TOP + 1 - total
open("stub.asm", "w").write(stub(x)); subprocess.run(["pasmo", "--bin", "stub.asm", "stub.bin"], check=True)
img = open("stub.bin", "rb").read()
assert x + len(img) == TOP + 1
assert TOP >= end_dec + delta, "blob must end at least delta bytes above the decompressed data"
vzname = (name.replace("_", " ") + " ZX0").encode().ljust(16, b" ")[:16] + b"\x00"
open(name + "_ZX0.VZ", "wb").write(b"VZF0" + vzname + b"\xF1" + struct.pack("<H", x) + img)
print("%s: raw %d bytes -> packed %d bytes (ZX0 blob %d, load $%04X-$%04X, unpacks to $%04X, delta %d)" % (name, len(body), len(img), len(blob), x, TOP, ORG, delta))
open(name + "_ZX0.info", "w").write("%d %d\n" % (x, len(img)))
