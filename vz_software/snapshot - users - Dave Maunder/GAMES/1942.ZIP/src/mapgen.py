import math, random
H = 192          # scrolling map height in pixel rows (seamless wrap)
MW = 96          # playfield width in pixels
GREEN, YELLOW, BLUE, RED = 0, 1, 2, 3

def make_map(seed=1942):
    f = H / 192.0
    rng = random.Random(seed)
    # (cx, cy, rx, ry) ellipses; several per island give a bean shape
    blobs = [
        # big central-right bean
        (58, 64, 20, 22), (62, 86, 18, 22), (56, 46, 12, 14),
        # top-left island touching the left edge
        (6, 14, 18, 16), (14, 26, 10, 10),
        # right island
        (88, 126, 14, 18), (84, 108, 10, 10),
        # left-centre island
        (22, 150, 16, 18), (26, 170, 12, 14), (14, 134, 10, 10),
        # islets
        (44, 112, 5, 7), (90, 28, 6, 8), (36, 6, 5, 6), (70, 168, 7, 9), (50, 188, 6, 6),
    ]
    blobs = [(cx, cy*f, rx, max(4, ry*f)) for (cx, cy, rx, ry) in blobs]
    phases = [(rng.random()*6.28, rng.random()*6.28) for _ in blobs]
    land = [[False]*MW for _ in range(H)]
    for y in range(H):
        for x in range(MW):
            for (cx, cy, rx, ry), (p1, p2) in zip(blobs, phases):
                dy = abs(y - cy)
                dy = min(dy, H - dy)
                dx = x - cx
                ang = math.atan2(dy if y >= cy else -dy, dx)
                wob = 1.0 + 0.16*math.sin(3*ang + p1) + 0.09*math.sin(5*ang + p2)
                if (dx/rx)**2 + (dy/ry)**2 < wob*wob:
                    land[y][x] = True
                    break
    return land

def colour_map(land):
    # distance to sea (4-neighbour), wrap in y, clamp in x
    INF = 99
    dist = [[INF]*MW for _ in range(H)]
    from collections import deque
    q = deque()
    for y in range(H):
        for x in range(MW):
            if not land[y][x]:
                dist[y][x] = 0
                q.append((y, x))
    while q:
        y, x = q.popleft()
        for dy, dx in ((1,0),(-1,0),(0,1),(0,-1)):
            ny = (y+dy) % H
            nx = x+dx
            if 0 <= nx < MW and dist[ny][nx] > dist[y][x]+1:
                dist[ny][nx] = dist[y][x]+1
                q.append((ny, nx))
    img = [[BLUE]*MW for _ in range(H)]
    for y in range(H):
        for x in range(MW):
            if not land[y][x]:
                continue
            d = dist[y][x]
            if d <= 1:
                img[y][x] = YELLOW                      # shoreline
            elif d == 2:
                img[y][x] = YELLOW if (x+y) % 2 == 0 else GREEN   # beach dither
            else:
                img[y][x] = YELLOW if (y % 2 == 0 and (x + 2*((y//2) % 2)) % 4 == 0) else GREEN  # sparse dotted grass
    return img

if __name__ == "__main__":
    from PIL import Image
    land = make_map()
    img = colour_map(land)
    pal = {GREEN:(96,190,70), YELLOW:(240,230,140), BLUE:(20,20,230), RED:(220,60,40)}
    # draw 3 copies side by side to inspect the vertical wrap
    out = Image.new("RGB", (MW*3*4, H*4), (0,0,0))
    px = out.load()
    for rep in range(3):
        for y in range(H):
            for x in range(MW):
                c = pal[img[y][x]]
                for yy in range(4):
                    for xx in range(4):
                        px[rep*MW*4 + x*4+xx, y*4+yy] = c
    out = out.resize((out.width, int(out.height*0.75)))
    out.save("map_preview.png")
    print("rows with land:", sum(1 for y in range(H) if any(land[y])))
