# data generators for 1942 (VZ200)  -- all emitted into the .asm as DEFB/DEFW
import mapgen
GREEN, YELLOW, BLUE, RED = 0, 1, 2, 3
COL = {'G': GREEN, 'Y': YELLOW, 'B': BLUE, 'R': RED}
H = mapgen.H
MROWS = H + 64
SHIFT_STEP = 1            # 1 = pre-shift for every pixel position, 2 = every 2nd pixel
PRECISE = set()           # sprites that keep full 1-pixel precision even when SHIFT_STEP = 2
def set_height(h):
    global H, MROWS
    mapgen.H = h; H = h; MROWS = h + 64

def db_lines(data, per=16):
    out = []
    for i in range(0, len(data), per):
        out.append("        defb " + ",".join("0%02Xh" % b for b in data[i:i+per]))
    return "\n".join(out)

def pack_row(pix):
    out = []
    for i in range(0, len(pix), 4):
        v = 0
        for k in range(4):
            v |= pix[i+k] << (6-2*k)
        out.append(v)
    return out

def map_block():
    land = mapgen.make_map()
    img = mapgen.colour_map(land)
    rows = [pack_row(img[y % H]) for y in range(MROWS)]     # rows H..H+63 duplicate rows 0..63
    # global word list in image order, then reversed (word-reversed layout, bytes inside a word keep order)
    words = []
    for r in rows:
        for c in range(12):
            words.append((r[2*c], r[2*c+1]))
    words.reverse()
    flat = []
    for a, b in words:
        flat += [a, b]
    return flat

# ---------------------------------------------------------------- sprites
def outline(rows):
    h = len(rows); w = 9
    g = [list(r.ljust(9, '.')) for r in rows]
    o = [r[:] for r in g]
    for y in range(h):
        for x in range(w):
            if g[y][x] == '.':
                for dy, dx in ((1,0),(-1,0),(0,1),(0,-1)):
                    yy, xx = y+dy, x+dx
                    if 0 <= yy < h and 0 <= xx < w and g[yy][xx] not in '.B':
                        o[y][x] = 'B'
                        break
    return ["".join(r) for r in o]

def mirror(rows):
    return [r[::-1] for r in rows]

ART = {}
# P-38 Lightning: twin booms, centre gondola, red roundels on the wing tips, cockpit
ART['PL0'] = outline([".Y..Y..Y.", ".Y.YYY.Y.", "RYYYRYYYR", "YYYYYYYYY", ".Y.YRY.Y.", ".Y..Y..Y.", ".YYYYYYY.", "YY.....YY"])
ART['PL1'] = outline(["...YYY...", "..YYYYY..", "..RYRYR..", "..YYYYY..", "..YYRYY..", "...Y.Y...", "..YYYYY..", "..Y...Y.."])
ART['PL2'] = outline(["....Y....", "....Y....", "...YRY...", "...YYY...", "...YRY...", "....Y....", "...YYY...", "...Y.Y..."])
# Zero-style fighter flying down: red wings with a yellow cockpit and cowling
# banked P-38: the wing on the side being turned towards is dropped (looks like a dive)
pll = ["....Y..Y.", "...YYY.Y.", "...YRYYYR", "...YYYYYY", "...YRY.Y.", "....Y..Y.", "....YYYY.", "......YY."]
ART['PLL'] = outline(pll)
ART['PLR'] = outline(mirror(pll))
ART['EN0'] = outline(["....R....", "..RRRRR..", "....R....", "RRRRYRRRR", ".RRRRRRR.", "....R....", "....Y...."])
ART['ENL'] = outline(["....R....", "..RRRRR..", "....R....", "RRRRYRRR.", "..RRRRRR.", "....R....", "....Y...."])
ART['ENR'] = outline(mirror(["....R....", "..RRRRR..", "....R....", "RRRRYRRR.", "..RRRRRR.", "....R....", "....Y...."]))
ART['EX0'] = [".........", "...Y.R...", "....Y....", "...R.Y...", ".........", "........."]
ART['EX1'] = ["..R...Y..", "...YRY...", ".YRYYYR..", "..RYRY...", "...Y.R...", "..R...Y.."]
ART['EX2'] = [".Y.....R.", "....Y....", "R.......Y", "...R.....", ".Y.....Y.", "....R...."]
ART['PB']  = [".R.....R.", ".R.....R."]
ART['EB']  = ["....YR...", "....RY..."]
SPR_ORDER = ['PL0','PL1','PL2','PLL','PLR','BS0','BS1','BS2','BS3','BS4','BS5','EN0','ENL','ENR','EX0','EX1','EX2','PB','EB']

def sprite_blocks(rows, step=1):
    blocks = {}
    for s in range(0, 8, step):
        data = bytearray()
        for r in rows:
            px = [None]*16
            for i, ch in enumerate(r):
                if ch != '.':
                    px[s+i] = COL[ch]
            for byte in range(4):
                m = d = 0
                for p in range(4):
                    v = px[byte*4+p]
                    if v is None:
                        m |= 3 << (6-2*p)
                    else:
                        d |= v << (6-2*p)
                data += bytes([m, d])
        blocks[s] = bytes(data)
    return blocks

def sprite_asm():
    out = ["; ---- sprite descriptors: height, then 8 pointers (one per pixel shift 0-7).",
           ";      data per row = 4 bytes of (mask,data) pairs, in image-byte order."]
    steps = {}
    for name in SPR_ORDER:
        step = 1 if (SHIFT_STEP == 1 or name in PRECISE) else SHIFT_STEP
        steps[name] = step
        rows = ART[name]
        out.append("SPR_%s:  defb %d" % (name, len(rows)))
        out.append("        defw " + ",".join("SPD_%s_%d" % (name, (s // step) * step) for s in range(8)))
    for name in SPR_ORDER:
        for s, blk in sprite_blocks(ART[name], steps[name]).items():
            out.append("SPD_%s_%d:" % (name, s))
            out.append(db_lines(blk, 8))
    return "\n".join(out)

# ---------------------------------------------------------------- font (3x5, 1 byte per glyph row = 4 px cell)
F = {
'A':"010101111101101",'B':"110101110101110",'C':"011100100100011",'D':"110101101101110",
'E':"111100110100111",'F':"111100110100100",'G':"011100101101011",'H':"101101111101101",
'I':"111010010010111",'J':"001001001101010",'K':"101101110101101",'L':"100100100100111",
'M':"101111111101101",'N':"111101101101101",'O':"010101101101010",'P':"110101110100100",
'Q':"010101101111011",'R':"110101110101101",'S':"011100010001110",'T':"111010010010010",
'U':"101101101101111",'V':"101101101101010",'W':"101101111111101",'X':"101101010101101",
'Y':"101101010010010",'Z':"111001010100111",
'0':"111101101101111",'1':"010110010010111",'2':"111001111100111",'3':"111001111001111",
'4':"101101111001001",'5':"111100111001111",'6':"111100111101111",'7':"111001001010010",
'8':"111101111101111",'9':"111101111001111",
' ':"000000000000000",'-':"000000111000000",'!':"010010010000010",':':"000010000010000",
'=':"000111000111000",'.':"000000000000010",',':"000000000010100",
}
GLYPH_ORDER = list("0123456789") + [' '] + list("ABCDEFGHIJKLMNOPQRSTUVWXYZ") + list("-!:=.,")
def gidx(ch): return GLYPH_ORDER.index(ch)
def text_idx(s): return [gidx(c) for c in s] + [0xFF]

def font_bytes(colour):
    out = []
    for ch in GLYPH_ORDER:
        bits = F[ch]
        for r in range(5):
            row = bits[r*3:r*3+3]
            v = 0
            for k in range(3):
                v |= (colour if row[k] == '1' else BLUE) << (6-2*k)
            v |= BLUE << 0          # 4th pixel = blue spacing
            out.append(v)
    return out

def big_glyph(ch):
    bits = F[ch]
    out = []
    for r in range(5):
        row = bits[r*3:r*3+3]
        px = []
        for k in range(3):
            px += [YELLOW if row[k] == '1' else BLUE]*2
        px += [BLUE, BLUE]
        line = pack_row(px)
        out += line; out += line
    return out

def panel_image():
    img = [[BLUE]*32 for _ in range(64)]      # 32 px wide panel (8 bytes) - col 0 is the divider byte
    for y in range(64):
        img[y][0] = YELLOW; img[y][1] = YELLOW
    def put(text, row, col_byte):
        x0 = col_byte*4
        for n, ch in enumerate(text):
            bits = F[ch]
            for r in range(5):
                for k in range(3):
                    if bits[r*3+k] == '1':
                        img[row+r][x0+n*4+k] = GREEN
    put("SCORE", 1, 1); put("HI", 14, 1); put("STAGE", 27, 1); put("LOOPS", 51, 1)
    out = []
    for y in range(64):
        out += pack_row(img[y])
    return out

ICON = ["Y..YY..Y", "YYYYYYYY", "Y..YY..Y", "...YY...", "..YYYY.."]
def icon_bytes():
    out = []
    for r in ICON:
        px = [YELLOW if c == 'Y' else BLUE for c in r]
        out += pack_row(px)
    return out


# ---------------------------------------------------------------- boss: 27x16 bomber built from six 9x8 tiles
def boss_canvas():
    W, Hh = 27, 16
    c = [['.']*W for _ in range(Hh)]
    def put(x0, x1, y, ch):
        for x in range(x0, x1+1):
            c[y][x] = ch
    for y in range(Hh):                      # fuselage, rounded nose at the bottom
        if y == 0 or y >= 14: put(12, 14, y, 'R')
        else: put(11, 15, y, 'R')
    put(8, 18, 1, 'R'); put(9, 17, 2, 'R')   # tailplane
    put(3, 23, 5, 'R'); put(1, 25, 6, 'R'); put(1, 25, 7, 'R'); put(2, 24, 8, 'R'); put(4, 22, 9, 'R')   # wings
    for x in (4, 8, 18, 22):                 # four engines with yellow props
        put(x, x, 10, 'R'); put(x, x, 11, 'R'); put(x, x, 12, 'Y')
        put(x, x, 6, 'Y'); put(x, x, 7, 'Y')
    put(1, 1, 6, 'Y'); put(25, 25, 6, 'Y')   # wing-tip lights
    put(13, 13, 12, 'Y'); put(13, 13, 13, 'Y'); put(13, 13, 3, 'Y')   # cockpit / spine
    # blue outline (4-neighbour) so it reads on land as well as sea
    o = [r[:] for r in c]
    for y in range(Hh):
        for x in range(W):
            if c[y][x] == '.':
                for dy, dx in ((1,0),(-1,0),(0,1),(0,-1)):
                    yy, xx = y+dy, x+dx
                    if 0 <= yy < Hh and 0 <= xx < W and c[yy][xx] not in '.B':
                        o[y][x] = 'B'; break
    return ["".join(r) for r in o]
for _row in range(2):
    for _col in range(3):
        ART['BS%d' % (_row*3 + _col)] = [r[_col*9:_col*9+9] for r in boss_canvas()[_row*8:_row*8+8]]
