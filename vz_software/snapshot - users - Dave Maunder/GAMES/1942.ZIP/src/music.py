# Original march-style title tune for the 4 channel 1-bit engine.
# (Original composition - not a transcription of any existing game's music.)
SAMPLE_T = """ add hl,de|ld a,h|add a,a|sbc a,a|and 21h|xor 28h|ld (LATCH),a|add ix,bc|push ix|pop af|add a,a|sbc a,a|and 21h|xor 28h|ld (LATCH),a|exx|add hl,de|ld a,h|add a,a|sbc a,a|and 21h|xor 28h|ld (LATCH),a|add iy,bc|push iy|pop af|add a,a|sbc a,a|and 21h|xor 28h|ld (LATCH),a|exx""".split("|")
def sample_code():
    return "\n".join("            " + s.strip() for s in SAMPLE_T)
# T-states: ch0 50 + ch2 75 + exx 4 + ch1 50 + ch3 75 + exx 4 = 258 per sample;
# loop overhead 40 per 2 samples  ->  278 T per sample on average
T_PER_SAMPLE = 258 + 20
CPU = 3579545.0
FS = CPU / T_PER_SAMPLE
TICK_T = 100 * (2*258 + 40)
UNIT = 7                      # ticks per sixteenth note (quarter = 28 ticks, ~134 bpm)

NOTE = {'C':0,'C#':1,'D':2,'Eb':3,'E':4,'F':5,'F#':6,'G':7,'G#':8,'A':9,'Bb':10,'B':11}
def m(name):
    n = name[:-1]; o = int(name[-1])
    return 12*(o+1) + NOTE[n]
def pitch_table():
    out = []
    for midi in range(24, 97):
        f = 440.0 * 2 ** ((midi-69)/12.0)
        step = round(f * 65536 / FS)
        out += [step & 255, step >> 8]
    return out

# 16 bars: chord root name and lead melody (note, sixteenths)
CHORDS = ['Dm','Bb','C','A', 'Dm','Bb','A','Dm', 'Gm','Dm','A','A', 'Dm','Bb','A','Dm']
TONES = {'Dm':(62,65,69,38), 'Bb':(58,62,65,34), 'C':(60,64,67,36), 'A':(57,61,64,33), 'Gm':(55,58,62,31)}
R = None
LEAD = [
 [('A4',4),('D5',4),('F5',4),('A5',4)],
 [('G5',6),('F5',2),('D5',4),('Bb4',4)],
 [('E5',4),('G5',4),('C6',4),('G5',4)],
 [('A5',6),('G5',2),('E5',4),('C#5',4)],
 [('A4',4),('D5',4),('F5',4),('A5',4)],
 [('G5',4),('A5',4),('Bb5',4),('A5',4)],
 [('G5',4),('F5',4),('E5',4),('C#5',4)],
 [('D5',12),(R,4)],
 [('Bb4',4),('D5',4),('G5',8)],
 [('F5',4),('A5',4),('D6',8)],
 [('C#6',4),('E6',4),('A5',8)],
 [('A5',12),(R,4)],
 [('A4',4),('D5',4),('F5',4),('A5',4)],
 [('G5',6),('F5',2),('D5',4),('Bb4',4)],
 [('E5',4),('G5',4),('A5',4),('C#6',4)],
 [('D6',12),(R,4)],
]
def streams():
    ch0, ch1, ch2, ch3 = [], [], [], []
    for bar, ch in enumerate(CHORDS):
        for name, u in LEAD[bar]:
            ch0.append((0 if name is R else m(name), u*UNIT))
        a, b, c, root = TONES[ch]
        for k in range(16):
            ch1.append(((a, b, c, b)[k % 4], UNIT))
        for beat in range(4):
            n = root if beat % 2 == 0 else root + 7
            ch2 += [(n, 3*UNIT), (0, UNIT)]
        for beat in range(4):
            if beat % 2 == 0:
                ch3 += [(31, 9), (0, 19)]       # kick (low pitch)
            else:
                ch3 += [(0xFE, 7), (0, 21)]     # snare (noise)
    return [ch0, ch1, ch2, ch3]
def music_asm():
    out = []
    for i, s in enumerate(streams()):
        out.append("MUS_CH%d:" % i)
        row = []
        for n, d in s:
            assert 0 < d < 256 and (n == 0 or n == 0xFE or 24 <= n <= 96)
            row += [n, d]
        row += [0xFF]
        for j in range(0, len(row), 16):
            out.append("        defb " + ",".join("0%02Xh" % x for x in row[j:j+16]))
    return "\n".join(out)
