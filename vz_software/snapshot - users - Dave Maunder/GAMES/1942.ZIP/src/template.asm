; =====================================================================
;  1942  -  vertical scrolling air-combat shooter for the VZ200 / VZ300
;  MODE(1) 128x64, 4 colour (CSS0: green / yellow / blue / red)
;
;  Build : python3 build_1942.py   (generates this file, assembles it with
;          pasmo and wraps the result as 1942.VZ)
;  Load  : binary file, loads and runs at $8000 (needs RAM $8000-$CBFF,
;          i.e. a 32KB cartridge such as the Ben Venn SD Loader)
;
;  KEYS     Q up   A down   M left   , right   SPACE fire   N loop
;  JOYSTICK port $2E / $2B directions + button 1 = fire, button 2 ($2D/$27) = loop
;           (enable with J on the title screen - keyboard always works)
;
;  HOW THE SCREEN IS DRAWN (no snow)
;   The 6847 corrupts the picture ("snow") whenever the Z80 touches video RAM
;   while the VDG is fetching display data.  So video RAM is ONLY written
;   right after the field-sync (FS, bit 7 of $6800) falling edge, i.e. from the
;   end of the active display through the bottom border, retrace and top
;   border.  Everything else is done in RAM:
;     * the whole land/sea picture lives in a RAM map (96x(192+64) pixels)
;     * sprites are drawn INTO that map (saving what was under them), so the
;       map window for the current scroll position is the finished back buffer
;     * at the vsync edge the back buffer is copied to $7000 by an unrolled
;       POP/PUSH blitter (about 13.5 T-states per byte) whose source addresses
;       are patched each frame by PATCH_BLIT
;   The map is stored "word reversed" (see gendata.map_block) so that POP
;   (ascending) / PUSH (descending) walk the picture in the right order.
; =====================================================================

VRAM        equ 7000h
LATCH       equ 6800h
MAPH        equ @MAPH@              ; scrolling map height in rows
MAPROWS     equ MAPH+64
TOPEND      equ MAPDATA+MAPROWS*24-2 ; address of image word 0 (row 0, col 0)
WRAPW0      equ TOPEND-24*(MAPH-1)
SCROLL_DIV  equ 2                   ; frames per one-row scroll step
EXP_TICKS   equ 5
BOSS_KILLS  equ 20                 ; enemy planes shot down before the boss arrives
TXTROW      equ 27                  ; GAME OVER text position inside the playfield
TXTCOL      equ 11
MAXE        equ 4
MAXPB       equ 3
MAXEB       equ 3
SLOT        equ 40                  ; bytes per sprite save slot
IDX_R       equ 28                  ; font index of the letter R

            org @ORG@

; ---------------------------------------------------------------------
START:      di
            ld sp,STACKTOP
            ld hl,VARS              ; RAM powers up (or is left after unpacking) full of
            ld de,VARS+1            ; garbage: clear every game variable first
            ld bc,VEND-VARS-1
            ld (hl),0
            ldir
            ld a,08h                ; MODE(1), CSS0, speaker idle
            ld (LATCH),a
            ld a,55h
            ld (rngseed),a
            xor a
            ld (joyon),a
            ld (nsaved),a           ; no sprites drawn yet
            ld hl,SAVEBUF
            ld (savep),hl
            ld hl,HISCORE
            ld b,6
st_hi:      ld (hl),a
            inc hl
            djnz st_hi
MAIN:       call SHOW_TITLE
            call NEW_GAME
            call GAME_LOOP
            call GAME_OVER
            jr MAIN

; ---------------------------------------------------------------------
; WAITVS - wait for the falling edge of FS (bit 7 of $6800)
; ---------------------------------------------------------------------
WAITVS:     ld a,(LATCH)
            rlca
            jr nc,WAITVS            ; still in the low (blank) phase: wait for high
wv2:        ld a,(LATCH)
            rlca
            jr c,wv2                ; wait for high -> low edge
            ret

; ---------------------------------------------------------------------
; RND - 8 bit pseudo random in A (clobbers B)
; ---------------------------------------------------------------------
RND:        ld a,(rngseed)
            ld b,a
            rrca
            rrca
            rrca
            xor 1Fh
            add a,b
            sbc a,255
            ld (rngseed),a
            ret

; ---------------------------------------------------------------------
; BEEP  B = cycles, C = pitch delay.  The speaker is driven differentially by
; latch bits 0 and 5 (01 = +1, 20 = -1, both or neither = 0), graphics bits kept.
; ---------------------------------------------------------------------
BEEP:       ld a,09h                ; speaker +1 (bit 0)
            ld (LATCH),a
            ld d,c
bp2:        dec d
            jr nz,bp2
            ld a,28h                ; speaker -1 (bit 5)
            ld (LATCH),a
            ld d,c
bp3:        dec d
            jr nz,bp3
            djnz BEEP
            ld a,08h                ; back to idle (graphics bits only)
            ld (LATCH),a
            ret
SFX_FIRE:   ld b,4
            ld c,5
            jp BEEP
SFX_EXPL:   ld b,14
            ld a,(tick)
            and 7
            add a,3
            ld c,a
            jp BEEP

; ---------------------------------------------------------------------
; READ_INPUT -> (inkeys): b0 up b1 down b2 left b3 right b4 fire b5 loop
; ---------------------------------------------------------------------
READ_INPUT: ld c,0
            ld a,(68FEh)            ; row A0: Q = $10
            and 10h
            jr nz,ri1
            set 0,c
ri1:        ld a,(68FDh)            ; row A1: A = $10
            and 10h
            jr nz,ri2
            set 1,c
ri2:        ld a,(68EFh)            ; row A4: M=$20 SPACE=$10 ,=$08 N=$01
            ld b,a
            and 20h
            jr nz,ri3
            set 2,c
ri3:        ld a,b
            and 08h
            jr nz,ri4
            set 3,c
ri4:        ld a,b
            and 10h
            jr nz,ri5
            set 4,c
ri5:        ld a,b
            and 01h
            jr nz,ri6
            set 5,c
ri6:        ld a,(joyon)
            or a
            jr z,ri9
            in a,(2Eh)              ; joystick 1 : b0 up b1 down b2 left b3 right b4 fire (active low)
            ld b,a
            in a,(2Bh)              ; joystick 2
            and b
            ld b,a
            bit 0,b
            jr nz,rj1
            set 0,c
rj1:        bit 1,b
            jr nz,rj2
            set 1,c
rj2:        bit 2,b
            jr nz,rj3
            set 2,c
rj3:        bit 3,b
            jr nz,rj4
            set 3,c
rj4:        bit 4,b
            jr nz,rj5
            set 4,c
rj5:        in a,(2Dh)              ; second button (arm) = loop
            ld b,a
            in a,(27h)
            and b
            bit 4,a
            jr nz,ri9
            set 5,c
ri9:        ld a,c
            ld (inkeys),a
            ret

; ---------------------------------------------------------------------
; Direct-to-VRAM helpers (call only right after WAITVS and keep them short)
; ---------------------------------------------------------------------
; PUT_RECT  HL=src, DE=vram dest, B=rows, C=width in bytes
PUT_RECT:   ld a,b
            ld (pr_h),a
            ld a,c
            ld (pr_w),a
pr_row:     push de
            ld a,(pr_w)
            ld c,a
            ld b,0
            ldir
            pop de
            push hl
            ld hl,32
            add hl,de
            ex de,hl
            pop hl
            ld a,(pr_h)
            dec a
            ld (pr_h),a
            jr nz,pr_row
            ret
; PUTCHAR  A=glyph index, DE=vram dest, IX=font table
PUTCHAR:    ld l,a
            add a,a
            add a,a
            add a,l
            ld c,a
            ld b,0
            push ix
            pop hl
            add hl,bc
            ld b,5
            ld c,1
            jp PUT_RECT
; PRINT_STR  HL = indices terminated by $FF, DE = vram dest, IX = font
PRINT_STR:  ld a,(hl)
            cp 0FFh
            ret z
            push hl
            push de
            call PUTCHAR
            pop de
            pop hl
            inc hl
            inc de
            jr PRINT_STR
; PRINT_IDX  HL = indices, B = count, DE = vram dest, IX = font
PRINT_IDX:  ld a,(hl)
            push bc
            push hl
            push de
            call PUTCHAR
            pop de
            pop hl
            pop bc
            inc hl
            inc de
            djnz PRINT_IDX
            ret
; PANEL_ROWS HL=src DE=dst B=rows (8 bytes per row)
PANEL_ROWS: push bc
            ld bc,8
            ldir
            ld a,e
            add a,24
            ld e,a
            jr nc,pnr2
            inc d
pnr2:       pop bc
            djnz PANEL_ROWS
            ret
; PRINT_LINE  HL=text, DE=vram, IX=font : waits for vsync first
PRINT_LINE: push hl
            push de
            call WAITVS
            pop de
            pop hl
            jp PRINT_STR

; ---------------------------------------------------------------------
; Title screen
; ---------------------------------------------------------------------
SHOW_TITLE: ld hl,VRAM
            ld b,4
tt_fill:    push bc
            push hl
            call WAITVS
            pop hl
            ld d,h
            ld e,l
            inc de
            ld (hl),0AAh
            ld bc,511
            ldir
            ex de,hl                ; HL = start of next 512 byte block
            pop bc
            djnz tt_fill
            call WAITVS             ; big "1942" logo
            ld hl,BIGDIGITS
            ld de,VRAM+6*32+12
            ld c,4
tt_logo:    push bc
            push hl
            push de
            ld b,10
            ld c,2
            call PUT_RECT
            pop de
            pop hl
            ld bc,20
            add hl,bc
            inc de
            inc de
            pop bc
            dec c
            jr nz,tt_logo
            ld ix,FONT_Y
            ld hl,STR_PRESS
            ld de,VRAM+22*32+6
            call PRINT_LINE
            ld ix,FONT_Y
            ld hl,STR_K1
            ld de,VRAM+46*32+7
            call PRINT_LINE
            ld hl,STR_K2
            ld de,VRAM+52*32+7
            call PRINT_LINE
            ld hl,STR_K3
            ld de,VRAM+58*32+7
            call PRINT_LINE
            call DRAW_OPTS
            xor a
            ld (kheld),a
;#IF MUSIC
            call MUS_INIT
;#END
tl_loop:
;#IF MUSIC
            call MUS_TICK           ; ~16 ms of music, then poll the keys
;#END
            ld hl,rngseed
            inc (hl)
            ld c,0
            ld a,(687Fh)            ; J
            and 20h
            jr nz,tl_a
            set 0,c
tl_a:       ld a,(68EFh)            ; SPACE
            and 10h
            jr nz,tl_c
            set 2,c
tl_c:       ld a,(joyon)
            or a
            jr z,tl_d
            in a,(2Eh)
            bit 4,a
            jr nz,tl_d
            set 2,c
tl_d:       ld a,c
            or a
            jr z,tl_rel
            ld a,(kheld)
            or a
            jr nz,tl_loop
            ld a,1
            ld (kheld),a
            bit 2,c
            ret nz                  ; start the game
            bit 0,c
            jr z,tl_loop
            ld a,(joyon)
            xor 1
            ld (joyon),a
            call DRAW_OPTS
            jr tl_loop
tl_rel:     xor a
            ld (kheld),a
            jr tl_loop

DRAW_OPTS:  ld ix,FONT_Y
            ld hl,STR_JOY_OFF
            ld a,(joyon)
            or a
            jr z,do1
            ld hl,STR_JOY_ON
do1:        ld de,VRAM+34*32+6
            jp PRINT_LINE

; ---------------------------------------------------------------------
; New game
; ---------------------------------------------------------------------
NEW_GAME:   call TXT_RESTORE        ; put back the map under the last game's text/sprites
            call RESTORE_SPRITES
            xor a
;#IF BOSS
            ld (kills),a
            ld (bossact),a
            ld (bossnum),a
;#END
            ld (gocnt),a
            ld (plstate),a
            ld (gover),a
            ld (loopt),a
            ld (firecd),a
            ld (wavecnt),a
            ld (tick),a
            ld (srow),a
            ld a,3
            ld (lives),a
            ld (loops),a
            ld a,1
            ld (stage),a
            xor a
            ld (STAGEBUF),a
            inc a
            ld (STAGEBUF+1),a
            ld a,44
            ld (px),a
            ld a,50
            ld (py),a
            ld a,100
            ld (invuln),a
            ld a,60
            ld (spawncd),a
            ld a,SCROLL_DIV
            ld (scrollc),a
            ld hl,TOPEND
            ld (W0),hl
            ld hl,SAVEBUF
            ld (savep),hl
            ld hl,SCORE
            ld b,6
ng1:        ld (hl),0
            inc hl
            djnz ng1
            ld hl,ENEMS
            ld de,ENEMS+1
            ld bc,32+9+12-1
            ld (hl),0
            ldir
            call WAITVS             ; HUD panel (static labels + divider) in two vblanks
            ld hl,PANELIMG
            ld de,VRAM+24
            ld b,32
            call PANEL_ROWS
            call WAITVS
            ld b,32
            call PANEL_ROWS         ; HL/DE continue where they stopped
            ld a,1Fh
            ld (dirty),a
            ret

; ---------------------------------------------------------------------
; Main game loop
; ---------------------------------------------------------------------
GAME_LOOP:  call RESTORE_SPRITES
            call READ_INPUT
            call UPDATE_ALL
            call DRAW_ALL
            call PATCH_BLIT
            call WAITVS
            call PRESENT
            ld a,(gover)
            or a
            jr z,GAME_LOOP
            ret

PRESENT:    call BLIT_P1
            call BLIT_P2
            jp PANEL_UPDATE

PANEL_UPDATE:
            ld a,(dirty)
            or a
            ret z
            ld hl,dirty
            bit 0,a
            jr z,pu1
            res 0,(hl)
            ld hl,SCORE
            ld b,6
            ld de,VRAM+7*32+25
            ld ix,FONT_Y
            jp PRINT_IDX
pu1:        bit 1,a
            jr z,pu2
            res 1,(hl)
            ld hl,HISCORE
            ld b,6
            ld de,VRAM+20*32+25
            ld ix,FONT_Y
            jp PRINT_IDX
pu2:        bit 2,a
            jr z,pu3
            res 2,(hl)
            ld hl,STAGEBUF
            ld b,2
            ld de,VRAM+33*32+25
            ld ix,FONT_Y
            jp PRINT_IDX
pu3:        bit 3,a
            jr z,pu4
            res 3,(hl)
            jp DRAW_LIVES
pu4:        res 4,(hl)
            jp DRAW_LOOPS

DRAW_LIVES: ld c,0
dlv1:       ld a,c
            ld hl,lives
            cp (hl)
            ld hl,ICON
            jr c,dlv2
            ld hl,ICONBLANK
dlv2:       push hl
            ld hl,VRAM+41*32+25
            ld a,c
            add a,a
            ld e,a
            ld d,0
            add hl,de
            ex de,hl
            pop hl
            push bc
            ld b,5
            ld c,2
            call PUT_RECT
            pop bc
            inc c
            ld a,c
            cp 3
            jr c,dlv1
            ret

DRAW_LOOPS: ld hl,LOOPSTR
            ld c,0
dlp1:       ld a,c
            push hl
            ld hl,loops
            cp (hl)
            pop hl
            ld a,10
            jr nc,dlp2
            ld a,IDX_R
dlp2:       ld (hl),a
            inc hl
            inc c
            ld a,c
            cp 3
            jr c,dlp1
            ld hl,LOOPSTR
            ld b,3
            ld de,VRAM+57*32+25
            ld ix,FONT_Y
            jp PRINT_IDX

; ---------------------------------------------------------------------
; Game over
; ---------------------------------------------------------------------
GAME_OVER:  call UPDATE_HI
            ld a,2
            ld (dirty),a
            ld (plstate),a          ; 2 = player gone
            xor a
;#IF BOSS
            ld (bossact),a
;#END
            ld (gocnt),a
            ld (kheld),a
go_frame:   call TXT_RESTORE        ; undo in reverse order: the text was drawn last
            call RESTORE_SPRITES    ; the world keeps scrolling behind the text
            ld hl,tick
            inc (hl)
            call UPD_SCROLL
            call UPD_ENEMIES
            call UPD_EBULLETS
            call SPAWN_LOGIC
            call DRAW_ALL
            call DRAW_TXT
            call PATCH_BLIT
            call WAITVS
            call PRESENT
            ld a,(gocnt)
            cp 120
            jr nc,go_chk
            inc a
            ld (gocnt),a
            jr go_frame
go_chk:     ld a,(68EFh)            ; SPACE: must be released, then pressed
            and 10h
            jr z,go_pressed
            ld a,1
            ld (kheld),a
            jr go_frame
go_pressed: ld a,(kheld)
            or a
            jr z,go_frame
go4:        ld a,(68EFh)            ; wait for release before the title screen
            and 10h
            jr z,go4
            ret

; TXT_RESTORE - undo DRAW_TXT (LIFO)
TXT_RESTORE:
            ld a,(txtn)
            or a
            ret z
            ld b,a
            ld hl,(txtp)
txr1:       dec hl
            ld a,(hl)               ; original byte
            dec hl
            ld d,(hl)
            dec hl
            ld e,(hl)
            ld (de),a
            djnz txr1
            xor a
            ld (txtn),a
            ld hl,TXTSAVE
            ld (txtp),hl
            ret

; DRAW_TXT - OR the red "GAME OVER" glyph pixels into the map window
; (so the scrolling background stays visible around the letters)
DRAW_TXT:   ld hl,TXTSAVE
            ld (txtp),hl
            xor a
            ld (txtn),a
            ld a,TXTROW
            ld (t1),a               ; current row y
            xor a
            ld (t2),a               ; glyph row 0..4
dtx_row:    ld a,(t1)
            call MUL24
            ex de,hl
            ld hl,(W0)
            or a
            sbc hl,de               ; W0 - 24*y
            ld de,-9
            add hl,de               ; address of the first character byte
            ex de,hl
            ld a,1
            ld (t3),a               ; parity of the byte column
            ld hl,STR_GAMEOVER
dtx_ch:     ld a,(hl)
            cp 0FFh
            jr z,dtx_next
            push hl
            ld l,a
            add a,a
            add a,a
            add a,l                 ; 5 * glyph index
            ld hl,t2
            add a,(hl)
            ld l,a
            ld h,0
            push de
            ld de,FONT_Y
            add hl,de
            pop de
            ld a,(hl)               ; glyph row byte (yellow on blue)
            and 55h                 ; keep the set pixels
            ld b,a
            add a,a
            or b
            ld b,a                  ; B = both bits of each set pixel (red)
            ld hl,(txtp)
            ld a,(de)
            ld (hl),e
            inc hl
            ld (hl),d
            inc hl
            ld (hl),a               ; save the original byte
            inc hl
            ld (txtp),hl
            or b                    ; OR the text pixels in place
            ld (de),a
            ld hl,txtn
            inc (hl)
            pop hl
            inc hl
            ld a,(t3)
            or a
            jr nz,dtx_odd
            inc de
            ld a,1
            ld (t3),a
            jr dtx_ch
dtx_odd:    dec de
            dec de
            dec de
            xor a
            ld (t3),a
            jr dtx_ch
dtx_next:   ld hl,t1
            inc (hl)
            ld hl,t2
            inc (hl)
            ld a,(hl)
            cp 5
            jr c,dtx_row
            ret

UPDATE_HI:  ld hl,SCORE
            ld de,HISCORE
            ld b,6
uh1:        ld a,(de)
            cp (hl)
            jr c,uh_new
            jr nz,uh_done
            inc hl
            inc de
            djnz uh1
uh_done:    ret
uh_new:     ld hl,SCORE
            ld de,HISCORE
            ld bc,6
            ldir
            ret

; ---------------------------------------------------------------------
; Update
; ---------------------------------------------------------------------
UPDATE_ALL: ld hl,tick
            inc (hl)
            call UPD_SCROLL
            call UPD_PLAYER
            call UPD_PBULLETS
            call UPD_ENEMIES
;#IF BOSS
            call UPD_BOSS
;#END
            call UPD_EBULLETS
            call SPAWN_LOGIC
            jp COLLISIONS

UPD_SCROLL: ld hl,scrollc
            dec (hl)
            ret nz
            ld (hl),SCROLL_DIV
            ld a,(srow)
            or a
            jr z,us_wrap
            dec a
            ld (srow),a
            ld hl,(W0)
            ld de,24
            add hl,de
            ld (W0),hl
            ret
us_wrap:    ld a,MAPH-1
            ld (srow),a
            ld hl,WRAPW0
            ld (W0),hl
            ret

UPD_PLAYER: ld a,(firecd)
            or a
            jr z,up0
            dec a
            ld (firecd),a
up0:        ld a,(invuln)
            or a
            jr z,up1
            dec a
            ld (invuln),a
up1:        ld a,(loopt)
            or a
            jr z,up2
            dec a
            ld (loopt),a
up2:        ld a,(plstate)
            or a
            jr z,up_alive
            ld hl,plexp
            dec (hl)
            ret nz
            ld a,(lives)
            or a
            jr nz,up_resp
            ld a,1
            ld (gover),a
            ret
up_resp:    xor a
            ld (plstate),a
            ld a,44
            ld (px),a
            ld a,50
            ld (py),a
            ld a,120
            ld (invuln),a
            ret
up_alive:   ld a,(inkeys)
            ld b,a
            bit 2,b
            jr z,upr
            ld a,(px)
            or a
            jr z,upr
            dec a
            ld (px),a
upr:        bit 3,b
            jr z,upu
            ld a,(px)
            cp 87
            jr nc,upu
            inc a
            ld (px),a
upu:        bit 0,b
            jr z,upd
            ld a,(py)
            or a
            jr z,upd
            dec a
            ld (py),a
upd:        bit 1,b
            jr z,upf
            ld a,(py)
            cp 56
            jr nc,upf
            inc a
            ld (py),a
upf:        bit 4,b
            jr z,upl
            ld a,(firecd)
            or a
            jr nz,upl
            call FIRE_PB
upl:        bit 5,b
            ret z
            ld a,(loopt)
            or a
            ret nz
            ld a,(loops)
            or a
            ret z
            dec a
            ld (loops),a
            ld a,48
            ld (loopt),a
            ld hl,dirty
            set 4,(hl)
            ret

FIRE_PB:    push bc
            ld hl,PBULS
            ld b,MAXPB
fp1:        ld a,(hl)
            or a
            jr z,fp2
            inc hl
            inc hl
            inc hl
            djnz fp1
            pop bc
            ret
fp2:        ld (hl),1
            inc hl
            ld a,(px)
            ld (hl),a
            inc hl
            ld a,(py)
            sub 2
            ld (hl),a
            ld a,8
            ld (firecd),a
            call SFX_FIRE
            pop bc
            ret

UPD_PBULLETS:
            ld ix,PBULS
            ld b,MAXPB
upb:        ld a,(ix+0)
            or a
            jr z,upbn
            ld a,(ix+2)
            sub 2
            ld (ix+2),a
            bit 7,a
            jr z,upbn
            cp 0FFh
            jr z,upbn
            ld (ix+0),0
upbn:       ld de,3
            add ix,de
            djnz upb
            ret

UPD_ENEMIES:
            ld ix,ENEMS
            ld b,MAXE
ue_loop:    ld a,(ix+0)
            or a
            jp z,ue_next
            cp 1
            jp z,ue_alive
            dec (ix+4)              ; exploding
            jp nz,ue_next
            inc (ix+0)
            ld a,(ix+0)
            cp 5
            jr nc,ue_free
            ld (ix+4),EXP_TICKS
            jp ue_next
ue_free:    ld (ix+0),0
            jp ue_next
ue_alive:   ld a,(tick)
            and 3
            cp 3
            jr z,ue_noy
            inc (ix+2)
ue_noy:     ld (ix+6),0
            ld a,(ix+3)
            or a
            jr z,ue_xdone
            cp 1
            jr nz,ue_t2
            ld a,(ix+2)
            bit 7,a
            jr nz,ue_xdone          ; not on screen yet
            inc (ix+4)              ; type 1: sway
            ld a,(ix+4)
            rrca
            rrca
            and 0Fh
            ld e,a
            ld d,0
            ld hl,SWAYTAB
            add hl,de
            ld a,(hl)
            ld (ix+6),a
            jr ue_dx
ue_t2:      ld a,(ix+2)             ; type 2: dive at the player
            bit 7,a
            jr nz,ue_xdone
            cp 8
            jr c,ue_xdone
            ld a,(tick)
            and 1
            jr nz,ue_xdone
            inc (ix+2)
            ld a,(px)
            cp (ix+1)
            jr z,ue_xdone
            ld a,1
            jr nc,ue_t2s
            ld a,0FFh
ue_t2s:     ld (ix+6),a
ue_dx:      ld a,(ix+1)
            add a,(ix+6)
            bit 7,a
            jr z,ue_c1
            xor a
ue_c1:      cp 88
            jr c,ue_c2
            ld a,87
ue_c2:      ld (ix+1),a
ue_xdone:   ld a,(ix+2)
            bit 7,a
            jr nz,ue_shoot
            cp 64
            jr c,ue_shoot
            ld (ix+0),0
            jr ue_next
ue_shoot:   dec (ix+5)
            jr nz,ue_next
            call ENEMY_FIRE
ue_next:    ld de,8
            add ix,de
            dec b
            jp nz,ue_loop
            ret

ENEMY_FIRE: push bc
            call RND
            and 7Fh
            add a,70
            ld (ix+5),a
            ld a,(ix+2)
            bit 7,a
            jr nz,ef_ret
            cp 40
            jr nc,ef_ret
            ld hl,EBULS
            ld b,MAXEB
ef1:        ld a,(hl)
            or a
            jr z,ef_found
            inc hl
            inc hl
            inc hl
            inc hl
            djnz ef1
ef_ret:     pop bc
            ret
ef_found:   ld (hl),1
            inc hl
            ld a,(ix+1)
            ld (hl),a
            inc hl
            ld a,(ix+2)
            add a,6
            ld (hl),a
            inc hl
            ld a,(ix+3)
            or a
            jr z,ef_dx0
            ld a,(px)
            cp (ix+1)
            jr z,ef_dx0
            ld a,1
            jr nc,ef_sdx
            ld a,0FFh
ef_sdx:     ld (hl),a
            jr ef_ret
ef_dx0:     ld (hl),0
            jr ef_ret

UPD_EBULLETS:
            ld ix,EBULS
            ld b,MAXEB
ueb:        ld a,(ix+0)
            or a
            jr z,uebn
            ld a,(tick)
            and 3
            jr z,ueb_x
            inc (ix+2)
ueb_x:      ld a,(tick)
            and 1
            jr nz,ueb_y
            ld a,(ix+1)
            add a,(ix+3)
            cp 88
            jr nc,ueb_kill
            ld (ix+1),a
ueb_y:      ld a,(ix+2)
            bit 7,a
            jr nz,uebn
            cp 64
            jr c,uebn
ueb_kill:   ld (ix+0),0
uebn:       ld de,4
            add ix,de
            djnz ueb
            ret

SPAWN_LOGIC:
;#IF BOSS
            ld a,(bossact)
            or a
            ret nz                  ; no ordinary waves during the boss fight
            ld a,(kills)
            cp BOSS_KILLS
            jr c,sl_norm
            ld ix,ENEMS             ; boss is due: wait for clear skies
            ld b,MAXE
sl_chk:     ld a,(ix+0)
            or a
            ret nz
            ld de,8
            add ix,de
            djnz sl_chk
            jp BOSS_START
;#END
sl_norm:    ld hl,spawncd
            dec (hl)
            ret nz
            ld ix,ENEMS
            ld b,MAXE
            ld c,0
sl1:        ld a,(ix+0)
            or a
            jr nz,sl2
            inc c
sl2:        ld de,8
            add ix,de
            djnz sl1
            ld a,c
            or a
            jr nz,sl3
            ld a,20
            ld (spawncd),a
            ret
sl3:        ld (t5),a               ; free slots
            cp 3
            jr c,sl4
            ld a,3
sl4:        ld (t1),a               ; formation size
            call RND
            and 3Fh
            cp 56
            jr c,sl5
            sub 56
sl5:        add a,8
            ld (t2),a               ; x of first plane
            call RND
            and 3
            cp 3
            jr nz,sl6
            ld a,1
sl6:        ld c,a
            ld a,(stage)
            cp 2
            jr nc,sl7
            ld a,c
            cp 2
            jr nz,sl7
            ld c,1
sl7:        ld a,c
            ld (t3),a               ; type
            xor a
            ld (t4),a               ; formation 0: three abreast
            call RND
            and 3
            jr nz,sl_fill
            ld a,1                  ; 1 time in 4: a FILE of bombers, one after another,
            ld (t4),a               ; lined up on the player's position
            ld a,(px)
            ld (t2),a
            ld a,(stage)
            cp 2
            ld a,0
            jr c,sl_ft
            call RND
            and 2                   ; straight or diving
sl_ft:      ld (t3),a
            ld a,(t5)
            cp 5
            jr c,sl_fn
            ld a,4
sl_fn:      ld (t1),a
sl_fill:    ld ix,ENEMS
            ld b,MAXE
            ld c,0                  ; formation index
sl8:        ld a,(ix+0)
            or a
            jr nz,sl9
            ld a,(t1)
            cp c
            jr z,sl_done
            ld (ix+0),1
            ld a,(t4)
            or a
            jr nz,sl_file
            ld a,c
            add a,a
            add a,a
            ld e,a
            add a,a
            add a,e                 ; 12*c
            ld e,a
            ld a,(t2)
            add a,e
            ld (ix+1),a
            ld (ix+2),0F8h          ; y = -8
            jr sl_com
sl_file:    ld a,(t2)
            ld (ix+1),a
            ld a,c
            add a,a
            ld e,a
            add a,a
            add a,a
            add a,a
            sub e                   ; 14*c rows apart
            ld e,a
            ld a,0F8h
            sub e
            ld (ix+2),a
sl_com:     ld a,(t3)
            ld (ix+3),a
            ld (ix+4),0
            ld a,c
            add a,a
            add a,a
            add a,a
            add a,60
            ld (ix+5),a
            ld (ix+6),0
            inc c
sl9:        ld de,8
            add ix,de
            djnz sl8
sl_done:
;#IF BOSS
;#ELSE
            ld hl,wavecnt           ; no boss in this build: a new stage every 10 waves
            inc (hl)
            ld a,(hl)
            cp 10
            jr c,sl_wv
            ld (hl),0
            call NEXT_STAGE
sl_wv:
;#END
            call RND
            and 3Fh
            ld (t1),a
            ld a,(stage)
            ld b,a
            add a,a
            add a,b
            add a,a                 ; stage*6
            cp 50
            jr c,sl_c2
            ld a,50
sl_c2:      ld b,a
            ld a,130
            sub b
            ld hl,t1
            add a,(hl)
            ld (spawncd),a
            ret

;#IF BOSS
; ---------------------------------------------------------------------
; Boss
; ---------------------------------------------------------------------
BOSS_START: ld a,1
            ld (bossact),a
            ld a,34
            ld (bossx),a
            ld a,0F0h
            ld (bossy),a
            ld a,1
            ld (bossdir),a
            ld a,90
            ld (bossfire),a
            ld a,(bossnum)
            cp 10
            jr c,bs1
            ld a,10
bs1:        ld b,a
            add a,a
            add a,a
            add a,b                 ; 5 * boss number
            add a,20
            ld (bosshp),a
            ld b,12
            ld c,40
            jp BEEP                 ; low warning rumble

UPD_BOSS:   ld a,(bossact)
            or a
            ret z
            cp 2
            jr z,ubd
            ld a,(bossy)
            cp 4
            jr z,ub_mv
            ld a,(tick)             ; fly in slowly
            and 1
            ret nz
            ld hl,bossy
            inc (hl)
            ret
ub_mv:      ld a,(tick)
            and 1
            jr nz,ub_fire
            ld a,(bossx)
            ld hl,bossdir
            add a,(hl)
            ld (bossx),a
            cp 69
            jr c,ub_l
            ld a,0FFh
            ld (bossdir),a
            jr ub_fire
ub_l:       or a
            jr nz,ub_fire
            ld a,1
            ld (bossdir),a
ub_fire:    ld hl,bossfire
            dec (hl)
            ret nz
            ld a,(stage)
            ld b,a
            add a,a
            add a,b
            cp 31
            jr c,ub_f2
            ld a,30
ub_f2:      ld b,a
            ld a,70
            sub b
            ld (bossfire),a
            jp BOSS_FIRE
ubd:        ld hl,bossexp           ; exploding
            dec (hl)
            jr z,ub_done
            ld a,(hl)
            and 15
            ret nz
            jp SFX_EXPL
ub_done:    ld b,5                  ; +5000
ub_sc:      push bc
            ld a,10
            call ADD_SCORE
            pop bc
            djnz ub_sc
            xor a
            ld (kills),a
            ld (bossact),a
            ld hl,bossnum
            inc (hl)
            ld a,90
            ld (spawncd),a
            jp NEXT_STAGE

; BOSS_FIRE - a volley of three bullets (left, straight, right)
BOSS_FIRE:  ld c,0FFh
bf_loop:    ld hl,EBULS
            ld b,MAXEB
bf1:        ld a,(hl)
            or a
            jr z,bf_found
            inc hl
            inc hl
            inc hl
            inc hl
            djnz bf1
            ret
bf_found:   ld (hl),1
            inc hl
            ld a,(bossx)
            add a,9
            ld (hl),a
            inc hl
            ld a,(bossy)
            add a,14
            ld (hl),a
            inc hl
            ld (hl),c
            inc c
            ld a,c
            cp 2
            jr nz,bf_loop
            ret

;#END
NEXT_STAGE: ld a,(stage)
            cp 99
            jr z,ns1
            inc a
            ld (stage),a
ns1:        ld b,0
ns2:        sub 10
            jr c,ns3
            inc b
            jr ns2
ns3:        add a,10
            ld c,a
            ld a,b
            ld (STAGEBUF),a
            ld a,c
            ld (STAGEBUF+1),a
            ld a,(loops)
            cp 3
            jr nc,ns4
            inc a
            ld (loops),a
ns4:        ld hl,dirty
            set 2,(hl)
            set 4,(hl)
            ret

ADD_SCORE:  ld b,4
            ld hl,SCORE+3
asc1:       add a,(hl)
            cp 10
            jr c,asc2
            sub 10
            ld (hl),a
            ld a,1
            dec hl
            djnz asc1
            ret
asc2:       ld (hl),a
            ld hl,dirty
            set 0,(hl)
            ret

COLLISIONS: ld iy,PBULS             ; player bullets vs enemies
            ld c,MAXPB
cb1:        ld a,(iy+0)
            or a
            jp z,cb_next
            ld ix,ENEMS
            ld b,MAXE
cb2:        ld a,(ix+0)
            cp 1
            jr nz,cb2n
            ld a,(iy+1)
            sub (ix+1)
            jr nc,cb3
            neg
cb3:        cp 7
            jr nc,cb2n
            ld a,(iy+2)
            sub (ix+2)
            add a,1
            cp 8
            jr nc,cb2n
            ld (iy+0),0
            ld (ix+0),2
            ld (ix+4),EXP_TICKS
            push bc
            ld a,1
            call ADD_SCORE
;#IF BOSS
            ld hl,kills
            inc (hl)
;#END
            call SFX_EXPL
            pop bc
            jp cb_next
cb2n:       ld de,8
            add ix,de
            djnz cb2
;#IF BOSS
            ld a,(bossact)          ; this bullet against the boss
            cp 1
            jp nz,cb_next
            ld a,(bossy)
            bit 7,a
            jp nz,cb_next
            ld a,(iy+1)
            ld hl,bossx
            sub (hl)
            add a,8
            cp 35
            jp nc,cb_next
            ld a,(iy+2)
            ld hl,bossy
            sub (hl)
            add a,1
            cp 17
            jp nc,cb_next
            ld (iy+0),0
            ld hl,bosshp
            dec (hl)
            jr nz,cb_bhit
            ld a,2                  ; boss destroyed
            ld (bossact),a
            ld a,60
            ld (bossexp),a
cb_bhit:    push bc
            ld b,2
            ld c,3
            call BEEP
            pop bc
;#END
cb_next:    ld de,3
            add iy,de
            dec c
            jp nz,cb1
            ld a,(plstate)          ; player vs enemies / enemy bullets
            or a
            ret nz
            ld a,(invuln)
            ld b,a
            ld a,(loopt)
            or b
            ret nz
            ld ix,ENEMS
            ld b,MAXE
cp1:        ld a,(ix+0)
            cp 1
            jr nz,cp1n
            ld a,(px)
            sub (ix+1)
            jr nc,cp2
            neg
cp2:        cp 8
            jr nc,cp1n
            ld a,(py)
            sub (ix+2)
            jr nc,cp3
            neg
cp3:        cp 7
            jr nc,cp1n
            ld (ix+0),2
            ld (ix+4),EXP_TICKS
            jp PLAYER_HIT
cp1n:       ld de,8
            add ix,de
            djnz cp1
;#IF BOSS
            ld a,(bossact)          ; player against the boss
            cp 1
            jr nz,cp_nb
            ld a,(px)
            ld hl,bossx
            sub (hl)
            add a,8
            cp 35
            jr nc,cp_nb
            ld a,(py)
            ld hl,bossy
            sub (hl)
            add a,7
            cp 23
            jr nc,cp_nb
            jp PLAYER_HIT
cp_nb:
;#END
            ld ix,EBULS
            ld b,MAXEB
cq1:        ld a,(ix+0)
            or a
            jr z,cq1n
            ld a,(ix+1)
            ld hl,px
            sub (hl)
            add a,3
            cp 7
            jr nc,cq1n
            ld a,(ix+2)
            ld hl,py
            sub (hl)
            add a,1
            cp 9
            jr nc,cq1n
            ld (ix+0),0
            jp PLAYER_HIT
cq1n:       ld de,4
            add ix,de
            djnz cq1
            ret

PLAYER_HIT: ld a,1
            ld (plstate),a
            ld a,60
            ld (plexp),a
            ld hl,lives
            dec (hl)
            ld hl,dirty
            set 3,(hl)
            jp SFX_EXPL

; ---------------------------------------------------------------------
; Sprite engine
; ---------------------------------------------------------------------
DRAW_ALL:
;#IF BOSS
            call DRAW_BOSS
;#END
            ld ix,ENEMS
            ld b,MAXE
da1:        ld a,(ix+0)
            or a
            jr z,da1n
            cp 1
            jr nz,da_exp
            ld a,(ix+6)
            or a
            ld hl,SPR_EN0
            jr z,da_dr
            bit 7,a
            ld hl,SPR_ENR
            jr z,da_dr
            ld hl,SPR_ENL
            jr da_dr
da_exp:     sub 2
            add a,a
            ld e,a
            ld d,0
            ld hl,EXPTAB
            add hl,de
            ld e,(hl)
            inc hl
            ld d,(hl)
            ex de,hl
da_dr:      push bc
            ld b,(ix+1)
            ld c,(ix+2)
            call DRAW_SPRITE
            pop bc
da1n:       ld de,8
            add ix,de
            djnz da1
            ld ix,PBULS
            ld b,MAXPB
da2:        ld a,(ix+0)
            or a
            jr z,da2n
            push bc
            ld hl,SPR_PB
            ld b,(ix+1)
            ld c,(ix+2)
            call DRAW_SPRITE
            pop bc
da2n:       ld de,3
            add ix,de
            djnz da2
            ld ix,EBULS
            ld b,MAXEB
da3:        ld a,(ix+0)
            or a
            jr z,da3n
            push bc
            ld hl,SPR_EB
            ld b,(ix+1)
            ld c,(ix+2)
            call DRAW_SPRITE
            pop bc
da3n:       ld de,4
            add ix,de
            djnz da3
            ld a,(plstate)          ; player last (on top)
            cp 2
            ret z                   ; game over: no player
            or a
            jr nz,da_pexp
            ld a,(invuln)
            or a
            jr z,da_pshow
            ld a,(tick)
            and 2
            ret z                   ; blink while invulnerable
da_pshow:   ld a,(loopt)
            or a
            jr nz,da_lp
            ld a,(inkeys)           ; banking: the wing on the side we turn towards drops away
            and 0Ch
            ld e,0
            cp 04h
            jr nz,da_b2
            ld e,3                  ; diving left: left wing removed
            jr da_pf
da_b2:      cp 08h
            jr nz,da_pf
            ld e,4                  ; diving right: right wing removed
            jr da_pf
da_lp:      rrca
            rrca
            rrca
            and 1Fh
            ld e,a
            ld d,0
            ld hl,LOOPFR
            add hl,de
            ld e,(hl)
da_pf:      ld a,e
            add a,a
            ld e,a
            ld d,0
            ld hl,PLTAB
            add hl,de
            ld e,(hl)
            inc hl
            ld d,(hl)
            ex de,hl
da_pdr:     ld a,(px)
            ld b,a
            ld a,(py)
            ld c,a
            jp DRAW_SPRITE
da_pexp:    ld a,(plexp)
            ld hl,SPR_EX0
            cp 40
            jr nc,da_pdr
            ld hl,SPR_EX1
            cp 20
            jr nc,da_pdr
            ld hl,SPR_EX2
            jr da_pdr

;#IF BOSS
DRAW_BOSS:  ld a,(bossact)
            or a
            ret z
            cp 2
            jr z,db_exp
            ld hl,BOSSTAB
            ld b,6
db1:        push bc
            push hl
            ld a,(bossx)
            add a,(hl)
            ld d,a
            inc hl
            ld a,(bossy)
            add a,(hl)
            ld e,a
            inc hl
            ld c,(hl)
            inc hl
            ld h,(hl)
            ld l,c
            ld b,d
            ld c,e
            call DRAW_SPRITE
            pop hl
            ld de,4
            add hl,de
            pop bc
            djnz db1
            ret
db_exp:     xor a                   ; three overlapping explosions over the wreck
            ld (t1),a
dbe1:       ld a,(bossexp)
            rrca
            rrca
            rrca
            and 3
            ld hl,t1
            add a,(hl)
dbe2:       cp 3
            jr c,dbe3
            sub 3
            jr dbe2
dbe3:       add a,a
            ld e,a
            ld d,0
            ld hl,EXPTAB
            add hl,de
            ld e,(hl)
            inc hl
            ld d,(hl)
            push de                 ; sprite descriptor
            ld a,(t1)
            add a,a
            ld e,a
            ld d,0
            ld hl,BEXPOFF
            add hl,de
            ld a,(bossx)
            add a,(hl)
            ld b,a
            inc hl
            ld a,(bossy)
            add a,(hl)
            ld c,a
            pop hl
            call DRAW_SPRITE
            ld hl,t1
            inc (hl)
            ld a,(hl)
            cp 3
            jr c,dbe1
            ret

;#END
; MUL24  A = y (0..63)  ->  HL = 24*y   (clobbers DE)
MUL24:      ld l,a
            ld h,0
            add hl,hl
            add hl,hl
            add hl,hl               ; 8y
            ld d,h
            ld e,l
            add hl,hl               ; 16y
            add hl,de               ; 24y
            ret

; DRAW_SPRITE  HL = descriptor, B = x pixel (0..87), C = y row (signed)
DRAW_SPRITE:
            ld a,b
            ld (ds_x),a
            ld a,(hl)
            ld (ds_h),a
            inc hl
            ld (ds_tab),hl
            ld a,c
            ld d,0
            bit 7,a
            jr z,dsy1
            neg
            ld d,a                  ; rows hidden above the screen
            ld a,(ds_h)
            sub d
            ret z
            ret c
            ld e,a
            ld c,0
            jr dsy2
dsy1:       ld a,(ds_h)
            ld e,a
dsy2:       ld a,c
            cp 64
            ret nc
            add a,e
            cp 65
            jr c,dsy3
            ld a,64
            sub c
            ld e,a
dsy3:       ld a,d
            ld (ds_skip),a
            ld a,e
            ld (ds_rows),a
            ld a,c                  ; dest = W0 - 24*y - 2*(x>>3)
            call MUL24
            ex de,hl
            ld hl,(W0)
            or a
            sbc hl,de
            ld a,(ds_x)
            rrca
            rrca
            rrca
            and 1Fh
            add a,a
            ld e,a
            ld d,0
            or a
            sbc hl,de
            ex de,hl                ; DE = destination of first visible row
            ld a,(ds_x)             ; data pointer for this pixel shift
            and 7
            add a,a
            ld l,a
            ld h,0
            ld bc,(ds_tab)
            add hl,bc
            ld c,(hl)
            inc hl
            ld b,(hl)
            ld h,b
            ld l,c
            ld a,(ds_skip)
            or a
            jr z,dsd1
            ld b,a
dssk:       ld a,l
            add a,8
            ld l,a
            jr nc,dssk2
            inc h
dssk2:      djnz dssk
dsd1:       push hl
            ld hl,(savep)
            ld (hl),e
            inc hl
            ld (hl),d
            inc hl
            ld a,(ds_rows)
            ld (hl),a
            inc hl
            ld b,h
            ld c,l                  ; BC = save data pointer
            push bc
            ld bc,SLOT-3
            add hl,bc
            ld (savep),hl
            pop bc
            ld hl,nsaved
            inc (hl)
            pop hl                  ; HL = sprite data
dsrow:      ld a,(de)               ; image byte 0 at A
            ld (bc),a
            inc bc
            and (hl)
            inc hl
            or (hl)
            inc hl
            ld (de),a
            inc de
            ld a,(de)               ; byte 1 at A+1
            ld (bc),a
            inc bc
            and (hl)
            inc hl
            or (hl)
            inc hl
            ld (de),a
            dec de
            dec de
            dec de
            ld a,(de)               ; byte 2 at A-2
            ld (bc),a
            inc bc
            and (hl)
            inc hl
            or (hl)
            inc hl
            ld (de),a
            inc de
            ld a,(de)               ; byte 3 at A-1
            ld (bc),a
            inc bc
            and (hl)
            inc hl
            or (hl)
            inc hl
            ld (de),a
            ld a,e                  ; next row is 24 bytes lower
            sub 23
            ld e,a
            jr nc,dsr2
            dec d
dsr2:       ld a,(ds_rows)
            dec a
            ld (ds_rows),a
            jr nz,dsrow
            ret

; RESTORE_SPRITES - put back the background under last frame's sprites (LIFO)
RESTORE_SPRITES:
            ld a,(nsaved)
            or a
            ret z
            ld b,a
            ld hl,(savep)
rs_slot:    ld de,-SLOT
            add hl,de
            push hl
            push bc
            ld e,(hl)
            inc hl
            ld d,(hl)
            inc hl
            ld b,(hl)               ; rows
            inc hl
rs_row:     ld a,(hl)
            inc hl
            ld (de),a
            inc de
            ld a,(hl)
            inc hl
            ld (de),a
            dec de
            dec de
            dec de
            ld a,(hl)
            inc hl
            ld (de),a
            inc de
            ld a,(hl)
            inc hl
            ld (de),a
            ld a,e
            sub 23
            ld e,a
            jr nc,rs_r2
            dec d
rs_r2:      djnz rs_row
            pop bc
            pop hl
            djnz rs_slot
            ld hl,SAVEBUF
            ld (savep),hl
            xor a
            ld (nsaved),a
            ret


;#IF MUSIC
; ---------------------------------------------------------------------
; 4 channel 1-bit music engine (title screen only)
;  Each channel is a square wave from a 16 bit phase accumulator; the four
;  channels are time-sliced into the speaker latch (+1/-1 on bits 0/5), so the
;  speaker's own low-pass filtering mixes them.  One call to MUS_TICK renders
;  SAMPLE_ITERS*2 samples (~16 ms) after advancing the note streams.
;  Streams: pairs of (note,duration in ticks); note = MIDI number (24..96),
;  0 = rest, $FE = noise (random pitch every tick), $FF = loop to the start.
;  ch0 phase HL/step DE, ch1 HL'/DE', ch2 IX/BC, ch3 IY/BC'.
; ---------------------------------------------------------------------
SAMPLE_ITERS equ 100
MCH         equ MUSVARS             ; 4 x 10 bytes: ptr,remain,kind,step,phase,start

MUS_INIT:   ld hl,MCH
            ld de,MCH+1
            ld bc,39
            ld (hl),0
            ldir
            ld hl,MUSSTARTS
            ld ix,MCH
            ld b,4
mi1:        ld e,(hl)
            inc hl
            ld d,(hl)
            inc hl
            ld (ix+0),e
            ld (ix+1),d
            ld (ix+8),e
            ld (ix+9),d
            ld (ix+2),1
            ld de,10
            add ix,de
            djnz mi1
            ret

MUS_TICK:   ld ix,MCH
            ld b,4
mt_ch:      dec (ix+2)
            jr nz,mt_chk
            ld l,(ix+0)
            ld h,(ix+1)
            ld a,(hl)
            cp 0FFh
            jr nz,mt_nf
            ld l,(ix+8)             ; end of stream: loop
            ld h,(ix+9)
            ld a,(hl)
mt_nf:      inc hl
            ld c,(hl)
            inc hl
            ld (ix+0),l
            ld (ix+1),h
            ld (ix+2),c
            ld (ix+3),0
            or a
            jr z,mt_rest
            cp 0FEh
            jr z,mt_noise
            sub 24
            add a,a
            ld e,a
            ld d,0
            ld hl,PITCHTAB
            add hl,de
            ld e,(hl)
            inc hl
            ld d,(hl)
            ld (ix+4),e
            ld (ix+5),d
            jr mt_chk
mt_rest:    ld (ix+4),0
            ld (ix+5),0
            ld (ix+6),0
            ld (ix+7),0
            jr mt_chk
mt_noise:   ld (ix+3),1
mt_chk:     ld a,(ix+3)
            or a
            jr z,mt_nx
            push bc
            call RND
            ld (ix+4),a
            call RND
            or 40h
            ld (ix+5),a
            pop bc
mt_nx:      ld de,10
            add ix,de
            djnz mt_ch
            ld hl,(MCH+6)           ; load the phase/step registers
            ld de,(MCH+4)
            exx
            ld hl,(MCH+16)
            ld de,(MCH+14)
            ld bc,(MCH+34)
            exx
            ld bc,(MCH+24)
            ld ix,(MCH+26)
            ld iy,(MCH+36)
            ld a,SAMPLE_ITERS
            ld (mcnt),a
ml_loop:
@SAMPLE@
@SAMPLE@
            ld a,(mcnt)
            dec a
            ld (mcnt),a
            jp nz,ml_loop
            ld (MCH+6),hl
            ld (MCH+26),ix
            ld (MCH+36),iy
            exx
            ld (MCH+16),hl
            exx
            ld a,08h
            ld (LATCH),a
            ret

;#END
; ---------------------------------------------------------------------
; Unrolled blitter - generated by build_1942.py
; ---------------------------------------------------------------------
@BLIT@

; ---------------------------------------------------------------------
; Tables and data
; ---------------------------------------------------------------------
;#IF MUSIC
PITCHTAB:
@PITCH@
MUSSTARTS:  defw MUS_CH0,MUS_CH1,MUS_CH2,MUS_CH3
@MUSDATA@
;#END
SWAYTAB:    defb 0,1,1,1,1,0,0,0,0,0FFh,0FFh,0FFh,0FFh,0,0,0
LOOPFR:     defb 0,1,2,2,1,0,0,0
PLTAB:      defw SPR_PL0,SPR_PL1,SPR_PL2,SPR_PLL,SPR_PLR
;#IF BOSS
BOSSTAB:    defb 0,0
            defw SPR_BS0
            defb 9,0
            defw SPR_BS1
            defb 18,0
            defw SPR_BS2
            defb 0,8
            defw SPR_BS3
            defb 9,8
            defw SPR_BS4
            defb 18,8
            defw SPR_BS5
BEXPOFF:    defb 4,2,14,6,8,10
;#END
EXPTAB:     defw SPR_EX0,SPR_EX1,SPR_EX2
STR_PRESS:  defb @STR_PRESS@
STR_K1:     defb @STR_K1@
STR_K2:     defb @STR_K2@
STR_K3:     defb @STR_K3@
STR_JOY_OFF: defb @STR_JOY_OFF@
STR_JOY_ON:  defb @STR_JOY_ON@
STR_GAMEOVER: defb @STR_GAMEOVER@
ICON:
@ICON@
ICONBLANK:  defb 0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh,0AAh
BIGDIGITS:
@BIGDIGITS@
FONT_Y:
@FONT_Y@
PANELIMG:
@PANEL@
@SPRITES@
MAPDATA:
@MAP@
; ---------------------------------------------------------------------
; RAM variables (not part of the file)
; ---------------------------------------------------------------------
VARS        equ $
@VARS@
STACKTOP    equ VEND+160
