; ===========================================================================
;  KARATEKA  -  for the VZ200 / VZ300      (tribute to the Apple ][e original)
;  Video  : Australian VZ200 256x192 mono, CSS0 (OUT (32),28/29/30 + latch=8)
;  Origin : $7B00   (Ben Venn SD Loader style: RAM $7B00-$FFFF; moved down from $8000 to make room for the new sprites)
;
;  Controls   O / P  : walk left / right        SPACE (or ENTER): fight stance on/off
;             Q A Z  : high / mid / low punch   W S X : high / mid / low kick
;  (punches and kicks only work in fight stance - run into a guard and he hits you for double!)
;
;  Assemble:  sjasmplus --raw=KARATEKA.bin karateka.asm   then wrap with the 24 byte .VZ header
;  Data:      kar_sprites.inc kar_font.inc kar_scenes.inc  (made by gen_data.py / gen_sprites.py)
; ===========================================================================
        ORG $7B00

VRAM    EQU $7000
LATCH   EQU $6800
GFXVAL  EQU 8                   ; latch value: A/G=1, CSS=0
BANDTOP EQU 108                 ; first screen line of the redrawn action band (64 lines)
GROUNDY EQU 160                 ; screen line of the fighters' feet
STACKTOP EQU $FFF0

; fighter structure
F_X     EQU 0
F_DIR   EQU 1                   ; 0 = faces right, 1 = faces left
F_HP    EQU 2
F_MODE  EQU 3                   ; 0 = walk/run, 1 = fight stance
F_ACT   EQU 4
F_PH    EQU 5
F_FRAME EQU 6
F_HIT   EQU 7
F_COOL  EQU 8
F_RUN   EQU 9
F_STYLE EQU 10
F_ATK   EQU 11
F_ACTIVE EQU 12
F_ISPL  EQU 13
F_Y     EQU 14                  ; height above the ground (hawk)
F_TYPE  EQU 15                  ; 0 = karateka/guard, 1 = hawk, 2 = Mariko

ACT_IDLE EQU 0
ACT_ATK  EQU 1
ACT_HIT  EQU 2
ACT_FALL EQU 3
ACT_DEAD EQU 4
ACT_BOW  EQU 5

FR_STAND EQU 0
FR_FIGHT EQU 1
FR_RUN0  EQU 2
FR_HIT   EQU 18
FR_FALL  EQU 19
FR_DEAD  EQU 20
FR_BOW   EQU 21
FR_FSTEP EQU 22
FR_DIVE  EQU 3

ST_CLIFF EQU 0
ST_FIGHT EQU 1

REACH_P  EQU 25
REACH_K  EQU 31
XMIN     EQU 44
XMAX     EQU 200

START:  DI
        LD SP,STACKTOP
        CALL GFXON
        CALL INITREV
MAINLP: LD A,(SEED)
        OR A
        JR NZ,ML1
        LD A,$A7
        LD (SEED),A
ML1:    CALL TITLESCR
        CALL INTROCUT
        CALL NEWGAME
GAMELP: CALL GETKEYS
        CALL UPDATE
        LD A,(RESTART)
        OR A
        JR NZ,MAINLP
        CALL RENDER
        CALL VSYNC
        CALL BLITBAND
        LD A,(HUDDIRTY)
        OR A
        CALL NZ,DRAWHUD
        JR GAMELP

; ---------------------------------------------------------------- graphics
GFXON:  LD A,28
        OUT (32),A
        LD A,GFXVAL
        LD (LATCH),A
        ; probe: can the CPU read the video RAM back?  (needed by the scrolling transition)
        LD A,2
        CALL SELBANK
        LD A,$5A
        LD (VRAM+2047),A
        LD A,(VRAM+2047)
        CP $5A
        JR NZ,PR_NO
        LD A,$A5
        LD (VRAM+2047),A
        LD A,(VRAM+2047)
        CP $A5
        JR NZ,PR_NO
        XOR A
        LD (VRAM+2047),A
        LD A,1
        LD (VRAMRD),A
        RET
PR_NO:  XOR A
        LD (VRAMRD),A
        RET

INITREV:                        ; build the 256-byte bit-reverse table
        LD HL,REVLUT
        LD C,0
IR1:    LD D,C
        LD A,1
IR2:    RR D
        RLA
        JR NC,IR2
        LD (HL),A
        INC HL
        INC C
        JR NZ,IR1
        RET

SELBANK:                        ; A = 0..2 (lines 0-63 / 64-127 / 128-191)
        ADD A,28
        OUT (32),A
        LD A,GFXVAL
        LD (LATCH),A
        RET

VSYNC:  LD HL,LATCH             ; bit 7 of $6800 = frame sync: wait for a rising edge
        LD BC,20000
VS1:    BIT 7,(HL)
        JR Z,VS2
        DEC BC
        LD A,B
        OR C
        JR NZ,VS1
VS2:    LD BC,20000
VS3:    BIT 7,(HL)
        RET NZ
        DEC BC
        LD A,B
        OR C
        JR NZ,VS3
        RET

UNRLE:  LD A,(HL)               ; HL = src stream, DE = dest
        INC HL
        OR A
        RET Z
        JP M,UR_RUN
        LD C,A
        LD B,0
        LDIR
        JR UNRLE
UR_RUN: AND $7F
        ADD A,2
        LD B,A
        LD A,(HL)
        INC HL
UR_L:   LD (DE),A
        INC DE
        DJNZ UR_L
        JR UNRLE

LOADSCENE:                      ; A = 0 cliff, 1 gate, 2 palace (fight room), 3 title, 4-5 intro cuts, 6 Mariko's cell
        LD L,A
        LD H,0
        ADD HL,HL
        LD E,L
        LD D,H
        ADD HL,HL
        ADD HL,DE               ; *6
        LD DE,SCENETAB
        ADD HL,DE
        LD (SC_PTR),HL
        XOR A
        LD (SC_CHK),A
LS1:    LD HL,(SC_PTR)
        LD E,(HL)
        INC HL
        LD D,(HL)
        INC HL
        LD (SC_PTR),HL
        EX DE,HL
        LD DE,BUF
        CALL UNRLE
        LD A,(SC_CHK)
        CALL SELBANK
        LD HL,BUF
        LD DE,VRAM
        LD BC,2048
        LDIR
        LD A,(SC_CHK)
        CP 1
        JR NZ,LS2
        LD HL,BUF+1408
        LD DE,BGBAND
        LD BC,640
        LDIR
        JR LS3
LS2:    CP 2
        JR NZ,LS3
        LD HL,BUF
        LD DE,BGBAND+640
        LD BC,1408
        LDIR
LS3:    LD HL,SC_CHK
        INC (HL)
        LD A,(HL)
        CP 3
        JR C,LS1
        RET

BLITBAND:
        LD A,1
        CALL SELBANK
        LD HL,BUF
        LD DE,VRAM+1408
        LD BC,640
        LDIR
        LD A,2
        CALL SELBANK
        LD DE,VRAM
        LD BC,1408
        LDIR
        RET

RENDER: LD HL,BGBAND
        LD DE,BUF
        LD BC,2048
        LDIR
        LD A,(ENEMY+F_ACTIVE)
        OR A
        JR Z,RD1
        LD IX,ENEMY
        CALL DRAWFIGHTER
RD1:    LD IX,PLAYER
        JP DRAWFIGHTER

; ---------------------------------------------------------------- sprites
DRAWFIGHTER:                    ; IX = fighter / hawk / Mariko
        LD A,(IX+F_TYPE)
        CP 1
        CALL NZ,DRAWSHADOW      ; flat dark shadow under the feet (not for the flying hawk)
        LD A,(IX+F_TYPE)
        ADD A,A
        LD E,A
        LD D,0
        LD HL,TYPETAB
        ADD HL,DE
        LD E,(HL)
        INC HL
        LD D,(HL)               ; DE = frame table of this type
        LD A,(IX+F_FRAME)
        ADD A,A
        LD L,A
        LD H,0
        ADD HL,DE
        LD E,(HL)
        INC HL
        LD D,(HL)
        EX DE,HL                ; HL = sprite header
        LD (SP_HDR),HL
        LD A,(HL)               ; xoff
        INC HL
        LD C,A
        LD A,(HL)               ; yoff
        INC HL
        SUB (IX+F_Y)
        ADD A,GROUNDY-BANDTOP
        CP 64                   ; clip: never draw outside the action band
        RET NC
        LD (SP_ROW),A
        LD A,(HL)
        INC HL
        LD (SP_W),A
        LD B,A
        LD A,(HL)
        INC HL
        LD (SP_H),A
        INC HL
        INC HL                  ; HL = bitmap
        LD A,(IX+F_DIR)
        OR A
        JR Z,DF_R
        LD A,B                  ; facing left: mirror the bitmap, xoff' = -xoff - 8W + 1
        ADD A,A
        ADD A,A
        ADD A,A
        ADD A,C
        NEG
        INC A
        LD C,A
        PUSH BC
        CALL FLIPSPR
        POP BC
DF_R:   LD (SP_SRC),HL
        LD A,C
        ADD A,(IX+F_X)
        LD (SP_XS),A
        LD A,(IX+F_STYLE)
        ADD A,A
        LD E,A
        LD D,0
        LD HL,STYLETAB
        ADD HL,DE
        LD A,(HL)
        LD (SP_DMX),A
        INC HL
        LD A,(HL)
        LD (SP_DMK),A
        CALL SPRCORE
        LD A,(IX+F_ISPL)
        OR A
        RET NZ
        LD A,(IX+F_TYPE)
        OR A
        RET NZ
        LD A,(IX+F_ACT)         ; no helmet overlay on a fallen guard
        CP ACT_FALL
        RET NC
        LD HL,(SP_HDR)          ; guard: draw the horned helmet on the head
        INC HL
        INC HL
        INC HL
        INC HL
        LD A,(HL)
        INC HL
        LD C,(HL)
        LD B,(IX+F_DIR)
        INC B
        DEC B
        JR Z,DF_H
        NEG
DF_H:   ADD A,(IX+F_X)
        SUB 4
        LD (SP_XS),A
        LD A,C
        ADD A,GROUNDY-BANDTOP-1
        LD (SP_ROW),A
        LD A,2
        LD (SP_W),A
        LD A,5
        LD (SP_H),A
        LD HL,HORNBM
        LD (SP_SRC),HL
        LD A,$FF
        LD (SP_DMX),A
        XOR A
        LD (SP_DMK),A
        JP SPRCORE

DRAWSHADOW:                     ; erase a dark oval under the fighter's feet (OR-sprite cannot make dark)
        LD A,$2F                ; CPL
        LD (NOTP1),A
        LD (NOTP2),A
        LD A,$A6                ; AND (HL)
        LD (CMBOP),A
        LD (CMBOP2),A
        LD A,(IX+F_X)
        SUB 20
        LD (SP_XS),A
        LD A,GROUNDY-BANDTOP-1
        LD (SP_ROW),A
        LD A,5
        LD (SP_W),A
        LD A,3
        LD (SP_H),A
        LD HL,SHADOWBM
        LD (SP_SRC),HL
        LD A,$FF
        LD (SP_DMX),A
        XOR A
        LD (SP_DMK),A
        CALL SPRCORE
        XOR A
        LD (NOTP1),A
        LD (NOTP2),A
        LD A,$B6                ; OR (HL)
        LD (CMBOP),A
        LD (CMBOP2),A
        RET
SHADOWBM: DEFB $07,$FF,$FF,$FF,$E0, $FF,$FF,$FF,$FF,$FF, $07,$FF,$FF,$FF,$E0

FLIPSPR:                        ; HL = bitmap (SP_W x SP_H) -> mirrored copy in TMPSPR, returns HL = TMPSPR
        EXX
        LD B,REVLUT>>8
        EXX
        LD DE,TMPSPR
        LD A,(SP_H)
        LD (SP_RC),A
FS_ROW: PUSH DE
        LD A,(SP_W)
        DEC A
        ADD A,E
        LD E,A
        JR NC,FS_1
        INC D
FS_1:   LD A,(SP_W)
        LD B,A
FS_B:   LD A,(HL)
        INC HL
        EXX
        LD C,A
        LD A,(BC)
        EXX
        LD (DE),A
        DEC DE
        DJNZ FS_B
        POP DE
        LD A,(SP_W)
        ADD A,E
        LD E,A
        JR NC,FS_2
        INC D
FS_2:   LD A,(SP_RC)
        DEC A
        LD (SP_RC),A
        JR NZ,FS_ROW
        LD HL,TMPSPR
        RET

TYPETAB: DEFW SPRTAB,HAWKTAB,MARTAB
FLAPSEQ: DEFB 0,1,2,1
RUNSEQ:  DEFB 2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5

; OR a W-byte x H-row bitmap into BUF, shifted right by (SP_XS & 7), dither-masked by SP_DMX/DMK
SPRCORE:
        LD A,(SP_ROW)
        LD L,A
        LD H,0
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        LD DE,BUF
        ADD HL,DE
        LD A,(SP_XS)
        RRCA
        RRCA
        RRCA
        AND 31
        LD E,A
        LD D,0
        ADD HL,DE
        LD (SP_DST),HL
        LD A,(SP_XS)
        AND 7
        LD C,A
        LD A,7
        SUB C
        LD (ROTJ+1),A
        LD B,C
        LD A,$FF
        INC B
        DEC B
        JR Z,SC_M2
SC_M1:  SRL A
        DJNZ SC_M1
SC_M2:  LD (ANDM+1),A
        LD A,(SP_H)
        LD (SP_RC),A
        LD HL,(SP_SRC)
SC_ROW: LD A,(SP_DMX)
        LD (ANDD+1),A
        LD (ANDD2+1),A
        LD B,A
        LD A,(SP_DMK)
        XOR B
        LD (SP_DMX),A
        EXX
        LD HL,(SP_DST)
        EXX
        LD A,(SP_W)
        LD B,A
        LD C,0
SC_BYT: LD A,(HL)
        INC HL
ROTJ:   DEFB $18,0              ; JR +d  (d patched = 7 - shift) skips unused RRCAs
        RRCA
        RRCA
        RRCA
        RRCA
        RRCA
        RRCA
        RRCA
        LD D,A
ANDM:   AND $FF
        LD E,A
        XOR D
        LD D,A
        LD A,E
        OR C
        LD C,D
ANDD:   AND $FF
        EXX
NOTP1:  NOP                     ; patched to CPL when erasing (shadow)
CMBOP:  OR (HL)                 ; patched to AND (HL) when erasing
        LD (HL),A
        INC HL
        EXX
        DJNZ SC_BYT
        LD A,C
ANDD2:  AND $FF
        EXX
NOTP2:  NOP
CMBOP2: OR (HL)
        LD (HL),A
        EXX
        PUSH HL
        LD HL,(SP_DST)
        LD DE,32
        ADD HL,DE
        LD (SP_DST),HL
        POP HL
        LD A,(SP_RC)
        DEC A
        LD (SP_RC),A
        JR NZ,SC_ROW
        RET

HORNBM: DEFB $80,$40, $80,$40, $C0,$C0, $61,$80, $3F,$00
STYLETAB:                       ; pat0, pat0 xor pat1  (alternating line patterns)
        DEFB $FF,$00            ; 0 solid
        DEFB $AA,$FF            ; 1 50%
        DEFB $88,$AA            ; 2 25%
        DEFB $EE,$55            ; 3 75%

; ---------------------------------------------------------------- text
PUTC:                           ; A = char, C = col (0-31), B = text row (0-23)
        SUB 32
        LD L,A
        LD H,0
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        LD DE,FONT
        ADD HL,DE
        PUSH HL
        LD A,B
        RRCA
        RRCA
        RRCA
        AND 3
        CALL SELBANK
        LD A,B
        AND 7
        ADD A,$70
        LD D,A
        LD E,C
        POP HL
        LD B,8
PC1:    LD A,(HL)
        LD (DE),A
        INC HL
        LD A,E
        ADD A,32
        LD E,A
        JR NC,PC2
        INC D
PC2:    DJNZ PC1
        RET

PUTCUR: LD BC,(PCOL)            ; C = col, B = row
        CALL PUTC
        LD HL,PCOL
        INC (HL)
        RET

PRINTS: LD A,(HL)               ; HL = zero-terminated string at cursor
        OR A
        RET Z
        INC HL
        PUSH HL
        CALL PUTCUR
        POP HL
        JR PRINTS

PRDEC5: LD (PNUM),HL            ; print HL as 5 digits at cursor
        LD DE,DECTAB
        LD A,5
        LD (PCNT),A
PD1:    LD A,(DE)
        LD C,A
        INC DE
        LD A,(DE)
        LD B,A
        INC DE
        PUSH DE
        LD HL,(PNUM)
        LD A,48
PD2:    AND A
        SBC HL,BC
        JR C,PD3
        INC A
        JR PD2
PD3:    ADD HL,BC
        LD (PNUM),HL
        CALL PUTCUR
        POP DE
        LD HL,PCNT
        DEC (HL)
        JR NZ,PD1
        RET

DECTAB: DEFW 10000,1000,100,10,1

SETCUR  MACRO col,row
        LD BC,(row)*256+(col)
        LD (PCOL),BC
        ENDM

DRAWHUD:
        XOR A
        LD (HUDDIRTY),A
        LD (HUDI),A
HD_P:   LD A,(PLAYER+F_HP)
        LD B,A
        LD A,(HUDI)
        CP B
        LD E,32
        JR NC,HD_P1
        LD E,96
HD_P1:  LD A,(HUDI)
        INC A
        LD C,A
        LD B,22
        LD A,E
        CALL PUTC
        LD HL,HUDI
        INC (HL)
        LD A,(HL)
        CP 14
        JR C,HD_P
        XOR A
        LD (HUDI),A
HD_E:   LD A,(ENEMY+F_HP)
        LD B,A
        LD A,(ENEMY+F_ACTIVE)
        OR A
        JR NZ,HD_E0
        LD B,0
HD_E0:  LD A,(HUDI)
        CP B
        LD E,32
        JR NC,HD_E1
        LD E,97
HD_E1:  LD A,(HUDI)
        LD C,A
        LD A,30
        SUB C
        LD C,A
        LD B,22
        LD A,E
        CALL PUTC
        LD HL,HUDI
        INC (HL)
        LD A,(HL)
        CP 14
        JR C,HD_E
        SETCUR 1,23
        LD HL,TXT_SCORE
        CALL PRINTS
        LD HL,(SCORE)
        CALL PRDEC5
        SETCUR 21,23
        LD HL,LVLNAME+70
        LD A,(STATE)
        OR A
        JR Z,HD_L1
        LD A,(LEVEL)
        LD E,A
        ADD A,A
        ADD A,A
        ADD A,E
        ADD A,A
        LD E,A
        LD D,0
        LD HL,LVLNAME
        ADD HL,DE
HD_L1:  JP PRINTS

TXT_SCORE: DEFB "SCORE ",0

; ---------------------------------------------------------------- input
GETKEYS:
        LD C,0
        LD A,($68FE)
        BIT 4,A
        JR NZ,GK1
        SET 2,C                 ; Q punch high
GK1:    BIT 1,A
        JR NZ,GK2
        SET 5,C                 ; W kick high
GK2:    LD A,($68FD)
        BIT 4,A
        JR NZ,GK3
        SET 3,C                 ; A punch mid
GK3:    BIT 1,A
        JR NZ,GK4
        SET 6,C                 ; S kick mid
GK4:    LD A,($68FB)
        BIT 4,A
        JR NZ,GK5
        SET 4,C                 ; Z punch low
GK5:    BIT 1,A
        JR NZ,GK6
        SET 7,C                 ; X kick low
GK6:    LD A,($68BF)
        BIT 1,A
        JR NZ,GK7
        SET 0,C                 ; O left
GK7:    BIT 4,A
        JR NZ,GK8
        SET 1,C                 ; P right
GK8:    LD B,0
        BIT 2,A
        JR NZ,GK9
        LD B,1                  ; ENTER
GK9:    LD A,($68EF)
        BIT 4,A
        JR NZ,GK10
        LD B,1                  ; SPACE
GK10:   LD A,(KEYS)
        LD D,A
        LD A,C
        LD (KEYS),A
        LD A,D
        CPL
        AND C
        LD (KEYS_N),A
        LD A,(KEYS2)
        LD D,A
        LD A,B
        LD (KEYS2),A
        LD A,D
        CPL
        AND B
        AND 1
        LD (KEYS2_N),A
        RET

WAITKEY:                        ; wait for key release, then a fresh SPACE/ENTER press
WK1:    CALL GETKEYS
        LD HL,SEED
        INC (HL)
        LD A,(KEYS2)
        OR A
        JR NZ,WK1
WK2:    CALL GETKEYS
        LD HL,SEED
        INC (HL)
        LD A,(KEYS2_N)
        OR A
        JR Z,WK2
        RET

RND:    LD A,(SEED)
        LD B,A
        ADD A,A
        ADD A,A
        ADD A,B
        ADD A,$31
        LD (SEED),A
        LD B,A
        LD A,R
        XOR B
        RET

BEEP:                           ; D = half period, E = half cycles
        LD A,GFXVAL+1
BP1:    LD (LATCH),A
        XOR 33
        LD B,D
BP2:    DJNZ BP2
        DEC E
        JR NZ,BP1
        LD A,GFXVAL
        LD (LATCH),A
        RET

PLAYTUNE:                       ; HL = list of (D half period, E half cycles) pairs, ends with D=0
        LD A,(HL)
        OR A
        RET Z
        LD D,A
        INC HL
        LD E,(HL)
        INC HL
        PUSH HL
        CALL BEEP
        POP HL
        JR PLAYTUNE

SNDRUN: PUSH AF                 ; play tune at HL, preserving the caller's AF BC DE
        PUSH BC
        PUSH DE
        CALL PLAYTUNE
        POP DE
        POP BC
        POP AF
        RET
SND_SWING: PUSH HL
        LD HL,TUNE_SWING
        CALL SNDRUN
        POP HL
        RET
SND_FALL: PUSH HL
        LD HL,TUNE_FALL
        CALL SNDRUN
        POP HL
        RET
SND_JINGLE: PUSH HL
        LD HL,TUNE_JINGLE
        CALL SNDRUN
        POP HL
        RET
SND_SAD: PUSH HL
        LD HL,TUNE_SAD
        CALL SNDRUN
        POP HL
        RET
TUNE_SWING:  DEFB 50,50, 38,50, 28,50, 0                      ; rising whoosh
TUNE_THUD:   DEFB 170,40, 210,30, 0                           ; low thud after a hit
TUNE_FALL:   DEFB 60,40, 80,40, 100,40, 125,40, 150,40, 180,40, 215,40, 255,40, 0   ; falling sweep
TUNE_JINGLE: DEFB 128,190, 101,237, 84,250, 62,250, 62,250, 0 ; C E G C victory arpeggio
TUNE_SAD:    DEFB 150,180, 190,142, 230,118, 255,160, 0       ; game over, sinking

; ---------------------------------------------------------------- screens
TITLESCR:
        LD A,3
        CALL LOADSCENE
        SETCUR 4,19
        LD HL,TXT_T1
        CALL PRINTS
        SETCUR 2,20
        LD HL,TXT_T2
        CALL PRINTS
        SETCUR 1,22
        LD HL,TXT_T3
        CALL PRINTS
        SETCUR 5,23
        LD HL,TXT_T4
        CALL PRINTS
        JP WAITKEY

TXT_T1: DEFB "Q/A/Z PUNCH   W/S/X KICK",0
TXT_T2: DEFB "O/P MOVE  SPACE STANCE ON/OFF",0
TXT_T3: DEFB "PRESS SPACE OR ENTER TO START",0
TXT_T4: DEFB "VZ200 256X192 VERSION",0

BOXMSG: LD A,12                 ; clear a text box (rows 12-14, cols 7-24)
        LD (HUDI),A
BX1:    LD C,7
BX2:    LD A,(HUDI)
        LD B,A
        LD A,32
        PUSH BC
        CALL PUTC
        POP BC
        INC C
        LD A,C
        CP 25
        JR C,BX2
        LD HL,HUDI
        INC (HL)
        LD A,(HL)
        CP 15
        JR C,BX1
        RET

GAMEOVER:
        CALL SND_SAD
        CALL BOXMSG
        SETCUR 11,12
        LD HL,TXT_GO
        CALL PRINTS
        SETCUR 10,14
        LD HL,TXT_GO2
        CALL PRINTS
        CALL WAITKEY
        LD A,1
        LD (RESTART),A
        RET

TXT_GO:  DEFB "GAME OVER",0
TXT_GO2: DEFB "PRESS SPACE",0

VICTORY:
        LD A,3
        CALL LOADSCENE
        SETCUR 3,19
        LD HL,TXT_V1
        CALL PRINTS
        SETCUR 8,21
        LD HL,TXT_SCORE
        CALL PRINTS
        LD HL,(SCORE)
        CALL PRDEC5
        SETCUR 1,23
        LD HL,TXT_T3
        CALL PRINTS
        CALL WAITKEY
        LD A,1
        LD (RESTART),A
        RET

TXT_V1: DEFB "AKUMA FALLS! MARIKO IS FREE!",0

; ---------------------------------------------------------------- game flow
NEWGAME:
        XOR A
        LD (RESTART),A
        LD (STATE),A
        LD (LEVEL),A
        LD (SCORE),A
        LD (SCORE+1),A
        LD (EDEADT),A
        LD (PDEADT),A
        LD (KEYS),A
        LD (KEYS2),A
        LD (ENEMY+F_ACTIVE),A
        LD (ENEMY+F_ISPL),A
        LD (PLAYER+F_DIR),A
        LD (PLAYER+F_MODE),A
        LD (PLAYER+F_ACT),A
        LD (PLAYER+F_PH),A
        LD (PLAYER+F_RUN),A
        LD (PLAYER+F_STYLE),A
        LD (PLAYER+F_COOL),A
        LD (PLAYER+F_ATK),A
        LD (PLAYER+F_HIT),A
        LD (PLAYER+F_ACTIVE),A
        LD (PLAYER+F_TYPE),A
        LD (PLAYER+F_Y),A
        LD (ENEMY+F_TYPE),A
        LD (ENEMY+F_Y),A
        INC A
        LD (PLAYER+F_ISPL),A
        LD (PLAYER+F_ACTIVE),A
        LD (HUDDIRTY),A
        LD A,14
        LD (PLAYER+F_HP),A
        LD A,XMIN
        LD (PLAYER+F_X),A
        LD A,FR_STAND
        LD (PLAYER+F_FRAME),A
        XOR A
        JP LOADSCENE

STARTFIGHT:
        LD A,60
        LD (PLAYER+F_X),A
        XOR A
        LD (PLAYER+F_DIR),A
        LD (PLAYER+F_RUN),A
        LD (ENEMY+F_HIT),A
        LD (ENEMY+F_RUN),A
        LD (ENEMY+F_ATK),A
        LD (EDEADT),A
        LD A,ACT_BOW
        LD (PLAYER+F_ACT),A
        LD (ENEMY+F_ACT),A
        LD A,16
        LD (PLAYER+F_PH),A
        LD (ENEMY+F_PH),A
        LD A,(LEVEL)
        LD E,A
        LD D,0
        LD HL,HPTAB
        ADD HL,DE
        LD A,(HL)
        LD (ENEMY+F_HP),A
        LD HL,STYTAB
        ADD HL,DE
        LD A,(HL)
        LD (ENEMY+F_STYLE),A
        XOR A
        LD (ENEMY+F_Y),A
        LD (ENEMY+F_TYPE),A
        LD A,(LEVEL)
        CP 5
        JR NZ,SF_G
        LD A,1
        LD (ENEMY+F_TYPE),A     ; level 6 is the hawk
        LD A,22
        LD (ENEMY+F_Y),A
SF_G:   LD A,XMAX
        LD (ENEMY+F_X),A
        LD A,1
        LD (ENEMY+F_DIR),A
        LD (ENEMY+F_MODE),A
        LD (ENEMY+F_ACTIVE),A
        LD (HUDDIRTY),A
        LD (STATE),A
        LD A,10
        LD (ENEMY+F_COOL),A
        RET

ENTERGATE:
        XOR A
        LD (LEVEL),A
        LD (PLAYER+F_MODE),A
        JP SCROLLGATE

NEXTGUARD:
        LD HL,LEVEL
        INC (HL)
        LD A,(HL)
        CP 7
        JP Z,ENDGAME
        LD A,(PLAYER+F_HP)
        ADD A,4
        CP 15
        JR C,NG1
        LD A,14
NG1:    LD (PLAYER+F_HP),A
        LD A,(LEVEL)
        CP 3
        JR NZ,NG2
        LD A,2
        CALL LOADSCENE
NG2:    JP STARTFIGHT

UPDATE: CALL UPD_PLAYER
        CALL UPD_ENEMY
        LD A,(STATE)
        OR A
        JR Z,UP_CLIFF
        LD A,(ENEMY+F_ACT)
        CP ACT_DEAD
        JR NZ,UF1
        LD HL,EDEADT
        INC (HL)
        LD A,(HL)
        CP 30
        JR C,UF1
        CALL NEXTGUARD
        RET
UF1:    LD A,(PLAYER+F_ACT)
        CP ACT_DEAD
        RET NZ
        LD HL,PDEADT
        INC (HL)
        LD A,(HL)
        CP 36
        RET C
        XOR A
        LD (PDEADT),A
        JP GAMEOVER
UP_CLIFF:
        LD A,(PLAYER+F_X)
        CP 204
        RET C
        JP ENTERGATE

; ---------------------------------------------------------------- fighters
STARTATK:                       ; A = attack type 0..5 (PH PM PL KH KM KL), IX = fighter
        LD (IX+F_ATK),A
        ADD A,A
        ADD A,6
        LD (IX+F_FRAME),A
        LD A,ACT_ATK
        LD (IX+F_ACT),A
        XOR A
        LD (IX+F_PH),A
        LD (IX+F_HIT),A
        JP SND_SWING            ; whoosh

; shared state machine for hit / fall / dead / bow / attack timeline.  IX = self, IY = opponent.
; returns carry set if the fighter was busy (handled), clear if idle and free to decide.
UPD_COMMON:
        LD A,(IX+F_ACT)
        OR A
        RET Z                   ; idle: carry clear
        CP ACT_ATK
        JR Z,UC_ATK
        CP ACT_HIT
        JR Z,UC_HIT
        CP ACT_FALL
        JR Z,UC_FALL
        CP ACT_BOW
        JR Z,UC_BOW
        LD A,FR_DEAD
        LD (IX+F_FRAME),A
        SCF
        RET
UC_HIT: LD A,FR_HIT
        LD (IX+F_FRAME),A
        DEC (IX+F_PH)
        JR NZ,UC_RET
        XOR A
        LD (IX+F_ACT),A
UC_RET: SCF
        RET
UC_FALL:
        LD A,FR_FALL
        LD (IX+F_FRAME),A
        DEC (IX+F_PH)
        JR NZ,UC_RET
        LD A,ACT_DEAD
        LD (IX+F_ACT),A
        LD A,FR_DEAD
        LD (IX+F_FRAME),A
        SCF
        RET
UC_BOW: LD A,FR_BOW
        LD (IX+F_FRAME),A
        DEC (IX+F_PH)
        JR NZ,UC_RET
        XOR A
        LD (IX+F_ACT),A
        SCF
        RET
UC_ATK: LD A,(IX+F_ATK)
        CP 3
        LD HL,ATKP
        JR C,UA1
        LD HL,ATKK
UA1:    LD B,(HL)               ; windup ticks
        INC HL
        LD C,(HL)               ; extended ticks
        INC HL
        LD D,(HL)               ; recover ticks
        LD A,B
        ADD A,C
        LD H,A                  ; end of extend
        ADD A,D
        LD L,A                  ; end of recover
        LD A,(IX+F_ATK)
        ADD A,A
        ADD A,6
        LD E,A                  ; windup frame
        LD A,(IX+F_PH)
        CP B
        JR C,UA_W
        CP H
        JR C,UA_X
        CP L
        JR C,UA_W
        LD A,FR_FIGHT           ; attack finished
        LD (IX+F_FRAME),A
        XOR A
        LD (IX+F_ACT),A
        LD A,(IX+F_ISPL)
        OR A
        JR NZ,UC_RET
        CALL RND
        AND 3
        LD B,A
        LD A,(LEVEL)
        LD E,A
        LD D,0
        LD HL,COOLTAB
        ADD HL,DE
        LD A,(HL)
        ADD A,B
        LD (IX+F_COOL),A
        SCF
        RET
UA_W:   LD (IX+F_FRAME),E
        JR UA_NEXT
UA_X:   LD A,E
        INC A
        LD (IX+F_FRAME),A
        LD A,(IX+F_PH)
        CP B
        JR NZ,UA_NEXT
        LD A,(IX+F_HIT)
        OR A
        JR NZ,UA_NEXT
        CALL HITCHECK
UA_NEXT:
        INC (IX+F_PH)
        SCF
        RET

ATKP:   DEFB 2,2,2
ATKK:   DEFB 3,3,3
DMGTAB: DEFB 1,2,1,2,3,2

; attacker IX, defender IY: resolve a landed strike
HITCHECK:
        LD A,(IY+F_ACTIVE)
        OR A
        RET Z
        LD A,(IY+F_ACT)
        CP ACT_FALL
        RET Z
        CP ACT_DEAD
        RET Z
        LD A,(IY+F_TYPE)        ; a flying hawk can only be hit when it is low
        OR A
        JR Z,HC_OK
        LD A,(IY+F_Y)
        CP 24
        RET NC
HC_OK:  LD A,(IX+F_X)
        LD B,A
        LD A,(IY+F_X)
        SUB B
        JR C,HC_L
        LD C,A                  ; defender is to the right
        LD A,(IX+F_DIR)
        OR A
        RET NZ
        JR HC_D
HC_L:   NEG
        LD C,A
        LD A,(IX+F_DIR)
        OR A
        RET Z
HC_D:   LD A,(IX+F_ATK)
        CP 3
        LD B,REACH_P
        JR C,HC_R
        LD B,REACH_K
HC_R:   LD A,B
        CP C
        RET C                   ; out of reach
        LD A,(IX+F_ATK)         ; damage
        LD E,A
        LD D,0
        LD HL,DMGTAB
        ADD HL,DE
        LD A,(HL)
        LD B,(IY+F_MODE)
        INC B
        DEC B
        JR NZ,HC_M
        ADD A,A                 ; caught off guard: double damage
HC_M:   LD B,A
        LD A,(IY+F_HP)
        SUB B
        JR NC,HC_H
        XOR A
HC_H:   LD (IY+F_HP),A
        LD A,1
        LD (IX+F_HIT),A
        LD (HUDDIRTY),A
        LD A,(IX+F_ISPL)
        OR A
        JR Z,HC_NS
        LD A,B                  ; score = 10 per damage point
        ADD A,A
        LD C,A
        ADD A,A
        ADD A,A
        ADD A,C
        LD E,A
        LD D,0
        LD HL,(SCORE)
        ADD HL,DE
        LD (SCORE),HL
HC_NS:  LD A,(IY+F_HP)
        OR A
        JR Z,HC_DEAD
        LD A,ACT_HIT
        LD (IY+F_ACT),A
        LD A,4
        LD (IY+F_PH),A
        LD A,FR_HIT
        LD (IY+F_FRAME),A
        LD E,6
        LD D,90
        PUSH DE
        JR HC_KB
HC_DEAD:
        CALL SND_FALL           ; falling sweep
        LD A,ACT_FALL
        LD (IY+F_ACT),A
        LD A,5
        LD (IY+F_PH),A
        LD A,FR_FALL
        LD (IY+F_FRAME),A
        LD A,(IX+F_ISPL)
        OR A
        JR Z,HC_ND
        LD HL,(SCORE)
        LD DE,100
        ADD HL,DE
        LD (SCORE),HL
HC_ND:  LD E,10
        LD D,200
        PUSH DE
HC_KB:  LD A,(IX+F_DIR)         ; knock the defender back, away from the attacker
        OR A
        LD A,(IY+F_X)
        POP DE
        JR NZ,KB_L
        ADD A,E
        CP XMAX+1
        JR C,KB_S
        LD A,XMAX
        JR KB_S
KB_L:   SUB E
        CP XMIN
        JR NC,KB_S
        LD A,XMIN
KB_S:   LD (IY+F_X),A
        LD E,60
        CALL BEEP
        LD HL,TUNE_THUD         ; second, lower thud after the crack
        JP PLAYTUNE

UPD_PLAYER:
        LD IX,PLAYER
        LD IY,ENEMY
        CALL UPD_COMMON
        RET C
        LD A,(KEYS2_N)
        OR A
        JR Z,UP1
        LD A,(IX+F_MODE)
        XOR 1
        LD (IX+F_MODE),A
UP1:    LD A,(IX+F_MODE)
        OR A
        JR Z,UP_MOVE
        LD A,(KEYS_N)
        LD B,0
        BIT 2,A
        JR NZ,UP_ATK
        INC B
        BIT 3,A
        JR NZ,UP_ATK
        INC B
        BIT 4,A
        JR NZ,UP_ATK
        INC B
        BIT 5,A
        JR NZ,UP_ATK
        INC B
        BIT 6,A
        JR NZ,UP_ATK
        INC B
        BIT 7,A
        JR NZ,UP_ATK
        JR UP_MOVE
UP_ATK: LD A,B
        JP STARTATK
UP_MOVE:
        LD A,(KEYS)
        LD C,A
        LD E,(IX+F_X)           ; E = old X
        LD B,4
        LD A,(IX+F_MODE)
        OR A
        JR Z,UP2
        LD B,2
UP2:    LD D,0                  ; D = moved
        BIT 1,C
        JR Z,UP_NR
        LD A,(IX+F_X)
        ADD A,B
        CP 209
        JR C,UP3
        LD A,208
UP3:    LD (IX+F_X),A
        LD D,1
        LD (IX+F_DIR),0
UP_NR:  BIT 0,C
        JR Z,UP_NL
        LD A,(IX+F_X)
        SUB B
        CP XMIN
        JR NC,UP4
        LD A,XMIN
UP4:    LD (IX+F_X),A
        LD D,1
        LD (IX+F_DIR),1
UP_NL:  LD A,(ENEMY+F_ACTIVE)   ; keep out of the guard's body
        OR A
        JR Z,UP_FR
        LD A,(ENEMY+F_ACT)
        CP ACT_DEAD
        JR Z,UP_FR
        LD A,(IX+F_X)
        LD B,A
        LD A,(ENEMY+F_X)
        SUB B
        JR NC,UP5
        NEG
UP5:    CP 14
        JR NC,UP_FR
        LD (IX+F_X),E
UP_FR:  LD A,(IX+F_MODE)
        OR A
        JR Z,UP_WALK
        LD A,(ENEMY+F_ACTIVE)   ; stance: face the guard
        OR A
        JR Z,UP6
        LD A,(IX+F_X)
        LD B,A
        LD A,(ENEMY+F_X)
        CP B
        LD A,0
        JR NC,UP7
        INC A
UP7:    LD (IX+F_DIR),A
UP6:    LD A,D
        OR A
        LD A,FR_FIGHT
        JR Z,UP8
        INC (IX+F_RUN)
        LD A,(IX+F_RUN)
        RRCA
        AND 1
        LD A,FR_FIGHT
        JR Z,UP8
        LD A,FR_FSTEP
UP8:    LD (IX+F_FRAME),A
        RET
UP_WALK:
        LD A,D
        OR A
        JR Z,UP_STD
        JP RUNANIM
UP_STD: LD A,FR_STAND
        LD (IX+F_FRAME),A
        RET

RUNANIM:                        ; IX = fighter: advance the run cycle (4 frames, 3 ticks each)
        LD A,(IX+F_RUN)
        INC A
        CP 16
        JR C,RA1
        XOR A
RA1:    LD (IX+F_RUN),A
        LD E,A
        LD D,0
        LD HL,RUNSEQ
        ADD HL,DE
        LD A,(HL)
        LD (IX+F_FRAME),A
        RET

UPD_ENEMY:
        LD A,(ENEMY+F_ACTIVE)
        OR A
        RET Z
        LD A,(ENEMY+F_TYPE)
        OR A
        JP NZ,UPD_HAWK
        LD IX,ENEMY
        LD IY,PLAYER
        CALL UPD_COMMON
        RET C
        LD A,(IX+F_X)           ; face the player, C = distance
        LD B,A
        LD A,(IY+F_X)
        SUB B
        JR C,UE_FL
        LD C,A
        XOR A
        LD (IX+F_DIR),A
        JR UE_D
UE_FL:  NEG
        LD C,A
        LD A,1
        LD (IX+F_DIR),A
UE_D:   LD A,FR_FIGHT
        LD (IX+F_FRAME),A
        LD A,(IX+F_COOL)
        OR A
        JR Z,UE_NC
        DEC (IX+F_COOL)
UE_NC:  LD A,(IY+F_ACT)
        CP ACT_FALL
        RET Z
        CP ACT_DEAD
        RET Z
        LD A,C
        CP 27
        JR NC,UE_APPR
        CP 15
        JR C,UE_CLOSE
        LD A,(IX+F_COOL)        ; in range: strike?
        OR A
        RET NZ
        LD A,(IY+F_MODE)
        OR A
        JR Z,UE_GO              ; player off guard: always strike
        CALL RND
        LD B,A
        LD A,(LEVEL)
        LD E,A
        LD D,0
        LD HL,AGGTAB
        ADD HL,DE
        LD A,(HL)
        CP B
        RET C
UE_GO:  CALL RND
        AND 7
        CP 6
        JR C,UE_T1
        SUB 6
UE_T1:  LD B,A
        LD A,C
        CP 25
        LD A,B
        JR C,UE_T2
        CP 3
        JR NC,UE_T2
        ADD A,3                 ; far away: kick
UE_T2:  JP STARTATK
UE_CLOSE:
        LD A,(IX+F_COOL)
        OR A
        JR NZ,UE_BACK
        CALL RND
        AND 1
        JR UE_T2                ; short punch (high/mid)
UE_BACK:
        LD A,(IX+F_DIR)         ; step back from the player
        OR A
        LD A,(IX+F_X)
        JR NZ,UE_BR
        SUB 2
        CP XMIN
        JR NC,UE_BS
        LD A,XMIN
        JR UE_BS
UE_BR:  ADD A,2
        CP XMAX+1
        JR C,UE_BS
        LD A,XMAX
UE_BS:  LD (IX+F_X),A
        JP ESTEP
UE_APPR:
        LD A,(LEVEL)
        LD E,A
        LD D,0
        LD HL,SPDTAB
        ADD HL,DE
        LD B,(HL)
        LD A,(IX+F_DIR)
        OR A
        LD A,(IX+F_X)
        JR NZ,UE_AL
        ADD A,B
        CP XMAX+1
        JR C,UE_AS
        LD A,XMAX
        JR UE_AS
UE_AL:  SUB B
        CP XMIN
        JR NC,UE_AS
        LD A,XMIN
UE_AS:  LD (IX+F_X),A
        JP ESTEP
ESTEP:  INC (IX+F_RUN)
        LD A,(IX+F_RUN)
        RRCA
        AND 1
        LD A,FR_FIGHT
        JR Z,ES1
        LD A,FR_FSTEP
ES1:    LD (IX+F_FRAME),A
        RET


; ---------------------------------------------------------------- hawk
UPD_HAWK:
        LD IX,ENEMY
        LD IY,PLAYER
        LD A,(IX+F_ACT)
        CP ACT_ATK
        JP Z,HK_DIVE
        CALL UPD_COMMON
        JR NC,HK_IDLE
        LD A,(IX+F_ACT)
        CP ACT_FALL
        JR Z,HK_DROP
        CP ACT_DEAD
        RET NZ
HK_DROP:
        LD A,(IX+F_Y)           ; a dead hawk drops to the ground
        SUB 4
        JR NC,HK_D1
        XOR A
HK_D1:  LD (IX+F_Y),A
        RET
HK_IDLE:
        LD A,(IX+F_X)           ; face the player, C = distance
        LD B,A
        LD A,(IY+F_X)
        SUB B
        JR C,HK_FL
        LD C,A
        XOR A
        LD (IX+F_DIR),A
        JR HK_D
HK_FL:  NEG
        LD C,A
        LD A,1
        LD (IX+F_DIR),A
HK_D:   LD A,(IX+F_Y)           ; climb back to hover height
        CP 22
        JR NC,HK_FLAP
        ADD A,2
        LD (IX+F_Y),A
HK_FLAP:
        LD A,(IX+F_RUN)
        INC A
        LD (IX+F_RUN),A
        RRCA
        AND 3
        LD E,A
        LD D,0
        LD HL,FLAPSEQ
        ADD HL,DE
        LD A,(HL)
        LD (IX+F_FRAME),A
        LD A,C                  ; keep a hunting distance
        CP 70
        JR C,HK_CLOSE
        LD B,3
        LD A,(IX+F_DIR)
        CALL HK_STEP
        JR HK_CD
HK_CLOSE:
        CP 45
        JR NC,HK_CD
        LD B,3
        LD A,(IX+F_DIR)
        XOR 1
        CALL HK_STEP
HK_CD:  LD A,(IX+F_COOL)
        OR A
        JR Z,HK_GO
        DEC (IX+F_COOL)
        RET
HK_GO:  LD A,(IY+F_ACT)
        CP ACT_FALL
        RET Z
        CP ACT_DEAD
        RET Z
        LD A,ACT_ATK            ; start a dive
        LD (IX+F_ACT),A
        XOR A
        LD (IX+F_PH),A
        LD (IX+F_HIT),A
        INC A
        LD (IX+F_ATK),A
        RET
HK_STEP:                        ; A = direction (0 right, 1 left), B = pixels
        OR A
        LD A,(IX+F_X)
        JR NZ,HS_L
        ADD A,B
        CP XMAX+1
        JR C,HS_S
        LD A,XMAX
        JR HS_S
HS_L:   SUB B
        CP XMIN
        JR NC,HS_S
        LD A,XMIN
HS_S:   LD (IX+F_X),A
        RET
HK_DIVE:
        LD A,(IX+F_PH)
        CP 8
        JR NC,HK_CLIMB
        LD A,(IX+F_Y)           ; swoop down at the player
        SUB 2
        LD (IX+F_Y),A
        LD A,FR_DIVE
        LD (IX+F_FRAME),A
        LD B,6
        LD A,(IX+F_DIR)
        CALL HK_STEP
        LD A,(IX+F_Y)
        CP 20
        JR NC,HK_DN
        LD A,(IX+F_HIT)
        OR A
        CALL Z,HITCHECK         ; bite (once per dive)
HK_DN:  INC (IX+F_PH)
        RET
HK_CLIMB:
        CP 16
        JR NC,HK_END
        LD A,(IX+F_Y)
        ADD A,2
        LD (IX+F_Y),A
        LD A,1
        LD (IX+F_FRAME),A
        LD B,4
        LD A,(IX+F_DIR)
        CALL HK_STEP
        INC (IX+F_PH)
        RET
HK_END: XOR A
        LD (IX+F_ACT),A
        CALL RND
        AND 7
        ADD A,12
        LD (IX+F_COOL),A
        RET

; ---------------------------------------------------------------- scrolling screen change (cliff -> gate)
SCROLLGATE:
        LD A,(VRAMRD)
        OR A
        JP Z,SG_NO              ; video RAM not readable: plain cut instead
        LD HL,(SCENETAB+6)      ; unpack the gate screen (lines 30..175) into SCRB
        LD DE,BUF
        CALL UNRLE
        LD HL,BUF+960
        LD DE,SCRB
        LD BC,1088
        LDIR
        LD HL,(SCENETAB+8)
        LD DE,SCRB+1088
        CALL UNRLE
        LD HL,(SCENETAB+10)
        LD DE,BUF
        CALL UNRLE
        LD HL,BUF
        LD DE,SCRB+3136
        LD BC,1536
        LDIR
        XOR A
        LD (SG_S),A
        LD (PLAYER+F_DIR),A
        LD (PLAYER+F_ACT),A
SG_L:   LD HL,SG_S
        INC (HL)
        LD A,(HL)
        ADD A,A
        LD (SG_N),A
        SUB 2
        LD (SG_COL),A
        LD HL,SCRB              ; lines 30..63
        LD (SG_SRC),HL
        XOR A
        LD HL,VRAM+960
        LD B,34
        CALL SHIFTLINES
        LD HL,SCRB+1088         ; lines 64..107
        LD (SG_SRC),HL
        LD A,1
        LD HL,VRAM
        LD B,44
        CALL SHIFTLINES
        LD HL,SCRB+4544         ; lines 172..175 (the HUD lines below stay put)
        LD (SG_SRC),HL
        LD A,2
        LD HL,VRAM+1408
        LD B,4
        CALL SHIFTLINES
        CALL BANDMIX
        LD A,(SG_S)             ; the karateka keeps running while the scenery slides by
        LD B,A
        ADD A,A
        ADD A,A
        ADD A,A
        ADD A,B
        LD C,A
        LD A,204
        SUB C
        LD (PLAYER+F_X),A
        LD IX,PLAYER
        CALL RUNANIM
        CALL DRAWFIGHTER
        CALL VSYNC
        CALL BLITBAND
        LD A,(SG_S)
        CP 16
        JR C,SG_L
        LD HL,SCRB+2496         ; the gate screen's action band becomes the background
        LD DE,BGBAND
        LD BC,2048
        LDIR
        JP STARTFIGHT
SG_NO:  LD A,1
        CALL LOADSCENE
        JP STARTFIGHT

SHIFTLINES:                     ; A = bank, HL = window address of first line, B = lines, SG_SRC = new-screen row
        PUSH HL
        PUSH BC
        CALL SELBANK
        POP BC
        POP HL
SL1:    PUSH BC
        LD D,H
        LD E,L
        INC HL
        INC HL
        LD BC,30
        LDIR                    ; slide the line 2 bytes (16 pixels) left
        PUSH HL
        LD HL,(SG_SRC)
        LD A,(SG_COL)
        ADD A,L
        LD L,A
        JR NC,SL2
        INC H
SL2:    LDI                     ; two fresh bytes of the new screen enter on the right
        LDI
        LD HL,(SG_SRC)
        LD BC,32
        ADD HL,BC
        LD (SG_SRC),HL
        POP HL                  ; next line start
        POP BC
        DJNZ SL1
        RET

BANDMIX:                        ; BUF = old band slid left by SG_N bytes + new band entering from the right
        LD HL,BGBAND
        LD (SG_RB),HL
        LD HL,SCRB+2496
        LD (SG_RS),HL
        LD HL,BUF
        LD (SG_RD),HL
        LD A,64
        LD (SG_RC),A
BM1:    LD A,(SG_N)
        LD C,A
        LD A,32
        SUB C
        LD C,A
        LD B,0
        LD HL,(SG_RB)
        LD DE,(SG_RD)
        LD A,(SG_N)
        ADD A,L
        LD L,A
        JR NC,BM2
        INC H
BM2:    LD A,C
        OR A
        JR Z,BM3
        LDIR
BM3:    LD HL,(SG_RS)
        LD A,(SG_N)
        LD C,A
        LD B,0
        LDIR
        LD HL,(SG_RB)
        LD DE,32
        ADD HL,DE
        LD (SG_RB),HL
        LD HL,(SG_RS)
        ADD HL,DE
        LD (SG_RS),HL
        LD HL,(SG_RD)
        ADD HL,DE
        LD (SG_RD),HL
        LD HL,SG_RC
        DEC (HL)
        JR NZ,BM1
        RET

; ---------------------------------------------------------------- cut scenes
DELAYSKIP:                      ; BC = frames to wait, SPACE/ENTER skips
DS1:    PUSH BC
        CALL VSYNC
        CALL GETKEYS
        POP BC
        LD A,(KEYS2_N)
        OR A
        RET NZ
        DEC BC
        LD A,B
        OR C
        JR NZ,DS1
        RET

INTROCUT:
        LD A,4
        CALL LOADSCENE
        SETCUR 3,22
        LD HL,TXT_I1
        CALL PRINTS
        LD BC,160
        CALL DELAYSKIP
        LD A,5
        CALL LOADSCENE
        SETCUR 3,22
        LD HL,TXT_I2
        CALL PRINTS
        SETCUR 2,23
        LD HL,TXT_I3
        CALL PRINTS
        LD BC,200
        JP DELAYSKIP

TXT_I1: DEFB "AKUMA HAS CAPTURED MARIKO!",0
TXT_I2: DEFB "HE WILL FORCE HER TO WED!",0
TXT_I3: DEFB "FIGHT THROUGH HIS FORTRESS!",0

ENDGAME:
        CALL ENDCUT
        JP VICTORY

ENDCUT:                         ; Mariko runs in from the right, the karateka bows
        LD A,6                  ; Mariko's cell background
        CALL LOADSCENE
        XOR A
        LD (PLAYER+F_MODE),A
        LD (PLAYER+F_ACT),A
        LD (PLAYER+F_DIR),A
        LD (MARIKO+F_Y),A
        LD (MARIKO+F_RUN),A
        LD (MARIKO+F_STYLE),A
        LD (MARIKO+F_FRAME),A
        LD A,2
        LD (MARIKO+F_TYPE),A
        LD A,1
        LD (MARIKO+F_ISPL),A
        LD (MARIKO+F_DIR),A
        LD A,95
        LD (PLAYER+F_X),A
        LD A,236
        LD (MARIKO+F_X),A
        LD A,FR_STAND
        LD (PLAYER+F_FRAME),A
EC1:    CALL ECRENDER
        LD A,(MARIKO+F_X)
        SUB 3
        LD (MARIKO+F_X),A
        LD A,(MARIKO+F_RUN)
        INC A
        LD (MARIKO+F_RUN),A
        RRCA
        RRCA
        AND 3
        INC A                   ; walk frames 1..4
        LD (MARIKO+F_FRAME),A
        LD A,(MARIKO+F_X)
        CP 122
        JR NC,EC1
        XOR A
        LD (MARIKO+F_FRAME),A
        LD B,30
        CALL ECWAIT
        LD A,FR_BOW
        LD (PLAYER+F_FRAME),A
        LD B,24
        CALL ECWAIT
        LD A,FR_STAND
        LD (PLAYER+F_FRAME),A
        LD B,30
        CALL ECWAIT
        LD A,5                  ; Mariko stretches out her arms
        LD (MARIKO+F_FRAME),A
        LD B,30
        CALL ECWAIT
        CALL SND_JINGLE
        LD A,108                ; couple sprite replaces both fighters
        LD (MARIKO+F_X),A
        LD A,6
EC_H1:  LD (MARIKO+F_FRAME),A   ; hug and kiss frames 6..10
        PUSH AF
        LD B,16
        CALL ECWAIT2
        POP AF
        INC A
        CP 11
        JR C,EC_H1
        LD B,60
        JP ECWAIT2

ECWAIT2: LD A,B                 ; same as ECWAIT but only the couple sprite is drawn
        LD (ECT),A
ECW2:   CALL ECR_NP
        LD HL,ECT
        DEC (HL)
        JR NZ,ECW2
        RET
ECR_NP: LD HL,BGBAND
        LD DE,BUF
        LD BC,2048
        LDIR
        LD IX,MARIKO
        CALL DRAWFIGHTER
        CALL VSYNC
        JP BLITBAND

ECWAIT: LD A,B
        LD (ECT),A
ECW1:   CALL ECRENDER
        LD HL,ECT
        DEC (HL)
        JR NZ,ECW1
        RET
ECRENDER:
        LD HL,BGBAND
        LD DE,BUF
        LD BC,2048
        LDIR
        LD IX,MARIKO
        CALL DRAWFIGHTER
        LD IX,PLAYER
        CALL DRAWFIGHTER
        CALL VSYNC
        JP BLITBAND

; per-guard tuning (guards 1-5, then Akuma)
HPTAB:   DEFB 6,8,10,12,14,8,14
AGGTAB:  DEFB 70,100,130,160,190,200,220
COOLTAB: DEFB 10,8,7,6,5,5,4
SPDTAB:  DEFB 2,2,2,3,3,3,3
STYTAB:  DEFB 0,0,0,0,0,0,0
LVLNAME: DEFB "GUARD 1  ",0,"GUARD 2  ",0,"GUARD 3  ",0,"GUARD 4  ",0,"GUARD 5  ",0,"HAWK     ",0,"AKUMA    ",0
         DEFB "RUN...   ",0

        INCLUDE "kar_font.inc"
        INCLUDE "kar_sprites.inc"
        INCLUDE "kar_scenes.inc"

ENDMARK:
; ---------------------------------------------------------------- RAM (not part of the file)
BSSBASE EQU ENDMARK
PLAYER  EQU BSSBASE
ENEMY   EQU PLAYER+16
MARIKO  EQU ENEMY+16
VARS    EQU MARIKO+16
KEYS     EQU VARS+0
KEYS_N   EQU VARS+1
KEYS2    EQU VARS+2
KEYS2_N  EQU VARS+3
STATE    EQU VARS+4
LEVEL    EQU VARS+5
SCORE    EQU VARS+6             ; word
HUDDIRTY EQU VARS+8
RESTART  EQU VARS+9
SEED     EQU VARS+10
EDEADT   EQU VARS+11
PDEADT   EQU VARS+12
SC_PTR   EQU VARS+13            ; word
SC_CHK   EQU VARS+15
SP_HDR   EQU VARS+16            ; word
SP_XS    EQU VARS+18
SP_ROW   EQU VARS+19
SP_W     EQU VARS+20
SP_H     EQU VARS+21
SP_SRC   EQU VARS+22            ; word
SP_DST   EQU VARS+24            ; word
SP_DMX   EQU VARS+26
SP_DMK   EQU VARS+27
SP_RC    EQU VARS+28
PCOL     EQU VARS+29
PROW     EQU VARS+30
PNUM     EQU VARS+31            ; word
PCNT     EQU VARS+33
HUDI     EQU VARS+34
VRAMRD   EQU VARS+35
SG_S     EQU VARS+36
SG_N     EQU VARS+37
SG_COL   EQU VARS+38
SG_SRC   EQU VARS+39            ; word
SG_RB    EQU VARS+41            ; word
SG_RS    EQU VARS+43            ; word
SG_RD    EQU VARS+45            ; word
SG_RC    EQU VARS+47
ECT      EQU VARS+48
VAREND   EQU VARS+56
TMPSPR   EQU VAREND             ; 300  mirrored copy of a sprite
REVLUT   EQU (TMPSPR+300+255)&$FF00   ; 256  bit-reverse table
BUF      EQU REVLUT+256         ; 2048 working copy of the action band
BGBAND   EQU BUF+2048           ; 2048 background of the action band
SCRB     EQU BGBAND+2048        ; 4672 gate screen (only used while scrolling)
RAMEND   EQU SCRB+4672
