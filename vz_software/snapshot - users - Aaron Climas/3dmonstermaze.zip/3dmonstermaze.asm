; ==========================================================================
;  3D MONSTER MAZE  -  ZX81  ->  VZ200 / Laser 200 port
;
;  Original game: 3D MONSTER MAZE (1981)
;     idea J.K. Greye, programmed by Malcolm Evans, New Generation Software
;  This is a straight port of the original Z80 machine code.  The original code is
;  included unchanged (see "ORIGINAL BLOCK" below) apart from the relocation and a
;  handful of ZX81-specific patches.  Everything in THIS part of the file is new:
;    - start-up / exit
;    - the BASIC program of the original, rewritten in Z80 (menus, maze generation,
;      main game loop, appeal screen)
;    - keyboard, random numbers, timing
;    - a ZX81 "shadow display file" + converter to the 32x16 VZ200 text screen
;      (graphics blocks -> 2x2 semigraphics, text -> ASCII)
;
;  Controls:  A = turn left   W = move forward   D = turn right
;  Menu keys: K = instructions, C = start game, A = quit to BASIC
;  (the original used 5 / 7 / 8; the machine code still sees the ZX81 key codes 21H / 23H / 24H)
; ==========================================================================

DELTA       EQU 5000H          ; ZX81 address + DELTA = VZ200 address of the original block
VRAM        EQU 7000H          ; VZ200 screen memory (32 x 16)
KB          EQU 6800H          ; keyboard matrix / latch

; ---- RAM map (everything lives in the 16K expansion, 8000H-BFFFH) -------------
;  8000H-9081H  this glue code and its small tables
;  9082H-ABABH  original game block (code, display lists, text)
;  AC00H-B7FFH  12 page-aligned semigraphic lookup tables
;  B800H        ZX81 -> ASCII table
;  B900H        shadow display file (ZX81 layout: 1 + 24 rows of 33 bytes)  - not stored in the file
;  BD00H        back buffer of the VZ screen (512 bytes)
;  BF00H        variables
;  BFF0H        top of stack
VARS        EQU 0BF00H
SHADOW      EQU 0B900H
BACK        EQU 0BD00H
DFILEP      EQU VARS+0         ; word: pointer to SHADOW (stands in for the ZX81 D_FILE system variable)
SAVESP      EQU VARS+2
RNDS        EQU VARS+4
LASTKEY     EQU VARS+6
GFXTP       EQU VARS+7         ; word
GP0A        EQU VARS+9
GP0B        EQU VARS+10
GP1A        EQU VARS+11
GP1B        EQU VARS+12
OVC0        EQU VARS+13
OVW         EQU VARS+14
OVSRC       EQU VARS+15        ; word
VN          EQU VARS+17
VM          EQU VARS+18
VX          EQU VARS+19
VT          EQU VARS+20        ; word
GSPLIT      EQU VARS+22
HELDKEY     EQU VARS+23        ; game key that is currently held down and has already been used
STACK       EQU 0BFF0H

; ---- look and feel ---------------------------------------------------------
PAPER       EQU 0              ; colour of the lit semigraphic cells (0 = green = VZ200 default screen colour)
;  Text polarity on the VZ200: character codes 00H-3FH show light-on-dark ("normal"),
;  40H-7FH show dark-on-green ("inverse").  ZX81 black-on-white text -> inverse,
;  ZX81 inverse-video text -> normal.  Text-only screens use normal.

; ---- timing (milliseconds; the original BASIC ran at about these speeds) -----
T_MAIN      EQU 40             ; main game loop, in 5 ms ticks (200 ms)
T_ESC       EQU 20             ; escape animation loop, in 5 ms ticks
T_SCROLL    EQU 550            ; one step of the scrolling story text

        ORG 8000H

; ==========================================================================
;  START / EXIT
; ==========================================================================
START:  DI
        LD (SAVESP),SP
        LD SP,STACK
        XOR A
        LD (KB),A               ; text mode, colour set 0, speaker off
        LD HL,SHADOW
        LD (DFILEP),HL
        CALL CLSSHADOW
        LD A,R                  ; seed the random number generator
        LD H,A
        LD L,0A7H
        LD (RNDS),HL
        XOR A
        LD (LASTKEY),A
        JP MAIN

EXIT:   LD HL,VRAM              ; blank the screen and return to BASIC (the original's NEW)
        LD DE,VRAM+1
        LD BC,511
        LD (HL),20H
        LDIR
        XOR A
        LD (KB),A
        LD SP,(SAVESP)
        EI
        RET

; ==========================================================================
;  MAIN  -  the original BASIC program, line by line (line numbers in labels)
; ==========================================================================
MAIN:
; ---- 1015-1030  "ANYONE THERE?" ------------------------------------------
M1015:  CALL CLRBACK
        LD D,7
        LD E,9
        LD HL,S_ANYONE
        CALL PRINTAT
        CALL FLUSH
        XOR A
        LD (VN),A
M1025:  LD A,(VN)
        INC A
        LD (VN),A
        CP 100
        JR NZ,M1030
        LD D,9
        LD E,3
        LD HL,S_WELL
        CALL PRINTAT
        CALL FLUSH
M1030:  CALL RND16              ; stir the generator with the timing of the key press
        LD HL,30
        CALL DLYMS
        CALL ANYKEY
        OR A
        JR Z,M1025

; ---- 1040-1130  title picture and story scroll --------------------------------
M1040:  CALL CLSSHADOW
        XOR A
        LD (V_POS),A            ; 1050 POKE 16514,0
        LD HL,T_STORY           ; 1060/1070 text pointer -> start of the story
        LD (V_TXTPTR),HL
        CALL U_TITLEPIC         ; 1080
        CALL BLIT_TITLE
M1090:  CALL U_SCROLL           ; 1090
        CALL BLIT_TITLE
        CALL SUB3000            ; 1100
        LD A,(V_POS)            ; 1110 IF PEEK 16514<58 THEN GOTO 1090
        CP 58
        JR C,M1090
        CALL U_PIC2             ; 1120
        CALL BLIT_TITLE
        LD A,7                  ; 1125 LET S=7
        CALL SUB4000            ; 1130
M1140:  CALL KEYSCAN            ; 1140-1170
        CP 30H                  ; K
        JR Z,M2000
        CP 26H                  ; A
        JP Z,EXIT
        CP 28H                  ; C
        JR Z,M2400
        LD HL,20
        CALL DLYMS
        JR M1140

; ---- 2000-2040  instructions -----------------------------------------------
M2000:  XOR A
        LD (V_POS),A
        CALL U_TITLEPIC
        CALL BLIT_TITLE
M2020:  CALL U_SCROLL
        CALL BLIT_TITLE
        CALL SUB3000
        LD A,(V_POS)
        CP 64
        JR C,M2020
; ---- 2400-2640  "the mists of time" then a new maze ----------------------------
M2400:  CALL SUB6000
        CALL U_PIC2             ; 2500
        CALL BLIT_TITLE
        LD A,8
        CALL SUB4000            ; 2510
M2520:  CALL U_TITLEPIC         ; 2520
        CALL BLIT_TITLE
        XOR A
        LD (V_POS),A            ; 2530
        LD HL,T_STORY+(5AE0H-55A2H)    ; 2540/2550 text pointer -> "THE MISTS OF TIME ..."
        LD (V_TXTPTR),HL
M2560:  CALL U_SCROLL
        CALL BLIT_TITLE
        CALL SUB3000
        LD A,(V_POS)
        CP 14
        JR C,M2560
        LD A,3                  ; 2585
        CALL SUB4000
        CALL U_PIC2             ; 2595
        CALL BLIT_TITLE
        LD A,11                 ; 2600 FOR M=0 TO 10
        LD (VM),A
M2600:  CALL SUB3000
        LD HL,VM
        DEC (HL)
        JR NZ,M2600

; ---- 100-230  generate a maze --------------------------------------------------
M100:   CALL U_MAZEINIT         ; 100
        LD HL,0
        LD (VT),HL              ; 110 LET T=0
M120:   LD A,4                  ; 120 LET X=INT(RND*4)
        CALL RANDN
        LD (VX),A
        LD A,(V_POS)            ; 130 IF PEEK 16514<16 AND RND<.9 THEN LET X=2
        CP 16
        JR NC,M140
        CALL RND16
        LD A,H
        CP 230
        JR NC,M140
        LD A,2
        LD (VX),A
M140:   LD A,(VX)               ; 140 POKE 16517,X
        LD (V_DIR),A
        LD A,6                  ; 150 LET X=INT(RND*6)
        CALL RANDN
        LD (VX),A
        LD HL,(VT)              ; 160 LET T=T+X
        LD E,A
        LD D,0
        ADD HL,DE
        LD (VT),HL
        LD A,(VX)               ; 170 POKE 16516,X
        LD (V_FACING),A
        CALL U_CARVE            ; 180
        LD HL,(VT)              ; 190 IF T<800 THEN GOTO 120
        LD DE,800
        OR A
        SBC HL,DE
        JR C,M120
M200:   LD A,113                ; 200 POKE 16514,INT(RND*113)
        CALL RANDN
        LD (V_POS),A
        CALL U_EXIT             ; 210
        LD A,(V_POS)            ; 220 IF PEEK 16514<>255 THEN GOTO 200
        CP 255
        JR NZ,M200
        CALL U_TREX             ; 230
        LD HL,MAZE              ; (port) the original very occasionally lets the T-Rex's corridor
        LD BC,256               ;  erase the exit; make another maze if that happened
        LD A,2DH
        CPIR
        JR NZ,M100

; ---- 235-310  start of a game ----------------------------------------------------
M235:   CALL CLSSHADOW          ; 235 CLS
        LD HL,S_SCORE           ; 250 PRINT AT 9,27;"SCORE"
        LD DE,SHADOW+1+9*33+27
        LD BC,5
        LDIR
        LD A,255                ; 260 POKE 16514,255
        LD (V_POS),A
        LD A,HIGH(MAZE)         ; 270 POKE 16515,70
        LD (V_POS+1),A
        XOR A                   ; 280 POKE 16519,0
        LD (V_FLAGS),A
        LD A,8                  ; 290 POKE 16523,8
        LD (V_MISC),A
        LD A,1                  ; 300 POKE 16516,1
        LD (V_FACING),A
        CALL U_DRAW             ; 310
        CALL GAMEBLIT
M320:   LD HL,20                ; 320 IF INKEY$="" THEN GOTO 320
        CALL DLYMS
        CALL ANYKEY
        OR A
        JR Z,M320
        XOR A
        LD (LASTKEY),A
        LD (HELDKEY),A

; ---- 330-390  main game loop -------------------------------------------------------
M330:   LD A,128                ; 330 POKE 17901,INT(RND*128)
        CALL RANDN
        LD (V_RANDOM),A
        CALL GETKEYL            ; 340 POKE 16522,CODE INKEY$
        LD (V_KEY),A
        CALL U_STEP             ; 350
        CALL GAMEBLIT
        LD A,(V_FLAGS)          ; 360 IF PEEK 16519>=128 THEN GOTO 5000
        BIT 7,A
        JP NZ,M5000
        LD B,T_MAIN             ; 370-380 delay
        CALL DLYTICKS
        LD HL,(V_POS)           ; 390 IF PEEK(PEEK 16514+17920)<>45 THEN GOTO 330
        LD A,(HL)
        CP 2DH
        JR NZ,M330
        LD A,31                 ; 400 FOR N=0 TO 30
        LD (VN),A
M405:   LD A,128                ; 405 POKE 17901,INT(128*RND)
        CALL RANDN
        LD (V_RANDOM),A
        CALL U_STEP             ; 410
        CALL GAMEBLIT
        LD B,T_ESC              ; 420-430
        CALL DLYTICKS
        LD HL,VN
        DEC (HL)
        JR NZ,M405
        CALL CLSSHADOW          ; 440 CLS
        JP M2520                ; 450 GOTO 2520

; ---- 5000-5160  caught: appeal or continue -----------------------------------------
M5000:  LD A,(V_REXPOS)         ; 5000 LET A=PEEK 16520
        CP 177                  ; 5010 IF A>176 AND (A-16*INT(A/16))>9 THEN LET A=USR 17683
        JR C,M5015
        AND 0FH
        CP 10
        JR C,M5015
        CALL U_TREX
M5015:  CALL ANYKEY             ; (port) wait until every key is up, so a held game key
        OR A                    ;  (A = turn left) cannot choose "appeal" by accident
        JR Z,M5020
        LD HL,20
        CALL DLYMS
        JR M5015
M5020:  CALL KEYSCAN            ; 5020-5040
        CP 26H                  ; A = appeal
        JR Z,M5050
        CP 28H                  ; C = continue
        JR Z,M5150
        LD HL,20
        CALL DLYMS
        JR M5020
M5050:  CALL CLRBACK            ; 5050 CLS
        LD D,7                  ; 5060 PRINT AT 10,10;"APPEAL"
        LD E,10
        LD HL,S_APPEAL
        CALL PRINTAT
        CALL FLUSH
        CALL RND16              ; 5070 IF RND>.5 THEN GOTO 5120
        LD A,H
        CP 128
        JR NC,M5120
        LD D,9                  ; 5080 PRINT AT 12,10;"ACCEPTED"
        LD E,10
        LD HL,S_ACCEPT
        CALL PRINTAT
        CALL FLUSH
        LD HL,1500              ; 5090-5100
        CALL DLYMS
        JP EXIT                 ; 5110 NEW
M5120:  LD D,9                  ; 5120 PRINT AT 12,10;"REJECTED"
        LD E,10
        LD HL,S_REJECT
        CALL PRINTAT
        CALL FLUSH
        LD HL,1000              ; 5130-5140
        CALL DLYMS
M5150:  CALL SUB6000            ; 5150
        JP M235                 ; 5160 GOTO 235

; ---- subroutines of the BASIC program -----------------------------------------------
SUB3000: LD HL,T_SCROLL         ; 3000-3030 delay
        JP DLYMS

SUB4000: INC A                  ; 4000-4050  FOR M=0 TO S: POKE 16514,1: USR 21836: GOSUB 3000: NEXT M
        LD (VM),A
S4000:  LD A,1
        LD (V_POS),A
        CALL U_SCROLL
        CALL BLIT_TITLE
        CALL SUB3000
        LD HL,VM
        DEC (HL)
        JR NZ,S4000
        RET

SUB6000: LD A,1CH               ; 6000-6040 score := 0000
        LD (V_SCORE),A
        LD (V_SCORE+1),A
        LD (V_SCORE+2),A
        LD (V_SCORE+3),A
        RET

; ==========================================================================
;  Keyboard.  VZ200 matrix: read 68xxH, one address bit low selects a row, bits 0-5 = keys (0 = pressed)
;  Returns the ZX81 character code of the key (so the original code sees what it always saw), or 0.
; ==========================================================================
KEYSCAN:                        ; menu keys: A = 26H, C = 28H, K = 30H (ZX81 codes), 0 if none
        LD A,(68FDH)            ; row A1: F A D CTL S G
        BIT 4,A
        LD A,26H                ; 'A'
        RET Z
        LD A,(68FBH)            ; row A2: V Z C SHIFT X B
        BIT 3,A
        LD A,28H                ; 'C'
        RET Z
        LD A,(687FH)            ; row A7: J ; K : L H
        BIT 3,A
        LD A,30H                ; 'K'
        RET Z
        XOR A
        RET

; game keys: A = left, W = forward, D = right  ->  the ZX81 codes the original code expects (5, 7, 8)
GAMEKEY: LD A,(68FDH)           ; row A1: F A D CTL S G
        BIT 4,A
        LD A,21H
        RET Z
        LD A,(68FEH)            ; row A0: R Q E - W T
        BIT 1,A
        LD A,23H
        RET Z
        LD A,(68FDH)
        BIT 3,A
        LD A,24H
        RET Z
        XOR A
        RET

ANYKEY: LD D,0FEH               ; A <> 0 if any key is down
        LD B,8
AK1:    LD H,68H
        LD L,D
        LD A,(HL)
        OR 0C0H
        INC A
        JR NZ,AKYES
        RLC D
        DJNZ AK1
        XOR A
        RET
AKYES:  LD A,1
        RET

GETKEYL: CALL GAMEKEY           ; key down now: use it, and remember that this press has been used
        LD (HELDKEY),A          ;  (A = 0 clears the marker)
        OR A
        JR NZ,GK1
        LD A,(LASTKEY)          ; nothing down now: use a press that came and went during the delay
GK1:    PUSH AF
        XOR A
        LD (LASTKEY),A
        POP AF
        RET

; ==========================================================================
;  Timing and random numbers
; ==========================================================================
DLYMS:  PUSH BC                 ; delay HL milliseconds (3.58 MHz)
D1:     LD B,137
D2:     DJNZ D2
        LD B,137
D3:     DJNZ D3
        DEC HL
        LD A,H
        OR L
        JR NZ,D1
        POP BC
        RET

DLYTICKS: PUSH BC               ; delay B * 5 ms, remembering any NEW game key press made meanwhile
        CALL GAMEKEY
        OR A
        JR NZ,DT1
        LD (HELDKEY),A          ; key is up: forget the 'already used' marker
        JR DT2
DT1:    LD HL,HELDKEY
        CP (HL)
        JR Z,DT2                ; still the press the game already acted on: ignore it
        LD (LASTKEY),A          ; a new press
DT2:    LD HL,5
        CALL DLYMS
        POP BC
        DJNZ DLYTICKS
        RET

RND16:  LD HL,(RNDS)            ; xorshift16
        LD A,H
        RRA
        LD A,L
        RRA
        XOR H
        LD H,A
        LD A,L
        RRA
        LD A,H
        RRA
        XOR L
        LD L,A
        XOR H
        LD H,A
        LD (RNDS),HL
        RET

RANDN:  PUSH BC                 ; A = INT(RND*A)
        PUSH DE
        LD E,A
        CALL RND16
        LD C,H
        LD HL,0
        LD D,0
        LD B,8
RN1:    ADD HL,HL
        RLC C
        JR NC,RN2
        ADD HL,DE
RN2:    DJNZ RN1
        LD A,H
        POP DE
        POP BC
        RET

; ==========================================================================
;  Display.  The original code draws into a ZX81 display file (24 x 32, 33 bytes per row).
;  We keep that display file in RAM (SHADOW) and convert it to the 32 x 16 VZ200 screen:
;    * graphics: every ZX81 block is 2x2 sub-pixels; the picture is re-sampled from 48 to 32 sub-rows
;      and drawn with VZ200 2x2 semigraphics (paper = lit, ink = black, like black-on-white on the ZX81)
;    * text: copied as ASCII to the matching row of the VZ200 screen
; ==========================================================================
CLSSHADOW:                      ; = BASIC CLS
        LD HL,SHADOW
        LD (HL),76H
        INC HL
        LD B,24
CS1:    PUSH BC
        LD B,32
CS2:    LD (HL),0
        INC HL
        DJNZ CS2
        LD (HL),76H
        INC HL
        POP BC
        DJNZ CS1
        RET

CLRBACK: LD HL,BACK
        LD DE,BACK+1
        LD BC,511
        LD (HL),20H
        LDIR
        RET

PRINTAT: PUSH HL                ; D = row, E = column, HL -> zero-terminated ASCII, drawn into BACK
        LD L,D
        LD H,0
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        LD D,0
        ADD HL,DE
        LD DE,BACK
        ADD HL,DE
        EX DE,HL
        POP HL
PA1:    LD A,(HL)
        OR A
        RET Z
        AND 3FH                 ; normal (light on dark) polarity
        LD (DE),A
        INC HL
        INC DE
        JR PA1

FLUSH:  LD HL,BACK              ; copy BACK to the VZ200 screen, writing only what changed
        LD DE,VRAM
        LD BC,512
FL1:    LD A,(DE)
        CP (HL)
        JR Z,FL2
        LD A,(HL)
        LD (DE),A
FL2:    INC HL
        INC DE
        DEC BC
        LD A,B
        OR C
        JR NZ,FL1
FLEND:  RET

GAMEBLIT:                       ; choose the screen layout from the game state
        LD A,(V_FLAGS)
        BIT 7,A
        JR NZ,GB3
        LD HL,(V_POS)
        LD A,(HL)
        CP 2DH
        JR Z,GB2
        LD HL,LAY_GAME
        JR BLIT
GB2:    LD HL,LAY_ESC
        JR BLIT
GB3:    LD HL,LAY_CAUGHT
        JR BLIT

BLIT_TITLE:
        LD HL,LAY_TITLE

; HL -> layout: DW jt, DB split column, DB n, n x (DW rowmap, DB col0, DB col1)
BLIT:   LD E,(HL)
        INC HL
        LD D,(HL)
        INC HL
        LD A,(HL)
        INC HL
        LD (GSPLIT),A
        LD B,(HL)
        INC HL
        PUSH HL
        PUSH BC
        EX DE,HL
        CALL GFX
        POP BC
        POP HL
BL1:    LD A,B
        OR A
        JR Z,BL9
        PUSH BC
        CALL OVERLAY
        POP BC
        DJNZ BL1
BL9:    JP FLUSH

; ---- graphics layer -------------------------------------------------------------------
; HL -> table of 32 entries (one per VZ200 sub-row): DW source row address, DB table page (cols 0-24), DB page (cols 25-31)
; (cols 0..split-1 use page A, the others page B)
GFX:    LD DE,BACK
        LD B,16
GFXROW: PUSH BC
        LD C,(HL)
        INC HL
        LD B,(HL)
        INC HL
        PUSH BC
        POP IX                  ; IX = source row for the upper sub-row
        LD A,(HL)
        INC HL
        LD (GP0A),A
        LD A,(HL)
        INC HL
        LD (GP0B),A
        LD C,(HL)
        INC HL
        LD B,(HL)
        INC HL
        PUSH BC
        POP IY                  ; IY = source row for the lower sub-row
        LD A,(HL)
        INC HL
        LD (GP1A),A
        LD A,(HL)
        INC HL
        LD (GP1B),A
        LD (GFXTP),HL
        LD A,(GP0A)
        LD (M_P0+1),A
        LD A,(GP1A)
        LD (M_P1+1),A
        LD A,(GSPLIT)
        LD C,A
        CALL GCELLS
        LD A,(GP0B)
        LD (M_P0+1),A
        LD A,(GP1B)
        LD (M_P1+1),A
        LD A,(GSPLIT)
        LD C,A
        LD A,32
        SUB C
        LD C,A
        CALL NZ,GCELLS
        LD HL,(GFXTP)
        POP BC
        DJNZ GFXROW
        RET

GCELLS: LD A,(IX+0)             ; ZX81 character in the upper source sub-row
        INC IX
        LD L,A
M_P0:   LD H,0                  ; (patched: page of the lookup table)
        LD A,(HL)               ; 2 sub-pixels (left, right)
        ADD A,A
        ADD A,A
        LD B,A
        LD A,(IY+0)             ; lower sub-row
        INC IY
        LD L,A
M_P1:   LD H,0
        LD A,(HL)
        OR B                    ; 4 sub-pixels: UL UR LL LR = bits 3..0
        XOR 0FH                 ; paper is lit, ink is black
        OR 80H+(PAPER*16)       ; semigraphics character
        LD (DE),A
        INC DE
        DEC C
        JR NZ,GCELLS
        RET

; ---- text layer ----------------------------------------------------------------------
; HL -> DW rowmap (24 bytes: VZ200 row for each ZX81 row, FFH = none), DB first col, DB last col.  Returns HL after.
; ZX81 letters/digits/punctuation are converted with ZX2VZ (normal ZX81 text -> VZ inverse video, ZX81 inverse text -> VZ normal)
OVERLAY: LD E,(HL)
        INC HL
        LD D,(HL)
        INC HL
        LD A,(HL)
        INC HL
        LD (OVC0),A
        LD C,(HL)
        INC HL
        PUSH HL
        LD HL,OVC0
        LD A,C
        SUB (HL)
        INC A
        LD (OVW),A
        PUSH DE
        POP IX                  ; IX -> rowmap
        LD HL,SHADOW+1
        LD A,(OVC0)
        LD E,A
        LD D,0
        ADD HL,DE
        LD (OVSRC),HL
        LD B,24
OVR:    LD A,(IX+0)
        INC IX
        CP 0FFH
        JR Z,OVNEXT
        LD L,A
        LD H,0
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        ADD HL,HL
        LD DE,BACK
        ADD HL,DE
        LD A,(OVC0)
        LD E,A
        LD D,0
        ADD HL,DE
        PUSH BC
        PUSH HL
        POP IY                  ; IY = destination in BACK
        LD HL,(OVSRC)
        LD A,(OVW)
        LD C,A
OVC:    LD A,(HL)
        LD E,A
        LD D,HIGH(ZX2VZ)
        LD A,(DE)               ; 0 = not a text character
        OR A
        JR Z,OVSK
        LD (IY+0),A
OVSK:   INC HL
        INC IY
        DEC C
        JR NZ,OVC
        POP BC
OVNEXT: LD HL,(OVSRC)
        LD DE,33
        ADD HL,DE
        LD (OVSRC),HL
        DJNZ OVR
        POP HL
        RET

; ==========================================================================
;  Replacement for the original's 6x19 "you have eluded him" panel (ZX81 rows do not fit on 16 rows).
;  Called from the original code at 4D28H.  Draws 16 rows x 7 columns into the shadow display file.
; ==========================================================================
PANEL_ESCAPE:
        LD HL,ESCTAB
        LD DE,SHADOW+1+25
        LD B,16
PE1:    PUSH BC
        LD BC,7
        LDIR
        LD BC,33-7
        EX DE,HL
        ADD HL,BC
        EX DE,HL
        POP BC
        DJNZ PE1
        LD DE,1+33*5+27         ; score digits, drawn by the original routine
        JP L4CEF

; ---- text -------------------------------------------------------------------------------
S_ANYONE: DB "ANYONE THERE?",0
S_WELL:   DB "WELL PRESS SOMETHING THEN.",0
S_APPEAL: DB "APPEAL",0
S_ACCEPT: DB "ACCEPTED",0
S_REJECT: DB "REJECTED",0
S_SCORE:  DB 38H,28H,34H,37H,2AH           ; "SCORE" in ZX81 character codes

; 16 rows x 7 columns, ZX81 character codes ("YOU HAVE ELUDED HIM AND SCORED ... POINTS ...")
ESCTAB: DB 0,0,3EH,34H,3AH,0,0                          ;   YOU
        DB 0,2DH,26H,3BH,2AH,0,0                        ;  HAVE
        DB 2AH,31H,3AH,29H,2AH,29H,0                    ; ELUDED
        DB 2DH,2EH,32H,0,26H,33H,29H                    ; HIM AND
        DB 38H,28H,34H,37H,2AH,29H,0                    ; SCORED
        DB 0,0,0,0,0,0,0                                ; (score digits)
        DB 35H,34H,2EH,33H,39H,38H,0                    ; POINTS
        DB 37H,2AH,3DH,0,2EH,38H,0                      ; REX IS
        DB 0,3BH,2AH,37H,3EH,0,0                        ;  VERY
        DB 26H,33H,2CH,37H,3EH,1BH,0                    ; ANGRY.
        DB 3EH,34H,3AH,1AH,31H,31H,0                    ; YOU,LL
        DB 0,33H,2AH,2AH,29H,0,0                        ;  NEED
        DB 0,32H,34H,37H,2AH,0,0                        ;  MORE
        DB 0,31H,3AH,28H,30H,0,0                        ;  LUCK
        DB 0,39H,2DH,2EH,38H,0,0                        ;  THIS
        DB 0,39H,2EH,32H,2AH,1BH,0                      ;  TIME.

; ---- generated tables: layouts, row maps, semigraphic lookup tables ---------------------------
JT_GAME:
        DW SHADOW+1+33*0
        DB 0ACH,0B4H
        DW SHADOW+1+33*1
        DB 0ADH,0B5H
        DW SHADOW+1+33*1
        DB 0AEH,0B6H
        DW SHADOW+1+33*2
        DB 0AFH,0B7H
        DW SHADOW+1+33*3
        DB 0ACH,0B4H
        DW SHADOW+1+33*4
        DB 0ADH,0B5H
        DW SHADOW+1+33*4
        DB 0AEH,0B6H
        DW SHADOW+1+33*5
        DB 0AFH,0B7H
        DW SHADOW+1+33*6
        DB 0AEH,0B6H
        DW SHADOW+1+33*7
        DB 0ADH,0B5H
        DW SHADOW+1+33*8
        DB 0ACH,0B4H
        DW SHADOW+1+33*8
        DB 0AFH,0B7H
        DW SHADOW+1+33*9
        DB 0AEH,0B6H
        DW SHADOW+1+33*10
        DB 0ADH,0B5H
        DW SHADOW+1+33*11
        DB 0ACH,0B4H
        DW SHADOW+1+33*11
        DB 0AFH,0B7H
        DW SHADOW+1+33*12
        DB 0AEH,0B6H
        DW SHADOW+1+33*13
        DB 0ADH,0B5H
        DW SHADOW+1+33*14
        DB 0ACH,0B4H
        DW SHADOW+1+33*14
        DB 0AFH,0B7H
        DW SHADOW+1+33*15
        DB 0AEH,0B6H
        DW SHADOW+1+33*16
        DB 0ADH,0B5H
        DW SHADOW+1+33*17
        DB 0ACH,0B4H
        DW SHADOW+1+33*18
        DB 0ADH,0B5H
        DW SHADOW+1+33*18
        DB 0AEH,0B6H
        DW SHADOW+1+33*19
        DB 0AFH,0B7H
        DW SHADOW+1+33*20
        DB 0ACH,0B4H
        DW SHADOW+1+33*21
        DB 0ADH,0B5H
        DW SHADOW+1+33*21
        DB 0AEH,0B6H
        DW SHADOW+1+33*22
        DB 0AFH,0B7H
        DW SHADOW+1+33*23
        DB 0ACH,0B4H
        DW SHADOW+1+33*23
        DB 0AFH,0B7H
JT_CAUGHT:
        DW SHADOW+1+33*0
        DB 0B4H,0B4H
        DW SHADOW+1+33*1
        DB 0B5H,0B5H
        DW SHADOW+1+33*1
        DB 0B6H,0B6H
        DW SHADOW+1+33*2
        DB 0B7H,0B7H
        DW SHADOW+1+33*3
        DB 0B4H,0B4H
        DW SHADOW+1+33*4
        DB 0B5H,0B5H
        DW SHADOW+1+33*4
        DB 0B6H,0B6H
        DW SHADOW+1+33*5
        DB 0B7H,0B7H
        DW SHADOW+1+33*6
        DB 0B6H,0B6H
        DW SHADOW+1+33*7
        DB 0B5H,0B5H
        DW SHADOW+1+33*8
        DB 0B4H,0B4H
        DW SHADOW+1+33*8
        DB 0B7H,0B7H
        DW SHADOW+1+33*9
        DB 0B6H,0B6H
        DW SHADOW+1+33*10
        DB 0B5H,0B5H
        DW SHADOW+1+33*11
        DB 0B4H,0B4H
        DW SHADOW+1+33*11
        DB 0B7H,0B7H
        DW SHADOW+1+33*12
        DB 0B6H,0B6H
        DW SHADOW+1+33*13
        DB 0B5H,0B5H
        DW SHADOW+1+33*14
        DB 0B4H,0B4H
        DW SHADOW+1+33*14
        DB 0B7H,0B7H
        DW SHADOW+1+33*15
        DB 0B6H,0B6H
        DW SHADOW+1+33*16
        DB 0B5H,0B5H
        DW SHADOW+1+33*17
        DB 0B4H,0B4H
        DW SHADOW+1+33*18
        DB 0B5H,0B5H
        DW SHADOW+1+33*18
        DB 0B6H,0B6H
        DW SHADOW+1+33*19
        DB 0B7H,0B7H
        DW SHADOW+1+33*20
        DB 0B4H,0B4H
        DW SHADOW+1+33*21
        DB 0B5H,0B5H
        DW SHADOW+1+33*21
        DB 0B6H,0B6H
        DW SHADOW+1+33*22
        DB 0B7H,0B7H
        DW SHADOW+1+33*23
        DB 0B4H,0B4H
        DW SHADOW+1+33*23
        DB 0B7H,0B7H
JT_TITLE:
        DW SHADOW+1+33*0
        DB 0B0H,0B4H
        DW SHADOW+1+33*1
        DB 0B1H,0B5H
        DW SHADOW+1+33*1
        DB 0B2H,0B6H
        DW SHADOW+1+33*2
        DB 0B3H,0B7H
        DW SHADOW+1+33*3
        DB 0B2H,0B6H
        DW SHADOW+1+33*4
        DB 0B1H,0B5H
        DW SHADOW+1+33*5
        DB 0B0H,0B4H
        DW SHADOW+1+33*5
        DB 0B3H,0B7H
        DW SHADOW+1+33*6
        DB 0B2H,0B6H
        DW SHADOW+1+33*7
        DB 0B1H,0B5H
        DW SHADOW+1+33*8
        DB 0B0H,0B4H
        DW SHADOW+1+33*9
        DB 0B1H,0B5H
        DW SHADOW+1+33*9
        DB 0B2H,0B6H
        DW SHADOW+1+33*10
        DB 0B3H,0B7H
        DW SHADOW+1+33*11
        DB 0B0H,0B4H
        DW SHADOW+1+33*12
        DB 0B1H,0B5H
        DW SHADOW+1+33*12
        DB 0B2H,0B6H
        DW SHADOW+1+33*13
        DB 0B3H,0B7H
        DW SHADOW+1+33*14
        DB 0B2H,0B6H
        DW SHADOW+1+33*15
        DB 0B1H,0B5H
        DW SHADOW+1+33*16
        DB 0B0H,0B4H
        DW SHADOW+1+33*16
        DB 0B3H,0B7H
        DW SHADOW+1+33*17
        DB 0B2H,0B6H
        DW SHADOW+1+33*18
        DB 0B1H,0B5H
        DW SHADOW+1+33*19
        DB 0B0H,0B4H
        DW SHADOW+1+33*20
        DB 0B1H,0B5H
        DW SHADOW+1+33*20
        DB 0B2H,0B6H
        DW SHADOW+1+33*21
        DB 0B3H,0B7H
        DW SHADOW+1+33*22
        DB 0B0H,0B4H
        DW SHADOW+1+33*22
        DB 0B3H,0B7H
        DW SHADOW+1+33*23
        DB 0B0H,0B4H
        DW SHADOW+1+33*23
        DB 0B3H,0B7H
RM_PANEL:
        DB 0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,06H,07H,0FFH
        DB 0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH
RM_MSG:
        DB 0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH
        DB 0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FH
RM_ESC:
        DB 00H,01H,02H,03H,04H,05H,06H,07H,08H,09H,0AH,0BH
        DB 0CH,0DH,0EH,0FH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH
RM_CAUGHT:
        DB 00H,01H,01H,02H,03H,03H,04H,05H,05H,06H,07H,07H
        DB 08H,09H,09H,0AH,0BH,0BH,0CH,0DH,0DH,0EH,0FFH,0FH
RM_SCROLL:
        DB 0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,00H,01H,02H,03H,04H
        DB 05H,06H,07H,08H,09H,0AH,0BH,0CH,0DH,0FFH,0FFH,0FFH
RM_CREDITS:
        DB 0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH
        DB 0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0FFH,0EH,0FH
LAY_GAME:
        DW JT_GAME
        DB 25,2
        DW RM_PANEL
        DB 26,31
        DW RM_MSG
        DB 0,31
LAY_ESC:
        DW JT_GAME
        DB 25,1
        DW RM_ESC
        DB 25,31
LAY_CAUGHT:
        DW JT_CAUGHT
        DB 25,1
        DW RM_CAUGHT
        DB 0,31
LAY_TITLE:
        DW JT_TITLE
        DB 10,2
        DW RM_SCROLL
        DB 10,31
        DW RM_CREDITS
        DB 0,31

; ==========================================================================
;  ORIGINAL BLOCK (ZX81 3D Monster Maze machine code, relocated by DELTA)
; ==========================================================================
O40A6   EQU 040A6H+DELTA
O40AE   EQU 040AEH+DELTA
O40C0   EQU 040C0H+DELTA
O40D9   EQU 040D9H+DELTA
O40FD   EQU 040FDH+DELTA
O4138   EQU 04138H+DELTA
O4194   EQU 04194H+DELTA
O4214   EQU 04214H+DELTA
O42E1   EQU 042E1H+DELTA
O42E9   EQU 042E9H+DELTA
O46FF   EQU 046FFH+DELTA
O4E33   EQU 04E33H+DELTA
O50C8   EQU 050C8H+DELTA
        ORG 4082H+DELTA
V_POS:
        DB 02H
V_TXTPTR:
        DB 0B8H
V_FACING:
        DB 55H
V_DIR:
        DB 01H,04H
V_FLAGS:
        DB 02H
V_REXPOS:
        DB 7CH,46H
V_KEY:
        DB 23H
V_MISC:
        DB 08H
V_DEPTH:
        DB 01H
V_DIST:
        DB 07H
T_VIEWS:
        DB HIGH(O50C8),LOW(O50C8)
        DB HIGH(O4E33),LOW(O4E33)
        DB HIGH(O42E9),LOW(O42E9)
        DB HIGH(O4214),LOW(O4214)
        DB HIGH(O4194),LOW(O4194)
        DB HIGH(O4138),LOW(O4138)
        DB HIGH(O40FD),LOW(O40FD)
        DB HIGH(O40D9),LOW(O40D9)
        DB HIGH(O40C0),LOW(O40C0)
        DB HIGH(O40AE),LOW(O40AE)
        DB HIGH(O40A6),LOW(O40A6)
        DB HIGH(O42E1),LOW(O42E1)
        DB 01H,78H,01H,80H,20H,01H,80H,00H,01H,57H,01H,83H,1FH,02H,87H,80H
        DB 1FH,03H,87H,80H,05H,1EH,02H,02H,01H,00H,01H,35H,02H,87H,83H,1FH
        DB 02H,02H,07H,1FH,03H,80H,81H,82H,1EH,03H,84H,80H,06H,1EH,03H,03H
        DB 03H,82H,00H,01H,35H,03H,85H,80H,04H,1EH,03H,02H,80H,01H,1DH,04H
        DB 87H,80H,83H,05H,1DH,04H,85H,84H,80H,82H,1EH,03H,80H,80H,80H,1DH
        DB 05H,87H,80H,07H,03H,01H,00H,01H,14H,03H,81H,80H,82H,1DH,04H,85H
        DB 82H,80H,81H,1DH,04H,02H,06H,03H,86H,1DH,05H,85H,80H,83H,80H,05H
        DB 1CH,05H,02H,80H,80H,80H,80H,1CH,05H,87H,80H,80H,80H,05H,1CH,05H
        DB 80H,80H,80H,80H,05H,1BH,06H,87H,81H,05H,03H,80H,05H,1FH,02H,03H
        DB 03H,00H,00H,0D2H,03H,87H,83H,83H,1EH,04H,07H,80H,07H,05H,1CH,05H
        DB 87H,80H,80H,80H,05H,1CH,05H,85H,04H,03H,01H,82H,1CH,06H,80H,82H
        DB 00H,81H,80H,04H,1AH,07H,87H,80H,80H,80H,80H,80H,05H,1AH,07H,85H
        DB 05H,80H,80H,80H,07H,00H,1AH,07H,02H,85H,80H,80H,80H,80H,04H,1BH
        DB 06H,80H,80H,80H,80H,80H,80H,1BH,06H,80H,80H,80H,05H,81H,80H,1BH
        DB 07H,84H,80H,85H,80H,84H,80H,83H,19H,03H,83H,80H,05H,00H,00H,0B0H
        DB 04H,87H,80H,80H,82H,1DH,05H,80H,80H,80H,80H,05H,1CH,05H,80H,81H
        DB 80H,82H,05H,1BH,07H,85H,02H,80H,80H,07H,81H,00H,1AH,07H,81H,05H
        DB 02H,03H,87H,80H,05H,1AH,07H,80H,80H,04H,00H,80H,80H,80H,1AH,08H
        DB 84H,80H,80H,80H,80H,05H,80H,05H,19H,08H,00H,80H,80H,80H,80H,82H
        DB 02H,80H,19H,08H,81H,80H,80H,80H,80H,80H,82H,03H,18H,08H,81H,80H
        DB 80H,80H,80H,80H,80H,80H,19H,09H,80H,80H,84H,80H,80H,07H,80H,80H
        DB 05H,18H,09H,84H,80H,00H,84H,80H,81H,80H,80H,01H,17H,0AH,83H,80H
        DB 07H,00H,02H,80H,05H,80H,07H,00H,1EH,03H,84H,82H,04H,00H,00H,6FH
        DB 04H,83H,83H,83H,04H,1CH,06H,81H,80H,80H,80H,80H,05H,1AH,07H,85H
        DB 80H,80H,80H,80H,80H,80H,1AH,07H,85H,82H,85H,80H,80H,04H,07H,19H
        DB 09H,87H,07H,80H,80H,80H,80H,80H,80H,04H,17H,0AH,00H,80H,80H,02H
        DB 80H,81H,81H,07H,80H,82H,17H,0AH,85H,80H,80H,04H,02H,03H,03H,87H
        DB 80H,80H,17H,0AH,81H,80H,80H,80H,00H,00H,00H,81H,80H,80H,16H,0BH
        DB 87H,80H,05H,80H,80H,82H,83H,81H,80H,80H,07H,16H,0BH,85H,07H,85H
        DB 80H,80H,80H,80H,80H,80H,80H,01H,16H,0BH,85H,01H,81H,80H,80H,80H
        DB 80H,80H,80H,80H,05H,17H,0BH,00H,80H,80H,80H,80H,80H,80H,80H,80H
        DB 80H,04H,16H,0BH,87H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,16H
        DB 0BH,85H,80H,80H,80H,80H,80H,05H,84H,80H,80H,07H,16H,0BH,00H,80H
        DB 80H,80H,80H,80H,80H,80H,80H,80H,05H,17H,0AH,85H,80H,07H,85H,80H
        DB 07H,86H,80H,80H,04H,15H,0CH,87H,83H,80H,80H,05H,00H,03H,00H,02H
        DB 03H,03H,03H,15H,05H,02H,03H,03H,03H,00H,00H,01H,78H,01H,83H,20H
        DB 01H,03H,00H,00H,4DH,06H,87H,83H,83H,83H,83H,04H,1AH,08H,87H,80H
        DB 80H,80H,80H,80H,80H,04H,18H,0AH,87H,80H,80H,80H,80H,80H,80H,80H
        DB 80H,00H,16H,0BH,00H,81H,80H,34H,80H,80H,80H,80H,34H,80H,05H,16H
        DB 0BH,00H,80H,80H,80H,80H,80H,80H,80H,80H,80H,05H,16H,0BH,87H,80H
        DB 80H,80H,80H,84H,07H,80H,80H,80H,05H,15H,0DH,87H,80H,80H,89H,80H
        DB 80H,80H,80H,80H,80H,89H,82H,00H,13H,0EH,00H,80H,80H,05H,0AH,3BH
        DB 3BH,89H,89H,3BH,3BH,88H,80H,05H,13H,0FH,85H,80H,80H,80H,09H,00H
        DB 00H,0AH,0AH,00H,09H,8AH,80H,80H,00H,12H,0FH,85H,80H,80H,80H,88H
        DB 00H,00H,00H,00H,00H,88H,80H,80H,80H,04H,12H,0FH,85H,80H,80H,80H
        DB 8AH,88H,00H,00H,00H,00H,88H,80H,80H,80H,05H,12H,0FH,00H,89H,80H
        DB 80H,80H,88H,09H,00H,00H,09H,8AH,80H,80H,80H,05H,12H,10H,00H,8AH
        DB 89H,80H,80H,80H,8AH,88H,88H,8AH,80H,80H,80H,80H,82H,00H,11H,10H
        DB 00H,84H,8AH,89H,80H,80H,80H,80H,80H,80H,80H,80H,88H,80H,80H,00H
        DB 12H,0FH,02H,80H,8AH,80H,80H,80H,80H,80H,80H,80H,80H,88H,80H,80H
        DB 00H,12H,0FH,00H,84H,80H,80H,07H,80H,80H,05H,81H,80H,80H,88H,80H
        DB 80H,00H,13H,0EH,85H,80H,80H,05H,80H,80H,80H,80H,80H,80H,80H,88H
        DB 07H,00H,11H,0FH,87H,83H,80H,80H,80H,05H,85H,80H,80H,07H,85H,80H
        DB 80H,05H,00H,12H,0FH,85H,80H,80H,80H,07H,00H,00H,03H,01H,00H,85H
        DB 80H,80H,82H,04H,1CH,06H,00H,80H,80H,80H,80H,04H,1CH,05H,02H,03H
        DB 03H,03H,01H,00H,00H,00H,00H,04H,10H,01H,0EAH
U_MAZEINIT:
        LD HL,V_RANDOM+3
        LD BC,011FH
        LD DE,V_RANDOM+4
        LD (HL),80H
        LDIR
        LD HL,O46FF
        LD (V_POS),HL
        RET
U_CARVE:
        LD A,(V_FACING)
        LD B,A
L4439:
        LD DE,0010H
        LD HL,(V_POS)
        LD A,(V_DIR)
        CP 00H
        JP Z,L4465
        CP 01H
        JP Z,L449B
        CP 02H
        JP Z,L445E
        CP 03H
        JP Z,L4457
        RET
L4457:
        INC HL
        LD A,0FH
        AND L
        JR NZ,L44A4
        RET
L445E:
        ADD HL,DE
        LD A,F0H
        AND L
        JR NZ,L446E
        RET
L4465:
        LD A,F0H
        AND L
        JR NZ,L446B
        RET
L446B:
        AND A
        SBC HL,DE
L446E:
        LD A,(HL)
        CP 00H
        JR Z,L448F
        LD A,0FH
        AND L
        JR Z,L4482
        DEC HL
        LD A,(HL)
        CP 00H
        JR NZ,L4481
        RET
L447F:
        JR L4439
L4481:
        INC HL
L4482:
        INC HL
        LD A,0FH
        AND L
        JR Z,L448E
        LD A,(HL)
        CP 00H
        JR NZ,L448E
        RET
L448E:
        DEC HL
L448F:
        LD A,00H
        LD (V_POS),HL
        EX DE,HL
        LD (DE),A
        DJNZ L4439
        LD B,D
        LD C,E
        RET
L449B:
        LD A,L
        AND 0FH
        CP 01H
        JR NZ,L44A3
        RET
L44A3:
        DEC HL
L44A4:
        LD A,(HL)
        CP 00H
        JR Z,L44C7
        LD A,F0H
        AND L
        JR Z,L44B8
        AND A
        SBC HL,DE
        LD A,(HL)
        CP 00H
        JR NZ,L44B7
        RET
L44B7:
        ADD HL,DE
L44B8:
        ADD HL,DE
        LD A,F0H
        AND L
        JR Z,L44C4
        LD A,(HL)
        CP 00H
        JR NZ,L44C4
        RET
L44C4:
        AND A
        SBC HL,DE
L44C7:
        LD (V_POS),HL
        EX DE,HL
        LD A,00H
        LD (DE),A
        DJNZ L447F
        RET
U_EXIT:
        LD HL,MAZE+48
        LD A,(V_POS)
        ADD A,L
        LD L,A
        LD A,(HL)
        CP 00H
        RET NZ
        LD (HL),2DH
        CALL L4D7C
        LD C,00H
        CALL L4504
        LD DE,000FH
        CALL L4504
        LD DE,0002H
        CALL L4504
        LD DE,000FH
        CALL L4504
        LD HL,O46FF
        LD (HL),00H
        LD HL,V_POS
        LD (HL),FFH
        RET
L4504:
        ADD HL,DE
        LD A,(HL)
        CP 00H
        JR NZ,L4512
        BIT 0,C
        JR Z,L4510
        LD (HL),80H
L4510:
        LD C,01H
L4512:
        RET
U_TREX:
        LD HL,MAZE+5
L4516:
        LD B,06H
L4518:
        BIT 7,(HL)
        JR Z,L4525
        INC HL
        DJNZ L4518
        LD BC,000AH
        ADD HL,BC
        JR L4516
L4525:
        LD (V_REXPOS),HL
        LD (HL),32H
        JP L4D92
        DB 00H,00H,00H,00H,05H,0F7H,01H,0EAH,00H
V_SCORE:
        DB 1CH,1CH,1CH,1CH,00H,02H,00H,00H,00H,00H,00H,05H
T_MSGS:
        DB 00H,00H,00H,37H,2AH,3DH,00H,31H,2EH,2AH,38H,00H,2EH,33H,00H,3CH
        DB 26H,2EH,39H,00H,00H,00H,00H,0B7H,0BAH,0B3H,00H,2DH,2AH,00H,2EH,38H
        DB 00H,27H,2AH,2DH,2EH,33H,29H,00H,3EH,34H,3AH,00H,00H,0B7H,0BAH,0B3H
        DB 00H,2DH,2AH,00H,2EH,38H,00H,27H,2AH,38H,2EH,29H,2AH,00H,3EH,34H
        DB 3AH,00H,00H,00H,00H,37H,2AH,3DH,00H,2DH,26H,38H,00H,38H,2AH,2AH
        DB 33H,00H,3EH,34H,3AH,00H,00H,00H,00H,2BH,34H,34H,39H,38H,39H,2AH
        DB 35H,38H,00H,26H,35H,35H,37H,34H,26H,28H,2DH,2EH,33H,2CH,00H,2DH
        DB 2AH,00H,2EH,38H,00H,2DH,3AH,33H,39H,2EH,33H,2CH,00H,2BH,34H,37H
        DB 00H,3EH,34H,3AH
T_BLANK:
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
V_NOISE:
        DB 3BH,8BH,18H,3CH,3DH,27H,2EH,3BH,0A8H,38H,2CH
V_RANDOM:
        DB 4DH,00H,00H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H
        DB 80H,80H,80H
MAZE:
        DB 80H,00H,80H,00H,80H,80H,32H,80H,80H,80H,80H,80H,80H,80H,80H,00H
        DB 80H,00H,00H,00H,00H,00H,08H,00H,00H,00H,00H,00H,00H,80H,80H,00H
        DB 80H,00H,80H,00H,80H,80H,08H,80H,80H,80H,00H,80H,80H,80H,80H,00H
        DB 80H,08H,08H,08H,08H,08H,08H,80H,80H,80H,00H,00H,00H,00H,00H,00H
        DB 80H,08H,80H,08H,80H,80H,08H,80H,80H,80H,2DH,80H,80H,80H,80H,00H
        DB 80H,08H,80H,08H,80H,80H,08H,80H,80H,80H,80H,80H,80H,80H,80H,00H
        DB 80H,08H,00H,08H,00H,00H,08H,08H,08H,08H,08H,80H,80H,80H,80H,00H
        DB 80H,08H,80H,08H,80H,80H,08H,80H,80H,80H,08H,08H,08H,08H,00H,00H
        DB 80H,08H,80H,08H,80H,80H,08H,08H,08H,08H,80H,80H,08H,80H,80H,00H
        DB 80H,08H,08H,08H,08H,08H,08H,80H,80H,08H,80H,80H,08H,80H,80H,00H
        DB 80H,00H,80H,08H,80H,80H,00H,80H,80H,08H,80H,80H,08H,80H,80H,00H
        DB 80H,00H,80H,08H,80H,80H,00H,80H,80H,08H,80H,80H,08H,80H,80H,00H
        DB 80H,00H,00H,08H,08H,08H,08H,08H,08H,08H,08H,08H,08H,00H,00H,00H
        DB 80H,00H,80H,00H,80H,80H,00H,80H,80H,00H,80H,80H,00H,80H,80H,80H
        DB 80H,00H,80H,00H,80H,80H,00H,80H,80H,00H,80H,80H,00H,00H,00H,00H
        DB 80H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,80H,80H,80H,00H
        DB 80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,07H,76H,06H,0EAH
U_STEP:
        LD HL,V_FLAGS
        LD A,(V_KEY)
        CP 00H
        JR NZ,L4743
L473A:
        SET 5,(HL)
        BIT 4,(HL)
        JP L4D6C
        DB 18H,2DH
L4743:
        CP 23H
        JR NZ,L474B
        SET 6,(HL)
        JR L476C
L474B:
        CP 21H
        JR NZ,L475B
        LD A,(V_FACING)
        INC A
        CP 04H
        JR NZ,L4769
        LD A,00H
        JR L4769
L475B:
        CP 24H
        JR NZ,L473A
        LD A,(V_FACING)
        CP 00H
        JR NZ,L4768
        LD A,04H
L4768:
        DEC A
L4769:
        LD (V_FACING),A
L476C:
        RES 5,(HL)
        RES 7,(HL)
U_DRAW:
        LD HL,(V_POS)
        LD A,(HL)
        CP 2DH
        JP Z,L4B2F
        LD A,00H
        LD (V_DEPTH),A
        LD A,07H
        LD (V_DIST),A
        CALL L4A52
        CALL L4A34
        LD A,(V_FACING)
        CP 00H
        JR NZ,L4798
        LD DE,FFF0H
        LD BC,0001H
        JR L47B9
L4798:
        CP 01H
        JR NZ,L47A4
        LD DE,FFFFH
        LD BC,FFF0H
        JR L47B9
L47A4:
        CP 02H
        JR NZ,L47B0
        LD DE,0010H
        LD BC,FFFFH
        JR L47B9
L47B0:
        CP 03H
        RET NZ
        LD DE,0001H
        LD BC,0010H
L47B9:
        LD HL,V_FLAGS
        BIT 5,(HL)
        LD HL,(V_POS)
        JP NZ,L4ADF
        LD A,(V_FLAGS)
        BIT 6,A
        JR Z,L47D9
        ADD HL,DE
        BIT 7,(HL)
        JP Z,L47D9
        RES 6,A
        LD (V_FLAGS),A
        JP L4AF4
L47D9:
        LD A,(V_FLAGS)
        RES 4,A
        LD (V_FLAGS),A
        LD (V_POS),HL
        PUSH DE
        PUSH BC
        PUSH HL
        ADD HL,BC
        LD BC,0100H
        LD (V_DIR),BC
        CALL L4884
        POP HL
        POP BC
        PUSH HL
        AND A
        SBC HL,BC
        PUSH BC
        CALL L4904
        LD BC,0401H
L47FF:
        LD (V_DIR),BC
        LD HL,V_DEPTH
        INC (HL)
        POP BC
        POP HL
        POP DE
        ADD HL,DE
        BIT 7,(HL)
        JP NZ,L49F6
        LD A,(V_REXPOS)
        CP L
        JR NZ,L481C
        LD A,(V_DEPTH)
        LD (V_DIST),A
L481C:
        LD A,(HL)
        CP 2DH
        JR NZ,L4829
        LD A,(V_FLAGS)
        SET 4,A
        LD (V_FLAGS),A
L4829:
        PUSH DE
        PUSH BC
        PUSH HL
        ADD HL,BC
        CALL L4884
        POP HL
        POP BC
        PUSH HL
        AND A
        SBC HL,BC
        PUSH BC
        CALL L4904
        LD A,(V_DIR+1)
        LD B,A
        DJNZ L47FF
        LD B,01H
        LD A,C
        CP 0CH
        JR C,L47FF
        POP DE
        POP HL
        POP DE
        ADD HL,DE
        PUSH HL
        LD HL,(DFILEP)
        PUSH BC
        LD BC,000DH
        ADD HL,BC
        LD DE,0021H
        LD B,17H
L4859:
        LD (HL),00H
        ADD HL,DE
        DJNZ L4859
        POP BC
        LD HL,(DFILEP)
        LD DE,0178H
        ADD HL,DE
        POP DE
        EX DE,HL
        BIT 7,(HL)
        JR NZ,L4878
        LD A,83H
        LD (DE),A
        LD HL,0021H
        ADD HL,DE
        LD (HL),03H
        JP L4987
L4878:
        LD A,09H
        LD (DE),A
        LD HL,0021H
        ADD HL,DE
        LD (HL),0AH
        JP L4987
L4884:
        LD BC,(V_DIR)
        BIT 7,(HL)
        JR NZ,L48C1
L488C:
        LD HL,(DFILEP)
        LD A,19H
        SUB C
        LD E,A
        LD D,00H
        ADD HL,DE
        LD DE,0021H
        LD A,C
        CP 00H
        LD A,B
        LD B,17H
        JR NZ,L48A2
        INC B
L48A2:
        LD (HL),00H
        ADD HL,DE
        DJNZ L48A2
        LD B,A
        LD A,C
        CP 0BH
        JR Z,L48B1
        INC C
        DJNZ L488C
        RET
L48B1:
        LD HL,(DFILEP)
        LD DE,0179H
        ADD HL,DE
        LD DE,0021H
        LD (HL),09H
        ADD HL,DE
        LD (HL),0AH
        RET
L48C1:
        PUSH BC
        LD DE,0019H
        LD HL,(DFILEP)
        ADD HL,DE
        LD DE,0021H
        LD A,16H
        LD B,C
        SLA B
        SUB B
        LD B,00H
        AND A
        SBC HL,BC
        LD B,C
        PUSH AF
        LD A,B
        CP 00H
        JR Z,L48E3
L48DE:
        LD (HL),00H
        ADD HL,DE
        DJNZ L48DE
L48E3:
        POP AF
        LD (HL),81H
        LD B,A
        CP 00H
        JR Z,L48F0
L48EB:
        ADD HL,DE
        LD (HL),80H
        DJNZ L48EB
L48F0:
        ADD HL,DE
        LD (HL),84H
        LD A,C
        CP 02H
        JR C,L48FF
        LD B,A
        DEC B
L48FA:
        ADD HL,DE
        LD (HL),00H
        DJNZ L48FA
L48FF:
        POP BC
        INC C
        DJNZ L48C1
        RET
L4904:
        LD BC,(V_DIR)
        BIT 7,(HL)
        JR NZ,L4949
L490C:
        LD D,00H
        LD E,C
        LD HL,(DFILEP)
        INC HL
        ADD HL,DE
        LD DE,0021H
        LD A,C
        CP 00H
        LD A,B
        LD B,17H
        JR NZ,L4920
        INC B
L4920:
        LD (HL),00H
        ADD HL,DE
        DJNZ L4920
        LD B,A
        LD A,C
        CP 0BH
        JR Z,L4936
        INC C
        DJNZ L490C
        LD BC,(V_DIR)
        LD A,B
        ADD A,C
        LD C,A
        RET
L4936:
        LD HL,(DFILEP)
        LD DE,0177H
        ADD HL,DE
        LD DE,0021H
        LD (HL),09H
        ADD HL,DE
        LD (HL),0AH
        LD BC,000CH
        RET
L4949:
        PUSH BC
        LD DE,0021H
        LD HL,(DFILEP)
        INC HL
        LD A,16H
        LD B,C
        SLA B
        SUB B
        LD B,00H
        ADD HL,BC
        LD B,C
        PUSH AF
        LD A,B
        CP 00H
        JR Z,L4966
L4961:
        LD (HL),00H
        ADD HL,DE
        DJNZ L4961
L4966:
        POP AF
        LD (HL),82H
        LD B,A
        CP 00H
        JR Z,L4973
L496E:
        ADD HL,DE
        LD (HL),80H
        DJNZ L496E
L4973:
        ADD HL,DE
        LD (HL),07H
        LD B,C
        LD A,C
        CP 02H
        JR C,L4982
        DEC B
L497D:
        ADD HL,DE
        LD (HL),00H
        DJNZ L497D
L4982:
        POP BC
        INC C
        DJNZ L4949
        RET
L4987:
        LD BC,000CH
        LD HL,(DFILEP)
        ADD HL,BC
        LD B,01H
        LD DE,016BH
        ADD HL,DE
        LD DE,0021H
L4997:
        AND A
        SBC HL,DE
        DEC HL
        DEC C
        JR Z,L49BD
        LD A,(HL)
        CP 00H
        JR Z,L49A7
        LD B,01H
        JR L4997
L49A7:
        LD A,0DH
        SUB C
        SUB B
        SLA A
        PUSH BC
        PUSH HL
L49AF:
        ADD HL,DE
        DJNZ L49AF
        LD B,A
L49B3:
        LD (HL),08H
        ADD HL,DE
        DJNZ L49B3
        POP HL
        POP BC
        INC B
        JR L4997
L49BD:
        LD HL,(DFILEP)
        LD DE,0179H
        ADD HL,DE
        LD BC,010CH
        LD DE,0021H
L49CA:
        AND A
        SBC HL,DE
        INC HL
        DEC C
        JR NZ,L49D7
        CALL L4A34
        JP L4AF4
L49D7:
        LD A,(HL)
        CP 00H
        JR Z,L49E0
        LD B,01H
        JR L49CA
L49E0:
        LD A,0DH
        SUB C
        SUB B
        SLA A
        PUSH BC
        PUSH HL
L49E8:
        ADD HL,DE
        DJNZ L49E8
        LD B,A
L49EC:
        LD (HL),08H
        ADD HL,DE
        DJNZ L49EC
        POP HL
        POP BC
        INC B
        JR L49CA
L49F6:
        LD HL,(DFILEP)
        INC HL
        LD DE,0021H
        LD BC,(V_DIR)
        LD B,00H
        ADD HL,BC
        LD A,19H
        LD B,C
        SLA B
        SUB B
        LD B,A
        SUB 01H
L4A0D:
        PUSH BC
        PUSH HL
        LD B,C
L4A10:
        LD (HL),00H
        ADD HL,DE
        DJNZ L4A10
        LD B,A
L4A16:
        LD (HL),08H
        ADD HL,DE
        DJNZ L4A16
        LD B,C
        DEC B
        JR Z,L4A24
L4A1F:
        LD (HL),00H
        ADD HL,DE
        DJNZ L4A1F
L4A24:
        POP HL
        INC HL
        POP BC
        DJNZ L4A0D
        LD A,(V_FLAGS)
        BIT 4,A
        CALL NZ,L4B2F
        JP L4987
L4A34:
        LD HL,(V_POS)
        LD A,(V_REXPOS)
        CP L
        RET NZ
        POP AF
        LD A,00H
        LD (V_DIST),A
        LD A,(V_FLAGS)
        BIT 1,A
        JP Z,L4AF4
        SET 7,A
        LD (V_FLAGS),A
        JP L4AF4
L4A52:
        LD HL,V_FLAGS
        LD A,(HL)
        BIT 5,A
        JR NZ,L4A5C
        SET 0,A
L4A5C:
        INC A
        BIT 2,A
        JR NZ,L4A63
        LD (HL),A
        RET
L4A63:
        AND F0H
        LD (HL),A
        LD HL,V_POS
        LD A,00H
        RRD
        LD B,A
        RRD
        LD D,A
        RRD
        LD HL,V_REXPOS
        RRD
        LD C,A
        PUSH BC
        RRD
        LD E,A
        PUSH DE
        RRD
        LD A,B
        CP C
        JR NC,L4A88
        LD A,C
        SUB B
        JR L4A89
L4A88:
        SUB C
L4A89:
        LD C,A
        LD A,D
        CP E
        JR NC,L4A92
        LD A,E
        SUB D
        JR L4A93
L4A92:
        SUB E
L4A93:
        CP C
        POP DE
        POP BC
        CALL NC,L4AA0
        CALL C,L4ABE
        CALL C,L4AA0
        RET
L4AA0:
        LD HL,(V_REXPOS)
        LD A,D
        PUSH BC
        LD BC,0010H
        CP E
        JR NC,L4AB0
        AND A
        SBC HL,BC
        JR L4AB3
L4AB0:
        JR Z,L4ABB
        ADD HL,BC
L4AB3:
        POP BC
        BIT 7,(HL)
        SCF
        RET NZ
        AND A
        JR L4AD3
L4ABB:
        POP BC
        SCF
        RET
L4ABE:
        LD HL,(V_REXPOS)
        LD A,B
        CP C
        JR NC,L4AC8
        DEC HL
        JR L4ACB
L4AC8:
        JR Z,L4AD1
        INC HL
L4ACB:
        BIT 7,(HL)
        SCF
        RET NZ
        JR L4AD3
L4AD1:
        SCF
        RET
L4AD3:
        LD (V_REXPOS),HL
        SET 3,(HL)
        LD HL,V_FLAGS
        SET 3,(HL)
        POP DE
        RET
L4ADF:
        LD B,00H
        LD A,(V_REXPOS)
        JR L4AED
L4AE6:
        ADD HL,DE
        BIT 7,(HL)
        JP NZ,L4B92
        INC B
L4AED:
        CP L
        JR NZ,L4AE6
        LD A,B
        LD (V_DIST),A
L4AF4:
        LD A,(V_DIST)
        CP 06H
        JP NC,L4B92
        LD DE,T_VIEWS
        LD HL,V_FLAGS
        SLA A
        SLA A
        BIT 1,(HL)
        JR NZ,L4B0D
        LD L,02H
        ADD A,L
L4B0D:
        LD L,A
        LD H,00H
        ADD HL,DE
        LD D,(HL)
        INC HL
        LD E,(HL)
        EX DE,HL
        LD B,(HL)
        INC HL
        LD DE,(DFILEP)
L4B1B:
        EX DE,HL
        LD A,(DE)
        CP 00H
        JP Z,L4CB3
        LD C,A
        ADD HL,BC
        INC DE
        LD A,(DE)
        LD B,00H
        LD C,A
        INC DE
        EX DE,HL
        LDIR
        JR L4B1B
L4B2F:
        LD A,(V_RANDOM)
        CP 40H
        JR C,L4B38
        ADD A,40H
L4B38:
        LD (V_RANDOM),A
        LD HL,V_NOISE+1
        LD DE,V_NOISE
        LD BC,000CH
        LDIR
        LD BC,(V_DIR)
        LD B,00H
        LD A,0CH
        SUB C
        SLA A
        LD C,A
        CP 04H
        RET C
        LD DE,(DFILEP)
        LD HL,0199H
        ADD HL,DE
        LD DE,V_NOISE+10
        LD A,(DE)
        LD (HL),A
L4B62:
        DEC DE
        PUSH DE
        LD A,(DE)
        INC B
        INC B
        PUSH BC
        DEC HL
        LD DE,0021H
        AND A
        SBC HL,DE
L4B6F:
        INC HL
        LD (HL),A
        DJNZ L4B6F
        POP BC
        DEC B
        PUSH BC
L4B76:
        ADD HL,DE
        LD (HL),A
        DJNZ L4B76
        POP BC
        INC B
        PUSH BC
L4B7D:
        DEC HL
        LD (HL),A
        DJNZ L4B7D
        POP BC
        DEC B
        PUSH BC
L4B84:
        AND A
        SBC HL,DE
        LD (HL),A
        DJNZ L4B84
        POP BC
        INC B
        POP DE
        LD A,B
        CP C
        JR C,L4B62
        RET
L4B92:
        LD A,(V_FLAGS)
        BIT 3,A
        JR NZ,L4BB9
        LD HL,V_MISC
        LD A,08H
        CP (HL)
        JR Z,L4BA2
        INC (HL)
L4BA2:
        LD DE,0000H
        JP L4CB0
L4BA8:
        BIT 7,A
        RET Z
        CPL
        INC A
        RET
L4BAE:
        LD A,00H
        RRD
        LD C,A
        RRD
        LD B,A
        RRD
        RET
L4BB9:
        LD HL,V_REXPOS
        CALL L4BAE
        PUSH BC
        POP DE
        LD HL,V_POS
        CALL L4BAE
        LD A,B
        SUB D
        LD B,A
        LD A,C
        SUB E
        LD C,A
        CP 00H
        JR NZ,L4BF9
        LD A,B
        CALL L4BA8
        CP 07H
        JR NC,L4C26
        PUSH BC
        CALL L4C57
        POP BC
        LD A,B
        CALL L4BA8
        CP 03H
        JR NC,L4C51
        LD A,(V_FACING)
        BIT 0,A
        JR NZ,L4BF3
        LD DE,0016H
        JP L4CB0
L4BF3:
        LD DE,002CH
        JP L4CB0
L4BF9:
        LD A,B
        CP 00H
        JR NZ,L4C26
        LD A,C
        CALL L4BA8
        CP 07H
        JR NC,L4C26
        PUSH BC
        CALL L4C57
        POP BC
        LD A,C
        CALL L4BA8
        CP 03H
        JR NC,L4C51
        LD A,(V_FACING)
        BIT 0,A
        JR Z,L4C20
        LD DE,0016H
        JP L4CB0
L4C20:
        LD DE,002CH
        JP L4CB0
L4C26:
        LD A,B
        CALL L4BA8
        LD B,A
        LD A,C
        CALL L4BA8
        ADD A,B
        CP 09H
        JR C,L4C45
        LD A,(V_MISC)
        CP 00H
        JR Z,L4C4B
        DEC A
        LD (V_MISC),A
        LD DE,006EH
        JP L4CB0
L4C45:
        LD DE,0058H
        JP L4CB0
L4C4B:
        LD DE,0084H
        JP L4CB0
L4C51:
        LD DE,0042H
        JP L4CB0
L4C57:
        LD A,B
        CP 00H
        JR Z,L4C6E
        CALL L4BA8
        BIT 7,B
        LD B,A
        JR Z,L4C69
        LD DE,0010H
        JR L4C7F
L4C69:
        LD DE,FFF0H
        JR L4C7F
L4C6E:
        LD A,C
        CALL L4BA8
        BIT 7,C
        LD B,A
        JR Z,L4C7C
        LD DE,0001H
        JR L4C7F
L4C7C:
        LD DE,FFFFH
L4C7F:
        LD HL,(V_POS)
L4C82:
        ADD HL,DE
        BIT 7,(HL)
        JR NZ,L4C8A
        DJNZ L4C82
        RET
L4C8A:
        POP DE
        POP BC
        JP L4C26
L4C8F:
        LD A,E
        CP 6EH
        JR Z,L4C9D
        CP 00H
        JR Z,L4C9D
        LD A,00H
        LD (V_MISC),A
L4C9D:
        LD HL,T_MSGS
        ADD HL,DE
        EX DE,HL
        LD HL,(DFILEP)
        LD BC,02F9H
        ADD HL,BC
        EX DE,HL
        LD BC,0016H
        LDIR
        RET
L4CB0:
        CALL L4C8F
L4CB3:
        LD HL,V_FLAGS
        LD A,48H
        AND (HL)
        CP 48H
        RES 6,(HL)
        JR NZ,L4CC5
        LD DE,V_SCORE+11
        CALL L4D0D
L4CC5:
        LD HL,V_FLAGS
        BIT 7,(HL)
        JR Z,L4CD1
        LD DE,018DH
        JR L4CEF
L4CD1:
        LD HL,(V_POS)
        LD A,(HL)
        CP 2DH
        JR NZ,L4CE1
        LD DE,V_SCORE+7
        CALL L4D0D
        JR L4D28
L4CE1:
        LD A,(V_DIST)
        JP L4D58
L4CE7:
        CP 06H
        CALL C,L4C9D
L4CEC:
        LD DE,0166H
L4CEF:
        LD HL,(DFILEP)
        ADD HL,DE
        EX DE,HL
        LD HL,V_SCORE
        LD B,04H
L4CF9:
        LD A,(HL)
        CP 1CH
        JR NZ,L4D06
        LD A,00H
        LD (DE),A
        INC HL
        INC DE
        DJNZ L4CF9
        RET
L4D06:
        LD A,(HL)
        LD (DE),A
        INC HL
        INC DE
        DJNZ L4D06
        RET
L4D0D:
        LD HL,V_SCORE+3
        LD B,04H
        AND A
L4D13:
        LD A,(DE)
        ADC A,(HL)
        DEC DE
        CP 26H
        JR C,L4D22
        SUB 0AH
        LD (HL),A
        DEC HL
        SCF
        DJNZ L4D13
        RET
L4D22:
        LD (HL),A
        DEC HL
        AND A
        DJNZ L4D13
        RET
L4D28:                      ; (port) escape panel - drawn by PANEL_ESCAPE in the glue (16 rows)
        CALL PANEL_ESCAPE
        LD DE,0084H
        JP L4C9D
        DS 31,0
        DB 00H,00H,00H,00H,00H,00H,00H,00H
L4D58:
        CP 00H
        JP Z,L4CEC
        LD DE,0084H
        JP L4CE7
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H
L4D6C:
        LD A,(V_DIST)
        CP 00H
        JP Z,U_DRAW
        BIT 4,(HL)
        CALL NZ,L4B2F
        JP U_DRAW
L4D7C:                      ; (orig) anti-tamper check of the ZX81 display file - removed in the port
        PUSH HL
        LD DE,0FFF0H        ; (orig side effect kept: DE = -16 = one row up in the maze)
        POP HL
        RET
        DS 12,0
        DB 00H,00H,00H,00H
L4D92:
        LD (V_POS),HL
        LD HL,V_FACING
        LD (HL),0AH
        INC HL
        LD (HL),03H
        JP U_CARVE
        DB 00H,00H,00H,00H,00H,00H,0AH,85H,00H,0EAH
T_ESCAPE:
        DB 00H,3EH,34H,3AH,00H,00H,00H,2DH,26H,3BH,2AH,00H,2AH,31H,3AH,29H
        DB 2AH,29H,00H,2DH,2EH,32H,00H,00H,00H,26H,33H,29H,00H,00H,38H,28H
        DB 34H,37H,2AH,29H,00H,00H,00H,00H,00H,00H,35H,34H,2EH,33H,39H,38H
        DB 00H,00H,00H,00H,00H,00H,37H,2AH,3DH,00H,2EH,38H,00H,3BH,2AH,37H
        DB 3EH,00H,26H,33H,2CH,37H,3EH,1BH,00H,00H,00H,00H,00H,00H,3EH,34H
        DB 3AH,1AH,31H,31H,00H,33H,2AH,2AH,29H,00H,00H,32H,34H,37H,2AH,00H
        DB 00H,31H,3AH,28H,30H,00H,00H,39H,2DH,2EH,38H,00H,00H,39H,2EH,32H
        DB 2AH,1BH,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,0CH,91H,02H,0EAH,00H,01H,19H,80H,80H,03H,01H
        DB 00H,00H,81H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,82H,00H,00H
        DB 84H,80H,85H,80H,80H,08H,19H,00H,00H,00H,00H,87H,81H,80H,80H,80H
        DB 80H,80H,80H,80H,80H,80H,80H,80H,05H,00H,00H,00H,84H,82H,80H,80H
        DB 08H,19H,83H,83H,83H,81H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H
        DB 80H,80H,80H,80H,04H,00H,00H,00H,02H,03H,01H,08H,19H,80H,80H,80H
        DB 80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H
        DB 83H,00H,00H,00H,00H,00H,08H,19H,80H,80H,80H,80H,80H,80H,80H,80H
        DB 03H,00H,00H,84H,80H,80H,80H,03H,03H,80H,80H,80H,80H,82H,83H,83H
        DB 83H,08H,19H,80H,80H,80H,80H,80H,80H,80H,82H,04H,00H,00H,81H,80H
        DB 80H,05H,00H,00H,02H,80H,80H,80H,80H,80H,80H,80H,08H,19H,80H,80H
        DB 80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,83H,83H
        DB 80H,80H,80H,80H,80H,80H,80H,08H,19H,80H,80H,80H,80H,80H,80H,80H
        DB 80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H
        DB 80H,80H,08H,19H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H
        DB 80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,08H,19H,80H
        DB 07H,84H,80H,03H,00H,00H,80H,05H,00H,00H,06H,80H,00H,00H,87H,84H
        DB 80H,07H,03H,03H,84H,80H,80H,80H,08H,19H,05H,00H,85H,84H,04H,00H
        DB 85H,84H,05H,00H,87H,01H,80H,04H,00H,06H,85H,80H,05H,00H,00H,87H
        DB 84H,07H,03H,08H,19H,05H,00H,05H,02H,05H,00H,05H,02H,05H,00H,06H
        DB 00H,84H,05H,87H,01H,00H,80H,05H,00H,00H,06H,85H,05H,00H,08H,19H
        DB 82H,85H,00H,00H,85H,06H,00H,00H,84H,07H,00H,00H,02H,80H,01H,00H
        DB 00H,84H,80H,00H,06H,00H,85H,05H,00H,08H,19H,84H,06H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,03H,03H,00H
        DB 00H,00H,80H,87H,08H,19H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,03H,01H,08H
        DB 19H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,08H,19H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,08H,19H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 08H,19H,00H,81H,82H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,08H,19H,81H,07H,84H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,08H,19H,80H,01H,00H,05H,00H,00H,87H,83H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,08H,19H,05H,00H,00H,05H,87H,80H,03H,01H,05H,00H,00H,87H,04H
        DB 00H,00H,00H,83H,00H,00H,00H,00H,00H,00H,00H,00H,08H,19H,80H,83H
        DB 00H,82H,80H,01H,00H,00H,85H,00H,87H,80H,03H,04H,00H,85H,07H,86H
        DB 00H,87H,80H,86H,00H,00H,04H,08H,19H,80H,80H,80H,80H,05H,00H,00H
        DB 00H,05H,00H,81H,01H,00H,85H,00H,80H,00H,02H,04H,81H,01H,00H,86H
        DB 85H,05H,00H,00H,00H,00H,00H,00H,00H,00H,0EH,9EH,02H,0EAH,00H,01H
        DB 19H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H
        DB 80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,08H,19H,80H,80H,80H,80H
        DB 80H,07H,03H,03H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H
        DB 80H,80H,80H,80H,80H,08H,19H,80H,03H,00H,85H,80H,05H,00H,00H,85H
        DB 01H,80H,80H,00H,02H,03H,07H,80H,80H,80H,80H,80H,80H,80H,80H,80H
        DB 08H,19H,80H,00H,00H,07H,85H,05H,00H,00H,05H,00H,84H,05H,00H,00H
        DB 87H,01H,80H,80H,03H,84H,80H,80H,80H,80H,80H,08H,19H,85H,00H,00H
        DB 05H,00H,84H,00H,85H,00H,00H,85H,01H,00H,87H,01H,00H,80H,80H,00H
        DB 00H,87H,03H,80H,80H,80H,08H,19H,02H,05H,85H,01H,00H,00H,03H,01H
        DB 00H,00H,02H,83H,83H,01H,00H,00H,80H,01H,00H,00H,05H,00H,81H,80H
        DB 80H,08H,19H,00H,03H,81H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,80H,00H,87H,06H,00H,00H,80H,03H,00H,08H,19H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,84H,83H
        DB 01H,00H,00H,87H,80H,00H,00H,08H,19H,3EH,34H,3AH,00H,2DH,26H,3BH
        DB 2AH,00H,27H,2AH,2AH,33H,00H,00H,00H,00H,00H,00H,00H,00H,85H,05H
        DB 00H,83H,08H,20H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,85H,83H,03H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,01H,20H,35H,34H,38H,39H,2DH,3AH,32H,34H,3AH,38H
        DB 31H,3EH,00H,26H,3CH,26H,37H,29H,2AH,29H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,01H,19H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,08H,19H,00H,00H,00H,00H,00H,35H,34H,2EH,33H,39H,38H,00H,26H
        DB 33H,29H,00H,38H,2AH,33H,39H,2AH,33H,28H,2AH,29H,08H,19H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,08H,19H,39H,34H,00H,37H,34H,26H,32H
        DB 00H,39H,2DH,2AH,00H,32H,26H,3FH,2AH,00H,2BH,34H,37H,2AH,3BH,2AH
        DB 37H,1BH,08H,19H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,08H,19H,80H
        DB 80H,82H,00H,2EH,2BH,00H,3EH,34H,3AH,00H,3CH,2EH,38H,2DH,00H,39H
        DB 34H,00H,26H,35H,35H,2AH,26H,31H,08H,19H,03H,00H,80H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,08H,19H,00H,00H,07H,00H,87H,81H,84H,00H,35H,37H,2AH
        DB 38H,38H,00H,0A6H,1AH,00H,2AH,31H,38H,2AH,00H,00H,00H,00H,08H,19H
        DB 00H,87H,01H,81H,07H,00H,85H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,08H,19H,82H,06H,81H,07H,00H
        DB 00H,85H,00H,00H,00H,83H,04H,00H,35H,37H,2AH,38H,38H,00H,0A8H,1BH
        DB 00H,00H,00H,00H,08H,19H,80H,80H,80H,00H,00H,00H,06H,00H,87H,80H
        DB 01H,84H,00H,00H,83H,04H,00H,00H,00H,00H,00H,00H,00H,00H,00H,08H
        DB 19H,80H,80H,80H,82H,00H,87H,01H,87H,80H,01H,00H,06H,00H,81H,05H
        DB 86H,00H,87H,04H,00H,00H,00H,00H,00H,00H,08H,19H,80H,80H,80H,80H
        DB 80H,80H,83H,80H,01H,00H,87H,01H,81H,07H,00H,85H,00H,07H,85H,00H
        DB 87H,03H,04H,00H,00H,00H,00H,00H,00H,00H,00H,00H,10H,0ABH,01H,0EAH
T_TITLEPIC:
        DB 80H,80H,80H,07H,03H,84H,80H,80H,80H,80H,80H,80H,80H,05H,00H,85H
        DB 80H,80H,80H,80H,80H,80H,83H,16H,16H,16H,83H,89H,80H,80H,80H,80H
        DB 80H,15H,34H,15H,80H,8AH,00H,80H,80H,80H,80H,04H,14H,87H,80H,07H
        DB 00H,80H,80H,80H,07H,02H,83H,01H,84H,05H,00H,84H,80H,01H,00H,00H
        DB 00H,00H,00H,2EH,00H,85H,05H,00H,00H,00H,04H,00H,00H,00H,00H,85H
        DB 05H,2EH,00H,00H,80H,00H,87H,00H,00H,85H,05H,2EH,00H,87H,01H,05H
        DB 00H,86H,83H,80H,05H,2EH,00H,06H,17H,86H,00H,85H,80H,80H,05H,87H
        DB 06H,17H,17H,17H,86H,85H,80H,80H,05H,2EH,17H,17H,17H,17H,17H,84H
        DB 80H,80H,82H,15H,17H,17H,17H,17H,17H,85H,80H,80H,80H,04H,17H,17H
        DB 2EH,17H,17H,81H,80H,80H,80H,05H,17H,17H,2EH,17H,17H,80H,80H,80H
        DB 80H,05H,17H,17H,2EH,17H,17H,80H,80H,80H,80H,05H,17H,17H,82H,17H
        DB 17H,80H,80H,80H,80H,05H,17H,17H,80H,17H,17H,80H,80H,80H,80H,80H
        DB 17H,87H,80H,17H,87H,80H,80H,80H,03H,03H,01H,02H,03H,00H,03H,03H
        DB 03H,03H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,80H,0B5H,0B7H,0B4H
        DB 0A9H,0BAH,0A8H,0AAH,0A9H,80H,0A7H,0BEH,80H,0AFH,9BH,0B0H,9BH,0ACH,0B7H,0AAH
        DB 0BEH,0AAH,80H,0B8H,0B4H,0ABH,0B9H,0BCH,0A6H,0B7H,0AAH,80H,80H,80H,80H,80H
        DB 80H,80H,0A8H,0B4H,0B5H,0BEH,0B7H,0AEH,0ACH,0ADH,0B9H,80H,80H,0B2H,9BH,0AAH
        DB 9BH,0AAH,0BBH,0A6H,0B3H,0B8H,80H,80H,80H,80H,80H,80H,00H,00H,00H,00H
        DB 00H,00H
T_PIC2:
        DB 80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H
        DB 80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H,80H
        DB 80H,80H,89H,80H,80H,80H,80H,80H,80H,80H,80H,88H,88H,88H,80H,80H
        DB 80H,80H,80H,80H,80H,88H,88H,88H,80H,80H,80H,80H,80H,01H,00H,84H
        DB 8AH,07H,02H,84H,80H,80H,05H,00H,00H,00H,34H,00H,00H,00H,80H,80H
        DB 05H,00H,87H,06H,03H,83H,87H,00H,85H,80H,05H,2EH,05H,00H,00H,00H
        DB 84H,00H,85H,80H,05H,2EH,05H,00H,00H,87H,01H,00H,81H,80H,05H,87H
        DB 06H,83H,87H,01H,87H,81H,80H,80H,05H,2EH,17H,17H,86H,83H,01H,84H
        DB 80H,80H,00H,00H,00H,00H,00H,00H,00H,11H,85H,00H,0EAH
L5519:
        LD DE,(DFILEP)
        INC DE
L551E:
        PUSH BC
        PUSH DE
        LD BC,000AH
        LDIR
        POP DE
        PUSH HL
        LD HL,0021H
        ADD HL,DE
        EX DE,HL
        POP HL
        POP BC
        DJNZ L551E
        RET
U_TITLEPIC:
        LD HL,T_TITLEPIC
        LD B,16H
        CALL L5519
        LD BC,0020H
        LDIR
        INC DE
        LD BC,0020H
        LDIR
        RET
U_PIC2:
        LD HL,T_PIC2
        LD B,0DH
        JR L5519
U_SCROLL:
        LD HL,(DFILEP)
        LD DE,000BH
        ADD HL,DE
        LD B,14H
L5555:
        PUSH BC
        PUSH HL
        POP DE
        LD BC,0021H
        ADD HL,BC
        PUSH HL
        LD BC,0016H
        LDIR
        POP HL
        POP BC
        DJNZ L5555
        EX DE,HL
        LD HL,V_POS
        INC (HL)
        BIT 0,(HL)
        JR NZ,L5574
        LD HL,T_BLANK
        JR L5581
L5574:
        LD BC,(V_TXTPTR)
        LD HL,0016H
        ADD HL,BC
        LD (V_TXTPTR),HL
        PUSH BC
        POP HL
L5581:
        LD BC,0016H
        LDIR
        RET
        DB 83H,40H,0C9H,1BH,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,12H,0AH,06H,0EAH
T_STORY:
        DB 00H,00H,00H,37H,34H,31H,31H,00H,3AH,35H,1AH,37H,34H,31H,31H,00H
        DB 3AH,35H,1AH,00H,00H,00H,00H,38H,2AH,2AH,00H,39H,2DH,2AH,00H,26H
        DB 32H,26H,3FH,2EH,33H,2CH,00H,00H,00H,00H,00H,00H,00H,39H,3EH,37H
        DB 26H,33H,33H,34H,38H,26H,3AH,37H,3AH,38H,00H,37H,2AH,3DH,00H,00H
        DB 00H,00H,00H,30H,2EH,33H,2CH,00H,34H,2BH,00H,39H,2DH,2AH,00H,29H
        DB 2EH,33H,34H,38H,26H,3AH,37H,38H,00H,2EH,33H,00H,2DH,2EH,38H,00H
        DB 31H,26H,2EH,37H,1BH,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,35H
        DB 2AH,37H,2BH,2AH,28H,39H,31H,3EH,00H,35H,37H,2AH,38H,2AH,37H,3BH
        DB 2AH,29H,00H,00H,00H,2EH,33H,00H,38H,2EH,31H,2EH,28H,34H,33H,00H
        DB 38H,2EH,33H,28H,2AH,00H,00H,00H,00H,00H,00H,35H,37H,2AH,2DH,2EH
        DB 38H,39H,34H,37H,2EH,28H,00H,39H,2EH,32H,2AH,38H,1AH,2DH,2AH,00H
        DB 00H,2EH,38H,00H,27H,37H,34H,3AH,2CH,2DH,39H,00H,39H,34H,00H,3EH
        DB 34H,3AH,00H,2BH,34H,37H,00H,3EH,34H,3AH,37H,00H,2AH,33H,39H,2AH
        DB 37H,39H,26H,2EH,33H,32H,2AH,33H,39H,00H,00H,00H,00H,26H,33H,29H
        DB 00H,2AH,3DH,2DH,2EH,31H,26H,37H,26H,39H,2EH,34H,33H,1BH,00H,00H
        DB 00H,00H,00H,00H,00H,2EH,2BH,00H,3EH,34H,3AH,00H,29H,26H,37H,2AH
        DB 00H,39H,34H,00H,00H,00H,00H,00H,00H,2AH,33H,39H,2AH,37H,00H,2DH
        DB 2EH,38H,00H,31H,26H,2EH,37H,1AH,3EH,34H,3AH,00H,29H,34H,00H,38H
        DB 34H,00H,26H,39H,00H,3EH,34H,3AH,37H,00H,34H,3CH,33H,00H,37H,2EH
        DB 38H,30H,1BH,00H,00H,39H,2DH,2AH,00H,32H,26H,33H,26H,2CH,2AH,32H
        DB 2AH,33H,39H,00H,26H,28H,28H,2AH,35H,39H,00H,33H,34H,00H,37H,2AH
        DB 38H,35H,34H,33H,38H,2EH,27H,2EH,31H,2EH,39H,3EH,00H,2BH,34H,37H
        DB 00H,39H,2DH,2AH,00H,2DH,2AH,26H,31H,39H,2DH,00H,26H,33H,29H,00H
        DB 38H,26H,2BH,2AH,39H,3EH,00H,34H,2BH,00H,39H,2DH,2AH,00H,26H,29H
        DB 3BH,2AH,33H,39H,3AH,37H,2AH,37H,00H,3CH,2DH,34H,00H,2AH,33H,39H
        DB 2AH,37H,38H,00H,2DH,2EH,38H,00H,37H,2AH,26H,31H,32H,1BH,39H,2DH
        DB 2AH,00H,00H,32H,26H,33H,26H,2CH,2AH,32H,2AH,33H,39H,00H,26H,29H
        DB 3BH,2EH,38H,2AH,00H,00H,00H,00H,00H,39H,2DH,26H,39H,00H,39H,2DH
        DB 2EH,38H,00H,2EH,38H,00H,33H,34H,39H,00H,26H,00H,00H,00H,00H,2CH
        DB 26H,32H,2AH,00H,2BH,34H,37H,00H,39H,2DH,34H,38H,2AH,00H,34H,2BH
        DB 00H,26H,00H,00H,00H,33H,2AH,37H,3BH,34H,3AH,38H,00H,29H,2EH,38H
        DB 35H,34H,38H,2EH,39H,2EH,34H,33H,1BH,00H,00H,00H,00H,2EH,2BH,00H
        DB 3EH,34H,3AH,00H,26H,37H,2AH,00H,2EH,33H,00H,26H,33H,3EH,00H,00H
        DB 00H,29H,34H,3AH,27H,39H,1AH,39H,2DH,2AH,33H,00H,35H,37H,2AH,38H
        DB 38H,00H,0A6H,00H,00H,00H,00H,2EH,2BH,00H,2EH,33H,38H,39H,37H,3AH
        DB 28H,39H,2EH,34H,33H,38H,00H,26H,37H,2AH,00H,00H,00H,33H,2AH,2AH
        DB 29H,2AH,29H,00H,39H,34H,00H,35H,37H,34H,28H,2AH,2AH,29H,1AH,00H
        DB 00H,00H,00H,39H,2DH,2AH,33H,00H,35H,37H,2AH,38H,38H,00H,0B0H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,34H,39H,2DH,2AH,37H,3CH,2EH
        DB 38H,2AH,00H,35H,37H,2AH,38H,38H,00H,0A8H,00H,00H,00H,00H,00H,00H
        DB 00H,39H,2DH,2AH,00H,34H,33H,31H,3EH,00H,28H,34H,33H,39H,37H,34H
        DB 31H,38H,00H,00H,00H,3EH,34H,3AH,00H,37H,2AH,36H,3AH,2EH,37H,2AH
        DB 00H,26H,37H,2AH,0EH,16H,00H,00H,00H,00H,00H,00H,00H,26H,1BH,1BH
        DB 1BH,1BH,39H,3AH,37H,33H,00H,31H,2AH,2BH,39H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,3CH,1BH,1BH,1BH,1BH,32H,34H,3BH,2AH,00H,2BH,34H,37H
        DB 3CH,26H,37H,29H,00H,00H,00H,00H,00H,29H,1BH,1BH,1BH,1BH,39H,3AH
        DB 37H,33H,00H,37H,2EH,2CH,2DH,39H,00H,00H,00H,00H,00H,2BH,3AH,37H
        DB 39H,2DH,2AH,37H,00H,2EH,33H,2BH,34H,37H,32H,26H,39H,2EH,34H,33H
        DB 00H,00H,00H,2EH,38H,00H,35H,37H,34H,3BH,2EH,29H,2AH,29H,00H,29H
        DB 3AH,37H,2EH,33H,2CH,00H,00H,00H,00H,39H,2DH,2AH,00H,2AH,33H,28H
        DB 34H,3AH,33H,39H,2AH,37H,1BH,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,2BH,34H,37H,00H,2AH,26H,28H,2DH,00H,32H,34H,3BH,2AH,00H,00H
        DB 00H,00H,00H,00H,00H,38H,28H,34H,37H,2EH,33H,2CH,00H,2EH,38H,00H
        DB 26H,38H,00H,2BH,34H,31H,31H,34H,3CH,38H,00H,00H,00H,21H,00H,35H
        DB 39H,38H,16H,3CH,2DH,2EH,31H,2AH,00H,2DH,2AH,00H,2EH,38H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,39H,37H,26H,28H,30H,2EH,33H
        DB 2CH,00H,3EH,34H,3AH,1BH,00H,1EH,1CH,1CH,00H,35H,39H,38H,16H,2EH
        DB 2BH,00H,3EH,34H,3AH,00H,2AH,38H,28H,26H,35H,2AH,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,2DH,2EH,38H,00H,31H,26H,2EH,37H,1BH,00H,00H
        DB 00H,00H,00H,00H,00H,38H,2EH,33H,28H,2AH,00H,37H,2AH,3DH,00H,2EH
        DB 38H,00H,26H,31H,3CH,26H,3EH,38H,00H,39H,37H,3EH,2EH,33H,2CH,00H
        DB 39H,34H,00H,32H,34H,3BH,2AH,00H,00H,00H,00H,00H,00H,00H,00H,39H
        DB 34H,3CH,26H,37H,29H,38H,00H,2DH,2EH,38H,00H,35H,37H,2AH,3EH,1AH
        DB 26H,00H,00H,00H,00H,38H,30H,2EH,31H,2BH,3AH,31H,00H,26H,29H,3BH
        DB 2AH,33H,39H,3AH,37H,2AH,37H,00H,00H,00H,00H,28H,26H,33H,00H,28H
        DB 34H,33H,39H,37H,34H,31H,00H,39H,2DH,2AH,00H,00H,00H,00H,00H,00H
        DB 00H,32H,34H,33H,38H,39H,2AH,37H,38H,00H,32H,34H,3BH,2AH,32H,2AH
        DB 33H,39H,38H,00H,39H,34H,00H,2EH,32H,35H,37H,34H,3BH,2AH,00H,2DH
        DB 2EH,38H,00H,38H,28H,34H,37H,2AH,1BH,00H,00H,00H,00H,39H,2DH,2AH
        DB 00H,2AH,38H,28H,26H,35H,2AH,00H,37H,34H,3AH,39H,2AH,1AH,00H,00H
        DB 00H,00H,00H,3CH,2DH,2EH,28H,2DH,00H,2EH,38H,00H,26H,39H,00H,39H
        DB 2DH,2AH,00H,2AH,33H,29H,00H,00H,00H,34H,2BH,00H,26H,00H,28H,3AH
        DB 31H,16H,29H,2AH,16H,38H,26H,28H,1AH,2EH,38H,00H,00H,00H,00H,3BH
        DB 2EH,38H,2EH,27H,31H,2AH,00H,3AH,35H,00H,39H,34H,00H,21H,00H,32H
        DB 34H,3BH,2AH,38H,00H,26H,3CH,26H,3EH,1BH,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,39H,2DH,2AH
        DB 00H,2CH,26H,32H,2AH,00H,2AH,33H,29H,38H,00H,3CH,2DH,2AH,33H,00H
        DB 00H,2DH,2AH,00H,28H,26H,39H,28H,2DH,2AH,38H,00H,3EH,34H,3AH,1BH
        DB 2EH,2BH,00H,3EH,34H,3AH,00H,2AH,38H,28H,26H,35H,2AH,00H,26H,00H
        DB 33H,2AH,3CH,00H,32H,26H,3FH,2AH,00H,2EH,38H,00H,00H,2CH,2AH,33H
        DB 2AH,37H,26H,39H,2AH,29H,00H,26H,33H,29H,00H,3EH,34H,3AH,37H,00H
        DB 00H,00H,00H,35H,37H,2AH,3BH,2EH,34H,3AH,38H,00H,38H,28H,34H,37H
        DB 2AH,00H,00H,00H,00H,00H,00H,00H,00H,28H,26H,37H,37H,2EH,2AH,29H
        DB 00H,2BH,34H,37H,3CH,26H,37H,29H,1BH,00H,00H,00H,00H,00H,00H,00H
        DB 00H,39H,2DH,2AH,00H,32H,2EH,38H,39H,38H,00H,34H,2BH,00H,39H,2EH
        DB 32H,2AH,00H,00H,00H,3CH,2EH,31H,31H,00H,35H,26H,38H,38H,00H,34H
        DB 3BH,2AH,37H,00H,3EH,34H,3AH,00H,00H,00H,00H,2BH,34H,37H,00H,26H
        DB 27H,34H,3AH,39H,00H,1FH,1CH,00H,38H,2AH,28H,34H,33H,29H,38H,00H
        DB 00H,3CH,2DH,2EH,31H,2AH,00H,39H,37H,26H,33H,38H,35H,34H,37H,39H
        DB 2EH,33H,2CH,00H,00H,00H,00H,3EH,34H,3AH,00H,39H,34H,00H,39H,2DH
        DB 2AH,00H,31H,26H,2EH,37H,00H,34H,2BH,00H,00H,00H,00H,39H,3EH,37H
        DB 26H,33H,33H,34H,38H,26H,3AH,37H,3AH,38H,00H,37H,2AH,3DH,1BH,00H
        DB 00H,00H,00H,00H,00H,27H,2AH,38H,39H,00H,34H,2BH,00H,31H,3AH,28H
        DB 30H,1BH,1BH,1BH,1BH,1BH,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,76H

        ORG 0AC00H
TAB_ON_TE:
        DB 00H,02H,01H,03H,00H,02H,01H,03H,02H,00H,02H,01H,03H,02H,00H,02H
        DB 00H,03H,01H,03H,01H,00H,02H,00H,02H,01H,03H,01H,03H,02H,00H,02H
        DB 00H,03H,01H,03H,01H,00H,02H,00H,02H,01H,03H,01H,03H,02H,00H,02H
        DB 00H,03H,01H,03H,01H,00H,02H,00H,02H,01H,03H,01H,03H,02H,00H,02H
        DB 00H,03H,01H,03H,01H,00H,02H,00H,02H,01H,03H,01H,03H,02H,00H,02H
        DB 00H,03H,01H,03H,01H,00H,02H,00H,02H,01H,03H,01H,03H,02H,00H,02H
        DB 00H,03H,01H,03H,01H,00H,02H,00H,02H,01H,03H,01H,03H,02H,00H,02H
        DB 00H,03H,01H,03H,01H,00H,02H,00H,02H,01H,03H,01H,03H,02H,00H,02H
        DB 03H,01H,02H,00H,03H,01H,02H,00H,02H,03H,02H,02H,00H,01H,03H,01H
        DB 03H,00H,02H,00H,02H,03H,01H,03H,01H,02H,00H,02H,00H,01H,03H,01H
        DB 03H,00H,02H,00H,02H,03H,01H,03H,01H,02H,00H,02H,00H,01H,03H,01H
        DB 03H,00H,02H,00H,02H,03H,01H,03H,01H,02H,00H,02H,00H,01H,03H,01H
        DB 03H,00H,02H,00H,02H,03H,01H,03H,01H,02H,00H,02H,00H,01H,03H,01H
        DB 03H,00H,02H,00H,02H,03H,01H,03H,01H,02H,00H,02H,00H,01H,03H,01H
        DB 03H,00H,02H,00H,02H,03H,01H,03H,01H,02H,00H,02H,00H,01H,03H,01H
        DB 03H,00H,02H,00H,02H,03H,01H,03H,01H,02H,00H,02H,00H,01H,03H,01H
TAB_ON_TO:
        DB 00H,02H,01H,03H,00H,02H,01H,03H,01H,00H,01H,01H,03H,02H,00H,02H
        DB 00H,03H,01H,03H,01H,00H,02H,00H,02H,01H,03H,01H,03H,02H,00H,02H
        DB 00H,03H,01H,03H,01H,00H,02H,00H,02H,01H,03H,01H,03H,02H,00H,02H
        DB 00H,03H,01H,03H,01H,00H,02H,00H,02H,01H,03H,01H,03H,02H,00H,02H
        DB 00H,03H,01H,03H,01H,00H,02H,00H,02H,01H,03H,01H,03H,02H,00H,02H
        DB 00H,03H,01H,03H,01H,00H,02H,00H,02H,01H,03H,01H,03H,02H,00H,02H
        DB 00H,03H,01H,03H,01H,00H,02H,00H,02H,01H,03H,01H,03H,02H,00H,02H
        DB 00H,03H,01H,03H,01H,00H,02H,00H,02H,01H,03H,01H,03H,02H,00H,02H
        DB 03H,01H,02H,00H,03H,01H,02H,00H,01H,03H,01H,02H,00H,01H,03H,01H
        DB 03H,00H,02H,00H,02H,03H,01H,03H,01H,02H,00H,02H,00H,01H,03H,01H
        DB 03H,00H,02H,00H,02H,03H,01H,03H,01H,02H,00H,02H,00H,01H,03H,01H
        DB 03H,00H,02H,00H,02H,03H,01H,03H,01H,02H,00H,02H,00H,01H,03H,01H
        DB 03H,00H,02H,00H,02H,03H,01H,03H,01H,02H,00H,02H,00H,01H,03H,01H
        DB 03H,00H,02H,00H,02H,03H,01H,03H,01H,02H,00H,02H,00H,01H,03H,01H
        DB 03H,00H,02H,00H,02H,03H,01H,03H,01H,02H,00H,02H,00H,01H,03H,01H
        DB 03H,00H,02H,00H,02H,03H,01H,03H,01H,02H,00H,02H,00H,01H,03H,01H
TAB_ON_BE:
        DB 00H,00H,00H,00H,02H,02H,02H,02H,02H,02H,00H,03H,03H,00H,01H,01H
        DB 02H,02H,03H,03H,00H,01H,01H,02H,02H,03H,03H,00H,00H,01H,02H,02H
        DB 03H,03H,00H,00H,01H,02H,02H,03H,03H,00H,00H,01H,01H,02H,03H,03H
        DB 00H,00H,01H,01H,02H,03H,03H,00H,00H,01H,01H,02H,02H,03H,00H,00H
        DB 01H,01H,02H,02H,03H,00H,00H,01H,01H,02H,02H,03H,03H,00H,01H,01H
        DB 02H,02H,03H,03H,00H,01H,01H,02H,02H,03H,03H,00H,00H,01H,02H,02H
        DB 03H,03H,00H,00H,01H,02H,02H,03H,03H,00H,00H,01H,01H,02H,03H,03H
        DB 00H,00H,01H,01H,02H,03H,03H,00H,00H,01H,01H,02H,02H,03H,00H,00H
        DB 03H,03H,03H,03H,01H,01H,01H,01H,02H,02H,03H,00H,00H,03H,02H,02H
        DB 01H,01H,00H,00H,03H,02H,02H,01H,01H,00H,00H,03H,03H,02H,01H,01H
        DB 00H,00H,03H,03H,02H,01H,01H,00H,00H,03H,03H,02H,02H,01H,00H,00H
        DB 03H,03H,02H,02H,01H,00H,00H,03H,03H,02H,02H,01H,01H,00H,03H,03H
        DB 02H,02H,01H,01H,00H,03H,03H,02H,02H,01H,01H,00H,00H,03H,02H,02H
        DB 01H,01H,00H,00H,03H,02H,02H,01H,01H,00H,00H,03H,03H,02H,01H,01H
        DB 00H,00H,03H,03H,02H,01H,01H,00H,00H,03H,03H,02H,02H,01H,00H,00H
        DB 03H,03H,02H,02H,01H,00H,00H,03H,03H,02H,02H,01H,01H,00H,03H,03H
TAB_ON_BO:
        DB 00H,00H,00H,00H,02H,02H,02H,02H,01H,01H,00H,03H,03H,00H,01H,01H
        DB 02H,02H,03H,03H,00H,01H,01H,02H,02H,03H,03H,00H,00H,01H,02H,02H
        DB 03H,03H,00H,00H,01H,02H,02H,03H,03H,00H,00H,01H,01H,02H,03H,03H
        DB 00H,00H,01H,01H,02H,03H,03H,00H,00H,01H,01H,02H,02H,03H,00H,00H
        DB 01H,01H,02H,02H,03H,00H,00H,01H,01H,02H,02H,03H,03H,00H,01H,01H
        DB 02H,02H,03H,03H,00H,01H,01H,02H,02H,03H,03H,00H,00H,01H,02H,02H
        DB 03H,03H,00H,00H,01H,02H,02H,03H,03H,00H,00H,01H,01H,02H,03H,03H
        DB 00H,00H,01H,01H,02H,03H,03H,00H,00H,01H,01H,02H,02H,03H,00H,00H
        DB 03H,03H,03H,03H,01H,01H,01H,01H,01H,01H,03H,00H,00H,03H,02H,02H
        DB 01H,01H,00H,00H,03H,02H,02H,01H,01H,00H,00H,03H,03H,02H,01H,01H
        DB 00H,00H,03H,03H,02H,01H,01H,00H,00H,03H,03H,02H,02H,01H,00H,00H
        DB 03H,03H,02H,02H,01H,00H,00H,03H,03H,02H,02H,01H,01H,00H,03H,03H
        DB 02H,02H,01H,01H,00H,03H,03H,02H,02H,01H,01H,00H,00H,03H,02H,02H
        DB 01H,01H,00H,00H,03H,02H,02H,01H,01H,00H,00H,03H,03H,02H,01H,01H
        DB 00H,00H,03H,03H,02H,01H,01H,00H,00H,03H,03H,02H,02H,01H,00H,00H
        DB 03H,03H,02H,02H,01H,00H,00H,03H,03H,02H,02H,01H,01H,00H,03H,03H
TAB_PIC_TE:
        DB 00H,02H,01H,03H,00H,02H,01H,03H,02H,00H,02H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,02H,02H,02H,02H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,02H,00H
        DB 00H,00H,00H,00H,02H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 03H,01H,02H,00H,03H,01H,02H,00H,02H,03H,02H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,02H,02H,02H,02H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,02H,00H
        DB 00H,00H,00H,00H,02H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
TAB_PIC_TO:
        DB 00H,02H,01H,03H,00H,02H,01H,03H,01H,00H,01H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,01H,01H,01H,01H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,01H,00H
        DB 00H,00H,00H,00H,01H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 03H,01H,02H,00H,03H,01H,02H,00H,01H,03H,01H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,01H,01H,01H,01H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,01H,00H
        DB 00H,00H,00H,00H,01H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
TAB_PIC_BE:
        DB 00H,00H,00H,00H,02H,02H,02H,02H,02H,02H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,02H,02H,02H,02H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,02H,00H
        DB 00H,00H,00H,00H,02H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 03H,03H,03H,03H,01H,01H,01H,01H,02H,02H,03H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,02H,02H,02H,02H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,02H,00H
        DB 00H,00H,00H,00H,02H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
TAB_PIC_BO:
        DB 00H,00H,00H,00H,02H,02H,02H,02H,01H,01H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,01H,01H,01H,01H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,01H,00H
        DB 00H,00H,00H,00H,01H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 03H,03H,03H,03H,01H,01H,01H,01H,01H,01H,03H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,01H,01H,01H,01H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,01H,00H
        DB 00H,00H,00H,00H,01H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
TAB_OFF_TE:
        DB 00H,02H,01H,03H,00H,02H,01H,03H,02H,00H,02H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 03H,01H,02H,00H,03H,01H,02H,00H,02H,03H,02H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
TAB_OFF_TO:
        DB 00H,02H,01H,03H,00H,02H,01H,03H,01H,00H,01H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 03H,01H,02H,00H,03H,01H,02H,00H,01H,03H,01H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
TAB_OFF_BE:
        DB 00H,00H,00H,00H,02H,02H,02H,02H,02H,02H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 03H,03H,03H,03H,01H,01H,01H,01H,02H,02H,03H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
TAB_OFF_BO:
        DB 00H,00H,00H,00H,02H,02H,02H,02H,01H,01H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 03H,03H,03H,03H,01H,01H,01H,01H,01H,01H,03H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        ORG 0B800H
ZX2VZ:
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,62H,63H,64H,7AH,7FH
        DB 68H,69H,7EH,7CH,7DH,6BH,6DH,6AH,6FH,7BH,6CH,6EH,70H,71H,72H,73H
        DB 74H,75H,76H,77H,78H,79H,41H,42H,43H,44H,45H,46H,47H,48H,49H,4AH
        DB 4BH,4CH,4DH,4EH,4FH,50H,51H,52H,53H,54H,55H,56H,57H,58H,59H,5AH
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,22H,23H,24H,3AH,3FH
        DB 28H,29H,3EH,3CH,3DH,2BH,2DH,2AH,2FH,3BH,2CH,2EH,30H,31H,32H,33H
        DB 34H,35H,36H,37H,38H,39H,01H,02H,03H,04H,05H,06H,07H,08H,09H,0AH
        DB 0BH,0CH,0DH,0EH,0FH,10H,11H,12H,13H,14H,15H,16H,17H,18H,19H,1AH
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
        DB 00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H,00H
