HELLO

Si vous lisez ca cela veux dire que vous avez vu une de mes demos, je vous en remercie, et j'espere que vous l'avez appreci�.

Mais sur mon site il y en a encore plein d'autre donc je vous conseille d'y aller tout de suite:
http:\\democoding.fr.st

Et si vous vous voulez m'ecrire pour des avis ou des demandes de conseil voici mon mail:
josh83@wanadoo.fr

Josh83

