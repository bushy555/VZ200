#include <vz.h>
#include <graphics.h>
#include <stdio.h>
#include <sound.h>
#include <stdlib.h>
#include <ctype.h>
#include <strings.h>
#include <conio.h>
#include <math.h>
int p;
int n4;
int n3;
int n2;
int n1;
float c;
int k,x,y;
int xsize,ysize;
int buffer1[128*64];
int buffer2[128*64];

main(){
	memset(buffer1[x],0,2048);
	memset(buffer2[x],0,2048);
	memset(buffer1[1984], 221, 64);
	memset(buffer2[1984], 221, 64);
	memset(0x77c0, 221, 64);

	xsize = 32;
	ysize = 64;
	k=1;
	vz_setbase(0x7000);
	vz_mode(1);

	while(k==1)	{
     for (y=1;y<(ysize-2);y++){
        for (x=1;x<(xsize-2);x++){

         n1 = buffer1[(x+1)+(y*64)];
         n2 = buffer1[(x-1)+(y*64)];
         n3 = buffer1[x+((y+1)*64)];
         n4 = buffer1[x+((y-1)*64)];
         p = ((n1+n2+n3+n4)  );              	//The average of the 4 neighbours
         if (p<0) {p=1;}                      	//Don't let the fire cool below zero
}
}
}
}

