#include <vz.h>
#include <graphics.h>
#include <stdio.h>
#include <sound.h>
#include <stdlib.h>
#include <ctype.h>
#include <strings.h>
#include <conio.h>
#include <math.h>
int p;
int n4;
int n3;
int n2;
int n1;
float c;
int k,x,y;
int xsize,ysize;
int buffer1[128*64];
int buffer2[128*64];
//int coolingmap[128*64];

main(){
	memset(buffer1[x],0,2048);
	memset(buffer2[x],0,2048);
	memset(buffer1[1984], 221, 64);
	memset(buffer2[1984], 221, 64);
	memset(0x77c0, 221, 64);

	xsize = 32;
	ysize = 64;
	k=1;
	vz_setbase(0x7000);
	vz_mode(1);

	while(k==1)	{
     for (y=1;y<(ysize-2);y++){
        for (x=1;x<(xsize-2);x++){

         n1 = buffer1[(x+1)+(y*64)];
         n2 = buffer1[(x-1)+(y*64)];
         n3 = buffer1[x+((y+1)*64)];
         n4 = buffer1[x+((y-1)*64)];

   //      c = coolingmap[x+(y*64)];			//Read a pixel from the cooling map

         p = ((n1+n2+n3+n4)  );              	//The average of the 4 neighbours
//	p = p-c;                               //minus c
	

         if (p<0) {p=1;}                      	//Don't let the fire cool below zero
//         if (p>4) {p=4;} 
 
//         buffer2(x,y-1) = p;                    //write this pixel to the other buffer
//         buffer2((y-1)*64+x) = p;                    //write this pixel to the other buffer
//         buffer2[(y-1)*64+x]=p;

//	bpoke(buffer2[(y-1)*(64+x)], 85);
//	memcpy(buffer2[(y-1)*64+x],p,1);
                  //notice that it is one pixel higher.

//   memcpy (buffer2, 0x7000, 2048);             	//Display the next frame
//   memcpy (buffer1, buffer2, 2048);		//Update buffer1
}
}
}
}



/*

----
INTEGER: xsize
INTEGER: ysize
INTEGER: c
INTEGER: n1
INTEGER: n2
INTEGER: n3
INTEGER: n4
INTEGER: p
ARRAY_OF_BYTES: buffer1(xsize*ysize)
ARRAY_OF_BYTES: buffer2(xsize*ysize)
ARRAY_OF_BYTES: CoolingMap(xsize*ysize)
loop forever

  loop y  from 1 to (ysize-2)                   ;Loop through all pixels on the screen, except
    loop x  from 1 to (xsize-2)                 ;the ones at the very edge.

      n1 = read pixel from buffer1(x+1, y)      ;Read the 4 neighbouring pixels
      n2 = read pixel from buffer1(x-1, y)
      n3 = read pixel from buffer1(x, y+1)
      n4 = read pixel from buffer1(x, y-1)

      c  = read pixel from CoolingMap(x, y)     ;Read a pixel from the cooling map

      p = ((n1+n2+n3+n4) / 4)                   ;The average of the 4 neighbours
      p = p-c                                   ;minus c

      if p<0 then p=0                           ;Dont let the fire cool below zero


      write pixel of value p to buffer2(x,y-1)  ;write this pixel to the other buffer
                                                ;notice that it is one pixel higher.

    end x loop
  end yloop

  copy buffer2 to the screen                    ;Display the next frame
  copy buffer2 to buffer1                       ;Update buffer1
  scroll CoolingMap up one pixel

end of loop

*/
