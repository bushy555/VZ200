
#include <graphics.h>
#include <stdio.h>
#include <math.h>
#include <vz.h>

main()
{
float x,y;
char z,buf;
	//clg();
	vz_setbase(0x7000);
	vz_mode(1);

	for (x=-3.0; x<3.0; x=x+0.06)
	{
		buf=100;
		for (y=-3.0; y<3.0; y=y+0.2)
		{
			z = (char) 60.0 - (10.0 * (y + 3.0) + ( 10.0 * sin (x*x + y*y) ));
			if (buf>z)
			{
				buf = z;
//				plot ( (char) (15.0 * (x+3.0)), (char) z);
				vz_plot ( (char) (15.0 * (x+3.0)), (char) z, 3);
			}
		}
	}
	
	while (getk() != 13) {};
}

