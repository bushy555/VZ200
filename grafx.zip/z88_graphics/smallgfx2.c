
#include <graphics.h>
#include <stdio.h>
#include <math.h>

main(){

	int x,a,k;
	k=1;	
	vz_setbase(0x7000);
	vz_mode(1);

	for (x=1;x<95;x++)	{
		a=50-x;
		plot (x,32-(a*a/80));
	}
	
				/* Draw a diamond - weak, but it demonstrates relative drawing! */
        
        plot(61,25);
	        drawr(15,15);
	        drawr(15,-15);
	        drawr(-15,-15);
	        drawr(-15,15);

        circle(30,30,20,1);
	circle(30,30,28,1);

	fill(8,35);	
	fill(70,30);
	
	for (x=1;x<25000;x++)	{;}
	for (x=1;x<25000;x++)	{;}



	while (k==1){
		for (x=30;x<100;x++){
        		circle(x,20,10,2);
        		circle(x,30,15,3);
		}
		circle( rand(50)+50,rand(20),rand(20),rand(3)+1);
	}
}


