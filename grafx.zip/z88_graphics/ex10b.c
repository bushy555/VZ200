//
//
// compile with _com2
//
//
#include <graphics.h>
#include <zx81.h>
#include <vz.h>

	unsigned char stencil[192*2];

main() {
	int c, l;
	unsigned char i;
	unsigned int dly;

	vz_setbase(0xe000);
	vz_mode(1);
//	invhrg();
//	zx_border(0);
//	zx_colour(PAPER_BLACK|INK_WHITE);

	c = 0;

	// paint polygon
	for (;;) {
		
//	vz_mode(1);
	vz_setbase(0xe000);


	

		for (i=4;i>0;i--) {
			stencil_init(stencil);
			stencil_add_circle(80+c*3-i, 42+i, i*3+5, 1, stencil);
			stencil_render(stencil, 14-(i*2));
		}



	vz_setbase(0x7000);
	memcpy (0x7000, 0xe000, 2048);


//		for (dly=0;dly<3000;dly++) {};

		c = (c+1) & 15;
	}
}
