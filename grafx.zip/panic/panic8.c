 #include <vz.h>
 #include <graphics.h>
 #include <stdio.h>
 #include <sound.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <strings.h>
 #include <conio.h>

int witch()
int	i,j;	

{
	memset (28672, 170, 2048);
	for (j=0;j<32;j++){
		i=j+28672;



bpoke(i+0x004,191);





bpoke(i+0x024,191);bpoke(i+0x025,234);




bpoke(i+0x044,175);bpoke(i+0x045,250);




bpoke(i+0x064,171);bpoke(i+0x065,254);





bpoke(i+0x085,255);bpoke(i+0x086,234);bpoke(i+0x087,186);




bpoke(i+0x0A5,255);bpoke(i+0x0A6,251);bpoke(i+0x0A7,234);




bpoke(i+0x0C5,255);
bpoke(i+0x0C6,255);bpoke(i+0x0C7,234);




bpoke(i+0x0E5,191);bpoke(i+0x0E6,255);




bpoke(i+0x105,255);bpoke(i+0x106,255);bpoke(i+0x107,250);




bpoke(i+0x124,175);bpoke(i+0x125,255);
bpoke(i+0x126,175);bpoke(i+0x127,250);



bpoke(i+0x140,186);bpoke(i+0x143,175);
bpoke(i+0x144,255);bpoke(i+0x145,254);bpoke(i+0x146,171);bpoke(i+0x147,234);



bpoke(i+0x160,186);
bpoke(i+0x163,191);bpoke(i+0x164,254);bpoke(i+0x165,175);bpoke(i+0x166,191);bpoke(i+0x167,234);




bpoke(i+0x180,191);bpoke(i+0x181,234);bpoke(i+0x183,255);bpoke(i+0x184,255);bpoke(i+0x185,239);
bpoke(i+0x186,190);



bpoke(i+0x1A0,175);bpoke(i+0x1A1,239);bpoke(i+0x1A2,251);bpoke(i+0x1A3,255);
bpoke(i+0x1A4,255);bpoke(i+0x1A5,255);bpoke(i+0x1A6,250);bpoke(i+0x1A9,175);



bpoke(i+0x1C0,171);bpoke(i+0x1C1,255);
bpoke(i+0x1C2,251);bpoke(i+0x1C3,255);bpoke(i+0x1C4,255);bpoke(i+0x1C5,255);bpoke(i+0x1C6,250);
bpoke(i+0x1C9,254);



bpoke(i+0x1E0,171);bpoke(i+0x1E1,255);bpoke(i+0x1E2,255);bpoke(i+0x1E3,255);bpoke(i+0x1E4,255);bpoke(i+0x1E5,255);
bpoke(i+0x1E6,254);bpoke(i+0x1E8,175);bpoke(i+0x1E9,250);



bpoke(i+0x200,171);bpoke(i+0x201,255);bpoke(i+0x202,255);bpoke(i+0x203,254);
bpoke(i+0x204,191);bpoke(i+0x205,255);bpoke(i+0x206,255);bpoke(i+0x207,255);bpoke(i+0x208,255);bpoke(i+0x209,234);



bpoke(i+0x221,191);
bpoke(i+0x222,255);bpoke(i+0x223,250);bpoke(i+0x224,175);bpoke(i+0x225,255);bpoke(i+0x226,255);bpoke(i+0x227,255);
bpoke(i+0x228,255);



bpoke(i+0x242,255);bpoke(i+0x243,250);bpoke(i+0x244,191);bpoke(i+0x245,255);
bpoke(i+0x246,255);bpoke(i+0x247,255);bpoke(i+0x248,250);



bpoke(i+0x262,191);
bpoke(i+0x264,255);bpoke(i+0x265,254);bpoke(i+0x266,191);bpoke(i+0x267,255);bpoke(i+0x268,234);




bpoke(i+0x283,171);bpoke(i+0x284,255);bpoke(i+0x285,254);bpoke(i+0x287,190);




bpoke(i+0x2A3,171);bpoke(i+0x2A4,255);bpoke(i+0x2A5,250);
bpoke(i+0x2A7,250);



bpoke(i+0x2C3,171);
bpoke(i+0x2C4,255);bpoke(i+0x2C5,255);bpoke(i+0x2C6,255);bpoke(i+0x2C7,255);




bpoke(i+0x2E3,171);bpoke(i+0x2E4,255);bpoke(i+0x2E5,255);bpoke(i+0x2E6,255);bpoke(i+0x2E7,255);
bpoke(i+0x2E8,250);



bpoke(i+0x303,171);bpoke(i+0x304,255);bpoke(i+0x305,255);
bpoke(i+0x306,255);bpoke(i+0x307,255);bpoke(i+0x308,250);



bpoke(i+0x323,171);
bpoke(i+0x324,255);bpoke(i+0x325,255);bpoke(i+0x326,255);bpoke(i+0x327,255);bpoke(i+0x328,250);




bpoke(i+0x343,171);bpoke(i+0x344,255);bpoke(i+0x345,255);bpoke(i+0x346,255);bpoke(i+0x347,255);
bpoke(i+0x348,250);



bpoke(i+0x363,171);bpoke(i+0x364,255);bpoke(i+0x365,254);
bpoke(i+0x366,191);bpoke(i+0x367,255);bpoke(i+0x368,234);



bpoke(i+0x383,171);
bpoke(i+0x384,255);bpoke(i+0x385,254);bpoke(i+0x386,255);bpoke(i+0x387,255);bpoke(i+0x388,234);




bpoke(i+0x3A4,255);bpoke(i+0x3A5,239);bpoke(i+0x3A6,255);bpoke(i+0x3A7,255);




bpoke(i+0x3C4,254);bpoke(i+0x3C5,191);
bpoke(i+0x3C6,255);bpoke(i+0x3C7,254);



bpoke(i+0x3E3,175);
bpoke(i+0x3E4,250);bpoke(i+0x3E5,255);bpoke(i+0x3E6,255);bpoke(i+0x3E7,250);




bpoke(i+0x402,171);bpoke(i+0x403,255);bpoke(i+0x405,255);bpoke(i+0x406,255);bpoke(i+0x407,250);




bpoke(i+0x422,175);bpoke(i+0x423,254);bpoke(i+0x425,175);
bpoke(i+0x426,255);bpoke(i+0x427,250);



bpoke(i+0x442,174);bpoke(i+0x443,250);
bpoke(i+0x445,171);bpoke(i+0x446,255);bpoke(i+0x447,250);



bpoke(i+0x461,191);
bpoke(i+0x462,255);bpoke(i+0x463,250);bpoke(i+0x466,191);bpoke(i+0x467,238);




bpoke(i+0x480,171);bpoke(i+0x481,255);bpoke(i+0x482,255);bpoke(i+0x483,254);bpoke(i+0x485,234);
bpoke(i+0x486,255);bpoke(i+0x487,234);



bpoke(i+0x4A0,191);bpoke(i+0x4A1,250);bpoke(i+0x4A2,190);
bpoke(i+0x4A4,171);bpoke(i+0x4A5,250);bpoke(i+0x4A6,255);bpoke(i+0x4A7,234);



bpoke(i+0x4C0,255);bpoke(i+0x4C1,254);
bpoke(i+0x4C2,186);bpoke(i+0x4C4,175);bpoke(i+0x4C5,255);bpoke(i+0x4C6,255);bpoke(i+0x4C7,234);




bpoke(i+0x4E0,191);bpoke(i+0x4E1,251);bpoke(i+0x4E2,250);bpoke(i+0x4E3,250);bpoke(i+0x4E4,175);bpoke(i+0x4E5,255);
bpoke(i+0x4E6,255);



bpoke(i+0x500,255);bpoke(i+0x501,255);bpoke(i+0x502,235);bpoke(i+0x503,255);
bpoke(i+0x504,255);bpoke(i+0x505,255);bpoke(i+0x506,254);



bpoke(i+0x520,190);bpoke(i+0x521,255);
bpoke(i+0x522,171);bpoke(i+0x523,255);bpoke(i+0x524,254);bpoke(i+0x525,175);bpoke(i+0x526,250);




bpoke(i+0x540,235);bpoke(i+0x541,239);bpoke(i+0x542,191);bpoke(i+0x543,255);bpoke(i+0x544,254);bpoke(i+0x545,171);
bpoke(i+0x546,234);bpoke(i+0x560,171);bpoke(i+0x561,171);bpoke(i+0x562,190);bpoke(i+0x563,191);
bpoke(i+0x564,254);bpoke(i+0x581,175);bpoke(i+0x582,250);bpoke(i+0x584,234);
}



int main()
{
	int a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,x,y,z;
	int dir, dira, dirb;
    	vz_mode(1);
	i=0;
        z=0;
	dir = 1;
	dira = 1;
	dirb = 1;
	x = 64;
	y = 64;
	i = 64;
	j = 64;
	k = 2;
	a=1;
	b=1;
	c=3;
	d=3;
	e=16;
	f=32;
	g=8;
	h=32;
	vz_setbase( 0xE000 );
	asm("di\n");
	witch();

	memset (0xE000, 170, 2048);
	while (z==0)
	{
	memset (0xE000, 170, 2048);
	
	if (dir == 1) {k++;}
	if ((dir == 1) && (k == 25)) {dir = 0;}
	if (dir == 0) {k--;}
	if ((dir == 0) && (k == 4))  {dir = 1;}

	if ((dira ==1) && (a< 25)) {a++ ;  b=0; dira=1;}
	if ((dira ==1) && (a== 25)){a=25;  b++; dira=2;}
	if ((dira ==2) && (b< 44)) {a=25;  b++; dira=2;}
	if ((dira ==2) && (b== 44)){a-- ; b=44; dira=3;}
	if ((dira ==3) && (a> 0))  {a-- ; b=44; dira=3;}
	if ((dira ==3) && (a== 0)) {a=0 ;  b--; dira=4;}
	if ((dira ==4) && (b> 0))  {a=0 ;  b--; dira=4;}
	if ((dira ==4) && (b== 0)) {a++ ;  b=0; dira=1;}

	if ((dirb ==1) && (c<25)) {c++; d++; dirb=1;}
	if ((dirb ==1) && (c==25)) {dirb=2;}
	if ((dirb ==2) && (c>2)) {c--; d--; dirb=2;}
	if ((dirb ==2) && (c==2)) {dirb=1;}


	if (rand(255)/128 < 60) {e++;}
	if (rand(255)/128 < 60) {f--;}
	if (rand(255)/128 < 60) {e--;}
	if (rand(255)/128 < 60) {f++;}
	if (e <3)   {e=3;}
	if (e > 24) {e=24;}
	if (f <2)   {f=2;}
	if (f > 48) {f=48;}


	if (rand(255)/128 < 60) {g++;}
	if (rand(255)/128 < 60) {h--;}
	if (rand(255)/128 < 60) {g--;}
	if (rand(255)/128 < 60) {h++;}
	if (g <3)   {g=3;}
	if (g > 24) {g=24;}
	if (h <2)   {h=2;}
	if (h > 48) {h=48;}


		{
		// STAR A
		i = a+(b*32) + 0xE000;
bpoke(i+0x023,138);bpoke(i+0x043,2);bpoke(i+0x062,168);bpoke(i+0x063,0);bpoke(i+0x082,160);bpoke(i+0x083,0);
bpoke(i+0x084,42);bpoke(i+0x0A2,128);bpoke(i+0x0A3,0);bpoke(i+0x0A4,10);bpoke(i+0x0C2,0);bpoke(i+0x0C3,0);bpoke(i+0x0C4,2);
bpoke(i+0x0E0,0);bpoke(i+0x0E1,0);bpoke(i+0x0E2,0);bpoke(i+0x0E3,0);bpoke(i+0x0E4,0);bpoke(i+0x0E5,0);bpoke(i+0x0E6,2);
bpoke(i+0x100,128);bpoke(i+0x101,0);bpoke(i+0x102,0);bpoke(i+0x103,0);bpoke(i+0x104,0);bpoke(i+0x105,0);bpoke(i+0x106,10);
bpoke(i+0x120,160);bpoke(i+0x121,0);bpoke(i+0x122,0);bpoke(i+0x123,0);bpoke(i+0x124,0);bpoke(i+0x125,0);
bpoke(i+0x126,42);bpoke(i+0x141,0);bpoke(i+0x142,0);bpoke(i+0x143,0);bpoke(i+0x144,0);bpoke(i+0x145,2);bpoke(i+0x161,160);
bpoke(i+0x162,0);bpoke(i+0x163,0);bpoke(i+0x164,0);bpoke(i+0x165,42);bpoke(i+0x181,168);bpoke(i+0x182,0);bpoke(i+0x183,0);bpoke(i+0x184,0);
bpoke(i+0x1A1,160);bpoke(i+0x1A2,0);bpoke(i+0x1A3,0);bpoke(i+0x1A4,0);bpoke(i+0x1A5,42);bpoke(i+0x1C1,128);
bpoke(i+0x1C2,0);bpoke(i+0x1C3,0);bpoke(i+0x1C4,0);bpoke(i+0x1C5,10);bpoke(i+0x1E0,168);bpoke(i+0x1E1,0);bpoke(i+0x1E2,2);bpoke(i+0x1E4,0);
bpoke(i+0x1E5,0);bpoke(i+0x200,160);bpoke(i+0x201,0);bpoke(i+0x202,42);bpoke(i+0x204,160);bpoke(i+0x205,0);bpoke(i+0x206,42);
bpoke(i+0x220,128);bpoke(i+0x221,2);bpoke(i+0x225,0);bpoke(i+0x226,10);bpoke(i+0x240,0);bpoke(i+0x245,168);bpoke(i+0x246,2);



		i = (0xe800 - (23*32)) + k/4;

// STAR B

bpoke(i+0x023,154);bpoke(i+0x043,86);bpoke(i+0x062,169);bpoke(i+0x063,85);bpoke(i+0x082,165);bpoke(i+0x083,85);bpoke(i+0x084,106);
bpoke(i+0x0A2,149);bpoke(i+0x0A3,85);bpoke(i+0x0A4,90);bpoke(i+0x0C2,85);bpoke(i+0x0C3,85);bpoke(i+0x0C4,86);
bpoke(i+0x0E0,85);bpoke(i+0x0E1,85);bpoke(i+0x0E2,85);bpoke(i+0x0E3,85);bpoke(i+0x0E4,85);bpoke(i+0x0E5,85);bpoke(i+0x0E6,86);
bpoke(i+0x100,149);bpoke(i+0x101,85);bpoke(i+0x102,85);bpoke(i+0x103,85);bpoke(i+0x104,85);bpoke(i+0x105,85);bpoke(i+0x106,90);
bpoke(i+0x120,165);bpoke(i+0x121,85);bpoke(i+0x122,85);bpoke(i+0x123,85);bpoke(i+0x124,85);bpoke(i+0x125,85);bpoke(i+0x126,106);
bpoke(i+0x141,85);bpoke(i+0x142,85);bpoke(i+0x143,85);bpoke(i+0x144,85);bpoke(i+0x145,86);bpoke(i+0x161,165);
bpoke(i+0x162,85);bpoke(i+0x163,85);bpoke(i+0x164,85);bpoke(i+0x165,106);bpoke(i+0x181,169);bpoke(i+0x182,85);
bpoke(i+0x183,85);bpoke(i+0x184,85);bpoke(i+0x1A1,165);bpoke(i+0x1A2,85);bpoke(i+0x1A3,85);bpoke(i+0x1A4,85);bpoke(i+0x1A5,106);
bpoke(i+0x1C1,149);bpoke(i+0x1C2,85);bpoke(i+0x1C3,85);bpoke(i+0x1C4,85);bpoke(i+0x1C5,90);bpoke(i+0x1E0,169);bpoke(i+0x1E1,85);
bpoke(i+0x1E2,86);bpoke(i+0x1E4,85);bpoke(i+0x1E5,85);bpoke(i+0x200,165);bpoke(i+0x201,85);bpoke(i+0x202,106);
bpoke(i+0x204,165);bpoke(i+0x205,85);bpoke(i+0x206,106);bpoke(i+0x220,149);bpoke(i+0x221,86);bpoke(i+0x225,85);bpoke(i+0x226,90);
bpoke(i+0x240,85);bpoke(i+0x245,169);bpoke(i+0x246,86);bpoke(i+0x260,90);bpoke(i+0x266,150);

//STAR C

//		i = ((0xe000 + (32*32)) + (k/2));
		i = c + (d*32) + 0xE000;
bpoke(i+0x023,186);bpoke(i+0x043,254);bpoke(i+0x062,171);bpoke(i+0x063,255);bpoke(i+0x082,175);bpoke(i+0x083,255);bpoke(i+0x084,234);
bpoke(i+0x0A2,191);bpoke(i+0x0A3,255);bpoke(i+0x0A4,250);bpoke(i+0x0C2,255);bpoke(i+0x0C3,255);bpoke(i+0x0C4,254);
bpoke(i+0x0E0,255);bpoke(i+0x0E1,255);bpoke(i+0x0E2,255);bpoke(i+0x0E3,255);bpoke(i+0x0E4,255);bpoke(i+0x0E5,255);bpoke(i+0x0E6,254);
bpoke(i+0x100,191);bpoke(i+0x101,255);bpoke(i+0x102,255);bpoke(i+0x103,255);bpoke(i+0x104,255);bpoke(i+0x105,255);bpoke(i+0x106,250);
bpoke(i+0x120,175);bpoke(i+0x121,255);bpoke(i+0x122,255);bpoke(i+0x123,255);bpoke(i+0x124,255);bpoke(i+0x125,255);
bpoke(i+0x126,234);bpoke(i+0x141,255);bpoke(i+0x142,255);bpoke(i+0x143,255);bpoke(i+0x144,255);bpoke(i+0x145,254);
bpoke(i+0x161,175);bpoke(i+0x162,255);bpoke(i+0x163,255);bpoke(i+0x164,255);bpoke(i+0x165,234);
bpoke(i+0x181,171);bpoke(i+0x182,255);bpoke(i+0x183,255);bpoke(i+0x184,255);bpoke(i+0x1A1,175);bpoke(i+0x1A2,255);bpoke(i+0x1A3,255);
bpoke(i+0x1A4,255);bpoke(i+0x1A5,234);bpoke(i+0x1C1,191);bpoke(i+0x1C2,255);bpoke(i+0x1C3,255);bpoke(i+0x1C4,255);bpoke(i+0x1C5,250);
bpoke(i+0x1E0,171);bpoke(i+0x1E1,255);bpoke(i+0x1E2,254);bpoke(i+0x1E4,255);bpoke(i+0x1E5,255);bpoke(i+0x200,175);bpoke(i+0x201,255);
bpoke(i+0x202,234);bpoke(i+0x204,175);bpoke(i+0x205,255);bpoke(i+0x206,234);bpoke(i+0x220,191);bpoke(i+0x221,254);bpoke(i+0x225,255);
bpoke(i+0x226,250);bpoke(i+0x240,255);bpoke(i+0x245,171);bpoke(i+0x246,254);bpoke(i+0x260,250);bpoke(i+0x266,190);
                                      

		i = ((0xE000 + (31*32)) - (k/3)) - 8;

bpoke(i+0x023,154);bpoke(i+0x043,86);bpoke(i+0x062,169);bpoke(i+0x063,85);bpoke(i+0x082,165);bpoke(i+0x083,85);bpoke(i+0x084,106);
bpoke(i+0x0A2,149);bpoke(i+0x0A3,85);bpoke(i+0x0A4,90);bpoke(i+0x0C2,85);bpoke(i+0x0C3,85);bpoke(i+0x0C4,86);
bpoke(i+0x0E0,85);bpoke(i+0x0E1,85);bpoke(i+0x0E2,85);bpoke(i+0x0E3,85);bpoke(i+0x0E4,85);bpoke(i+0x0E5,85);bpoke(i+0x0E6,86);
bpoke(i+0x100,149);bpoke(i+0x101,85);bpoke(i+0x102,85);bpoke(i+0x103,85);bpoke(i+0x104,85);bpoke(i+0x105,85);bpoke(i+0x106,90);
bpoke(i+0x120,165);bpoke(i+0x121,85);bpoke(i+0x122,85);bpoke(i+0x123,85);bpoke(i+0x124,85);bpoke(i+0x125,85);bpoke(i+0x126,106);
bpoke(i+0x141,85);bpoke(i+0x142,85);bpoke(i+0x143,85);bpoke(i+0x144,85);bpoke(i+0x145,86);bpoke(i+0x161,165);
bpoke(i+0x162,85);bpoke(i+0x163,85);bpoke(i+0x164,85);bpoke(i+0x165,106);bpoke(i+0x181,169);bpoke(i+0x182,85);
bpoke(i+0x183,85);bpoke(i+0x184,85);bpoke(i+0x1A1,165);bpoke(i+0x1A2,85);bpoke(i+0x1A3,85);bpoke(i+0x1A4,85);bpoke(i+0x1A5,106);
bpoke(i+0x1C1,149);bpoke(i+0x1C2,85);bpoke(i+0x1C3,85);bpoke(i+0x1C4,85);bpoke(i+0x1C5,90);bpoke(i+0x1E0,169);bpoke(i+0x1E1,85);
bpoke(i+0x1E2,86);bpoke(i+0x1E4,85);bpoke(i+0x1E5,85);bpoke(i+0x200,165);bpoke(i+0x201,85);bpoke(i+0x202,106);
bpoke(i+0x204,165);bpoke(i+0x205,85);bpoke(i+0x206,106);bpoke(i+0x220,149);bpoke(i+0x221,86);bpoke(i+0x225,85);bpoke(i+0x226,90);
bpoke(i+0x240,85);bpoke(i+0x245,169);bpoke(i+0x246,86);bpoke(i+0x260,90);bpoke(i+0x266,150);



//star d

		i =  0xE000 + e + (f*32);

bpoke(i+0x003,85);bpoke(i+0x004,90);bpoke(i+0x022,149);bpoke(i+0x023,85);bpoke(i+0x024,85);bpoke(i+0x025,106);
bpoke(i+0x042,85);bpoke(i+0x043,106);bpoke(i+0x044,149);bpoke(i+0x045,90);
bpoke(i+0x061,169);bpoke(i+0x062,85);bpoke(i+0x064,165);bpoke(i+0x065,86);
bpoke(i+0x081,149);bpoke(i+0x082,149);bpoke(i+0x083,106);bpoke(i+0x084,165);bpoke(i+0x085,101);bpoke(i+0x086,106);
bpoke(i+0x0A1,86);bpoke(i+0x0A2,165);bpoke(i+0x0A3,106);bpoke(i+0x0A4,165);bpoke(i+0x0A5,105);bpoke(i+0x0A6,90);
bpoke(i+0x0C1,90);bpoke(i+0x0C2,165);bpoke(i+0x0C3,106);bpoke(i+0x0C4,165);bpoke(i+0x0C6,86);
bpoke(i+0x0E0,169);bpoke(i+0x0E1,106);bpoke(i+0x0E2,169);bpoke(i+0x0E3,90);bpoke(i+0x0E4,149);bpoke(i+0x0E6,150);
bpoke(i+0x100,165);bpoke(i+0x102,169);bpoke(i+0x103,90);bpoke(i+0x104,150);bpoke(i+0x106,165);
bpoke(i+0x120,165);bpoke(i+0x123,90);bpoke(i+0x124,150);bpoke(i+0x126,165);bpoke(i+0x127,106);
bpoke(i+0x140,149);bpoke(i+0x141,90);bpoke(i+0x143,86);bpoke(i+0x144,90);bpoke(i+0x146,85);bpoke(i+0x147,106);
bpoke(i+0x160,149);bpoke(i+0x161,85);bpoke(i+0x163,150);bpoke(i+0x164,90);bpoke(i+0x165,165);bpoke(i+0x166,85);bpoke(i+0x167,90);
bpoke(i+0x180,85);bpoke(i+0x181,85);bpoke(i+0x182,90);bpoke(i+0x183,150);bpoke(i+0x184,106);bpoke(i+0x185,85);
bpoke(i+0x186,85);bpoke(i+0x187,90);bpoke(i+0x1A0,90);bpoke(i+0x1A1,169);bpoke(i+0x1A2,85);bpoke(i+0x1A3,165);
bpoke(i+0x1A4,101);bpoke(i+0x1A5,85);bpoke(i+0x1A7,90);bpoke(i+0x1C0,90);bpoke(i+0x1C2,165);bpoke(i+0x1C3,85);bpoke(i+0x1C4,85);
bpoke(i+0x1C5,106);bpoke(i+0x1C7,90);bpoke(i+0x1E0,90);bpoke(i+0x1E3,149);bpoke(i+0x1E4,106);bpoke(i+0x1E7,90);
bpoke(i+0x200,90);bpoke(i+0x202,165);bpoke(i+0x203,85);bpoke(i+0x204,85);bpoke(i+0x205,106);bpoke(i+0x207,90);
bpoke(i+0x220,90);bpoke(i+0x221,169);bpoke(i+0x222,85);bpoke(i+0x223,165);bpoke(i+0x224,101);bpoke(i+0x225,85);bpoke(i+0x227,90);
bpoke(i+0x240,85);bpoke(i+0x241,85);bpoke(i+0x242,90);bpoke(i+0x243,150);bpoke(i+0x244,106);bpoke(i+0x245,85);bpoke(i+0x246,85);
bpoke(i+0x247,90);bpoke(i+0x260,149);bpoke(i+0x261,85);bpoke(i+0x263,150);bpoke(i+0x264,90);bpoke(i+0x265,165);bpoke(i+0x266,85);
bpoke(i+0x267,90);bpoke(i+0x280,149);bpoke(i+0x281,90);bpoke(i+0x283,86);bpoke(i+0x284,90);bpoke(i+0x286,85);bpoke(i+0x287,106);
bpoke(i+0x2A0,149);bpoke(i+0x2A3,90);bpoke(i+0x2A4,150);bpoke(i+0x2A6,165);bpoke(i+0x2A7,106);bpoke(i+0x2C0,165);bpoke(i+0x2C2,169);
bpoke(i+0x2C3,90);bpoke(i+0x2C4,150);bpoke(i+0x2C6,165);bpoke(i+0x2E0,169);bpoke(i+0x2E1,106);bpoke(i+0x2E2,169);bpoke(i+0x2E3,90);
bpoke(i+0x2E4,149);bpoke(i+0x2E6,150);bpoke(i+0x301,90);bpoke(i+0x302,165);bpoke(i+0x303,106);bpoke(i+0x304,165);bpoke(i+0x306,86);
bpoke(i+0x321,86);bpoke(i+0x322,165);bpoke(i+0x323,106);bpoke(i+0x324,165);bpoke(i+0x325,105);bpoke(i+0x326,90);bpoke(i+0x341,149);
bpoke(i+0x342,85);bpoke(i+0x343,106);bpoke(i+0x344,165);bpoke(i+0x345,85);bpoke(i+0x346,106);bpoke(i+0x361,169);bpoke(i+0x362,85);
bpoke(i+0x364,165);bpoke(i+0x365,86);bpoke(i+0x382,85);bpoke(i+0x383,85);bpoke(i+0x384,85);bpoke(i+0x385,90);
bpoke(i+0x3A2,165);bpoke(i+0x3A3,85);bpoke(i+0x3A4,85);


		i =  0xE000 + g + (h*32);

//stard3
bpoke(i+0x002,166);bpoke(i+0x005,90);bpoke(i+0x022,166);bpoke(i+0x024,165);bpoke(i+0x025,106);bpoke(i+0x042,149);bpoke(i+0x043,85);
bpoke(i+0x044,85);bpoke(i+0x045,106);bpoke(i+0x062,149);bpoke(i+0x063,85);bpoke(i+0x064,85);bpoke(i+0x065,106);bpoke(i+0x082,85);bpoke(i+0x083,106);
bpoke(i+0x085,85);bpoke(i+0x0A2,90);bpoke(i+0x0A5,165);bpoke(i+0x0A6,85);bpoke(i+0x0A7,86);bpoke(i+0x0C2,90);bpoke(i+0x0C5,169);
bpoke(i+0x0C6,85);bpoke(i+0x0E0,165);bpoke(i+0x0E1,85);bpoke(i+0x0E2,106);bpoke(i+0x0E6,86);bpoke(i+0x100,169);bpoke(i+0x101,85);
bpoke(i+0x106,90);bpoke(i+0x121,150);bpoke(i+0x126,150);bpoke(i+0x141,165);bpoke(i+0x146,150);bpoke(i+0x161,165);bpoke(i+0x166,149);
bpoke(i+0x181,165);bpoke(i+0x186,85);bpoke(i+0x187,106);bpoke(i+0x1A1,149);bpoke(i+0x1A2,106);bpoke(i+0x1A6,106);bpoke(i+0x1A7,90);
bpoke(i+0x1C0,85);bpoke(i+0x1C1,85);bpoke(i+0x1C2,90);bpoke(i+0x1C5,165);bpoke(i+0x1C6,106);bpoke(i+0x1E2,149);bpoke(i+0x1E3,106);bpoke(i+0x1E5,85);
bpoke(i+0x202,169);bpoke(i+0x203,85);bpoke(i+0x204,85);bpoke(i+0x205,85);bpoke(i+0x222,169);bpoke(i+0x223,85);bpoke(i+0x224,169);bpoke(i+0x225,85);
bpoke(i+0x242,169);bpoke(i+0x243,86);bpoke(i+0x245,149);bpoke(i+0x262,169);bpoke(i+0x263,106);bpoke(i+0x265,165);bpoke(i+0x282,165);bpoke(i+0x285,165);




	memcpy (28672, 0xE000 , 2048);
		}

	}
}
