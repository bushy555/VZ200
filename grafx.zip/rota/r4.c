 #include <vz.h>
 #include <graphics.h>
 #include <stdio.h>
 #include <sound.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <strings.h>
 #include <conio.h>
 #include <math.h>
 
 #define PI = 3.1415926535

main()
{
   int     i,j,k,x,y,a,b,d,e,f, angle, m, n, c, s;
   double  t,zx,zy;

   vz_setbase(0x7000);
   k = 1;
   vz_mode(1);

   i=0;j=0;
   // line 1
   vz_plot(i  ,j,0);vz_plot(i+1,j,0);vz_plot(i+2,j,0); vz_plot(i+3,j,0); vz_plot(i+4,j,0); vz_plot(i+5,j,0); vz_plot(i+6,j,0); vz_plot(i+7,j,0);
   vz_plot(i+8,j,0);vz_plot(i+9,j,0);vz_plot(i+10,j,0);vz_plot(i+11,j,0);vz_plot(i+12,j,0);vz_plot(i+13,j,1);vz_plot(i+14,j,1);vz_plot(i+15,j,1);
   // line 2
   vz_plot(i  ,j+1,0);vz_plot(i+1,j+1,0);vz_plot(i+2,j+1,0); vz_plot(i+3,j+1,0); vz_plot(i+4,j+1,0); vz_plot(i+5,j+1,0); vz_plot(i+6,j+1,3); vz_plot(i+7,j+1,3);
   vz_plot(i+8,j+1,3);vz_plot(i+9,j+1,3);vz_plot(i+10,j+1,3);vz_plot(i+11,j+1,0);vz_plot(i+12,j+1,0);vz_plot(i+13,j+1,1);vz_plot(i+14,j+1,1);vz_plot(i+15,j+1,1);
   // line 3
vz_plot(i  ,j+2,0);vz_plot(i+1,j+2,0);vz_plot(i+2,j+2,0); vz_plot(i+3,j+2,0); vz_plot(i+4,j+2,0); vz_plot(i+5,j+2,3); vz_plot(i+6,j+2,3); vz_plot(i+7,j+2, 3);
vz_plot(i+8,j+2,3);vz_plot(i+9,j+2,3);vz_plot(i+10,j+2,3);vz_plot(i+11,j+2,3);vz_plot(i+12,j+2,3);vz_plot(i+13,j+2,3);vz_plot(i+14,j+2,1);vz_plot(i+15,j+2,1);
// line 4
vz_plot(i  ,j+3,0);vz_plot(i+1,j+3,0);vz_plot(i+2,j+3,0); vz_plot(i+3,j+3,0); vz_plot(i+4,j+3,0); vz_plot(i+5,j+3,2); vz_plot(i+6,j+3,2); vz_plot(i+7,j+3,2);
vz_plot(i+8,j+3,1);vz_plot(i+9,j+3,1);vz_plot(i+10,j+3,2);vz_plot(i+11,j+3,1);vz_plot(i+12,j+3,1);vz_plot(i+13,j+3,2);vz_plot(i+14,j+3,2);vz_plot(i+15,j+3,2);
// line 5
vz_plot(i  ,j+4,0);vz_plot(i+1,j+4,0);vz_plot(i+2,j+4,0); vz_plot(i+3,j+4,0); vz_plot(i+4,j+4,2); vz_plot(i+5,j+4,1); vz_plot(i+6,j+4,2); vz_plot(i+7,j+4,1);
vz_plot(i+8,j+4,1);vz_plot(i+9,j+4,1);vz_plot(i+10,j+4,2);vz_plot(i+11,j+4,1);vz_plot(i+12,j+4,1);vz_plot(i+13,j+4,2);vz_plot(i+14,j+4,2);vz_plot(i+15,j+4,2);
// line 6
vz_plot(i  ,j+5,0);vz_plot(i+1,j+5,0);vz_plot(i+2,j+5,0); vz_plot(i+3,j+5,0); vz_plot(i+4,j+5,2); vz_plot(i+5,j+5,1); vz_plot(i+6,j+5,2); vz_plot(i+7,j+5,2);
vz_plot(i+8,j+5,1);vz_plot(i+9,j+5,1);vz_plot(i+10,j+5,1);vz_plot(i+11,j+5,2);vz_plot(i+12,j+5,1);vz_plot(i+13,j+5,1);vz_plot(i+14,j+5,1);vz_plot(i+15,j+5,2);
// line 7
vz_plot(i  ,j+6,0);vz_plot(i+1,j+6,0);vz_plot(i+2,j+6,0); vz_plot(i+3,j+6,0); vz_plot(i+4,j+6,2); vz_plot(i+5,j+6,2); vz_plot(i+6,j+6,1); vz_plot(i+7,j+6,1);
vz_plot(i+8,j+6,1);vz_plot(i+9,j+6,1);vz_plot(i+10,j+6,2);vz_plot(i+11,j+6,2);vz_plot(i+12,j+6,2);vz_plot(i+13,j+6,2);vz_plot(i+14,j+6,2);vz_plot(i+15,j+6,0);
// line 8
vz_plot(i  ,j+7,0);vz_plot(i+1,j+7,0);vz_plot(i+2,j+7,0); vz_plot(i+3,j+7,0); vz_plot(i+4,j+7,0); vz_plot(i+5,j+7,0); vz_plot(i+6,j+7,1); vz_plot(i+7,j+7,1);
vz_plot(i+8,j+7,1);vz_plot(i+9,j+7,1);vz_plot(i+10,j+7,1);vz_plot(i+11,j+7,1);vz_plot(i+12,j+7,1);vz_plot(i+13,j+7,2);vz_plot(i+14,j+7,0);vz_plot(i+15,j+7,0);
// line 9
vz_plot(i  ,j+8,0);vz_plot(i+1,j+8,0);vz_plot(i+2,j+8,2); vz_plot(i+3,j+8,2); vz_plot(i+4,j+8,2); vz_plot(i+5,j+8,2); vz_plot(i+6,j+8,2); vz_plot(i+7,j+8,3);
vz_plot(i+8,j+8,2);vz_plot(i+9,j+8,2);vz_plot(i+10,j+8,2);vz_plot(i+11,j+8,3);vz_plot(i+12,j+8,2);vz_plot(i+13,j+8,0);vz_plot(i+14,j+8,0);vz_plot(i+15,j+8,0);
// line 10
vz_plot(i  ,j+9,0);vz_plot(i+1,j+9,2);vz_plot(i+2,j+9,2); vz_plot(i+3,j+9,2); vz_plot(i+4,j+9,2); vz_plot(i+5,j+9,2); vz_plot(i+6,j+9,2); vz_plot(i+7,j+9,2);
vz_plot(i+8,j+9,3);vz_plot(i+9,j+9,2);vz_plot(i+10,j+9,2);vz_plot(i+11,j+9,2);vz_plot(i+12,j+9,3);vz_plot(i+13,j+9,0);vz_plot(i+14,j+9,0);vz_plot(i+15,j+9,2);
// line 11
vz_plot(i  ,j+10,1);vz_plot(i+1,j+10,1);vz_plot(i+2,j+10,2); vz_plot(i+3,j+10,2); vz_plot(i+4,j+10,2); vz_plot(i+5,j+10,2); vz_plot(i+6,j+10,2); vz_plot(i+7,j+10,2);
vz_plot(i+8,j+10,3);vz_plot(i+9,j+10,3);vz_plot(i+10,j+10,3);vz_plot(i+11,j+10,3);vz_plot(i+12,j+10,3);vz_plot(i+13,j+10,0);vz_plot(i+14,j+10,0);vz_plot(i+15,j+10,2);
// line 12
vz_plot(i  ,j+11,1);vz_plot(i+1,j+11,1);vz_plot(i+2,j+11,1); vz_plot(i+3,j+11,0); vz_plot(i+4,j+11,3); vz_plot(i+5,j+11,3); vz_plot(i+6,j+11,2); vz_plot(i+7,j+11,3);
vz_plot(i+8,j+11,3);vz_plot(i+9,j+11,1);vz_plot(i+10,j+11,3);vz_plot(i+11,j+11,3);vz_plot(i+12,j+11,1);vz_plot(i+13,j+11,3);vz_plot(i+14,j+11,2);vz_plot(i+15,j+11,2);
// line 13
vz_plot(i  ,j+12,0);vz_plot(i+1,j+12,1);vz_plot(i+2,j+12,0); vz_plot(i+3,j+12,2); vz_plot(i+4,j+12,3); vz_plot(i+5,j+12,3); vz_plot(i+6,j+12,3); vz_plot(i+7,j+12,3);
vz_plot(i+8,j+12,3);vz_plot(i+9,j+12,3);vz_plot(i+10,j+12,3);vz_plot(i+11,j+12,3);vz_plot(i+12,j+12,3);vz_plot(i+13,j+12,3);vz_plot(i+14,j+12,2);vz_plot(i+15,j+12,2);
// line 14
vz_plot(i  ,j+13,0);vz_plot(i+1,j+13,0);vz_plot(i+2,j+13,2); vz_plot(i+3,j+13,2); vz_plot(i+4,j+13,2); vz_plot(i+5,j+13,3); vz_plot(i+6,j+13,3); vz_plot(i+7,j+13,3);
vz_plot(i+8,j+13,3);vz_plot(i+9,j+13,3);vz_plot(i+10,j+13,3);vz_plot(i+11,j+13,3);vz_plot(i+12,j+13,3);vz_plot(i+13,j+13,3);vz_plot(i+14,j+13,2);vz_plot(i+15,j+13,2);
// line 15
vz_plot(i  ,j+14,0);vz_plot(i+1,j+14,2);vz_plot(i+2,j+14,2); vz_plot(i+3,j+14,2); vz_plot(i+4,j+14,3); vz_plot(i+5,j+14,3); vz_plot(i+6,j+14,3); vz_plot(i+7,j+14,3);
vz_plot(i+8,j+14,3);vz_plot(i+9,j+14,3);vz_plot(i+10,j+14,0);vz_plot(i+11,j+14,0);vz_plot(i+12,j+14,0);vz_plot(i+13,j+14,0);vz_plot(i+14,j+14,0);vz_plot(i+15,j+14,0);
// line 16
vz_plot(i  ,j+15,0);vz_plot(i+1,j+15,2);vz_plot(i+2,j+15,0); vz_plot(i+3,j+15,0); vz_plot(i+4,j+15,3); vz_plot(i+5,j+15,3); vz_plot(i+6,j+15,3); vz_plot(i+7,j+15,0);
vz_plot(i+8,j+15,0);vz_plot(i+9,j+15,0);vz_plot(i+10,j+15,0);vz_plot(i+11,j+15,0);vz_plot(i+12,j+15,0);vz_plot(i+13,j+15,0);vz_plot(i+14,j+15,0);vz_plot(i+15,j+15,0);






//    procedure rotate2d( var x_coords, y_coords  :  coord_vals;
//                            xp, yp, degrees     :  integer  );
//       var i                :  integer;
//           t, c, s, zx, zy  :  real;
//       begin
//          t := (degrees MOD 360) * 0.0174533; { Convert Degrees to Radians }
//          c := cos( t );
//          s := sin( t );
//          for i := 1 to x_coords[0] do begin
//              zx := (x_coords[i] - xp) * c - (y_coords[i] - yp) * s + xp;
//              zy := (y_coords[i] - yp) * c + (x_coords[i] - xp) * s + yp;
//              x_coords[i] := round( zx );
//              y_coords[i] := round( zy );
//          end;
//       end;


   while (k==1)   {
      for (angle=0;angle<360;angle++)       {
         c = (cos( angle / 360) * 0.0174533);  
         s = (sin( angle / 360) * 0.0174533);  
         for (j=0;j<16;j++)   {
//            for (i=0;i<4;i++) {
//               zx = 50 + ( (bpeek(0x7000+i) ) * c )- ((bpeek(0x7000+(j*32))) * s));
//               zy = (20 + bpeek(0x7000+(j*32)) * c + bpeek(0x7000+i) * s);
//            vz_plot(zx, zy, bpeek(0x7000+(j*32)+i));                 
//            vz_plot(zx, zy, 2);                 
//
//            }
//
//            for (i=0;i<4;i++) {
//               zx = int(50 + (bpeek(0x7000+i) & 48)* c - (bpeek(0x7000+(j*32)) & 48) * s);
//               zy = int(20 + bpeek(0x7000+(j*32)) * c + bpeek(0x7000+i) * s);
//               vz_plot(zx, zy, bpeek(0x7000+(j*32)+i));                 
//            }
//
//
//            for (i=0;i<4;i++) {
//               zx = 50 + bpeek(0x7000+i) * c - bpeek(0x7000+(j*32)) * s;
//               zy = 20 + bpeek(0x7000+(j*32)) * c + bpeek(0x7000+i) * s;
//               vz_plot(zx, zy, bpeek(0x7000+(j*32)+i));                 
//            }
//
//
            for (i=0;i<2;i++) {

               zx = 50 + bpeek(0x7000+i) * c - bpeek(0x7000+(j*32)) * s;
               zy = 20 + bpeek(0x7000+(j*32)) * c + bpeek(0x7000+i) * s;
                 vz_plot ( i, j, 3);
                 vz_plot ( i+4, j, 3);
                 vz_plot ( i+8, j, 3);
                 vz_plot ( i+12, j, 3);
//               vz_plot(zx, zy, bpeek(0x7000+(j*32)+(i*2)));                 
               vz_plot(zx + i, zy+j, bpeek(0x7000+(j*32)+(i)));   
               vz_plot(zx + i+4, zy+j, bpeek(0x7000+(j*32)+(i)));   
               vz_plot(zx + i+8, zy+j, bpeek(0x7000+(j*32)+(i)));   
               vz_plot(zx + i+12, zy+j, bpeek(0x7000+(j*32)+(i)));   

            }


         }
      }
   
}
}
