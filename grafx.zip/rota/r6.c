// R6
//
//
//  USes SIN / COS tables in Asm to do the rotating.
//  got it working, still slow.
//
//
///////////////////
//

 #include <vz.h>
 #include <graphics.h>
 #include <stdio.h>
 #include <sound.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <strings.h>
 #include <conio.h>
 #include <math.h>
 #include <zxlowgfx.h>
 #include <spectrum.h>
// #include <zx81.h>
// #include <aquarius.h>


 #define PI = 3.1415926535

int x1, y1, i, j;
//int g_col;



int vz_set(int x, int y, int c)		// ----- graphics mode set pixel at x=L, y=H color C
{
   #asm
pset4:  
	ld	hl, 2
	add	hl, sp

	ld	c, (hl)			// colour
	inc	hl
	inc	hl
	ld	e, (hl)			// Y value	e = y.
	inc	hl
	inc	hl
	ld	l, (hl)			// x value      l = x.
	ld	h, e			// y value      h = y.

        ld      a, l            ; get x
        sla     l               ; calculate screen offset
        srl     h
        rr      l
        srl     h
        rr      l
        srl     h
        rr      l
        and     #3              ; pixel offset
        inc     a
        ld      b, #0b11111100
pset3:  rrc     b
        rrc     b
        rrc     c
        rrc     c
        dec     a
        jr      nz, pset3
	ld	de, 0x7000
	add	hl, de
        ld      a, (hl)
        and     b
        or      c
        ld      (hl), a
	 ret
   #endasm
}




int vz_point2(int x, int y)		// ROM CALL
{
   #asm
	ld	hl, 2
	add	hl, sp
	ld	e, (hl)			// Y value	e = y.
	inc	hl
	inc	hl
	ld	l, (hl)			// x value      l = x.
	ld	h, e			// y value      h = y.
        ld      a, l            ; get x
	push	af

	ld	e, h		; e = y
	xor	a
	ld	d, a
	ex	de, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ex	de, hl
	pop	af
	push	af
	srl	a
	srl	a
	add	a,e
	ld	e,a
	ld	a,d
	or	70h
	ld	d, a
	pop	af
	and	3	
	add	a,a
	ld	b,a
	ld	c, 0c0h
aset:	rrc	c
	djnz	aset
	ld	a, (de)
	and	c
	ld	b, a
	ld	a, c
bset:	rrc	b
	rrc	a
	cp	3
	jr	nz,bset
	ld	h, 0
	ld	l, b

;	ld	l, a


   #endasm
}


display_old()			// Displays MArio via VZ_PLOT and also displays
{			
int	m;
int	n;
	i = 0;
	j = 0;
	
   // line 1
   vz_plot(i  ,j,0);vz_plot(i+1,j,0);vz_plot(i+2,j,0); vz_plot(i+3,j,0); vz_plot(i+4,j,0); vz_plot(i+5,j,0); vz_plot(i+6,j,0); vz_plot(i+7,j,0);
   vz_plot(i+8,j,0);vz_plot(i+9,j,0);vz_plot(i+10,j,0);vz_plot(i+11,j,0);vz_plot(i+12,j,0);vz_plot(i+13,j,1);vz_plot(i+14,j,1);vz_plot(i+15,j,1);
   // line 2
   vz_plot(i  ,j+1,0);vz_plot(i+1,j+1,0);vz_plot(i+2,j+1,0); vz_plot(i+3,j+1,0); vz_plot(i+4,j+1,0); vz_plot(i+5,j+1,0); vz_plot(i+6,j+1,3); vz_plot(i+7,j+1,3);
   vz_plot(i+8,j+1,3);vz_plot(i+9,j+1,3);vz_plot(i+10,j+1,3);vz_plot(i+11,j+1,0);vz_plot(i+12,j+1,0);vz_plot(i+13,j+1,1);vz_plot(i+14,j+1,1);vz_plot(i+15,j+1,1);
   // line 3
vz_plot(i  ,j+2,0);vz_plot(i+1,j+2,0);vz_plot(i+2,j+2,0); vz_plot(i+3,j+2,0); vz_plot(i+4,j+2,0); vz_plot(i+5,j+2,3); vz_plot(i+6,j+2,3); vz_plot(i+7,j+2, 3);
vz_plot(i+8,j+2,3);vz_plot(i+9,j+2,3);vz_plot(i+10,j+2,3);vz_plot(i+11,j+2,3);vz_plot(i+12,j+2,3);vz_plot(i+13,j+2,3);vz_plot(i+14,j+2,1);vz_plot(i+15,j+2,1);
// line 4
vz_plot(i  ,j+3,0);vz_plot(i+1,j+3,0);vz_plot(i+2,j+3,0); vz_plot(i+3,j+3,0); vz_plot(i+4,j+3,0); vz_plot(i+5,j+3,2); vz_plot(i+6,j+3,2); vz_plot(i+7,j+3,2);
vz_plot(i+8,j+3,1);vz_plot(i+9,j+3,1);vz_plot(i+10,j+3,2);vz_plot(i+11,j+3,1);vz_plot(i+12,j+3,1);vz_plot(i+13,j+3,2);vz_plot(i+14,j+3,2);vz_plot(i+15,j+3,2);
// line 5
vz_plot(i  ,j+4,0);vz_plot(i+1,j+4,0);vz_plot(i+2,j+4,0); vz_plot(i+3,j+4,0); vz_plot(i+4,j+4,2); vz_plot(i+5,j+4,1); vz_plot(i+6,j+4,2); vz_plot(i+7,j+4,1);
vz_plot(i+8,j+4,1);vz_plot(i+9,j+4,1);vz_plot(i+10,j+4,2);vz_plot(i+11,j+4,1);vz_plot(i+12,j+4,1);vz_plot(i+13,j+4,2);vz_plot(i+14,j+4,2);vz_plot(i+15,j+4,2);
// line 6
vz_plot(i  ,j+5,0);vz_plot(i+1,j+5,0);vz_plot(i+2,j+5,0); vz_plot(i+3,j+5,0); vz_plot(i+4,j+5,2); vz_plot(i+5,j+5,1); vz_plot(i+6,j+5,2); vz_plot(i+7,j+5,2);
vz_plot(i+8,j+5,1);vz_plot(i+9,j+5,1);vz_plot(i+10,j+5,1);vz_plot(i+11,j+5,2);vz_plot(i+12,j+5,1);vz_plot(i+13,j+5,1);vz_plot(i+14,j+5,1);vz_plot(i+15,j+5,2);
// line 7
vz_plot(i  ,j+6,0);vz_plot(i+1,j+6,0);vz_plot(i+2,j+6,0); vz_plot(i+3,j+6,0); vz_plot(i+4,j+6,2); vz_plot(i+5,j+6,2); vz_plot(i+6,j+6,1); vz_plot(i+7,j+6,1);
vz_plot(i+8,j+6,1);vz_plot(i+9,j+6,1);vz_plot(i+10,j+6,2);vz_plot(i+11,j+6,2);vz_plot(i+12,j+6,2);vz_plot(i+13,j+6,2);vz_plot(i+14,j+6,2);vz_plot(i+15,j+6,0);
// line 8
vz_plot(i  ,j+7,0);vz_plot(i+1,j+7,0);vz_plot(i+2,j+7,0); vz_plot(i+3,j+7,0); vz_plot(i+4,j+7,0); vz_plot(i+5,j+7,0); vz_plot(i+6,j+7,1); vz_plot(i+7,j+7,1);
vz_plot(i+8,j+7,1);vz_plot(i+9,j+7,1);vz_plot(i+10,j+7,1);vz_plot(i+11,j+7,1);vz_plot(i+12,j+7,1);vz_plot(i+13,j+7,2);vz_plot(i+14,j+7,0);vz_plot(i+15,j+7,0);
// line 9
vz_plot(i  ,j+8,0);vz_plot(i+1,j+8,0);vz_plot(i+2,j+8,2); vz_plot(i+3,j+8,2); vz_plot(i+4,j+8,2); vz_plot(i+5,j+8,2); vz_plot(i+6,j+8,2); vz_plot(i+7,j+8,3);
vz_plot(i+8,j+8,2);vz_plot(i+9,j+8,2);vz_plot(i+10,j+8,2);vz_plot(i+11,j+8,3);vz_plot(i+12,j+8,2);vz_plot(i+13,j+8,0);vz_plot(i+14,j+8,0);vz_plot(i+15,j+8,0);
// line 10
vz_plot(i  ,j+9,0);vz_plot(i+1,j+9,2);vz_plot(i+2,j+9,2); vz_plot(i+3,j+9,2); vz_plot(i+4,j+9,2); vz_plot(i+5,j+9,2); vz_plot(i+6,j+9,2); vz_plot(i+7,j+9,2);
vz_plot(i+8,j+9,3);vz_plot(i+9,j+9,2);vz_plot(i+10,j+9,2);vz_plot(i+11,j+9,2);vz_plot(i+12,j+9,3);vz_plot(i+13,j+9,0);vz_plot(i+14,j+9,0);vz_plot(i+15,j+9,2);
// line 11
vz_plot(i  ,j+10,1);vz_plot(i+1,j+10,1);vz_plot(i+2,j+10,2); vz_plot(i+3,j+10,2); vz_plot(i+4,j+10,2); vz_plot(i+5,j+10,2); vz_plot(i+6,j+10,2); vz_plot(i+7,j+10,2);
vz_plot(i+8,j+10,3);vz_plot(i+9,j+10,3);vz_plot(i+10,j+10,3);vz_plot(i+11,j+10,3);vz_plot(i+12,j+10,3);vz_plot(i+13,j+10,0);vz_plot(i+14,j+10,0);vz_plot(i+15,j+10,2);
// line 12
vz_plot(i  ,j+11,1);vz_plot(i+1,j+11,1);vz_plot(i+2,j+11,1); vz_plot(i+3,j+11,0); vz_plot(i+4,j+11,3); vz_plot(i+5,j+11,3); vz_plot(i+6,j+11,2); vz_plot(i+7,j+11,3);
vz_plot(i+8,j+11,3);vz_plot(i+9,j+11,1);vz_plot(i+10,j+11,3);vz_plot(i+11,j+11,3);vz_plot(i+12,j+11,1);vz_plot(i+13,j+11,3);vz_plot(i+14,j+11,2);vz_plot(i+15,j+11,2);
// line 13
vz_plot(i  ,j+12,0);vz_plot(i+1,j+12,1);vz_plot(i+2,j+12,0); vz_plot(i+3,j+12,2); vz_plot(i+4,j+12,3); vz_plot(i+5,j+12,3); vz_plot(i+6,j+12,3); vz_plot(i+7,j+12,3);
vz_plot(i+8,j+12,3);vz_plot(i+9,j+12,3);vz_plot(i+10,j+12,3);vz_plot(i+11,j+12,3);vz_plot(i+12,j+12,3);vz_plot(i+13,j+12,3);vz_plot(i+14,j+12,2);vz_plot(i+15,j+12,2);
// line 14
vz_plot(i  ,j+13,0);vz_plot(i+1,j+13,0);vz_plot(i+2,j+13,2); vz_plot(i+3,j+13,2); vz_plot(i+4,j+13,2); vz_plot(i+5,j+13,3); vz_plot(i+6,j+13,3); vz_plot(i+7,j+13,3);
vz_plot(i+8,j+13,3);vz_plot(i+9,j+13,3);vz_plot(i+10,j+13,3);vz_plot(i+11,j+13,3);vz_plot(i+12,j+13,3);vz_plot(i+13,j+13,3);vz_plot(i+14,j+13,2);vz_plot(i+15,j+13,2);
// line 15
vz_plot(i  ,j+14,0);vz_plot(i+1,j+14,2);vz_plot(i+2,j+14,2); vz_plot(i+3,j+14,2); vz_plot(i+4,j+14,3); vz_plot(i+5,j+14,3); vz_plot(i+6,j+14,3); vz_plot(i+7,j+14,3);
vz_plot(i+8,j+14,3);vz_plot(i+9,j+14,3);vz_plot(i+10,j+14,0);vz_plot(i+11,j+14,0);vz_plot(i+12,j+14,0);vz_plot(i+13,j+14,0);vz_plot(i+14,j+14,0);vz_plot(i+15,j+14,0);
// line 16
vz_plot(i  ,j+15,0);vz_plot(i+1,j+15,2);vz_plot(i+2,j+15,0); vz_plot(i+3,j+15,0); vz_plot(i+4,j+15,3); vz_plot(i+5,j+15,3); vz_plot(i+6,j+15,3); vz_plot(i+7,j+15,0);
vz_plot(i+8,j+15,0);vz_plot(i+9,j+15,0);vz_plot(i+10,j+15,0);vz_plot(i+11,j+15,0);vz_plot(i+12,j+15,0);vz_plot(i+13,j+15,0);vz_plot(i+14,j+15,0);vz_plot(i+15,j+15,0);
}

display_big(int m , int n){		// Mario as 32x16 big sized via POKE
					// display 32x16 mario via poke
m=m+0x7000;

bpoke(m+n* 1,  0);bpoke(m+1+n* 1,  0);bpoke(m+2+n* 1,  0);bpoke(m+3+n* 1,  0);bpoke(m+4+n* 1,  0);bpoke(m+5+n* 1,  0);bpoke(m+6+n* 1,  0);bpoke(m+7+n* 1,  0);bpoke(m+8+n* 1,  0);bpoke(m+9+n* 1,  0);bpoke(m+10+n* 1,  0);bpoke(m+11+n* 1,  0);bpoke(m+12+n* 1,  0);bpoke(m+13+n* 1, 85);bpoke(m+14+n* 1, 85);bpoke(m+15+n* 1, 85);
bpoke(m+n* 2,  0);bpoke(m+1+n* 2,  0);bpoke(m+2+n* 2,  0);bpoke(m+3+n* 2,  0);bpoke(m+4+n* 2,  0);bpoke(m+5+n* 2,  0);bpoke(m+6+n* 2,255);bpoke(m+7+n* 2,255);bpoke(m+8+n* 2,255);bpoke(m+9+n* 2,255);bpoke(m+10+n* 2,255);bpoke(m+11+n* 2,  0);bpoke(m+12+n* 2,  0);bpoke(m+13+n* 2, 85);bpoke(m+14+n* 2, 85);bpoke(m+15+n* 2, 85);
bpoke(m+n* 3,  0);bpoke(m+1+n* 3,  0);bpoke(m+2+n* 3,  0);bpoke(m+3+n* 3,  0);bpoke(m+4+n* 3,  0);bpoke(m+5+n* 3,255);bpoke(m+6+n* 3,255);bpoke(m+7+n* 3,255);bpoke(m+8+n* 3,255);bpoke(m+9+n* 3,255);bpoke(m+10+n* 3,255);bpoke(m+11+n* 3,255);bpoke(m+12+n* 3,255);bpoke(m+13+n* 3,255);bpoke(m+14+n* 3, 85);bpoke(m+15+n* 3, 85);
bpoke(m+n* 4,  0);bpoke(m+1+n* 4,  0);bpoke(m+2+n* 4,  0);bpoke(m+3+n* 4,  0);bpoke(m+4+n* 4,  0);bpoke(m+5+n* 4,170);bpoke(m+6+n* 4,170);bpoke(m+7+n* 4,170);bpoke(m+8+n* 4, 85);bpoke(m+9+n* 4, 85);bpoke(m+10+n* 4,170);bpoke(m+11+n* 4, 85);bpoke(m+12+n* 4, 85);bpoke(m+13+n* 4,170);bpoke(m+14+n* 4,170);bpoke(m+15+n* 4,170);
bpoke(m+n* 5,  0);bpoke(m+1+n* 5,  0);bpoke(m+2+n* 5,  0);bpoke(m+3+n* 5,  0);bpoke(m+4+n* 5,170);bpoke(m+5+n* 5, 85);bpoke(m+6+n* 5,170);bpoke(m+7+n* 5, 85);bpoke(m+8+n* 5, 85);bpoke(m+9+n* 5, 85);bpoke(m+10+n* 5,170);bpoke(m+11+n* 5, 85);bpoke(m+12+n* 5, 85);bpoke(m+13+n* 5,170);bpoke(m+14+n* 5,170);bpoke(m+15+n* 5,170);
bpoke(m+n* 6,  0);bpoke(m+1+n* 6,  0);bpoke(m+2+n* 6,  0);bpoke(m+3+n* 6,  0);bpoke(m+4+n* 6,170);bpoke(m+5+n* 6, 85);bpoke(m+6+n* 6,170);bpoke(m+7+n* 6,170);bpoke(m+8+n* 6, 85);bpoke(m+9+n* 6, 85);bpoke(m+10+n* 6, 85);bpoke(m+11+n* 6,170);bpoke(m+12+n* 6, 85);bpoke(m+13+n* 6, 85);bpoke(m+14+n* 6, 85);bpoke(m+15+n* 6,170);
bpoke(m+n* 7,  0);bpoke(m+1+n* 7,  0);bpoke(m+2+n* 7,  0);bpoke(m+3+n* 7,  0);bpoke(m+4+n* 7,170);bpoke(m+5+n* 7,170);bpoke(m+6+n* 7, 85);bpoke(m+7+n* 7, 85);bpoke(m+8+n* 7, 85);bpoke(m+9+n* 7, 85);bpoke(m+10+n* 7,170);bpoke(m+11+n* 7,170);bpoke(m+12+n* 7,170);bpoke(m+13+n* 7,170);bpoke(m+14+n* 7,170);bpoke(m+15+n* 7,  0);
bpoke(m+n* 8,  0);bpoke(m+1+n* 8,  0);bpoke(m+2+n* 8,  0);bpoke(m+3+n* 8,  0);bpoke(m+4+n* 8,  0);bpoke(m+5+n* 8,  0);bpoke(m+6+n* 8, 85);bpoke(m+7+n* 8, 85);bpoke(m+8+n* 8, 85);bpoke(m+9+n* 8, 85);bpoke(m+10+n* 8, 85);bpoke(m+11+n* 8, 85);bpoke(m+12+n* 8, 85);bpoke(m+13+n* 8,170);bpoke(m+14+n* 8,  0);bpoke(m+15+n* 8,  0);
bpoke(m+n* 9,  0);bpoke(m+1+n* 9,  0);bpoke(m+2+n* 9,170);bpoke(m+3+n* 9,170);bpoke(m+4+n* 9,170);bpoke(m+5+n* 9,170);bpoke(m+6+n* 9,170);bpoke(m+7+n* 9,255);bpoke(m+8+n* 9,170);bpoke(m+9+n* 9,170);bpoke(m+10+n* 9,170);bpoke(m+11+n* 9,255);bpoke(m+12+n* 9,170);bpoke(m+13+n* 9,  0);bpoke(m+14+n* 9,  0);bpoke(m+15+n* 9,  0);
bpoke(m+n*10,  0);bpoke(m+1+n*10,170);bpoke(m+2+n*10,170);bpoke(m+3+n*10,170);bpoke(m+4+n*10,170);bpoke(m+5+n*10,170);bpoke(m+6+n*10,170);bpoke(m+7+n*10,170);bpoke(m+8+n*10,255);bpoke(m+9+n*10,170);bpoke(m+10+n*10,170);bpoke(m+11+n*10,170);bpoke(m+12+n*10,255);bpoke(m+13+n*10,  0);bpoke(m+14+n*10,  0);bpoke(m+15+n*10,170);
bpoke(m+n*11, 85);bpoke(m+1+n*11, 85);bpoke(m+2+n*11,170);bpoke(m+3+n*11,170);bpoke(m+4+n*11,170);bpoke(m+5+n*11,170);bpoke(m+6+n*11,170);bpoke(m+7+n*11,170);bpoke(m+8+n*11,255);bpoke(m+9+n*11,255);bpoke(m+10+n*11,255);bpoke(m+11+n*11,255);bpoke(m+12+n*11,255);bpoke(m+13+n*11,  0);bpoke(m+14+n*11,  0);bpoke(m+15+n*11,170);
bpoke(m+n*12, 85);bpoke(m+1+n*12, 85);bpoke(m+2+n*12, 85);bpoke(m+3+n*12,  0);bpoke(m+4+n*12,255);bpoke(m+5+n*12,255);bpoke(m+6+n*12,170);bpoke(m+7+n*12,255);bpoke(m+8+n*12,255);bpoke(m+9+n*12, 85);bpoke(m+10+n*12,255);bpoke(m+11+n*12,255);bpoke(m+12+n*11, 85);bpoke(m+13+n*12,255);bpoke(m+14+n*12,170);bpoke(m+15+n*12,170);
bpoke(m+n*13,  0);bpoke(m+1+n*13, 85);bpoke(m+2+n*13,  0);bpoke(m+3+n*13,170);bpoke(m+4+n*13,255);bpoke(m+5+n*13,255);bpoke(m+6+n*13,255);bpoke(m+7+n*13,255);bpoke(m+8+n*13,255);bpoke(m+9+n*13,255);bpoke(m+10+n*13,255);bpoke(m+11+n*13,255);bpoke(m+12+n*13,255);bpoke(m+13+n*13,255);bpoke(m+14+n*13,170);bpoke(m+15+n*13,170);
bpoke(m+n*14,  0);bpoke(m+1+n*14,  0);bpoke(m+2+n*14,170);bpoke(m+3+n*14,170);bpoke(m+4+n*14,170);bpoke(m+5+n*14,255);bpoke(m+6+n*14,255);bpoke(m+7+n*14,255);bpoke(m+8+n*14,255);bpoke(m+9+n*14,255);bpoke(m+10+n*14,255);bpoke(m+11+n*14,255);bpoke(m+12+n*14,255);bpoke(m+13+n*14,255);bpoke(m+14+n*14,170);bpoke(m+15+n*14,170);
bpoke(m+n*15,  0);bpoke(m+1+n*15,170);bpoke(m+2+n*15,170);bpoke(m+3+n*15,170);bpoke(m+4+n*15,255);bpoke(m+5+n*15,255);bpoke(m+6+n*15,255);bpoke(m+7+n*15,255);bpoke(m+8+n*15,255);bpoke(m+9+n*15,255);bpoke(m+10+n*15,  0);bpoke(m+11+n*15,  0);bpoke(m+12+n*15,  0);bpoke(m+13+n*15,  0);bpoke(m+14+n*15,  0);bpoke(m+15+n*15,  0);
bpoke(m+n*16,  0);bpoke(m+1+n*16,170);bpoke(m+2+n*16,  0);bpoke(m+3+n*16,  0);bpoke(m+4+n*16,255);bpoke(m+5+n*16,255);bpoke(m+6+n*16,255);bpoke(m+7+n*16,  0);bpoke(m+8+n*16,  0);bpoke(m+9+n*16,0)  ;bpoke(m+10+n*16,  0);bpoke(m+11+n*16,  0);bpoke(m+12+n*16,  0);bpoke(m+13+n*16,  0);bpoke(m+14+n*16,  0);bpoke(m+15+n*16,  0);
}




clear_screen(){
#asm
	ld 	hl, 0x7000
	ld 	de, 0x7001
	ld 	bc, 2048
	ld 	(hl), 0         ;set first byte to '0'
	ldir    		;copy bytes
#endasm
}


getsin( int angle)			// split coz dunno how to return 2x values in HL.
{
#asm
	ld	hl, 2
	add	hl, sp
	ld	e, (hl)			// get angle passed value (1 to 256)
	ld	hl, sin_table		// load start of table offset
	ld	d, 0
;				e = angle
	add	hl, de			// add offset + angle = new table offset
	ld	e, (hl)			// pass table value back to HL
	ld	l, e
	ld	h, 0			// clear top of hl. value is in L
	ret


sin_table:
defb 0  ,  3,  6,  9, 12, 16, 19, 22, 25, 28, 31, 34, 37, 40, 43, 46
defb 49 ,51 , 54, 57, 60, 63, 65, 68, 71, 73, 76, 78, 81, 83, 85, 88
defb 90 ,92 , 94, 96, 98,100,102,104,106,107,109,111,112,113,115,116
defb 117,118,120,121,122,122,123,124,125,125,126,126,126,127,127,127
defb 127,127,127,127,126,126,126,125,125,124,123,122,122,121,120,118
defb 117,116,115,113,112,111,109,107,106,104,102,100, 98, 96, 94, 92
defb  90, 88, 85, 83, 81, 78, 76, 73, 71, 68, 65, 63, 60, 57, 54, 51
defb  49, 46, 43, 40, 37, 34, 31, 28, 25, 22, 19, 16, 12,  9,  6,  3
defb   0,  -3,  -6, -9,-12,-16,-19,-22,-25,-28,-31,-34,-37,-40,-43,-46
defb -49,-51,-54,-57,-60,-63,-65,-68,-71,-73,-76,-78,-81,-83,-85,-88
defb -90,-92,-94,-96,-98,-100,-102,-104,-106,-107,-109,-111,-112,-113,-115,-116
defb -117,-118,-120,-121,-122,-122,-123,-124,-125,-125,-126,-126,-126,-127,-127,-127
defb -127,-127,-127,-127,-126,-126,-126,-125,-125,-124,-123,-122,-122,-121,-120,-118
defb -117,-116,-115,-113,-112,-111,-109,-107,-106,-104,-102,-100,-98,-96,-94,-92
defb -90,-88,-85,-83,-81,-78,-76,-73,-71,-68,-65,-63,-60,-57,-54,-51
defb -49,-46,-43,-40,-37,-34,-31,-28,-25,-22,-19,-16,-12,-9,-6,-3

#endasm
}


getcos( int angle)			// split coz dunno how to return 2x values in HL.
{
#asm
	ld	hl, 2
	add	hl, sp
	ld	e, (hl)			// get angle passed value (1 to 256)
	ld	hl, cosin_table		// load start of table offset
	ld	d, 0
;				e = angle
	add	hl, de			// add offset + angle = new table offset
	ld	e, (hl)			// pass table value back to HL
	ld	l, e
	ld	h, 0			// clear top of hl. value is in L
	ret

cosin_table:
defb 127,127,127,127,126,126,126,125,125,124,123,122,122,121,120,118
defb 117,116,115,113,112,111,109,107,106,104,102,100, 98, 96, 94, 92
defb  90, 88, 85, 83, 81, 78, 76, 73, 71, 68, 65, 63, 60, 57, 54, 51
defb  49, 46, 43, 40, 37, 34, 31, 28, 25, 22, 19, 16, 12,  9,  6,  3
defb   0,253,250,247,244,240,237,234,231,228,225,222,219,216,213,210
defb 207,205,202,199,196,193,191,188,185,183,180,178,175,173,171,168
defb 166,164,162,160,158,156,154,152,150,149,147,145,144,143,141,140
defb 139,138,136,135,134,134,133,132,131,131,130,130,130,129,129,129
defb 129,129,129,129,130,130,130,131,131,132,133,134,134,135,136,138
defb 139,140,141,143,144,145,147,149,150,152,154,156,158,160,162,164
defb 166,168,171,173,175,178,180,183,185,188,191,193,196,199,202,205
defb 207,210,213,216,219,222,225,228,231,234,237,240,244,247,250,253
defb   0,  3,  6,  9, 12, 16, 19, 22, 25, 28, 31, 34, 37, 40, 43, 46
defb  49, 51, 54, 57, 60, 63, 65, 68, 71, 73, 76, 78, 81, 83, 85, 88
defb  90, 92, 94, 96, 98,100,102,104,106,107,109,111,112,113,115,116
defb 117,118,120,121,122,122,123,124,125,125,126,126,126,127,127,127

#endasm
}




disp( int x1, int y1)			// Display Mario via ASM (x,y)
{
#asm	

ld	hl, 2
add	hl, sp
ld	e, (hl)
inc	hl
ld	d, (hl)
ld	(y1), de
inc	hl
ld	e, (hl)
inc	hl
ld	d, (hl)
ld	(x1), de



	ld	a, (y1)			; mul HL = H * E 
	ld	h, a
	ld	e, 32
	ld 	l, 0
	ld 	d, l
	ld 	b, 8
mult:   add  	hl, hl
        jr   	nc, noadd
        add  	hl, de
noadd:  djnz 	mult
	push	hl
	pop	bc			; bc = y*32

	ld	hl, x1
	ld	a, (hl)			; a = x

	ld	hl, 0x7000
	add	hl, bc			; hl = 0x7000 + y*32
	ld	c, a
	ld	b, 0			; bc = x
	add	hl, bc			; hl= 0x7000 + (y*32) + x

	
	push	hl
	pop	de			; de = destin screen.

	ld	hl, mario
	ld	c, 0
//line 1
//	ldi
	ldi
	ldi
	ldi
// line 2
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl

	ldi
	ldi
	ldi
	ldi
// line 3
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl
	ldi
	ldi
	ldi
	ldi
// line 4
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl
	ldi
	ldi
	ldi
	ldi
// line 5
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl
	ldi
	ldi
	ldi
	ldi
// line 6
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl
	ldi
	ldi
	ldi
	ldi

// line 7
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl
	ldi
	ldi
	ldi
	ldi
// line 8
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl
	ldi
	ldi
	ldi
	ldi

// line 9
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl
	ldi
	ldi
	ldi
	ldi
// line 10
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl
	ldi
	ldi
	ldi
	ldi
// line 11
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl
	ldi
	ldi
	ldi
	ldi
// line 12
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl
	ldi
	ldi
	ldi
	ldi
// line 13
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl
	ldi
	ldi
	ldi
	ldi
// line 14
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl
	ldi
	ldi
	ldi
	ldi
// line 15
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl
	ldi
	ldi
	ldi
	ldi

// line 16
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl
	ldi
	ldi
	ldi
	ldi


	ret

x1:	defb 0,0
y1:	defb 0,0
o:	defb 0,0
p:	defb 0,0
k:	defb 0,0
l:	defb 0,0
m:	defb 0,0
n:	defb 0,0


mariolo:								; lo res mode(0) mario. 16x16
defb 143,143,143,143,143,143,143,143,143,143,143,143,143,159,159,159
defb 143,143,143,143,143,143,191,191,191,191,191,143,143,159,159,159
defb 143,143,143,143,143,191,191,191,191,191,191,191,191,191,159,159
defb 143,143,143,143,143,175,175,175,159,159,175,159,159,175,175,175
defb 143,143,143,143,175,159,175,159,159,159,175,159,159,175,175,175
defb 143,143,143,143,175,159,175,175,159,159,159,175,159,159,159,175
defb 143,143,143,143,175,175,159,159,159,159,175,175,175,175,175,143
defb 143,143,143,143,143,143,159,159,159,159,159,159,159,175,143,143
defb 143,143,175,175,175,175,175,191,175,175,175,191,175,143,143,143
defb 143,175,175,175,175,175,175,175,191,175,175,175,191,143,143,175
defb 159,159,175,175,175,175,175,175,191,191,191,191,191,143,143,175
defb 159,159,159,143,191,191,175,191,191,159,191,191,159,191,175,175
defb 143,159,143,175,191,191,191,191,191,191,191,191,191,191,175,175
defb 143,143,175,175,175,191,191,191,191,191,191,191,191,191,175,175
defb 143,175,175,175,191,191,191,191,191,191,143,143,143,143,143,143
defb 143,175,143,143,191,191,191,143,143,143,143,143,143,143,143,143



mario:				; working
defb     0,   0,   21,    0
defb	15,  252,   21,   0
defb    63,  255,  245,   0
defb 	42,   89,  127,   0
defb	 153,   89,  106, 0 
defb	 154,   86,   86, 0
defb	 165,   90,  168, 0
defb	   5,   85,   96, 10
defb	 171,  171,  128, 42
defb	 170,  234,  194, 90
defb	 170,  255,  194, 84
defb	 251,  223,  122, 18
defb	 255,  255,  250, 10
defb	191,  255,  250,  42
defb	255,  240,    0, 32
defb	252,    0,    0, 0


//mario:		; Big Endian
defb	0,0,21,0
defb	15,0,21,252
defb	63,0,245,255
defb	42,0,127,89
defb	153,0,106,89
defb	154,0,86,86
defb	165,0,168,90
defb	165,0,168,90
defb	5,0,96,85
defb	171,10,128,171
defb	170,42,194,234
defb	170,90,194,255
defb	251,84,122,223
defb	255,18,250,255
defb	191,10,250,255
defb	255,42,0,240
defb	252,32,0,0




//mario:
defb     0,   0,   21
defb	 0,  15,  252,   21
defb	 0,  63,  255,  245
defb 	 0,  42,   89,  127
defb	 0, 153,   89,  106
defb	 0, 154,   86,   86
defb	 0, 165,   90,  168
defb	 0,   5,   85,   96
defb	10, 171,  171,  128
defb	42, 170,  234,  194
defb	90, 170,  255,  194
defb	84, 251,  223,  122
defb	18, 255,  255,  250
defb	10, 191,  255,  250
defb	42, 255,  240,    0
defb	32, 252,    0,    0







#endasm
}

rotalo(){
const int line1[]=(143,143,143,143,143,143,143,143,143,143,143,143,143,159,159,159);
const int line2[]=(143,143,143,143,143,143,191,191,191,191,191,143,143,159,159,159);
const int line3[]=(143,143,143,143,143,191,191,191,191,191,191,191,191,191,159,159);
const int line4[]=(143,143,143,143,143,175,175,175,159,159,175,159,159,175,175,175);
const int line5[]=(143,143,143,143,175,159,175,159,159,159,175,159,159,175,175,175);
const int line6[]=(143,143,143,143,175,159,175,175,159,159,159,175,159,159,159,175);
const int line7[]=(143,143,143,143,175,175,159,159,159,159,175,175,175,175,175,143);
const int line8[]=(143,143,143,143,143,143,159,159,159,159,159,159,159,175,143,143);
const int line9[]=(143,143,175,175,175,175,175,191,175,175,175,191,175,143,143,143);
const int line10[]=(143,175,175,175,175,175,175,175,191,175,175,175,191,143.143,175);
const int line11[]=(159,159,175,175,175,175,175,175,191,191,191,191,191,143,143,175);
const int line12[]=(159,159,159,143,191,191,175,191,191,159,191,191,159,191,175,175);
const int line13[]=(143,159,143,175,191,191,191,191,191,191,191,191,191,191,175,175);
const int line14[]=(143,143,175,175,175,191,191,191,191,191,191,191,191,191,175,175);
const int line15[]=(143,175,175,175,191,191,191,191,191,191,143,143,143,143,143,143);
const int line16[]=(143,175,143,143,191,191,191,143,143,143,143,143,143,143,143,143);
int	i,x,y;

	for (y=0;y++;y<16){
		bpoke(28672+000+y, line1(y));}
	for (y=0;y++;y<16){
		bpoke(28672+1*32+y, line2(y));}
	for (y=0;y++;y<16){
		bpoke(28672+2*32+y, line3(y));}
	for (y=0;y++;y<16){
		bpoke(28672+3*32+y, line4(y));}
	for (y=0;y++;y<16){
		bpoke(28672+4*32+y, line5(y));}
	for (y=0;y++;y<16){
		bpoke(28672+5*32+y, line6(y));}
	for (y=0;y++;y<16){
		bpoke(28672+6*32+y, line7(y));}
	for (y=0;y++;y<16){
		bpoke(28672+7*32+y, line8(y));}
	for (y=0;y++;y<16){
		bpoke(28672+8*32+y, line9(y));}
	for (y=0;y++;y<16){
		bpoke(28672+9*32+y, line10(y));}
	for (y=0;y++;y<16){
		bpoke(28672+10*32+y, line11(y));}
	for (y=0;y++;y<16){
		bpoke(28672+11*32+y, line12(y));}
	for (y=0;y++;y<16){
		bpoke(28672+12*32+y, line13(y));}
	for (y=0;y++;y<16){
		bpoke(28672+13*32+y, line14(y));}
	for (y=0;y++;y<16){
		bpoke(28672+14*32+y, line15(y));}
	for (y=0;y++;y<16){
		bpoke(28672+15*32+y, line16(y));}
	}




rota(){					//attempt at rotating mario.
//int angle,  m,n, c, s, zx, zy;
int angle;
float 	src_x, src_y, dest_x, dest_y;
float 	dx, dy;
float	start_x, start_y;



//          t := (degrees MOD 360) * 0.0174533; { Convert Degrees to Radians }
//          c := cos( t );
//          s := sin( t );
//          for i := 1 to x_coords[0] do begin
//              zx := (x_coords[i] - xp) * c - (y_coords[i] - yp) * s + xp;
//              zy := (y_coords[i] - yp) * c + (x_coords[i] - xp) * s + yp;
//              x_coords[i] := round( zx );
//              y_coords[i] := round( zy );



     for (angle = 0; angle < 256; angle++){
	start_x = 32;					// source image x
	start_y = 32;					// source image Y

		dx = getsin(angle) * 0.5;
		dy = getcos(angle) * 0.5;
//	dx = cos(angle);
//	dy = sin(angle);

	for (dest_y = 15;dest_y < 40; dest_y++) {
	   src_x = start_x;
           src_y = start_y;
           for (dest_x=16;dest_x< 48; dest_x++) {
//		vz_plot ( dest_x, dest_y+32, vz_point2(src_x, src_y, 3) );
//		vz_plot ( dest_x+62, dest_y+32, (point(src_x, src_y)) );
//		bpoke ( 0x7000 + (dest_y*32) + dest_x, bpeek(0x7000 + (src_x) + (32*src_y)));

//		vz_plot ( dest_x+32, dest_y+32,vz_point2(src_x+16, src_y+16) );
		vz_set ( dest_x+64, dest_y+16, vz_point2(src_x, src_y) );

            	src_x += dx;
            	src_y += dy;
           }

           start_x -= dy;
           start_y += dx;
     }
}
}



main()
{
   int     i,j,k,l,x,y,a,b,c,d,e,f,g,h, angle, m,n, s, o;
   double  t,zx,zy;
int g_col;
int 	src_x, src_y, dest_x, dest_y;

   vz_setbase(0x7000);
   k = 1;
   l = 1;
   clg();
   vz_mode(1);
	#asm
	di
	#endasm

//  	while(k==1){
//		rotalo();
//	}





   i=0;j=0;
//	display_old();


	disp(3, 0);
	disp(7, 0);
	disp(11, 0);
	disp(15, 0);
	disp(19, 0);
	disp(23, 0);
	disp(27, 0);

	disp(3, 16);
	disp(7, 16);
	disp(11, 16);
	disp(15, 16);
	disp(19, 16);
	disp(23, 16);
	disp(27, 16);

	disp(3, 32);
	disp(7, 32);
	disp(11, 32);
	disp(15, 32);
	disp(19, 32);
	disp(23, 32);
	disp(27, 32);

//piccy();

here:

   	while (l==1)   {
		rota ();			// rotate MARIO image


//	for (i=0;i<360;i++) {
//		x=cos(i      *6)*12;  
//		y=sin(i      *6)*8;  
//		a=cos((i+240)*6)*12;  
//		b=sin((i+240)*6)*8; 
//		c=cos((i+120)*6)*12;  
//		d=sin((i+120)*6)*8; 
//
//		vz_line (x+96, y+16, a+96, b+16,1);
//		vz_line (x+96, y+16,  c+96, d+16, vz_point2(x+32,y+16));
//	}
}
}



//####################################################################################


//    procedure rotate2d( var x_coords, y_coords  :  coord_vals;
//                            xp, yp, degrees     :  integer  );
//       var i                :  integer;
//           t, c, s, zx, zy  :  real;
//       begin
//          t := (degrees MOD 360) * 0.0174533; { Convert Degrees to Radians }
//          c := cos( t );
//          s := sin( t );
//          for i := 1 to x_coords[0] do begin
//              zx := (x_coords[i] - xp) * c - (y_coords[i] - yp) * s + xp;
//              zy := (y_coords[i] - yp) * c + (x_coords[i] - xp) * s + yp;
//              x_coords[i] := round( zx );
//              y_coords[i] := round( zy );
//          end;
//       end;



//   vz_plot (0,0,3);   vz_plot (1,0,1);   vz_plot (1,0,1);   vz_plot (1,0,3);
//   vz_plot (127,0,3);vz_plot (0,63,3);vz_plot (127,63,3);
//   vz_plot (0,0,1);   vz_plot (1,0,1);   vz_plot (2,0,0);   vz_plot (3,0,3); vz_set (4,0,3);
//   vz_plot (0,2,1);   vz_plot (1,2,0);   vz_plot (2,2,0);   vz_set (3,2,1);
//   vz_set (0,4,0);   vz_set (1,4,0);   vz_set (2,4,3);   vz_set (3,4,0);
// a=   vz_point2(0,0);
// b=   vz_point2(1,0);
// c =  vz_point2(2,0);
// d =  vz_point2(3,0);
// e=   vz_point2(0,2);
// f=   vz_point2(1,2);
// g =  vz_point2(2,2);
// h =  vz_point2(3,2);
// i=   vz_point2(0,4);
// j=   vz_point2(1,4);
// l =  vz_point2(2,4);
// m =  vz_point2(3,4);
// n =  vz_point2(4,0); 
//   vz_mode(0);
//	printf("a = %d\n" ,   a );
//	printf("b = %d\n" ,   b );
//	printf("c = %d\n" ,   c );
//	printf("d = %d\n" ,   d );
//	printf("e = %d\n" ,   e );
//	printf("f = %d\n" ,   f );
//	printf("g = %d\n" ,   g );
//	printf("h = %d\n" ,   h );
//	printf("i = %d\n" ,   i );
//	printf("j = %d\n" ,   j );
//	printf("l = %d\n" ,   l );
//	printf("m = %d\n" ,   m );
//	printf("n = %d\n" ,   n );
//  	while(k==1){;}
//



/*
;-----------------------------------------------------------------------------
; Sinus/Cosinus tables in the range -127..+127 for angles 0..255.
;-----------------------------------------------------------------------------


sin1:
  db   0,  3,  6,  9, 12, 16, 19, 22, 25, 28, 31, 34, 37, 40, 43, 46
  db  49, 51, 54, 57, 60, 63, 65, 68, 71, 73, 76, 78, 81, 83, 85, 88
  db  90, 92, 94, 96, 98,100,102,104,106,107,109,111,112,113,115,116
  db 117,118,120,121,122,122,123,124,125,125,126,126,126,127,127,127
cos1:
  db 127,127,127,127,126,126,126,125,125,124,123,122,122,121,120,118
  db 117,116,115,113,112,111,109,107,106,104,102,100, 98, 96, 94, 92
  db  90, 88, 85, 83, 81, 78, 76, 73, 71, 68, 65, 63, 60, 57, 54, 51
  db  49, 46, 43, 40, 37, 34, 31, 28, 25, 22, 19, 16, 12,  9,  6,  3
  db   0,253,250,247,244,240,237,234,231,228,225,222,219,216,213,210
  db 207,205,202,199,196,193,191,188,185,183,180,178,175,173,171,168
  db 166,164,162,160,158,156,154,152,150,149,147,145,144,143,141,140
  db 139,138,136,135,134,134,133,132,131,131,130,130,130,129,129,129
  db 129,129,129,129,130,130,130,131,131,132,133,134,134,135,136,138
  db 139,140,141,143,144,145,147,149,150,152,154,156,158,160,162,164
  db 166,168,171,173,175,178,180,183,185,188,191,193,196,199,202,205
  db 207,210,213,216,219,222,225,228,231,234,237,240,244,247,250,253
  db   0,  3,  6,  9, 12, 16, 19, 22, 25, 28, 31, 34, 37, 40, 43, 46
  db  49, 51, 54, 57, 60, 63, 65, 68, 71, 73, 76, 78, 81, 83, 85, 88
  db  90, 92, 94, 96, 98,100,102,104,106,107,109,111,112,113,115,116
  db 117,118,120,121,122,122,123,124,125,125,126,126,126,127,127,127

sin2:
        dw   0,6,13,19,25,31,38,44,50,56  
        dw   62,69,75,81,87,92,98,104,110,116  
        dw   121,127,132,137,143,148,153,158,163,168  
        dw   172,177,182,186,190,194,198,202,206,210  
        dw   213,217,220,223,226,229,232,235,237,239  
        dw   241,243,245,247,249,250,251,252,253,254  
        dw   255,255,256,256        ;64 vlaues

cos2:   dw   256,256,256,255,255,254
        dw   253,252,251,249,248,246,244,242,240,238  
        dw   236,233,231,228,225,222,218,215,212,208  
        dw   204,200,196,192,188,184,179,175,170,165  
        dw   160,156,150,145,140,135,129,124,118,113  
        dw   107,101,95,90,84,78,72,65,59,53  
        dw   47,41,35,28,22,16,9,3,0 ,-4 ,-10  
        dw  -16 ,-23 ,-29 ,-35 ,-41 ,-48 ,-54 ,-60 ,-66 ,-72  
        dw  -78 ,-84 ,-90 ,-96 ,-102 ,-107 ,-113 ,-119 ,-124 ,-130  
        dw  -135 ,-141 ,-146 ,-151 ,-156 ,-161 ,-166 ,-171 ,-175 ,-180  
        dw  -184 ,-189 ,-193 ,-197 ,-201 ,-205 ,-209 ,-212 ,-216 ,-219  
        dw  -222 ,-225 ,-228 ,-231 ,-234 ,-236 ,-239 ,-241 ,-243 ,-245  
        dw  -247 ,-248 ,-250 ,-251 ,-252 ,-253 ,-254 ,-255 ,-256 ,-256  
        dw  -256 ,-256 ,-256 ,-256 ,-256 ,-255 ,-255 ,-254 ,-253 ,-252  
        dw  -251 ,-249 ,-248 ,-246 ,-244 ,-242 ,-240 ,-237 ,-235 ,-232  
        dw  -230 ,-227 ,-224 ,-221 ,-217 ,-214 ,-210 ,-207 ,-203 ,-199  
        dw  -195 ,-191 ,-186 ,-182 ,-178 ,-173 ,-168 ,-163 ,-159 ,-154  
        dw  -148 ,-143 ,-138 ,-133 ,-127 ,-122 ,-116 ,-110 ,-105 ,-99  
        dw  -93 ,-87 ,-81 ,-75 ,-69 ,-63 ,-57 ,-51 ,-44 ,-38  
        dw  -32 ,-26 ,-19 ,-13 ,-7
        dw   0,6,13,19,25,31,38,44,50,56  
        dw   62,69,75,81,87,92,98,104,110,116  
        dw   121,127,132,137,143,148,153,158,163,168  
        dw   172,177,182,186,190,194,198,202,206,210  
        dw   213,217,220,223,226,229,232,235,237,239  
        dw   241,243,245,247,249,250,251,252,253,254  
        dw   255,255,256,256

;-----------------------------------------------------------------------------
; Sinus/Cosinus tables in the range -64..+64 for angles 0..255.
;-----------------------------------------------------------------------------

sin3:
  db    0,  2,  3,  5,  6,  8,  9, 11, 12, 14, 16, 17, 19, 20, 22, 23
  db   24, 26, 27, 29, 30, 32, 33, 34, 36, 37, 38, 39, 41, 42, 43, 44
  db   45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 56, 57, 58, 59
  db   59, 60, 60, 61, 61, 62, 62, 62, 63, 63, 63, 64, 64, 64, 64, 64

Cos3:
  db   64, 64, 64, 64, 64, 64, 63, 63, 63, 62, 62, 62, 61, 61, 60, 60
  db   59, 59, 58, 57, 56, 56, 55, 54, 53, 52, 51, 50, 49, 48, 47, 46
  db   45, 44, 43, 42, 41, 39, 38, 37, 36, 34, 33, 32, 30, 29, 27, 26
  db   24, 23, 22, 20, 19, 17, 16, 14, 12, 11,  9,  8,  6,  5,  3,  2
  db    0,254,253,251,250,248,247,245,244,242,240,239,237,236,234,233
  db  232,230,229,227,226,224,223,222,220,219,218,217,215,214,213,212
  db  211,210,209,208,207,206,205,204,203,202,201,200,200,199,198,197
  db  197,196,196,195,195,194,194,194,193,193,193,192,192,192,192,192
  db  192,192,192,192,192,192,193,193,193,194,194,194,195,195,196,196
  db  197,197,198,199,200,200,201,202,203,204,205,206,207,208,209,210
  db  211,212,213,214,215,217,218,219,220,222,223,224,226,227,229,230
  db  232,233,234,236,237,239,240,242,244,245,247,248,250,251,253,254
  db    0,  2,  3,  5,  6,  8,  9, 11, 12, 14, 16, 17, 19, 20, 22, 23
  db   24, 26, 27, 29, 30, 32, 33, 34, 36, 37, 38, 39, 41, 42, 43, 44
  db   45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 56, 57, 58, 59
  db   59, 60, 60, 61, 61, 62, 62, 62, 63, 63, 63, 64, 64, 64, 64, 64



*/