// R10 - think R10 is working set
// R10A - is with MARIO64x64
//
// - rotates
// - VZ_SET2   : Plotting to 0XE000h
// - has Z axis. zooms in and out.
//



 #include <vz.h>
 #include <graphics.h>
 #include <stdio.h>
// #include <sound.h>
 #include <stdlib.h>
// #include <ctype.h>
 #include <strings.h>
 #include <conio.h>
 #include <math.h>
// #include <zxlowgfx.h>
// #include <spectrum.h>
// #include <zx81.h>
// #include <aquarius.h>


 #define PI = 3.1415926535

int x1, y1, i, j;
//int g_col;



int vz_set(int x, int y, int c)		// ----- graphics mode set pixel at x=L, y=H color C
{
   #asm
pset4:  
	ld	hl, 2
	add	hl, sp

	ld	c, (hl)			// colour
	inc	hl
	inc	hl
	ld	e, (hl)			// Y value	e = y.
	inc	hl
	inc	hl
	ld	l, (hl)			// x value      l = x.
	ld	h, e			// y value      h = y.

        ld      a, l            ; get x
        sla     l               ; calculate screen offset
        srl     h
        rr      l
        srl     h
        rr      l
        srl     h
        rr      l
        and     #3              ; pixel offset
        inc     a
        ld      b, #0b11111100
pset3:  rrc     b
        rrc     b
        rrc     c
        rrc     c
        dec     a
        jr      nz, pset3
	ld	de, 0x7000
	add	hl, de
        ld      a, (hl)
        and     b
        or      c
        ld      (hl), a
	 ret
   #endasm
}


int vz_set2(int x, int y, int c)		// ----- graphics mode set pixel at x=L, y=H color C
{
   #asm
pset0:  
	ld	hl, 2
	add	hl, sp

	ld	c, (hl)			// colour
	inc	hl
	inc	hl
	ld	e, (hl)			// Y value	e = y.
	inc	hl
	inc	hl
	ld	l, (hl)			// x value      l = x.
	ld	h, e			// y value      h = y.

        ld      a, l            ; get x
        sla     l               ; calculate screen offset
        srl     h
        rr      l
        srl     h
        rr      l
        srl     h
        rr      l
        and     #3              ; pixel offset
        inc     a
        ld      b, #0b11111100
pset1:  rrc     b
        rrc     b
        rrc     c
        rrc     c
        dec     a
        jr      nz, pset1
	ld	de, 0x7000			// was 0xe000
	add	hl, de
        ld      a, (hl)
        and     b
        or      c
        ld      (hl), a
	 ret
   #endasm
}





int vz_point2(int x, int y)		// ROM CALL
{
   #asm
	ld	hl, 2
	add	hl, sp
	ld	e, (hl)			// Y value	e = y.
	inc	hl
	inc	hl
	ld	l, (hl)			// x value      l = x.
	ld	h, e			// y value      h = y.
        ld      c, l            ; get x

	ld	e, h		; e = y
	xor	a
	ld	d, a
	ex	de, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ex	de, hl
	ld	a, c		//restore x
	srl	a
	srl	a
	add	a,e
	ld	e,a
	ld	a,d
	or	70h
	ld	d, a
	ld	a, c		//restore x
	and	3	
	add	a,a
	ld	b,a
	ld	c, 0c0h
aset:	rrc	c
	djnz	aset
	ld	a, (de)
	and	c
	ld	b, a
	ld	a, c
bset:	rrc	b
	rrc	a
	cp	3
	jr	nz,bset
	ld	h, 0
	ld	l, b

;	ld	l, a


   #endasm
}


int vz_point(int x, int y)		// ROM CALL
{
   #asm
	ld	hl, 2
	add	hl, sp
	ld	e, (hl)			// Y value	e = y.
	inc	hl
	inc	hl
	ld	l, (hl)			// x value      l = x.
	ld	h, e			// y value      h = y.
        ld      c, l            ; get x

	ld	e, h		; e = y
	xor	a
	ld	d, a
	ex	de, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ex	de, hl
	ld	a, c		//restore x
	srl	a
	srl	a
	add	a,e
	ld	e,a
	ld	a,d
	or	232 		// 208=D0.  232=0xe8  240=0xe500
	ld	d, a
	ld	a, c		//restore x
	and	3	
	add	a,a
	ld	b,a
	ld	c, 0c0h
asetc:	rrc	c
	djnz	asetc
	ld	a, (de)
	and	c
	ld	b, a
	ld	a, c
bsetc:	rrc	b
	rrc	a
	cp	3
	jr	nz,bsetc
	ld	h, 0
	ld	l, b

;	ld	l, a


   #endasm
}




disp()			// Display Mario via ASM (x,y)
{
#asm	


	
disp1:	

					// 	ldir	Repeats LDI (LD (DE),(HL), then increments DE, HL, and decrements BC) until BC=0. 
					//	Note that if BC=0 before this instruction is called, it will loop around until BC=0 again.

					//	ldi	Performs a "LD (DE),(HL)", then increments DE and HL, and decrements BC.
	ld	bc, 16
	ld	de, 0x7000
	ld	hl, mario64
disp2:	push	bc
	push	hl
	push	hl
	push	hl
	ld	bc, 16
	ldir			// line 1
	pop	hl
	ld	bc, 16
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	ldir			// line 2
	pop	hl
	ld	bc, 16
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	ldir			// line 3
	pop	hl
	ld	bc, 16
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	ldir			// line 4
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	inc	de
	pop	bc
	djnz	disp2

	ret




mario64:
defb 0,0,0,0,0,0,0,0,0,0,0,0,0,85,85,85
defb 0,0,0,0,0,0,255,255,255,255,255,0,0,85,85,85
defb 0,0,0,0,0,255,255,255,255,255,255,255,255,255,85,85
defb 0,0,0,0,0,170,170,170,85,85,170,85,85,170,170,170
defb 0,0,0,0,170,85,170,85,85,85,170,85,85,170,170,170
defb 0,0,0,0,170,85,170,170,85,85,85,170,85,85,85,170
defb 0,0,0,0,170,170,85,85,85,85,170,170,170,170,170,0
defb 0,0,0,0,0,0,85,85,85,85,85,85,85,170,0,0
defb 0,0,170,170,170,170,170,255,170,170,170,255,170,0,0,0
defb 0,170,170,170,170,170,170,170,255,170,170,170,255,0,0,170
defb 85,85,170,170,170,170,170,170,255,255,255,255,255,0,0,170
defb 85,85,85,0,255,255,170,255,255,85,255,255,85,255,170,170
defb 0,85,0,170,255,255,255,255,255,255,255,255,255,255,170,170
defb 0,0,170,170,170,255,255,255,255,255,255,255,255,255,170,170
defb 0,170,170,170,255,255,255,255,255,255,0,0,0,0,0,0
defb 0,170,0,0,255,255,255,0,0,0,0,0,0,0,0,0



#endasm
}





screentobuffer()
{
	#asm
		ld 	de, 0x7000
		ld	hl, 0xe000
		ld	bc, 2048
		ldir
		ret
	#endasm
}


buffertoscreen()
{
	#asm
		ld 	hl, 0x7000
		ld	de, 0xe000
		ld	bc, 2048
		ldir
		ret
	#endasm
}


clear_screen()
{
#asm
	ld 	hl, 0x7000
	ld 	de, 0x7001
	ld 	bc, 2048
	ld 	(hl), 0         ;set first byte to '0'
	ldir    		;copy bytes
	ret
#endasm
}




main()
{
   int     i,j,k,l,x,y,a,b,c,d,e,f,g,h, m,n, s, o;

//int 	src_x, src_y, dest_x, dest_y;

float angle;
float 	src_x, src_y;
int dest_x, dest_y;
float 	dx, dy;
float	start_x, start_y;
//float	z,y;

//float sinv, cosv;


//sinv[128]=(1.000000, 0.998750, 0.995004, 0.988771, 0.980067, 0.968912, 0.955337, 0.939373, 0.921061, 0.900447);

/*
0.877583, 0.852524, 0.825336, 0.796084, 0.764842, 0.731689, 0.696707, 0.659983, 0.621610, 0.581683, 
0.540302, 0.497571, 0.453596, 0.408487, 0.362358, 0.315322, 0.267499, 0.219007, 0.169967, 0.120503, 
0.070738, 0.020795, -0.029199, -0.079120, -0.128844, -0.178245, -0.227201, -0.275590, -0.323289, -0.370180, 
-0.416146, -0.461072, -0.504845, -0.547357, -0.588500, -0.628173, -0.666275, -0.702712, -0.737393, -0.770231, 
-0.801143, -0.830053, -0.856888, -0.881582, -0.904072, -0.924302, -0.942222, -0.957787, -0.970958, -0.981702, 
-0.989992, -0.995808, -0.999135, -0.999965, -0.998295, -0.994130, -0.987480, -0.978362, -0.966799, -0.952819, 
-0.936457, -0.917755, -0.896759, -0.873522, -0.848101, -0.820561, -0.790969, -0.759401, -0.725934, -0.690653, 
-0.653646, -0.615004, -0.574826, -0.533211, -0.490263, -0.446089, -0.400801, -0.354510, -0.307334, -0.259390, 
-0.210797, -0.161677, -0.112153, -0.062349, -0.012389, 0.037602, 0.087499, 0.137177, 0.186513, 0.235382, 
0.283663, 0.331235, 0.377979, 0.423778, 0.468518, 0.512087, 0.554376, 0.595279, 0.634695, 0.672524, 0.708672, 
0.743048, 0.775568, 0.806149, 0.834715, 0.861194, 0.885521, 0.907635, 0.927480, 0.945007, 0.960172, 0.972936, 
0.983269, 0.991145, 0.996543, 0.999450, 0.999859, 0.997768, 0.993184);

cosv[128]=(0.000000, 0.049979, 0.099833, 0.149438, 0.198669, 0.247404, 0.295520, 0.342898, 0.389418, 0.434966, 
0.479426, 0.522687, 0.564643, 0.605186, 0.644218, 0.681639, 0.717356, 0.751280, 0.783327, 0.813416, 
0.841471, 0.867423, 0.891207, 0.912764, 0.932039, 0.948985, 0.963558, 0.975723, 0.985450, 0.992713, 
0.997495, 0.999784, 0.999574, 0.996865, 0.991665, 0.983986, 0.973848, 0.961275, 0.946300, 0.928960, 
0.909298, 0.887363, 0.863210, 0.836899, 0.808497, 0.778074, 0.745706, 0.711474, 0.675464, 0.637766, 
0.598473, 0.557685, 0.515502, 0.472032, 0.427381, 0.381662, 0.334990, 0.287479, 0.239251, 0.190424, 
0.141122, 0.091466, 0.041582, -0.008405, -0.058372, -0.108193, -0.157744, -0.206900, -0.255539, -0.303540, 
-0.350781, -0.397146, -0.442518, -0.486785, -0.529834, -0.571559, -0.611856, -0.650623, -0.687764, -0.723186, 
-0.756801, -0.788524, -0.818276, -0.845982, -0.871575, -0.894989, -0.916165, -0.935052, -0.951602, -0.965773, 
-0.977530, -0.986844, -0.993691, -0.998054, -0.999923, -0.999293, -0.996165, -0.990546, -0.982453, -0.971903, 
-0.958924, -0.943548, -0.925814, -0.905766, -0.883454, -0.858934, -0.832266, -0.803519, -0.772763, -0.740076, 
-0.705538, -0.669238, -0.631264, -0.591713, -0.550683, -0.508276, -0.464599, -0.419760, -0.373873, -0.327050, 
-0.279411, -0.231073, -0.182157, -0.132787, -0.083084, -0.033173, 0.016820, 0.066771, 0.116555);

*/



   vz_setbase(0x7000);
 j=0;
   k = 1;
   l = 1;
   clg();
   vz_mode(1);
	#asm
	di
	#endasm
   i=0;j=0;

	disp();

	vz_plot(0,0,3);vz_plot(0,63,3);vz_plot(127,63,3);vz_plot(127,0,3);


//	screentobuffer();

	memcpy (0xe000, 0x7000, 2048);
	memcpy (0xe800, 0x7000, 2048);

dx=0;dy=0;
   vz_setbase(0x7000);


//   	while (j==0)   {}


   	while (l==1)   {


//z=1;y=0;

	vz_plot(0,0,1);vz_plot(0,63,1);vz_plot(127,63,1);vz_plot(127,0,1);

//          t := (degrees MOD 360) * 0.0174533; { Convert Degrees to Radians }
//          c := cos( t );
//          s := sin( t );
//          for i := 1 to x_coords[0] do begin
//              zx := (x_coords[i] - xp) * c - (y_coords[i] - yp) * s + xp;
//              zy := (y_coords[i] - yp) * c + (x_coords[i] - xp) * s + yp;
//              x_coords[i] := round( zx );
//              y_coords[i] := round( zy );

     for ( angle = 0; angle < 6.35; angle = angle + 0.05 ){
	start_x = 0;					// source image x
	start_y = 0;					// source image Y

	dx = cos(angle);
	dy = sin(angle);




//	if (y=0) z=z+.2;
//	if (y=1) z=z-.2;
//	if (z>2.1) y=1;
//	if (z<0.3) y=0;
	

	for (dest_y = 0;dest_y < 64; dest_y++) {
	   src_x = start_x;
           src_y = start_y;
//           for (dest_x=16;dest_x< 48; dest_x=dest_x+4) {
//           for (dest_x=16;dest_x< 48; dest_x++) {
//		vz_plot ( dest_x, dest_y+32, vz_point2(src_x, src_y, 3) );
//		vz_plot ( dest_x+62, dest_y+32, (point(src_x, src_y)) );
//		bpoke ( 0x7000 + (dest_y*32) + dest_x, bpeek(0x7000 + (src_x) + (32*src_y)));
//		vz_plot ( dest_x+72, dest_y+23,vz_point2(src_x, src_y) );


vz_plot (120,dest_y,2);

//goto here


 		vz_set2 ( 0, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 1, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 2, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 0+3, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 0+4, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 5, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 6, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 7, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 8, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 9, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;

 		vz_set2 ( 10, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 11, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 12, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 13, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 14, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 15, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 16, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 17, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 18, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 19, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;


here:
 		vz_set2 ( 20, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 21, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 22, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 23, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 24, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 25, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 26, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 27, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 28, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 29, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 30, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 31, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 32, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 33, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 34, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 35, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 36, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 37, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 38, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 39, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 40, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 41, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 42, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 43, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 44, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 45, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 46, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 47, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 48, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 49, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;

 		vz_set2 ( 50, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 51, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 52, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 53, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 54, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 55, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 56, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 57, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 58, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 59, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 60, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 61, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 62, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 63, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 64, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 65, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 66, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 67, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 68, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 69, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 70, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 71, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 72, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 73, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 74, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 75, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 76, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 77, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 78, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 79, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 80, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 81, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 82, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 83, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 84, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 85, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 86, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 87, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 88, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 89, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 90, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 91, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 92, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 93, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 94, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 95, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 96, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 97, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 98, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 99, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 100, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 101, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 102, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 103, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 104, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 105, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 106, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 107, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 108, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 109, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 110, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 111, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 112, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 113, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 114, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 115, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 116, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 117, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 118, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 119, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 120, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 121, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 122, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 123, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 124, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 125, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 126, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;
 		vz_set2 ( 127, dest_y, vz_point(src_x, src_y) );
            	src_x += dx;
            	src_y += dy;

           start_x -= dy;
           start_y += dx;
        } 				//end: For Y

//	memcpy (0x7000, 0xe000, 2048);
}





// #############################3333333333333333333333333333333333333333333
}
}



//####################################################################################


//    procedure rotate2d( var x_coords, y_coords  :  coord_vals;
//                            xp, yp, degrees     :  integer  );
//       var i                :  integer;
//           t, c, s, zx, zy  :  real;
//       begin
//          t := (degrees MOD 360) * 0.0174533; { Convert Degrees to Radians }
//          c := cos( t );
//          s := sin( t );
//          for i := 1 to x_coords[0] do begin
//              zx := (x_coords[i] - xp) * c - (y_coords[i] - yp) * s + xp;
//              zy := (y_coords[i] - yp) * c + (x_coords[i] - xp) * s + yp;
//              x_coords[i] := round( zx );
//              y_coords[i] := round( zy );
//          end;
//       end;



//   vz_plot (0,0,3);   vz_plot (1,0,1);   vz_plot (1,0,1);   vz_plot (1,0,3);
//   vz_plot (127,0,3);vz_plot (0,63,3);vz_plot (127,63,3);
//   vz_plot (0,0,1);   vz_plot (1,0,1);   vz_plot (2,0,0);   vz_plot (3,0,3); vz_set (4,0,3);
//   vz_plot (0,2,1);   vz_plot (1,2,0);   vz_plot (2,2,0);   vz_set (3,2,1);
//   vz_set (0,4,0);   vz_set (1,4,0);   vz_set (2,4,3);   vz_set (3,4,0);
// a=   vz_point2(0,0);
// b=   vz_point2(1,0);
// c =  vz_point2(2,0);
// d =  vz_point2(3,0);
// e=   vz_point2(0,2);
// f=   vz_point2(1,2);
// g =  vz_point2(2,2);
// h =  vz_point2(3,2);
// i=   vz_point2(0,4);
// j=   vz_point2(1,4);
// l =  vz_point2(2,4);
// m =  vz_point2(3,4);
// n =  vz_point2(4,0); 
//   vz_mode(0);
//	printf("a = %d\n" ,   a );
//	printf("b = %d\n" ,   b );
//	printf("c = %d\n" ,   c );
//	printf("d = %d\n" ,   d );
//	printf("e = %d\n" ,   e );
//	printf("f = %d\n" ,   f );
//	printf("g = %d\n" ,   g );
//	printf("h = %d\n" ,   h );
//	printf("i = %d\n" ,   i );
//	printf("j = %d\n" ,   j );
//	printf("l = %d\n" ,   l );
//	printf("m = %d\n" ,   m );
//	printf("n = %d\n" ,   n );
//  	while(k==1){;}
//



/*
;-----------------------------------------------------------------------------
; Sinus/Cosinus tables in the range -127..+127 for angles 0..255.
;-----------------------------------------------------------------------------


sin1:
  db   0,  3,  6,  9, 12, 16, 19, 22, 25, 28, 31, 34, 37, 40, 43, 46
  db  49, 51, 54, 57, 60, 63, 65, 68, 71, 73, 76, 78, 81, 83, 85, 88
  db  90, 92, 94, 96, 98,100,102,104,106,107,109,111,112,113,115,116
  db 117,118,120,121,122,122,123,124,125,125,126,126,126,127,127,127
cos1:
  db 127,127,127,127,126,126,126,125,125,124,123,122,122,121,120,118
  db 117,116,115,113,112,111,109,107,106,104,102,100, 98, 96, 94, 92
  db  90, 88, 85, 83, 81, 78, 76, 73, 71, 68, 65, 63, 60, 57, 54, 51
  db  49, 46, 43, 40, 37, 34, 31, 28, 25, 22, 19, 16, 12,  9,  6,  3
  db   0,253,250,247,244,240,237,234,231,228,225,222,219,216,213,210
  db 207,205,202,199,196,193,191,188,185,183,180,178,175,173,171,168
  db 166,164,162,160,158,156,154,152,150,149,147,145,144,143,141,140
  db 139,138,136,135,134,134,133,132,131,131,130,130,130,129,129,129
  db 129,129,129,129,130,130,130,131,131,132,133,134,134,135,136,138
  db 139,140,141,143,144,145,147,149,150,152,154,156,158,160,162,164
  db 166,168,171,173,175,178,180,183,185,188,191,193,196,199,202,205
  db 207,210,213,216,219,222,225,228,231,234,237,240,244,247,250,253
  db   0,  3,  6,  9, 12, 16, 19, 22, 25, 28, 31, 34, 37, 40, 43, 46
  db  49, 51, 54, 57, 60, 63, 65, 68, 71, 73, 76, 78, 81, 83, 85, 88
  db  90, 92, 94, 96, 98,100,102,104,106,107,109,111,112,113,115,116
  db 117,118,120,121,122,122,123,124,125,125,126,126,126,127,127,127

sin2:
        dw   0,6,13,19,25,31,38,44,50,56  
        dw   62,69,75,81,87,92,98,104,110,116  
        dw   121,127,132,137,143,148,153,158,163,168  
        dw   172,177,182,186,190,194,198,202,206,210  
        dw   213,217,220,223,226,229,232,235,237,239  
        dw   241,243,245,247,249,250,251,252,253,254  
        dw   255,255,256,256        ;64 vlaues

cos2:   dw   256,256,256,255,255,254
        dw   253,252,251,249,248,246,244,242,240,238  
        dw   236,233,231,228,225,222,218,215,212,208  
        dw   204,200,196,192,188,184,179,175,170,165  
        dw   160,156,150,145,140,135,129,124,118,113  
        dw   107,101,95,90,84,78,72,65,59,53  
        dw   47,41,35,28,22,16,9,3,0 ,-4 ,-10  
        dw  -16 ,-23 ,-29 ,-35 ,-41 ,-48 ,-54 ,-60 ,-66 ,-72  
        dw  -78 ,-84 ,-90 ,-96 ,-102 ,-107 ,-113 ,-119 ,-124 ,-130  
        dw  -135 ,-141 ,-146 ,-151 ,-156 ,-161 ,-166 ,-171 ,-175 ,-180  
        dw  -184 ,-189 ,-193 ,-197 ,-201 ,-205 ,-209 ,-212 ,-216 ,-219  
        dw  -222 ,-225 ,-228 ,-231 ,-234 ,-236 ,-239 ,-241 ,-243 ,-245  
        dw  -247 ,-248 ,-250 ,-251 ,-252 ,-253 ,-254 ,-255 ,-256 ,-256  
        dw  -256 ,-256 ,-256 ,-256 ,-256 ,-255 ,-255 ,-254 ,-253 ,-252  
        dw  -251 ,-249 ,-248 ,-246 ,-244 ,-242 ,-240 ,-237 ,-235 ,-232  
        dw  -230 ,-227 ,-224 ,-221 ,-217 ,-214 ,-210 ,-207 ,-203 ,-199  
        dw  -195 ,-191 ,-186 ,-182 ,-178 ,-173 ,-168 ,-163 ,-159 ,-154  
        dw  -148 ,-143 ,-138 ,-133 ,-127 ,-122 ,-116 ,-110 ,-105 ,-99  
        dw  -93 ,-87 ,-81 ,-75 ,-69 ,-63 ,-57 ,-51 ,-44 ,-38  
        dw  -32 ,-26 ,-19 ,-13 ,-7
        dw   0,6,13,19,25,31,38,44,50,56  
        dw   62,69,75,81,87,92,98,104,110,116  
        dw   121,127,132,137,143,148,153,158,163,168  
        dw   172,177,182,186,190,194,198,202,206,210  
        dw   213,217,220,223,226,229,232,235,237,239  
        dw   241,243,245,247,249,250,251,252,253,254  
        dw   255,255,256,256

;-----------------------------------------------------------------------------
; Sinus/Cosinus tables in the range -64..+64 for angles 0..255.
;-----------------------------------------------------------------------------

sin3:
  db    0,  2,  3,  5,  6,  8,  9, 11, 12, 14, 16, 17, 19, 20, 22, 23
  db   24, 26, 27, 29, 30, 32, 33, 34, 36, 37, 38, 39, 41, 42, 43, 44
  db   45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 56, 57, 58, 59
  db   59, 60, 60, 61, 61, 62, 62, 62, 63, 63, 63, 64, 64, 64, 64, 64

Cos3:
  db   64, 64, 64, 64, 64, 64, 63, 63, 63, 62, 62, 62, 61, 61, 60, 60
  db   59, 59, 58, 57, 56, 56, 55, 54, 53, 52, 51, 50, 49, 48, 47, 46
  db   45, 44, 43, 42, 41, 39, 38, 37, 36, 34, 33, 32, 30, 29, 27, 26
  db   24, 23, 22, 20, 19, 17, 16, 14, 12, 11,  9,  8,  6,  5,  3,  2
  db    0,254,253,251,250,248,247,245,244,242,240,239,237,236,234,233
  db  232,230,229,227,226,224,223,222,220,219,218,217,215,214,213,212
  db  211,210,209,208,207,206,205,204,203,202,201,200,200,199,198,197
  db  197,196,196,195,195,194,194,194,193,193,193,192,192,192,192,192
  db  192,192,192,192,192,192,193,193,193,194,194,194,195,195,196,196
  db  197,197,198,199,200,200,201,202,203,204,205,206,207,208,209,210
  db  211,212,213,214,215,217,218,219,220,222,223,224,226,227,229,230
  db  232,233,234,236,237,239,240,242,244,245,247,248,250,251,253,254
  db    0,  2,  3,  5,  6,  8,  9, 11, 12, 14, 16, 17, 19, 20, 22, 23
  db   24, 26, 27, 29, 30, 32, 33, 34, 36, 37, 38, 39, 41, 42, 43, 44
  db   45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 56, 57, 58, 59
  db   59, 60, 60, 61, 61, 62, 62, 62, 63, 63, 63, 64, 64, 64, 64, 64




*/