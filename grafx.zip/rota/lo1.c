//  NEED to get POINT() working (returns true/false, which is 1 (yellow) or 0 (green)
// OR VZ_point working properly
//

 #include <vz.h>
 #include <graphics.h>
 #include <stdio.h>
 #include <sound.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <strings.h>
 #include <conio.h>
 #include <math.h>
 #include <zxlowgfx.h>
 #include <spectrum.h>
// #include <zx81.h>
// #include <aquarius.h>


 #define PI = 3.1415926535

int x1, y1, i, j;
//int g_col;



int vz_set(int x, int y, int c)		// ----- graphics mode set pixel at x=L, y=H color C
{
   #asm
pset4:  
	ld	hl, 2
	add	hl, sp

	ld	c, (hl)			// colour
	inc	hl
	inc	hl
	ld	e, (hl)			// Y value	e = y.
	inc	hl
	inc	hl
	ld	l, (hl)			// x value      l = x.
	ld	h, e			// y value      h = y.

        ld      a, l            ; get x
        sla     l               ; calculate screen offset
        srl     h
        rr      l
        srl     h
        rr      l
        srl     h
        rr      l
        and     #3              ; pixel offset
        inc     a
        ld      b, #0b11111100
pset3:  rrc     b
        rrc     b
        rrc     c
        rrc     c
        dec     a
        jr      nz, pset3
	ld	de, 0x7000
	add	hl, de
        ld      a, (hl)
        and     b
        or      c
        ld      (hl), a
	 ret
   #endasm
}


int vz_point(int x, int y)		// ----- graphics mode set pixel at x=L, y=H color C
{
   #asm
pset1:  
	ld	hl, 2
	add	hl, sp

;	ld	c, (hl)			// colour
;	inc	hl
;	inc	hl
	ld	e, (hl)			// Y value	e = y.
	inc	hl
	inc	hl
	ld	l, (hl)			// x value      l = x.
	ld	h, e			// y value      h = y.

	ld	c, 3

        ld      a, l            ; get x
        sla     l               ; calculate screen offset
        srl     h
        rr      l
        srl     h
        rr      l
        srl     h
        rr      l

	ld	de, 0x7000
	add	hl, de
        ld      a, (hl)
//        and     #3              ; pixel offset
	ld	b, 3
	and	b
	ld	h, 0
        ld      l, a

	ret
   #endasm
}


display_old()			// Displays MArio via VZ_PLOT and also displays
{			
int	m;
int	n;
	i = 0;
	j = 0;
	
   // line 1
   vz_plot(i  ,j,0);vz_plot(i+1,j,0);vz_plot(i+2,j,0); vz_plot(i+3,j,0); vz_plot(i+4,j,0); vz_plot(i+5,j,0); vz_plot(i+6,j,0); vz_plot(i+7,j,0);
   vz_plot(i+8,j,0);vz_plot(i+9,j,0);vz_plot(i+10,j,0);vz_plot(i+11,j,0);vz_plot(i+12,j,0);vz_plot(i+13,j,1);vz_plot(i+14,j,1);vz_plot(i+15,j,1);
   // line 2
   vz_plot(i  ,j+1,0);vz_plot(i+1,j+1,0);vz_plot(i+2,j+1,0); vz_plot(i+3,j+1,0); vz_plot(i+4,j+1,0); vz_plot(i+5,j+1,0); vz_plot(i+6,j+1,3); vz_plot(i+7,j+1,3);
   vz_plot(i+8,j+1,3);vz_plot(i+9,j+1,3);vz_plot(i+10,j+1,3);vz_plot(i+11,j+1,0);vz_plot(i+12,j+1,0);vz_plot(i+13,j+1,1);vz_plot(i+14,j+1,1);vz_plot(i+15,j+1,1);
   // line 3
vz_plot(i  ,j+2,0);vz_plot(i+1,j+2,0);vz_plot(i+2,j+2,0); vz_plot(i+3,j+2,0); vz_plot(i+4,j+2,0); vz_plot(i+5,j+2,3); vz_plot(i+6,j+2,3); vz_plot(i+7,j+2, 3);
vz_plot(i+8,j+2,3);vz_plot(i+9,j+2,3);vz_plot(i+10,j+2,3);vz_plot(i+11,j+2,3);vz_plot(i+12,j+2,3);vz_plot(i+13,j+2,3);vz_plot(i+14,j+2,1);vz_plot(i+15,j+2,1);
// line 4
vz_plot(i  ,j+3,0);vz_plot(i+1,j+3,0);vz_plot(i+2,j+3,0); vz_plot(i+3,j+3,0); vz_plot(i+4,j+3,0); vz_plot(i+5,j+3,2); vz_plot(i+6,j+3,2); vz_plot(i+7,j+3,2);
vz_plot(i+8,j+3,1);vz_plot(i+9,j+3,1);vz_plot(i+10,j+3,2);vz_plot(i+11,j+3,1);vz_plot(i+12,j+3,1);vz_plot(i+13,j+3,2);vz_plot(i+14,j+3,2);vz_plot(i+15,j+3,2);
// line 5
vz_plot(i  ,j+4,0);vz_plot(i+1,j+4,0);vz_plot(i+2,j+4,0); vz_plot(i+3,j+4,0); vz_plot(i+4,j+4,2); vz_plot(i+5,j+4,1); vz_plot(i+6,j+4,2); vz_plot(i+7,j+4,1);
vz_plot(i+8,j+4,1);vz_plot(i+9,j+4,1);vz_plot(i+10,j+4,2);vz_plot(i+11,j+4,1);vz_plot(i+12,j+4,1);vz_plot(i+13,j+4,2);vz_plot(i+14,j+4,2);vz_plot(i+15,j+4,2);
// line 6
vz_plot(i  ,j+5,0);vz_plot(i+1,j+5,0);vz_plot(i+2,j+5,0); vz_plot(i+3,j+5,0); vz_plot(i+4,j+5,2); vz_plot(i+5,j+5,1); vz_plot(i+6,j+5,2); vz_plot(i+7,j+5,2);
vz_plot(i+8,j+5,1);vz_plot(i+9,j+5,1);vz_plot(i+10,j+5,1);vz_plot(i+11,j+5,2);vz_plot(i+12,j+5,1);vz_plot(i+13,j+5,1);vz_plot(i+14,j+5,1);vz_plot(i+15,j+5,2);
// line 7
vz_plot(i  ,j+6,0);vz_plot(i+1,j+6,0);vz_plot(i+2,j+6,0); vz_plot(i+3,j+6,0); vz_plot(i+4,j+6,2); vz_plot(i+5,j+6,2); vz_plot(i+6,j+6,1); vz_plot(i+7,j+6,1);
vz_plot(i+8,j+6,1);vz_plot(i+9,j+6,1);vz_plot(i+10,j+6,2);vz_plot(i+11,j+6,2);vz_plot(i+12,j+6,2);vz_plot(i+13,j+6,2);vz_plot(i+14,j+6,2);vz_plot(i+15,j+6,0);
// line 8
vz_plot(i  ,j+7,0);vz_plot(i+1,j+7,0);vz_plot(i+2,j+7,0); vz_plot(i+3,j+7,0); vz_plot(i+4,j+7,0); vz_plot(i+5,j+7,0); vz_plot(i+6,j+7,1); vz_plot(i+7,j+7,1);
vz_plot(i+8,j+7,1);vz_plot(i+9,j+7,1);vz_plot(i+10,j+7,1);vz_plot(i+11,j+7,1);vz_plot(i+12,j+7,1);vz_plot(i+13,j+7,2);vz_plot(i+14,j+7,0);vz_plot(i+15,j+7,0);
// line 9
vz_plot(i  ,j+8,0);vz_plot(i+1,j+8,0);vz_plot(i+2,j+8,2); vz_plot(i+3,j+8,2); vz_plot(i+4,j+8,2); vz_plot(i+5,j+8,2); vz_plot(i+6,j+8,2); vz_plot(i+7,j+8,3);
vz_plot(i+8,j+8,2);vz_plot(i+9,j+8,2);vz_plot(i+10,j+8,2);vz_plot(i+11,j+8,3);vz_plot(i+12,j+8,2);vz_plot(i+13,j+8,0);vz_plot(i+14,j+8,0);vz_plot(i+15,j+8,0);
// line 10
vz_plot(i  ,j+9,0);vz_plot(i+1,j+9,2);vz_plot(i+2,j+9,2); vz_plot(i+3,j+9,2); vz_plot(i+4,j+9,2); vz_plot(i+5,j+9,2); vz_plot(i+6,j+9,2); vz_plot(i+7,j+9,2);
vz_plot(i+8,j+9,3);vz_plot(i+9,j+9,2);vz_plot(i+10,j+9,2);vz_plot(i+11,j+9,2);vz_plot(i+12,j+9,3);vz_plot(i+13,j+9,0);vz_plot(i+14,j+9,0);vz_plot(i+15,j+9,2);
// line 11
vz_plot(i  ,j+10,1);vz_plot(i+1,j+10,1);vz_plot(i+2,j+10,2); vz_plot(i+3,j+10,2); vz_plot(i+4,j+10,2); vz_plot(i+5,j+10,2); vz_plot(i+6,j+10,2); vz_plot(i+7,j+10,2);
vz_plot(i+8,j+10,3);vz_plot(i+9,j+10,3);vz_plot(i+10,j+10,3);vz_plot(i+11,j+10,3);vz_plot(i+12,j+10,3);vz_plot(i+13,j+10,0);vz_plot(i+14,j+10,0);vz_plot(i+15,j+10,2);
// line 12
vz_plot(i  ,j+11,1);vz_plot(i+1,j+11,1);vz_plot(i+2,j+11,1); vz_plot(i+3,j+11,0); vz_plot(i+4,j+11,3); vz_plot(i+5,j+11,3); vz_plot(i+6,j+11,2); vz_plot(i+7,j+11,3);
vz_plot(i+8,j+11,3);vz_plot(i+9,j+11,1);vz_plot(i+10,j+11,3);vz_plot(i+11,j+11,3);vz_plot(i+12,j+11,1);vz_plot(i+13,j+11,3);vz_plot(i+14,j+11,2);vz_plot(i+15,j+11,2);
// line 13
vz_plot(i  ,j+12,0);vz_plot(i+1,j+12,1);vz_plot(i+2,j+12,0); vz_plot(i+3,j+12,2); vz_plot(i+4,j+12,3); vz_plot(i+5,j+12,3); vz_plot(i+6,j+12,3); vz_plot(i+7,j+12,3);
vz_plot(i+8,j+12,3);vz_plot(i+9,j+12,3);vz_plot(i+10,j+12,3);vz_plot(i+11,j+12,3);vz_plot(i+12,j+12,3);vz_plot(i+13,j+12,3);vz_plot(i+14,j+12,2);vz_plot(i+15,j+12,2);
// line 14
vz_plot(i  ,j+13,0);vz_plot(i+1,j+13,0);vz_plot(i+2,j+13,2); vz_plot(i+3,j+13,2); vz_plot(i+4,j+13,2); vz_plot(i+5,j+13,3); vz_plot(i+6,j+13,3); vz_plot(i+7,j+13,3);
vz_plot(i+8,j+13,3);vz_plot(i+9,j+13,3);vz_plot(i+10,j+13,3);vz_plot(i+11,j+13,3);vz_plot(i+12,j+13,3);vz_plot(i+13,j+13,3);vz_plot(i+14,j+13,2);vz_plot(i+15,j+13,2);
// line 15
vz_plot(i  ,j+14,0);vz_plot(i+1,j+14,2);vz_plot(i+2,j+14,2); vz_plot(i+3,j+14,2); vz_plot(i+4,j+14,3); vz_plot(i+5,j+14,3); vz_plot(i+6,j+14,3); vz_plot(i+7,j+14,3);
vz_plot(i+8,j+14,3);vz_plot(i+9,j+14,3);vz_plot(i+10,j+14,0);vz_plot(i+11,j+14,0);vz_plot(i+12,j+14,0);vz_plot(i+13,j+14,0);vz_plot(i+14,j+14,0);vz_plot(i+15,j+14,0);
// line 16
vz_plot(i  ,j+15,0);vz_plot(i+1,j+15,2);vz_plot(i+2,j+15,0); vz_plot(i+3,j+15,0); vz_plot(i+4,j+15,3); vz_plot(i+5,j+15,3); vz_plot(i+6,j+15,3); vz_plot(i+7,j+15,0);
vz_plot(i+8,j+15,0);vz_plot(i+9,j+15,0);vz_plot(i+10,j+15,0);vz_plot(i+11,j+15,0);vz_plot(i+12,j+15,0);vz_plot(i+13,j+15,0);vz_plot(i+14,j+15,0);vz_plot(i+15,j+15,0);
}

display_big(int m , int n){		// Mario as 32x16 big sized via POKE
					// display 32x16 mario via poke
m=m+0x7000;

bpoke(m+n* 1,  0);bpoke(m+1+n* 1,  0);bpoke(m+2+n* 1,  0);bpoke(m+3+n* 1,  0);bpoke(m+4+n* 1,  0);bpoke(m+5+n* 1,  0);bpoke(m+6+n* 1,  0);bpoke(m+7+n* 1,  0);bpoke(m+8+n* 1,  0);bpoke(m+9+n* 1,  0);bpoke(m+10+n* 1,  0);bpoke(m+11+n* 1,  0);bpoke(m+12+n* 1,  0);bpoke(m+13+n* 1, 85);bpoke(m+14+n* 1, 85);bpoke(m+15+n* 1, 85);
bpoke(m+n* 2,  0);bpoke(m+1+n* 2,  0);bpoke(m+2+n* 2,  0);bpoke(m+3+n* 2,  0);bpoke(m+4+n* 2,  0);bpoke(m+5+n* 2,  0);bpoke(m+6+n* 2,255);bpoke(m+7+n* 2,255);bpoke(m+8+n* 2,255);bpoke(m+9+n* 2,255);bpoke(m+10+n* 2,255);bpoke(m+11+n* 2,  0);bpoke(m+12+n* 2,  0);bpoke(m+13+n* 2, 85);bpoke(m+14+n* 2, 85);bpoke(m+15+n* 2, 85);
bpoke(m+n* 3,  0);bpoke(m+1+n* 3,  0);bpoke(m+2+n* 3,  0);bpoke(m+3+n* 3,  0);bpoke(m+4+n* 3,  0);bpoke(m+5+n* 3,255);bpoke(m+6+n* 3,255);bpoke(m+7+n* 3,255);bpoke(m+8+n* 3,255);bpoke(m+9+n* 3,255);bpoke(m+10+n* 3,255);bpoke(m+11+n* 3,255);bpoke(m+12+n* 3,255);bpoke(m+13+n* 3,255);bpoke(m+14+n* 3, 85);bpoke(m+15+n* 3, 85);
bpoke(m+n* 4,  0);bpoke(m+1+n* 4,  0);bpoke(m+2+n* 4,  0);bpoke(m+3+n* 4,  0);bpoke(m+4+n* 4,  0);bpoke(m+5+n* 4,170);bpoke(m+6+n* 4,170);bpoke(m+7+n* 4,170);bpoke(m+8+n* 4, 85);bpoke(m+9+n* 4, 85);bpoke(m+10+n* 4,170);bpoke(m+11+n* 4, 85);bpoke(m+12+n* 4, 85);bpoke(m+13+n* 4,170);bpoke(m+14+n* 4,170);bpoke(m+15+n* 4,170);
bpoke(m+n* 5,  0);bpoke(m+1+n* 5,  0);bpoke(m+2+n* 5,  0);bpoke(m+3+n* 5,  0);bpoke(m+4+n* 5,170);bpoke(m+5+n* 5, 85);bpoke(m+6+n* 5,170);bpoke(m+7+n* 5, 85);bpoke(m+8+n* 5, 85);bpoke(m+9+n* 5, 85);bpoke(m+10+n* 5,170);bpoke(m+11+n* 5, 85);bpoke(m+12+n* 5, 85);bpoke(m+13+n* 5,170);bpoke(m+14+n* 5,170);bpoke(m+15+n* 5,170);
bpoke(m+n* 6,  0);bpoke(m+1+n* 6,  0);bpoke(m+2+n* 6,  0);bpoke(m+3+n* 6,  0);bpoke(m+4+n* 6,170);bpoke(m+5+n* 6, 85);bpoke(m+6+n* 6,170);bpoke(m+7+n* 6,170);bpoke(m+8+n* 6, 85);bpoke(m+9+n* 6, 85);bpoke(m+10+n* 6, 85);bpoke(m+11+n* 6,170);bpoke(m+12+n* 6, 85);bpoke(m+13+n* 6, 85);bpoke(m+14+n* 6, 85);bpoke(m+15+n* 6,170);
bpoke(m+n* 7,  0);bpoke(m+1+n* 7,  0);bpoke(m+2+n* 7,  0);bpoke(m+3+n* 7,  0);bpoke(m+4+n* 7,170);bpoke(m+5+n* 7,170);bpoke(m+6+n* 7, 85);bpoke(m+7+n* 7, 85);bpoke(m+8+n* 7, 85);bpoke(m+9+n* 7, 85);bpoke(m+10+n* 7,170);bpoke(m+11+n* 7,170);bpoke(m+12+n* 7,170);bpoke(m+13+n* 7,170);bpoke(m+14+n* 7,170);bpoke(m+15+n* 7,  0);
bpoke(m+n* 8,  0);bpoke(m+1+n* 8,  0);bpoke(m+2+n* 8,  0);bpoke(m+3+n* 8,  0);bpoke(m+4+n* 8,  0);bpoke(m+5+n* 8,  0);bpoke(m+6+n* 8, 85);bpoke(m+7+n* 8, 85);bpoke(m+8+n* 8, 85);bpoke(m+9+n* 8, 85);bpoke(m+10+n* 8, 85);bpoke(m+11+n* 8, 85);bpoke(m+12+n* 8, 85);bpoke(m+13+n* 8,170);bpoke(m+14+n* 8,  0);bpoke(m+15+n* 8,  0);
bpoke(m+n* 9,  0);bpoke(m+1+n* 9,  0);bpoke(m+2+n* 9,170);bpoke(m+3+n* 9,170);bpoke(m+4+n* 9,170);bpoke(m+5+n* 9,170);bpoke(m+6+n* 9,170);bpoke(m+7+n* 9,255);bpoke(m+8+n* 9,170);bpoke(m+9+n* 9,170);bpoke(m+10+n* 9,170);bpoke(m+11+n* 9,255);bpoke(m+12+n* 9,170);bpoke(m+13+n* 9,  0);bpoke(m+14+n* 9,  0);bpoke(m+15+n* 9,  0);
bpoke(m+n*10,  0);bpoke(m+1+n*10,170);bpoke(m+2+n*10,170);bpoke(m+3+n*10,170);bpoke(m+4+n*10,170);bpoke(m+5+n*10,170);bpoke(m+6+n*10,170);bpoke(m+7+n*10,170);bpoke(m+8+n*10,255);bpoke(m+9+n*10,170);bpoke(m+10+n*10,170);bpoke(m+11+n*10,170);bpoke(m+12+n*10,255);bpoke(m+13+n*10,  0);bpoke(m+14+n*10,  0);bpoke(m+15+n*10,170);
bpoke(m+n*11, 85);bpoke(m+1+n*11, 85);bpoke(m+2+n*11,170);bpoke(m+3+n*11,170);bpoke(m+4+n*11,170);bpoke(m+5+n*11,170);bpoke(m+6+n*11,170);bpoke(m+7+n*11,170);bpoke(m+8+n*11,255);bpoke(m+9+n*11,255);bpoke(m+10+n*11,255);bpoke(m+11+n*11,255);bpoke(m+12+n*11,255);bpoke(m+13+n*11,  0);bpoke(m+14+n*11,  0);bpoke(m+15+n*11,170);
bpoke(m+n*12, 85);bpoke(m+1+n*12, 85);bpoke(m+2+n*12, 85);bpoke(m+3+n*12,  0);bpoke(m+4+n*12,255);bpoke(m+5+n*12,255);bpoke(m+6+n*12,170);bpoke(m+7+n*12,255);bpoke(m+8+n*12,255);bpoke(m+9+n*12, 85);bpoke(m+10+n*12,255);bpoke(m+11+n*12,255);bpoke(m+12+n*11, 85);bpoke(m+13+n*12,255);bpoke(m+14+n*12,170);bpoke(m+15+n*12,170);
bpoke(m+n*13,  0);bpoke(m+1+n*13, 85);bpoke(m+2+n*13,  0);bpoke(m+3+n*13,170);bpoke(m+4+n*13,255);bpoke(m+5+n*13,255);bpoke(m+6+n*13,255);bpoke(m+7+n*13,255);bpoke(m+8+n*13,255);bpoke(m+9+n*13,255);bpoke(m+10+n*13,255);bpoke(m+11+n*13,255);bpoke(m+12+n*13,255);bpoke(m+13+n*13,255);bpoke(m+14+n*13,170);bpoke(m+15+n*13,170);
bpoke(m+n*14,  0);bpoke(m+1+n*14,  0);bpoke(m+2+n*14,170);bpoke(m+3+n*14,170);bpoke(m+4+n*14,170);bpoke(m+5+n*14,255);bpoke(m+6+n*14,255);bpoke(m+7+n*14,255);bpoke(m+8+n*14,255);bpoke(m+9+n*14,255);bpoke(m+10+n*14,255);bpoke(m+11+n*14,255);bpoke(m+12+n*14,255);bpoke(m+13+n*14,255);bpoke(m+14+n*14,170);bpoke(m+15+n*14,170);
bpoke(m+n*15,  0);bpoke(m+1+n*15,170);bpoke(m+2+n*15,170);bpoke(m+3+n*15,170);bpoke(m+4+n*15,255);bpoke(m+5+n*15,255);bpoke(m+6+n*15,255);bpoke(m+7+n*15,255);bpoke(m+8+n*15,255);bpoke(m+9+n*15,255);bpoke(m+10+n*15,  0);bpoke(m+11+n*15,  0);bpoke(m+12+n*15,  0);bpoke(m+13+n*15,  0);bpoke(m+14+n*15,  0);bpoke(m+15+n*15,  0);
bpoke(m+n*16,  0);bpoke(m+1+n*16,170);bpoke(m+2+n*16,  0);bpoke(m+3+n*16,  0);bpoke(m+4+n*16,255);bpoke(m+5+n*16,255);bpoke(m+6+n*16,255);bpoke(m+7+n*16,  0);bpoke(m+8+n*16,  0);bpoke(m+9+n*16,0)  ;bpoke(m+10+n*16,  0);bpoke(m+11+n*16,  0);bpoke(m+12+n*16,  0);bpoke(m+13+n*16,  0);bpoke(m+14+n*16,  0);bpoke(m+15+n*16,  0);
}





clear_screen(){
#asm
	ld 	hl, 0x7000
	ld 	de, 0x7001
	ld 	bc, 2048
	ld 	(hl), 0         ;set first byte to '0'
	ldir    		;copy bytes
#endasm
}


disp( int x1, int y1)			// Display Mario via ASM (x,y)
{
#asm	

ld	hl, 2
add	hl, sp
ld	e, (hl)
inc	hl
ld	d, (hl)
ld	(y1), de
inc	hl
ld	e, (hl)
inc	hl
ld	d, (hl)
ld	(x1), de



	ld	a, (y1)			; mul HL = H * E 
	ld	h, a
	ld	e, 32
	ld 	l, 0
	ld 	d, l
	ld 	b, 8
mult:   add  	hl, hl
        jr   	nc, noadd
        add  	hl, de
noadd:  djnz 	mult
	push	hl
	pop	bc			; bc = y*32

	ld	hl, x1
	ld	a, (hl)			; a = x

	ld	hl, 0x7000
	add	hl, bc			; hl = 0x7000 + y*32
	ld	c, a
	ld	b, 0			; bc = x
	add	hl, bc			; hl= 0x7000 + (y*32) + x

	
	push	hl
	pop	de			; de = destin screen.

	ld	hl, mario
	ld	c, 0
//line 1
//	ldi
	ldi
	ldi
	ldi
// line 2
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl

	ldi
	ldi
	ldi
	ldi
// line 3
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl
	ldi
	ldi
	ldi
	ldi
// line 4
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl
	ldi
	ldi
	ldi
	ldi
// line 5
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl
	ldi
	ldi
	ldi
	ldi
// line 6
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl
	ldi
	ldi
	ldi
	ldi

// line 7
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl
	ldi
	ldi
	ldi
	ldi
// line 8
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl
	ldi
	ldi
	ldi
	ldi

// line 9
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl
	ldi
	ldi
	ldi
	ldi
// line 10
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl
	ldi
	ldi
	ldi
	ldi
// line 11
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl
	ldi
	ldi
	ldi
	ldi
// line 12
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl
	ldi
	ldi
	ldi
	ldi
// line 13
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl
	ldi
	ldi
	ldi
	ldi
// line 14
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl
	ldi
	ldi
	ldi
	ldi
// line 15
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl
	ldi
	ldi
	ldi
	ldi

// line 16
	push	hl
	push	de
	pop	hl
	ld	bc, 28
	add	hl, bc
	push	hl
	pop	de
	pop	hl
	ldi
	ldi
	ldi
	ldi


	ret

x1:	defb 0,0
y1:	defb 0,0
o:	defb 0,0
p:	defb 0,0
k:	defb 0,0
l:	defb 0,0
m:	defb 0,0
n:	defb 0,0


mariolo:								; lo res mode(0) mario. 16x16
defb 143,143,143,143,143,143,143,143,143,143,143,143,143,159,159,159
defb 143,143,143,143,143,143,191,191,191,191,191,143,143,159,159,159
defb 143,143,143,143,143,191,191,191,191,191,191,191,191,191,159,159
defb 143,143,143,143,143,175,175,175,159,159,175,159,159,175,175,175
defb 143,143,143,143,175,159,175,159,159,159,175,159,159,175,175,175
defb 143,143,143,143,175,159,175,175,159,159,159,175,159,159,159,175
defb 143,143,143,143,175,175,159,159,159,159,175,175,175,175,175,143
defb 143,143,143,143,143,143,159,159,159,159,159,159,159,175,143,143
defb 143,143,175,175,175,175,175,191,175,175,175,191,175,143,143,143
defb 143,175,175,175,175,175,175,175,191,175,175,175,191,143.143,175
defb 159,159,175,175,175,175,175,175,191,191,191,191,191,143,143,175
defb 159,159,159,143,191,191,175,191,191,159,191,191,159,191,175,175
defb 143,159,143,175,191,191,191,191,191,191,191,191,191,191,175,175
defb 143,143,175,175,175,191,191,191,191,191,191,191,191,191,175,175
defb 143,175,175,175,191,191,191,191,191,191,143,143,143,143,143,143
defb 143,175,143,143,191,191,191,143,143,143,143,143,143,143,143,143



mario:				; working
defb     0,   0,   21,    0
defb	15,  252,   21,   0
defb    63,  255,  245,   0
defb 	42,   89,  127,   0
defb	 153,   89,  106, 0 
defb	 154,   86,   86, 0
defb	 165,   90,  168, 0
defb	   5,   85,   96, 10
defb	 171,  171,  128, 42
defb	 170,  234,  194, 90
defb	 170,  255,  194, 84
defb	 251,  223,  122, 18
defb	 255,  255,  250, 10
defb	191,  255,  250,  42
defb	255,  240,    0, 32
defb	252,    0,    0, 0


//mario:		; Big Endian
defb	0,0,21,0
defb	15,0,21,252
defb	63,0,245,255
defb	42,0,127,89
defb	153,0,106,89
defb	154,0,86,86
defb	165,0,168,90
defb	165,0,168,90
defb	5,0,96,85
defb	171,10,128,171
defb	170,42,194,234
defb	170,90,194,255
defb	251,84,122,223
defb	255,18,250,255
defb	191,10,250,255
defb	255,42,0,240
defb	252,32,0,0




//mario:
defb     0,   0,   21
defb	 0,  15,  252,   21
defb	 0,  63,  255,  245
defb 	 0,  42,   89,  127
defb	 0, 153,   89,  106
defb	 0, 154,   86,   86
defb	 0, 165,   90,  168
defb	 0,   5,   85,   96
defb	10, 171,  171,  128
defb	42, 170,  234,  194
defb	90, 170,  255,  194
defb	84, 251,  223,  122
defb	18, 255,  255,  250
defb	10, 191,  255,  250
defb	42, 255,  240,    0
defb	32, 252,    0,    0







#endasm
}

rotalo(){
int line1[16]=(143,143,143,143,143,143,143,143,143,143,143,143,143,159,159,159);
int line2[16]=(143,143,143,143,143,143,191,191,191,191,191,143,143,159,159,159);
int line3(16)=[143,143,143,143,143,191,191,191,191,191,191,191,191,191,159,159];
int line4(16)=[143,143,143,143,143,175,175,175,159,159,175,159,159,175,175,175];
int line5(16)=[143,143,143,143,175,159,175,159,159,159,175,159,159,175,175,175];
int line6(16)=[143,143,143,143,175,159,175,175,159,159,159,175,159,159,159,175];
int line7(16)=[143,143,143,143,175,175,159,159,159,159,175,175,175,175,175,143];
int line8(16)=[143,143,143,143,143,143,159,159,159,159,159,159,159,175,143,143];
int line9(16)=[143,143,175,175,175,175,175,191,175,175,175,191,175,143,143,143];
int line10(16)=[143,175,175,175,175,175,175,175,191,175,175,175,191,143.143,175];
int line11(16)=[159,159,175,175,175,175,175,175,191,191,191,191,191,143,143,175];
int line12(16)=[159,159,159,143,191,191,175,191,191,159,191,191,159,191,175,175];
int line13(16)=[143,159,143,175,191,191,191,191,191,191,191,191,191,191,175,175];
int line14(16)=[143,143,175,175,175,191,191,191,191,191,191,191,191,191,175,175];
int line15(16)=[143,175,175,175,191,191,191,191,191,191,143,143,143,143,143,143];
int line16(16)=[143,175,143,143,191,191,191,143,143,143,143,143,143,143,143,143];
int	i,x,y;

	for (y=0;y++;y<16){
		poke(28672+000+y, line1(y));}
	for (y=0;y++;y<16){
		poke(28672+1*32+y, line2(y))}
	for (y=0;y++;y<16){
		poke(28672+2*32+y, line3(y));}
	for (y=0;y++;y<16){
		poke(28672+3*32+y, line4(y));}
	for (y=0;y++;y<16){
		poke(28672+4*32+y, line5(y));}
	for (y=0;y++;y<16){
		poke(28672+5*32+y, line6(y));}
	for (y=0;y++;y<16){
		poke(28672+6*32+y, line7(y));}
	for (y=0;y++;y<16){
		poke(28672+7*32+y, line8(y));}
	for (y=0;y++;y<16){
		poke(28672+8*32+y, line9(y));}
	for (y=0;y++;y<16){
		poke(28672+9*32+y, line10(y));}
	for (y=0;y++;y<16){
		poke(28672+10*32+y, line11(y));}
	for (y=0;y++;y<16){
		poke(28672+11*32+y, line12(y));}
	for (y=0;y++;y<16){
		poke(28672+12*32+y, line13(y));}
	for (y=0;y++;y<16){
		poke(28672+13*32+y, line14(y));}
	for (y=0;y++;y<16){
		poke(28672+14*32+y, line15(y));}
	for (y=0;y++;y<16){
		poke(28672+15*32+y, line16(y));}
	}
}



rota(){					//attempt at rotating mario.
//int angle,  m,n, c, s, zx, zy;
int angle,  m,n, o,zx, zy;
double c, s;
int 	src_x, src_y, dest_x, dest_y;
int 	dx, dy, start_x, start_y;


   vz_plot (3,60,2);vz_plot (4,60,2);vz_plot (5,60,2);
   vz_plot (3,61,2);vz_plot (4,61,3);vz_plot (5,61,2);
   vz_plot (3,62,2);vz_plot (4,62,2);vz_plot (5,62,2);


//          t := (degrees MOD 360) * 0.0174533; { Convert Degrees to Radians }
//          c := cos( t );
//          s := sin( t );
//          for i := 1 to x_coords[0] do begin
//              zx := (x_coords[i] - xp) * c - (y_coords[i] - yp) * s + xp;
//              zy := (y_coords[i] - yp) * c + (x_coords[i] - xp) * s + yp;
//              x_coords[i] := round( zx );
//              y_coords[i] := round( zy );



     for (angle = 0; angle < 360; angle++){
	start_x = 16;					// source image x
	start_y = 16;					// source image Y
	dx = (cos(angle))*2; // 1.2;
	dy = (sin(angle))*2; // 1.2;
	for (dest_y = 16;dest_y < 32; dest_y++) {
	   src_x = start_x;
           src_y = start_y;
           for (dest_x=0;dest_x< 20; dest_x++) {
//		vz_plot ( dest_x, dest_y+32, vz_point2(src_x, src_y, 3) );
		vz_plot ( dest_x+62, dest_y+32, (point(src_x, src_y)) );
//		bpoke ( 0x7000 + (dest_y*32) + dest_x, bpeek(0x7000 + (src_x) + (32*src_y)));

		vz_plot ( dest_x+32, dest_y+32,vz_point(src_x, src_y) );
		vz_set ( dest_x, dest_y+32, vz_point(src_x, src_y) );


            	src_x += dx;
            	src_y += dy;
           }
           start_x -= dy;
           start_y += dx;
    	}
     }


// ##############################################################



}





main()
{
   int     i,j,k,l,x,y,a,b,d,e,f, angle,  m,n, c, s, o;
   double  t,zx,zy;
int g_col;
short int tmp, *ptr;
int 	src_x, src_y, dest_x, dest_y;

   vz_setbase(0x7000);
   k = 1;
   l = 1;
   clg();
//   vz_mode(1);

  	while(k==1){
		rotalo();
	}



   vz_plot (0,0,3);vz_plot (127,0,3);vz_plot (0,63,3);vz_plot (127,63,3);
   i=0;j=0;
//	display_old();
	disp(3, 0);
	disp(7, 0);
	disp(11, 0);
	disp(15, 0);
	disp(19, 0);
	disp(23, 0);
	disp(27, 0);

	disp(3, 16);
	disp(7, 16);
	disp(11, 16);
	disp(15, 16);
	disp(19, 16);
	disp(23, 16);
	disp(27, 16);

	disp(3, 32);
	disp(7, 32);
	disp(11, 32);
	disp(15, 32);
	disp(19, 32);
	disp(23, 32);
	disp(27, 32);

//	display_big(16, 32);
//	display_big(0, 32);
//	display_big(32*32, 32);
//	display_big(16+32*32, 32);


   while (k==1)   {
//	for (j=2;j<30;j++){
//	display_old();
//	disp(12, 0);
//	for (l=0;l<200;l++){}
//	clear_screen();



// POINT / VZ_POINT TESTING ROUTINE

		for (i=0;i<127;i++){
			vz_set (i,48, (vz_point(i,8) & 3) );
			vz_set (i,49, (vz_point(i,9) & 3) );
	
	}

vz_set (7,  50, 2);
vz_set (8 , 50, 2);
vz_set (9 , 50, 2);
vz_set (10, 50, 2);
vz_set (11, 50, 2);
vz_set (12, 50, 2);
vz_set (13, 50, 2);
vz_set (14, 50, 2);
vz_set (16, 50, 1);
vz_set (17, 50, 1);
vz_set (18, 50, 1);
vz_set (19, 50, 1);
vz_set (20, 50, 1);
vz_set (22, 50, 3);
vz_set (23, 50, 3);
vz_set (24, 50, 3);
vz_set (25, 50, 3);
vz_set (26, 50, 3);

vz_set (7,  56, vz_point(7 ,50));
vz_set (8,  57, vz_point(8 ,50));
vz_set (9,  58, vz_point(9 ,50));
vz_set (10, 51, vz_point(10,50));
vz_set (11, 52, vz_point(11,50));
vz_set (12, 53, vz_point(12,50));
vz_set (13, 54,  vz_point(13,50));
vz_set (14, 55,  vz_point(14,50));
vz_set (16, 56,  vz_point(16,50));
vz_set (17, 57,  vz_point(17,50));
vz_set (18, 58,  vz_point(18,50));
vz_set (19, 59,  vz_point(19,50));
vz_set (20, 60,  vz_point(20,50));
vz_set (22, 51,  vz_point(22,50));
vz_set (23, 52,  vz_point(23,50));
vz_set (24, 53,  vz_point(24,50));
vz_set (25, 54,  vz_point(25,50));
vz_set (26, 55,  vz_point(26,50));



// short int tmp, *ptr;
// tmp = asm_func_foo();
// ptr = &tmp;





//	rota ();			// rotate MARIO image


       vz_plot (1,1,0);
       vz_plot (2,1,1);
       vz_plot (3,1,2);
       vz_plot (4,1,3);

  


}

}



//    procedure rotate2d( var x_coords, y_coords  :  coord_vals;
//                            xp, yp, degrees     :  integer  );
//       var i                :  integer;
//           t, c, s, zx, zy  :  real;
//       begin
//          t := (degrees MOD 360) * 0.0174533; { Convert Degrees to Radians }
//          c := cos( t );
//          s := sin( t );
//          for i := 1 to x_coords[0] do begin
//              zx := (x_coords[i] - xp) * c - (y_coords[i] - yp) * s + xp;
//              zy := (y_coords[i] - yp) * c + (x_coords[i] - xp) * s + yp;
//              x_coords[i] := round( zx );
//              y_coords[i] := round( zy );
//          end;
//       end;








