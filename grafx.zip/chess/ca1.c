
#include <graphics.h>
#include <stdio.h>
#include <math.h>
#include <vz.h>
#define PI = 3.1415926535
main()
{
float x,y;
float angle, i, j;
char z,v,w, buf;
	vz_setbase(0x7000);
	vz_mode(1);




	for (x=0;i<360;i+=0.5)
	{
		angle = x;
		z = (char) angle * PI / 180;
		v = 20 * cos (z);
		w = 20 * cos (z);
		
		vz_plot ( (char) (16.0 * (v+3.0)), (char) w,2);
	}
	
	while (getk() != 13) {};
}

