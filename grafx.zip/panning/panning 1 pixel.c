
01010101

00001100  12
00110000  48
11000000  192


   12      48        192
00001100 00110000 11000000

ld	a, 0
ld	hl, a
ld	a, offset
ld	h, a		// take a copy of byte.
ld	a, offset + 1
ld	l, a		// HL.   H=byte 1, L=byte 2
ld	e, a
or	e, 11000000	// grab high nibble to keep it


ld	a, h
or	a, e		//upper bits from byte 2, are now 

rlc	a		// rotate byte 1.
			//bits 7 & 8 of byte2 are now byte 1 bits 1 & 2. 

ld 	offset, a		//write back to mem


inc 	offset


