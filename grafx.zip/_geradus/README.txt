
By Gerardus 28/04/2014

Resources used: 

VZ Super Graphics (by Joe Leon)
Two PDF files included in archive with details and schematics of the original hack as published in the HVVZUG, downloaded from vz200.org.

Paint Shop Pro.

CVZ2WAV by James the Animal Tamer.
Available from the VZemu Yahoo group.

VZem, the excellent VZ emulator by Guy Thomason.
Available from the VZemu Yahoo group.

Special thanks to Dave Maunder for all his help.



Information:


The hack above was performed by me in 2014 on a VZ300, pic is included. I converted some images which you can load on a real VZ that has been modified with the above hack by using the included loader. (also 16k memory expansion)

I've included .vz images for emulator usage, but note, on the emulator the images are inverted for some reason so use the image files with INV in them or 256x192 image will be a negative.

To load an image on a real VZ, first CLOAD the BASIC loader and RUN the program. It will ask to load an image file. Select one of the files (without the INV in them) and when loading completes after some time type RUN 280 and press enter and the image will be displayed.

After pressing break, you will be presented with garbage on the screen. Type OUT 32,8 to return to text mode. To load another image just type RUN and repeat as above.

On the emulator the easiest way is to load the image file first by clicking File/load VZ and selecting one of the image files with INV in them. Then click File/load VZ again and load the BASIC loader.

Then type RUN 280 and the image will display the same way as it does on a real VZ with the hack. Note: emulator settings VZ300, 34k RAM and Extended Australian GFX.

The alternative method to display the images on the emulator is to load run the program the same as for a real VZ and then load the approriate included INV image wav file.

To create an image suitable for display - use Paint Shop Pro or similar and convert to 1 bit
colour and resize to 256x192 and save as a .BMP. Import that file into VZemu (Utils/Load Bitmap) and save (File/Save VZ) and in options select BASIC with Start address:C000/End Address:D800. Convert the resultant .vz to .wav for loading on a real VZ.

Any questions, discuss in the Yahoo VZemu group :-)






