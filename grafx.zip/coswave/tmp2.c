
#include <graphics.h>
#include <stdio.h>
#include <math.h>
#include <vz.h>

#include <stdlib.h>
#include <ctype.h>
#include <strings.h>


main()
{
int x,y;
int s,t;
char z,buf;
int buffer [200];

	vz_setbase(0x7000);
	vz_mode(1);
	for (x=0; x<120; x++){
		for (y=0; y<64; y++){
			vz_plot(x,y,2);
		}
	}

	for (x=0; x<120; x++){
           buffer[x] = point(x,y);
	}

	vz_mode(0);

	for (x=0; x<120; x++){
		printf(" ",buffer[x],"/d");
	}



	while (getk() != 13) {
	};


}



