
#include <graphics.h>
#include <stdio.h>
#include <math.h>
#include <vz.h>

main()
{
float x,y;
int s,t;
char z,buf;
	vz_setbase(0x7000);
	vz_mode(1);
	for (x=-3.0; x<3.0; x=x+0.05)
	{
		buf=120;
		for (y=-3.0; y<3.0; y=y+0.2)
		{


			z = (char) 60.0 - (10.0 * (y + 3.0) + ( 10.0 * sin (x*x + y*y) ));
			if (buf>z)
			{
				buf = z;
				plot ( (char) (15.0 * (x+3.0)), (char) z);
			}



			
		}
	}
	

	for (t=0;t<64;t++){
		for (s=0;s<128;s++){
			buf=point(s,t);
			if (buf == 2) {buf = 3;}
			if (buf == 3) {buf = 4;}
			if (buf == 4) {buf = 2;}
			vz_plot ( s,t,buf);
		}
	}
	while (getk() != 13) {};


}



