
#include <graphics.h>
#include <stdio.h>
#include <math.h>
#include <vz.h>

main()
{
float x,y;
char z,buf;
	vz_setbase(0x7000);
	vz_mode(1);


	for (x=-3.0; x<3.0; x=x+0.06)
	{
		buf=100;
		for (y=-3.0; y<3.0; y=y+0.2)
		{
			z=(char)70.0-(10.0*(y+3.0)+(10.0*cos(x*x+y*y)));
			if (buf>z)
			{
				buf = z;
				vz_plot ( (char) (16.0 * (x+3.0)), (char) z,2);
			}
		}
	}
	
	while (getk() != 13) {};
}

