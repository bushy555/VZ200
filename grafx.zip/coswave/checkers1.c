
#include <graphics.h>
#include <stdio.h>
#include <math.h>
#include <vz.h>
#include <stdlib.h>
#include <ctype.h>
#include <strings.h>
#include <gray.h>
#define SCRSIZE     2048 


const unsigned int col[256] = {0,2,3,1,8,10,11,9,12,14,15,13,4,6,7,5,32,34,35,33,40,42,43,41,44,46,47,45,36,38,39,37,48,50,51,49,56,58,59,57,60,62,63,61, 52,54,55, 53,16,18,19,17,24,26,27, 25,28, 30,31,29,20,22,23,21,128, 130,131, 129,136,138,139,137,140,142,143, 141,132,134,135,133,160,162,163, 161,168,170,171,169,172,174,175, 173,164, 166,167,165,176,178,179,177,184, 186,187,185,188,190,191,189,180,182,183, 181,144, 146,147, 145,152, 154,155,153,156,158,159,157,148,150,151,149,192, 194,195, 193,200, 202,203, 201,204,206,207,205,196,198,199,197,224,226,227, 225,232, 235,236, 234,236,238,239,237,228,230,231,229,240, 242,243,241,248, 250,251, 249,252, 254,255, 253,244, 246,247, 245,208, 210,211, 209,216, 218,219, 217,220, 222,223, 221,212, 214,215, 213,64, 66,67, 65,72, 74,75, 73,76, 78,79, 77,68, 70,71, 69,96, 98,99, 97,104, 106,107, 105,108, 110,111, 109,100, 102,103, 101,112, 114,115, 113,120, 122,123,121,124,126,127,125,116, 118,119,117,80,82,83,81,88,90, 91,89,92,94,95,93, 84,86, 87,85};


char scr[128*64];
/* char scr2[128*64*2]; */
char *mem;




dis( x,y,c,d,e,f)
	int x,y,c,d,e,f;
	{
	vz_line(x+(63-21),y,63-(x/2),31-(y/2),c);
  	memcpy(0x7000,scr,SCRSIZE);           
	return 0;
	}


main(argc, argv)
int argc;
int *argv;

{	int a,b,c,d,e,f,g,h,i,j,s,t,x,y,z;


	s=0;
	c=0;
        d=1;
        e=2;
        f=3;
	a=0;
	x=0;
	y=63;
	i=0;
	j=0;
        z=1;
    	vz_mode(1);
	vz_setbase(scr); 
	asm("di\n");




        for(y=0;y<64;y=y+8){
	   for(x=0;x<128;x=x+8){
	      vz_plot(x+0,y+0,1);
	      vz_plot(x+1,y+0,1);
	      vz_plot(x+2,y+0,1);
	      vz_plot(x+3,y+0,1);
	      vz_plot(x+0,y+1,1);
	      vz_plot(x+1,y+1,1);
	      vz_plot(x+2,y+1,1);
	      vz_plot(x+3,y+1,1);
	      vz_plot(x+0,y+2,1);
	      vz_plot(x+1,y+2,1);
	      vz_plot(x+2,y+2,1);
	      vz_plot(x+3,y+2,1);
	      vz_plot(x+0,y+3,1);
	      vz_plot(x+1,y+3,1);
	      vz_plot(x+2,y+3,1);
	      vz_plot(x+3,y+3,1);

	      vz_plot(x+4,y,2);
	      vz_plot(x+5,y,2);
	      vz_plot(x+6,y,2);
	      vz_plot(x+7,y,2);
	      vz_plot(x+4,y+1,2);
	      vz_plot(x+5,y+1,2);
	      vz_plot(x+6,y+1,2);
	      vz_plot(x+7,y+1,2);
	      vz_plot(x+4,y+2,2);
	      vz_plot(x+5,y+2,2);
	      vz_plot(x+6,y+2,2);
	      vz_plot(x+7,y+2,2);
	      vz_plot(x+4,y+3,2);
	      vz_plot(x+5,y+3,2);
	      vz_plot(x+6,y+3,2);
	      vz_plot(x+7,y+3,2);

	      vz_plot(x+0,y+4,2);
	      vz_plot(x+1,y+4,2);
	      vz_plot(x+2,y+4,2);
	      vz_plot(x+3,y+4,2);
	      vz_plot(x+0,y+5,2);
	      vz_plot(x+1,y+5,2);
	      vz_plot(x+2,y+5,2);
	      vz_plot(x+3,y+5,2);
	      vz_plot(x+0,y+6,2);
	      vz_plot(x+1,y+6,2);
	      vz_plot(x+2,y+6,2);
	      vz_plot(x+3,y+6,2);
	      vz_plot(x+0,y+7,2);
	      vz_plot(x+1,y+7,2);
	      vz_plot(x+2,y+7,2);
	      vz_plot(x+3,y+7,2);

	      vz_plot(x+4,y+4,3);
	      vz_plot(x+5,y+4,3);
	      vz_plot(x+6,y+4,3);
	      vz_plot(x+7,y+4,3);
	      vz_plot(x+4,y+5,3);
	      vz_plot(x+5,y+5,3);
	      vz_plot(x+6,y+5,3);
	      vz_plot(x+7,y+5,3);
	      vz_plot(x+4,y+6,3);
	      vz_plot(x+5,y+6,3);
	      vz_plot(x+6,y+6,3);
	      vz_plot(x+7,y+6,3);
	      vz_plot(x+4,y+7,3);
	      vz_plot(x+5,y+7,3);
	      vz_plot(x+6,y+7,3);
	      vz_plot(x+7,y+7,3);
}}


      z=1;
	while(z<2){
	   z++;
           for(i=0;i<3;i++){
	   dis(63,31,c,d,e,f);
	   dis(63,30,c,d,e,f);
	   dis(63,29,c,d,e,f);
	   dis(63,28,c,d,e,f);
	   dis(62,27,c,d,e,f);
	   dis(62,26,c,d,e,f);
	   dis(62,25,c,d,e,f);
	   dis(61,24,c,d,e,f);
	   dis(60,23,c,d,e,f);
	   dis(59,22,c,d,e,f);
	   dis(58,21,c,d,e,f);
	   dis(57,21,c,d,e,f);
	   dis(56,20,c,d,e,f);
	   dis(55,20,c,d,e,f);
	   dis(54,19,c,d,e,f);
	   dis(53,19,c,d,e,f);
	   dis(52,18,c,d,e,f);
	   dis(51,18,c,d,e,f);
	   dis(50,18,c,d,e,f);
	   dis(49,17,c,d,e,f);
	   dis(48,17,c,d,e,f);
	   dis(47,17,c,d,e,f);
	   dis(46,17,c,d,e,f);
	   dis(45,17,c,d,e,f);
	   dis(44,16,c,d,e,f);
	   dis(43,16,c,d,e,f);
           c++;
           if (c>3) {c=0;}
	   dis(42,16,c,d,e,f);
	   dis(41,16,c,d,e,f);
	   dis(40,17,c,d,e,f);
	   dis(39,17,c,d,e,f);
	   dis(38,17,c,d,e,f);
	   dis(37,17,c,d,e,f);
	   dis(36,18,c,d,e,f);
	   dis(35,18,c,d,e,f);
	   dis(34,18,c,d,e,f);
	   dis(33,19,c,d,e,f);
	   dis(32,19,c,d,e,f);
	   dis(31,19,c,d,e,f);
	   dis(30,20,c,d,e,f);
	   dis(29,20,c,d,e,f);
	   dis(28,21,c,d,e,f);
	   dis(27,21,c,d,e,f);
	   dis(26,22,c,d,e,f);
	   dis(25,23,c,d,e,f);
	   dis(24,24,c,d,e,f);
	   dis(23,25,c,d,e,f);
	   dis(22,26,c,d,e,f);
	   dis(22,27,c,d,e,f);
	   dis(21,28,c,d,e,f);
	   dis(21,29,c,d,e,f);
	   dis(21,30,c,d,e,f);
           c++;
           if (c>3) {c=0;}
	   dis(21,31,c,d,e,f);
	   dis(21,32,c,d,e,f);
	   dis(21,33,c,d,e,f);
	   dis(22,34,c,d,e,f);
	   dis(22,35,c,d,e,f);
	   dis(22,36,c,d,e,f);
	   dis(23,37,c,d,e,f);
	   dis(23,38,c,d,e,f);
	   dis(24,39,c,d,e,f);
	   dis(25,40,c,d,e,f);
	   dis(26,41,c,d,e,f);
	   dis(27,42,c,d,e,f);
	   dis(28,42,c,d,e,f);
	   dis(29,43,c,d,e,f);
	   dis(30,43,c,d,e,f);
	   dis(31,44,c,d,e,f);
	   dis(32,44,c,d,e,f);
	   dis(33,44,c,d,e,f);
	   dis(34,44,c,d,e,f);
	   dis(35,45,c,d,e,f);
	   dis(36,45,c,d,e,f);
	   dis(37,45,c,d,e,f);
	   dis(38,45,c,d,e,f);
	   dis(39,45,c,d,e,f);
	   dis(40,46,c,d,e,f);
	   dis(41,46,c,d,e,f);
           c++;
           if (c>3) {c=0;}
	   dis(42,46,c,d,e,f);
	   dis(43,46,c,d,e,f);
	   dis(44,45,c,d,e,f);
	   dis(45,45,c,d,e,f);
	   dis(46,45,c,d,e,f);
	   dis(47,45,c,d,e,f);
	   dis(48,45,c,d,e,f);
	   dis(49,44,c,d,e,f);
	   dis(50,44,c,d,e,f);
	   dis(51,44,c,d,e,f);
	   dis(52,44,c,d,e,f);
	   dis(53,43,c,d,e,f);
	   dis(54,43,c,d,e,f);
	   dis(55,42,c,d,e,f);
	   dis(56,42,c,d,e,f);
	   dis(57,41,c,d,e,f);
	   dis(58,40,c,d,e,f);
	   dis(59,40,c,d,e,f);
	   dis(60,39,c,d,e,f);
	   dis(61,38,c,d,e,f);
	   dis(61,37,c,d,e,f);
	   dis(62,36,c,d,e,f);
	   dis(62,35,c,d,e,f);
	   dis(62,34,c,d,e,f);
	   dis(63,33,c,d,e,f);
	   dis(63,32,c,d,e,f);
           c++;
           if (c>3) {c=0;}
           c++;
           if (c>3) {c=0;}
	}
        }




   memcpy(0xe000,0x7000,2048);
   vz_setbase(0x7000);
   while (getk() != 13) {
      for (s=0xe000; s< 0xe000 + 2048; s++){
         bpoke(s, col[bpeek(s)]);
      }
   memcpy(0x7000,0xe000,2048);







} 


}





