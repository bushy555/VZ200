
#include <graphics.h>
#include <stdio.h>
#include <math.h>
#include <vz.h>

main()
{
float x,y;
char z,buf;
	vz_setbase(0x7000);
	vz_mode(1);
	for (x=-3.0; x<3.0; x=x+0.06)
	{
		buf=100;
		for (y=-3.0; y<3.0; y=y+0.2)
		{
			z=(char)70.0-(10.0*(y+3.0)+(10.0*cos(x*x+y*y)));
//			z = (char) 35.0 - (6.0 * (y + 3.0) + ( 6.0 * cos (x*x + y*y) ));

			if (buf>z)
			{
				buf = z;
//				vz_plot ( (char) (16.0 * (x+3.0)), (char) z,2);



				// coloured "rings"
				//cplot ( (char) (9.0 * (x+3.0)), (char) z, (4.0 +(cos (x*x + y*y) * 2.0)));

				// this colouring option has a phase shift and evidences of the "waves"
				vz_plot ( (char) (9.0 * (x+3.0)), (char) z, (3.0 +(sin (x*x + y*y) * 2.0)));



			}
		}
	}
	
	while (getk() != 13) {};
}



