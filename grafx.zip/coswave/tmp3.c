
#include <graphics.h>
#include <stdio.h>
#include <math.h>
#include <vz.h>

#include <stdlib.h>
#include <ctype.h>
#include <strings.h>


main()
{
int x,y;
int s,t;
char z,buf;
int  buffer1[32*64];
int  buffer2[32*64];
	vz_setbase(0x7000);
	vz_mode(1);

	while (getk() != 13) {
		memset(0x7000+ (62*32), 221, 64);
		memset(buffer1+(62*32), 221, 64);
		memset(buffer2+(62*32), 221, 64);
	}
}



