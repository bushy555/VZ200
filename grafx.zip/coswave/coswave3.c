

#include <graphics.h>
#include <stdio.h>
#include <math.h>
#include <vz.h>

#include <stdlib.h>
#include <ctype.h>
#include <strings.h>
main()
{
float x,y;
int s,t;
char z,buf;
	vz_setbase(0x7000);
	vz_mode(1);
	for (x=-3.0; x<3.0; x=x+0.05)
	{
		buf=120;
		for (y=-3.0; y<3.0; y=y+0.2)
		{
			z=(char)70.0-(10.0*(y+3.0)+(10.0*cos(x*x+y*y)));
//			z = (char) 35.0 - (6.0 * (y + 3.0) + ( 6.0 * cos (x*x + y*y) ));

			if (buf>z)
			{
				buf = z;
//				vz_plot ( (char) (16.0 * (x+3.0)), (char) z,2);



				// coloured "rings"
//				vz_plot ( (char) (9.0 * (x+3.0)), (char) z, (4.0 +(cos (x*x + y*y) * 2.0)));
				vz_plot ( (char) (20.0 * (x+3.0)), (char) z, (4.0 +(cos (x*x + y*y) * 2.0)));

				// this colouring option has a phase shift and evidences of the "waves"
//				vz_plot ( (char) (9.0 * (x+3.0)), (char) z, (3.0 +(sin (x*x + y*y) * 2.0)));



			}
		}
	}
	




	while (getk() != 13) {
	   for (s=0x7000; s< 0x7000 + 2048; s++){
	      t=bpeek(s);
	      if (t==0){;}
	      if (t==1){t=2;}
	      if (t==2){t=3;}
	      if (t==3){t=1;}

	      if (t==16){t=32;}
	      if (t==32){t=48;}
	      if (t==48){t=16;}

	      if (t==4){t=8;}
	      if (t==8){t=12;}
	      if (t==12){t=4;}

              bpoke(s,t );	
           }		
	}


}



