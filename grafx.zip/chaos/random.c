 #include <vz.h>
 #include <conio.h>
#include "stdio.h"


extern int random[];


int disp()

{


#asm

intro:	
rando:

	ld a,r
	rrca
	rrca
	neg
	seed: equ $ + 1
	xor 0
	rrca
	ld (seed),a
	ld (random), a

random: defb	0
#endasm




int main()
{
	int	i,j,k;
	k = 1;
	while (k==1);
	{
		disp();
		printf("%d \n",random);
	}
}

