#include <vz.h>
#include <graphics.h>
#include <stdio.h>
 #include <sound.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <strings.h>
 #include <conio.h>
 #include <math.h>

int	rnd;
int	x;
int	y;
int	z;
int	i, j, k;



int main()
{

    	vz_mode(1);
    	asm("di\n");
	vz_setbase(0x7000);
	vz_color(1);
	vz_bgrd(1);
	z = 1;
	x = 63;
	y = 63;
	i = 63;
	j = 63;
	while (z == 1)
	{

		rnd = rand(255);
	
	
		if ((rnd > 10921) && (rnd < 21846))
		{
			x = x + 16;
			y = y + 64;
		}
	
		if (rnd > 21845)
		{
			x = x + 32;
			y = y + 0;
		}
	
		x = x /2;
		y = y /2;
		
		i=28672 + x + (y*32);

		bpoke(i,1);
	}

}





