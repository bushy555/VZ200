 #include <vz.h>
 #include <conio.h>
#include "stdio.h"



extern char mydata[];
extern int random;

#asm
._mydata
 defm	"This is a string"
 defb	0 ; String termination
._random
 defb   0
 defb   0
#endasm


fred()
{
#asm
 ld (hl), random
 inc (hl)
#endasm
}

main()
{
 random = 1;
  printf("mydata: %s \n",mydata);
  printf("random: %d \n",random);
 random = 23;
  printf("mydata: %s \n",mydata);
  printf("random: %d \n",random);
 random = 27;
  printf("mydata: %s \n",mydata);
  printf("random: %d \n",random);
  fred();
  printf("mydata: %s \n",mydata);
  printf("random: %d \n",random);
  
}

