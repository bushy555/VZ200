#include <vz.h>
#include <graphics.h>
#include <stdio.h>
 #include <sound.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <strings.h>
 #include <conio.h>
 #include <math.h>

#define PI = 3.1415926535
main()
{
float cx, cy;
float angle,  j;
char z,v,w, buf;
int k, sz,i,x,y,a,b,c,d,e,f;
	vz_setbase(0x7000);
	k = 1;
	vz_mode(1);
	cx = 50;
	cy = 30;
	while (k==1)
	{
	for (i=0;i<360;i=i+1) {
		x=cos(i*6)*15;  
		y=sin(i*6)*10;  
		e=cos(i*6)*15;  
		f=sin(i*6)*10;  
		a=cos((i+240)*6)*15;  
		b=sin((i+240)*6)*10; 
		c=cos((i+120)*6)*15;  
		d=sin((i+120)*6)*10; 
//		vz_mode(1);
//		vz_plot (cx+x,cy+y, 2);
//		vz_plot (cx+a,cy+b, 3);
//		vz_plot (cx+c,cy+d, 1);

		vz_line (cx+x+e, cy+y+f, cx+a+e, cy+b+f, 3);
		vz_line (cx+a+e, cy+b+f, cx+c+e, cy+d+f, 3);
		vz_line (cx+c+e, cy+d+f, cx+x+e, cy+y+f, 3);

	}
	}
}












