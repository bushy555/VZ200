 #include <vz.h>
 #include <graphics.h>
 #include <stdio.h>
 #include <sound.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <strings.h>
 #include <conio.h>

int main()
{
	int 	a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,z;
	int	x, y;

    	vz_mode(1);
	i=0;
        z=0;

	x = 64;
	y = 64;
	i = 64;
	j = 64;
	k = 0;
	vz_setbase( 0x7000 );
	asm("di\n");
	while (z==0)
	{


		#asm
			ld	de, rnd
			ld	a, (de)
			ld	hl, rnd2
			ld	b, (hl)
			rra	b
			xor	b
			inc	(hl)
			ld	rnd, (hl)
			ld	rnd2, (de)
			
			ld	a, (hl)

			cp	a, 44
			jr	c, here1

			cp	a, 128
			jr	c, here2


here2:			ld	hl, x
			ld	a, (hL)
			ld	hl, y
			ld	b, (hl)

			add 	a, 32
			add	b, 32

			ld	hl, x
			ld	(hL), a
			ld	hl, y
			ld	(hl), a
			jp	here1			



here2:			ld	hl, x
			ld	a, (hL)
			ld	hl, y
			ld	b, (hl)

			add	b, 32

			ld	hl, x
			ld	(hL), a
			ld	hl, y
			ld	(hl), a
			


here1:			
			
			ld	hl, x
			ld	a, (hL)
			ld	hl, y
			ld	b, (hl)

			shr	a
			shr	b

			ld	hl, x
			ld	(hL), a
			ld	hl, y
			ld	(hl), a



			ld	hl, x
			ld	a, (hL)
			ld	hl, y
			ld	b, (hl)

			mov	dx, 64
			mov	ax, Y
			mul	dx		--> ax
			add	ax, X
			add	ax, 28672
			PLOT




x def 0
y def 0			

		#endasm








		k = rand(255);
		if ((k > 10921) && (k < 21846))
		{
			x = x + 63;
			y = y + 64;	
		}
		if (k > 21846)
		{
			x = x + 128;	

		}
		x = x/2;
		y = y/2;
		vz_plot(x, y, 3);
	}
#asm
a:	ld	hl, (x)
	ld	de, 63
	add	hl, de
	ld	(x), hl
	ld	hl, (y)
	ld	de, 63
	add 	hl, de
	ld	(y), hl
	ret

b:	ld	hl, (x)
	ld	de, 128
	add	hl, de
	ld	(x), hl
	ret

x:	defb	63
y:	defb 	64
#endasm
	
}
