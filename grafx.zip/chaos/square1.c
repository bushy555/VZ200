// was 773 bytes
// 681, 308, 302

 #include <vz.h>
 #include <graphics.h>
 #include <stdio.h>
 #include <sound.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <strings.h>
 #include <conio.h>
 #include <math.h>



int i,j, cx, cy;
int x4, y4, x5, y5, x6, y6, x7, y7, x8, y8; 



int main()
{
	vz_setbase(0x7000);
    	vz_mode(1);
    	asm("di\n");
	cx=32;
	cy=16;

	for (i=0;i<360;i++) {

		x4=cx+cos(i*6)*23;  
		y4=cy+sin(i*6)*16;  
		x5=cx+cos((i+240)*6)*23//+x4;  
		y5=cy+sin((i+240)*6)*16//+y4; 
		x6=cx+cos((i+120)*6)*23;  
		y6=cy+sin((i+120)*6)*16; 
		x7=cx+cos((i+60)*6)*23;  
		y7=cy+sin((i+60)*6)*16; 
		x8=x6+cos((i+60)*6)*23;  
		y8=y6+sin((i+60)*6)*16; 

    		vz_mode(1);

		vz_line (x4,y4,x6,y6,5);
		vz_line (x5,y5,x6,y6,5);
		vz_line (x6,y6,x7,y7,5);
		vz_line (x4,y4,x5,y5,5);
		vz_line (x5,y5,x7,y7,5);

		vz_line (x4+70,y4,x6+50,y6,2);
		vz_line (x5+70,y5,x6+50,y6,2);
		vz_line (x6+70,y6,x7+50,y7,2);
		vz_line (x4+70,y4,x5+50,y5,2);
		vz_line (x5+70,y5,x7+50,y7,2);


		vz_line (x4,y4+30,x6,y6+30,3);
//		vz_line (x5,y5+30,x6,y6+30,3);
		vz_line (x6,y6+30,x8,y8+30,3);
		vz_line (x4,y4+30,x5,y5+30,3);
		vz_line (x5,y5+30,x8,y8+30,3);

		vz_line (x4+70,y4+30,x6+70,y6+30,4);
		vz_line (x5+70,y5+30,x6+70,y6+30,4);
		vz_line (x6+70,y6+30,x8+70,y8+30,4);
		vz_line (x4+70,y4+30,x5+70,y5+30,4);
		vz_line (x5+70,y5+30,x8+70,y8+30,4);


	}
}

