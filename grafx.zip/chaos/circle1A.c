#include <vz.h>
#include <graphics.h>
#include <stdio.h>
 #include <sound.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <strings.h>
 #include <conio.h>
 #include <math.h>

#define PI = 3.1415926535
main()
{
float cx, cy;
float angle,  j;
char z,v,w, buf;
int k, sz,x,y,a,b,c,d,e,f,r;
int i;
	vz_setbase(0x7000);
	k = 1;
	vz_mode(1);
	cx = 50;
	cy = 30;
 	r= 20
	while (k==1)
	{
	for (i=0;i<360;i=i+1) {
		x=cx+r*cos(i)+r*sin(i);  
		y=cy+r*sin(i)+r*cos(i);  
		a=cx+r*cos((i+180))+r*sin((i+180));  
		b=cy+r*sin((i+180))+r*cos((i+180)); 

		vz_mode(1);
		vz_line (x,y,a,b,3);
//		vz_line (cx,cy,x,y,3);
		vz_plot(a,b,2);
		vz_plot(a,b-1,2);
		vz_plot(a-1,b,2);
		vz_plot(a-1,b-1,2);

	}
	}
}

