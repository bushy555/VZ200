#include <vz.h>
#include <graphics.h>
#include <stdio.h>
 #include <sound.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <strings.h>
 #include <conio.h>
 #include <math.h>






int main()
{

#include <stdio.h>
#include <graphics.h>
#include <stdlib.h>
#include <conio.h>
#include <math.h>
#include <vz.h>


void DrawCircle(int x, int y, int r, int color)

{
      static const double PI = 3.1415926535;
      double i, angle, x1, y1;

      for(i = 0; i < 360; i += 0.1)
      {
            angle = i;
            x1 = r * cos(angle * PI / 180);
            y1 = r * sin(angle * PI / 180);
            vz_plot(x + x1, y + y1, color);
      }
}


void main()
{
      int grd, grm, i;
      int color, xmax, ymax;

    	vz_mode(1);
    	asm("di\n");
	vz_setbase(0x7000);
	vz_color(1);
	vz_bgrd(1);
 
      color = GREEN;
      setbkcolor(BLUE);
 
      xmax = 127;
      ymax = 63;
 
      setcolor(WHITE);
      rectangle(0,0,xmax,ymax);
 
      for(i = 0; i < 230; i += 10)
      {
            DrawCircle(128, 63, i, 3);
            if(color > WHITE) {color = GREEN;}
      }
      getch();
      closegraph();
}



}

