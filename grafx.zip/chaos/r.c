 #include <vz.h>
 #include <conio.h>
#include "stdio.h"
extern char mydata[];
extern int fred;




main()
{
  printf("%s \n",mydata);
//  mydata == "hello world";
  printf("%s \n",mydata);
  printf("%d \n ",fred);




  fred = 2;
  printf("%d \n ",fred);
  fred = 3;
  printf("%d \n ",fred);
  fred = 4;
  printf("%d \n ",fred);

 wow();



  printf("fred: %d \n ",fred);


}


wow()
{


#asm
	ld	hl, s
	inc	(hl)
	inc	(hl)
	inc	(hl)
	ld	a, (hl)
	ld	(s), a
ret



._mydata
 defm	"This is a string"
 defb	0 ; String termination
s:
._fred
 defb   1

#endasm
}