// was 773 bytes
// 681, 308, 302

 #include <vz.h>
 #include <graphics.h>
 #include <stdio.h>
 #include <sound.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <strings.h>
 #include <conio.h>
 #include <math.h>



int i,j, cx, cy;
int x4, y4, x5, y5, x6, y6; 



int chaos(int y1, int y2, int y3)
{

#asm


ld	hl, 2
add	hl, sp


ld	e, (hl)
inc	hl
ld	d, (hl)
ld	(y1), de
inc	hl


ld	e, (hl)
inc	hl
ld	d, (hl)
ld	(y2), de
inc	hl


ld	e, (hl)
inc	hl
ld	d, (hl)
ld	(y3), de



intro:	
intro2:	




// HL=H*E				YELLOW LINE         HL = (Y1) * 32		
	ld	e, 32
	ld	a, (y1)
	ld	h, a
  	ld 	d,0                    ; clearing D and L
	ld 	l,0
  	ld 	b,8                    ; we have 8 bits
Mul8b2:	add 	hl,hl                  ; advancing a bit
  	jp 	nc,Mul8bS2             ; if zero, we skip the addition (jp is used for speed)
  	add 	hl,de                  ; adding to the product if necessary
Mul8bS2:djnz 	Mul8b2
	ld	de, 0x7000
	add	hl,de
	ld	c, 32
loop1:	ld	(hl), 85
	inc	hl
	dec	c					
	jp	nz, loop1


// HL=H*E				RED LINE         HL = (Y1) * 32		
	ld	e, 32
	ld	a, (y2)
	ld	h, a
  	ld 	d,0                    ; clearing D and L
	ld 	l,0
  	ld 	b,8                    ; we have 8 bits
Mul8b3:	add 	hl,hl                  ; advancing a bit
  	jp 	nc,Mul8bS3             ; if zero, we skip the addition (jp is used for speed)
  	add 	hl,de                  ; adding to the product if necessary
Mul8bS3:djnz 	Mul8b3
	ld	de, 0x7000
	add	hl,de
	ld	c, 32
loop2:	ld	(hl), 255
	inc	hl
	dec	c					
	jp	nz, loop2



// HL=H*E				BLUE LINE         HL = (Y1) * 32		
	ld	e, 32
	ld	a, (y3)
	ld	h, a
  	ld 	d,0                    ; clearing D and L
	ld 	l,0
  	ld 	b,8                    ; we have 8 bits
Mul8b4:	add 	hl,hl                  ; advancing a bit
  	jp 	nc,Mul8bS4            ; if zero, we skip the addition (jp is used for speed)
  	add 	hl,de                  ; adding to the product if necessary
Mul8bS4:djnz 	Mul8b4
	ld	de, 0x7000
	add	hl,de
	ld	c, 32
loop3:	ld	(hl), 170
	inc	hl
	dec	c					
	jp	nz, loop3



	ret
 	

x1:		defb 0
y1:		defb 0
x2:		defb 0
y2:		defb 0
x3:		defb 0
y3:		defb 0

#endasm
}






int main()
{
	vz_setbase(0x7000);
    	vz_mode(1);
    	asm("di\n");
	cx=33;
	cy=16;

	for (i=0;i<360;i++) {



		y4=cy+sin(i*6)*15 ;  
		y5=cy+sin((i+240)*6)*15 ;   
		y6=cy+sin((i+120)*6)*15 ; 

    		vz_mode(1);

		chaos (y4,y5,y6);

	}
}

