#include <vz.h>
#include <graphics.h>
#include <stdio.h>
 #include <sound.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <strings.h>
 #include <conio.h>
 #include <math.h>

#define PI = 3.1415926535
main()
{
float cx, cy;
float angle;
char z,v,w, buf;
int j,k, sz,i,x,y,a,b,c,d,e,f;
	vz_setbase(0x7000);
	k = 1;
	vz_mode(1);
	cx = 50;
	cy = 30;
	while (k==1)
	{
	for (i=0;i<360;i=i+1) {
		x=cos(i*6)*10;  
		y=sin(i*6)*10;  
		a=cos((i+240)*6)*10;  
		b=sin((i+240)*6)*10; 
		c=cos((i+120)*6)*10;  
		d=sin((i+120)*6)*10; 


	for (j=0;j<100;j++) {



		k = rand(255);
		if (k < 10922)
		{
			e=e + x
			f = f + y;	
		}
		if ((k > 10921) && (k < 21846))
		{
			e = e + a;
			f = f + b;	
		}
		if (k > 21846)
		{
			e = e + c;	
			f = f + d;	
		}
		e = e/2;
		f = f/2;
		bpoke (f*32 +e+5, 255);
//		vz_plot(cx+e, cy+f, 3);
	}

//	memcpy (0x7000, 0xe000, 2048);
	memset (0x7000, 0 ,2048);



//		vz_plot (cx+x,cy+y, 2);
//		vz_plot (cx+a,cy+b, 3);
//		vz_plot (cx+c,cy+d, 1);
	}
	}
}

