#include <vz.h>
#include <graphics.h>
#include <stdio.h>
 #include <sound.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <strings.h>
 #include <conio.h>
 #include <math.h>

#define PI = 3.1415926535
main()
{
float cx, cy;
float angle,  j;
char z,v,w, buf;
int k, sz,i,x,y,a,b,c,d,e,f;
	vz_setbase(0x7000);
	k = 1;
	vz_mode(1);
	cx = 50;
	cy = 30;
	while (k==1)
	{
	for (i=0;i<360;i=i+1) {
		x=cos(i*6)*30;  
		y=sin(i*6)*20;  
		a=cos((i+90)*6)*30;  
		b=sin((i+90)*6)*20; 
		c=cos((i+120)*6)*30;  
		d=sin((i+120)*6)*20; 
		e=cos((i+180)*6)*30;  
		f=sin((i+180)*6)*20; 

		vz_mode(1);
		vz_plot (cx+x,cy+y, 2);
		vz_plot (cx+a,cy+b, 2);
		vz_plot (cx+c,cy+d, 2);
		vz_plot (cx+e,cy+f, 2);
	}
	}
}

