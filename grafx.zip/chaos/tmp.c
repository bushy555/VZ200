 #include <vz.h>
 #include <conio.h>



int	r_seed;


int disp(x)
int x;
{
	
	
#asm

jp 	intro


	

Multiply:                        ; this routine performs the operation HL=D*E
  ld hl,0                        ; HL is used to accumulate the result
  ld a,d                         ; checking one of the factors; returning if it is zero
  or a
  ret z
  ld b,d                         ; one factor is in B
  ld d,h                         ; clearing D (H is zero), so DE holds the other factor
MulLoop:                         ; adding DE to HL exactly B times
  add hl,de
  djnz MulLoop
  ret


Mul8b:                           ; this routine performs the operation HL=H*E
  ld d,0                         ; clearing D and L
  ld l,d
  ld b,8                         ; we have 8 bits
Mul8bLoop:
  add hl,hl                      ; advancing a bit
  jp nc,Mul8bSkip                ; if zero, we skip the addition (jp is used for speed)
  add hl,de                      ; adding to the product if necessary
Mul8bSkip:
  djnz Mul8bLoop
  ret

rand_8:

	ld	hl, r_seed
	ld	a, (hl)
	AND	#B8h		; mask non feedback bits
	SCF			; set carry
	JP	PO,no_clr	; skip clear if odd
	CCF			; complement carry (clear it)
no_clr:
	ld	a, (hl)
	RLA			; rotate carry into byte
	
	ld (hl),a	; save back for next prn
	RET			; done


	ret


intro:					// H = x    L = y
	call	RAND_8
	push	hl
	ld	hl, r_seed
	inc	a
	ld	(hl), a
	pop	hl
	
#endasm

	printf("%d \n",r_seed);

}









int main()
{
	int	i,j,k;
	r_seed = 1;
    	vz_mode(1);
    	asm("di\n");
	vz_setbase(0x7000);
	vz_color(1);
//	vz_bgrd(1);
	for (i=2;i<10000;i++){
		disp();
		vz_getch();
	}
	
}



