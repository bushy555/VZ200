 #include <vz.h>
 #include <graphics.h>
 #include <stdio.h>
 #include <sound.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <strings.h>
 #include <conio.h>

int main()
{
	int a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,x,y,z;

    	vz_mode(1);
	i=0;
        z=0;
	x = 64;
	y = 64;
	i = 64;
	j = 64;
	k = 0;
	vz_setbase( 0x7000 );
	asm("di\n");
	while (z==0)
	{
		k = rand(255);
		if ((k > 10921) && (k < 21846))
		{
			x = x + 16;
			y = y + 16;	
		}
		if (k > 21846)
		{
			x = x + 32;	
		}
		x = x/2;
		y = y/2;
		vz_plot(x, y, 3);
	}
}





   .globl    rand
; ----- int rand(void);
rand:    push    ix
   ld    ix, #0
   add    ix, sp
;    17 bit polynome
;    x = ((x << 7) | (x >> 10)) + 0x18000

   ld    a, r
   and    #7
   inc    a
   ld    c, a
   ld    hl, (seed)
   ld    a, (seed+2)
rand0:    ld    b, #7
rand1:    rra
   adc    hl,hl
   rla
   djnz    rand1
   ld    de, #0x8000
   add    hl, de
   adc    a, #1
       dec     c
   jr    nz, rand0
   ld    (seed), hl
   ld    (seed+2), a
   res    #7, h    ; positive numbers only
       ld      e, l
   ld    d, h
       ld      l, 4(ix)
       ld      h, 5(ix)
   pop    ix
   jp    .mod

   .globl    srand
; ----- void srand(int start);
srand:
   push    ix
   ld    ix, #0
       add     ix, sp
   ld    l, 4(ix)
   ld    h, 5(ix)
   ld    a, h
   or    l
   jr    nz, srand1
   ld    a, r
   ld    l, a
   add    a, b
   adc    a, c
   sbc    a, d
   xor    e
   ld    h, a
srand1:
   ld    (seed), hl
   pop    ix
   ret


