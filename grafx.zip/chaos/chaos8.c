// was 773 bytes
// 681, 308, 302

 #include <vz.h>
 #include <graphics.h>
 #include <stdio.h>
 #include <sound.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <strings.h>
 #include <conio.h>
 #include <math.h>



int i,j, cx, cy;
int x4, y4, x5, y5, x6, y6; 



//int chaos(int x3, int y3, int x2, int y2, int x1, int y1)
int chaos(int y3, int x3, int y2, int x2, int y1, int x1)
{

#asm


ld	hl, 2
add	hl, sp

ld	e, (hl)
inc	hl
ld	d, (hl)
ld	(x1), de
inc	hl

ld	e, (hl)
inc	hl
ld	d, (hl)
ld	(y1), de
inc	hl

ld	e, (hl)
inc	hl
ld	d, (hl)
ld	(x2), de
inc	hl

ld	e, (hl)
inc	hl
ld	d, (hl)
ld	(y2), de
inc	hl

ld	e, (hl)
inc	hl
ld	d, (hl)
ld	(x3), de
inc	hl

ld	e, (hl)
inc	hl
ld	d, (hl)
ld	(y3), de


intr:   ld	b, 5
intro:	ld	c, 255			// H = x    L = y
intro2:	push	bc
	ld 	a,r
	rrca
//	rrca
//	neg
seed2:	xor 	0
	rrca
	ld 	(seed2+1),a

	cp	85			//Mul8b		// HL = h*e
	jr	c,next2
	cp	170
	jr	c,next3


next1:	ld	a, (x1)
	add	a, h
	ld	h, a					// 128/4		// add  (128,0) or 32,0 for poke
	ld	a, (y1)
	add	a, l
	ld	l, a					// 128/4		// add  (128,0) or 32,0 for poke
	jp	calc


next2:	ld	a, (x2)
	add	a, h
	ld	h, a
	ld	a, (y2)			// set(63,63) ; X = 63. Or X=16 for POKE
	add	a, l
	ld	l, a
	jp	calc			// Y = 63.
next3:
	ld	a, (x3)
	add	a, h
	ld	h, a
	ld	a, (y3)
	add	a, l
	ld	l, a

calc:	sra	h			// divide h / 2. H= X coord
	sra	l			// divide l / 2. L= Y coord

	push	hl			// HL   H=x L=Y

	ld	a, h			// a = X co-ord
	ld	c, 3			// c = colour
					// l = Y co-ord


pset:		// L = Y, A = X, C = Colour
        LD      H,0                     ; make 16 bit
        ADD     HL,HL                   ; multiple * 2
        ADD     HL,HL                   ; multiple * 4
        ADD     HL,HL                   ; multiple * 8
        ADD     HL,HL                   ; multiple * 16
        ADD     HL,HL                   ; multiple * 32
        LD      DE,28672                ; start of screen mem
        ADD     HL,DE                   ; DE has address of screen row
        LD      E,A                     ; setup for 16 bit add
        SRL     E                       ; divide by 2
        SRL     E                       ; divide by 4
        LD      D,0
        ADD     HL,DE                   ; DE points to correct screen byte
        SLA     E                       ; multiply by 2
        SLA     E                       ; multiply by 4
        SUB     E                       ; A has remainder - 0,1,2,3
        LD      B,A                     ; set up for djnz
        INC     B
        LD      D,11111100b             ; pixel mask
PSET1:  RRC     C
        RRC     C                       ; adjust color                       
        RRC     D
        RRC     D                       ; adjust pixel mask
        DJNZ    PSET1                   ; C has color, D has mask
        LD      A,(HL)                  ; get byte
        AND     D                       ; mask out pixel
        OR      C                       ; set pixel to color
        LD      (HL),A                  ; and display


	pop	hl
	pop	bc			// restore 255 counter
	dec	c
	jp	nz, intro2
	dec	b
//	ld	c, b
//	dec	c
	jp	nz,intro

	ret
 	






x1:		defb 0
y1:		defb 0
x2:		defb 0
y2:		defb 0
x3:		defb 0
y3:		defb 0



#endasm
}






int main()
{
	vz_setbase(0x7000);
    	vz_mode(1);
    	asm("di\n");
	cx=32;
	cy=32;

	for (i=0;i<360;i++) {


		x4=cx+cos(i*6)*32 ;  
		y4=cy+sin(i*6)*32 ;  
		x5=cx+cos((i+240)*6)*32  ;
		y5=cy+sin((i+240)*6)*32  ;     
		x6=cx+cos((i+120)*6)*32 ;
		y6=cy+sin((i+120)*6)*32 ;   

    		vz_mode(1);

		chaos (x4,y4,x5,y5,x6,y6);

//           memcpy(0x7000,0xa000,2048);
//           memset(0xa000,0,2048);

	}
}

