// was 773 bytes
// 681, 308, 302

 #include <vz.h>
#include <graphics.h>
#include <stdio.h>
 #include <sound.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <strings.h>
 #include <conio.h>
 #include <math.h>



int i,j;
int x4, y4, x5, y5, x6, y6; 



int chaos(int x1, int y1, int x2, int y2, int x3, int y3)
{

#asm


ld	hl, 2
add	hl, sp

pop	hl
ld	e, (hl)
inc	hl
ld	d, (hl)
ld	(x1), de
inc	hl

ld	e, (hl)
inc	hl
ld	d, (hl)
ld	(y1), de
inc	hl

ld	e, (hl)
inc	hl
ld	d, (hl)
inc	hl
ld	(x2), de

ld	e, (hl)
inc	hl
ld	d, (hl)
inc	hl
ld	(y2), de

ld	e, (hl)
inc	hl
ld	d, (hl)
inc	hl
ld	(x1), de

ld	e, (hl)
inc	hl
ld	d, (hl)
inc	hl
ld	(y1), de



intro:	ld	c, 255			// H = x    L = y
intro2:	push	bc
	ld 	a,r
	rrca
	rrca
	neg
seed2:	xor 	0
	rrca
	ld 	(seed2+1),a

	cp	85			//Mul8b		// HL = h*e
	jr	c,calc
	cp	170
	jr	c,next
	ld	a, (x1)
	add	a, h
	ld	h, a					// 128/4		// add  (128,0) or 32,0 for poke
	ld	a, (y1)
	add	a, l
	ld	l, a					// 128/4		// add  (128,0) or 32,0 for poke
	jp	calc


next:	ld	a, (x2)
	add	a, h
	ld	h, a
	ld	a, (y2)			// set(63,63) ; X = 63. Or X=16 for POKE
	add	a, l
	ld	l, a
	jp	calc			// Y = 63.
calc2:
	ld	a, (x3)
	add	a, h
	ld	h, a
	ld	a, (y3)
	add	a, l
	ld	l, a

calc:	sra	h			// divide h / 2
	sra	l			// divide l / 2

	push	hl			// HL   H=x L=Y
	ld	c, h			// temporarily put bc= X
	ld	e, 32			// width of screen
	ld	h, l			//  e=32 h=Y, c=x

// HL=H*E


  	ld d,0                         ; clearing D and L
	ld l,0
  	ld b,8                         ; we have 8 bits
Mul8bLoop2:
  	add hl,hl                      ; advancing a bit
  	jp nc,Mul8bSkip2                ; if zero, we skip the addition (jp is used for speed)
  	add hl,de                      ; adding to the product if necessary
Mul8bSkip2:
  	djnz Mul8bLoop2

				// HL = H * E     (HL=H*Y)   (HL=H*32) 
	ld	de, 0x7000
	add	hl, de 			// add SCREEN_BASE.  HL = (Y*32) + 0x7000
	ld	a, l
	add	a, c
	ld	l, a
					// add X.            HL = 0x7000 + (Y*32) + x 
	ld	(hl), c
	pop	hl
	pop	bc
	dec	c
	jp	nz,intro2
	ret
 
	

x1:		defb 0
y1:		defb 0
x2:		defb 0
y2:		defb 0
x3:		defb 0
y3:		defb 0



#endasm
}









int main()
{

	vz_setbase(0x7000);
    	vz_mode(1);
    	asm("di\n");

	for (i=0;i<360;i++) {

		x4=cos((i      *6)*23);  
		y4=sin((i      *6)*16);  
		x5=cos(((i+240)*6)*23);  
		y5=sin(((i+240)*6)*16); 
		x6=cos(((i+120)*6)*23);  
		y6=sin(((i+120)*6)*16); 
//    		vz_mode(1);

printf ("num %d %d %d %d %d %d \n", x4, y4, x5, y5, x6, y6);

//		chaos (28+x4, 16+y4, 28+x5, 16+y5, 16+x6, 28+y6);
	}
}

