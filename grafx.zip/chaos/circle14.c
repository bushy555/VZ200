#include <vz.h>
#include <graphics.h>
#include <stdio.h>
 #include <sound.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <strings.h>
 #include <conio.h>
 #include <math.h>

#define PI = 3.1415926535
main()
{
float cx, cy;

int  a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z;
	vz_setbase(0xe000);
	k = 1;
	vz_mode(1);
	cx = 50;
	cy = 30;
	while (k==1)
	{
	for (z=0;z<360;z=z+1) {

		a=cos((z+2))*30;  
		b=sin((z+2))*20; 
		c=cos((z-6))*30;  
		d=sin((z-6))*20; 
		e=cos((z+16))*30;  
		f=sin((z+16))*20; 
//		g=cos((z-20))*30;  
//		h=sin((z-20))*20; 



		for (j=0;j<400;j++)
		{
			k = rand(255);
			if (k < 8192)
			{
				x = x + a;	
				y = y + b;	
			}



			if ((k > 10921) && (k < 21846))
			{
				x = x + c;
				y = y + d;	
			}
			if (k > 21847)
			{
				x = x + e;	
				y = y + f;	
			}
			x = x/2;
			y = y/2;
			vz_plot(cx+x, cy+y, 3);
		}
		memcpy (0x7000, 0xe000, 2048);
		memset (0xe000, 0, 2048);





//		vz_plot (cx+a,cy+b, 3);	 
//		vz_plot (cx+c,cy+d, 3);  
//		vz_plot (cx+e,cy+f, 3);
//		vz_plot (cx+g,cy+h, 3);


	}
	}
}
