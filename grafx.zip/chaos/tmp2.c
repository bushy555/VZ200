#include <vz.h>
#include <graphics.h>
#include <stdio.h>
 #include <sound.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <strings.h>
 #include <conio.h>
 #include <math.h>

#define PI = 3.1415926535

void DrawCircle(int x, int y, int r, int color)
{
      float i, angle, x1, y1;
int j;
      for(i = 0; i < 360; i += 0.1)
      {
            angle = i;

		j = (angle * PI / 180);
            x1 = r * cos(j));
            y1 = r * sin(j));
            vz_plot(x + x1, y + y1, color);
      }
}


int main()
{
      int grd, grm, i;
      int color, xmax, ymax;

    	vz_mode(1);
    	asm("di\n");
	vz_setbase(0x7000);
	vz_color(1);
	vz_bgrd(1);
 
      color = GREEN;
      setbkcolor(BLUE);
 
      xmax = 127;
      ymax = 63;
 
      setcolor(WHITE);
      rectangle(0,0,xmax,ymax);
 
      for(i = 0; i < 230; i += 10)
      {
            DrawCircle(128, 63, i, 3);
            if(color > WHITE) {color = GREEN;}
      }
      getch();
      closegraph();
}



}

