
#include <sound.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <vz.h>
#include <graphics.h>
#include <strings.h>
#include <conio.h>



#define delay 0x4FFF 
#define screen0 0x7000
#define screen1 0xe000
#define screen2 0x8000

	int	i,j,k,l,m,n,o,p,q,r,z;


#asm

   
    mov al,13h
    int 10h
    mov dx,03d4h
    mov ah,0x20
    out dx,ax
    push 0a000h
    pop ds
MainLoop:
RenderLoop:
    mov ax,si
    shr ax,1
    imul al
    not ax
    sub ah,140
    cwd
    xor cx,cx
    mov cl,bh
    inc cx
    div cx
    xchg cx,ax
    mov ah,bl
    imul cx
    mov ax,cx
    add ax,si
    xor al,dl
    and al,32
    dec ax
    sub al,ch
    cmp al,16
    jge ok
    mov al,16
ok:
    mov [bx-128+32],al
    inc bx
    jnz RenderLoop
    lodsb
    jmp MainLoop