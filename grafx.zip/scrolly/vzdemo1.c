#include <sound.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <vz.h>
#include <graphics.h>
#include <strings.h>


#define _src1	0x7000
#define _src2	0xe000
#define _dst1	0x7000
#define _dst2	0xe000


char 	*mem;
	int scr[32*64];



intro()
{
	int	i,j,k,l,m;
    	vz_mode(1);
    	asm("di\n");


       	
	for (k=0;k<32;k++)
        {

        i=k+scr;

	vz_setbase(scr);
	memset(scr, 255, 2048);



bpoke(i+0x03D,165);bpoke(i+0x03E,169);bpoke(i+0x05D,165);bpoke(i+0x05E,165);
bpoke(i+0x07D,169);bpoke(i+0x07E,165);bpoke(i+0x09C,169);bpoke(i+0x09D,165);bpoke(i+0x09E,165);
bpoke(i+0x0BC,169);bpoke(i+0x0BD,101);bpoke(i+0x0BE,86);
bpoke(i+0x0DD,85);bpoke(i+0x0DE,86);bpoke(i+0x0FC,165);bpoke(i+0x0FD,85);bpoke(i+0x0FE,86);bpoke(i+0x0FF,169);
bpoke(i+0x11C,149);bpoke(i+0x11D,85);bpoke(i+0x11E,85);bpoke(i+0x11F,85);
bpoke(i+0x13C,165);bpoke(i+0x13D,85);bpoke(i+0x13E,85);bpoke(i+0x13F,85);bpoke(i+0x145,154);
bpoke(i+0x15C,169);bpoke(i+0x15D,85);bpoke(i+0x15E,85);bpoke(i+0x15F,90);bpoke(i+0x164,90);bpoke(i+0x165,90);
bpoke(i+0x17C,169);bpoke(i+0x17D,85);bpoke(i+0x17E,85);bpoke(i+0x17F,106);
bpoke(i+0x184,154);bpoke(i+0x185,90);bpoke(i+0x19D,85);bpoke(i+0x19E,86);
bpoke(i+0x1A4,90);bpoke(i+0x1A5,90);bpoke(i+0x1B5,85);bpoke(i+0x1B8,154);
bpoke(i+0x1BD,149);bpoke(i+0x1BE,86);bpoke(i+0x1C4,150);bpoke(i+0x1C5,90);bpoke(i+0x1C6,106);
bpoke(i+0x1D4,165);bpoke(i+0x1D5,85);bpoke(i+0x1D6,90);bpoke(i+0x1D8,154);bpoke(i+0x1D9,106);
bpoke(i+0x1DD,149);bpoke(i+0x1DE,85);bpoke(i+0x1E4,149);bpoke(i+0x1E5,85);bpoke(i+0x1E6,106);
bpoke(i+0x1F4,149);bpoke(i+0x1F5,85);bpoke(i+0x1F7,154);bpoke(i+0x1F8,89);bpoke(i+0x1FD,149);
bpoke(i+0x1FE,86);bpoke(i+0x204,149);bpoke(i+0x205,85);bpoke(i+0x206,106);
bpoke(i+0x214,85);bpoke(i+0x215,85);bpoke(i+0x216,86);bpoke(i+0x217,150);bpoke(i+0x218,153);bpoke(i+0x219,166);
bpoke(i+0x21D,149);bpoke(i+0x21E,86);
bpoke(i+0x222,169);bpoke(i+0x223,106);bpoke(i+0x224,149);bpoke(i+0x225,85);bpoke(i+0x226,86);
bpoke(i+0x233,149);bpoke(i+0x234,85);bpoke(i+0x235,85);bpoke(i+0x236,106);bpoke(i+0x237,166);bpoke(i+0x238,86);bpoke(i+0x239,90);
bpoke(i+0x23D,85);bpoke(i+0x23E,85);bpoke(i+0x23F,106);
bpoke(i+0x242,169);bpoke(i+0x243,86);bpoke(i+0x244,85);bpoke(i+0x245,85);
bpoke(i+0x246,90);bpoke(i+0x252,101);bpoke(i+0x253,85);bpoke(i+0x254,85);bpoke(i+0x255,102);bpoke(i+0x257,165);
bpoke(i+0x258,85);bpoke(i+0x259,106);bpoke(i+0x25D,149);
bpoke(i+0x25E,85);bpoke(i+0x263,165);
bpoke(i+0x264,85);bpoke(i+0x265,85);bpoke(i+0x266,90);
bpoke(i+0x271,169);bpoke(i+0x272,85);bpoke(i+0x273,85);bpoke(i+0x274,86);
bpoke(i+0x276,153);bpoke(i+0x277,165);bpoke(i+0x278,85);
bpoke(i+0x27D,149);bpoke(i+0x27E,85);bpoke(i+0x27F,106);
bpoke(i+0x283,165);bpoke(i+0x284,85);bpoke(i+0x285,85);bpoke(i+0x286,90);
bpoke(i+0x291,165);bpoke(i+0x292,85);bpoke(i+0x293,85);
bpoke(i+0x294,90);bpoke(i+0x296,169);bpoke(i+0x297,85);bpoke(i+0x298,85);bpoke(i+0x299,106);
bpoke(i+0x29D,85);bpoke(i+0x29E,85);
bpoke(i+0x2A4,85);bpoke(i+0x2A5,85);bpoke(i+0x2A6,106);bpoke(i+0x2B1,165);
bpoke(i+0x2B2,85);bpoke(i+0x2B3,85);bpoke(i+0x2B7,85);
bpoke(i+0x2B8,85);bpoke(i+0x2BD,149);bpoke(i+0x2BE,85);bpoke(i+0x2BF,106);
bpoke(i+0x2C4,149);bpoke(i+0x2C5,85);bpoke(i+0x2D1,149);bpoke(i+0x2D2,85);bpoke(i+0x2D3,85);
bpoke(i+0x2D7,149);bpoke(i+0x2D8,86);
bpoke(i+0x2DD,149);bpoke(i+0x2DE,85);bpoke(i+0x2DF,106);
bpoke(i+0x2E4,149);bpoke(i+0x2E5,86);
bpoke(i+0x2EA,166);bpoke(i+0x2EC,169);bpoke(i+0x2ED,85);
bpoke(i+0x2EE,90);bpoke(i+0x2F1,85);bpoke(i+0x2F2,85);bpoke(i+0x2F3,86);
bpoke(i+0x2F7,165);bpoke(i+0x2F8,86);
bpoke(i+0x2FD,85);bpoke(i+0x2FE,85);bpoke(i+0x2FF,106);
bpoke(i+0x304,149);bpoke(i+0x305,85);
bpoke(i+0x30A,105);bpoke(i+0x30B,166);
bpoke(i+0x30C,169);bpoke(i+0x30D,85);bpoke(i+0x30E,86);bpoke(i+0x311,85);
bpoke(i+0x312,85);bpoke(i+0x313,106);bpoke(i+0x316,106);bpoke(i+0x317,101);
bpoke(i+0x318,86);bpoke(i+0x31D,149);
bpoke(i+0x31E,85);bpoke(i+0x31F,90);
bpoke(i+0x324,149);bpoke(i+0x325,86);
bpoke(i+0x32A,101);bpoke(i+0x32B,166);bpoke(i+0x32C,154);bpoke(i+0x32D,85);bpoke(i+0x32E,85);
bpoke(i+0x330,169);bpoke(i+0x331,85);bpoke(i+0x332,85);bpoke(i+0x333,106);bpoke(i+0x335,105);
bpoke(i+0x336,105);bpoke(i+0x337,169);bpoke(i+0x338,86);
bpoke(i+0x33D,149);bpoke(i+0x33E,85);bpoke(i+0x33F,90);
bpoke(i+0x344,149);bpoke(i+0x345,85);
bpoke(i+0x349,166);bpoke(i+0x34A,89);bpoke(i+0x34B,166);bpoke(i+0x34C,165);bpoke(i+0x34D,85);
bpoke(i+0x34E,85);bpoke(i+0x34F,102);bpoke(i+0x350,165);bpoke(i+0x351,85);bpoke(i+0x352,85);
bpoke(i+0x354,169);bpoke(i+0x355,165);bpoke(i+0x356,149);bpoke(i+0x357,169);bpoke(i+0x358,85);
bpoke(i+0x35D,149);bpoke(i+0x35E,85);bpoke(i+0x35F,90);
bpoke(i+0x364,85);bpoke(i+0x365,85);
bpoke(i+0x366,85);bpoke(i+0x369,169);bpoke(i+0x36A,149);bpoke(i+0x36B,86);
bpoke(i+0x36D,85);bpoke(i+0x36E,85);bpoke(i+0x36F,85);bpoke(i+0x370,149);bpoke(i+0x371,85);
bpoke(i+0x372,85);bpoke(i+0x374,169);bpoke(i+0x375,102);bpoke(i+0x376,86);bpoke(i+0x377,149);
bpoke(i+0x378,86);bpoke(i+0x37D,149);
bpoke(i+0x37E,85);bpoke(i+0x37F,86);



	j = scr-(5*32) - k;


bpoke(j+0x00D,175);bpoke(j+0x00E,171);bpoke(j+0x02D,175);bpoke(j+0x02E,175);bpoke(j+0x04D,171);bpoke(j+0x04E,175);
bpoke(j+0x06C,171);bpoke(j+0x06D,175);bpoke(j+0x06E,175);bpoke(j+0x08C,171);bpoke(j+0x08D,239);bpoke(j+0x08E,254);
bpoke(j+0x0AD,255);bpoke(j+0x0AE,254);bpoke(j+0x0CC,175);bpoke(j+0x0CD,255);bpoke(j+0x0CE,254);bpoke(j+0x0CF,171);
bpoke(j+0x0EC,191);bpoke(j+0x0ED,255);bpoke(j+0x0EE,255);bpoke(j+0x0EF,255);
bpoke(j+0x10C,175);bpoke(j+0x10D,255);bpoke(j+0x10E,255);bpoke(j+0x10F,255);
bpoke(j+0x12C,171);bpoke(j+0x12D,255);bpoke(j+0x12E,255);bpoke(j+0x12F,250);bpoke(j+0x135,234);
bpoke(j+0x14C,171);bpoke(j+0x14D,255);bpoke(j+0x14E,255);bpoke(j+0x14F,234);
bpoke(j+0x153,171);bpoke(j+0x154,235);bpoke(j+0x155,234);
bpoke(j+0x16D,255);bpoke(j+0x16E,254);bpoke(j+0x174,235);bpoke(j+0x175,234);
bpoke(j+0x185,255);bpoke(j+0x188,186);bpoke(j+0x18D,191);bpoke(j+0x18E,254);
bpoke(j+0x193,171);bpoke(j+0x194,235);bpoke(j+0x195,234);
bpoke(j+0x1A4,175);bpoke(j+0x1A5,255);bpoke(j+0x1A6,250);bpoke(j+0x1A8,186);bpoke(j+0x1A9,234);
bpoke(j+0x1AD,191);bpoke(j+0x1AE,255);bpoke(j+0x1B4,251);bpoke(j+0x1B5,235);
bpoke(j+0x1C4,191);bpoke(j+0x1C5,255);bpoke(j+0x1C7,186);
bpoke(j+0x1C8,251);bpoke(j+0x1CD,191);bpoke(j+0x1CE,254);bpoke(j+0x1D4,255);bpoke(j+0x1D5,255);
bpoke(j+0x1E4,255);bpoke(j+0x1E5,255);bpoke(j+0x1E6,254);bpoke(j+0x1E7,190);bpoke(j+0x1E8,187);bpoke(j+0x1E9,174);
bpoke(j+0x1ED,191);bpoke(j+0x1EE,254);bpoke(j+0x1F4,255);bpoke(j+0x1F5,255);
bpoke(j+0x203,191);bpoke(j+0x204,255);bpoke(j+0x205,255);bpoke(j+0x206,234);bpoke(j+0x207,174);bpoke(j+0x208,254);bpoke(j+0x209,250);
bpoke(j+0x20D,255);bpoke(j+0x20E,255);bpoke(j+0x20F,234);
bpoke(j+0x212,175);bpoke(j+0x214,255);bpoke(j+0x215,255);bpoke(j+0x216,250);
bpoke(j+0x222,239);bpoke(j+0x223,255);bpoke(j+0x224,255);bpoke(j+0x225,238);bpoke(j+0x227,175);
bpoke(j+0x228,255);bpoke(j+0x229,234);bpoke(j+0x22D,191);bpoke(j+0x22E,255);bpoke(j+0x232,175);bpoke(j+0x233,251);
bpoke(j+0x234,255);bpoke(j+0x235,255);bpoke(j+0x236,234);
bpoke(j+0x241,171);bpoke(j+0x242,255);bpoke(j+0x243,255);bpoke(j+0x244,254);
bpoke(j+0x246,187);bpoke(j+0x247,175);bpoke(j+0x248,255);
bpoke(j+0x24D,191);bpoke(j+0x24E,255);bpoke(j+0x24F,234);
bpoke(j+0x253,191);bpoke(j+0x254,255);bpoke(j+0x255,255);bpoke(j+0x256,234);
bpoke(j+0x261,175);bpoke(j+0x262,255);bpoke(j+0x263,255);
bpoke(j+0x264,250);bpoke(j+0x266,171);bpoke(j+0x267,255);bpoke(j+0x268,255);bpoke(j+0x269,234);
bpoke(j+0x26D,255);bpoke(j+0x26E,255);bpoke(j+0x273,191);bpoke(j+0x274,255);bpoke(j+0x275,255);
bpoke(j+0x276,234);bpoke(j+0x281,175);bpoke(j+0x282,255);bpoke(j+0x283,255);bpoke(j+0x287,255);
bpoke(j+0x288,255);bpoke(j+0x28D,191);bpoke(j+0x28E,255);bpoke(j+0x28F,234);bpoke(j+0x293,171);
bpoke(j+0x294,255);bpoke(j+0x295,255);bpoke(j+0x2A1,191);bpoke(j+0x2A2,255);bpoke(j+0x2A3,255);
bpoke(j+0x2A7,191);bpoke(j+0x2A8,254);bpoke(j+0x2AD,191);bpoke(j+0x2AE,255);bpoke(j+0x2AF,234);
bpoke(j+0x2B4,255);bpoke(j+0x2B5,254);bpoke(j+0x2C1,255);bpoke(j+0x2C2,255);bpoke(j+0x2C3,254);
bpoke(j+0x2C7,175);bpoke(j+0x2C8,254);bpoke(j+0x2CD,255);bpoke(j+0x2CE,255);bpoke(j+0x2CF,234);
bpoke(j+0x2D4,255);bpoke(j+0x2D5,250);bpoke(j+0x2DA,186);
bpoke(j+0x2DC,175);bpoke(j+0x2DD,255);bpoke(j+0x2DE,234);bpoke(j+0x2E1,255);
bpoke(j+0x2E2,255);bpoke(j+0x2E3,234);bpoke(j+0x2E6,234);bpoke(j+0x2E7,239);
bpoke(j+0x2E8,254);bpoke(j+0x2ED,191);bpoke(j+0x2EE,255);bpoke(j+0x2EF,250);
bpoke(j+0x2F4,255);bpoke(j+0x2F5,254);bpoke(j+0x2F9,171);bpoke(j+0x2FA,174);bpoke(j+0x2FB,186);
bpoke(j+0x2FC,175);bpoke(j+0x2FD,255);bpoke(j+0x2FE,250);
bpoke(j+0x300,171);bpoke(j+0x301,255);bpoke(j+0x302,255);bpoke(j+0x303,234);bpoke(j+0x305,235);
bpoke(j+0x306,235);bpoke(j+0x307,171);bpoke(j+0x308,254);
bpoke(j+0x30D,191);bpoke(j+0x30E,255);bpoke(j+0x30F,250);
bpoke(j+0x314,255);bpoke(j+0x315,250);bpoke(j+0x319,171);bpoke(j+0x31A,190);bpoke(j+0x31B,186);bpoke(j+0x31C,235);bpoke(j+0x31D,255);
bpoke(j+0x31E,254);bpoke(j+0x320,175);bpoke(j+0x321,255);bpoke(j+0x322,255);
bpoke(j+0x324,171);bpoke(j+0x325,175);bpoke(j+0x326,191);bpoke(j+0x327,171);bpoke(j+0x328,255);
bpoke(j+0x32D,191);bpoke(j+0x32E,255);bpoke(j+0x32F,250);
bpoke(j+0x334,255);bpoke(j+0x335,254);bpoke(j+0x339,187);bpoke(j+0x33A,238);bpoke(j+0x33B,186);
bpoke(j+0x33C,191);bpoke(j+0x33D,255);bpoke(j+0x33E,255);bpoke(j+0x33F,186);bpoke(j+0x340,191);bpoke(j+0x341,255);
bpoke(j+0x342,255);bpoke(j+0x344,171);bpoke(j+0x345,238);bpoke(j+0x346,254);bpoke(j+0x347,191);
bpoke(j+0x348,254);bpoke(j+0x34D,191);bpoke(j+0x34E,255);bpoke(j+0x34F,254);bpoke(j+0x353,171);
bpoke(j+0x354,255);bpoke(j+0x355,255);bpoke(j+0x356,254);bpoke(j+0x359,174);
bpoke(j+0x35A,255);bpoke(j+0x35B,250);bpoke(j+0x35C,171);bpoke(j+0x35D,255);bpoke(j+0x35E,255);bpoke(j+0x35F,254);
bpoke(j+0x360,255);bpoke(j+0x361,255);bpoke(j+0x362,254);bpoke(j+0x364,175);bpoke(j+0x365,255);
bpoke(j+0x366,238);bpoke(j+0x367,255);bpoke(j+0x368,255);
bpoke(j+0x36D,175);bpoke(j+0x36E,255);bpoke(j+0x36F,255);bpoke(j+0x370,234);bpoke(j+0x371,250);
bpoke(j+0x373,171);bpoke(j+0x374,255);bpoke(j+0x375,255);bpoke(j+0x376,255);bpoke(j+0x377,234);
bpoke(j+0x379,175);bpoke(j+0x37A,255);bpoke(j+0x37B,234);bpoke(j+0x37D,171);
bpoke(j+0x37E,255);bpoke(j+0x37F,255);

	vz_setbase(0x7000);
//	memmove(0x7000,scr, 2048);
	memcpy(scr, 0x7000, 2048);

	}
}






int main()
{
	int i;
	int j;
	int k;
	int l;
	int m;
	int quit;

	quit = 0;

	while (quit == 0) {
	intro();
	}	
}
