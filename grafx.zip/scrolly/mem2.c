#include <sound.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <vz.h>
#include <graphics.h>
#include <strings.h>


#define _src1	0x7000
#define _src2	0xe000
#define _dst1	0x7000
#define _dst2	0xe000



	int duration;
	int keyboard;









//
//; ----- int memset(char *dst, int chr, int size);
//	.globl	memset
//memset: push	ix
//        ld      ix, #0
//        add     ix, sp
//	ld	c,4(ix) 	; get size
//	ld	b,5(ix)
//	ld	e,6(ix) 	; get chr
//	ld	l,8(ix) 	; get *dst
//	ld	h,9(ix)
//mset1:	ld	(hl), e
//	inc	hl
//	dec	bc
//	ld	a, b
//	or	c
//	jr	nz, mset1
//	pop	ix
//	ret
//





//void memfill(int addr, int numbytes, char value)
//{
//        asm{
//                LD      L,(IX-05)
//                LD      H,(IX-04)
//                LD      C,(IX-03)
//                LD      B,(IX-02)
//MEMFILL1:  
//                LD      A,(IX-01)
//                LD      (HL),A
//                INC     HL
//                DEC     BC
//                LD      A,B
//                OR      C
//                JR      NZ,MEMFILL1
//            };
//}


//memcpy(int saddr, int daddr, int numbytes)
//{
//#asm
//	push	ix
//        ld      ix, #0
//        add     ix, sp
//	ld	c,4(ix) 	; get size
//	ld	b,5(ix)
//	ld	l,6(ix) 	; get *src
//	ld	h,7(ix)
//	ld	e,8(ix) 	; get *dst
//	ld	d,9(ix)
//	ldir
//	pop	ix
//	ret
//#endasm
//}





intro()
{
	int	i;
	int	j;
	int	k;
    	vz_mode(1);
    	asm("di\n");


       	for (k=0;k<32;k++)
        {

        i=k+28672;


	vz_setbase(0x7000);
//	vz_setbase(0xd000);
	memset(0x7000, 255, 2048);
//	memset(0x7000, 255, 2048);




bpoke(i+0x006,239);bpoke(i+0x00B,239);bpoke(i+0x025,254);bpoke(i+0x026,175);
bpoke(i+0x02B,154);bpoke(i+0x045,249);bpoke(i+0x046,91);
bpoke(i+0x04A,254);bpoke(i+0x04B,85);bpoke(i+0x04C,175);bpoke(i+0x065,165);
bpoke(i+0x066,91);bpoke(i+0x06A,254);bpoke(i+0x06B,85);bpoke(i+0x06C,90);
bpoke(i+0x084,254);bpoke(i+0x085,85);bpoke(i+0x086,86);
bpoke(i+0x08A,254);bpoke(i+0x08B,86);bpoke(i+0x08C,85);bpoke(i+0x08D,175);
bpoke(i+0x0A4,233);bpoke(i+0x0A5,86);bpoke(i+0x0A6,85);bpoke(i+0x0A7,191);
bpoke(i+0x0AA,254);bpoke(i+0x0AB,91);bpoke(i+0x0AC,165);bpoke(i+0x0AD,91);
bpoke(i+0x0C4,149);bpoke(i+0x0C5,106);
bpoke(i+0x0C6,85);bpoke(i+0x0C7,111);bpoke(i+0x0CA,249);bpoke(i+0x0CB,91);
bpoke(i+0x0CC,250);bpoke(i+0x0CD,86);bpoke(i+0x0CE,191);bpoke(i+0x0E3,250);
bpoke(i+0x0E4,85);bpoke(i+0x0E5,190);bpoke(i+0x0E6,85);bpoke(i+0x0E7,111);
bpoke(i+0x0EA,249);bpoke(i+0x0EB,91);bpoke(i+0x0ED,165);bpoke(i+0x0EE,107);
bpoke(i+0x0F2,234);bpoke(i+0x0F3,170);
bpoke(i+0x103,229);bpoke(i+0x104,90);bpoke(i+0x106,149);bpoke(i+0x107,91);
bpoke(i+0x10A,229);bpoke(i+0x10B,111);bpoke(i+0x10D,250);
bpoke(i+0x10E,86);bpoke(i+0x10F,191);bpoke(i+0x112,149);bpoke(i+0x113,85);
bpoke(i+0x114,170);bpoke(i+0x115,170);bpoke(i+0x123,149);bpoke(i+0x124,111);
bpoke(i+0x126,149);bpoke(i+0x127,91);bpoke(i+0x12A,229);bpoke(i+0x12B,111);
bpoke(i+0x12E,165);bpoke(i+0x12F,107);bpoke(i+0x132,149);bpoke(i+0x133,85);
bpoke(i+0x134,85);bpoke(i+0x135,85);bpoke(i+0x136,170);
bpoke(i+0x137,170);bpoke(i+0x138,191);bpoke(i+0x142,250);bpoke(i+0x143,86);
bpoke(i+0x144,191);bpoke(i+0x146,149);bpoke(i+0x147,86);
bpoke(i+0x14A,229);bpoke(i+0x14B,191);bpoke(i+0x14E,249);bpoke(i+0x14F,86);
bpoke(i+0x151,254);bpoke(i+0x152,85);bpoke(i+0x153,85);bpoke(i+0x154,85);bpoke(i+0x155,85);
bpoke(i+0x156,85);bpoke(i+0x157,85);bpoke(i+0x158,106);bpoke(i+0x159,170);bpoke(i+0x15A,191);
bpoke(i+0x162,229);bpoke(i+0x163,91);bpoke(i+0x166,149);bpoke(i+0x167,86);
bpoke(i+0x16A,149);bpoke(i+0x16B,191);
bpoke(i+0x16E,229);bpoke(i+0x16F,85);bpoke(i+0x170,191);bpoke(i+0x171,249);bpoke(i+0x172,86);bpoke(i+0x173,170);
bpoke(i+0x174,149);bpoke(i+0x175,85);bpoke(i+0x176,85);bpoke(i+0x177,85);bpoke(i+0x178,85);bpoke(i+0x179,85);
bpoke(i+0x17A,106);bpoke(i+0x17B,170);bpoke(i+0x17C,170);bpoke(i+0x17D,175);
bpoke(i+0x181,254);bpoke(i+0x182,149);bpoke(i+0x183,175);
bpoke(i+0x186,229);bpoke(i+0x187,85);bpoke(i+0x188,191);bpoke(i+0x18A,150);
bpoke(i+0x18E,229);bpoke(i+0x18F,85);bpoke(i+0x190,111);bpoke(i+0x191,249);
bpoke(i+0x192,91);bpoke(i+0x194,234);bpoke(i+0x195,170);bpoke(i+0x196,169);bpoke(i+0x197,85);
bpoke(i+0x198,85);bpoke(i+0x199,85);bpoke(i+0x19A,85);bpoke(i+0x19B,85);bpoke(i+0x19C,85);bpoke(i+0x19D,90);
bpoke(i+0x1A1,249);bpoke(i+0x1A2,86);
bpoke(i+0x1A6,229);bpoke(i+0x1A7,85);bpoke(i+0x1A8,191);bpoke(i+0x1A9,254);
bpoke(i+0x1AA,86);bpoke(i+0x1AC,175);bpoke(i+0x1AE,149);bpoke(i+0x1AF,85);
bpoke(i+0x1B0,91);bpoke(i+0x1B1,229);bpoke(i+0x1B2,91);
bpoke(i+0x1B6,254);bpoke(i+0x1B7,170);bpoke(i+0x1B8,170);bpoke(i+0x1B9,165);bpoke(i+0x1BA,85);bpoke(i+0x1BB,85);
bpoke(i+0x1BC,85);bpoke(i+0x1BD,85);bpoke(i+0x1BE,191);bpoke(i+0x1C1,165);
bpoke(i+0x1C2,107);bpoke(i+0x1C5,191);bpoke(i+0x1C6,229);bpoke(i+0x1C7,85);
bpoke(i+0x1C8,111);bpoke(i+0x1C9,254);bpoke(i+0x1CA,86);bpoke(i+0x1CB,254);bpoke(i+0x1CC,90);
bpoke(i+0x1CE,149);bpoke(i+0x1CF,85);bpoke(i+0x1D0,91);bpoke(i+0x1D1,149);bpoke(i+0x1D2,111);
bpoke(i+0x1D4,191);bpoke(i+0x1D9,250);
bpoke(i+0x1DA,170);bpoke(i+0x1DB,170);bpoke(i+0x1DC,169);bpoke(i+0x1DD,85);bpoke(i+0x1DE,111);
bpoke(i+0x1E0,254);bpoke(i+0x1E1,85);bpoke(i+0x1E2,191);bpoke(i+0x1E4,250);bpoke(i+0x1E5,191);
bpoke(i+0x1E6,249);bpoke(i+0x1E7,85);bpoke(i+0x1E8,111);bpoke(i+0x1E9,254);bpoke(i+0x1EA,91);bpoke(i+0x1EB,254);
bpoke(i+0x1EC,85);bpoke(i+0x1ED,175);bpoke(i+0x1EE,149);bpoke(i+0x1EF,85);bpoke(i+0x1F0,86);bpoke(i+0x1F1,149);
bpoke(i+0x1F2,191);bpoke(i+0x1F3,254);bpoke(i+0x1F4,106);bpoke(i+0x1F5,175);
bpoke(i+0x1FC,254);bpoke(i+0x1FD,165);
bpoke(i+0x1FE,91);bpoke(i+0x200,233);bpoke(i+0x201,90);
bpoke(i+0x204,229);bpoke(i+0x205,111);bpoke(i+0x206,249);bpoke(i+0x207,85);bpoke(i+0x208,111);bpoke(i+0x209,249);
bpoke(i+0x20A,91);bpoke(i+0x20B,254);bpoke(i+0x20C,85);bpoke(i+0x20D,90);bpoke(i+0x20E,85);bpoke(i+0x20F,85);
bpoke(i+0x210,86);bpoke(i+0x211,85);bpoke(i+0x212,191);bpoke(i+0x213,249);bpoke(i+0x214,85);bpoke(i+0x215,90);
bpoke(i+0x216,171);
bpoke(i+0x21D,233);bpoke(i+0x21E,86);bpoke(i+0x220,149);bpoke(i+0x221,111);
bpoke(i+0x224,149);bpoke(i+0x225,111);bpoke(i+0x226,254);bpoke(i+0x227,85);
bpoke(i+0x228,91);bpoke(i+0x229,249);bpoke(i+0x22A,91);bpoke(i+0x22B,254);bpoke(i+0x22C,85);bpoke(i+0x22D,85);
bpoke(i+0x22E,85);bpoke(i+0x22F,85);bpoke(i+0x230,86);bpoke(i+0x231,86);bpoke(i+0x233,249);
bpoke(i+0x234,85);bpoke(i+0x235,85);bpoke(i+0x236,86);bpoke(i+0x237,170);bpoke(i+0x238,191);
bpoke(i+0x23D,249);bpoke(i+0x23E,85);bpoke(i+0x23F,191);
bpoke(i+0x240,229);bpoke(i+0x241,111);bpoke(i+0x243,250);bpoke(i+0x244,85);bpoke(i+0x245,111);
bpoke(i+0x246,254);bpoke(i+0x247,85);bpoke(i+0x248,91);bpoke(i+0x249,229);bpoke(i+0x24A,111);bpoke(i+0x24B,254);
bpoke(i+0x24C,85);bpoke(i+0x24D,85);bpoke(i+0x24E,85);bpoke(i+0x24F,85);bpoke(i+0x250,89);bpoke(i+0x251,86);
bpoke(i+0x253,249);bpoke(i+0x254,85);bpoke(i+0x255,85);bpoke(i+0x256,85);bpoke(i+0x257,85);
bpoke(i+0x258,106);bpoke(i+0x259,170);bpoke(i+0x25D,249);
bpoke(i+0x25E,85);bpoke(i+0x25F,191);bpoke(i+0x260,249);bpoke(i+0x261,91);bpoke(i+0x263,229);
bpoke(i+0x264,85);bpoke(i+0x265,111);bpoke(i+0x267,149);bpoke(i+0x268,86);bpoke(i+0x269,165);
bpoke(i+0x26A,111);bpoke(i+0x26B,249);bpoke(i+0x26C,85);bpoke(i+0x26D,85);bpoke(i+0x26E,85);bpoke(i+0x26F,85);
bpoke(i+0x270,101);bpoke(i+0x271,91);bpoke(i+0x273,229);bpoke(i+0x274,85);bpoke(i+0x275,85);
bpoke(i+0x276,85);bpoke(i+0x277,85);bpoke(i+0x278,85);bpoke(i+0x279,85);bpoke(i+0x27A,171);
bpoke(i+0x27D,229);bpoke(i+0x27E,85);bpoke(i+0x27F,111);bpoke(i+0x280,254);bpoke(i+0x281,91);
bpoke(i+0x283,149);bpoke(i+0x284,85);bpoke(i+0x285,91);bpoke(i+0x287,149);
bpoke(i+0x288,85);bpoke(i+0x289,85);bpoke(i+0x28A,191);bpoke(i+0x28B,249);bpoke(i+0x28C,85);bpoke(i+0x28D,85);
bpoke(i+0x28E,85);bpoke(i+0x28F,85);bpoke(i+0x290,101);bpoke(i+0x291,111);bpoke(i+0x293,149);
bpoke(i+0x294,85);bpoke(i+0x295,85);bpoke(i+0x296,85);bpoke(i+0x297,85);bpoke(i+0x298,85);bpoke(i+0x299,86);
bpoke(i+0x29A,175);bpoke(i+0x29D,165);bpoke(i+0x29E,85);bpoke(i+0x29F,91);
bpoke(i+0x2A1,150);bpoke(i+0x2A2,250);bpoke(i+0x2A3,85);bpoke(i+0x2A4,85);bpoke(i+0x2A5,91);
bpoke(i+0x2A7,149);bpoke(i+0x2A8,85);bpoke(i+0x2A9,85);bpoke(i+0x2AA,191);bpoke(i+0x2AB,249);
bpoke(i+0x2AC,85);bpoke(i+0x2AD,85);bpoke(i+0x2AE,85);bpoke(i+0x2AF,85);bpoke(i+0x2B0,149);bpoke(i+0x2B1,111);
bpoke(i+0x2B3,149);bpoke(i+0x2B4,85);bpoke(i+0x2B5,85);bpoke(i+0x2B6,85);bpoke(i+0x2B7,85);
bpoke(i+0x2B8,85);bpoke(i+0x2B9,91);bpoke(i+0x2BC,170);bpoke(i+0x2BD,85);
bpoke(i+0x2BE,85);bpoke(i+0x2BF,86);bpoke(i+0x2C1,229);bpoke(i+0x2C2,165);bpoke(i+0x2C3,85);
bpoke(i+0x2C4,85);bpoke(i+0x2C5,91);bpoke(i+0x2C7,229);bpoke(i+0x2C8,85);bpoke(i+0x2C9,85);
bpoke(i+0x2CA,191);bpoke(i+0x2CB,249);bpoke(i+0x2CC,85);bpoke(i+0x2CD,85);bpoke(i+0x2CE,85);bpoke(i+0x2CF,86);
bpoke(i+0x2D0,85);bpoke(i+0x2D1,170);bpoke(i+0x2D2,254);bpoke(i+0x2D3,85);bpoke(i+0x2D4,85);bpoke(i+0x2D5,85);
bpoke(i+0x2D6,85);bpoke(i+0x2D7,85);bpoke(i+0x2D8,85);bpoke(i+0x2D9,175);bpoke(i+0x2DB,250);
bpoke(i+0x2DC,85);bpoke(i+0x2DD,85);bpoke(i+0x2DE,85);bpoke(i+0x2DF,86);bpoke(i+0x2E1,249);
bpoke(i+0x2E2,85);bpoke(i+0x2E3,85);bpoke(i+0x2E4,85);bpoke(i+0x2E5,91);bpoke(i+0x2E7,229);
bpoke(i+0x2E8,85);bpoke(i+0x2E9,85);bpoke(i+0x2EA,191);bpoke(i+0x2EB,229);bpoke(i+0x2EC,85);bpoke(i+0x2ED,85);
bpoke(i+0x2EE,85);bpoke(i+0x2EF,86);bpoke(i+0x2F0,85);bpoke(i+0x2F1,85);bpoke(i+0x2F2,169);bpoke(i+0x2F3,85);
bpoke(i+0x2F4,85);bpoke(i+0x2F5,85);bpoke(i+0x2F6,85);bpoke(i+0x2F7,85);bpoke(i+0x2F8,90);
bpoke(i+0x2FB,165);bpoke(i+0x2FC,85);bpoke(i+0x2FD,85);bpoke(i+0x2FE,85);bpoke(i+0x2FF,86);
bpoke(i+0x301,254);bpoke(i+0x302,85);bpoke(i+0x303,85);bpoke(i+0x304,85);bpoke(i+0x305,86);
bpoke(i+0x307,229);bpoke(i+0x308,85);bpoke(i+0x309,86);bpoke(i+0x30B,229);
bpoke(i+0x30C,85);bpoke(i+0x30D,85);bpoke(i+0x30E,165);bpoke(i+0x30F,90);bpoke(i+0x310,85);bpoke(i+0x311,85);
bpoke(i+0x312,85);bpoke(i+0x313,85);bpoke(i+0x314,85);bpoke(i+0x315,86);bpoke(i+0x316,85);bpoke(i+0x317,85);
bpoke(i+0x318,111);bpoke(i+0x31A,254);bpoke(i+0x31B,85);bpoke(i+0x31C,85);bpoke(i+0x31D,85);
bpoke(i+0x31E,85);bpoke(i+0x31F,86);bpoke(i+0x321,254);bpoke(i+0x322,85);bpoke(i+0x323,85);
bpoke(i+0x324,85);bpoke(i+0x325,86);bpoke(i+0x327,249);bpoke(i+0x328,85);bpoke(i+0x329,86);
bpoke(i+0x32B,229);bpoke(i+0x32C,85);bpoke(i+0x32D,85);bpoke(i+0x32E,186);bpoke(i+0x32F,86);
bpoke(i+0x330,149);bpoke(i+0x331,85);bpoke(i+0x332,85);bpoke(i+0x333,85);bpoke(i+0x334,85);bpoke(i+0x335,91);
bpoke(i+0x336,170);bpoke(i+0x337,85);bpoke(i+0x338,191);bpoke(i+0x33A,233);bpoke(i+0x33B,85);
bpoke(i+0x33C,85);bpoke(i+0x33D,85);bpoke(i+0x33E,85);bpoke(i+0x33F,86);
bpoke(i+0x342,149);bpoke(i+0x343,85);bpoke(i+0x344,85);bpoke(i+0x345,86);bpoke(i+0x347,249);
bpoke(i+0x348,85);bpoke(i+0x349,91);bpoke(i+0x34B,229);bpoke(i+0x34C,85);bpoke(i+0x34D,86);
bpoke(i+0x34F,171);bpoke(i+0x350,229);bpoke(i+0x351,85);bpoke(i+0x352,85);bpoke(i+0x353,85);
bpoke(i+0x354,85);bpoke(i+0x355,91);bpoke(i+0x356,249);bpoke(i+0x357,86);bpoke(i+0x359,254);
bpoke(i+0x35A,149);bpoke(i+0x35B,85);bpoke(i+0x35C,85);bpoke(i+0x35D,85);bpoke(i+0x35E,85);bpoke(i+0x35F,86);
bpoke(i+0x362,229);bpoke(i+0x363,85);bpoke(i+0x364,85);bpoke(i+0x365,85);
bpoke(i+0x366,191);bpoke(i+0x367,249);bpoke(i+0x368,85);bpoke(i+0x369,91);bpoke(i+0x36B,149);
bpoke(i+0x36C,85);bpoke(i+0x36D,86);bpoke(i+0x370,249);bpoke(i+0x371,85);
bpoke(i+0x372,85);bpoke(i+0x373,85);bpoke(i+0x374,85);bpoke(i+0x375,91);bpoke(i+0x376,165);bpoke(i+0x377,107);
bpoke(i+0x379,233);bpoke(i+0x37A,85);bpoke(i+0x37B,85);bpoke(i+0x37C,85);bpoke(i+0x37D,85);
bpoke(i+0x37E,85);bpoke(i+0x37F,91);bpoke(i+0x382,249);bpoke(i+0x383,85);
bpoke(i+0x384,85);bpoke(i+0x385,85);bpoke(i+0x386,191);bpoke(i+0x387,249);bpoke(i+0x388,85);bpoke(i+0x389,91);
bpoke(i+0x38B,149);bpoke(i+0x38C,85);bpoke(i+0x38D,86);
bpoke(i+0x390,249);bpoke(i+0x391,85);bpoke(i+0x392,85);bpoke(i+0x393,85);bpoke(i+0x394,85);bpoke(i+0x395,110);
bpoke(i+0x396,85);bpoke(i+0x397,191);bpoke(i+0x399,149);bpoke(i+0x39A,85);bpoke(i+0x39B,85);
bpoke(i+0x39C,85);bpoke(i+0x39D,85);bpoke(i+0x39E,85);bpoke(i+0x39F,91);
bpoke(i+0x3A2,254);bpoke(i+0x3A3,85);bpoke(i+0x3A4,85);bpoke(i+0x3A5,149);bpoke(i+0x3A6,191);bpoke(i+0x3A7,254);
bpoke(i+0x3A8,85);bpoke(i+0x3A9,111);bpoke(i+0x3AA,254);bpoke(i+0x3AB,85);bpoke(i+0x3AC,85);bpoke(i+0x3AD,91);
bpoke(i+0x3B0,254);bpoke(i+0x3B1,85);bpoke(i+0x3B2,85);bpoke(i+0x3B3,85);
bpoke(i+0x3B4,85);bpoke(i+0x3B5,105);bpoke(i+0x3B6,86);bpoke(i+0x3B8,254);bpoke(i+0x3B9,85);
bpoke(i+0x3BA,85);bpoke(i+0x3BB,85);bpoke(i+0x3BC,85);bpoke(i+0x3BD,85);bpoke(i+0x3BE,86);bpoke(i+0x3BF,175);
bpoke(i+0x3C3,165);bpoke(i+0x3C4,86);bpoke(i+0x3C5,149);
bpoke(i+0x3C6,191);bpoke(i+0x3C7,254);bpoke(i+0x3C8,85);bpoke(i+0x3C9,111);bpoke(i+0x3CA,254);bpoke(i+0x3CB,85);
bpoke(i+0x3CC,85);bpoke(i+0x3CD,91);bpoke(i+0x3D1,149);
bpoke(i+0x3D2,85);bpoke(i+0x3D3,85);bpoke(i+0x3D4,85);bpoke(i+0x3D5,165);bpoke(i+0x3D6,107);
bpoke(i+0x3D8,233);bpoke(i+0x3D9,85);bpoke(i+0x3DA,85);bpoke(i+0x3DB,85);bpoke(i+0x3DC,85);bpoke(i+0x3DD,85);
bpoke(i+0x3DE,107);bpoke(i+0x3E3,249);
bpoke(i+0x3E4,91);bpoke(i+0x3E5,149);bpoke(i+0x3E6,111);bpoke(i+0x3E7,254);bpoke(i+0x3E8,85);bpoke(i+0x3E9,111);
bpoke(i+0x3EA,254);bpoke(i+0x3EB,85);bpoke(i+0x3EC,85);bpoke(i+0x3ED,91);
bpoke(i+0x3F1,234);bpoke(i+0x3F2,149);bpoke(i+0x3F3,85);bpoke(i+0x3F4,85);bpoke(i+0x3F5,149);
bpoke(i+0x3F6,191);bpoke(i+0x3F8,149);bpoke(i+0x3F9,85);bpoke(i+0x3FA,85);bpoke(i+0x3FB,85);
bpoke(i+0x3FC,85);bpoke(i+0x3FD,86);bpoke(i+0x3FE,191);
bpoke(i+0x403,254);bpoke(i+0x404,175);bpoke(i+0x405,229);bpoke(i+0x406,111);
bpoke(i+0x408,149);bpoke(i+0x409,191);bpoke(i+0x40A,254);bpoke(i+0x40B,85);bpoke(i+0x40C,85);bpoke(i+0x40D,91);
bpoke(i+0x412,234);bpoke(i+0x413,169);
bpoke(i+0x414,85);bpoke(i+0x415,86);bpoke(i+0x417,254);bpoke(i+0x418,85);bpoke(i+0x419,85);
bpoke(i+0x41A,85);bpoke(i+0x41B,85);bpoke(i+0x41C,85);bpoke(i+0x41D,91);bpoke(i+0x425,229);
bpoke(i+0x426,111);bpoke(i+0x428,149);bpoke(i+0x429,191);bpoke(i+0x42A,254);bpoke(i+0x42B,85);
bpoke(i+0x42C,85);bpoke(i+0x42D,91);
bpoke(i+0x433,254);bpoke(i+0x434,165);bpoke(i+0x435,91);bpoke(i+0x437,233);
bpoke(i+0x438,85);bpoke(i+0x439,85);bpoke(i+0x43A,85);bpoke(i+0x43B,85);bpoke(i+0x43C,85);bpoke(i+0x43D,175);
bpoke(i+0x445,229);bpoke(i+0x446,91);bpoke(i+0x448,229);bpoke(i+0x449,191);
bpoke(i+0x44A,254);bpoke(i+0x44B,85);bpoke(i+0x44C,85);bpoke(i+0x44D,91);
bpoke(i+0x454,149);bpoke(i+0x455,111);
bpoke(i+0x457,149);bpoke(i+0x458,85);bpoke(i+0x459,85);bpoke(i+0x45A,85);bpoke(i+0x45B,85);
bpoke(i+0x45C,90);bpoke(i+0x465,229);bpoke(i+0x466,91);
bpoke(i+0x468,229);bpoke(i+0x469,191);bpoke(i+0x46A,249);bpoke(i+0x46B,85);bpoke(i+0x46C,85);bpoke(i+0x46D,91);
bpoke(i+0x473,254);
bpoke(i+0x474,86);bpoke(i+0x475,191);bpoke(i+0x476,254);bpoke(i+0x477,85);bpoke(i+0x478,85);bpoke(i+0x479,85);
bpoke(i+0x47A,85);bpoke(i+0x47B,85);bpoke(i+0x47C,175);
bpoke(i+0x485,249);
bpoke(i+0x486,91);bpoke(i+0x488,249);bpoke(i+0x489,191);bpoke(i+0x48A,249);bpoke(i+0x48B,85);
bpoke(i+0x48C,85);bpoke(i+0x48D,111);
bpoke(i+0x493,249);bpoke(i+0x494,91);bpoke(i+0x496,249);bpoke(i+0x497,85);
bpoke(i+0x498,85);bpoke(i+0x499,85);bpoke(i+0x49A,85);bpoke(i+0x49B,90);
bpoke(i+0x4A5,249);bpoke(i+0x4A6,91);bpoke(i+0x4A8,250);
bpoke(i+0x4AA,249);bpoke(i+0x4AB,85);bpoke(i+0x4AC,85);bpoke(i+0x4AD,111);
bpoke(i+0x4B3,229);bpoke(i+0x4B4,111);
bpoke(i+0x4B6,229);bpoke(i+0x4B7,85);bpoke(i+0x4B8,85);bpoke(i+0x4B9,85);bpoke(i+0x4BA,85);bpoke(i+0x4BB,175);
bpoke(i+0x4C5,249);bpoke(i+0x4C6,86);
bpoke(i+0x4C8,250);bpoke(i+0x4CA,229);bpoke(i+0x4CB,85);bpoke(i+0x4CC,85);bpoke(i+0x4CD,111);
bpoke(i+0x4D3,150);
bpoke(i+0x4D4,191);bpoke(i+0x4D6,149);bpoke(i+0x4D7,85);bpoke(i+0x4D8,85);bpoke(i+0x4D9,85);
bpoke(i+0x4DA,85);bpoke(i+0x4DB,111);
bpoke(i+0x4E5,249);
bpoke(i+0x4E6,86);bpoke(i+0x4E8,254);bpoke(i+0x4EA,229);bpoke(i+0x4EB,85);
bpoke(i+0x4EC,85);bpoke(i+0x4ED,191);
bpoke(i+0x4F2,250);bpoke(i+0x4F3,91);bpoke(i+0x4F5,254);bpoke(i+0x4F6,85);bpoke(i+0x4F7,85);
bpoke(i+0x4F8,86);bpoke(i+0x4F9,169);bpoke(i+0x4FA,85);bpoke(i+0x4FB,91);
bpoke(i+0x505,254);bpoke(i+0x506,86);
bpoke(i+0x50A,229);bpoke(i+0x50B,85);bpoke(i+0x50C,85);bpoke(i+0x50D,191);
bpoke(i+0x512,229);bpoke(i+0x513,111);bpoke(i+0x515,249);
bpoke(i+0x516,85);bpoke(i+0x517,85);bpoke(i+0x518,91);bpoke(i+0x519,254);bpoke(i+0x51A,170);bpoke(i+0x51B,86);
bpoke(i+0x525,254);bpoke(i+0x526,86);
bpoke(i+0x52A,229);bpoke(i+0x52B,85);bpoke(i+0x52C,85);bpoke(i+0x52D,191);
bpoke(i+0x532,149);bpoke(i+0x533,191);
bpoke(i+0x535,229);bpoke(i+0x536,85);bpoke(i+0x537,85);bpoke(i+0x538,91);
bpoke(i+0x53A,254);bpoke(i+0x53B,85);bpoke(i+0x53C,175);
bpoke(i+0x545,254);
bpoke(i+0x546,85);bpoke(i+0x547,191);bpoke(i+0x54A,229);bpoke(i+0x54B,85);
bpoke(i+0x54C,86);bpoke(i+0x551,254);
bpoke(i+0x552,150);bpoke(i+0x554,254);bpoke(i+0x555,149);bpoke(i+0x556,85);bpoke(i+0x557,85);
bpoke(i+0x558,111);bpoke(i+0x55A,249);bpoke(i+0x55B,85);bpoke(i+0x55C,91);
bpoke(i+0x565,254);bpoke(i+0x566,85);bpoke(i+0x567,191);
bpoke(i+0x56A,229);bpoke(i+0x56B,85);bpoke(i+0x56C,86);
bpoke(i+0x571,249);bpoke(i+0x572,90);bpoke(i+0x574,249);bpoke(i+0x575,85);
bpoke(i+0x576,85);bpoke(i+0x577,85);bpoke(i+0x578,111);bpoke(i+0x57A,249);bpoke(i+0x57B,85);
bpoke(i+0x57C,86);
bpoke(i+0x586,149);bpoke(i+0x587,191);
bpoke(i+0x58A,229);bpoke(i+0x58B,85);bpoke(i+0x58C,86);
bpoke(i+0x591,229);bpoke(i+0x592,111);
bpoke(i+0x594,229);bpoke(i+0x595,85);bpoke(i+0x596,85);bpoke(i+0x597,85);bpoke(i+0x598,111);
bpoke(i+0x59A,229);bpoke(i+0x59B,85);bpoke(i+0x59C,86);
bpoke(i+0x5A6,149);bpoke(i+0x5A7,111);bpoke(i+0x5AA,149);bpoke(i+0x5AB,85);
bpoke(i+0x5AC,86);bpoke(i+0x5B1,149);
bpoke(i+0x5B2,191);bpoke(i+0x5B4,149);bpoke(i+0x5B5,85);bpoke(i+0x5B6,85);bpoke(i+0x5B7,85);
bpoke(i+0x5B8,111);bpoke(i+0x5BA,229);bpoke(i+0x5BB,85);bpoke(i+0x5BC,85);bpoke(i+0x5BD,191);
bpoke(i+0x5C6,149);bpoke(i+0x5C7,111);
bpoke(i+0x5CA,149);bpoke(i+0x5CB,85);bpoke(i+0x5CC,86);
bpoke(i+0x5D1,150);bpoke(i+0x5D2,191);bpoke(i+0x5D3,254);bpoke(i+0x5D4,170);bpoke(i+0x5D5,170);
bpoke(i+0x5D6,170);bpoke(i+0x5D7,170);bpoke(i+0x5D8,191);bpoke(i+0x5DA,229);bpoke(i+0x5DB,85);
bpoke(i+0x5DC,85);bpoke(i+0x5DD,111);
bpoke(i+0x5E6,149);bpoke(i+0x5E7,111);
bpoke(i+0x5EA,149);bpoke(i+0x5EB,85);bpoke(i+0x5EC,91);
bpoke(i+0x5F0,254);bpoke(i+0x5F1,91);
bpoke(i+0x5FA,149);bpoke(i+0x5FB,85);bpoke(i+0x5FC,85);bpoke(i+0x5FD,111);
bpoke(i+0x606,229);bpoke(i+0x607,111);bpoke(i+0x60A,149);bpoke(i+0x60B,85);
bpoke(i+0x60C,91);bpoke(i+0x610,249);bpoke(i+0x611,111);
bpoke(i+0x61A,149);bpoke(i+0x61B,85);bpoke(i+0x61C,85);bpoke(i+0x61D,191);
bpoke(i+0x626,229);bpoke(i+0x627,91);bpoke(i+0x629,254);
bpoke(i+0x62A,85);bpoke(i+0x62B,85);bpoke(i+0x62C,91);
bpoke(i+0x630,229);bpoke(i+0x631,191);
bpoke(i+0x63A,149);bpoke(i+0x63B,85);
bpoke(i+0x63C,85);bpoke(i+0x63D,191);
bpoke(i+0x646,229);bpoke(i+0x647,90);
bpoke(i+0x648,171);bpoke(i+0x649,254);bpoke(i+0x64A,85);bpoke(i+0x64B,85);bpoke(i+0x64C,91);
bpoke(i+0x650,149);bpoke(i+0x651,191);
bpoke(i+0x659,254);
bpoke(i+0x65A,85);bpoke(i+0x65B,85);bpoke(i+0x65C,86);
bpoke(i+0x666,229);bpoke(i+0x667,85);bpoke(i+0x668,86);bpoke(i+0x669,170);bpoke(i+0x66A,85);bpoke(i+0x66B,85);
bpoke(i+0x66C,91);bpoke(i+0x670,149);bpoke(i+0x671,170);
bpoke(i+0x672,170);bpoke(i+0x673,170);bpoke(i+0x674,170);bpoke(i+0x675,170);bpoke(i+0x676,191);
bpoke(i+0x679,254);bpoke(i+0x67A,85);bpoke(i+0x67B,85);bpoke(i+0x67C,86);
bpoke(i+0x686,249);bpoke(i+0x687,85);bpoke(i+0x688,85);bpoke(i+0x689,85);
bpoke(i+0x68A,85);bpoke(i+0x68B,85);bpoke(i+0x68C,91);bpoke(i+0x68F,254);
bpoke(i+0x690,85);bpoke(i+0x691,85);bpoke(i+0x692,85);bpoke(i+0x693,85);bpoke(i+0x694,85);bpoke(i+0x695,85);
bpoke(i+0x696,106);bpoke(i+0x697,170);bpoke(i+0x698,171);bpoke(i+0x699,249);bpoke(i+0x69A,85);bpoke(i+0x69B,85);
bpoke(i+0x69C,86);
bpoke(i+0x6A6,249);bpoke(i+0x6A7,85);
bpoke(i+0x6A8,85);bpoke(i+0x6A9,85);bpoke(i+0x6AA,85);bpoke(i+0x6AB,85);bpoke(i+0x6AC,111);
bpoke(i+0x6AF,249);bpoke(i+0x6B0,85);bpoke(i+0x6B1,85);bpoke(i+0x6B2,85);bpoke(i+0x6B3,85);
bpoke(i+0x6B4,85);bpoke(i+0x6B5,85);bpoke(i+0x6B6,85);bpoke(i+0x6B7,85);bpoke(i+0x6B8,86);bpoke(i+0x6B9,169);
bpoke(i+0x6BA,85);bpoke(i+0x6BB,85);bpoke(i+0x6BC,91);
bpoke(i+0x6C6,254);bpoke(i+0x6C7,85);bpoke(i+0x6C8,85);bpoke(i+0x6C9,85);bpoke(i+0x6CA,85);bpoke(i+0x6CB,85);
bpoke(i+0x6CC,111);bpoke(i+0x6CF,254);bpoke(i+0x6D0,85);bpoke(i+0x6D1,85);
bpoke(i+0x6D2,85);bpoke(i+0x6D3,85);bpoke(i+0x6D4,85);bpoke(i+0x6D5,85);bpoke(i+0x6D6,85);bpoke(i+0x6D7,85);
bpoke(i+0x6D8,85);bpoke(i+0x6D9,85);bpoke(i+0x6DA,85);bpoke(i+0x6DB,85);bpoke(i+0x6DC,91);
bpoke(i+0x6E7,149);bpoke(i+0x6E8,85);bpoke(i+0x6E9,85);
bpoke(i+0x6EA,85);bpoke(i+0x6EB,85);bpoke(i+0x6EC,111);bpoke(i+0x6EF,254);
bpoke(i+0x6F0,85);bpoke(i+0x6F1,85);bpoke(i+0x6F2,85);bpoke(i+0x6F3,85);bpoke(i+0x6F4,85);bpoke(i+0x6F5,85);
bpoke(i+0x6F6,85);bpoke(i+0x6F7,85);bpoke(i+0x6F8,85);bpoke(i+0x6F9,85);bpoke(i+0x6FA,85);bpoke(i+0x6FB,85);
bpoke(i+0x6FC,111);bpoke(i+0x707,229);
bpoke(i+0x708,85);bpoke(i+0x709,85);bpoke(i+0x70A,85);bpoke(i+0x70B,85);bpoke(i+0x70C,191);
bpoke(i+0x710,149);bpoke(i+0x711,85);bpoke(i+0x712,85);bpoke(i+0x713,85);
bpoke(i+0x714,85);bpoke(i+0x715,85);bpoke(i+0x716,85);bpoke(i+0x717,85);bpoke(i+0x718,85);bpoke(i+0x719,85);
bpoke(i+0x71A,85);bpoke(i+0x71B,85);bpoke(i+0x71C,111);
bpoke(i+0x727,229);bpoke(i+0x728,85);bpoke(i+0x729,85);bpoke(i+0x72A,85);bpoke(i+0x72B,85);
bpoke(i+0x72C,191);bpoke(i+0x730,229);bpoke(i+0x731,85);
bpoke(i+0x732,85);bpoke(i+0x733,85);bpoke(i+0x734,85);bpoke(i+0x735,85);bpoke(i+0x736,85);bpoke(i+0x737,85);
bpoke(i+0x738,85);bpoke(i+0x739,85);bpoke(i+0x73A,85);bpoke(i+0x73B,85);bpoke(i+0x73C,191);
bpoke(i+0x747,249);bpoke(i+0x748,85);bpoke(i+0x749,85);
bpoke(i+0x74A,85);bpoke(i+0x74B,85);bpoke(i+0x74C,191);
bpoke(i+0x750,249);bpoke(i+0x751,85);bpoke(i+0x752,85);bpoke(i+0x753,85);bpoke(i+0x754,85);bpoke(i+0x755,85);
bpoke(i+0x756,85);bpoke(i+0x757,85);bpoke(i+0x758,85);bpoke(i+0x759,85);bpoke(i+0x75A,85);bpoke(i+0x75B,85);
bpoke(i+0x75C,191);bpoke(i+0x767,254);bpoke(i+0x768,85);bpoke(i+0x769,85);
bpoke(i+0x76A,85);bpoke(i+0x76B,85);bpoke(i+0x76C,191);bpoke(i+0x770,249);
bpoke(i+0x771,85);bpoke(i+0x772,85);bpoke(i+0x773,85);
bpoke(i+0x774,85);bpoke(i+0x775,85);bpoke(i+0x776,85);bpoke(i+0x777,85);bpoke(i+0x778,85);bpoke(i+0x779,85);
bpoke(i+0x77A,85);bpoke(i+0x77B,86);bpoke(i+0x788,170);bpoke(i+0x789,170);bpoke(i+0x78A,149);bpoke(i+0x78B,85);
bpoke(i+0x78C,191);bpoke(i+0x790,254);bpoke(i+0x791,85);
bpoke(i+0x792,85);bpoke(i+0x793,85);bpoke(i+0x794,85);bpoke(i+0x795,85);bpoke(i+0x796,85);bpoke(i+0x797,85);
bpoke(i+0x798,85);bpoke(i+0x799,85);bpoke(i+0x79A,85);bpoke(i+0x79B,86);
bpoke(i+0x7AA,234);bpoke(i+0x7AB,170);bpoke(i+0x7AC,191);
bpoke(i+0x7B1,170);bpoke(i+0x7B2,170);bpoke(i+0x7B3,170);bpoke(i+0x7B4,170);bpoke(i+0x7B5,170);
bpoke(i+0x7B6,170);bpoke(i+0x7B7,85);bpoke(i+0x7B8,85);bpoke(i+0x7B9,85);bpoke(i+0x7BA,85);bpoke(i+0x7BB,91);
bpoke(i+0x7D7,170);bpoke(i+0x7D8,170);bpoke(i+0x7D9,170);
bpoke(i+0x7DA,149);bpoke(i+0x7DB,91);bpoke(i+0x7FA,234);bpoke(i+0x7FB,171);




//--------


	j = 0x7000+32 - k;
         

//        j = (i +32) + (0x7000-i) + (0x7000-i);


bpoke(j+0x44E,235);bpoke(j+0x451,254);bpoke(j+0x452,191);bpoke(j+0x46D,254);bpoke(j+0x46E,150);bpoke(j+0x471,249);
bpoke(j+0x472,106);bpoke(j+0x48D,233);bpoke(j+0x48E,85);bpoke(j+0x48F,191);bpoke(j+0x491,229);
bpoke(j+0x492,105);bpoke(j+0x493,170);bpoke(j+0x4AC,254);bpoke(j+0x4AD,149);bpoke(j+0x4AE,165);bpoke(j+0x4AF,111);
bpoke(j+0x4B1,229);bpoke(j+0x4B2,190);bpoke(j+0x4B3,165);bpoke(j+0x4B4,171);bpoke(j+0x4B6,250);bpoke(j+0x4B7,171);
bpoke(j+0x4CC,233);bpoke(j+0x4CD,90);bpoke(j+0x4CE,229);bpoke(j+0x4CF,91);bpoke(j+0x4D1,230);bpoke(j+0x4D3,250);
bpoke(j+0x4D4,86);bpoke(j+0x4D5,191);bpoke(j+0x4D6,229);bpoke(j+0x4D7,86);bpoke(j+0x4D8,170);bpoke(j+0x4D9,170);
bpoke(j+0x4DA,170);bpoke(j+0x4EB,254);bpoke(j+0x4EC,150);bpoke(j+0x4ED,175);bpoke(j+0x4EE,249);bpoke(j+0x4EF,86);
bpoke(j+0x4F1,155);bpoke(j+0x4F4,165);bpoke(j+0x4F5,111);bpoke(j+0x4F6,149);bpoke(j+0x4F7,170);
bpoke(j+0x4F8,165);bpoke(j+0x4F9,85);bpoke(j+0x4FA,85);bpoke(j+0x4FB,170);bpoke(j+0x4FC,170);bpoke(j+0x4FD,170);
bpoke(j+0x4FE,171);bpoke(j+0x50B,233);bpoke(j+0x50C,171);bpoke(j+0x50D,254);bpoke(j+0x50E,249);bpoke(j+0x50F,86);
bpoke(j+0x510,254);bpoke(j+0x511,91);bpoke(j+0x512,250);bpoke(j+0x513,190);bpoke(j+0x514,149);bpoke(j+0x515,110);
bpoke(j+0x516,86);bpoke(j+0x518,250);bpoke(j+0x519,170);bpoke(j+0x51A,170);bpoke(j+0x51B,170);
bpoke(j+0x51C,169);bpoke(j+0x51D,85);bpoke(j+0x51E,86);bpoke(j+0x52A,254);bpoke(j+0x52B,154);bpoke(j+0x52D,234);
bpoke(j+0x52E,254);bpoke(j+0x52F,85);bpoke(j+0x530,190);bpoke(j+0x531,91);bpoke(j+0x532,229);bpoke(j+0x533,106);
bpoke(j+0x534,85);bpoke(j+0x535,89);bpoke(j+0x536,91);bpoke(j+0x537,254);bpoke(j+0x538,170);bpoke(j+0x539,171);
bpoke(j+0x53C,254);bpoke(j+0x53D,170);bpoke(j+0x53E,149);bpoke(j+0x53F,191);bpoke(j+0x54A,233);bpoke(j+0x54B,175);
bpoke(j+0x54C,254);bpoke(j+0x54D,149);bpoke(j+0x54E,190);bpoke(j+0x54F,85);bpoke(j+0x550,190);bpoke(j+0x551,111);
bpoke(j+0x552,229);bpoke(j+0x553,85);bpoke(j+0x554,85);bpoke(j+0x555,89);bpoke(j+0x556,111);bpoke(j+0x557,249);
bpoke(j+0x558,85);bpoke(j+0x559,86);bpoke(j+0x55A,170);bpoke(j+0x55B,175);bpoke(j+0x55E,229);bpoke(j+0x55F,111);
bpoke(j+0x56A,250);bpoke(j+0x56B,111);bpoke(j+0x56C,233);bpoke(j+0x56D,85);bpoke(j+0x56E,191);bpoke(j+0x56F,149);
bpoke(j+0x570,105);bpoke(j+0x571,111);bpoke(j+0x572,149);bpoke(j+0x573,85);bpoke(j+0x574,85);bpoke(j+0x575,101);
bpoke(j+0x576,191);bpoke(j+0x577,229);bpoke(j+0x578,85);bpoke(j+0x579,85);bpoke(j+0x57A,85);bpoke(j+0x57B,90);
bpoke(j+0x57C,175);bpoke(j+0x57D,254);bpoke(j+0x57E,165);bpoke(j+0x57F,91);bpoke(j+0x58B,154);bpoke(j+0x58C,149);
bpoke(j+0x58D,85);bpoke(j+0x58E,191);bpoke(j+0x58F,149);bpoke(j+0x590,85);bpoke(j+0x591,191);bpoke(j+0x592,149);
bpoke(j+0x593,85);bpoke(j+0x594,85);bpoke(j+0x595,150);bpoke(j+0x596,175);bpoke(j+0x597,149);bpoke(j+0x598,85);
bpoke(j+0x599,85);bpoke(j+0x59A,85);bpoke(j+0x59B,111);bpoke(j+0x59C,254);bpoke(j+0x59D,169);bpoke(j+0x59E,85);
bpoke(j+0x59F,86);bpoke(j+0x5AB,229);bpoke(j+0x5AC,85);bpoke(j+0x5AD,85);bpoke(j+0x5AE,111);bpoke(j+0x5AF,229);
bpoke(j+0x5B0,85);bpoke(j+0x5B1,190);bpoke(j+0x5B2,85);bpoke(j+0x5B3,86);bpoke(j+0x5B4,150);bpoke(j+0x5B5,149);
bpoke(j+0x5B6,90);bpoke(j+0x5B7,85);bpoke(j+0x5B8,85);bpoke(j+0x5B9,165);bpoke(j+0x5BA,86);bpoke(j+0x5BB,191);
bpoke(j+0x5BC,233);bpoke(j+0x5BD,85);bpoke(j+0x5BE,85);bpoke(j+0x5BF,86);bpoke(j+0x5CB,250);bpoke(j+0x5CC,85);
bpoke(j+0x5CD,85);bpoke(j+0x5CE,111);bpoke(j+0x5CF,229);bpoke(j+0x5D0,86);bpoke(j+0x5D1,254);bpoke(j+0x5D2,85);
bpoke(j+0x5D3,86);bpoke(j+0x5D4,234);bpoke(j+0x5D5,229);bpoke(j+0x5D6,85);bpoke(j+0x5D7,85);bpoke(j+0x5D8,85);
bpoke(j+0x5D9,169);bpoke(j+0x5DA,171);bpoke(j+0x5DB,250);bpoke(j+0x5DC,149);bpoke(j+0x5DD,85);bpoke(j+0x5DE,85);
bpoke(j+0x5DF,91);bpoke(j+0x5EC,165);bpoke(j+0x5ED,86);bpoke(j+0x5EE,111);bpoke(j+0x5EF,229);bpoke(j+0x5F0,91);
bpoke(j+0x5F1,249);bpoke(j+0x5F2,85);bpoke(j+0x5F3,91);bpoke(j+0x5F5,249);bpoke(j+0x5F6,85);bpoke(j+0x5F7,85);
bpoke(j+0x5F8,90);bpoke(j+0x5F9,150);bpoke(j+0x5FB,165);bpoke(j+0x5FC,85);bpoke(j+0x5FD,85);bpoke(j+0x5FE,85);
bpoke(j+0x5FF,91);bpoke(j+0x60C,250);bpoke(j+0x60D,106);bpoke(j+0x60E,91);bpoke(j+0x60F,249);bpoke(j+0x610,91);
bpoke(j+0x611,249);bpoke(j+0x612,85);bpoke(j+0x613,91);bpoke(j+0x615,254);bpoke(j+0x616,170);bpoke(j+0x617,85);
bpoke(j+0x618,90);bpoke(j+0x619,171);bpoke(j+0x61A,250);bpoke(j+0x61B,85);bpoke(j+0x61C,85);bpoke(j+0x61D,85);
bpoke(j+0x61E,90);bpoke(j+0x61F,175);bpoke(j+0x62D,191);bpoke(j+0x62E,155);bpoke(j+0x62F,249);bpoke(j+0x630,91);
bpoke(j+0x631,249);bpoke(j+0x632,85);bpoke(j+0x633,111);bpoke(j+0x637,170);bpoke(j+0x638,150);bpoke(j+0x63A,229);
bpoke(j+0x63B,85);bpoke(j+0x63C,85);bpoke(j+0x63D,90);bpoke(j+0x63E,175);bpoke(j+0x64E,150);bpoke(j+0x64F,254);
bpoke(j+0x650,111);bpoke(j+0x651,249);bpoke(j+0x652,85);bpoke(j+0x653,111);bpoke(j+0x657,254);bpoke(j+0x658,107);
bpoke(j+0x659,254);bpoke(j+0x65A,149);bpoke(j+0x65B,85);bpoke(j+0x65C,85);bpoke(j+0x65D,111);bpoke(j+0x66E,150);
bpoke(j+0x670,175);bpoke(j+0x671,249);bpoke(j+0x672,85);bpoke(j+0x673,111);bpoke(j+0x677,234);bpoke(j+0x678,191);
bpoke(j+0x679,233);bpoke(j+0x67A,85);bpoke(j+0x67B,85);bpoke(j+0x67C,90);bpoke(j+0x67D,191);bpoke(j+0x68E,230);
bpoke(j+0x690,239);bpoke(j+0x691,249);bpoke(j+0x692,85);bpoke(j+0x693,111);bpoke(j+0x697,155);bpoke(j+0x698,254);
bpoke(j+0x699,149);bpoke(j+0x69A,85);bpoke(j+0x69B,170);bpoke(j+0x69C,86);bpoke(j+0x69D,175);bpoke(j+0x6AE,229);
bpoke(j+0x6AF,191);bpoke(j+0x6B1,229);bpoke(j+0x6B2,85);bpoke(j+0x6B3,191);bpoke(j+0x6B6,250);bpoke(j+0x6B7,111);
bpoke(j+0x6B8,233);bpoke(j+0x6B9,85);bpoke(j+0x6BA,86);bpoke(j+0x6BC,165);bpoke(j+0x6BD,91);bpoke(j+0x6CE,249);
bpoke(j+0x6CF,191);bpoke(j+0x6D1,229);bpoke(j+0x6D2,85);bpoke(j+0x6D3,191);bpoke(j+0x6D6,166);bpoke(j+0x6D7,190);
bpoke(j+0x6D8,149);bpoke(j+0x6D9,85);bpoke(j+0x6DA,86);bpoke(j+0x6DC,149);bpoke(j+0x6DD,86);bpoke(j+0x6EE,249);
bpoke(j+0x6EF,191);bpoke(j+0x6F1,229);bpoke(j+0x6F2,86);bpoke(j+0x6F5,254);bpoke(j+0x6F6,107);bpoke(j+0x6F7,250);
bpoke(j+0x6F8,170);bpoke(j+0x6F9,170);bpoke(j+0x6FA,171);bpoke(j+0x6FC,149);bpoke(j+0x6FD,85);bpoke(j+0x6FE,191);
bpoke(j+0x70E,249);bpoke(j+0x70F,111);bpoke(j+0x711,149);bpoke(j+0x712,86);bpoke(j+0x715,249);bpoke(j+0x716,191);
bpoke(j+0x71C,149);bpoke(j+0x71D,86);bpoke(j+0x72E,254);bpoke(j+0x72F,106);bpoke(j+0x730,170);bpoke(j+0x731,149);
bpoke(j+0x732,86);bpoke(j+0x735,230);bpoke(j+0x736,170);bpoke(j+0x737,170);bpoke(j+0x738,171);bpoke(j+0x73B,254);
bpoke(j+0x73C,85);bpoke(j+0x73D,86);bpoke(j+0x74E,254);bpoke(j+0x74F,85);bpoke(j+0x750,85);bpoke(j+0x751,85);
bpoke(j+0x752,91);bpoke(j+0x755,149);bpoke(j+0x756,85);bpoke(j+0x757,85);bpoke(j+0x758,86);bpoke(j+0x759,170);
bpoke(j+0x75A,170);bpoke(j+0x75B,169);bpoke(j+0x75C,85);bpoke(j+0x75D,86);bpoke(j+0x76F,149);bpoke(j+0x770,85);
bpoke(j+0x771,85);bpoke(j+0x772,91);bpoke(j+0x774,254);bpoke(j+0x775,85);bpoke(j+0x776,85);bpoke(j+0x777,85);
bpoke(j+0x778,85);bpoke(j+0x779,85);bpoke(j+0x77A,85);bpoke(j+0x77B,85);bpoke(j+0x77C,85);bpoke(j+0x77D,91);
bpoke(j+0x78F,229);bpoke(j+0x790,85);bpoke(j+0x791,85);bpoke(j+0x792,91);bpoke(j+0x795,165);bpoke(j+0x796,85);
bpoke(j+0x797,85);bpoke(j+0x798,85);bpoke(j+0x799,85);bpoke(j+0x79A,85);bpoke(j+0x79B,85);bpoke(j+0x79C,85);
bpoke(j+0x79D,91);bpoke(j+0x7AF,249);bpoke(j+0x7B0,85);bpoke(j+0x7B1,85);bpoke(j+0x7B2,111);bpoke(j+0x7B5,249);
bpoke(j+0x7B6,85);bpoke(j+0x7B7,85);bpoke(j+0x7B8,85);bpoke(j+0x7B9,85);bpoke(j+0x7BA,85);bpoke(j+0x7BB,85);
bpoke(j+0x7BC,85);bpoke(j+0x7BD,111);bpoke(j+0x7CF,254);bpoke(j+0x7D0,170);bpoke(j+0x7D1,170);bpoke(j+0x7D2,175);
bpoke(j+0x7D5,254);bpoke(j+0x7D6,170);bpoke(j+0x7D7,170);bpoke(j+0x7D8,170);bpoke(j+0x7D9,170);
bpoke(j+0x7DA,170);bpoke(j+0x7DB,85);bpoke(j+0x7DC,85);bpoke(j+0x7DD,191);bpoke(j+0x7FB,170);bpoke(j+0x7FC,170);



//	vz_setbase(0x7000);

//	memmove(0x7000, 0xd000, 2048);

	}




bit_fx2(7);
bit_fx3(0);
bit_fx3(1);
bit_fx3(2);
bit_fx3(0);
bit_fx3(1);
bit_fx3(2);
bit_fx3(3);
bit_fx3(4);
bit_fx3(5);
bit_fx3(3);
bit_fx3(4);
bit_fx3(5);
bit_fx3(6);


}






int main()
{
	int i;
	int j;
	int k;
	int l;
	int m;
	int quit;

	quit = 0;
	duration = 50;
	keyboard = 5;

	while (quit == 0) {
	intro();
	}	
}
