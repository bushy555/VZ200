//
//;            ...#... - Current pixel being computed
//;            ...A...
//;            ..BCD..
//;            .......
//;
//;where the pixel being computed = ((16*A)+(14*C)+B+D)/32
//;
//;

#include <vz.h>
#include <graphics.h>
#include <stdio.h>
 #include <sound.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <strings.h>
 #include <conio.h>

#define SCRSIZE     	2048 
#define video		0x7000

//#define scr 0xe000
#define scr 28672
//int scr[128*64];

	int a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,x,y,z;
	int current;

pok(int x, int y)	  //poke (x,y)
{
#asm
	push	ix
        ld      ix, #0
        add     ix, sp
	ld	a,4(ix) 	// get char
	ld	b,5(ix)
	ld	l,6(ix) 	// get POKE memory
	ld	h,7(ix)
	ld	(hl), a
	pop	ix
	ret

#endasm

}



fire_line(){
	int	rnd;
	int 	t;
	int	u;
	for (t=1;t<32;t++){
		
 		u = scr + (63*32) + t;

		bpoke( u, rand(255)/255);
	}
}





clear(){
#asm
	ld	bc, 2048
	ld	de, 0
	ld	hl, 0xe000
	ld	hl, 28672

mset1:	ld	(hl), e
	inc	hl
	dec	bc
	ld	a, b
	or	c
	jr	nz, mset1
#endasm
}


main(){	
    	vz_mode(1);
	i=0;
        z=1;
	vz_setbase(scr);
	asm("di\n");


	for (i=0;i<32;i++){bpoke((scr+(63*32)+i),255);

	clear();

	while(z==1){          


	fire_line();

	for (x=1024+128+128+128+128;x<2048;x++)
{
			current = scr + (x);
			a = wpeek(scr+(x+32)) ;
			b = wpeek(scr+(x+32+32-1));
			c = wpeek(scr+(x+32+32)) ;
			d = wpeek(scr+(x+32+32+1)); 
			e = ( bpeek(c)+ bpeek(d)) ;
                  bpoke( current , e );
        }

	}

}
}

