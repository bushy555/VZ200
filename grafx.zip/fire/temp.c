
 #include <vz.h>
 #include <conio.h>

#define SCRSIZE     	2048 
#define video		0x7000
int scr[128*64];

char *mem;
main(argc, argv)
int argc;
int *argv;

{	
	int a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,x,y,z;
    	
	while(!(z==2)){          

        b=rand() % 20;
	printf("rand 256 = %d\n",b);
}


	i=0;
        z=1;
	for (i=0;i<32;i++){
      	   mem[(scr+(63*32)+i)]=172;} /* rand(255);} */
	asm("di\n");
	while(!(z==2)){          
           for (j=50;j<62;j++){
 	      for (i=1;i<16;i++){
/*                 a = (mem[(scr+(((j-1)*32)+(i-1)))])+(mem[(scr+(((j-1)*32)+(i)))])+(mem[(scr+(((j-1)*32)+(i+1)))]) ;
		 a=a+(mem[(scr+(((j  )*32)+(i-1)))])+                              (mem[(scr+(((j  )*32)+(i+1)))]) ;
		 a=a+(mem[(scr+(((j+1)*32)+(i-1)))])+(mem[(scr+(((j+1)*32)+(i)))])+(mem[(scr+(((j+1)*32)+(i+1)))]) ;
	*/	
		 mem[(scr+((j*32)+i))] = rand(255);
	      }
}
	   memcpy(0x7000,scr,2048);
/*	for (i=0;i<32;i++){
      	   mem[(scr2+((62*32)+i))]=rand(255);} */

	}	
}




 