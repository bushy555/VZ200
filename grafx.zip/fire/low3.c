 #include <vz.h>
 #include <conio.h>





//#include <vz.h>
//#include <graphics.h>
//#include <stdio.h>
// #include <sound.h>
// #include <stdlib.h>
// #include <ctype.h>
// #include <strings.h>
// #include <conio.h>
// #include <math.h>



#define SCRSIZE     	2048 
#define video		0x7000
int scr[16*16];

char *mem;
main(argc, argv)
int argc;
int *argv;

{	
	int a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,x,y,z;
    	vz_mode(0);
    	asm("di\n");
	vz_setbase(0x7000);



	i=0;
        z=1;



//	for (i=0;i<32;i++){
//   		mem[(28672+(32*15)+i)]= 96;}
//
//	for (i=8;i<24;i++){
//   		mem[(28672+(32*15)+i)]= ((rand() %128) + 128);}
//
//	for (i=0;i<32;i++){
//                e=rand(256);
//		if (e>128) 
//   		mem[(28672+(32*15)+i)]= ((rand() %128 )+ 128);}



	asm("di\n");
	while(!(z==2)){          
           for (j=0;j<15;j++){
 	      for (i=8;i<24;i++){

a = (( mem[ 28672 + (((j+1)*32) + (i-1) ) ]  +  mem[ 28672 + (((j+1)*32) + (i)   ) ]  +  mem[ 28672 + (((j+1)*32) + (i+1) ) ] ) /4 )  ;


//	d = ( a  /3 )  ;
//        if ((a>4)) {
		mem[(28672+((j*32)+i))] = a ;
//	}

	      }


}
	for (i=8;i<24;i++){
   		mem[(29152+i)]= ((rand() %128) +128); }










//	   memcpy(0x7000,scr,512);

//	for (i=0;i<32;i++){
//      	   mem[(scr2+((62*32)+i))]=rand(255);} 

	}	
}




