#include <stdio.h>
main() {
    int i,j;
    char a;
    a=getch();
    for(i=0;i<(int)a;i++) j=rand(i);
    printf("Rand   ");
    for(j=0;j<70;j++)  {
        printf("db  ");
        for(i=0;i<11;i++)  {
            printf("%d,",(int)rand(i)%256);
            }
            printf("%d\n",(int)rand(i)%256);
        }
    }
