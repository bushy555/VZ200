 #include <vz.h>
 #include <conio.h>





//#include <vz.h>
//#include <graphics.h>
//#include <stdio.h>
// #include <sound.h>
// #include <stdlib.h>
// #include <ctype.h>
// #include <strings.h>
// #include <conio.h>
// #include <math.h>



#define SCRSIZE     	2048 
#define video		0x7000
int scr[16*16];

char *mem;
main(argc, argv)
int argc;
int *argv;

{	
	int a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,x,y,z;
    	vz_mode(0);
    	asm("di\n");
	vz_setbase(0x7000);

//  144,160,176,192,208,224,240,255
//  144,255,192,160,208,208,160,192,255,144
//  144,255,192,208,160,160,208,192,255,144

	i=0;
        z=1;


//	while(!(z==2)){          
//	for (i=0;i<256;i++){
//   		mem[(28672+i)]= i;}
//}

//
//	for (i=8;i<24;i++){
//   		mem[(28672+(32*15)+i)]= ((rand() %128) + 128);}
//
//	for (i=0;i<32;i++){
//                e=rand(256);
//		if (e>128) 
//   		mem[(28672+(32*15)+i)]= ((rand() %128 )+ 128);}



	asm("di\n");
	while(!(z==2)){          
           for (j=0;j<15;j++){
// 	      for (i=10;i<22;i++){
 	      for (i=9;i<23;i++){

// a = (( mem[ 28672 + (((j+1)*32) + (i-1) ) ]  +  

// a = ((16 * (mem[ 28672 + (((j+1)*32) + (i)   ) ])) +  ( 14 * (mem[ 28672 + (((j+2)*32) + (i) ) ]))   +    mem[ 28672 + (((j+2)*32) + (i-1) ) ]       +       mem[ 28672 + (((j+2)*32) + (i+1)) ] ) /32 )  ;
// a=((16*mem[28672+(((j+1)*32)+(i))])+(14*mem[28672+(((j+2)*32)+(i))])+mem[28672+(((j+2)*32)+(i-1))]+mem[28672+(((j+2)*32)+(i+1))]) /32 ;
//	d = ( a  /3 )  ;
//        if ((a<128) ) {
//			mem[(28672+((j*32)+i))] = 96 ;
//			}
//	else {

// a=((16*mem[28672+(((j+1)*32)+(i))])+(14*mem[28672+(((j+2)*32)+(i))])+mem[28672+(((j+2)*32)+(i-1))]+mem[28672+(((j+2)*32)+(i+1))]) /32 ;
//	a = a | 128;


 a=((mem[28672+(((j+1)*32)+(i))])+(mem[28672+(((j+2)*32)+(i))])+mem[28672+(((j+2)*32)+(i-1))]+mem[28672+(((j+2)*32)+(i+1))]) /4 ;
	a = a | 64;
		

      if ((a<64) )   {	mem[(28672+((j*32)+i))] = a ;}

      }


}


//	for (i=12;i<20;i++){
	for (i=9;i<23;i++){
 		mem[(29152+i)]= ((rand() %128) + 170 ); }





//	   memcpy(0x7000,scr,512);

//	for (i=0;i<32;i++){
//      	   mem[(scr2+((62*32)+i))]=rand(255);} 

	}	
}




