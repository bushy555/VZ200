#define SCRSIZE     	2048 
#define video		0x7000
int scr[128*64];

char *mem;
main(argc, argv)
int argc;
int *argv;

{	
	int a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,x,y,z;
    	mode(1);
	i=0;
        z=1;
	setbase(scr);
	for (i=0;i<32;i++){
      	   mem[(scr+(63*32)+i)]=172;} /* rand(255);} */
	asm("di\n");
	while(!(z==2)){          
           for (j=50;j<62;j++){
 	      for (i=1;i<16;i++){
/*                 a = (mem[(scr+(((j-1)*32)+(i-1)))])+(mem[(scr+(((j-1)*32)+(i)))])+(mem[(scr+(((j-1)*32)+(i+1)))]) ;
		 a=a+(mem[(scr+(((j  )*32)+(i-1)))])+                              (mem[(scr+(((j  )*32)+(i+1)))]) ;
		 a=a+(mem[(scr+(((j+1)*32)+(i-1)))])+(mem[(scr+(((j+1)*32)+(i)))])+(mem[(scr+(((j+1)*32)+(i+1)))]) ;
	*/	
		 mem[(scr+((j*32)+i))] = rand(255);
	      }
}
	   memcpy(0x7000,scr,2048);
/*	for (i=0;i<32;i++){
      	   mem[(scr2+((62*32)+i))]=rand(255);} */

	}	
}




        mov     ax, 13h
        int     10h

        mov     dx, 03c8h
        xor     al, al
        out     dx, al
        inc     dx
@@0:    out     dx, al
        out     dx, al
        out     dx, al
        add     al, 2
        cmp     al, 64
        jnz     @@0

        push    0a000h
        pop     es
        push    es
        pop     ds

        mov     si, cs
        mov     bx, dx

@@1:    mov     di, 8960
        mov     cx, 640
@@2:    imul    si, bx
        inc     si
        mov     ax, si
        shr     ax, 11
        stosb
        loop    @@2

        xor     di, di
        mov     cx, 9280
@@3:    add     al, [di+321]
        add     al, [di+319]
        add     al, [di+320]
        shr     al, 2
        stosb
        loop    @@3

        in      al, 060h
        and     al, 1
        jz      @@1

        mov     al, 3h
        int     10h
        ret



CSEG            EndS                            ; End of segment
end start

