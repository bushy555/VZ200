//
//;            ...#... - Current pixel being computed
//;            ...A...
//;            ..BCD..
//;            .......
//;
//;where the pixel being computed = ((16*A)+(14*C)+B+D)/32
//;
//;

#include <vz.h>
#include <graphics.h>
#include <stdio.h>
 #include <sound.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <strings.h>
 #include <conio.h>

#define SCRSIZE     	2048 
#define video		0x7000

//#define scr 0xe000
#define scr 28672
//int scr[128*64];

	int a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,x,y,z;
	int current;

pok(int x, int y)	  //poke (x,y)
{
#asm
	push	ix
        ld      ix, #0
        add     ix, sp
	ld	a,4(ix) 	// get char
	ld	b,5(ix)
	ld	l,6(ix) 	// get POKE memory
	ld	h,7(ix)
	ld	(hl), a
	pop	ix
	ret

#endasm

}



fire_line(){
	int	rnd;
	int 	t;
	for (t=1;t<32;t++){
//		rnd = ;
		
//	pok( (scr+((63*32)+i)), (rand(255)/255) );
 

		bpoke((scr+((63*32)+t)), (rand(255)/255));
	}
}


mem_cpy(){			// int memcpy(char *dst, char *src, int size);
	#asm
mem: 	push	ix
        ld      ix, #0
        add     ix, sp
	ld	c,4(ix) 	// get size
	ld	b,5(ix)
	ld	l,6(ix) 	// get *src
	ld	h,7(ix)
	ld	e,8(ix) 	// get *dst
	ld	d,9(ix)
	ldir
	pop	ix
	ret

	#endasm
	}

mem2(){	
	#asm
	ld	hl, 0xe000
	ld	de, 0x7000
	ld	bc, 2048
 	ldir
	#endasm
}


clear(){
#asm
	ld	bc, 2048
	ld	de, 0
	ld	hl, 0xe000
	ld	hl, 28672

mset1:	ld	(hl), e
	inc	hl
	dec	bc
	ld	a, b
	or	c
	jr	nz, mset1
#endasm
}


main(){	
    	vz_mode(1);
	i=0;
        z=1;
	vz_setbase(scr);
	asm("di\n");


	for (i=0;i<32;i++){bpoke((scr+(63*32)+i),255);

	clear();

	while(z==1){          


	fire_line();

//	for (x=0;x<32;x++){
//          for (y=0;y<64;y++){
//                   a = (scr+((y  )*32)+(x+0));
//		   b = (scr+((y+1)*32)+(x-1));
//		   c = (scr+((y+1)*32)+(x  ));
//		   d = (scr+((y+1)*32)+(x+1));
//                   bpoke( a , ((bpeek(a) + bpeek(b) + bpeek(c) + bpeek(d)) / 3) );
//                   }


//	for (x=1970;x<2048;x++){
//                   a = (scr+(x));
//		   b = (scr+(x+31));
//		   c = (scr+(x+32));
//		   d = (scr+(x+33));
//                   bpoke( a , ((bpeek(a) + bpeek(b) + bpeek(c) + bpeek(d)) / 4) );
////                   bpoke( a , ((bpeek(a) + bpeek(b) + bpeek(c) + bpeek(d)) / 3) );
////                   bpoke( a , (( bpeek(b) + bpeek(c) + bpeek(d)) / 3) );
//                   }



//;            ...#... - Current pixel being computed
//;            ...A...
//;            ..BCD..
//;            .......
//;
//;where the pixel being computed = ((16*A)+(14*C)+B+D)/32


	for (x=1024;x<2048;x++)
{
			current = scr + (x);
			a = wpeek(scr+(x+32)) * 16;
			b = wpeek(scr+(x+32+32-1));
			c = wpeek(scr+(x+32+32+0)) * 14;
			d = wpeek(scr+(x+32+32+1); 
			e = (bpeek(a) + bpeek(b) + bpeek(c)+ bpeek(d)) /32;
                  bpoke( current , e );
        }

	
/*	#asm
	ld	bc, 0
	ld	de,  0
	ld	hl, 28672

loop1:	push	de
	ld	hl, 28672
	add	hl, bc
	push	hl
	ld	a, (hl)

	ld	de, 31
	add	hl, de

	ld	e, a

	ld	a, (hl)
	add	e, a
	
	inc	hl
	ld	a, (hl)
	add	e, a

	inc	hl
	ld	a, (hl)
	add	e,a

	ld	a, e

	pop	hl	

	ld	(hl), a
	rr	a
	rr	a

	ld	(hl), a
	pop	de
*/
//	inc	de
//	inc	bc
//	cp	2049
//	jr	nz,	loop1
//	djnz	loop1	
//	#endasm


//        xor     di, di
//        mov     cx, 9280
//@@3:    add     al, [di+321]
//        add     al, [di+319]
//        add     al, [di+320]
//        shr     al, 2
//        stosb
//        loop    @@3



//	mem2();
	}

}
}


			/*       a = (mem[(scr+(((j-1)*32)+(i-1)))])+(mem[(scr+(((j-1)*32)+(i)))])+(mem[(scr+(((j-1)*32)+(i+1)))]) ;
				 a=a+(mem[(scr+(((j  )*32)+(i-1)))])+                              (mem[(scr+(((j  )*32)+(i+1)))]) ;
				 a=a+(mem[(scr+(((j+1)*32)+(i-1)))])+(mem[(scr+(((j+1)*32)+(i)))])+(mem[(scr+(((j+1)*32)+(i+1)))]) ;
			*/	



/*



        mov     si, cs
        mov     bx, dx

@@1:    mov     di, 8960
        mov     cx, 640
@@2:    imul    si, bx
        inc     si
        mov     ax, si
        shr     ax, 11
        stosb
        loop    @@2

        xor     di, di
        mov     cx, 9280
@@3:    add     al, [di+321]
        add     al, [di+319]
        add     al, [di+320]
        shr     al, 2
        stosb
        loop    @@3

        in      al, 060h
        and     al, 1
        jz      @@1

        mov     al, 3h
        int     10h
        ret



CSEG            EndS                            ; End of segment
end start

*/






/*


//        mov     ax, 13h
//        int     10h
//
//        mov     dx, 03c8h
//        xor     al, al
//        out     dx, al
//        inc     dx
//@@0:    out     dx, al
//        out     dx, al
//        out     dx, al
//        add     al, 2
//        cmp     al, 64
//        jnz     @@0
//
//        push    0a000h
//        pop     es
//        push    es
//        pop     ds

        mov     si, cs
        mov     bx, dx

@@1:    mov     di, 8960
        mov     cx, 640
@@2:    imul    si, bx
        inc     si
        mov     ax, si
        shr     ax, 11
        stosb
        loop    @@2

        xor     di, di
        mov     cx, 9280
@@3:    add     al, [di+321]
        add     al, [di+319]
        add     al, [di+320]
        shr     al, 2
        stosb
        loop    @@3

        in      al, 060h
        and     al, 1
        jz      @@1

        mov     al, 3h
        int     10h
        ret



CSEG            EndS                            ; End of segment
end start

*/
