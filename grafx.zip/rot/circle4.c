#include <vz.h>
#include <graphics.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <strings.h>
#include <conio.h>
#include <math.h>

#define PI = 3.1415926535
main()
{
float cx, cy;
float angle,  j;
char z,v,w, buf;
int k, sz,i,x,y,a,b,c,d,e,f;
	vz_setbase(0xe000);
	vz_mode(1);


	k = 1;
	cx = 50;
	cy = 30;
	while (k==1)
	{
	for (i=0;i<360;i=i+1) {

		x=cos(i*6)*30;  
		y=sin(i*6)*20; 
 
		a=cos((i+10)*6)*30;  
		b=sin((i+10)*6)*20; 
		c=cos((i+20)*6)*30;  
		d=sin((i+20)*6)*20; 
		e=cos((i+30)*6)*30;  
		f=sin((i+30)*6)*20; 


//		vz_plot (cx+x,cy+y, 3);
//		vz_plot (cx+a,cy+b, 3);
//		vz_plot (cx+c,cy+d, 2);
//		vz_plot (cx+e,cy+f, 3);

		vz_line (cx+x,cy+y, cx+c,cy+d,3);
		vz_line (cx+a,cy+b, cx+e,cy+f,3);



	memcpy (0x7000, 0xe000, 2048);
	memset (0xe000, 0, 2048);
  	}


	}
}

