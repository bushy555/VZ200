
#include <stdio.h>

int    extendedhelp=0;
char	filename[16][65]={"?"};
int	files=0;


void main(int argc, char *argv[])
{
	FILE *ifp;
	int	a,b,count1,count2,count3,search,tmp,length;
	char    letter1,letter2,letter3,text[20],text2[20],wack,c;


	for(a=1;a<argc;a++) if(*argv[a]=='/' || *argv[a]=='-') switch(argv[a][1])
	{
		case 'h' :
			extendedhelp=1;
			break;
		case 'H' :
			extendedhelp=1;
			break;
		case '?' :
			extendedhelp=1;
			break;
	}
	else { strcpy(filename[files],argv[a]); files++; }
	if(*filename[0]=='?' || extendedhelp)
	{
		printf("\nBushy's TExt FInder   - The Hard Way!\n"
			"usage: TEFI [switch] <filename> <text-to-be-found>    switch:\n"
			"-h     Extended help\n\n"
			"Eg:    TEFI PB.EXE THE   (Pinball Dreams)\n");
		if(extendedhelp==1) printf("\n"
			"Bushy's TExt Finder 'TEFI' will search through the specified filename and will\n"
			"search for the inputted text. BUT... there is a massive difference unlike\n"
			"other so called text finders. CAN ONLY BE ONE WORD & ABOUT 8 CHARACTER LIMIT!\n"
			"Other text finders don't search for the text if it is encrypted. Encrypted in\n"
			"the sense that every character of the text has an unknown amount added to the\n"
			"characters. Such can be found in games where they use sheet (or paper) copy-\n"
			"protection. Words are inputted and are matched against a list of words within\n"
			"a file which cannot be easily seen to the viewer if using such editors as\n"
			"as Nortons Diskedit or simple old Debug. This program will find those words\n"
			"show the offset, and show the difference.\n"
			"Version 2 of this here program may even include an editor so that input of\n"
			"text with the known difference, into a program with encypted text is much\n"
			"more easier - maybe.  \n"
			"Example of 'encrypted' text: HELLO  \n"
			"                 can become: IFMMP or GDKKN or QNVVY or yv~~� or �����\n"
			"As you can see, it is hard (normally) to see this in a file using an editor.\n"
			"                                                          Bushman '95. Later...\n");
		exit(0);
		}
printf("Working...\n");

	for (a=0;a<20;a++)
	{
		text[a]=argv[2][a];
		printf("%c",text[a]);
		if (text[a]=='\0')
		{
			length=a;
			a = 21;
		}
	}
	printf("\nLength = %d\n",length);

	ifp = fopen( argv [1],"r");

	while ((c = getc(ifp)) != EOF)
	{
	   printf("\nchar    is --> %c <--",c);
	   printf("\ndecimal is --> %d <--\n",c);
	   b = 0;
	   while (b < 256)
	   {
	      for (search=0;search<length;++search)
	      {
		letter3=text[search];

	      if (letter3==c)
		printf("found! %c\n",c);

	       }


		b = b + 1;
		for (a=0;a<length;++a);
		{
			tmp = text[a];
			if (tmp == 255)
			   tmp = 0;
			text[a]=tmp;
		}
		for (a=0;a<length;++a)
		text[a]=text[a]+1;

	}
	fclose(ifp);
	exit(0);
}
}


