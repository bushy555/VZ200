#include <vz.h>
#include <graphics.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <strings.h>
#include <conio.h>
#include <math.h>

#define PI = 3.1415926535
main()
{
float cx, cy;
float angle,  j;
char z,v,w, buf;
int k, sz,i;
double x,y,a,b,c,d,e,f;

double aa[360];
double ab[360];
double ac[360];
double ad[360];
double ae[360];
double af[360];
double ag[360];
double ah[360];


	k = 1;
	cx = 50;
	cy = 30;

        printf(" please wait... 2 or so mins...");
	for (i=0;i<360;i=i+1) {
		aa[i]=cx+cos(i*6)*30;  
		ab[i]=cy+sin(i*6)*20; 
		ac[i]=cx+cos((i+90)*6)*30;  
		ad[i]=cy+sin((i+90)*6)*20; 
		ae[i]=cx+cos((i-20)*6)*30;  
		af[i]=cy+sin((i-20)*6)*20; 
		ag[i]=cx+cos((i-40)*6)*30;  
		ah[i]=cy+sin((i-40)*6)*20; 
	}

	vz_setbase(0xe000);
	vz_mode(1);

	while (k==1)	{
	for (i=0;i<360;i=i+1) {
	   vz_plot (aa[i], ab[i], 3);
	   vz_plot (ac[i], ad[i], 3);
	   vz_plot (ae[i], af[i], 3);
	   vz_plot (ag[i], ah[i], 3);
	memcpy (0x7000, 0xe000, 2048);
	memset (0xe000, 0, 2048);
  	}
    }
}

