
#include <graphics.h>
#include <stdio.h>
#include <math.h>
#include <vz.h>
#include <conio.h>
#include <stdlib.h>
#include <ctype.h>
#include <strings.h>


#define xcent 64
#define ycent 32
#define NOSTARS 15
#define PI 3.141592654
#define getrandom( min, max ) ((rand() % (int)(((max)+1) - (min))) + (min))

double degree[360];
double sinvals[360];
double cosvals[360];
short coords[3*NOSTARS];




main()
{
    short s,t,x,y,z,counter,page,x2,y2,z2,x3,y3,z3,counter2,angle1;
    short setc;

    printf("1...\n");
    for(counter=0;counter<360;counter++)    {
       degree[counter]=counter * PI / 180;    }
    printf("2...\n");
    for(counter=0;counter<360;counter++)    {
       sinvals[counter]=sin(degree[counter]);
       cosvals[counter]=cos(degree[counter]);    }
    printf("3...\n");
    for(counter=0;counter<NOSTARS*3;counter+=3){
       coords[counter]   = getrandom(-31,31);
       coords[counter+1] = getrandom(-31,31);
       coords[counter+2] = getrandom(-31,31);    }



	vz_setbase(0xe000);
	vz_mode(1);
	while (getk() != 13) { 
//    for(angle1=0;angle1<360;angle1++)
//    for(angle1=0;angle1<360;angle1++)
    for(angle1=0;angle1<360;angle1+=3)    {
    for(counter2=0;counter2<3*NOSTARS;counter2+=3)	{

	x = coords[counter2];
	y = coords[counter2+1];
	z = coords[counter2+2];
	x2= x * cosvals[angle1] + y * sinvals[angle1];
	y2= x * sinvals[angle1] - y * cosvals[angle1];
	x3= x2 * cosvals[angle1] + z * sinvals[angle1];
	z2= x2 * sinvals[angle1] - z * cosvals[angle1];
	y3= y2 * cosvals[angle1] + z2 * sinvals[angle1];
//	z3= y2 * sinvals[angle1] - z2 * cosvals[angle1];
//	x3+=xcent;
//	y3+=ycent;

	vz_plot(x3+xcent,y3+ycent,3);
	}

	memcpy (0x7000, 0xe000, 2048);
	memset (0xe000, 0, 2048);
	}
    };
}

