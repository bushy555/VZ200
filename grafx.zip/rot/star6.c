
#include <graphics.h>
#include <stdio.h>
#include <math.h>
#include <vz.h>
#include <conio.h>
#include <stdlib.h>

#define speed 1

#define xcent 64
#define ycent 32
#define NOSTARS 5
#define ZCONST 1

#define PI 3.141592654
double degree[360];
double sinvals[360];
double cosvals[360];

#define getrandom( min, max ) ((rand() % (int)(((max)+1) - (min))) + (min))
short coords[3*NOSTARS];





void drawall()
{
    register short x,y,z,x2,y2,z2,x3,y3,z3;
    short counter,counter2,angle1,angle2,angle3;
    char key;
    short setc;
    for(angle1=0,angle2=0;angle1<360;angle1++)
    {
    for(counter2=0;counter2<3*NOSTARS;counter2+=3)
	{

	x = coords[counter2];
	y = coords[counter2+1];
	z = coords[counter2+2];
	x2= x * cosvals[angle1] + y * sinvals[angle1];
	y2= x * sinvals[angle1] - y * cosvals[angle1];
	x3= x2 * cosvals[angle1] + z * sinvals[angle1];
	z2= x2 * sinvals[angle1] - z * cosvals[angle1];
	y3= y2 * cosvals[angle1] + z2 * sinvals[angle1];
	z3= y2 * sinvals[angle1] - z2 * cosvals[angle1];
	x3=x3/ZCONST;
	y3=y3/ZCONST;
	x3+=xcent;
	y3+=ycent;

//	if(z3<0)
//	setc(1);
//	if(z3>0)
//	setc(2);
//	if(z3<100)
//	setc(3);
//	if(z3>100)
//	setc(4);

	vz_plot(x3,y3,setc);
	}
//	_clearscreen(_GVIEWPORT);
    }
}


main()
{
    double radian;
    short  x,y,z,counter,page;

    printf("1...\n");
    for(counter=0;counter<360;counter++)    {
       radian=counter * PI / 180;
       degree[counter]=radian;
    }
    printf("2...\n");
    for(counter=0;counter<360;counter++)    {
       sinvals[counter]=sin(degree[counter*speed]);
       cosvals[counter]=cos(degree[counter*speed]);
    }
    printf("3...\n");
    for(counter=0;counter<NOSTARS*3;counter+=3){
       x=getrandom(-200,200);
       y=getrandom(-200,200);
       z=getrandom(-200,200);

       coords[counter] = x;
       coords[counter+1] = y;
       coords[counter+2] = z;
    }

	vz_setbase(0x7000);
	vz_mode(1);


	while (getk() != 13) { drawall() };
}

