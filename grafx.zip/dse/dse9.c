 #include <vz.h>
 #include <graphics.h>
 #include <stdio.h>
 #include <sound.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <strings.h>
 #include <conio.h>

int display_intro(int i){
int j;
bpoke(i+0x023,42);bpoke(i+0x024,170);bpoke(i+0x025,160);bpoke(i+0x02F,21);
bpoke(i+0x030,85);bpoke(i+0x031,80);bpoke(i+0x03A,3);bpoke(i+0x03B,255);
bpoke(i+0x03C,255);bpoke(i+0x042,10);bpoke(i+0x043,162);bpoke(i+0x044,138);bpoke(i+0x045,170);
bpoke(i+0x04E,5);bpoke(i+0x04F,81);bpoke(i+0x050,69);bpoke(i+0x051,85);
bpoke(i+0x05A,255);bpoke(i+0x05B,60);bpoke(i+0x05C,255);bpoke(i+0x05D,240);
bpoke(i+0x061,2);bpoke(i+0x062,170);bpoke(i+0x063,170);bpoke(i+0x064,170);bpoke(i+0x065,170);
bpoke(i+0x066,128);bpoke(i+0x06D,1);bpoke(i+0x06E,85);bpoke(i+0x06F,85);bpoke(i+0x070,85);bpoke(i+0x071,85);
bpoke(i+0x072,64);bpoke(i+0x079,63);bpoke(i+0x07A,255);bpoke(i+0x07B,255);bpoke(i+0x07C,255);bpoke(i+0x07D,252);
bpoke(i+0x081,8);bpoke(i+0x082,34);bpoke(i+0x083,170);
bpoke(i+0x084,170);bpoke(i+0x085,170);bpoke(i+0x086,168);
bpoke(i+0x08D,4);bpoke(i+0x08E,17);bpoke(i+0x08F,85);
bpoke(i+0x090,85);bpoke(i+0x091,85);bpoke(i+0x092,84);
bpoke(i+0x099,195);bpoke(i+0x09A,63);bpoke(i+0x09B,255);
bpoke(i+0x09C,255);bpoke(i+0x09D,255);bpoke(i+0x09E,192);bpoke(i+0x0A1,170);
bpoke(i+0x0A2,170);bpoke(i+0x0A3,170);bpoke(i+0x0A4,170);bpoke(i+0x0A5,8);bpoke(i+0x0A6,170);bpoke(i+0x0A7,128);
bpoke(i+0x0AD,85);bpoke(i+0x0AE,85);bpoke(i+0x0AF,85);bpoke(i+0x0B0,85);bpoke(i+0x0B1,4);bpoke(i+0x0B2,85);bpoke(i+0x0B3,64);
bpoke(i+0x0B8,15);bpoke(i+0x0B9,255);
bpoke(i+0x0BA,255);bpoke(i+0x0BB,255);bpoke(i+0x0BC,240);bpoke(i+0x0BD,207);bpoke(i+0x0BE,252);
bpoke(i+0x0C0,2);bpoke(i+0x0C1,42);bpoke(i+0x0C2,170);bpoke(i+0x0C3,128);bpoke(i+0x0C5,8);
bpoke(i+0x0C6,42);bpoke(i+0x0C7,160);
bpoke(i+0x0CC,1);bpoke(i+0x0CD,21);bpoke(i+0x0CE,85);bpoke(i+0x0CF,64);bpoke(i+0x0D1,4);
bpoke(i+0x0D2,21);bpoke(i+0x0D3,80);
bpoke(i+0x0D8,51);bpoke(i+0x0D9,255);bpoke(i+0x0DA,252);bpoke(i+0x0DD,195);
bpoke(i+0x0DE,255);bpoke(i+0x0E0,2);bpoke(i+0x0E1,170);bpoke(i+0x0E2,168);
bpoke(i+0x0E5,2);bpoke(i+0x0E6,42);bpoke(i+0x0E7,168);
bpoke(i+0x0EC,1);bpoke(i+0x0ED,85);bpoke(i+0x0EE,84);
bpoke(i+0x0F1,1);bpoke(i+0x0F2,21);bpoke(i+0x0F3,84);
bpoke(i+0x0F8,63);bpoke(i+0x0F9,255);bpoke(i+0x0FA,192);
bpoke(i+0x0FD,51);bpoke(i+0x0FE,255);bpoke(i+0x0FF,192);bpoke(i+0x100,2);bpoke(i+0x101,170);
bpoke(i+0x102,32);bpoke(i+0x106,170);bpoke(i+0x107,168);
bpoke(i+0x10C,1);bpoke(i+0x10D,85);bpoke(i+0x10E,16);bpoke(i+0x112,85);bpoke(i+0x113,84);
bpoke(i+0x118,63);bpoke(i+0x119,243);bpoke(i+0x11D,15);bpoke(i+0x11E,255);bpoke(i+0x11F,192);
bpoke(i+0x120,10);bpoke(i+0x121,170);bpoke(i+0x122,128);bpoke(i+0x125,2);
bpoke(i+0x126,170);bpoke(i+0x127,170);
bpoke(i+0x12C,5);bpoke(i+0x12D,85);bpoke(i+0x12E,64);bpoke(i+0x131,1);
bpoke(i+0x132,85);bpoke(i+0x133,85);
bpoke(i+0x138,255);bpoke(i+0x139,252);bpoke(i+0x13D,63);
bpoke(i+0x13E,255);bpoke(i+0x13F,240);bpoke(i+0x140,10);bpoke(i+0x141,170);
bpoke(i+0x145,2);bpoke(i+0x146,170);bpoke(i+0x147,170);
bpoke(i+0x14C,5);bpoke(i+0x14D,85);
bpoke(i+0x151,1);bpoke(i+0x152,85);bpoke(i+0x153,85);
bpoke(i+0x158,255);bpoke(i+0x159,240);
bpoke(i+0x15D,63);bpoke(i+0x15E,255);bpoke(i+0x15F,240);bpoke(i+0x160,10);bpoke(i+0x161,168);
bpoke(i+0x164,2);bpoke(i+0x165,170);bpoke(i+0x166,170);bpoke(i+0x167,170);
bpoke(i+0x168,128);bpoke(i+0x16C,5);bpoke(i+0x16D,84);
bpoke(i+0x170,1);bpoke(i+0x171,85);bpoke(i+0x172,85);bpoke(i+0x173,85);
bpoke(i+0x174,64);bpoke(i+0x178,255);bpoke(i+0x179,192);
bpoke(i+0x17C,63);bpoke(i+0x17D,255);bpoke(i+0x17E,255);bpoke(i+0x17F,252);
bpoke(i+0x180,42);bpoke(i+0x181,160);bpoke(i+0x184,170);bpoke(i+0x185,170);
bpoke(i+0x186,170);bpoke(i+0x187,168);bpoke(i+0x188,128);
bpoke(i+0x18C,21);bpoke(i+0x18D,80);bpoke(i+0x190,85);bpoke(i+0x191,85);
bpoke(i+0x192,85);bpoke(i+0x193,84);bpoke(i+0x194,64);bpoke(i+0x197,3);
bpoke(i+0x198,255);bpoke(i+0x19B,15);bpoke(i+0x19C,255);bpoke(i+0x19D,255);
bpoke(i+0x19E,255);bpoke(i+0x19F,204);bpoke(i+0x1A0,42);bpoke(i+0x1A1,160);bpoke(i+0x1A2,160);bpoke(i+0x1A3,42);
bpoke(i+0x1A5,32);bpoke(i+0x1A6,42);bpoke(i+0x1A7,168);bpoke(i+0x1A8,128);
bpoke(i+0x1AC,21);bpoke(i+0x1AD,80);bpoke(i+0x1AE,80);bpoke(i+0x1AF,21);
bpoke(i+0x1B1,16);bpoke(i+0x1B2,21);bpoke(i+0x1B3,84);bpoke(i+0x1B4,64);
bpoke(i+0x1B7,3);bpoke(i+0x1B8,255);bpoke(i+0x1B9,15);bpoke(i+0x1BA,3);bpoke(i+0x1BB,240);
bpoke(i+0x1BC,3);bpoke(i+0x1BD,3);bpoke(i+0x1BE,255);bpoke(i+0x1BF,204);bpoke(i+0x1C0,40);bpoke(i+0x1C1,170);
bpoke(i+0x1C2,168);bpoke(i+0x1C3,170);bpoke(i+0x1C4,170);bpoke(i+0x1C5,160);bpoke(i+0x1C6,10);bpoke(i+0x1C7,128);
bpoke(i+0x1C8,128);bpoke(i+0x1CC,20);bpoke(i+0x1CD,85);
bpoke(i+0x1CE,84);bpoke(i+0x1CF,85);bpoke(i+0x1D0,85);bpoke(i+0x1D1,80);bpoke(i+0x1D2,5);bpoke(i+0x1D3,64);
bpoke(i+0x1D4,64);bpoke(i+0x1D7,3);bpoke(i+0x1D8,207);bpoke(i+0x1D9,255);
bpoke(i+0x1DA,207);bpoke(i+0x1DB,255);bpoke(i+0x1DC,255);bpoke(i+0x1DE,252);bpoke(i+0x1DF,12);
bpoke(i+0x1E0,10);bpoke(i+0x1E1,130);bpoke(i+0x1E2,170);bpoke(i+0x1E3,170);bpoke(i+0x1E4,128);bpoke(i+0x1E5,8);
bpoke(i+0x1E6,2);bpoke(i+0x1E7,168);
bpoke(i+0x1EC,5);bpoke(i+0x1ED,65);bpoke(i+0x1EE,85);bpoke(i+0x1EF,85);bpoke(i+0x1F0,64);bpoke(i+0x1F1,4);
bpoke(i+0x1F2,1);bpoke(i+0x1F3,84);
bpoke(i+0x1F8,252);bpoke(i+0x1F9,63);bpoke(i+0x1FA,255);bpoke(i+0x1FB,252);bpoke(i+0x1FD,192);
bpoke(i+0x1FE,63);bpoke(i+0x1FF,192);bpoke(i+0x200,10);bpoke(i+0x201,170);bpoke(i+0x202,168);bpoke(i+0x203,34);
bpoke(i+0x205,32);bpoke(i+0x206,2);bpoke(i+0x207,8);
bpoke(i+0x20C,5);bpoke(i+0x20D,85);bpoke(i+0x20E,84);bpoke(i+0x20F,17);
bpoke(i+0x211,16);bpoke(i+0x212,1);bpoke(i+0x213,4);
bpoke(i+0x218,255);bpoke(i+0x219,255);bpoke(i+0x21A,195);bpoke(i+0x21B,48);
bpoke(i+0x21C,3);bpoke(i+0x21E,48);bpoke(i+0x21F,192);bpoke(i+0x220,2);bpoke(i+0x221,170);
bpoke(i+0x222,168);bpoke(i+0x223,2);bpoke(i+0x224,170);bpoke(i+0x225,128);bpoke(i+0x227,8);
bpoke(i+0x228,128);bpoke(i+0x22C,1);bpoke(i+0x22D,85);
bpoke(i+0x22E,84);bpoke(i+0x22F,1);bpoke(i+0x230,85);bpoke(i+0x231,64);bpoke(i+0x233,4);
bpoke(i+0x234,64);bpoke(i+0x238,63);bpoke(i+0x239,255);
bpoke(i+0x23A,192);bpoke(i+0x23B,63);bpoke(i+0x23C,252);bpoke(i+0x23F,204);
bpoke(i+0x240,2);bpoke(i+0x241,128);bpoke(i+0x242,40);
bpoke(i+0x248,128);bpoke(i+0x24C,1);bpoke(i+0x24D,64);bpoke(i+0x24E,20);
bpoke(i+0x254,64);bpoke(i+0x258,60);bpoke(i+0x259,3);bpoke(i+0x25A,192);
bpoke(i+0x25F,12);bpoke(i+0x261,170);bpoke(i+0x262,160);
bpoke(i+0x267,128);bpoke(i+0x268,128);bpoke(i+0x26D,85);bpoke(i+0x26E,80);
bpoke(i+0x273,64);bpoke(i+0x274,64);bpoke(i+0x278,15);bpoke(i+0x279,255);
bpoke(i+0x27E,12);bpoke(i+0x27F,12);bpoke(i+0x281,32);
bpoke(i+0x282,10);bpoke(i+0x283,162);bpoke(i+0x284,130);bpoke(i+0x285,160);bpoke(i+0x287,170);
bpoke(i+0x28D,16);bpoke(i+0x28E,5);bpoke(i+0x28F,81);bpoke(i+0x290,65);bpoke(i+0x291,80);bpoke(i+0x293,85);
bpoke(i+0x298,3);bpoke(i+0x29A,255);bpoke(i+0x29B,60);bpoke(i+0x29C,63);bpoke(i+0x29E,15);bpoke(i+0x29F,240);
bpoke(i+0x2A1,32);bpoke(i+0x2A2,34);bpoke(i+0x2A3,170);bpoke(i+0x2A5,160);
bpoke(i+0x2A6,10);bpoke(i+0x2A7,128);
bpoke(i+0x2AD,16);bpoke(i+0x2AE,17);bpoke(i+0x2AF,85);bpoke(i+0x2B1,80);
bpoke(i+0x2B2,5);bpoke(i+0x2B3,64);
bpoke(i+0x2B8,3);bpoke(i+0x2B9,3);bpoke(i+0x2BA,63);bpoke(i+0x2BB,240);bpoke(i+0x2BC,15);
bpoke(i+0x2BE,252);bpoke(i+0x2C1,10);bpoke(i+0x2C2,160);
bpoke(i+0x2C4,2);bpoke(i+0x2C5,160);bpoke(i+0x2C6,42);
bpoke(i+0x2CD,5);bpoke(i+0x2CE,80);bpoke(i+0x2D0,1);bpoke(i+0x2D1,80);bpoke(i+0x2D2,21);
bpoke(i+0x2D9,255);bpoke(i+0x2DC,63);bpoke(i+0x2DD,3);bpoke(i+0x2DE,240);bpoke(i+0x2E1,10);
bpoke(i+0x2E2,160);bpoke(i+0x2E3,10);bpoke(i+0x2E4,170);bpoke(i+0x2E5,2);bpoke(i+0x2E6,170);
bpoke(i+0x2ED,5);bpoke(i+0x2EE,80);bpoke(i+0x2EF,5);bpoke(i+0x2F0,85);bpoke(i+0x2F1,1);bpoke(i+0x2F2,85);
bpoke(i+0x2F9,255);bpoke(i+0x2FB,255);bpoke(i+0x2FC,240);bpoke(i+0x2FD,63);bpoke(i+0x2FE,240);
bpoke(i+0x301,2);bpoke(i+0x302,130);bpoke(i+0x303,128);bpoke(i+0x304,128);bpoke(i+0x305,10);
bpoke(i+0x306,168);bpoke(i+0x30D,1);bpoke(i+0x30E,65);bpoke(i+0x30F,64);bpoke(i+0x310,64);bpoke(i+0x311,5);
bpoke(i+0x312,84);bpoke(i+0x319,60);bpoke(i+0x31A,60);bpoke(i+0x31B,12);bpoke(i+0x31D,255);
bpoke(i+0x31E,192);bpoke(i+0x321,2);bpoke(i+0x322,128);
bpoke(i+0x326,168);bpoke(i+0x32D,1);bpoke(i+0x32E,64);bpoke(i+0x332,84);
bpoke(i+0x339,60);bpoke(i+0x33D,15);bpoke(i+0x33E,192);
bpoke(i+0x342,160);bpoke(i+0x343,42);bpoke(i+0x344,160);bpoke(i+0x345,2);bpoke(i+0x346,128);
bpoke(i+0x34E,80);bpoke(i+0x34F,21);bpoke(i+0x350,80);bpoke(i+0x351,1);bpoke(i+0x352,64);
bpoke(i+0x359,15);bpoke(i+0x35A,3);bpoke(i+0x35B,255);bpoke(i+0x35D,60);
bpoke(i+0x362,32);bpoke(i+0x365,10);
bpoke(i+0x366,128);bpoke(i+0x36E,16);bpoke(i+0x371,5);
bpoke(i+0x372,64);bpoke(i+0x379,3);bpoke(i+0x37D,252);
bpoke(i+0x382,10);bpoke(i+0x385,168);bpoke(i+0x38E,5);
bpoke(i+0x391,84);bpoke(i+0x39A,240);bpoke(i+0x39C,15);bpoke(i+0x39D,192);
bpoke(i+0x3A3,168);bpoke(i+0x3A4,10);bpoke(i+0x3A5,128);
bpoke(i+0x3AF,84);bpoke(i+0x3B0,5);bpoke(i+0x3B1,64);
bpoke(i+0x3BA,15);bpoke(i+0x3BB,192);bpoke(i+0x3BC,252);
bpoke(i+0x3C3,2);bpoke(i+0x3C4,160);bpoke(i+0x3CF,1);bpoke(i+0x3D0,80);bpoke(i+0x3DB,63);
bpoke(i+0x421,1);bpoke(i+0x422,84);bpoke(i+0x424,21);bpoke(i+0x425,69);
bpoke(i+0x426,85);bpoke(i+0x427,84);bpoke(i+0x42A,85);bpoke(i+0x42B,64);
bpoke(i+0x42C,1);bpoke(i+0x42D,85);bpoke(i+0x42F,5);bpoke(i+0x430,84);
bpoke(i+0x433,85);bpoke(i+0x434,85);bpoke(i+0x436,85);
bpoke(i+0x438,21);bpoke(i+0x439,80);bpoke(i+0x43A,5);bpoke(i+0x43B,80);bpoke(i+0x43C,5);bpoke(i+0x43D,84);
bpoke(i+0x441,1);bpoke(i+0x442,244);
bpoke(i+0x444,31);bpoke(i+0x445,71);bpoke(i+0x446,255);bpoke(i+0x447,244);bpoke(i+0x449,1);
bpoke(i+0x44A,255);bpoke(i+0x44B,208);bpoke(i+0x44C,7);bpoke(i+0x44D,253);bpoke(i+0x44E,64);bpoke(i+0x44F,31);
bpoke(i+0x450,245);bpoke(i+0x453,127);bpoke(i+0x454,253);
bpoke(i+0x456,125);bpoke(i+0x458,127);bpoke(i+0x459,244);bpoke(i+0x45A,7);bpoke(i+0x45B,208);
bpoke(i+0x45C,31);bpoke(i+0x45D,208);
bpoke(i+0x462,125);bpoke(i+0x464,125);bpoke(i+0x465,5);bpoke(i+0x466,85);bpoke(i+0x467,244);
bpoke(i+0x469,5);bpoke(i+0x46A,213);bpoke(i+0x46B,244);bpoke(i+0x46C,31);bpoke(i+0x46D,223);
bpoke(i+0x46E,64);bpoke(i+0x46F,127);bpoke(i+0x470,125);bpoke(i+0x473,125);
bpoke(i+0x474,95);bpoke(i+0x475,64);bpoke(i+0x476,125);bpoke(i+0x477,1);bpoke(i+0x478,245);bpoke(i+0x479,244);
bpoke(i+0x47A,7);bpoke(i+0x47B,208);bpoke(i+0x47C,125);bpoke(i+0x47D,64);
bpoke(i+0x482,125);bpoke(i+0x484,125);
bpoke(i+0x486,7);bpoke(i+0x487,208);bpoke(i+0x489,7);bpoke(i+0x48A,209);bpoke(i+0x48B,244);
bpoke(i+0x48C,31);bpoke(i+0x48D,71);bpoke(i+0x48E,208);bpoke(i+0x48F,125);bpoke(i+0x490,31);bpoke(i+0x491,64);
bpoke(i+0x493,125);bpoke(i+0x494,31);bpoke(i+0x495,64);bpoke(i+0x496,125);bpoke(i+0x497,7);
bpoke(i+0x498,208);bpoke(i+0x499,117);bpoke(i+0x49A,7);bpoke(i+0x49B,209);bpoke(i+0x49C,244);
bpoke(i+0x4A2,127);bpoke(i+0x4A3,64);
bpoke(i+0x4A4,125);bpoke(i+0x4A6,31);bpoke(i+0x4A7,64);bpoke(i+0x4A9,5);
bpoke(i+0x4AA,81);bpoke(i+0x4AB,244);bpoke(i+0x4AC,31);bpoke(i+0x4AD,71);bpoke(i+0x4AE,208);bpoke(i+0x4AF,125);
bpoke(i+0x4B0,31);bpoke(i+0x4B1,64);bpoke(i+0x4B3,125);bpoke(i+0x4B4,7);bpoke(i+0x4B5,208);
bpoke(i+0x4B6,125);bpoke(i+0x4B7,7);bpoke(i+0x4B8,208);bpoke(i+0x4B9,80);bpoke(i+0x4BA,7);bpoke(i+0x4BB,215);
bpoke(i+0x4BC,208);
bpoke(i+0x4C2,31);bpoke(i+0x4C3,65);bpoke(i+0x4C4,244);bpoke(i+0x4C6,31);bpoke(i+0x4C7,64);
bpoke(i+0x4CA,1);bpoke(i+0x4CB,244);bpoke(i+0x4CC,31);bpoke(i+0x4CD,71);
bpoke(i+0x4CE,208);bpoke(i+0x4CF,125);bpoke(i+0x4D0,31);bpoke(i+0x4D1,64);bpoke(i+0x4D3,125);
bpoke(i+0x4D4,7);bpoke(i+0x4D5,208);bpoke(i+0x4D6,125);bpoke(i+0x4D7,7);bpoke(i+0x4D8,208);
bpoke(i+0x4DA,7);bpoke(i+0x4DB,223);bpoke(i+0x4DC,244);
bpoke(i+0x4E2,31);bpoke(i+0x4E3,209);bpoke(i+0x4E4,244);
bpoke(i+0x4E6,125);bpoke(i+0x4E8,85);bpoke(i+0x4E9,80);bpoke(i+0x4EA,7);bpoke(i+0x4EB,208);
bpoke(i+0x4EC,31);bpoke(i+0x4ED,71);bpoke(i+0x4EE,208);bpoke(i+0x4EF,125);bpoke(i+0x4F0,31);bpoke(i+0x4F1,64);
bpoke(i+0x4F3,125);bpoke(i+0x4F4,7);bpoke(i+0x4F5,208);bpoke(i+0x4F6,125);bpoke(i+0x4F7,7);
bpoke(i+0x4F8,208);bpoke(i+0x4FA,7);bpoke(i+0x4FB,253);bpoke(i+0x4FC,244);
bpoke(i+0x502,31);bpoke(i+0x503,209);
bpoke(i+0x504,244);bpoke(i+0x505,1);bpoke(i+0x506,244);bpoke(i+0x508,127);bpoke(i+0x509,208);
bpoke(i+0x50A,23);bpoke(i+0x50B,208);bpoke(i+0x50C,31);bpoke(i+0x50D,71);bpoke(i+0x50E,208);bpoke(i+0x50F,125);
bpoke(i+0x510,31);bpoke(i+0x511,64);bpoke(i+0x513,125);bpoke(i+0x514,7);bpoke(i+0x515,208);
bpoke(i+0x516,125);bpoke(i+0x517,7);bpoke(i+0x518,208);bpoke(i+0x519,80);bpoke(i+0x51A,7);bpoke(i+0x51B,244);
bpoke(i+0x51C,125);
bpoke(i+0x522,7);bpoke(i+0x523,247);bpoke(i+0x524,208);bpoke(i+0x525,7);bpoke(i+0x526,208);
bpoke(i+0x528,127);bpoke(i+0x529,208);bpoke(i+0x52A,127);bpoke(i+0x52B,64);bpoke(i+0x52C,31);bpoke(i+0x52D,71);
bpoke(i+0x52E,208);bpoke(i+0x52F,125);bpoke(i+0x530,31);bpoke(i+0x531,64);bpoke(i+0x533,125);
bpoke(i+0x534,7);bpoke(i+0x535,208);bpoke(i+0x536,125);bpoke(i+0x537,7);bpoke(i+0x538,208);bpoke(i+0x539,117);
bpoke(i+0x53A,7);bpoke(i+0x53B,208);bpoke(i+0x53C,125);
bpoke(i+0x542,7);bpoke(i+0x543,247);bpoke(i+0x544,208);bpoke(i+0x545,7);
bpoke(i+0x546,208);bpoke(i+0x548,85);bpoke(i+0x549,81);bpoke(i+0x54A,253);
bpoke(i+0x54C,31);bpoke(i+0x54D,71);bpoke(i+0x54E,208);bpoke(i+0x54F,125);bpoke(i+0x550,31);bpoke(i+0x551,64);
bpoke(i+0x553,125);bpoke(i+0x554,23);bpoke(i+0x555,208);bpoke(i+0x556,125);bpoke(i+0x557,7);
bpoke(i+0x558,208);bpoke(i+0x559,125);bpoke(i+0x55A,7);bpoke(i+0x55B,208);bpoke(i+0x55C,31);bpoke(i+0x55D,64);
bpoke(i+0x562,7);bpoke(i+0x563,255);
bpoke(i+0x564,208);bpoke(i+0x565,31);bpoke(i+0x566,85);bpoke(i+0x567,84);bpoke(i+0x569,1);
bpoke(i+0x56A,245);bpoke(i+0x56B,84);bpoke(i+0x56C,7);bpoke(i+0x56D,215);bpoke(i+0x56E,64);bpoke(i+0x56F,31);
bpoke(i+0x570,93);bpoke(i+0x573,125);bpoke(i+0x574,95);bpoke(i+0x575,64);
bpoke(i+0x576,125);bpoke(i+0x577,1);bpoke(i+0x578,245);bpoke(i+0x579,244);bpoke(i+0x57A,7);bpoke(i+0x57B,208);
bpoke(i+0x57C,7);bpoke(i+0x57D,208);
bpoke(i+0x582,1);bpoke(i+0x583,255);bpoke(i+0x584,64);bpoke(i+0x585,31);bpoke(i+0x586,255);bpoke(i+0x587,244);
bpoke(i+0x589,7);bpoke(i+0x58A,255);bpoke(i+0x58B,244);bpoke(i+0x58C,7);bpoke(i+0x58D,255);
bpoke(i+0x58E,64);bpoke(i+0x58F,31);bpoke(i+0x590,253);bpoke(i+0x593,127);
bpoke(i+0x594,253);bpoke(i+0x595,64);bpoke(i+0x596,125);bpoke(i+0x597,1);bpoke(i+0x598,127);bpoke(i+0x599,244);
bpoke(i+0x59A,7);bpoke(i+0x59B,208);bpoke(i+0x59C,7);bpoke(i+0x59D,208);
bpoke(i+0x5A2,1);bpoke(i+0x5A3,85);bpoke(i+0x5A4,64);bpoke(i+0x5A5,21);
bpoke(i+0x5A6,85);bpoke(i+0x5A7,84);bpoke(i+0x5A9,5);bpoke(i+0x5AA,85);bpoke(i+0x5AB,84);
bpoke(i+0x5AC,1);bpoke(i+0x5AD,85);bpoke(i+0x5AF,5);bpoke(i+0x5B0,84);
bpoke(i+0x5B3,85);bpoke(i+0x5B4,84);bpoke(i+0x5B6,85);
bpoke(i+0x5B8,21);bpoke(i+0x5B9,80);bpoke(i+0x5BA,5);bpoke(i+0x5BB,80);bpoke(i+0x5BC,1);bpoke(i+0x5BD,84);
bpoke(i+0x648,5);bpoke(i+0x649,85);bpoke(i+0x64A,80);bpoke(i+0x64C,21);
bpoke(i+0x64F,85);bpoke(i+0x650,64);bpoke(i+0x651,5);bpoke(i+0x652,80);bpoke(i+0x653,5);
bpoke(i+0x654,84);bpoke(i+0x656,84);bpoke(i+0x658,21);
bpoke(i+0x65A,85);bpoke(i+0x668,7);bpoke(i+0x669,255);bpoke(i+0x66A,244);
bpoke(i+0x66C,29);bpoke(i+0x66E,1);bpoke(i+0x66F,255);bpoke(i+0x670,208);bpoke(i+0x671,7);
bpoke(i+0x672,208);bpoke(i+0x673,7);bpoke(i+0x674,244);bpoke(i+0x676,116);
bpoke(i+0x678,31);bpoke(i+0x679,64);bpoke(i+0x67A,125);
bpoke(i+0x688,7);bpoke(i+0x689,213);
bpoke(i+0x68A,244);bpoke(i+0x68C,127);bpoke(i+0x68D,64);bpoke(i+0x68E,1);bpoke(i+0x68F,213);
bpoke(i+0x690,244);bpoke(i+0x691,7);bpoke(i+0x692,244);bpoke(i+0x693,7);bpoke(i+0x694,244);bpoke(i+0x695,1);
bpoke(i+0x696,253);bpoke(i+0x698,31);bpoke(i+0x699,64);bpoke(i+0x69A,125);
bpoke(i+0x6A8,7);bpoke(i+0x6A9,209);bpoke(i+0x6AA,253);bpoke(i+0x6AC,127);bpoke(i+0x6AD,64);
bpoke(i+0x6AE,7);bpoke(i+0x6AF,209);bpoke(i+0x6B0,244);bpoke(i+0x6B1,7);bpoke(i+0x6B2,221);bpoke(i+0x6B3,29);
bpoke(i+0x6B4,244);bpoke(i+0x6B5,1);bpoke(i+0x6B6,253);bpoke(i+0x6B8,31);bpoke(i+0x6B9,208);
bpoke(i+0x6BA,125);
bpoke(i+0x6C8,7);bpoke(i+0x6C9,209);bpoke(i+0x6CA,116);bpoke(i+0x6CB,1);
bpoke(i+0x6CC,247);bpoke(i+0x6CD,208);bpoke(i+0x6CE,7);bpoke(i+0x6CF,208);bpoke(i+0x6D0,80);bpoke(i+0x6D1,7);
bpoke(i+0x6D2,221);bpoke(i+0x6D3,29);bpoke(i+0x6D4,244);bpoke(i+0x6D5,7);bpoke(i+0x6D6,223);bpoke(i+0x6D7,64);
bpoke(i+0x6D8,31);bpoke(i+0x6D9,244);bpoke(i+0x6DA,125);
bpoke(i+0x6E8,7);bpoke(i+0x6E9,213);
bpoke(i+0x6EA,244);bpoke(i+0x6EB,1);bpoke(i+0x6EC,215);bpoke(i+0x6ED,208);bpoke(i+0x6EE,7);bpoke(i+0x6EF,208);
bpoke(i+0x6F1,7);bpoke(i+0x6F2,221);bpoke(i+0x6F3,29);bpoke(i+0x6F4,244);bpoke(i+0x6F5,7);
bpoke(i+0x6F6,95);bpoke(i+0x6F7,64);bpoke(i+0x6F8,31);bpoke(i+0x6F9,125);bpoke(i+0x6FA,125);
bpoke(i+0x708,7);bpoke(i+0x709,255);bpoke(i+0x70A,208);bpoke(i+0x70B,7);bpoke(i+0x70C,215);bpoke(i+0x70D,244);
bpoke(i+0x70E,7);bpoke(i+0x70F,208);bpoke(i+0x711,7);bpoke(i+0x712,221);bpoke(i+0x713,29);
bpoke(i+0x714,244);bpoke(i+0x715,31);bpoke(i+0x716,95);bpoke(i+0x717,208);bpoke(i+0x718,31);bpoke(i+0x719,93);
bpoke(i+0x71A,125);
bpoke(i+0x728,7);bpoke(i+0x729,213);bpoke(i+0x72A,64);bpoke(i+0x72B,7);
bpoke(i+0x72C,65);bpoke(i+0x72D,244);bpoke(i+0x72E,7);bpoke(i+0x72F,208);bpoke(i+0x730,80);bpoke(i+0x731,7);
bpoke(i+0x732,215);bpoke(i+0x733,117);bpoke(i+0x734,244);bpoke(i+0x735,29);bpoke(i+0x736,7);bpoke(i+0x737,208);
bpoke(i+0x738,31);bpoke(i+0x739,95);bpoke(i+0x73A,125);bpoke(i+0x748,7);bpoke(i+0x749,208);
bpoke(i+0x74B,7);bpoke(i+0x74C,85);bpoke(i+0x74D,253);bpoke(i+0x74E,7);bpoke(i+0x74F,209);
bpoke(i+0x750,244);bpoke(i+0x751,7);bpoke(i+0x752,215);bpoke(i+0x753,245);bpoke(i+0x754,244);bpoke(i+0x755,29);
bpoke(i+0x756,87);bpoke(i+0x757,244);bpoke(i+0x758,31);bpoke(i+0x759,71);bpoke(i+0x75A,253);
bpoke(i+0x768,7);bpoke(i+0x769,208);bpoke(i+0x76B,31);bpoke(i+0x76C,255);bpoke(i+0x76D,253);
bpoke(i+0x76E,7);bpoke(i+0x76F,209);bpoke(i+0x770,244);bpoke(i+0x771,7);bpoke(i+0x772,209);bpoke(i+0x773,209);
bpoke(i+0x774,244);bpoke(i+0x775,127);bpoke(i+0x776,255);bpoke(i+0x777,244);bpoke(i+0x778,31);bpoke(i+0x779,71);
bpoke(i+0x77A,253);bpoke(i+0x788,7);bpoke(i+0x789,208);bpoke(i+0x78B,31);
bpoke(i+0x78C,85);bpoke(i+0x78D,95);bpoke(i+0x78E,71);bpoke(i+0x78F,213);bpoke(i+0x790,244);bpoke(i+0x791,7);
bpoke(i+0x792,209);bpoke(i+0x793,81);bpoke(i+0x794,244);bpoke(i+0x795,125);bpoke(i+0x796,85);bpoke(i+0x797,125);
bpoke(i+0x798,31);bpoke(i+0x799,65);bpoke(i+0x79A,253);
bpoke(i+0x7A8,7);bpoke(i+0x7A9,208);
bpoke(i+0x7AA,1);bpoke(i+0x7AB,125);bpoke(i+0x7AD,31);bpoke(i+0x7AE,65);bpoke(i+0x7AF,127);
bpoke(i+0x7B0,208);bpoke(i+0x7B1,7);bpoke(i+0x7B2,208);bpoke(i+0x7B3,65);bpoke(i+0x7B4,245);bpoke(i+0x7B5,244);
bpoke(i+0x7B7,125);bpoke(i+0x7B8,31);bpoke(i+0x7B9,65);bpoke(i+0x7BA,253);
bpoke(i+0x7C8,5);bpoke(i+0x7C9,85);bpoke(i+0x7CA,85);bpoke(i+0x7CB,85);bpoke(i+0x7CD,21);
bpoke(i+0x7CE,85);bpoke(i+0x7CF,85);bpoke(i+0x7D0,85);bpoke(i+0x7D1,85);bpoke(i+0x7D2,80);bpoke(i+0x7D3,65);
bpoke(i+0x7D4,85);bpoke(i+0x7D5,84);bpoke(i+0x7D7,85);bpoke(i+0x7D8,85);bpoke(i+0x7D9,64);
bpoke(i+0x7DA,85);

	for(i=1;i<1024+32;i=i+32){ 		
	   memcpy(0x7800-i+1,0xe000+1024,i);
	   memcpy(0x7000    ,0xe000+1024-i+1,i);
	   for(j=0;j<200;j++){}
        }

        for (j=1;j<25000;j++){}
        memset(0x7000,0,2048);
        memset(0xe000,0,2048);

}







int display_dick(int i){
bpoke(i+0x002,2);bpoke(i+0x003,170);bpoke(i+0x004,170);
bpoke(i+0x022,42);bpoke(i+0x023,168);bpoke(i+0x024,162);bpoke(i+0x025,168);
bpoke(i+0x042,170);bpoke(i+0x043,170);bpoke(i+0x044,170);bpoke(i+0x045,170);bpoke(i+0x046,160);
bpoke(i+0x061,10);bpoke(i+0x062,170);bpoke(i+0x063,170);bpoke(i+0x064,170);bpoke(i+0x065,162);
bpoke(i+0x066,8);bpoke(i+0x081,170);bpoke(i+0x082,136);bpoke(i+0x083,42);
bpoke(i+0x084,170);bpoke(i+0x085,170);bpoke(i+0x086,170);bpoke(i+0x087,128);
bpoke(i+0x0A0,2);bpoke(i+0x0A1,170);
bpoke(i+0x0A2,8);bpoke(i+0x0A5,170);bpoke(i+0x0A6,170);bpoke(i+0x0A7,32);
bpoke(i+0x0C0,10);bpoke(i+0x0C1,170);bpoke(i+0x0C2,32);bpoke(i+0x0C5,10);
bpoke(i+0x0C6,170);bpoke(i+0x0C7,160);
bpoke(i+0x0E0,10);bpoke(i+0x0E1,170);bpoke(i+0x0E2,128);
bpoke(i+0x0E5,2);bpoke(i+0x0E6,42);bpoke(i+0x0E7,160);
bpoke(i+0x100,42);bpoke(i+0x101,170);
bpoke(i+0x102,160);bpoke(i+0x106,170);bpoke(i+0x107,168);
bpoke(i+0x120,42);bpoke(i+0x121,170);bpoke(i+0x122,160);
bpoke(i+0x126,42);bpoke(i+0x127,168);
bpoke(i+0x140,170);bpoke(i+0x141,170);bpoke(i+0x142,170);bpoke(i+0x143,160);
bpoke(i+0x146,10);bpoke(i+0x147,168);bpoke(i+0x160,138);bpoke(i+0x161,170);
bpoke(i+0x162,170);bpoke(i+0x163,170);bpoke(i+0x164,128);bpoke(i+0x166,2);bpoke(i+0x167,170);
bpoke(i+0x180,138);bpoke(i+0x181,170);bpoke(i+0x182,2);bpoke(i+0x184,42);bpoke(i+0x185,2);
bpoke(i+0x186,130);bpoke(i+0x187,170);
bpoke(i+0x1A0,128);bpoke(i+0x1A1,168);bpoke(i+0x1A2,2);bpoke(i+0x1A3,170);
bpoke(i+0x1A4,170);bpoke(i+0x1A5,138);bpoke(i+0x1A6,170);bpoke(i+0x1A7,138);
bpoke(i+0x1C0,10);bpoke(i+0x1C1,160);
bpoke(i+0x1C2,8);bpoke(i+0x1C4,170);bpoke(i+0x1C5,170);bpoke(i+0x1C6,160);bpoke(i+0x1C7,168);
bpoke(i+0x1E0,8);bpoke(i+0x1E1,32);bpoke(i+0x1E2,2);bpoke(i+0x1E4,34);bpoke(i+0x1E5,10);
bpoke(i+0x1E6,170);bpoke(i+0x1E7,168);bpoke(i+0x200,136);bpoke(i+0x203,170);
bpoke(i+0x204,160);bpoke(i+0x205,10);bpoke(i+0x206,170);bpoke(i+0x207,160);
bpoke(i+0x220,128);bpoke(i+0x225,10);bpoke(i+0x227,160);
bpoke(i+0x240,128);bpoke(i+0x241,128);bpoke(i+0x245,2);bpoke(i+0x246,170);bpoke(i+0x247,128);
bpoke(i+0x260,42);bpoke(i+0x261,128);bpoke(i+0x262,2);bpoke(i+0x263,160);
bpoke(i+0x264,162);bpoke(i+0x265,168);bpoke(i+0x266,2);
bpoke(i+0x281,168);bpoke(i+0x282,2);bpoke(i+0x283,128);bpoke(i+0x284,42);bpoke(i+0x285,162);bpoke(i+0x286,2);
bpoke(i+0x2A1,42);bpoke(i+0x2A2,2);bpoke(i+0x2A3,160);bpoke(i+0x2A5,2);
bpoke(i+0x2A6,168);bpoke(i+0x2C1,42);bpoke(i+0x2C2,160);bpoke(i+0x2C3,42);
bpoke(i+0x2C4,168);bpoke(i+0x2C5,2);bpoke(i+0x2C6,168);
bpoke(i+0x2E1,10);bpoke(i+0x2E2,168);bpoke(i+0x2E4,128);bpoke(i+0x2E5,160);bpoke(i+0x2E6,160);
bpoke(i+0x301,10);bpoke(i+0x302,128);bpoke(i+0x306,160);bpoke(i+0x322,160);bpoke(i+0x323,2);
bpoke(i+0x324,170);bpoke(i+0x325,2);bpoke(i+0x326,128);
bpoke(i+0x342,168);bpoke(i+0x345,2);bpoke(i+0x362,10);bpoke(i+0x363,128);bpoke(i+0x365,40);
bpoke(i+0x383,168);bpoke(i+0x384,10);bpoke(i+0x385,128);bpoke(i+0x3A3,2);bpoke(i+0x3A4,160);
}




int main()
{
	int a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,x,y,z;
	int dir, dira, dirb;
    	vz_mode(1);
	memset (0xe000,0,2048);
	memset (0xe800,0,2048);
	i=0;
        z=0;
	dir = 1;
	dira = 1;
	dirb = 1;
	x = 64;
	y = 64;
	i = 28672;
	j = 64;
	k = 2;
	l = 0;
	a=1;
	b=1;
	c=3;
	d=3;
	e=16;
	f=32;
	vz_setbase( 0x7000 );
	asm("di\n");

        i=0xe000;
	display_intro(i);


        i=28672;

	while (z==0)
	{
        i=28672;
	memset(0x7000,0,2048);
	memset(0x7000,255,31);
//	memset(0x7000+(29*32),255,31);

	
	display_dick(i);


// DSE shadow
k=0;l=0;j=0;
for (i=0;i<8*32;i++){
	b=bpeek(28672 + (i) );
	j++;	if (j==31){j=0;l++;}
	bpoke   (28672 + 32*32 + (l*32) + j -1, b);
}


GHOST

011110
101101
101101
111111
111111
101101






// move dots
        k=0;
	for (j=1;j<10;j++){

	   for (i=7;i<31;i=i+3){bpoke(28672+(24*32)+i,00);bpoke(28672+(25*32)+i,00);}
	   for (i=9;i<31;i=i+3){bpoke(28672+(24*32)+i,80);bpoke(28672+(25*32)+i,80);}

	if (k==0){
		bpoke(28672+23*32+3,8);	 bpoke(28672+23*32+4,8);
		bpoke(28672+24*32+3,8);  bpoke(28672+24*32+4,8);
		bpoke(28672+25*32+3,8);  bpoke(28672+25*32+4,8);
		bpoke(28672+26*32+3,2);  bpoke(28672+26*32+4,160);
                k=1;
		} 
        else
	if (k==1){
		bpoke(28672+23*32+3,0);	bpoke(28672+23*32+4,0);
		bpoke(28672+24*32+3,0);	bpoke(28672+24*32+4,0);
		bpoke(28672+25*32+3,0);	bpoke(28672+25*32+4,0);
		bpoke(28672+26*32+3,0);	bpoke(28672+26*32+4,0);
                k=0;
		}


              for (l=1;l<1500;l++){}
	   for (i=9;i<31;i=i+3){bpoke(28672+(24*32)+i,00);bpoke(28672+(25*32)+i,00);}
	   for (i=8;i<31;i=i+3){bpoke(28672+(24*32)+i,80);bpoke(28672+(25*32)+i,80);}


              for (l=1;l<1500;l++){}
	   for (i=8;i<31;i=i+3){bpoke(28672+(24*32)+i,00);bpoke(28672+(25*32)+i,00);}
	   for (i=7;i<31;i=i+3){bpoke(28672+(24*32)+i,80);bpoke(28672+(25*32)+i,80);}





              for (l=1;l<1500;l++){}
	}
        for (i=7;i<31;i=i+3){bpoke(28672+(24*32)+i,00);bpoke(28672+(25*32)+i,00);}


// setup stationery dots

//	for (i=8;i<31;i=i+3){bpoke(0xe000+(24*32)+i,80);bpoke(0xe000+(25*32)+i,80);}
//	for (i=31;i<8;i=i-3){bpoke(0xe000+(24*32)+i,80);bpoke(0xe000+(25*32)+i,80);}
	k=0;

// move dick
	for (i=1;i<19;i=i+1){
	   memset (0xe000, 0 , 2048);
	   memset(0xe000,255,31);
//	   memset(0xe000+(29*32),255,15);

 	   for (j=31;j>i+3;j=j-3){bpoke(0xe000+(24*32)+j,80);bpoke(0xe000+(25*32)+j,80);}
	   display_dick(i+0xe000);


//shadow

m=0;n=0;o=0;
for (o=0;o<8*32;o++){
	b=bpeek(28672 + (o) );
	m++;	if (m==31){m=0;n++;}
	bpoke   (0xe000 + 32*32 + (n*32) + m -1, b);
}


//	      for (j=1;j<31;j++){bpoke(0xe000+(j*32)+i-1,00);}


	if (k==0){
		bpoke(0xe000+23*32+3+i,8);  bpoke(0xe000+23*32+4+i,8);
		bpoke(0xe000+24*32+3+i,8);  bpoke(0xe000+24*32+4+i,8);
		bpoke(0xe000+25*32+3+i,8);  bpoke(0xe000+25*32+4+i,8);
		bpoke(0xe000+26*32+3+i,2);  bpoke(0xe000+26*32+4+i,160);
                k=1;
		} 
        else
	if (k==1){
		bpoke(0xe000+23*32+3+i,0);	bpoke(0xe000+23*32+4+i,0);
		bpoke(0xe000+24*32+3+i,0);	bpoke(0xe000+24*32+4+i,0);
		bpoke(0xe000+25*32+3+i,0);	bpoke(0xe000+25*32+4+i,0);
		bpoke(0xe000+26*32+3+i,0);	bpoke(0xe000+26*32+4+i,0);
                k=0;
		}


	   memcpy (28672, 0xe000, 2048);
//           for (l=1;l<250;l++){}
	}









//	memcpy (28672, 0xE000 , 2048);
		}
}
	















