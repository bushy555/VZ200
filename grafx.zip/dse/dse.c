 #include <vz.h>
 #include <graphics.h>
 #include <stdio.h>
 #include <sound.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <strings.h>
 #include <conio.h>

int main()
{
	int a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,x,y,z;
	int dir, dira, dirb;
    	vz_mode(1);
	i=0;
        z=0;
	dir = 1;
	dira = 1;
	dirb = 1;
	x = 64;
	y = 64;
	i = 28672;
	j = 64;
	k = 2;
	a=1;
	b=1;
	c=3;
	d=3;
	e=16;
	f=32;
	vz_setbase( 0x7000 );
	asm("di\n");
	while (z==0)
	{

bpoke(i+0x002,2);bpoke(i+0x003,170);bpoke(i+0x004,170);bpoke(i+0x00A,170);bpoke(i+0x00B,170);
bpoke(i+0x00C,42);bpoke(i+0x00D,168);bpoke(i+0x011,10);
bpoke(i+0x012,138);bpoke(i+0x013,170);bpoke(i+0x014,170);bpoke(i+0x015,170);bpoke(i+0x016,128);
bpoke(i+0x019,34);bpoke(i+0x01A,40);bpoke(i+0x01B,170);bpoke(i+0x01C,170);bpoke(i+0x01D,170);
bpoke(i+0x01E,168);bpoke(i+0x020,2);bpoke(i+0x021,170);bpoke(i+0x022,170);bpoke(i+0x023,170);
bpoke(i+0x024,168);bpoke(i+0x025,34);bpoke(i+0x026,170);bpoke(i+0x028,8);bpoke(i+0x029,170);
bpoke(i+0x02A,168);bpoke(i+0x02D,34);bpoke(i+0x02E,170);bpoke(i+0x02F,128);
bpoke(i+0x030,10);bpoke(i+0x031,170);bpoke(i+0x032,160);bpoke(i+0x035,34);
bpoke(i+0x036,170);bpoke(i+0x037,128);bpoke(i+0x038,42);bpoke(i+0x039,168);bpoke(i+0x03A,128);
bpoke(i+0x03D,10);bpoke(i+0x03E,170);bpoke(i+0x03F,160);bpoke(i+0x040,42);bpoke(i+0x041,168);
bpoke(i+0x045,10);bpoke(i+0x046,170);bpoke(i+0x047,160);bpoke(i+0x048,42);bpoke(i+0x049,160);bpoke(i+0x04D,10);
bpoke(i+0x04E,170);bpoke(i+0x04F,168);bpoke(i+0x050,42);bpoke(i+0x051,128);
bpoke(i+0x054,170);bpoke(i+0x055,170);bpoke(i+0x056,170);bpoke(i+0x057,160);bpoke(i+0x058,170);bpoke(i+0x059,128);
bpoke(i+0x05B,42);bpoke(i+0x05C,162);bpoke(i+0x05D,130);bpoke(i+0x05E,170);bpoke(i+0x05F,168);
bpoke(i+0x060,170);bpoke(i+0x061,34);bpoke(i+0x062,130);bpoke(i+0x063,168);bpoke(i+0x065,128);
bpoke(i+0x066,170);bpoke(i+0x067,130);bpoke(i+0x068,162);bpoke(i+0x069,170);bpoke(i+0x06A,170);bpoke(i+0x06B,170);
bpoke(i+0x06C,170);bpoke(i+0x06D,128);bpoke(i+0x06E,42);bpoke(i+0x06F,2);bpoke(i+0x070,42);
bpoke(i+0x072,162);bpoke(i+0x073,160);bpoke(i+0x075,128);bpoke(i+0x076,32);bpoke(i+0x077,162);
bpoke(i+0x078,42);bpoke(i+0x079,168);bpoke(i+0x07A,160);bpoke(i+0x07B,40);bpoke(i+0x07C,42);
bpoke(i+0x07F,32);bpoke(i+0x080,8);bpoke(i+0x082,32);bpoke(i+0x083,2);
bpoke(i+0x084,128);bpoke(i+0x087,8);bpoke(i+0x088,2);bpoke(i+0x089,138);bpoke(i+0x08A,128);bpoke(i+0x08F,32);
bpoke(i+0x091,160);bpoke(i+0x092,32);bpoke(i+0x093,10);bpoke(i+0x094,32);
bpoke(i+0x096,10);bpoke(i+0x097,8);bpoke(i+0x099,128);bpoke(i+0x09A,170);bpoke(i+0x09B,168);
bpoke(i+0x09C,10);bpoke(i+0x09E,42);bpoke(i+0x09F,32);bpoke(i+0x0A1,138);
bpoke(i+0x0A2,136);bpoke(i+0x0A3,160);bpoke(i+0x0A4,2);bpoke(i+0x0A6,168);bpoke(i+0x0A7,128);
bpoke(i+0x0A9,42);bpoke(i+0x0AB,10);bpoke(i+0x0AC,168);bpoke(i+0x0AD,138);
bpoke(i+0x0AE,168);bpoke(i+0x0B1,8);bpoke(i+0x0B2,170);bpoke(i+0x0B3,32);
bpoke(i+0x0B4,32);bpoke(i+0x0B5,42);bpoke(i+0x0B6,160);bpoke(i+0x0B9,10);bpoke(i+0x0BB,2);bpoke(i+0x0BD,10);bpoke(i+0x0BE,128);
bpoke(i+0x0C1,2);bpoke(i+0x0C2,130);bpoke(i+0x0C3,170);bpoke(i+0x0C5,10);bpoke(i+0x0CA,128);bpoke(i+0x0CB,40);
bpoke(i+0x0CD,168);bpoke(i+0x0D2,32);bpoke(i+0x0D4,2);bpoke(i+0x0D5,128);
bpoke(i+0x0DA,10);bpoke(i+0x0DB,160);bpoke(i+0x0DC,168);bpoke(i+0x0E3,42);

a=0
for a=1to29/4
	for j=1to4
		for i=0to31
                 	b=peek((a*j)+i)
		
	

//	memcpy (28672, 0xE000 , 2048);
		}
}
	
