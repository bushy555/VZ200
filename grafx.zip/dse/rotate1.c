// To build it for a Spectrum:
//  zcc +zx -create-app -lndos -lm rotate.c
//  zcc +zx -create-app -lndos -lmzx_tiny rotate.c
//
//To build it for a ZX81:
//  zcc +zx81 -startup=3 -lgfx81hr192 -create-app -lm rotate.c
//
//VZ:  zcc +vz -create-app -lm rotate.c -o rotate.vz



 #include <vz.h>
 #include <graphics.h>
 #include <stdio.h>
 #include <sound.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <strings.h>
 #include <conio.h>
#include <math.h>
#include <string.h>



//  	vz_mode(1);
//	vz_setbase( 0x7000 );
//	asm("di\n");


// Set the font location here.

//#ifdef __VZ200__
#define FONT 65
//#endif


//#ifdef __SPECTRUM__
//#define FONT 15360
//#endif

//#ifdef __ZX81__
//#define FONT 7680
//#endif


float s,g,e;
int a,b,c,d;
unsigned char p,q;

void rotate_text(int width, int height, int x, int y, int angle, char *text)
{
 x+=width*7; y+=height*8;
 g=angle/180.0*pi();
 s=sin(g); g=cos(g);
 a=0;
 
//#ifdef __ZX81__
// text=strlwr(text);
//#endif
//#ifdef __VZ200__
// text=strlwr(text);
//#endif
 
 while (text[a]!=0) {
//#ifdef __ZX81__
//   b=FONT+ascii_zx(text[a])*8+7;
//#else


//   b=FONT+text[a]*8+7;
//   b=FONT+text[a]*8+7;

   b=FONT+text[a];

//#endif
   for (c=6;c>0;c--) {
     p=*(b-c);
     for (d=0;d<7;d++) {
       q=p/2;
       if (p&1)
         for (e=0.0;e<(0.0+height);e+=0.4) {
           plot(x+(c*height+e)*s-d*width*g,y-(c*height+e)*g-d*width*s);
           drawr((1.2-width)*g,(1.2-width)*s);
         }
       p=q;
     }
   }
   x=x+g*width*8.0;
   y=y+s*width*8.0-g*width;
   
   a++;
 }
}


void main()
{
	clg();

	rotate_text(3, 5, 0, 0, 48, "H I !!");
//	rotate_text(3, 5, 0, 0, 48, "Hello World!");
//	rotate_text(3, 5, 0, 0, 8, "Hello World!");
}

