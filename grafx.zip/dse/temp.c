 #include <vz.h>
 #include <graphics.h>
 #include <stdio.h>
 #include <sound.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <strings.h>
 #include <conio.h>


int smile[] =
{
85, 170, 255, 0, 85, 85, 170, 170, 255, 255,0,0,0,0,0,0,0
};


char smile2[] =
{
85, 170, 255, 0, 85, 85, 170, 170, 255, 255,0,0,0,0,0,0,0
};













int main()
{
	int a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,x,y,z;
	int dir, dira, dirb;
    	vz_mode(1);
	i=0;
        z=0;
	dir = 1;
	dira = 1;
	dirb = 1;
	x = 64;
	y = 64;
	i = 28672;
	j = 64;
	k = 2;
	l = 0;
	a=1;
	b=1;
	c=3;
	d=3;
	e=16;
	f=32;
	vz_setbase( 0x7000 );

	z=0;
	while (z==0){

                bpoke (0x7800-16,255);                bpoke (0x7800-16-32,255);                 bpoke (0x7800-16-64,255);

	        for (i=0;i<17;i++){
			bpoke(0x7000+i, smile[i]);
		}


	        for (i=0;i<17;i++){
			bpoke(0x7100+i, smile2[i]);
		}


	        for (i=0;i<17;i++){
			bpoke(0x7200+i, smile(i));
		}


	        for (i=0;i<17;i++){
			bpoke(0x7300+i, smile2(i));
		}


	}


}
	















