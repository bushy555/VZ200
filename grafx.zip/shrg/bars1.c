 #include <vz.h>
 #include <graphics.h>
 #include <stdio.h>
 #include <sound.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <strings.h>
 #include <conio.h>




int main()
{
	int a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,x,y,z;
    	vz_mode(1);
	x = 64;
	y = 64;
	i = 28672;
	j = 64;


	vz_setbase(0x7000);
	wpoke(30779, wpeek(30779) | 2);
	outp(222,0);
    	vz_mode(1);
	outp(222,1);
    	vz_mode(1);
	outp(222,2);
    	vz_mode(1);
	asm("di\n");





	z=0;
	while (z==0){


		k=0;l=1;
        		for (j=0;j<64;j++){
					memset(0xe000,0,2048);
		        	for (i=0;i<32;i++){

//					bpoke(0xE000+((j-1)*32)+i, 0);
					bpoke(0xE000+(j*32)+i, 255);
				}
				outp(222,0);
				memcpy(0x7000,0xe000, 2048);
			}


        		for (j=0;j<64;j++){
					memset(0xe000,0,2048);
		        	for (i=0;i<32;i++){
//					bpoke(0xE000+((j-1)*32)+i, 0);
					bpoke(0xE000+(j*32)+i, 255);
				}
				outp(222,1);
				memcpy(0x7000,0xe000, 2048);
			}


        		for (j=0;j<64;j++){
					memset(0xe000,0,2048);
		        	for (i=0;i<32;i++){
//					bpoke(0xE000+((j-1)*32)+i, 0);
					bpoke(0xE000+(j*32)+i, 255);
				}
				outp(222,2);
				memcpy(0x7000,0xe000, 2048);
			}



		}
	}

	








