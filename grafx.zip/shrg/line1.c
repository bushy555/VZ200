#include <graphics.h>
#include <stdio.h>
 #include <sound.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <strings.h>
 #include <conio.h>
#include <vz.h>


main()
{
	int m,n,i,j,k, l,  o,p,x,y,z;
	vz_setbase(0x7000);
	wpoke(30779, (wpeek(30779) | 2));
//	wpoke(30779, 8);

	vz_setbase(0x7000);
	outp(222,2);
    	vz_mode(1);
	vz_setbase(28672+2048);

	outp(222,1);
    	vz_mode(1);
	vz_setbase(28672+2048+2048);
	outp(222,0);
    	vz_mode(1);

	asm("di\n");
wpoke(28672+81,85);wpoke(28672+82,85);wpoke(28672+83,85);wpoke(28672+84,85);
wpoke(28672+82,3);wpoke(28672+83,3);wpoke(28672+84,3);wpoke(28672+85,3);
wpoke(28672+92,133);wpoke(28672+93,123);wpoke(28672+94,93);wpoke(28672+95,193);

wpoke(28672+2046,133);wpoke(28672+2047,85);wpoke(28672+2048,85);wpoke(28672+2049,85);
wpoke(28672+2050,133);wpoke(28672+2051,85);wpoke(28672+2052,85);wpoke(28672+2053,85);
wpoke(28672+2055,85);
wpoke(28672+2191,133);wpoke(28672+2190,85);wpoke(28672+2189,85);wpoke(28672+3188,85);
wpoke(28672+2192,85);wpoke(28672+2193,85);wpoke(28672+3194,85);wpoke(28672+3195,85);
wpoke(28672+2196,85);wpoke(28672+2197,85);wpoke(28672+3198,85);wpoke(28672+3192,85);
wpoke(28672+2206,85);wpoke(28672+2207,85);wpoke(28672+3208,85);wpoke(28672+3209,85);

wpoke(28672+3606,85);wpoke(28672+3607,85);wpoke(28672+3608,85);wpoke(28672+3609,85);
wpoke(28672+3006,85);wpoke(28672+3107,85);wpoke(28672+3108,85);wpoke(28672+3109,85);



//set
// OUTP( 222,Y/64);
// PA:= 28672 + 32 * (Y AND 63) + INT(X/8) 
// X1=2^(7-(X AND 7))
// WPOKE (PA, WPEEK(PA) | X1)


//reset
// OUTP( 222,Y/64);
// PA:= 28672 + 32 * (Y AND 63) + INT(X/8) 
// X1=2^(7-(X AND 7))
// WPOKE (PA, PEEK(PA) AND 255 - X1)
 





	for(i=1;i<32000;i++){}				//short delay
	for(i=1;i<32000;i++){}				//short delay
	for(i=1;i<32000;i++){}				//short delay
	for(i=1;i<32000;i++){}				//short delay



wpoke(0x701A,20);wpoke(0x701E,5);wpoke(0x701F,64);wpoke(0x703A,5);wpoke(0x703E,20);wpoke(0x704D,5);
wpoke(0x704E,85);wpoke(0x705A,1);wpoke(0x705B,64);wpoke(0x705D,1);wpoke(0x705E,80);wpoke(0x706C,1);
wpoke(0x706D,85);wpoke(0x706E,85);wpoke(0x706F,80);wpoke(0x707C,21);wpoke(0x707D,64);wpoke(0x7085,85);
wpoke(0x7086,80);wpoke(0x708C,21);wpoke(0x708D,85);wpoke(0x708E,85);wpoke(0x708F,84);wpoke(0x709B,1);
wpoke(0x709C,85);wpoke(0x709D,84);wpoke(0x70A4,5);wpoke(0x70A5,85);wpoke(0x70A6,84);wpoke(0x70AC,5);
wpoke(0x70AD,85);wpoke(0x70AE,85);wpoke(0x70AF,85);wpoke(0x70B9,1);wpoke(0x70BA,64);wpoke(0x70BB,5);
wpoke(0x70BC,85);wpoke(0x70BD,85);wpoke(0x70C4,21);wpoke(0x70C5,85);wpoke(0x70C6,85);wpoke(0x70C7,85);
wpoke(0x70C8,64);wpoke(0x70CC,5);wpoke(0x70CD,85);wpoke(0x70CE,85);wpoke(0x70CF,85);wpoke(0x70DA,21);
wpoke(0x70DB,5);wpoke(0x70DC,85);wpoke(0x70DD,85);wpoke(0x70DE,5);wpoke(0x70DF,64);wpoke(0x70E3,1);
wpoke(0x70E4,85);wpoke(0x70E5,85);wpoke(0x70E6,85);wpoke(0x70E7,85);wpoke(0x70E8,84);wpoke(0x70EC,5);
wpoke(0x70ED,85);wpoke(0x70EE,85);wpoke(0x70EF,85);wpoke(0x70F0,64);wpoke(0x70FB,1);wpoke(0x70FC,85);
wpoke(0x70FD,84);wpoke(0x70FF,21);wpoke(0x7103,5);wpoke(0x7104,85);wpoke(0x7105,85);wpoke(0x7106,85);
wpoke(0x7107,85);wpoke(0x7108,84);wpoke(0x710C,1);wpoke(0x710D,85);wpoke(0x710E,85);wpoke(0x710F,85);
wpoke(0x7110,64);wpoke(0x711C,21);wpoke(0x711D,64);wpoke(0x7123,21);wpoke(0x7124,85);wpoke(0x7125,85);
wpoke(0x7126,85);wpoke(0x7127,85);wpoke(0x7128,80);wpoke(0x712D,85);wpoke(0x712E,85);wpoke(0x712F,85);
wpoke(0x713B,16);wpoke(0x713D,1);wpoke(0x7143,21);wpoke(0x7144,85);wpoke(0x7145,85);wpoke(0x7146,85);
wpoke(0x7147,85);wpoke(0x7148,64);wpoke(0x714D,1);wpoke(0x714E,85);wpoke(0x714F,84);wpoke(0x715B,80);
wpoke(0x715C,1);wpoke(0x715D,1);wpoke(0x715E,64);wpoke(0x7163,21);wpoke(0x7164,85);wpoke(0x7165,85);
wpoke(0x7166,85);wpoke(0x716E,5);wpoke(0x716F,64);wpoke(0x7172,85);wpoke(0x7173,85);wpoke(0x7174,64);
wpoke(0x717A,5);wpoke(0x717C,1);wpoke(0x717E,16);wpoke(0x7183,5);wpoke(0x7184,85);wpoke(0x7185,85);
wpoke(0x7186,85);wpoke(0x7190,1);wpoke(0x7191,85);wpoke(0x7192,85);wpoke(0x7193,85);wpoke(0x7194,80);
wpoke(0x719A,4);wpoke(0x719C,1);wpoke(0x719E,4);wpoke(0x71A4,85);wpoke(0x71A5,85);wpoke(0x71A6,84);
wpoke(0x71B0,5);wpoke(0x71B1,85);wpoke(0x71B2,85);wpoke(0x71B3,85);wpoke(0x71B4,84);wpoke(0x71BC,4);
wpoke(0x71C4,1);wpoke(0x71C5,85);wpoke(0x71C6,80);wpoke(0x71D0,5);wpoke(0x71D1,117);wpoke(0x71D2,117);
wpoke(0x71D3,127);wpoke(0x71D4,213);wpoke(0x71D5,79);wpoke(0x71D6,192);wpoke(0x71D7,3);wpoke(0x71D8,3);
wpoke(0x71DA,255);wpoke(0x71DC,255);wpoke(0x71DD,3);wpoke(0x71DE,3);wpoke(0x71DF,240);wpoke(0x71EA,1);
wpoke(0x71EB,64);wpoke(0x71F0,21);wpoke(0x71F1,213);wpoke(0x71F2,213);wpoke(0x71F3,213);wpoke(0x71F4,117);
wpoke(0x71F5,112);wpoke(0x71F6,48);wpoke(0x71F7,12);wpoke(0x71F8,48);wpoke(0x71F9,3);wpoke(0x71FB,3);
wpoke(0x71FC,3);wpoke(0x71FD,12);wpoke(0x71FE,12);wpoke(0x71FF,12);wpoke(0x7208,21);wpoke(0x7209,80);
wpoke(0x720A,22);wpoke(0x720B,144);wpoke(0x7210,23);wpoke(0x7211,255);wpoke(0x7212,87);wpoke(0x7213,255);
wpoke(0x7214,213);wpoke(0x7215,208);wpoke(0x7217,63);wpoke(0x7218,192);wpoke(0x7219,15);wpoke(0x721A,240);
wpoke(0x721B,15);wpoke(0x721C,252);wpoke(0x721E,3);wpoke(0x721F,192);wpoke(0x7228,106);wpoke(0x7229,164);
wpoke(0x722A,106);wpoke(0x722B,148);wpoke(0x722C,85);wpoke(0x722D,64);wpoke(0x7230,13);wpoke(0x7231,93);
wpoke(0x7232,93);wpoke(0x7233,87);wpoke(0x7234,87);wpoke(0x7235,83);wpoke(0x7237,192);wpoke(0x7238,192);
wpoke(0x7239,48);wpoke(0x723B,48);wpoke(0x723C,192);wpoke(0x723E,192);wpoke(0x7246,1);wpoke(0x7247,85);
wpoke(0x7248,170);wpoke(0x7249,169);wpoke(0x724A,170);wpoke(0x724B,165);wpoke(0x724C,170);wpoke(0x724D,149);
wpoke(0x7250,53);wpoke(0x7251,117);wpoke(0x7252,117);wpoke(0x7253,93);wpoke(0x7254,85);wpoke(0x7255,252);
wpoke(0x7256,3);wpoke(0x7258,48);wpoke(0x7259,15);wpoke(0x725A,240);wpoke(0x725B,192);wpoke(0x725C,48);
wpoke(0x725E,63);wpoke(0x725F,192);wpoke(0x7266,22);wpoke(0x7267,170);wpoke(0x7268,170);wpoke(0x7269,149);
wpoke(0x726A,170);wpoke(0x726B,166);wpoke(0x726C,170);wpoke(0x726D,169);wpoke(0x726E,80);wpoke(0x7270,1);
wpoke(0x7271,85);wpoke(0x7272,85);wpoke(0x7273,85);wpoke(0x7274,85);wpoke(0x7286,90);wpoke(0x7287,170);
wpoke(0x7288,169);wpoke(0x7289,106);wpoke(0x728A,90);wpoke(0x728B,170);wpoke(0x728C,170);wpoke(0x728D,170);
wpoke(0x728E,148);wpoke(0x7290,1);wpoke(0x7291,85);wpoke(0x7292,85);wpoke(0x7293,85);wpoke(0x7294,64);
wpoke(0x72A6,106);wpoke(0x72A7,85);wpoke(0x72A8,86);wpoke(0x72A9,170);wpoke(0x72AA,165);wpoke(0x72AB,85);
wpoke(0x72AC,106);wpoke(0x72AD,170);wpoke(0x72AE,169);wpoke(0x72AF,84);wpoke(0x72B1,169);wpoke(0x72B2,85);
wpoke(0x72B3,170);wpoke(0x72B5,32);wpoke(0x72B7,8);wpoke(0x72B8,2);wpoke(0x72B9,168);wpoke(0x72BB,32);
wpoke(0x72BC,32);wpoke(0x72BD,170);wpoke(0x72BE,160);wpoke(0x72BF,8);wpoke(0x72C5,1);wpoke(0x72C6,169);
wpoke(0x72C7,64);wpoke(0x72C8,21);wpoke(0x72C9,105);wpoke(0x72CA,170);wpoke(0x72CB,164);wpoke(0x72CC,90);
wpoke(0x72CD,149);wpoke(0x72CE,170);wpoke(0x72CF,164);wpoke(0x72D0,2);wpoke(0x72D1,6);wpoke(0x72D2,66);
wpoke(0x72D5,128);wpoke(0x72D7,32);wpoke(0x72D8,8);wpoke(0x72D9,2);wpoke(0x72DB,128);wpoke(0x72DC,128);
wpoke(0x72DD,8);wpoke(0x72DF,32);wpoke(0x72E5,1);wpoke(0x72E6,148);wpoke(0x72E7,2);wpoke(0x72E8,129);
wpoke(0x72E9,165);wpoke(0x72EA,26);wpoke(0x72EB,170);wpoke(0x72EC,69);wpoke(0x72ED,80);wpoke(0x72EE,26);
wpoke(0x72EF,164);wpoke(0x72F0,8);wpoke(0x72F1,8);wpoke(0x72F2,10);wpoke(0x72F3,128);wpoke(0x72F4,2);
wpoke(0x72F7,128);wpoke(0x72F8,32);wpoke(0x72F9,128);wpoke(0x72FA,2);wpoke(0x72FB,170);wpoke(0x72FD,32);
wpoke(0x7306,64);wpoke(0x7307,6);wpoke(0x7308,97);wpoke(0x7309,169);wpoke(0x730A,86);wpoke(0x730B,170);
wpoke(0x730C,150);wpoke(0x730D,165);wpoke(0x730E,5);wpoke(0x730F,80);wpoke(0x7310,32);wpoke(0x7311,32);
wpoke(0x7312,32);wpoke(0x7314,8);wpoke(0x7316,2);wpoke(0x7318,128);wpoke(0x7319,32);wpoke(0x731A,8);
wpoke(0x731B,8);wpoke(0x731D,128);wpoke(0x7327,9);wpoke(0x7328,166);wpoke(0x7329,86);wpoke(0x732A,65);
wpoke(0x732B,90);wpoke(0x732C,170);wpoke(0x732D,170);wpoke(0x732E,80);wpoke(0x7330,170);wpoke(0x7332,10);
wpoke(0x7333,160);wpoke(0x7334,2);wpoke(0x7335,168);wpoke(0x7336,8);wpoke(0x7338,42);wpoke(0x7339,128);
wpoke(0x733A,32);wpoke(0x733B,32);wpoke(0x733C,2);wpoke(0x733E,2);wpoke(0x7347,2);wpoke(0x7348,134);
wpoke(0x7349,170);wpoke(0x734A,64);wpoke(0x734B,5);wpoke(0x734C,86);wpoke(0x734D,170);wpoke(0x734E,148);
wpoke(0x7368,5);wpoke(0x7369,169);wpoke(0x736A,64);wpoke(0x736C,1);wpoke(0x736D,86);wpoke(0x736E,164);
wpoke(0x7388,26);wpoke(0x7389,86);wpoke(0x738A,64);wpoke(0x738D,1);wpoke(0x738E,80);wpoke(0x73A8,26);
wpoke(0x73A9,169);wpoke(0x73AA,64);wpoke(0x73C8,22);wpoke(0x73C9,165);wpoke(0x73E8,25);wpoke(0x73E9,89);
wpoke(0x7408,106);wpoke(0x7409,164);wpoke(0x7418,7);wpoke(0x7419,255);wpoke(0x7428,90);wpoke(0x7429,148);
wpoke(0x7438,7);wpoke(0x7439,255);wpoke(0x7448,101);wpoke(0x7449,100);wpoke(0x7458,4);wpoke(0x7468,106);
wpoke(0x7469,164);wpoke(0x7478,68);wpoke(0x7479,64);wpoke(0x7488,90);wpoke(0x7489,148);wpoke(0x7498,21);
wpoke(0x74A8,101);wpoke(0x74A9,100);wpoke(0x74B8,4);wpoke(0x74BC,1);wpoke(0x74BD,252);wpoke(0x74C7,1);
wpoke(0x74C8,170);wpoke(0x74C9,144);wpoke(0x74D8,4);wpoke(0x74DC,1);wpoke(0x74E7,1);wpoke(0x74E8,170);
wpoke(0x74E9,144);wpoke(0x74F8,4);wpoke(0x74FC,21);wpoke(0x74FD,80);wpoke(0x7507,1);wpoke(0x7508,106);
wpoke(0x7509,80);wpoke(0x7515,4);wpoke(0x7517,1);wpoke(0x7518,85);wpoke(0x7519,80);wpoke(0x751C,1);
wpoke(0x7527,1);wpoke(0x7528,149);wpoke(0x7529,144);wpoke(0x7535,85);wpoke(0x7536,64);wpoke(0x7538,4);
wpoke(0x753C,1);wpoke(0x7547,6);wpoke(0x7548,170);wpoke(0x7549,64);wpoke(0x7555,4);wpoke(0x7558,4);
wpoke(0x755C,1);wpoke(0x7567,6);wpoke(0x7568,170);wpoke(0x7569,64);wpoke(0x7575,4);wpoke(0x7578,4);
wpoke(0x757C,85);wpoke(0x757D,84);wpoke(0x7587,5);wpoke(0x7588,169);wpoke(0x7589,64);wpoke(0x7595,4);
wpoke(0x7598,4);wpoke(0x759A,2);wpoke(0x759C,1);wpoke(0x75A7,6);wpoke(0x75A8,86);wpoke(0x75A9,64);
wpoke(0x75B5,4);wpoke(0x75B7,5);wpoke(0x75B8,85);wpoke(0x75B9,84);wpoke(0x75BA,42);wpoke(0x75BB,128);
wpoke(0x75BC,1);wpoke(0x75C7,90);wpoke(0x75C8,170);wpoke(0x75C9,148);wpoke(0x75D4,1);wpoke(0x75D5,85);
wpoke(0x75D6,80);wpoke(0x75D8,4);wpoke(0x75DA,22);wpoke(0x75DB,128);wpoke(0x75DC,1);wpoke(0x75E6,63);
wpoke(0x75E7,255);wpoke(0x75E8,255);wpoke(0x75E9,255);wpoke(0x75EA,252);wpoke(0x75F5,4);wpoke(0x75F6,3);
wpoke(0x75F7,128);wpoke(0x75F8,4);wpoke(0x75FA,170);wpoke(0x75FB,161);wpoke(0x75FC,85);wpoke(0x75FD,85);
wpoke(0x75FF,7);wpoke(0x7605,63);wpoke(0x7606,255);wpoke(0x7607,255);wpoke(0x7608,255);wpoke(0x7609,255);
wpoke(0x760A,255);wpoke(0x760B,192);wpoke(0x7615,4);wpoke(0x7616,15);wpoke(0x7617,224);wpoke(0x7618,4);
wpoke(0x761A,90);wpoke(0x761B,160);wpoke(0x761C,1);wpoke(0x761F,31);wpoke(0x7624,3);wpoke(0x7625,255);
wpoke(0x7626,255);wpoke(0x7627,255);wpoke(0x7628,255);wpoke(0x7629,255);wpoke(0x762A,255);wpoke(0x762B,255);
wpoke(0x7632,5);wpoke(0x7633,84);wpoke(0x7635,85);wpoke(0x7636,74);wpoke(0x7637,97);wpoke(0x7638,85);
wpoke(0x7639,80);wpoke(0x763A,170);wpoke(0x763B,96);wpoke(0x763C,85);wpoke(0x763D,84);wpoke(0x763F,16);
wpoke(0x7644,255);wpoke(0x7645,255);wpoke(0x7646,255);wpoke(0x7647,255);wpoke(0x7648,255);wpoke(0x7649,255);
wpoke(0x764A,255);wpoke(0x764B,255);wpoke(0x764C,240);wpoke(0x7653,21);wpoke(0x7654,85);wpoke(0x7655,85);
wpoke(0x7656,85);wpoke(0x7657,85);wpoke(0x7658,85);wpoke(0x7659,85);wpoke(0x765A,85);wpoke(0x765B,85);
wpoke(0x765C,85);wpoke(0x765D,85);wpoke(0x765E,85);wpoke(0x765F,64);wpoke(0x7663,15);wpoke(0x7664,255);
wpoke(0x7665,255);wpoke(0x7666,255);wpoke(0x7667,255);wpoke(0x7668,255);wpoke(0x7669,255);wpoke(0x766A,255);
wpoke(0x766B,255);wpoke(0x766C,255);wpoke(0x7673,1);wpoke(0x7674,85);wpoke(0x7675,81);wpoke(0x7676,81);
wpoke(0x7677,81);wpoke(0x7678,81);wpoke(0x7679,81);wpoke(0x767A,81);wpoke(0x767B,81);wpoke(0x767C,81);
wpoke(0x767D,81);wpoke(0x767E,85);wpoke(0x767F,64);wpoke(0x7682,3);wpoke(0x7683,255);wpoke(0x7684,255);
wpoke(0x7685,255);wpoke(0x7686,255);wpoke(0x7687,255);wpoke(0x7688,255);wpoke(0x7689,255);wpoke(0x768A,255);
wpoke(0x768B,255);wpoke(0x768C,255);wpoke(0x768D,192);wpoke(0x7694,5);wpoke(0x7695,85);wpoke(0x7696,21);
wpoke(0x7697,21);wpoke(0x7698,21);wpoke(0x7699,21);wpoke(0x769A,21);wpoke(0x769B,21);wpoke(0x769C,21);
wpoke(0x769D,21);wpoke(0x769E,21);wpoke(0x769F,64);wpoke(0x76A2,63);wpoke(0x76A3,255);wpoke(0x76A4,255);
wpoke(0x76A5,255);wpoke(0x76A6,255);wpoke(0x76A7,255);wpoke(0x76A8,255);wpoke(0x76A9,255);wpoke(0x76AA,255);
wpoke(0x76AB,255);wpoke(0x76AC,255);wpoke(0x76AD,240);wpoke(0x76B5,85);wpoke(0x76B6,85);wpoke(0x76B7,85);
wpoke(0x76B8,85);wpoke(0x76B9,85);wpoke(0x76BA,85);wpoke(0x76BB,85);wpoke(0x76BC,85);wpoke(0x76BD,85);
wpoke(0x76BE,85);wpoke(0x76C0,170);wpoke(0x76C1,170);wpoke(0x76C2,170);wpoke(0x76C3,170);wpoke(0x76C4,170);
wpoke(0x76C5,170);wpoke(0x76C6,154);wpoke(0x76C7,170);wpoke(0x76C8,170);wpoke(0x76C9,170);wpoke(0x76CA,170);
wpoke(0x76CB,170);wpoke(0x76CC,170);wpoke(0x76CD,170);wpoke(0x76CE,170);wpoke(0x76CF,170);wpoke(0x76D0,170);
wpoke(0x76D1,170);wpoke(0x76D2,170);wpoke(0x76D3,170);wpoke(0x76D4,170);wpoke(0x76D5,170);wpoke(0x76D6,170);
wpoke(0x76D7,170);wpoke(0x76D8,170);wpoke(0x76D9,170);wpoke(0x76DA,170);wpoke(0x76DB,170);wpoke(0x76DC,170);
wpoke(0x76DD,170);wpoke(0x76DE,170);wpoke(0x76DF,170);wpoke(0x76E0,166);wpoke(0x76E1,170);wpoke(0x76E2,170);
wpoke(0x76E3,170);wpoke(0x76E4,170);wpoke(0x76E5,106);wpoke(0x76E6,169);wpoke(0x76E7,106);wpoke(0x76E8,170);
wpoke(0x76E9,166);wpoke(0x76EA,170);wpoke(0x76EB,170);wpoke(0x76EC,170);wpoke(0x76ED,170);wpoke(0x76EE,170);
wpoke(0x76EF,154);wpoke(0x76F0,170);wpoke(0x76F1,170);wpoke(0x76F2,169);wpoke(0x76F3,90);wpoke(0x76F4,170);
wpoke(0x76F5,169);wpoke(0x76F6,170);wpoke(0x76F7,170);wpoke(0x76F8,170);wpoke(0x76F9,170);wpoke(0x76FA,106);
wpoke(0x76FB,170);wpoke(0x76FC,170);wpoke(0x76FD,149);wpoke(0x76FE,106);wpoke(0x76FF,170);wpoke(0x7700,170);
wpoke(0x7701,170);wpoke(0x7702,170);wpoke(0x7703,170);wpoke(0x7704,170);wpoke(0x7705,170);wpoke(0x7706,170);
wpoke(0x7707,85);wpoke(0x7708,170);wpoke(0x7709,170);wpoke(0x770A,170);wpoke(0x770B,170);wpoke(0x770C,170);
wpoke(0x770D,166);wpoke(0x770E,165);wpoke(0x770F,170);wpoke(0x7710,170);wpoke(0x7711,154);wpoke(0x7712,170);
wpoke(0x7713,170);wpoke(0x7714,170);wpoke(0x7715,165);wpoke(0x7716,170);wpoke(0x7717,170);wpoke(0x7718,170);
wpoke(0x7719,170);wpoke(0x771A,170);wpoke(0x771B,170);wpoke(0x771C,170);wpoke(0x771D,170);wpoke(0x771E,170);
wpoke(0x771F,149);wpoke(0x7720,170);wpoke(0x7721,170);wpoke(0x7722,170);wpoke(0x7723,170);wpoke(0x7724,86);
wpoke(0x7725,170);wpoke(0x7726,170);wpoke(0x7727,106);wpoke(0x7728,170);wpoke(0x7729,170);wpoke(0x772A,170);
wpoke(0x772B,170);wpoke(0x772C,170);wpoke(0x772D,170);wpoke(0x772E,170);wpoke(0x772F,170);wpoke(0x7730,170);
wpoke(0x7731,170);wpoke(0x7732,170);wpoke(0x7733,170);wpoke(0x7734,170);wpoke(0x7735,170);wpoke(0x7736,170);
wpoke(0x7737,170);wpoke(0x7738,170);wpoke(0x7739,170);wpoke(0x773A,170);wpoke(0x773B,170);wpoke(0x773C,170);
wpoke(0x773D,170);wpoke(0x773E,170);wpoke(0x773F,170);wpoke(0x7740,170);wpoke(0x7741,170);wpoke(0x7742,170);
wpoke(0x7743,170);wpoke(0x7744,170);wpoke(0x7745,170);wpoke(0x7746,170);wpoke(0x7747,170);wpoke(0x7748,170);
wpoke(0x7749,170);wpoke(0x774A,170);wpoke(0x774B,170);wpoke(0x774C,170);wpoke(0x774D,170);wpoke(0x774E,170);
wpoke(0x774F,170);wpoke(0x7750,170);wpoke(0x7751,170);wpoke(0x7752,170);wpoke(0x7753,170);wpoke(0x7754,170);
wpoke(0x7755,170);wpoke(0x7756,170);wpoke(0x7757,170);wpoke(0x7758,170);wpoke(0x7759,170);wpoke(0x775A,170);
wpoke(0x775B,170);wpoke(0x775C,170);wpoke(0x775D,170);wpoke(0x775E,170);wpoke(0x775F,170);wpoke(0x7760,170);
wpoke(0x7761,170);wpoke(0x7762,170);wpoke(0x7763,170);wpoke(0x7764,170);wpoke(0x7765,170);wpoke(0x7766,170);
wpoke(0x7767,170);wpoke(0x7768,170);wpoke(0x7769,170);wpoke(0x776A,170);wpoke(0x776B,170);wpoke(0x776C,170);
wpoke(0x776D,170);wpoke(0x776E,170);wpoke(0x776F,170);wpoke(0x7770,170);wpoke(0x7771,170);wpoke(0x7772,170);
wpoke(0x7773,170);wpoke(0x7774,170);wpoke(0x7775,170);wpoke(0x7776,170);wpoke(0x7777,170);wpoke(0x7778,170);
wpoke(0x7779,170);wpoke(0x777A,170);wpoke(0x777B,170);wpoke(0x777C,170);wpoke(0x777D,170);wpoke(0x777E,170);
wpoke(0x777F,170);wpoke(0x7780,170);wpoke(0x7781,170);wpoke(0x7782,170);wpoke(0x7783,170);wpoke(0x7784,170);
wpoke(0x7785,170);wpoke(0x7786,170);wpoke(0x7787,170);wpoke(0x7788,170);wpoke(0x7789,170);wpoke(0x778A,170);
wpoke(0x778B,170);wpoke(0x778C,170);wpoke(0x778D,170);wpoke(0x778E,170);wpoke(0x778F,170);wpoke(0x7790,170);
wpoke(0x7791,170);wpoke(0x7792,170);wpoke(0x7793,170);wpoke(0x7794,170);wpoke(0x7795,170);wpoke(0x7796,170);
wpoke(0x7797,170);wpoke(0x7798,170);wpoke(0x7799,170);wpoke(0x779A,170);wpoke(0x779B,170);wpoke(0x779C,170);
wpoke(0x779D,170);wpoke(0x779E,170);wpoke(0x779F,170);wpoke(0x77A0,170);wpoke(0x77A1,170);wpoke(0x77A2,170);
wpoke(0x77A3,170);wpoke(0x77A4,170);wpoke(0x77A5,170);wpoke(0x77A6,170);wpoke(0x77A7,170);wpoke(0x77A8,170);
wpoke(0x77A9,170);wpoke(0x77AA,170);wpoke(0x77AB,170);wpoke(0x77AC,170);wpoke(0x77AD,170);wpoke(0x77AE,170);
wpoke(0x77AF,170);wpoke(0x77B0,170);wpoke(0x77B1,170);wpoke(0x77B2,170);wpoke(0x77B3,170);wpoke(0x77B4,170);
wpoke(0x77B5,170);wpoke(0x77B6,170);wpoke(0x77B7,170);wpoke(0x77B8,170);wpoke(0x77B9,170);wpoke(0x77BA,170);
wpoke(0x77BB,170);wpoke(0x77BC,170);wpoke(0x77BD,170);wpoke(0x77BE,170);wpoke(0x77BF,170);wpoke(0x77C0,170);
wpoke(0x77C1,170);wpoke(0x77C2,170);wpoke(0x77C3,170);wpoke(0x77C4,170);wpoke(0x77C5,170);wpoke(0x77C6,170);
wpoke(0x77C7,170);wpoke(0x77C8,170);wpoke(0x77C9,170);wpoke(0x77CA,170);wpoke(0x77CB,170);wpoke(0x77CC,170);
wpoke(0x77CD,170);wpoke(0x77CE,170);wpoke(0x77CF,170);wpoke(0x77D0,170);wpoke(0x77D1,170);wpoke(0x77D2,170);
wpoke(0x77D3,170);wpoke(0x77D4,170);wpoke(0x77D5,170);wpoke(0x77D6,170);wpoke(0x77D7,170);wpoke(0x77D8,170);
wpoke(0x77D9,170);wpoke(0x77DA,170);wpoke(0x77DB,170);wpoke(0x77DC,170);wpoke(0x77DD,170);wpoke(0x77DE,170);
wpoke(0x77DF,170);wpoke(0x77E0,170);wpoke(0x77E1,170);wpoke(0x77E2,170);wpoke(0x77E3,170);wpoke(0x77E4,170);
wpoke(0x77E5,170);wpoke(0x77E6,170);wpoke(0x77E7,170);wpoke(0x77E8,170);wpoke(0x77E9,170);wpoke(0x77EA,170);
wpoke(0x77EB,170);wpoke(0x77EC,170);wpoke(0x77ED,170);wpoke(0x77EE,170);wpoke(0x77EF,170);wpoke(0x77F0,170);
wpoke(0x77F1,170);wpoke(0x77F2,170);wpoke(0x77F3,170);wpoke(0x77F4,170);wpoke(0x77F5,170);wpoke(0x77F6,170);
wpoke(0x77F7,170);wpoke(0x77F8,170);wpoke(0x77F9,170);wpoke(0x77FA,170);wpoke(0x77FB,170);wpoke(0x77FC,170);
wpoke(0x77FD,170);wpoke(0x77FE,170);wpoke(0x77FF,170);
memcpy(0xF000,0x7000,2048);


wpoke(0xE031,160);wpoke(0xE090,10);wpoke(0xE091,168);wpoke(0xE0B1,2);wpoke(0xE0C3,10);wpoke(0xE0C4,170);wpoke(0xE0C5,170);
wpoke(0xE0C6,128);wpoke(0xE0E6,42);wpoke(0xE0E7,170);wpoke(0xE0E8,170);wpoke(0xE109,170);wpoke(0xE10A,170);wpoke(0xE10B,160);
wpoke(0xE110,10);wpoke(0xE111,168);wpoke(0xE12A,2);wpoke(0xE12B,128);wpoke(0xE12F,2);wpoke(0xE130,170);wpoke(0xE131,170);
wpoke(0xE132,128);wpoke(0xE14F,42);wpoke(0xE150,160);wpoke(0xE151,34);wpoke(0xE152,168);wpoke(0xE16F,160);wpoke(0xE171,32);
wpoke(0xE172,10);wpoke(0xE173,170);wpoke(0xE18E,42);wpoke(0xE18F,168);wpoke(0xE191,32);wpoke(0xE192,10);wpoke(0xE193,170);
wpoke(0xE194,160);wpoke(0xE1AE,42);wpoke(0xE1AF,168);wpoke(0xE1B0,8);wpoke(0xE1B1,40);wpoke(0xE1B2,170);wpoke(0xE1B3,2);
wpoke(0xE1B4,170);wpoke(0xE1B5,128);wpoke(0xE1CE,171);wpoke(0xE1CF,234);wpoke(0xE1D0,10);wpoke(0xE1D1,136);wpoke(0xE1D2,162);
wpoke(0xE1D4,170);wpoke(0xE1D5,168);wpoke(0xE1ED,128);wpoke(0xE1EE,175);wpoke(0xE1EF,254);wpoke(0xE1F0,130);wpoke(0xE1F1,168);
wpoke(0xE1F2,162);wpoke(0xE1F4,10);wpoke(0xE1F5,250);wpoke(0xE1F6,128);wpoke(0xE20C,10);wpoke(0xE20D,130);wpoke(0xE20E,191);
wpoke(0xE20F,255);wpoke(0xE210,160);wpoke(0xE211,170);wpoke(0xE212,168);wpoke(0xE213,2);wpoke(0xE214,162);wpoke(0xE215,175);
wpoke(0xE216,170);wpoke(0xE22C,10);wpoke(0xE22D,162);wpoke(0xE22E,255);wpoke(0xE22F,255);wpoke(0xE230,250);wpoke(0xE231,42);
wpoke(0xE232,42);wpoke(0xE233,130);wpoke(0xE234,168);wpoke(0xE235,43);wpoke(0xE236,250);wpoke(0xE237,170);wpoke(0xE238,128);
wpoke(0xE23B,128);wpoke(0xE24C,42);wpoke(0xE24D,234);wpoke(0xE24E,170);wpoke(0xE24F,171);wpoke(0xE250,250);wpoke(0xE251,10);
wpoke(0xE252,160);wpoke(0xE253,170);wpoke(0xE254,168);wpoke(0xE255,43);wpoke(0xE256,255);wpoke(0xE257,250);wpoke(0xE258,170);
wpoke(0xE259,160);wpoke(0xE25B,128);wpoke(0xE267,10);wpoke(0xE268,170);wpoke(0xE269,128);wpoke(0xE26C,43);wpoke(0xE26D,254);
wpoke(0xE26E,170);wpoke(0xE26F,170);wpoke(0xE270,254);wpoke(0xE271,138);wpoke(0xE272,160);wpoke(0xE273,32);wpoke(0xE274,130);
wpoke(0xE275,175);wpoke(0xE276,250);wpoke(0xE277,170);wpoke(0xE278,170);wpoke(0xE279,170);wpoke(0xE27A,160);wpoke(0xE27B,160);
wpoke(0xE289,42);wpoke(0xE28A,160);wpoke(0xE28C,175);wpoke(0xE28D,255);wpoke(0xE28E,255);wpoke(0xE28F,254);wpoke(0xE290,191);
wpoke(0xE291,130);wpoke(0xE292,168);wpoke(0xE293,10);wpoke(0xE294,130);wpoke(0xE295,191);wpoke(0xE296,234);wpoke(0xE297,254);
wpoke(0xE298,170);wpoke(0xE299,170);wpoke(0xE29A,170);wpoke(0xE29B,40);wpoke(0xE2AB,40);wpoke(0xE2AC,175);wpoke(0xE2AD,255);
wpoke(0xE2AE,255);wpoke(0xE2AF,255);wpoke(0xE2B0,174);wpoke(0xE2B1,170);wpoke(0xE2B2,170);wpoke(0xE2B3,170);wpoke(0xE2B4,170);
wpoke(0xE2B5,255);wpoke(0xE2B6,171);wpoke(0xE2B7,255);wpoke(0xE2B8,255);wpoke(0xE2B9,234);wpoke(0xE2BA,162);wpoke(0xE2BB,170);
wpoke(0xE2C4,42);wpoke(0xE2C5,128);wpoke(0xE2CB,42);wpoke(0xE2CC,191);wpoke(0xE2CD,170);wpoke(0xE2CE,170);wpoke(0xE2CF,191);
wpoke(0xE2D0,239);wpoke(0xE2D1,255);wpoke(0xE2D2,254);wpoke(0xE2D3,174);wpoke(0xE2D4,175);wpoke(0xE2D5,254);wpoke(0xE2D6,175);
wpoke(0xE2D7,250);wpoke(0xE2D8,170);wpoke(0xE2D9,170);wpoke(0xE2DA,162);wpoke(0xE2DB,170);wpoke(0xE2E5,10);wpoke(0xE2E6,168);
wpoke(0xE2EB,8);wpoke(0xE2EC,175);wpoke(0xE2ED,170);wpoke(0xE2EE,170);wpoke(0xE2EF,191);wpoke(0xE2F0,235);wpoke(0xE2F1,255);
wpoke(0xE2F2,255);wpoke(0xE2F3,255);wpoke(0xE2F4,255);wpoke(0xE2F5,250);wpoke(0xE2F6,255);wpoke(0xE2F7,170);wpoke(0xE2F8,170);
wpoke(0xE2F9,170);wpoke(0xE2FA,170);wpoke(0xE2FB,168);wpoke(0xE306,2);wpoke(0xE307,170);wpoke(0xE308,128);wpoke(0xE30B,10);
wpoke(0xE30C,170);wpoke(0xE30D,138);wpoke(0xE30E,136);wpoke(0xE30F,175);wpoke(0xE310,250);wpoke(0xE311,170);wpoke(0xE312,170);
wpoke(0xE313,170);wpoke(0xE314,170);wpoke(0xE315,170);wpoke(0xE316,250);wpoke(0xE317,130);wpoke(0xE318,170);wpoke(0xE319,128);
wpoke(0xE31A,2);wpoke(0xE31B,128);wpoke(0xE328,170);wpoke(0xE329,128);wpoke(0xE32B,10);wpoke(0xE32C,170);wpoke(0xE32D,10);
wpoke(0xE32E,168);wpoke(0xE32F,42);wpoke(0xE330,254);wpoke(0xE331,191);wpoke(0xE332,255);wpoke(0xE333,255);wpoke(0xE334,255);
wpoke(0xE335,255);wpoke(0xE336,234);wpoke(0xE337,2);wpoke(0xE338,42);wpoke(0xE33A,2);wpoke(0xE33B,128);wpoke(0xE349,32);
wpoke(0xE34B,2);wpoke(0xE34C,170);wpoke(0xE34D,42);wpoke(0xE34F,10);wpoke(0xE350,191);wpoke(0xE351,255);wpoke(0xE352,255);
wpoke(0xE353,255);wpoke(0xE354,255);wpoke(0xE355,254);wpoke(0xE356,160);wpoke(0xE357,2);wpoke(0xE358,168);wpoke(0xE35A,2);
wpoke(0xE36B,10);wpoke(0xE36C,128);wpoke(0xE36D,168);wpoke(0xE36E,32);wpoke(0xE370,171);wpoke(0xE371,255);
wpoke(0xE372,255);wpoke(0xE373,255);wpoke(0xE374,250);wpoke(0xE375,170);wpoke(0xE376,130);wpoke(0xE377,138);
wpoke(0xE378,40);wpoke(0xE37A,10);wpoke(0xE38D,170);wpoke(0xE38E,128);
wpoke(0xE390,42);wpoke(0xE391,170);wpoke(0xE392,170);wpoke(0xE393,170);wpoke(0xE394,170);wpoke(0xE395,160);
wpoke(0xE396,42);wpoke(0xE397,170);wpoke(0xE398,168);wpoke(0xE3AC,8);wpoke(0xE3AD,160);
wpoke(0xE3AE,128);wpoke(0xE3B0,2);wpoke(0xE3B1,170);wpoke(0xE3B2,170);wpoke(0xE3B3,170);
wpoke(0xE3B4,170);wpoke(0xE3B5,138);wpoke(0xE3B6,170);wpoke(0xE3B7,169);wpoke(0xE3B8,106);
wpoke(0xE3C3,2);wpoke(0xE3C4,160);wpoke(0xE3CA,10);wpoke(0xE3CB,170);wpoke(0xE3CC,170);wpoke(0xE3CD,170);wpoke(0xE3CE,128);
wpoke(0xE3D1,170);wpoke(0xE3D2,170);wpoke(0xE3D3,170);wpoke(0xE3D4,168);wpoke(0xE3D5,42);wpoke(0xE3D6,169);wpoke(0xE3D7,85);
wpoke(0xE3D8,86);wpoke(0xE3D9,128);wpoke(0xE3E3,42);wpoke(0xE3E4,128);wpoke(0xE3E9,2);
wpoke(0xE3EA,170);wpoke(0xE3EB,170);wpoke(0xE3EC,170);wpoke(0xE3ED,170);
wpoke(0xE3F2,10);wpoke(0xE3F3,170);wpoke(0xE3F4,128);wpoke(0xE3F5,170);
wpoke(0xE3F6,149);wpoke(0xE3F7,85);wpoke(0xE3F8,86);wpoke(0xE3F9,128);wpoke(0xE403,168);wpoke(0xE406,10);
wpoke(0xE409,170);wpoke(0xE40A,170);wpoke(0xE40B,149);wpoke(0xE40C,85);wpoke(0xE40D,86);
wpoke(0xE40E,128);wpoke(0xE411,170);wpoke(0xE412,170);wpoke(0xE413,170);
wpoke(0xE414,138);wpoke(0xE415,170);wpoke(0xE416,85);wpoke(0xE417,85);wpoke(0xE418,86);wpoke(0xE419,128);
wpoke(0xE422,2);wpoke(0xE423,160);wpoke(0xE426,42);wpoke(0xE428,2);wpoke(0xE429,170);wpoke(0xE42A,170);wpoke(0xE42B,85);
wpoke(0xE42C,85);wpoke(0xE42D,85);wpoke(0xE42E,160);wpoke(0xE430,170);wpoke(0xE431,170);
wpoke(0xE432,160);wpoke(0xE434,10);wpoke(0xE435,165);wpoke(0xE436,85);wpoke(0xE437,85);wpoke(0xE438,86);wpoke(0xE439,128);
wpoke(0xE442,2);wpoke(0xE443,128);wpoke(0xE446,168);wpoke(0xE448,42);wpoke(0xE449,170);
wpoke(0xE44A,85);wpoke(0xE44B,85);wpoke(0xE44C,85);wpoke(0xE44D,85);wpoke(0xE44E,160);wpoke(0xE44F,2);
wpoke(0xE450,170);wpoke(0xE451,128);wpoke(0xE454,170);wpoke(0xE455,165);
wpoke(0xE456,106);wpoke(0xE457,149);wpoke(0xE458,90);wpoke(0xE459,128);
wpoke(0xE462,10);wpoke(0xE465,2);wpoke(0xE466,128);wpoke(0xE467,2);
wpoke(0xE468,170);wpoke(0xE469,169);wpoke(0xE46A,86);wpoke(0xE46B,165);wpoke(0xE46C,85);wpoke(0xE46D,85);
wpoke(0xE46E,104);wpoke(0xE470,128);wpoke(0xE473,2);
wpoke(0xE474,170);wpoke(0xE475,86);wpoke(0xE476,190);wpoke(0xE477,149);wpoke(0xE478,90);wpoke(0xE479,128);
wpoke(0xE482,8);wpoke(0xE483,2);wpoke(0xE485,10);wpoke(0xE487,2);wpoke(0xE488,170);wpoke(0xE489,85);wpoke(0xE48A,107);
wpoke(0xE48B,250);wpoke(0xE48C,149);wpoke(0xE48D,85);wpoke(0xE48E,168);
wpoke(0xE492,128);wpoke(0xE493,2);wpoke(0xE494,169);wpoke(0xE495,91);wpoke(0xE496,175);wpoke(0xE497,85);wpoke(0xE498,90);
wpoke(0xE4A2,8);wpoke(0xE4A3,10);wpoke(0xE4A5,40);wpoke(0xE4A7,42);wpoke(0xE4A8,165);wpoke(0xE4A9,85);
wpoke(0xE4AA,191);wpoke(0xE4AB,175);wpoke(0xE4AC,149);wpoke(0xE4AD,85);wpoke(0xE4AE,160);
wpoke(0xE4B1,2);wpoke(0xE4B2,128);wpoke(0xE4B3,2);wpoke(0xE4B4,165);wpoke(0xE4B5,110);
wpoke(0xE4B6,174);wpoke(0xE4B7,85);wpoke(0xE4B8,168);wpoke(0xE4C3,40);wpoke(0xE4C5,160);wpoke(0xE4C7,170);
wpoke(0xE4C8,165);wpoke(0xE4C9,86);wpoke(0xE4CA,170);wpoke(0xE4CB,170);wpoke(0xE4CC,149);wpoke(0xE4CD,85);
wpoke(0xE4CE,160);wpoke(0xE4D1,2);wpoke(0xE4D2,128);wpoke(0xE4D3,10);
wpoke(0xE4D4,149);wpoke(0xE4D5,111);wpoke(0xE4D6,250);wpoke(0xE4D7,86);wpoke(0xE4D8,160);wpoke(0xE4E3,40);
wpoke(0xE4E5,160);wpoke(0xE4E6,2);wpoke(0xE4E7,170);wpoke(0xE4E8,149);wpoke(0xE4E9,91);wpoke(0xE4EA,254);wpoke(0xE4EB,171);
wpoke(0xE4EC,149);wpoke(0xE4ED,86);wpoke(0xE4EE,160);wpoke(0xE4F1,2);
wpoke(0xE4F3,42);wpoke(0xE4F4,85);wpoke(0xE4F5,86);wpoke(0xE4F6,165);wpoke(0xE4F7,86);wpoke(0xE4F8,160);wpoke(0xE503,32);
wpoke(0xE505,160);wpoke(0xE506,2);wpoke(0xE507,170);wpoke(0xE508,85);wpoke(0xE509,91);
wpoke(0xE50A,174);wpoke(0xE50B,254);wpoke(0xE50C,149);wpoke(0xE50D,106);wpoke(0xE50E,128);
wpoke(0xE510,40);wpoke(0xE511,2);wpoke(0xE513,170);wpoke(0xE514,85);wpoke(0xE515,85);
wpoke(0xE516,85);wpoke(0xE517,106);wpoke(0xE523,32);wpoke(0xE525,160);wpoke(0xE526,2);wpoke(0xE527,169);
wpoke(0xE528,85);wpoke(0xE529,86);wpoke(0xE52A,187);wpoke(0xE52B,250);wpoke(0xE52C,85);wpoke(0xE52D,106);
wpoke(0xE530,160);wpoke(0xE531,2);wpoke(0xE533,169);wpoke(0xE534,85);wpoke(0xE535,85);wpoke(0xE536,85);wpoke(0xE537,168);
wpoke(0xE543,40);wpoke(0xE545,160);wpoke(0xE546,2);wpoke(0xE547,169);wpoke(0xE548,85);wpoke(0xE549,85);wpoke(0xE54A,170);
wpoke(0xE54B,165);wpoke(0xE54C,85);wpoke(0xE54D,170);wpoke(0xE550,160);wpoke(0xE551,2);
wpoke(0xE553,169);wpoke(0xE554,85);wpoke(0xE555,86);wpoke(0xE556,170);wpoke(0xE557,160);
wpoke(0xE563,8);wpoke(0xE565,32);wpoke(0xE566,2);wpoke(0xE567,169);wpoke(0xE568,85);wpoke(0xE569,85);
wpoke(0xE56A,85);wpoke(0xE56B,85);wpoke(0xE56C,106);wpoke(0xE56D,160);
wpoke(0xE570,32);wpoke(0xE571,2);wpoke(0xE573,41);wpoke(0xE574,90);wpoke(0xE575,170);wpoke(0xE576,170);wpoke(0xE577,160);
wpoke(0xE583,2);wpoke(0xE585,40);wpoke(0xE586,2);wpoke(0xE587,169);
wpoke(0xE588,85);wpoke(0xE589,85);wpoke(0xE58A,85);wpoke(0xE58B,86);wpoke(0xE58C,170);
wpoke(0xE590,8);wpoke(0xE592,128);wpoke(0xE593,42);wpoke(0xE594,170);wpoke(0xE595,168);wpoke(0xE596,128);wpoke(0xE5A5,10);
wpoke(0xE5A7,170);wpoke(0xE5A8,85);wpoke(0xE5A9,85);wpoke(0xE5AA,85);wpoke(0xE5AB,90);
wpoke(0xE5AC,170);wpoke(0xE5AD,42);wpoke(0xE5AE,170);wpoke(0xE5AF,168);wpoke(0xE5B1,2);
wpoke(0xE5B2,128);wpoke(0xE5B3,10);wpoke(0xE5B4,170);wpoke(0xE5B5,160);wpoke(0xE5C7,42);wpoke(0xE5C8,106);wpoke(0xE5C9,85);
wpoke(0xE5CA,86);wpoke(0xE5CB,170);wpoke(0xE5CC,170);wpoke(0xE5CD,170);wpoke(0xE5CE,170);wpoke(0xE5CF,170);
wpoke(0xE5E7,10);wpoke(0xE5E8,170);wpoke(0xE5E9,170);wpoke(0xE5EA,170);wpoke(0xE5EB,170);wpoke(0xE5EC,170);wpoke(0xE5ED,160);
wpoke(0xE5EE,2);wpoke(0xE5EF,170);wpoke(0xE608,170);wpoke(0xE609,170);wpoke(0xE60A,170);wpoke(0xE60B,170);
wpoke(0xE60C,128);wpoke(0xE60E,42);wpoke(0xE60F,168);wpoke(0xE629,10);
wpoke(0xE62A,170);wpoke(0xE62B,128);wpoke(0xE62D,2);wpoke(0xE62E,170);wpoke(0xE62F,128);
wpoke(0xE63A,170);wpoke(0xE63B,170);wpoke(0xE63C,170);wpoke(0xE63D,170);
wpoke(0xE648,2);wpoke(0xE649,170);wpoke(0xE64A,160);wpoke(0xE64D,10);wpoke(0xE64E,168);
wpoke(0xE657,42);wpoke(0xE658,170);wpoke(0xE659,170);
wpoke(0xE65A,170);wpoke(0xE65B,170);wpoke(0xE65C,170);wpoke(0xE65D,170);wpoke(0xE65E,170);wpoke(0xE65F,160);
wpoke(0xE668,170);wpoke(0xE669,168);wpoke(0xE66D,170);wpoke(0xE66E,128);
wpoke(0xE675,42);wpoke(0xE676,170);wpoke(0xE677,170);wpoke(0xE678,170);wpoke(0xE679,170);wpoke(0xE67A,128);wpoke(0xE67D,42);
wpoke(0xE67E,170);wpoke(0xE67F,160);wpoke(0xE687,42);wpoke(0xE688,170);wpoke(0xE68C,2);wpoke(0xE68D,168);
wpoke(0xE693,42);wpoke(0xE694,170);wpoke(0xE695,170);wpoke(0xE696,160);wpoke(0xE69F,160);wpoke(0xE6A6,2);wpoke(0xE6A7,170);
wpoke(0xE6A8,128);wpoke(0xE6AC,42);wpoke(0xE6AD,160);wpoke(0xE6B1,42);wpoke(0xE6B2,170);wpoke(0xE6B3,170);wpoke(0xE6B4,160);
wpoke(0xE6C6,170);wpoke(0xE6C7,160);wpoke(0xE6CC,170);wpoke(0xE6CF,2);wpoke(0xE6D0,170);wpoke(0xE6D1,170);wpoke(0xE6D2,168);
wpoke(0xE6E5,10);wpoke(0xE6E6,170);wpoke(0xE6EC,168);wpoke(0xE6EE,42);wpoke(0xE6EF,170);wpoke(0xE6F0,170);wpoke(0xE6F1,128);
wpoke(0xE705,170);wpoke(0xE706,128);wpoke(0xE70C,170);wpoke(0xE70D,170);wpoke(0xE70E,170);wpoke(0xE70F,160);
wpoke(0xE724,10);wpoke(0xE725,168);wpoke(0xE72C,170);wpoke(0xE72D,170);wpoke(0xE72E,128);wpoke(0xE744,10);wpoke(0xE745,128);



	m=1;
	while(m==1){

/*
//	going frmo one piccy to the other, nibble by nibble within byte.	
//
	memcpy (0x7000, 0xe000, 2048);
	for (y=0;y<64;y++){
		for (x=0;x<32;x++){
			z = bpeek(0xf000+x+(y*32));
			
			n= z && 48;
			o = bpeek(0xf000+x+(y*32));
			wpoke (0x7000+x+(y*32), o | n); 
		}
	}
for (i=0;i<10000;i++);
	memcpy (0x7000, 0xe000, 2048);
	for (y=0;y<64;y++){
		for (x=0;x<32;x++){
			z = bpeek(0xe000+x+(y*32));
			n= z && 51;
			o = bpeek(0xf000+x+(y*32));
			wpoke (0x7000+x+(y*32), o | n); 
		}
	}
for (i=0;i<10000;i++);
	memcpy (0x7000, 0xe000, 2048);
	for (y=0;y<64;y++){
		for (x=0;x<32;x++){
			z = bpeek(0xe000+x+(y*32));
			n= z && 243;
			o = bpeek(0xf000+x+(y*32));
			wpoke (0x7000+x+(y*32), o | n); 
		}
	}
for (i=0;i<10000;i++);
	memcpy (0x7000, 0xe000, 2048);
	for (y=0;y<64;y++){
		for (x=0;x<32;x++){
			z = bpeek(0xe000+x+(y*32));
			n= z && 255;
			o = bpeek(0xf000+x+(y*32));
			wpoke (0x7000+x+(y*32), o | n); 
		}
	}
for (i=0;i<10000;i++);

*/


// -------------------------------------------- 
// Horizontal SPLIT-IN screen effect            
// -------------------------------------------- 
	for(i=1;i<1024+32;i=i+32){ 		
	   memcpy(0x7800-i+1,0xe000+1024,i);
	   memcpy(0x7000    ,0xe000+1024-i+1,i);
	   for(j=0;j<200;j++){}
	}
	
	for(i=1;i<30000;i++){}				//short delay



// -------------------------------------------- 
// Horizontal SPLIT-OUT screen effect           
// -------------------------------------------- 
	for(i=0;i<32;i++){
		memcpy(0x7000   , 0xE000+(i*32)+32,1024-32-(i*32));
	   	memset (0x7000+(1024-32-(i*32)), 255,32);
		memcpy(0x7400+(i*32)   , 0xE400,1024-(i*32));
	   	memset (0x7400-32+(i*32), 255,32);

		for(j=0;j<200;j++){}
	}



// -------------------------------------------- 
// Full horizontal Screen scroll up 
// -------------------------------------------- 
 	memcpy(0xe800, 0x7000, 2048);
	for (n=0;n<5000;n++);
        for(y=0;y<64;y++){
	   memcpy(0x7000   , 0xe800+(y*32)+32,2048-(y*32));
		for (n=0;n<5000;n++);}



		memcpy(0x7000,0xE000,2048);
		for(i=0;i<20000;i++);
		for(i=0;i<20000;i++);


		for(i=0;i<20000;i++);



		for(y=0;y!=64;y++);{
			for (i=0;i!=y;i++){
				memcpy(0x7000+i, 0xE000+y, 32);
			}
		}

	

		for(i=0;i<20000;i++);
		for(i=0;i<20000;i++);


//        xor     bp, bp
//@L0:    mov     bx, bp
//        mov     si, bx
//        mov     dx, si
//@L2:    add     bx, 320         ; top add gives
//        mov     di, bx          ; bottom add gives
//        mov     cx, 80
//        rep     movsd
//  /      cmp     bx, 64320;4160
//        je      @NextL2
//        mov     si, dx
//  /      mov     di, bx
//        mov     cx, 80
//        rep     movsd
//        cmp     bx, 64320;4160
//        jne     @L2
//@NextL2:add     bp, 320;640;160
//        cmp     bp, 64000
//        jne     @L0
//       xor     ax, ax
//        int     16h



		memcpy(0x7000,0xF000,2048);
		for(i=0;i<20000;i++);
		for(i=0;i<20000;i++);

		for(i=0;i!=2049;i++){
			j = bpeek(0x7000+i);
			j = j + 85;
			wpoke (0x7000+i, j);
		}
		for(i=0;i<20000;i++);
		for(i=0;i<20000;i++);


	}
}



