/***************************************************************************/
/*                                                                         */
/*  3D Rotating Cube. Created for Amiga and PC by Stefan Henrikson 1993.   */
/*                                                                         */
/*  Modified for Z88 BASIC 1993, SmallC+ Z88 1998 by Dennis Groning.       */
/*                                                                         */
/***************************************************************************/

#include <stdio.h>
#include <math.h>
#include <graphics.h>

#define MAX_X   64.0
#define MAX_Y    32.0
#define NODES     8
#define SIZE     12.0

/* djm speed ups */

#define MAX_X2  32.0
#define MAX_Y2   32.0

struct window win;    /* Window structure */

main()
{
        double x[NODES], y[NODES], z[NODES];
        double vx, vy, vz;
        double xg[NODES], yg[NODES], zg[NODES];
        double mx, my, halfangle;
        double cx,cy,cz,sx,sy,sz;
        double t1,t2,t3;
        int node;

        vx=0; vy=0; vz=0;
/* Next line not needed */
/*        mx=MAX_X2; my=MAX_Y2; */

    win->graph=1;
    win->width=128;
    win->number='4';

        /* Open map with width 256 on window #4 */
/*    window(win); */


        x[0]=-SIZE; y[0]=-SIZE; z[0]=-SIZE;
        x[1]=-SIZE; y[1]= SIZE; z[1]=-SIZE;
        x[2]= SIZE; y[2]= SIZE; z[2]=-SIZE;
        x[3]= SIZE; y[3]=-SIZE; z[3]=-SIZE;
        x[4]=-SIZE; y[4]=-SIZE; z[4]= SIZE; 
        x[5]=-SIZE; y[5]= SIZE; z[5]= SIZE; 
        x[6]= SIZE; y[6]= SIZE; z[6]= SIZE; 
        x[7]= SIZE; y[7]=-SIZE; z[7]= SIZE; 

        for(node=0;node!=NODES;node++) {
                xg[node]=x[node];
                yg[node]=y[node];
                zg[node]=z[node];
        }
        while(getk()==0) {
                cx=cos(vx); cy=cos(vy); sx=sin(vx); sy=sin(vy);
                cz=cos(vz); sz=sin(vz);
                mx=(MAX_X2-SIZE*1.8)*cos(vx)+MAX_X2;
                my=(MAX_Y2-SIZE*1.8)*sin(vy)+MAX_Y2;

                        t1=yg[0]*cx-zg[0]*sx;
                        t2=yg[0]*sx+zg[0]*cx;
                        t3=xg[0]*cy;
                        x[0] = (t3 + t2*sy)*cz;
                        x[0] = x[0] - t1*sz;
                        y[0] = (t3 + t2*sy)*sz;
                        y[0] = y[0] + t1*cz;
                        z[0]=-xg[0]*sy+t2*cy;



                        t1=yg[1]*cx-zg[1]*sx;
                        t2=yg[1]*sx+zg[1]*cx;
                        t3=xg[1]*cy;
                        x[1] = (t3 + t2*sy)*cz;
                        x[1] = x[1] - t1*sz;
                        y[1] = (t3 + t2*sy)*sz;
                        y[1] = y[1] + t1*cz;
                        z[1]=-xg[1]*sy+t2*cy;


                        t1=yg[2]*cx-zg[2]*sx;
                        t2=yg[2]*sx+zg[2]*cx;
                        t3=xg[2]*cy;
                        x[2] = (t3 + t2*sy)*cz;
                        x[2] = x[2] - t1*sz;
                        y[2] = (t3 + t2*sy)*sz;
                        y[2] = y[2] + t1*cz;
                        z[2]=-xg[2]*sy+t2*cy;


                        t1=yg[3]*cx-zg[3]*sx;
                        t2=yg[3]*sx+zg[3]*cx;
                        t3=xg[3]*cy;
                        x[3] = (t3 + t2*sy)*cz;
                        x[3] = x[2] - t1*sz;
                        y[3] = (t3 + t2*sy)*sz;
                        y[3] = y[3] + t1*cz;
                        z[3]=-xg[3]*sy+t2*cy;


                        t1=yg[4]*cx-zg[4]*sx;
                        t2=yg[4]*sx+zg[4]*cx;
                        t3=xg[4]*cy;
                        x[4] = (t3 + t2*sy)*cz;
                        x[4] = x[4] - t1*sz;
                        y[4] = (t3 + t2*sy)*sz;
                        y[4] = y[4] + t1*cz;
                        z[4]=-xg[4]*sy+t2*cy;


                        t1=yg[5]*cx-zg[5]*sx;
                        t2=yg[5]*sx+zg[5]*cx;
                        t3=xg[5]*cy;
                        x[5] = (t3 + t2*sy)*cz;
                        x[5] = x[5] - t1*sz;
                        y[5] = (t3 + t2*sy)*sz;
                        y[5] = y[5] + t1*cz;
                        z[5]=-xg[5]*sy+t2*cy;


                        t1=yg[6]*cx-zg[6]*sx;
                        t2=yg[6]*sx+zg[6]*cx;
                        t3=xg[6]*cy;
                        x[6] = (t3 + t2*sy)*cz;
                        x[6] = x[6] - t1*sz;
                        y[6] = (t3 + t2*sy)*sz;
                        y[6] = y[6] + t1*cz;
                        z[6]=-xg[6]*sy+t2*cy;


                        t1=yg[7]*cx-zg[7]*sx;
                        t2=yg[7]*sx+zg[7]*cx;
                        t3=xg[7]*cy;
                        x[7] = (t3 + t2*sy)*cz;
                        x[7] = x[7] - t1*sz;
                        y[7] = (t3 + t2*sy)*sz;
                        y[7] = y[7] + t1*cz;
                        z[7]=-xg[7]*sy+t2*cy;


                        t1=yg[8]*cx-zg[8]*sx;
                        t2=yg[8]*sx+zg[8]*cx;
                        t3=xg[8]*cy;
                        x[8] = (t3 + t2*sy)*cz;
                        x[8] = x[8] - t1*sz;
                        y[8] = (t3 + t2*sy)*sz;
                        y[8] = y[8] + t1*cz;
                        z[8]=-xg[8]*sy+t2*cy;


                vx+=0.08; vy+=0.16; vz+=0.064;
                clg();
                draw(x[0]+mx,y[0]+my,x[1]+mx,y[1]+my);
                draw(x[1]+mx,y[1]+my,x[2]+mx,y[2]+my);
                draw(x[2]+mx,y[2]+my,x[3]+mx,y[3]+my);
                draw(x[3]+mx,y[3]+my,x[0]+mx,y[0]+my);
                draw(x[4]+mx,y[4]+my,x[5]+mx,y[5]+my);
                draw(x[5]+mx,y[5]+my,x[6]+mx,y[6]+my);
                draw(x[6]+mx,y[6]+my,x[7]+mx,y[7]+my);
                draw(x[7]+mx,y[7]+my,x[4]+mx,y[4]+my);
                draw(x[0]+mx,y[0]+my,x[4]+mx,y[4]+my);
                draw(x[3]+mx,y[3]+my,x[7]+mx,y[7]+my);
                draw(x[2]+mx,y[2]+my,x[6]+mx,y[6]+my);
                draw(x[1]+mx,y[1]+my,x[5]+mx,y[5]+my);
        }
/*        closegfx(win); */
}
