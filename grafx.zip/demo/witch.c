#define SCRSIZE 	2048 
#define SCREEN	     	0x7000
char *mem;
main(argc, argv)
int argc;
int *argv;

{	
	int a,b,c,d,g,i,j,n,r,x,y,z,color;
	int  ix1, iy1;
	int  ix2, iy2;
	int  ix3, iy3;
	int  ix4, iy4;
	int  ix5, iy5;
	int  ix6, iy6;
    	mode(1);
	asm("di\n");
/*	setbase(0xE000);   *.
	setbase(0x7000);  
	x=64;
	y=32;
	r=25;
	color=0;


poke(i+0x000,170);poke(i+0x001,170);poke(i+0x002,170);poke(i+0x003,170);poke(i+0x004,191);poke(i+0x005,170);
poke(i+0x006,170);poke(i+0x007,170);poke(i+0x008,170);poke(i+0x009,170);poke(i+0x00A,170);poke(i+0x00B,170);
poke(i+0x00C,170);poke(i+0x00D,170);poke(i+0x00E,191);poke(i+0x00F,234);poke(i+0x010,170);poke(i+0x011,170);
poke(i+0x012,170);poke(i+0x013,170);poke(i+0x014,170);poke(i+0x015,170);poke(i+0x016,170);poke(i+0x017,170);
poke(i+0x018,175);poke(i+0x019,250);poke(i+0x01A,170);poke(i+0x01B,170);poke(i+0x01C,170);poke(i+0x01D,170);
poke(i+0x01E,170);poke(i+0x01F,170);poke(i+0x020,170);poke(i+0x021,170);poke(i+0x022,171);poke(i+0x023,254);
poke(i+0x024,170);poke(i+0x025,170);poke(i+0x026,170);poke(i+0x027,170);

poke(i+0x028+32,170);poke(i+0x029+32,170);poke(i+0x02A+32,170);poke(i+0x02B+32,170);poke(i+0x02C+32,170);poke(i+0x02D+32,255);
poke(i+0x02E+32,234);poke(i+0x02F+32,186);poke(i+0x030+32,170);poke(i+0x031+32,170);poke(i+0x032+32,170);poke(i+0x033+32,170);
poke(i+0x034+32,170);poke(i+0x035+32,170);poke(i+0x036+32,170);poke(i+0x037+32,255);poke(i+0x038+32,251);poke(i+0x039+32,234);
poke(i+0x03A+32,170);poke(i+0x03B+32,170);poke(i+0x03C+32,170);poke(i+0x03D+32,170);poke(i+0x03E+32,170);poke(i+0x03F+32,170);
poke(i+0x040+32,170);poke(i+0x041+32,255);poke(i+0x042+32,255);poke(i+0x043+32,234);poke(i+0x044+32,170);poke(i+0x045+32,170);
poke(i+0x046+32,170);poke(i+0x047+32,170);poke(i+0x048+32,170);poke(i+0x049+32,170);poke(i+0x04A+32,170);poke(i+0x04B+32,191);
poke(i+0x04C+32,255);poke(i+0x04D+32,170);poke(i+0x04E+32,170);poke(i+0x04F+32,170);

poke(i+0x050+64,170);poke(i+0x051+64,170);poke(i+0x052+64,170);poke(i+0x053+64,170);
poke(i+0x054+64,170);poke(i+0x055+64,255);poke(i+0x056+64,255);poke(i+0x057+64,250);poke(i+0x058+64,170);poke(i+0x059+64,170);
poke(i+0x05A+64,170);poke(i+0x05B+64,170);poke(i+0x05C+64,170);poke(i+0x05D+64,170);poke(i+0x05E+64,175);poke(i+0x05F+64,255);
poke(i+0x060+64,175);poke(i+0x061+64,250);poke(i+0x062+64,170);poke(i+0x063+64,170);poke(i+0x064+64,186);poke(i+0x065+64,170);
poke(i+0x066+64,170);poke(i+0x067+64,175);poke(i+0x068+64,255);poke(i+0x069+64,254);poke(i+0x06A+64,171);poke(i+0x06B+64,234);
poke(i+0x06C+64,170);poke(i+0x06D+64,170);poke(i+0x06E+64,186);poke(i+0x06F+64,170);poke(i+0x070+64,170);poke(i+0x071+64,191);
poke(i+0x072+64,254);poke(i+0x073+64,175);poke(i+0x074+64,191);poke(i+0x075+64,234);poke(i+0x076+64,170);poke(i+0x077+64,170);


poke(i+0x078,191);poke(i+0x079,234);poke(i+0x07A,170);poke(i+0x07B,255);poke(i+0x07C,255);poke(i+0x07D,239);
poke(i+0x07E,190);poke(i+0x07F,170);poke(i+0x080,170);poke(i+0x081,170);poke(i+0x082,175);poke(i+0x083,239);
poke(i+0x084,251);poke(i+0x085,255);poke(i+0x086,255);poke(i+0x087,255);poke(i+0x088,250);poke(i+0x089,170);
poke(i+0x08A,170);poke(i+0x08B,175);poke(i+0x08C,171);poke(i+0x08D,255);poke(i+0x08E,251);poke(i+0x08F,255);
poke(i+0x090,255);poke(i+0x091,255);poke(i+0x092,250);poke(i+0x093,170);poke(i+0x094,170);poke(i+0x095,254);
poke(i+0x096,171);poke(i+0x097,255);poke(i+0x098,255);poke(i+0x099,255);poke(i+0x09A,255);poke(i+0x09B,255);
poke(i+0x09C,254);poke(i+0x09D,170);poke(i+0x09E,175);poke(i+0x09F,250);poke(i+0x0A0,171);poke(i+0x0A1,255);
poke(i+0x0A2,255);poke(i+0x0A3,254);poke(i+0x0A4,191);poke(i+0x0A5,255);poke(i+0x0A6,255);poke(i+0x0A7,255);
poke(i+0x0A8,255);poke(i+0x0A9,234);poke(i+0x0AA,170);poke(i+0x0AB,191);poke(i+0x0AC,255);poke(i+0x0AD,250);
poke(i+0x0AE,175);poke(i+0x0AF,255);poke(i+0x0B0,255);poke(i+0x0B1,255);poke(i+0x0B2,255);poke(i+0x0B3,170);
poke(i+0x0B4,170);poke(i+0x0B5,170);poke(i+0x0B6,255);poke(i+0x0B7,250);poke(i+0x0B8,191);poke(i+0x0B9,255);
poke(i+0x0BA,255);poke(i+0x0BB,255);poke(i+0x0BC,250);poke(i+0x0BD,170);poke(i+0x0BE,170);poke(i+0x0BF,170);
poke(i+0x0C0,191);poke(i+0x0C1,170);poke(i+0x0C2,255);poke(i+0x0C3,254);poke(i+0x0C4,191);poke(i+0x0C5,255);
poke(i+0x0C6,234);poke(i+0x0C7,170);poke(i+0x0C8,170);poke(i+0x0C9,170);poke(i+0x0CA,170);poke(i+0x0CB,171);
poke(i+0x0CC,255);poke(i+0x0CD,254);poke(i+0x0CE,170);poke(i+0x0CF,190);poke(i+0x0D0,170);poke(i+0x0D1,170);
poke(i+0x0D2,170);poke(i+0x0D3,170);poke(i+0x0D4,170);poke(i+0x0D5,171);poke(i+0x0D6,255);poke(i+0x0D7,250);
poke(i+0x0D8,170);poke(i+0x0D9,250);poke(i+0x0DA,170);poke(i+0x0DB,170);poke(i+0x0DC,170);poke(i+0x0DD,170);
poke(i+0x0DE,170);poke(i+0x0DF,171);poke(i+0x0E0,255);poke(i+0x0E1,255);poke(i+0x0E2,255);poke(i+0x0E3,255);
poke(i+0x0E4,170);poke(i+0x0E5,170);poke(i+0x0E6,170);poke(i+0x0E7,170);poke(i+0x0E8,170);poke(i+0x0E9,171);
poke(i+0x0EA,255);poke(i+0x0EB,255);poke(i+0x0EC,255);poke(i+0x0ED,255);poke(i+0x0EE,250);poke(i+0x0EF,170);
poke(i+0x0F0,170);poke(i+0x0F1,170);poke(i+0x0F2,170);poke(i+0x0F3,171);poke(i+0x0F4,255);poke(i+0x0F5,255);
poke(i+0x0F6,255);poke(i+0x0F7,255);poke(i+0x0F8,250);poke(i+0x0F9,170);poke(i+0x0FA,170);poke(i+0x0FB,170);
poke(i+0x0FC,170);poke(i+0x0FD,171);poke(i+0x0FE,255);poke(i+0x0FF,255);poke(i+0x100,255);poke(i+0x101,255);
poke(i+0x102,250);poke(i+0x103,170);poke(i+0x104,170);poke(i+0x105,170);poke(i+0x106,170);poke(i+0x107,171);
poke(i+0x108,255);poke(i+0x109,255);poke(i+0x10A,255);poke(i+0x10B,255);poke(i+0x10C,250);poke(i+0x10D,170);
poke(i+0x10E,170);poke(i+0x10F,170);poke(i+0x110,170);poke(i+0x111,171);poke(i+0x112,255);poke(i+0x113,254);
poke(i+0x114,191);poke(i+0x115,255);poke(i+0x116,234);poke(i+0x117,170);poke(i+0x118,170);poke(i+0x119,170);
poke(i+0x11A,170);poke(i+0x11B,171);poke(i+0x11C,255);poke(i+0x11D,254);poke(i+0x11E,255);poke(i+0x11F,255);
poke(i+0x120,234);poke(i+0x121,170);poke(i+0x122,170);poke(i+0x123,170);poke(i+0x124,170);poke(i+0x125,170);
poke(i+0x126,255);poke(i+0x127,239);poke(i+0x128,255);poke(i+0x129,255);poke(i+0x12A,170);poke(i+0x12B,170);
poke(i+0x12C,170);poke(i+0x12D,170);poke(i+0x12E,170);poke(i+0x12F,170);poke(i+0x130,254);poke(i+0x131,191);
poke(i+0x132,255);poke(i+0x133,254);poke(i+0x134,170);poke(i+0x135,170);poke(i+0x136,170);poke(i+0x137,170);
poke(i+0x138,170);poke(i+0x139,175);poke(i+0x13A,250);poke(i+0x13B,255);poke(i+0x13C,255);poke(i+0x13D,250);
poke(i+0x13E,170);poke(i+0x13F,170);poke(i+0x140,170);poke(i+0x141,170);poke(i+0x142,171);poke(i+0x143,255);
poke(i+0x144,170);poke(i+0x145,255);poke(i+0x146,255);poke(i+0x147,250);poke(i+0x148,170);poke(i+0x149,170);
poke(i+0x14A,170);poke(i+0x14B,170);poke(i+0x14C,175);poke(i+0x14D,254);poke(i+0x14E,170);poke(i+0x14F,175);
poke(i+0x150,255);poke(i+0x151,250);poke(i+0x152,170);poke(i+0x153,170);poke(i+0x154,170);poke(i+0x155,170);
poke(i+0x156,174);poke(i+0x157,250);poke(i+0x158,170);poke(i+0x159,171);poke(i+0x15A,255);poke(i+0x15B,250);
poke(i+0x15C,170);poke(i+0x15D,170);poke(i+0x15E,170);poke(i+0x15F,191);poke(i+0x160,255);poke(i+0x161,250);
poke(i+0x162,170);poke(i+0x163,170);poke(i+0x164,191);poke(i+0x165,238);poke(i+0x166,170);poke(i+0x167,170);
poke(i+0x168,171);poke(i+0x169,255);poke(i+0x16A,255);poke(i+0x16B,254);poke(i+0x16C,170);poke(i+0x16D,234);
poke(i+0x16E,255);poke(i+0x16F,234);poke(i+0x170,170);poke(i+0x171,170);poke(i+0x172,191);poke(i+0x173,250);
poke(i+0x174,190);poke(i+0x175,170);poke(i+0x176,171);poke(i+0x177,250);poke(i+0x178,255);poke(i+0x179,234);
poke(i+0x17A,170);poke(i+0x17B,170);poke(i+0x17C,255);poke(i+0x17D,254);poke(i+0x17E,186);poke(i+0x17F,170);
poke(i+0x180,175);poke(i+0x181,255);poke(i+0x182,255);poke(i+0x183,234);poke(i+0x184,170);poke(i+0x185,170);
poke(i+0x186,191);poke(i+0x187,251);poke(i+0x188,250);poke(i+0x189,250);poke(i+0x18A,175);poke(i+0x18B,255);
poke(i+0x18C,255);poke(i+0x18D,170);poke(i+0x18E,170);poke(i+0x18F,170);poke(i+0x190,255);poke(i+0x191,255);
poke(i+0x192,235);poke(i+0x193,255);poke(i+0x194,255);poke(i+0x195,255);poke(i+0x196,254);poke(i+0x197,170);
poke(i+0x198,170);poke(i+0x199,170);poke(i+0x19A,190);poke(i+0x19B,255);poke(i+0x19C,171);poke(i+0x19D,255);
poke(i+0x19E,254);poke(i+0x19F,175);poke(i+0x1A0,250);poke(i+0x1A1,170);poke(i+0x1A2,170);poke(i+0x1A3,170);
poke(i+0x1A4,235);poke(i+0x1A5,239);poke(i+0x1A6,191);poke(i+0x1A7,255);poke(i+0x1A8,254);poke(i+0x1A9,171);
poke(i+0x1AA,234);poke(i+0x1AB,170);poke(i+0x1AC,170);poke(i+0x1AD,170);poke(i+0x1AE,171);poke(i+0x1AF,171);
poke(i+0x1B0,190);poke(i+0x1B1,191);poke(i+0x1B2,254);poke(i+0x1B3,170);poke(i+0x1B4,170);poke(i+0x1B5,170);
poke(i+0x1B6,170);poke(i+0x1B7,170);poke(i+0x1B8,170);poke(i+0x1B9,175);poke(i+0x1BA,250);poke(i+0x1BB,170);
poke(i+0x1BC,234);poke(i+0x1BD,170);poke(i+0x1BE,170);poke(i+0x1BF,170);poke(i+0x1C0,170);poke(i+0x1C1,170);


	ix1 =  0; iy1 = r * 64;
	ix2 =  0; iy2 = r * 64;
	ix3 =  0; iy3 = r * 64;
	ix4 =  0; iy4 = r * 64;
	ix5 =  0; iy5 = r * 64;
	ix6 =  0; iy6 = r * 64;

						/* Pre-calc offsets of the letters */
	for(i = 0; i < 20; i++) {
	    	ix2 = ix2 + iy2 / r;
		iy2 = iy2 - ix2 / r;
		ix3 = ix3 + iy3 / r;
		iy3 = iy3 - ix3 / r;
		ix4 = ix4 + iy4 / r;
		iy4 = iy4 - ix4 / r;
		ix5 = ix5 + iy5 / r;
		iy5 = iy5 - ix5 / r;
		ix6 = ix6 + iy6 / r;
		iy6 = iy6 - ix6 / r;}
	for(i = 0; i < 20; i++) {
		ix3 = ix3 + iy3 / r;
		iy3 = iy3 - ix3 / r;
		ix4 = ix4 + iy4 / r;
		iy4 = iy4 - ix4 / r;
		ix5 = ix5 + iy5 / r;
		iy5 = iy5 - ix5 / r;
		ix6 = ix6 + iy6 / r;
		iy6 = iy6 - ix6 / r;}
	for(i = 0; i < 40; i++) {
		ix4 = ix4 + iy4 / r;
		iy4 = iy4 - ix4 / r;
		ix5 = ix5 + iy5 / r;
		iy5 = iy5 - ix5 / r;
		ix6 = ix6 + iy6 / r;
		iy6 = iy6 - ix6 / r;}
	for(i = 0; i < 20; i++) {
		ix5 = ix5 + iy5 / r;
		iy5 = iy5 - ix5 / r;
		ix6 = ix6 + iy6 / r;
		iy6 = iy6 - ix6 / r;}
	for(i = 0; i < 20; i++) {
		ix6 = ix6 + iy6 / r;
		iy6 = iy6 - ix6 / r;}

	while(z){

		    draw_string(64+ix1/90,32+iy1/128,1,"T");
		    draw_string(64+ix2/90,32+iy2/128,2,"H");
		    draw_string(64+ix3/90,32+iy3/128,3,"E");
		    draw_string(64+ix4/90,32+iy4/128,1,"E");
		    draw_string(64+ix5/90,32+iy5/128,2,"N");
		    draw_string(64+ix6/90,32+iy6/128,3,"D");
 		    memcpy(0x7000, 0xE000, 2048);		     
		    draw_string(64+ix1/90,32+iy1/128,0,"T");
		    draw_string(64+ix2/90,32+iy2/128,0,"H");
		    draw_string(64+ix3/90,32+iy3/128,0,"E");
		    draw_string(64+ix4/90,32+iy4/128,0,"E");
		    draw_string(64+ix5/90,32+iy5/128,0,"N");
		    draw_string(64+ix6/90,32+iy6/128,0,"D");
		    ix1 = ix1 + iy1 / r;
		    iy1 = iy1 - ix1 / r;
		    ix2 = ix2 + iy2 / r;
		    iy2 = iy2 - ix2 / r;
		    ix3 = ix3 + iy3 / r;
		    iy3 = iy3 - ix3 / r;
		    ix4 = ix4 + iy4 / r;
		    iy4 = iy4 - ix4 / r;
		    ix5 = ix5 + iy5 / r;
		    iy5 = iy5 - ix5 / r;
		    ix6 = ix6 + iy6 / r;
		    iy6 = iy6 - ix6 / r;
	}
}


draw_string(x,y,color,src)
int x,y,color;
char *src;
{	while (*src)	{
	   char_draw(x,y,color,*src);
	   x += 6;
           src++;	}}
