#include <sound.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <vz.h>
#include <graphics.h>
#include <strings.h>

main()
{
	int x[512];
	int i;
	int j;
	int z;
	int y;
	int b;
	int a;
	int k;
	int l;

	char key;
	printf("LIFE\n");
	delay;
    	vz_setbase(0x7000);
	
    	vz_mode(1);
	for (j=1;j<15;j++)
	{
	for (i=1;i<31;i++)
	{
		z=(j*32)+i;
		x[z]=rand(2);
		if (x[z]==1)
 		{
			vz_plot((i*4)  ,(j*4)  ,2);
			vz_plot((i*4)+1,(j*4)  ,3);
			vz_plot((i*4)+2,(j*4)  ,3);
			vz_plot((i*4)+3,(j*4)  ,2);
			vz_plot((i*4)  ,(j*4)+1,3);
			vz_plot((i*4)+1,(j*4)+1,3);
			vz_plot((i*4)+2,(j*4)+1,3);
			vz_plot((i*4)+3,(j*4)+1,3);
			vz_plot((i*4)  ,(j*4)+2,3);
			vz_plot((i*4)+1,(j*4)+2,3);
			vz_plot((i*4)+2,(j*4)+2,3);
			vz_plot((i*4)+3,(j*4)+2,3);
			vz_plot((i*4)  ,(j*4)+3,2);
			vz_plot((i*4)+1,(j*4)+3,3);
			vz_plot((i*4)+2,(j*4)+3,3);
			vz_plot((i*4)+3,(j*4)+3,2);
		};
	};
	};




	while(!vz_inch())  
	{
	for (j=1;j<15;j++)
	{
		for (i=1;i<31;i++)
		{
			a=  x[(((j-1)*32)+(i-1))] + x[(((j-1)*32)+i)] + x[(((j-1)*32)+(i+1))] + x[(( j*32)+(i-1))];
			a=a + x[((j*32)+(i+1))] + x[(((j+1)*32)+(i-1))] + x[(((j+1)*32)+i)] + x[(((j+1)*32)+(i+1))];
			
			z= (j*32)+i;
			k=i*4;
			l=j*4;

			if (x[z]==1)
			{
				if ((a!=2)&&(a!=3))
				{
					x[z]=0;
					vz_plot((k)  ,(l),0);
					vz_plot((k)+1,(l),0);
					vz_plot((k)+2,(l),0);
					vz_plot((k)+3,(l),0);
					vz_plot((k)  ,(l)+1,0);
					vz_plot((k)+1,(l)+1,0);
					vz_plot((k)+2,(l)+1,0);
					vz_plot((k)+3,(l)+1,0);
					vz_plot((k)  ,(l)+2,0);
					vz_plot((k)+1,(l)+2,0);
					vz_plot((k)+2,(l)+2,0);
					vz_plot((k)+3,(l)+2,0);
					vz_plot((k)  ,(l)+3,0);
					vz_plot((k)+1,(l)+3,0);
					vz_plot((k)+2,(l)+3,0);
					vz_plot((k)+3,(l)+3,0);
				}
			}
			else
			{	if (a==3)
				{
					x[z]=1;
					vz_plot((k)  ,(l),2);
					vz_plot((k)+1,(l),3);
					vz_plot((k)+2,(l),3);
					vz_plot((k)+3,(l),2);
					vz_plot((k)  ,(l)+1,3);
					vz_plot((k)+1,(l)+1,3);
					vz_plot((k)+2,(l)+1,3);
					vz_plot((k)+3,(l)+1,3);
					vz_plot((k)  ,(l)+2,3);
					vz_plot((k)+1,(l)+2,3);
					vz_plot((k)+2,(l)+2,3);
					vz_plot((k)+3,(l)+2,3);
					vz_plot((k)  ,(l)+3,2);
					vz_plot((k)+1,(l)+3,3);
					vz_plot((k)+2,(l)+3,3);
					vz_plot((k)+3,(l)+3,2);
				};
			};
		};

	};
	};
	vz_getch();
	vz_mode(0);
	vz_bgrd(0);


	return 0;
}
