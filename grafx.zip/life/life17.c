/* 
Life. - 32x16 cells.  (0-31)x(0-15)

If cell X is on,  has 2 OR 3 neighbours on, cell X stays on, else cell X turns off. 
if cell X is off, has 3 neighbours on, cell X turns on, else cell X turns off.

scr is video screen buffer that is drawn to. Then is copied to video buffer.
x is an integer array which determines if a cell is on or off.
  [1] = cell on.
  [0] = cell off.

The x array is written to or laid out in the following way: ((X,Y) positions are shown)
(0,0)(1,0)(2,0)(3,0)...(30,0)(31,0)(0,1)(1,1)(2,1)(3,1)...(30,1)(31,1)(0,2)(1,2)(2,2)(3,2)...(30,2)(31,2)(0,3)(1,3) etc
*/


#define SCRSIZE     2048 
char scr[128*64];
char *mem;

main(argc, argv)
int argc;
int *argv;
{	char key;
	int x[512];
	int i;
	int j;
	int z;
	int y;
	int b;
	int a;
	int k;
	int l;
	int m,n,o,p;

	int q;
	int r;

    	setbase(scr);
    	mode(1);
	/* Sets up inital screen with random positions of cells. */
	/* Also displays them to the screen buffer. */
	/* There is no need to speed this section up. */
	for (j=1;j<15;j++){
	   for (i=1;i<31;i++){
		z=(j*32)+i;
		x[z]=rand(2);
		if (x[z]==1){
			line((i*4),(j*4)  ,(i*4)+3,(j*4)  ,2);
			line((i*4),(j*4)+1,(i*4)+3,(j*4)+1,2);
			line((i*4),(j*4)+2,(i*4)+3,(j*4)+2,2);
			line((i*4),(j*4)+3,(i*4)+3,(j*4)+3,2);}
                else{
                   x[z]=0;}
	   }
	}
        memcpy(0x7000,scr,SCRSIZE);		/* Copy screen Buffer to Video */


	y=0;
	while(y==0){
	   for (j=1;j<15;j++){			/* Y axis. From 2nd top line to 2nd bottom. */

	      for (i=1;i<31;i++){		/* X axis. From 2nd left to 2nd right. */

						/* tried re-adjusting m to be j*32+i and all others, but */
						/* keeps on crashing. Gave up. Slows it down by doing this j-1*32 */
						/* a=x[(m-1)]+...  finds neighbours from x array. */


		q = (((j-1)*32)+i);		/* appears faster like this */

	        a= x[q-1] + x[q] + x[q+1] + x[q+31] + x[q+33] + x[q+63] + x[q+64] + x[q+65];


						/* If cell X (is on or off) and has 3 neighbours on, cell X is on */
						/* OR: If cell X is on, has 2 neighbours on, cell X is on */
						/* Else, cell X is off. */

		 if ((a==3) || ((x[q+32]==1) && (a==2))){
                    x[q+32]=1;			/* Set cell to be on in the on/off array */
		    memset(scr+(j*4*32)+i    , 170,1);
		    memset(scr+((j*4+1)*32)+i, 150,1);
		    memset(scr+((j*4+2)*32)+i, 150,1);
		    memset(scr+((j*4+3)*32)+i, 170,1);}
                 else {
		    x[q+32]=0;			/* Set cell to be off in the on/off array */
		    memset(scr+(j*4*32)+i    , 0,1);
		    memset(scr+((j*4+1)*32)+i, 0,1);
		    memset(scr+((j*4+2)*32)+i, 0,1);
		    memset(scr+((j*4+3)*32)+i, 0,1);}
              }
	   }
           memcpy(0x7000,scr,SCRSIZE);		/* Copy screen Buffer to video */
           memset(scr,0,2048);			/* Clear screen Buffer */
	}
}
