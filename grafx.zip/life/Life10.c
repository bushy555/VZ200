
#define SCRSIZE     2048 
char scr[128*64];
char *mem;

main(argc, argv)
int argc;
int *argv;
{
	int x[512];
	int i;
	int j;
	int z;
	int y;
	int b;
	int a;
	int k;
	int l;
int m,n,o,p;

	char key;

    	setbase(scr);
	
    	mode(1);
	for (j=1;j<15;j++)
	{
	for (i=1;i<31;i++)
	{
		z=(j*32)+i;
		x[z]=rand(2);
		if (x[z]==1)
 		{
			line((i*4),(j*4)  ,(i*4)+3,(j*4)  ,2);
			line((i*4),(j*4)+1,(i*4)+3,(j*4)+1,2);
			line((i*4),(j*4)+2,(i*4)+3,(j*4)+2,2);
			line((i*4),(j*4)+3,(i*4)+3,(j*4)+3,2);
		}
                else
                   {
                      x[z]=0;
                   }
	}
	}
        memcpy(0x7000,scr,SCRSIZE);




	while(!inch()) {
	   for (j=1;j<15;j++){
	      for (i=1;i<31;i++){
                 m= ((j-1)*32)+i;
                 n= m+32;
                 o= m+64;
	         a=    x[(m-1)] + x[m] + x[(m+1)] + x[(n-1)] + x[(n+1)] + x[(o-1)] + x[o] + x[(o+1)];
			
		 k=i*4;
		 l=j*4;
		 if ((a==3) || ((x[n]==1) && (a==2))){
                    x[n]=1;
	            line(k,l  ,k+3,l  ,2);
		    line(k,l+1,k+3,l+1,2);
		    line(k,l+2,k+3,l+2,2);
		    line(k,l+3,k+3,l+3,2);}
                 else {
		    x[n]=0;
		    line(k,l  ,k+3,l  ,0);
		    line(k,l+1,k+3,l+1,0);
		    line(k,l+2,k+3,l+2,0);
		    line(k,l+3,k+3,l+3,0);}
              }
	   }

           memcpy(0x7000,scr,SCRSIZE);
           memset(scr,0,2048);
	};
	getch();
	mode(0);
	bgrd(0);
	printf("A = %d \n",a);


	return 0;
}
