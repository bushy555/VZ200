
#include <sound.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <graphics.h>
#include <strings.h>
#include <conio.h>
#include <time.h>
#include <games.h>
#include <lib3d.h>
#include <vz.h>
#include <math.h>
#include <gray.h>


#define screen0 0x7000
#define screen1 0xe000
#define screen2 0x8000

   int 	  a,b,c,i,j,l,m,n,o,q,r,x,y,z;
double w; 
double u; 
double v; 
int p;
int main(){

    	vz_mode(1);
    	asm("di\n");
   vz_setbase(0xe000);
	z=1;

memset (0x7000,0,2048);
memset (0xe000,0,2048);
memset (0xf000,0,2048);

bpoke (28772, 0xFF);
bpoke (28773, 0xFF);
bpoke (28774, 0xFF);
bpoke (28775, 0xFF);
bpoke (28776, 0xAA);
bpoke (28777, 0xAA);
bpoke (28778, 0x55);
bpoke (28779, 0x5E);
bpoke (28780, 0x5F);

bpoke (0xe100, 0xFF);
bpoke (0xe101, 0xAA);
bpoke (0xe102, 0xAA);
bpoke (0xe103, 0x55);
bpoke (0xe104, 0x5E);
bpoke (0xe105, 0x5E);
bpoke (0xe106, 0x5F);
bpoke (0xe107, 0xAA);
bpoke (0xe108, 0x5F);
bpoke (0xe109, 0xFF);

bpoke (0xf100, 0xFF);
bpoke (0xf101, 0xAA);
bpoke (0xf102, 0xAB);
bpoke (0xf103, 0xAC);
bpoke (0xf104, 0x5F);
bpoke (0xf105, 0x5E);
bpoke (0xf106, 0x6E);
bpoke (0xf107, 0x7E);
bpoke (0xf108, 0x8E);
bpoke (0xf109, 0xFF);

 for(i=0;i<=32000;i++){;}


   vz_setbase(0x7000);
	   p=1;
	while(z!=0){
		p++;
	   for(y=0;y<=4;y++){
	      for(x=0;x<=4;x++){
                 u = x* cos (p)+y*( -sin (p));
                 v = x* sin (p)+y* cos (p);
// 	         c = MEM[(0xe100+(u*32)+v)];
   c= bpeek ((0xe100+(u*32)+v))
		 bpoke(  (0xf100+(y*32)+x ), c  );

		 memcpy(0x7000, 0xf000, 2048);
		 memcpy(0xe000, 0xf000, 2048);
		bpoke (28672+30-p+(p*32),1);
		}
	   }
	}	




}

//            vz_plot ( (char) (20.0 * (x+3.0)), (char) z, (4.0 +(cos (x*x + y*y) * 2.0)));

