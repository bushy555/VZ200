VZDos 1.22 (custom by Yuanb)
----------
new featuers:

    Dispaly free memory in bytes after bootstrap
    BLOAD : Display START and END addr. They can be used in BSAVE.
    BSAVE 'filename', SSSS, EEEE - Where SSSS is the starting address
    of the file in Hexadicimal numbers, EEEE is the ending address of
    the file in Hexadicimal number
    Added 'RESET' command to allow soft reboot.

This custom VZ DOS is not compatible with programs making direct address calls


VZDos 1.21
----------
There is a bug in the original IDAM function in VZDos 1.2. This bug makes DOS very hard to sync. 
This patched version runs noticible faster on real machine.


VZDos 1.2  (original)
---------
This is the original VZdos 1.2, fully commented, retarget-able