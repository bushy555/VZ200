; ===========================================================================
; vzdos.asm (vzdos 1.2 disassembly) last updated : Jan-03-2021
;
; VZDOS Custom rom V1.22
; NOTE: 
; 1. This version may not be fully compatible with some Laser310/VZ200/300
; utilities. (i.e. EDASM disk version, Some Basic programs directly make DOS 
; function calls).
; 2. Search 'CUSTOM_ROM' for code changes.
;
; Version history:
; 1.22 : new featuers:
;        a. Dispaly free memory in bytes after bootstrap
;        b. BLOAD : Display START and END addr. They can be used in BSAVE.
;           BSAVE 'filename', SSSS, EEEE - Where SSSS is the starting address 
;           of the file in Hexadicimal numbers, EEEE is the ending address of 
;           the file in Hexadicimal number
;        c. Added 'RESET' command to allow soft reboot.
; 1.21 : zzemu's fast sync patch in IDAM function, this makes read sync a lot
;        faster on real DD-20 floppy drive.
; 1.2  : Original
;
; Segment type:	Pure code
		.org 4000h
DOSROM:		.dw 55AAh		; ROM Cartrige signature
		.dw 18E7h
; ---------------------------------------------------------------------------
		di
		jp	dosrom_init
; ---------------------------------------------------------------------------
		jp	POWON		; Disk power on
; ---------------------------------------------------------------------------
		jp	PWOFF		; Disk power off
; ---------------------------------------------------------------------------
		jp	ERROR		; Error	handling routine
; ---------------------------------------------------------------------------
		jp	RDMAP		; Read the track map of	the disk
; ---------------------------------------------------------------------------
		jp	CLEAR		; Clear	a sector of the	disk
; ---------------------------------------------------------------------------
		jp	SVMAP		; Save the track map of	the disk
; ---------------------------------------------------------------------------
		jp	dos_cmd_init	; Initialize the disk
; ---------------------------------------------------------------------------
		jp	CSI		; Command string interpreter
; ---------------------------------------------------------------------------
		jp	HEX		; Convert ASCII	to HEX
; ---------------------------------------------------------------------------
		jp	IDAM		; Read Identication Address Mark
; ---------------------------------------------------------------------------
		jp	CREATE		; Create an entry in directory
; ---------------------------------------------------------------------------
		jp	MAP		; Search for emptry sector
; ---------------------------------------------------------------------------
		jp	SEARCH		; Search for file in directory
; ---------------------------------------------------------------------------
		jp	FIND		; Search empty space in	directory
; ---------------------------------------------------------------------------
		jp	WRITE		; Write	a sector to disk
; ---------------------------------------------------------------------------
		jp	READ		; Read a sector	from disk
; ---------------------------------------------------------------------------
		jp	DLY		; Delay	ms in Reg C
; ---------------------------------------------------------------------------
		jp	STPIN		; Step in
; ---------------------------------------------------------------------------
		jp	STPOUT		; Step out
; ---------------------------------------------------------------------------
		jp	DKLOAD		; Load a file from disk
; ---------------------------------------------------------------------------
		jp	SAVEOB		; Save a file to disk
; ---------------------------------------------------------------------------

dosrom_init:				; CODE XREF: DOSROM:4005j
		ld	a, 61h ; 'a'
		out	(10h), a
		ld	hl, (78B1h)
		push	hl
		ld	de, 0FECAh
		add	hl, de		; Calculate IY,	base address of	DOS variables
					; For 64K or more RAM system :
					;
					; (End of RAM) + (- 0xFECA)
					; = 0xFFFF + (-	(65536-65226))
					; = 0xFFFF + (-	310)
					; = 0xFFFF - 310 (Hex :0x0136)
					; = 0xFEC9 (IY)
					;
					; For 18K RAM system:
					; = 0xB7FF - 0x0136
					; = B6C9 (IY), 46793 in	decimal
		push	hl
		pop	iy
		pop	hl		; restore end of ram
		ld	de, 8000h	; Minimum RAM required = 8000h - 7800h = 2k
		or	a
		sbc	hl, de
		jp	nc, init_dos_dcb ; Initialize DOS DCB
		ld	hl, aInsufficientM ; ?INSUFFICIENT MEMORY FOR DOS
		ei
		call	28A7h
		jp	1A19h		; Return to Basic
; ---------------------------------------------------------------------------

init_dos_dcb:				; CODE XREF: DOSROM:405Dj
		add	hl, de		; Initialize DOS DCB
		ld	de, 137h
		sbc	hl, de
		ld	(78B1h), hl
		ld	(78D6h), hl
		ld	de, 32h	; '2'
		or	a
		sbc	hl, de
		ld	(78A0h), hl
		dec	hl
		dec	hl
		ld	(78E8h), hl
		inc	hl
		inc	hl
		ld	sp, hl
		ld	(iy+14h), 0	; IY+20	: Current Track	Number
		ld	(iy+12h), 0	; IY+18	: User specified Track Number
		ld	(iy+11h), 0	; IY+17	: User specified Sector	Number
		ld	(iy+13h), 0Ah	; IY+19	: Retry	Count
		ld	(iy+16h), 0	; IY+22	: Next Track Number
		ld	(iy+15h), 0	; IY+21	: Next Sector Number
		ld	(iy+17h), 0	; IY+23	: FCB1,	File Control Block 1
					;	  Open flag, Status, FNAME, TRK#, SCTR#, Entry in SCTR
		ld	(iy+24h), 0	; IY+36	: FCB2,	File Control Block 2
					;	  Open flag, Status, FNAME, TRK#, SCTR#, Entry in SCTR
		ld	(iy+39h), 0	; IY+57	: Error	code mask?
		ld	(iy+0Bh), 10h	; IY+11	: Selected Drive # pattern
		ld	(iy+33h), 61h ;	'a' ; IY+51 : Copy of Latch
		ld	(iy+38h), 11h	; IY+56	: Stepper Phase
		push	iy
		pop	hl
		ld	de, 4Dh	; 'M'
		add	hl, de
		ld	(iy+31h), l	; IY+49	: Data buffer address
		ld	(iy+32h), h
		ld	de, 0FFF6h	; Copy hardcoded GAP2 block ->FCB2?
		add	hl, de
		ex	de, hl
		ld	hl, GAP2_BLOCK	; GAP2
		ld	bc, 0Ah
		ldir
		push	iy
		pop	hl
		ld	de, 0E7h ; '�'
		add	hl, de
		ld	(iy+34h), l
		ld	(iy+35h), h
		call	POWON
		ld	b, 28h ; '('    ; Seek Track #0
		call	STPOUT
		call	PWOFF
		ld	hl, dos_rst10
		ld	(7804h), hl	; Replace RST10h handler
		ld	hl, aDosBasicV1_2 ; DOS	Basic V1.2
		ei
		call	28A7h

; CUSTOM_ROM: Display available RAM
		ld hl, (78B1h)	; End of available RAM
		ld de, (78A4h)	; Begining of Basic
		sbc hl,de
		call 0FAFh		; Display available bytes
		ld hl, aKBytesFree+1	; String: ' BYTES FREE\r'
		call 28A7h
; CUSTOM_ROM: END
        
		ld	hl, 6000h	; Check	if there is 6000h ROM cartriage
		ld	a, 0AAh	; '�'
		cp	(hl)
		inc	hl
		jr	nz, loc_410F	; Return to Basic
		ld	a, 55h ; 'U'
		cp	(hl)
		inc	hl
		jr	nz, loc_410F	; Return to Basic
		ld	a, 0E7h	; '�'
		cp	(hl)
		inc	hl
		jr	nz, loc_410F	; Return to Basic
		ld	a, 18h
		cp	(hl)
		inc	hl

loc_410F:				; CODE XREF: DOSROM:40FDj DOSROM:4103j ...
		jp	nz, 1A19h	; Return to Basic
		jp	(hl)		; Continue boot	to 6000h
; ---------------------------------------------------------------------------
aDosBasicV1_2:	.db 1Bh, 1Bh		; DATA XREF: DOSROM:40EFo
; CUSTOM_ROM: Version
		.text "DOS BASIC V1.22"
		.db 0Dh, 0Dh, 0
; CUSTOM_ROM: END
aErrMsgLut:	.dw aFileAlreadyExi	; DATA XREF: ERROR+1Bt
					; "?FILE ALREADY EXISTS"
		.dw aDirectoryFull	; "?DIRECTORY FULL"
		.dw aDiskWriteProte	; "?DISK WRITE PROTECTED"
		.dw aFileNotOpen	; "?FILE NOT OPEN"
		.dw aDiskIOError	; "?DISK I/O ERROR"
		.dw aDiskFull		; "?DISK FULL"
		.dw aFileAlreadyOpe	; "?FILE ALREADY OPEN"
		.dw aDiskIOError	; "?DISK I/O ERROR"
		.dw aDiskIOError	; "?DISK I/O ERROR"
		.dw aUnsupportedDev	; "?UNSUPPORTED DEVICE"
		.dw aFileTypeMismat	; "?FILE TYPE MISMATCH"
		.dw aFileNotFound	; "?FILE NOT FOUND"
		.dw aDiskBufferFull	; "?DISK BUFFER FULL"
		.dw aIllegalRead	; "?ILLEGAL READ"
		.dw aIllegalWrite	; "?ILLEGAL WRITE"
aInsufficientM:	.text "?INSUFFICIENT MEMORY FOR DOS" ; DATA XREF: DOSROM:4060o
		.db 0Dh, 0
aFileAlreadyExi:.text "?FILE ALREADY EXISTS" ; DATA XREF: DOSROM:aErrMsgLuto
		.db 0
aDirectoryFull:	.text "?DIRECTORY FULL" ; DATA XREF: DOSROM:4128o
		.db 0
aDiskWriteProte:.text "?DISK WRITE PROTECTED" ; DATA XREF: DOSROM:412Ao
		.db 0
aFileNotOpen:	.text "?FILE NOT OPEN"  ; DATA XREF: DOSROM:412Co
		.db 0
aDiskIOError:	.text "?DISK I/O ERROR" ; DATA XREF: DOSROM:412Eo DOSROM:4134o ...
		.db 0
aDiskFull:	.text "?DISK FULL"      ; DATA XREF: DOSROM:4130o
		.db 0
aFileAlreadyOpe:.text "?FILE ALREADY OPEN" ; DATA XREF: DOSROM:4132o
		.db 0
aUnsupportedDev:.text "?UNSUPPORTED DEVICE" ; DATA XREF: DOSROM:4138o
		.db 0
aFileTypeMismat:.text "?FILE TYPE MISMATCH" ; DATA XREF: DOSROM:413Ao
		.db 0
aFileNotFound:	.text "?FILE NOT FOUND" ; DATA XREF: DOSROM:413Co
		.db 0
aDiskBufferFull:.text "?DISK BUFFER FULL" ; DATA XREF: DOSROM:413Eo
		.db 0
aIllegalRead:	.text "?ILLEGAL READ"   ; DATA XREF: DOSROM:4140o
		.db 0
aIllegalWrite:	.text "?ILLEGAL WRITE"  ; DATA XREF: DOSROM:4142o
		.db 0

; =============== S U B	R O U T	I N E =======================================

; Error	code in	A
; 0  - No error
; 1  - Syntax error
; 2  - File already exists
; 3  - Directory full
; 4  - Disk write protected
; 5  - File not	open
; 6  - Disk I/O	error
; 7  - Disk full
; 8  - File already open
; 9  - Sector not found
; 10 - Checksum	error
; 11 - Unsupported device
; 12 - File type mismatch
; 13 - File not	found
; 14 - Disk buffer full
; 15 - Illegal read
; 16 - Illegal write
; 17 - Break

ERROR:					; CODE XREF: DOSROM:400Ej
					; dos_cmd_load+5j ...
		push	af
		ld	a, (iy+39h)	; IY+57	: Error	code mask?
		or	a

loc_4246:
		call	nz, reset_basic_env
		pop	af
		or	a
		jr	z, loc_4281
		cp	1		; Error	> 1 && <=17
		jp	z, 1997h	; Error	code 0 & 1 -> Basic error handling
		cp	11h
		jp	z, loc_428A
		push	af
		call	20F9h
		pop	af
		ld	hl,  aErrMsgLut-04h ; Error message LUT	- 4 bytes to skip error	0 & 1
					; TODO : Patch 4 bytes to ErrMsgLut or reduce error code by 2
		sla	a
		add	a, l
		ld	l, a
		ld	a, 0
		adc	a, h
		ld	h, a
		ld	e, (hl)		; Load error string addr.
		inc	hl
		ld	d, (hl)
		ex	de, hl
		call	PWOFF
		call	28A7h
		ld	hl, (78A2h)
		ld	(78EAh), hl
		ld	(78ECh), hl
		inc	hl
		ld	a, l
		or	h
		dec	hl
		call	nz, 0FA7h

loc_4281:				; CODE XREF: ERROR+Aj
		ld	bc, 1A19h
		ld	hl, (78E8h)
		jp	1B9Ah
; ---------------------------------------------------------------------------

loc_428A:				; CODE XREF: ERROR+13j
		call	PWOFF
		ld	a, 1
		ei
		jp	1DA0h
; End of function ERROR


; =============== S U B	R O U T	I N E =======================================


dos_rst10:				; DATA XREF: DOSROM:40E9o
		exx
		ld	hl, 1D5Bh	; Basic	RST10 routine, process next character
		pop	de
		or	a
		sbc	hl, de
		push	de
		exx
		jp	nz, 1D78h
		push	hl
		call	1D78h
		jr	nz, dos_cli	; Next character in ASCII

loc_42A6:				; CODE XREF: dos_rst10+1Bj
		pop	de
		ret
; ---------------------------------------------------------------------------

dos_cli:				; CODE XREF: dos_rst10+11j
		or	a		; Next character in ASCII
		jp	p, search_dos_cmd ; Look for DOS command from LUT
		cp	8Eh ; '�'
		jr	nz, loc_42A6

loc_42B0:				; CODE XREF: dos_rst10+24j
		inc	hl
		ld	a, (hl)
		or	a
		jr	z, loc_42C5
		cp	20h ; ' '
		jr	z, loc_42B0
		cp	22h ; '"'
		jr	nz, loc_42C5
		pop	de
		ld	bc, loc_45DB
		dec	hl
		ex	de, hl
		jr	loc_4326	; After	DOS command, back to Basic
; ---------------------------------------------------------------------------

loc_42C5:				; CODE XREF: dos_rst10+20j
					; dos_rst10+28j
		pop	hl
		jp	1D78h
; ---------------------------------------------------------------------------

loc_42C9:				; CODE XREF: dos_rst10+6Cj
		pop	hl
		push	hl
		inc	hl
		ld	a, (hl)
		cp	42h ; 'B'       ; Undocumented DOS command shortcut
		jr	nz, loc_42DC	; Undocumented DOS command shortcut
		inc	hl
		ld	a, (hl)
		cp	8Eh ; '�'
		jr	nz, loc_42EB
		ld	b, 6		; index	6 = BRUN
		push	bc
		jr	jump_to_doscmd	; b = DOSCMD_VECTOR index
; ---------------------------------------------------------------------------

loc_42DC:				; CODE XREF: dos_rst10+3Cj
		cp	44h ; 'D'       ; Undocumented DOS command shortcut
		jr	nz, loc_42EB
		inc	hl
		ld	a, (hl)
		cp	96h ; '�'
		jr	nz, loc_42EB
		ld	b, 0Eh		; index	E = DCOPY
		push	bc
		jr	jump_to_doscmd	; b = DOSCMD_VECTOR index
; ---------------------------------------------------------------------------

loc_42EB:				; CODE XREF: dos_rst10+42j
					; dos_rst10+4Bj ...
		pop	hl
		jp	1D78h
; ---------------------------------------------------------------------------

search_dos_cmd:				; CODE XREF: dos_rst10+16j
		ld	de, DOSCMD_TBL_1 ; DOS_CMD_TBL - 1
		ld	b, 0FFh		; b = -1

loc_42F4:				; CODE XREF: dos_rst10+80j
		ld	c, (hl)
		ex	de, hl

loc_42F6:				; CODE XREF: dos_rst10+65j
					; dos_rst10+6Fj
		inc	hl
		or	(hl)
		jp	p, loc_42F6
		inc	b		; b++
		ld	a, (hl)
		and	7Fh ; ''
		jr	z, loc_42C9
		cp	c
		jr	nz, loc_42F6
		ex	de, hl
		push	hl

loc_4306:				; CODE XREF: dos_rst10+7Dj
		inc	de
		ld	a, (de)
		or	a
		jp	m, jump_to_doscmd ; b =	DOSCMD_VECTOR index
		ld	c, a
		inc	hl
		ld	a, (hl)
		cp	c
		jr	z, loc_4306
		pop	hl
		jr	loc_42F4
; ---------------------------------------------------------------------------

jump_to_doscmd:				; CODE XREF: dos_rst10+47j
					; dos_rst10+56j ...
		ld	a, b		; b = DOSCMD_VECTOR index
		pop	bc
		pop	bc
		pop	bc
		sla	a		; offset = DOSCMD_VECTOR index * 2
		ld	c, a
		ld	b, 0
		ex	de, hl
		ld	hl, DOSCMD_VECTOR ; DOS_CMD_HANDLER
		add	hl, bc
		ld	c, (hl)
		inc	hl
		ld	b, (hl)

loc_4326:				; CODE XREF: dos_rst10+30j
		ld	hl, 1D1Eh	; After	DOS command, back to Basic
		push	hl
		ex	de, hl
		inc	hl
		push	bc

DOSCMD_TBL_1:				; DATA XREF: dos_rst10:search_dos_cmdo
		ret
; End of function dos_rst10

; ---------------------------------------------------------------------------
DOSCMD_LUT:	.db 80h	+ 'L'           ; LOAD, 4C(Ascii) + 80 = CCh
aOad:		.text "OAD"
		.db 80h	+ 'S'           ; SAVE, 53(Ascii) + 80 = D3
aAve:		.text "AVE"
		.db 80h	+ 'O'           ; OPEN
aPen:		.text "PEN"
		.db 80h	+ 'C'           ; CLOSE
aLose:		.text "LOSE"
		.db 80h	+ 'B'           ; BSAVE
aSave:		.text "SAVE"
		.db 80h	+ 'B'           ; BLOAD
aLoad:		.text "LOAD"
		.db 80h	+ 'B'           ; BRUN
aRun:		.text "RUN"
		.db 80h	+ 'D'           ; DIR
aIr:		.text "IR"
		.db 80h	+ 'E'           ; ERA
aRa:		.text "RA"
		.db 80h	+ 'R'           ; REN
aEn:		.text "EN"
		.db 80h	+ 'I'           ; INIT
aNit:		.text "NIT"
		.db 80h	+ 'D'           ; DRIVE
aRive:		.text "RIVE"
		.db 80h	+ 'I'           ; IN#
aN:		.text "N#"
		.db 80h	+ 'P'           ; PR#
aR:		.text "R#"
		.db 80h	+ 'D'           ; DCOPY
aCopy:		.text "COPY"
		.db 80h	+ 'S'           ; STATUS
aTatus:		.text "TATUS"
; CUSTOM_ROM : RESET
		.db 80h + 'R'        ; RESET
aESET:     .text "ESET"
; CUSTOM_ROM: END
		.db 80h			; End of DOSCMD_TBL
DOSCMD_VECTOR:	.dw dos_cmd_load	; DATA XREF: dos_rst10+8Co
					; DOS LOAD Command
		.dw dos_cmd_save	; DOS SAVE Command
		.dw dos_cmd_open	; DOS OPEN Command
		.dw dos_cmd_close	; DOS CLOSE Command
		.dw dos_cmd_bsave	; DOS BSAVE Command
		.dw dos_cmd_bload	; DOS BLOAD Command
		.dw dos_cmd_brun	; DOS BRUN Command
		.dw dos_cmd_dir		; DOS DIR Command
		.dw dos_cmd_era		; DOS ERA Command
		.dw dos_cmd_ren		; DOS REN Command
		.dw dos_cmd_init	; dos_cmd_init
		.dw dos_cmd_drive	; dos_cmd_drive
		.dw dos_cmd_in		; dos_cmd_in(#)
		.dw dos_cmd_pr		; dos_cmd_pr(#)
		.dw dos_cmd_dcopy	; dos_cmd_dcopy
		.dw dos_cmd_status	; dos_cmd_status
; CUSTOM_ROM : RESET		
		.dw cust_cmd_reset	; cust_cmd_reset
; CUSTOM_ROM: END

; =============== S U B	R O U T	I N E =======================================

; DOS LOAD Command

dos_cmd_load:				; DATA XREF: DOSROM:DOSCMD_VECTORo
		call	CSI
		push	hl
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ld	(iy+9),	54h ; 'T'
		call	DKLOAD
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ld	hl, 1929h
		call	28A7h
		ld	hl, (78A4h)
		push	hl
		jp	1AE8h
; End of function dos_cmd_load

; ---------------------------------------------------------------------------

DKLOAD:					; CODE XREF: DOSROM:4041j
					; dos_cmd_load+Cp ...
		di
		call	POWON
		push	bc
		ld	bc, 32h	; '2'
		call	DLY		; delay	ms
		pop	bc
		call	SEARCH
		cp	2
		jp	z, loc_43CA
		or	a
		ret	nz
		ld	a, 0Dh
		ret
; ---------------------------------------------------------------------------

loc_43CA:				; CODE XREF: DOSROM:43C2j
		ld	a, (iy+9)
		cp	(iy+0Ah)
		ld	a, 0Ch
		ret	nz

loc_43D3:				; CODE XREF: dos_cmd_dcopy+4Bp
		ld	a, (de)
		inc	de
		ld	(iy+12h), a
		ld	a, (de)
		inc	de
		ld	(iy+11h), a
		ex	de, hl
		ld	e, (hl)
		inc	hl
		ld	d, (hl)
		inc	hl
		ld	(78A4h), de
		ld	(iy+0Eh), e
		ld	(iy+0Fh), d
		ld	e, (hl)
		inc	hl
		ld	d, (hl)
		ld	(78F9h), de

loc_43F3:				; CODE XREF: DOSROM:442Ej
		call	READ		; SECTOR READ ROUTINE
					;
					; retry	10 times
		or	a
		jp	nz, loc_4441
		ld	l, (iy+31h)
		ld	h, (iy+32h)
		push	hl
		ld	de, 7Eh	; '~'
		add	hl, de
		ld	a, (hl)
		inc	hl
		ld	(iy+12h), a
		ld	a, (hl)
		ld	(iy+11h), a
		pop	hl
		ld	e, (iy+0Eh)
		ld	d, (iy+0Fh)
		ld	bc, 7Eh	; '~'
		ld	a, (iy+12h)
		or	(iy+11h)
		jr	z, loc_4430
		ldir
		ld	(iy+0Eh), e
		ld	(iy+0Fh), d
		ld	a, (iy+12h)
		or	(iy+11h)
		jr	loc_43F3
; ---------------------------------------------------------------------------

loc_4430:				; CODE XREF: DOSROM:441Ej
		push	hl
		ld	hl, (78F9h)
		or	a
		sbc	hl, de
		ld	c, l
		ld	b, h
		pop	hl
		ldir
		call	PWOFF
		xor	a
		ret
; ---------------------------------------------------------------------------

loc_4441:				; CODE XREF: DOSROM:43F7j
		ld	hl, (78A4h)
		ld	(hl), 0
		inc	hl
		ld	(hl), 0
		inc	hl
		ld	(78F9h), hl
		ret

; =============== S U B	R O U T	I N E =======================================

; DOS SAVE Command

dos_cmd_save:				; DATA XREF: DOSROM:4373o
		call	CSI
		push	hl
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		call	POWON
		push	bc
		ld	bc, 2
		call	DLY		; delay	ms
		pop	bc
		in	a, (13h)
		or	a
		ld	a, 4
		jp	m, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ld	(iy+9),	54h ; 'T'
		pop	hl
; End of function dos_cmd_save


; =============== S U B	R O U T	I N E =======================================

; Save a file to disk

SAVEOB:					; CODE XREF: DOSROM:4044j
					; dos_cmd_dcopy+58p

; FUNCTION CHUNK AT 0:36E9 SIZE	00000028 BYTES
; FUNCTION CHUNK AT 489A SIZE 0000002A BYTES

		ld	de, (78F9h)
		push	de
		ld	de, (78A4h)
		push	de
		push	hl

loc_4479:				; CODE XREF: dos_cmd_bsave+5Ej
		di
		push	bc
		ld	bc, 32h	; '2'
		call	DLY		; delay	ms
		pop	bc
		ld	de, (78A4h)
		ld	(iy+0Eh), e
		ld	(iy+0Fh), d
		ld	(iy+12h), 0
		ld	(iy+11h), 0Fh
		call	READ		; SECTOR READ ROUTINE
					;
					; retry	10 times
		or	a
		jp	nz, loc_489A
		ld	e, (iy+34h)
		ld	d, (iy+35h)
		ld	l, (iy+31h)
		ld	h, (iy+32h)
		ld	bc, 50h	; 'P'
		ldir
		call	CREATE
		or	a
		jp	nz, loc_489A

loc_44B3:				; CODE XREF: SAVEOB+C9j
		ld	a, (iy+16h)
		or	(iy+15h)
		jp	z, loc_457C
		ld	d, (iy+16h)
		ld	e, (iy+15h)
		call	MAP
		cp	7
		jr	nz, loc_44E2
		call	SEARCH
		cp	2
		ld	a, 6
		jp	nz, loc_489A
		ex	de, hl
		ld	de, 0FFF6h
		add	hl, de
		ld	(hl), 1
		call	WRITE
		ld	a, 7
		jp	loc_489A
; ---------------------------------------------------------------------------

loc_44E2:				; CODE XREF: SAVEOB+59j
		or	a
		jp	nz, loc_489A
		ld	(iy+12h), d
		ld	(iy+11h), e
		ld	l, (iy+31h)
		ld	h, (iy+32h)
		push	hl
		ld	e, l
		ld	d, h
		inc	de
		ld	(hl), 0
		ld	bc, 80h	; '�'
		ldir
		ld	l, (iy+0Eh)
		ld	h, (iy+0Fh)
		push	hl
		ld	de, (78F9h)
		or	a
		sbc	hl, de
		jp	nc, loc_453A
		ld	de, 7Eh	; '~'
		add	hl, de
		jp	c, loc_4576
		ld	de, (78F9h)
		add	hl, de
		ld	(iy+0Eh), l
		ld	(iy+0Fh), h
		pop	hl
		pop	de
		ld	bc, 7Eh	; '~'
		ldir
		ld	a, (iy+16h)
		ld	(de), a
		inc	de
		ld	a, (iy+15h)
		ld	(de), a

loc_4530:				; CODE XREF: SAVEOB+106j
		call	WRITE
		or	a
		jp	nz, loc_489A
		jp	loc_44B3
; ---------------------------------------------------------------------------

loc_453A:				; CODE XREF: SAVEOB+9Dj SAVEOB+10Cj
		push	hl
		ld	l, (iy+34h)
		ld	h, (iy+35h)
		ld	a, (iy+16h)
		dec	a
		sla	a
		ld	e, a
		ld	d, 0
		ld	a, (iy+15h)
		cp	8
		ccf
		adc	hl, de
		and	7
		inc	a
		ld	b, a
		ld	c, (hl)
		rlc	c

loc_4559:				; CODE XREF: SAVEOB+EDj
		rrc	c
		djnz	loc_4559
		res	0, c
		ld	b, a
		rrc	c

loc_4562:				; CODE XREF: SAVEOB+F6j
		rlc	c
		djnz	loc_4562
		ld	(hl), c
		pop	bc
		pop	hl
		pop	de
		ldir
		ld	(iy+16h), 0
		ld	(iy+15h), 0
		jr	loc_4530
; ---------------------------------------------------------------------------

loc_4576:				; CODE XREF: SAVEOB+A4j
		ex	de, hl
		or	a
		sbc	hl, de
		jr	loc_453A
; ---------------------------------------------------------------------------

loc_457C:				; CODE XREF: SAVEOB+4Bj
		call	SEARCH
		cp	2
		jp	nz, loc_489A
		inc	de
		inc	de
		ld	hl, (78A4h)
		ex	de, hl
		ld	(hl), e
		inc	hl
		ld	(hl), d
		inc	hl
		ex	de, hl
		ld	hl, (78F9h)
		ex	de, hl
		ld	(hl), e
		inc	hl
		ld	(hl), d
		call	WRITE
		or	a
		jp	nz, loc_489A
		ld	l, (iy+31h)
		ld	h, (iy+32h)
		push	hl
		ld	e, l
		ld	d, h
		inc	de
		ld	(hl), 0
		ld	bc, 80h	; '�'
		ldir
		pop	hl
		ld	e, (iy+34h)
		ld	d, (iy+35h)
		ex	de, hl
		ld	bc, 50h	; 'P'
		ldir
		ld	(iy+12h), 0
		ld	(iy+11h), 0Fh
		call	WRITE
		push	af
		call	PWOFF
		pop	af
		pop	hl
		pop	de

loc_45CD:
		ld	(78A4h), de
		pop	de
		ld	(78F9h), de
		or	a
		jp	nz, ERROR	; Error	code in	A
; End of function SAVEOB		; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ret
; ---------------------------------------------------------------------------

loc_45DB:				; DATA XREF: dos_rst10+2Bo
		call	CSI
		push	hl
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ld	(iy+9),	54h ; 'T'
		call	DKLOAD
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ld	de, (78A4h)
		jp	36E9h

; =============== S U B	R O U T	I N E =======================================

; DOS OPEN Command

dos_cmd_open:				; DATA XREF: DOSROM:4375o
		call	2828h
		call	get_filename
		push	hl
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		pop	af
		rst	8
		inc	l
		call	2B1Ch
		or	a
		jr	z, loc_460E
		cp	2
		jp	nc, 1E4Ah

loc_460E:				; CODE XREF: dos_cmd_open+12j
		ld	(iy+0Ch), a
		push	hl
		call	sub_4778	; Used by dos command OPEN and CLOSE
		cp	5
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		push	hl
		call	sub_4FA5
		pop	hl
		ld	(hl), 1
		inc	hl
		ld	a, (iy+0Ch)
		ld	(hl), a
		inc	hl
		push	iy
		pop	de
		inc	de
		ex	de, hl
		ld	bc, 8
		ldir
		push	de
		di
		call	POWON
		push	bc
		ld	bc, 32h	; '2'
		call	DLY		; delay	ms
		pop	bc
		call	SEARCH
		cp	2
		jp	nz, loc_466B
		ld	a, (iy+0Ah)
		cp	44h ; 'D'
		ld	a, 0Ch
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		pop	hl
		ld	a, (de)
		ld	(hl), a
		ld	(iy+12h), a
		inc	de
		inc	hl
		ld	a, (de)
		ld	(hl), a
		ld	(iy+11h), a
		xor	a
		inc	hl
		ld	(hl), a
		ld	a, (iy+0Ch)
		or	a
		jr	nz, loc_46B9
		call	PWOFF
		pop	hl
		ret
; ---------------------------------------------------------------------------

loc_466B:				; CODE XREF: dos_cmd_open+4Ej
		ld	c, a
		ld	a, (iy+0Ch)
		or	a
		ld	a, c
		jp	z, loc_46A8
		in	a, (13h)
		or	a
		ld	c, 4
		jp	m, loc_46A8
		call	RDMAP
		ld	(iy+9),	44h ; 'D'
		call	CREATE
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		pop	hl
		ld	a, (iy+16h)
		ld	(iy+12h), a
		ld	(hl), a
		inc	hl
		ld	a, (iy+15h)
		ld	(iy+11h), a
		ld	(hl), a
		inc	hl
		ld	(hl), 0
		call	CLEAR		; Clear	a sector of the	disk
		call	SVMAP
		call	PWOFF
		pop	hl
		ret
; ---------------------------------------------------------------------------

loc_46A8:				; CODE XREF: dos_cmd_open+7Cj
					; dos_cmd_open+84j
		pop	hl
		ld	de, 0FFF6h
		add	hl, de
		ld	(hl), 0
		ld	a, c
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ld	a, 0Dh
		jp	ERROR		; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
; ---------------------------------------------------------------------------

loc_46B9:				; CODE XREF: dos_cmd_open+6Fj
		push	hl

loc_46BA:				; CODE XREF: dos_cmd_open+E2j
		call	READ		; SECTOR READ ROUTINE
					;
					; retry	10 times
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ld	l, (iy+31h)
		ld	h, (iy+32h)
		ld	de, 7Eh	; '~'
		add	hl, de
		ld	a, (hl)
		or	a
		jr	z, loc_46D9
		inc	hl
		ld	(iy+12h), a
		ld	a, (hl)
		ld	(iy+11h), a
		jr	loc_46BA
; ---------------------------------------------------------------------------

loc_46D9:				; CODE XREF: dos_cmd_open+D8j
		ld	b, 7Eh ; '~'
		ld	l, (iy+31h)
		ld	h, (iy+32h)

loc_46E1:				; CODE XREF: dos_cmd_open+F1j
		ld	a, (hl)
		inc	hl
		or	a
		jr	z, loc_4703
		djnz	loc_46E1
		call	RDMAP
		call	MAP
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ld	a, (iy+16h)
		ld	(iy+12h), a
		ld	a, (iy+15h)
		ld	(iy+11h), a
		call	CLEAR		; Clear	a sector of the	disk
		ld	b, 7Eh ; '~'

loc_4703:				; CODE XREF: dos_cmd_open+EFj
		ld	a, 7Eh ; '~'
		sub	b
		pop	hl
		ld	(hl), a
		dec	hl
		ld	a, (iy+11h)
		ld	(hl), a
		dec	hl
		ld	a, (iy+12h)
		ld	(hl), a
		call	PWOFF
		pop	hl
		ret
; End of function dos_cmd_open


; =============== S U B	R O U T	I N E =======================================


RDMAP:					; CODE XREF: DOSROM:4011j
					; dos_cmd_open+87p ...
		ld	(iy+12h), 0
		ld	(iy+11h), 0Fh
		call	READ		; SECTOR READ ROUTINE
					;
					; retry	10 times
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ld	e, (iy+34h)
		ld	d, (iy+35h)
		ld	l, (iy+31h)
		ld	h, (iy+32h)
		ld	bc, 50h	; 'P'
		ldir
		ret
; End of function RDMAP


; =============== S U B	R O U T	I N E =======================================

; Clear	DOS data buffer, used in CLEAR and SVMAP

clear_data_buf:				; CODE XREF: CLEARp SVMAPp
		ld	l, (iy+31h)
		ld	h, (iy+32h)	; iy+31h and iy+32h : DOS data buffer address
		ld	(hl), 0
		ld	e, l
		ld	d, h
		inc	de
		ld	bc, 80h	; '�'
		ldir
		ret
; End of function clear_data_buf


; =============== S U B	R O U T	I N E =======================================

; Clear	a sector of the	disk

CLEAR:					; CODE XREF: DOSROM:4014j
					; dos_cmd_open+A8p ...
		call	clear_data_buf	; Clear	DOS data buffer, used in CLEAR and SVMAP
		call	WRITE
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ret
; End of function CLEAR


; =============== S U B	R O U T	I N E =======================================


SVMAP:					; CODE XREF: DOSROM:4017j
					; dos_cmd_open+ABp ...
		call	clear_data_buf	; Clear	DOS data buffer, used in CLEAR and SVMAP
		ld	(iy+12h), 0
		ld	(iy+11h), 0Fh
		ld	e, (iy+31h)
		ld	d, (iy+32h)
		ld	l, (iy+34h)
		ld	h, (iy+35h)
		ld	bc, 50h	; 'P'
		ldir
		call	WRITE
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ret
; End of function SVMAP


; =============== S U B	R O U T	I N E =======================================

; Used by dos command OPEN and CLOSE

sub_4778:				; CODE XREF: dos_cmd_open+1Dp
					; dos_cmd_close+10p ...
		push	iy
		pop	hl
		ld	(iy+0),	0
		ld	de, 17h
		add	hl, de
		ld	a, (hl)
		or	a
		jr	z, loc_4790
		call	sub_47BF
		cp	8
		ret	z
		inc	(iy+0)

loc_4790:				; CODE XREF: sub_4778+Dj
		ld	de, 0Dh
		add	hl, de
		ld	a, (hl)
		or	a
		jr	nz, loc_47AC
		push	iy
		pop	hl
		ld	de, 17h
		add	hl, de
		ld	a, (iy+0)
		or	a
		jr	z, loc_47A9
		ld	de, 0Dh
		add	hl, de

loc_47A9:				; CODE XREF: sub_4778+2Bj
		ld	a, 5
		ret
; ---------------------------------------------------------------------------

loc_47AC:				; CODE XREF: sub_4778+1Ej
		call	sub_47BF
		cp	8
		ret	z
		or	a
		sbc	hl, de
		ld	a, (iy+17h)
		or	a
		ld	a, 0Eh
		ret	nz
		ld	a, 5
		ret
; End of function sub_4778


; =============== S U B	R O U T	I N E =======================================


sub_47BF:				; CODE XREF: sub_4778+Fp
					; sub_4778:loc_47ACp
		push	iy
		push	hl
		ld	b, 8
		inc	hl
		inc	hl

loc_47C6:				; CODE XREF: sub_47BF+10j
		ld	a, (iy+1)
		cp	(hl)
		inc	hl
		inc	iy
		jr	nz, loc_47D7
		djnz	loc_47C6
		ld	a, 8
		pop	de
		pop	iy
		ret
; ---------------------------------------------------------------------------

loc_47D7:				; CODE XREF: sub_47BF+Ej
		pop	hl
		pop	iy
		ld	a, 5
		ret
; End of function sub_47BF


; =============== S U B	R O U T	I N E =======================================

; DOS CLOSE Command

dos_cmd_close:				; DATA XREF: DOSROM:4377o
		call	CSI
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		push	hl
		ld	hl, (78A2h)
		inc	hl
		ld	a, h
		or	l
		jr	nz, loc_47F7
		call	sub_4778	; Used by dos command OPEN and CLOSE
		pop	hl
		cp	8
		ret	nz
		xor	a
		ld	(de), a
		ret
; ---------------------------------------------------------------------------

loc_47F7:				; CODE XREF: dos_cmd_close+Ej
		call	sub_4778	; Used by dos command OPEN and CLOSE
		pop	hl
		cp	8
		ret	nz
		ld	a, (de)
		cp	2
		ld	a, 0
		ld	(de), a
		ret	nz
		inc	de
		ld	a, (de)
		or	a
		ret	z
		push	hl
		ex	de, hl
		ld	de, 9
		add	hl, de
		ld	a, (hl)
		inc	hl
		ld	(iy+12h), a
		ld	a, (hl)
		ld	(iy+11h), a
		di
		call	POWON
		push	bc
		ld	bc, 32h	; '2'
		call	DLY		; delay	ms
		pop	bc
		in	a, (13h)
		or	a
		ld	a, 4
		jp	m, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		call	WRITE
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ei
		call	PWOFF
		pop	hl
		ret
; End of function dos_cmd_close


; =============== S U B	R O U T	I N E =======================================

; DOS BSAVE Command

dos_cmd_bsave:				; DATA XREF: DOSROM:4379o
		call	get_filename
		push	hl
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		pop	hl
		rst	8
		inc	l
		ld	de, (78F9h)
		push	de
		ld	de, (78A4h)
		push	de
		call	HEX
		ld	a, 1
		jp	c, loc_48B7
		ld	(78A4h), de
		rst	8
		inc	l
		call	HEX
		ld	a, 1
		jp	c, loc_48B7
		inc	de
		ld	(78F9h), de
		ld	a, (hl)
		or	a
		jr	z, loc_4874
		cp	3Ah ; ':'
		ld	a, 1
		jp	nz, loc_48B7

loc_4874:				; CODE XREF: dos_cmd_bsave+32j
		ld	(iy+9),	42h ; 'B'
		push	hl
		ld	hl, (78A4h)
		or	a
		sbc	hl, de
		ld	a, 1
		jp	nc, loc_489A
		call	POWON
		push	bc
		ld	bc, 2
		call	DLY		; delay	ms
		pop	bc
		in	a, (13h)
		or	a
		ld	a, 4
		jp	m, loc_489A
		jp	loc_4479
; End of function dos_cmd_bsave

; ---------------------------------------------------------------------------
; START	OF FUNCTION CHUNK FOR SAVEOB

loc_489A:				; CODE XREF: SAVEOB+2Aj SAVEOB+42j ...
		cp	11h
		jr	nz, loc_48B6
		call	SEARCH
		cp	2
		ld	a, 11h
		jr	nz, loc_48B6
		ex	de, hl
		ld	de, 0FFF6h
		add	hl, de
		ld	(hl), 1
		call	WRITE
		or	a
		jr	nz, loc_48B6
		ld	a, 11h

loc_48B6:				; CODE XREF: SAVEOB+42Ej SAVEOB+437j ...
		pop	hl

loc_48B7:				; CODE XREF: dos_cmd_bsave+1Aj
					; dos_cmd_bsave+28j ...
		pop	de
		ld	(78A4h), de
		pop	de
		ld	(78F9h), de
		jp	ERROR		; Error	code in	A
; END OF FUNCTION CHUNK	FOR SAVEOB	; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break

; =============== S U B	R O U T	I N E =======================================

; DOS BLOAD Command

dos_cmd_bload:				; DATA XREF: DOSROM:437Bo
		call	CSI
		push	hl
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ld	(iy+9),	42h ; 'B'
		pop	hl
		ld	de, (78F9h)
		push	de
		ld	de, (78A4h)
		push	de
		push	hl
		call	DKLOAD

; CUSTOM_ROM: BLOAD : Display START and END addr. 
; BSAVE 'filename', SSSS, EEEE - Where SSSS is the starting address of the file in Hexadicimal numbers, 
; EEEE is the ending address of the file in Hexadicimal number
		push af
		ld hl, aStartAddr	; String: 'START: '
		call 28A7h

		ld hl, (78A4h)	; TODO: 78A4h is overwritten with the original value of 78A4 before BLOAD, Change to the correct start addr ptr of B file
		call DispHLHex
		ld hl, aEndAddr
		call 28A7h
		ld hl, (78F9h)	; TODO: Change to the end addr ptr of B file
		dec hl			; TODO: Check why I need to decrease by 1, 7200H,776A -> 7200H,776BH
		call DispHLHex
		ld hl, aFinishPattern
		call 28A7h
		pop af
; CUSTOM_ROM: END

		pop	hl
		pop	de
		ld	(78A4h), de
		pop	de
		ld	(78F9h), de
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ret
; End of function dos_cmd_bload


; =============== S U B	R O U T	I N E =======================================

; DOS BRUN Command

dos_cmd_brun:				; DATA XREF: DOSROM:437Do
		call	CSI
		push	hl
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ld	(iy+9),	42h ; 'B'
		call	DKLOAD
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ld	hl, (78A4h)
		jp	(hl)
; End of function dos_cmd_brun


; =============== S U B	R O U T	I N E =======================================

; DOS DIR Command

dos_cmd_dir:				; DATA XREF: DOSROM:437Fo
		push	hl
		di
		call	POWON
		push	bc
		ld	bc, 32h	; '2'
		call	DLY		; delay	ms
		pop	bc
		ld	(iy+12h), 0	; User Spec, Track number
		ld	(iy+11h), 0	; User Spec, sector number
; End of function dos_cmd_dir


dir_next_sector:			; CODE XREF: DOSROM:498Dj
		di
		call	READ		; SECTOR READ ROUTINE
					;
					; retry	10 times
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ld	l, (iy+31h)
		ld	h, (iy+32h)
		ld	de, 6
		ld	c, 8

loc_492E:				; CODE XREF: DOSROM:4983j
		ld	a, (hl)
		or	a
		jr	z, loc_498F
		cp	1
		jr	nz, loc_493E
		push	bc
		ld	bc, 0Ah
		add	hl, bc
		pop	bc
		jr	loc_494C
; ---------------------------------------------------------------------------

loc_493E:				; CODE XREF: DOSROM:4934j
		ld	b, 0Ah

loc_4940:				; CODE XREF: DOSROM:4945j
		ld	a, (hl)
		call	32Ah
		inc	hl
		djnz	loc_4940
		ld	a, 0Dh
		call	32Ah

loc_494C:				; CODE XREF: DOSROM:493Cj
		di
		ld	a, (68EFh)
		bit	4, a		; Is SPACE pressed?
		jr	nz, loc_4981
		push	bc
		ld	bc, 14h
		call	DLY		; delay	ms
		pop	bc

loc_495C:				; CODE XREF: DOSROM:4961j
		ld	a, (68EFh)
		bit	4, a		; Is SPACE pressed? De-flicking
		jr	z, loc_495C
		push	bc
		ld	bc, 14h
		call	DLY		; delay	ms
		pop	bc

loc_496B:				; CODE XREF: DOSROM:4970j
		ld	a, (68EFh)
		bit	4, a
		jr	nz, loc_496B
		push	bc
		ld	bc, 14h
		call	DLY		; delay	ms
		pop	bc

loc_497A:				; CODE XREF: DOSROM:497Fj
		ld	a, (68EFh)
		bit	4, a
		jr	z, loc_497A

loc_4981:				; CODE XREF: DOSROM:4952j
		add	hl, de
		dec	c
		jr	nz, loc_492E
		inc	(iy+11h)	; user specified sector	#
		ld	a, (iy+11h)
		cp	0Fh
		jr	nz, dir_next_sector

loc_498F:				; CODE XREF: DOSROM:4930j
		call	PWOFF
		pop	hl
		ret

; =============== S U B	R O U T	I N E =======================================

; DOS ERA Command

dos_cmd_era:				; DATA XREF: DOSROM:4381o
		call	CSI
		push	hl
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		di
		call	POWON
		push	bc
		ld	bc, 32h	; '2'
		call	DLY		; delay	ms
		pop	bc
		in	a, (13h)
		or	a
		ld	a, 4
		jp	m, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		call	SEARCH
		cp	2
		jr	z, loc_49C0
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ld	a, 0Dh
		jp	ERROR		; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
; ---------------------------------------------------------------------------

loc_49C0:				; CODE XREF: dos_cmd_era+21j
		ld	a, (de)
		inc	de
		ld	(iy+16h), a
		ld	a, (de)
		ld	(iy+15h), a
		ex	de, hl
		ld	de, 0FFF5h
		add	hl, de
		ld	(hl), 1
		call	WRITE
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ld	(iy+12h), 0
		ld	(iy+11h), 0Fh
		call	READ		; SECTOR READ ROUTINE
					;
					; retry	10 times
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ld	e, (iy+34h)
		ld	d, (iy+35h)
		ld	l, (iy+31h)
		ld	h, (iy+32h)
		ld	bc, 50h	; 'P'
		ldir

loc_49F7:				; CODE XREF: dos_cmd_era+B9j
		ld	a, (iy+16h)
		or	a
		jp	z, loc_4A4F
		ld	(iy+12h), a
		ld	a, (iy+15h)
		ld	(iy+11h), a
		call	READ		; SECTOR READ ROUTINE
					;
					; retry	10 times
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ld	l, (iy+31h)
		ld	h, (iy+32h)
		ld	de, 7Eh	; '~'
		add	hl, de
		ld	a, (hl)
		ld	(iy+16h), a
		inc	hl
		ld	a, (hl)
		ld	(iy+15h), a
		ld	l, (iy+34h)
		ld	h, (iy+35h)
		ld	a, (iy+12h)
		dec	a
		sla	a
		ld	e, a
		ld	d, 0
		ld	a, (iy+11h)
		cp	8
		ccf
		adc	hl, de
		and	7
		inc	a
		ld	b, a
		ld	c, (hl)
		rlc	c

loc_4A3F:				; CODE XREF: dos_cmd_era+ADj
		rrc	c
		djnz	loc_4A3F
		res	0, c
		ld	b, a
		rrc	c

loc_4A48:				; CODE XREF: dos_cmd_era+B6j
		rlc	c
		djnz	loc_4A48
		ld	(hl), c
		jr	loc_49F7
; ---------------------------------------------------------------------------

loc_4A4F:				; CODE XREF: dos_cmd_era+67j
		ld	l, (iy+31h)
		ld	h, (iy+32h)
		push	hl
		ld	(hl), 0
		ld	e, l
		ld	d, h
		inc	de
		ld	bc, 7Fh	; ''
		ldir
		pop	de
		ld	l, (iy+34h)
		ld	h, (iy+35h)
		ld	bc, 50h	; 'P'
		ldir
		ld	(iy+12h), 0
		ld	(iy+11h), 0Fh
		call	WRITE
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		call	PWOFF
		pop	hl
		ret
; End of function dos_cmd_era


; =============== S U B	R O U T	I N E =======================================

; DOS REN Command

dos_cmd_ren:				; DATA XREF: DOSROM:4383o
		push	hl
		call	get_filename
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		rst	8
		inc	l
		call	CSI
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		pop	hl
		push	hl
		call	get_filename
		inc	hl
		push	hl
		di
		call	POWON
		push	bc
		ld	bc, 32h	; '2'
		call	DLY		; delay	ms
		pop	bc
		in	a, (13h)
		or	a
		ld	a, 4
		jp	m, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		call	SEARCH
		cp	2
		jp	z, loc_4ABD
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ld	a, 0Dh
		jp	ERROR		; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
; ---------------------------------------------------------------------------

loc_4ABD:				; CODE XREF: dos_cmd_ren+31j
		pop	hl
		call	CSI
		ex	(sp), hl
		push	hl
		call	SEARCH
		cp	0Dh
		jr	z, loc_4ACE
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break

loc_4ACE:				; CODE XREF: dos_cmd_ren+48j
		pop	hl
		call	get_filename
		inc	hl
		push	hl
		call	SEARCH
		cp	2
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		pop	bc
		push	hl
		push	de
		ld	l, c
		ld	h, b
		call	CSI
		pop	de
		pop	hl
		ld	bc, 0FFF8h
		add	hl, bc
		ex	de, hl
		add	hl, bc
		dec	hl
		dec	hl
		ld	a, (iy+0Ah)
		ld	(hl), a
		inc	hl
		ld	(hl), 3Ah ; ':'
		inc	hl
		ex	de, hl
		ld	bc, 8
		ldir
		call	WRITE
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		call	PWOFF
		pop	hl
		ret
; End of function dos_cmd_ren

; ---------------------------------------------------------------------------

dos_cmd_init:				; CODE XREF: DOSROM:401Aj
					; DATA XREF: DOSROM:4385o
		di
		call	POWON
		push	bc
		ld	bc, 3E8h
		call	DLY		; delay	ms
		pop	bc
		in	a, (13h)
		or	a
		ld	a, 4
		jp	m, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		push	hl
		push	iy
		pop	hl
		ld	de, 4Dh	; 'M'
		add	hl, de
		ld	(iy+12h), 0
		ld	(iy+11h), 0
		ld	(iy+0Eh), l
		ld	(iy+0Fh), h
		ex	de, hl
		ld	hl, GAP1_BLOCK	; GAP1
		ld	bc, 18h
		ldir
		ld	h, d
		ld	l, e
		ld	(hl), 0
		inc	de
		ld	bc, 82h	; '�'
		ldir
		ld	(iy+38h), 11h
		ld	b, 28h ; '('
		call	STPOUT
		push	bc
; ---------------------------------------------------------------------------
		.db 1
; ---------------------------------------------------------------------------
		sub	b
		ld	bc, 0BECDh
		ld	e, (hl)
		pop	bc
		ld	l, (iy+0Eh)
		ld	h, (iy+0Fh)
		ld	de, 0Bh
		add	hl, de
		ld	d, h
		ld	e, l
		inc	de
		ld	b, d
		ld	c, e
		inc	bc
		exx
; START	OF FUNCTION CHUNK FOR sub_4CBB

loc_4B67:				; CODE XREF: sub_4CBB+3Bj
		push	bc
		ld	bc, 64h	; 'd'
		call	DLY		; delay	ms
		pop	bc
		ld	a, (iy+33h)
		res	6, a
		ld	(iy+33h), a
		out	(10h), a
		push	bc
		ld	bc, 64h	; 'd'
		call	DLY		; delay	ms
		pop	bc
		ld	ix, sctr_intlce_lut ; sector interlace table
					; 16 sectors

loc_4B85:				; CODE XREF: sub_4CBB+1Cj
		ld	l, (iy+0Eh)
		ld	h, (iy+0Fh)
		ld	d, (iy+33h)
		ld	b, 9Ah ; '�'

loc_4B90:				; CODE XREF: sub_4CBB+9j
		ld	c, (hl)
		ld	a, 20h ; ' '
		xor	d
		rl	c
		jp	nc, loc_4BA4
		out	(10h), a
		xor	20h ; ' '
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_4BAF
; ---------------------------------------------------------------------------

loc_4BA4:				; CODE XREF: sub_4CBB-125j
		out	(10h), a
		xor	0
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_4BAF
; ---------------------------------------------------------------------------

loc_4BAF:				; CODE XREF: sub_4CBB-11Aj
					; sub_4CBB-10Fj
		inc	hl
		jp	loc_4BB3
; ---------------------------------------------------------------------------

loc_4BB3:				; CODE XREF: sub_4CBB-10Bj
		jp	loc_4BB6
; ---------------------------------------------------------------------------

loc_4BB6:				; CODE XREF: sub_4CBB:loc_4BB3j
		in	a, (12h)
		ld	a, 20h ; ' '
		xor	d
		rl	c
		jp	nc, loc_4BCB
		out	(10h), a
		xor	20h ; ' '
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_4BD6
; ---------------------------------------------------------------------------

loc_4BCB:				; CODE XREF: sub_4CBB-FEj
		out	(10h), a
		xor	0
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_4BD6
; ---------------------------------------------------------------------------

loc_4BD6:				; CODE XREF: sub_4CBB-F3j sub_4CBB-E8j
		inc	hl
		jp	loc_4BDA
; ---------------------------------------------------------------------------

loc_4BDA:				; CODE XREF: sub_4CBB-E4j
		jp	loc_4BDD
; ---------------------------------------------------------------------------

loc_4BDD:				; CODE XREF: sub_4CBB:loc_4BDAj
		in	a, (12h)
		ld	a, 20h ; ' '
		xor	d
		rl	c
		jp	nc, loc_4BF2
		out	(10h), a
		xor	20h ; ' '
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_4BFD
; ---------------------------------------------------------------------------

loc_4BF2:				; CODE XREF: sub_4CBB-D7j
		out	(10h), a
		xor	0
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_4BFD
; ---------------------------------------------------------------------------

loc_4BFD:				; CODE XREF: sub_4CBB-CCj sub_4CBB-C1j
		inc	hl
		jp	loc_4C01
; ---------------------------------------------------------------------------

loc_4C01:				; CODE XREF: sub_4CBB-BDj
		jp	loc_4C04
; ---------------------------------------------------------------------------

loc_4C04:				; CODE XREF: sub_4CBB:loc_4C01j
		in	a, (12h)
		ld	a, 20h ; ' '
		xor	d
		rl	c
		jp	nc, loc_4C19
		out	(10h), a
		xor	20h ; ' '
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_4C24
; ---------------------------------------------------------------------------

loc_4C19:				; CODE XREF: sub_4CBB-B0j
		out	(10h), a
		xor	0
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_4C24
; ---------------------------------------------------------------------------

loc_4C24:				; CODE XREF: sub_4CBB-A5j sub_4CBB-9Aj
		inc	hl
		jp	loc_4C28
; ---------------------------------------------------------------------------

loc_4C28:				; CODE XREF: sub_4CBB-96j
		jp	loc_4C2B
; ---------------------------------------------------------------------------

loc_4C2B:				; CODE XREF: sub_4CBB:loc_4C28j
		in	a, (12h)
		ld	a, 20h ; ' '
		xor	d
		rl	c
		jp	nc, loc_4C40
		out	(10h), a
		xor	20h ; ' '
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_4C4B
; ---------------------------------------------------------------------------

loc_4C40:				; CODE XREF: sub_4CBB-89j
		out	(10h), a
		xor	0
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_4C4B
; ---------------------------------------------------------------------------

loc_4C4B:				; CODE XREF: sub_4CBB-7Ej sub_4CBB-73j
		inc	hl
		jp	loc_4C4F
; ---------------------------------------------------------------------------

loc_4C4F:				; CODE XREF: sub_4CBB-6Fj
		jp	loc_4C52
; ---------------------------------------------------------------------------

loc_4C52:				; CODE XREF: sub_4CBB:loc_4C4Fj
		in	a, (12h)
		ld	a, 20h ; ' '
		xor	d
		rl	c
		jp	nc, loc_4C67
		out	(10h), a
		xor	20h ; ' '
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_4C72
; ---------------------------------------------------------------------------

loc_4C67:				; CODE XREF: sub_4CBB-62j
		out	(10h), a
		xor	0
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_4C72
; ---------------------------------------------------------------------------

loc_4C72:				; CODE XREF: sub_4CBB-57j sub_4CBB-4Cj
		inc	hl
		jp	loc_4C76
; ---------------------------------------------------------------------------

loc_4C76:				; CODE XREF: sub_4CBB-48j
		jp	loc_4C79
; ---------------------------------------------------------------------------

loc_4C79:				; CODE XREF: sub_4CBB:loc_4C76j
		in	a, (12h)
		ld	a, 20h ; ' '
		xor	d
		rl	c
		jp	nc, loc_4C8E
		out	(10h), a
		xor	20h ; ' '
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_4C99
; ---------------------------------------------------------------------------

loc_4C8E:				; CODE XREF: sub_4CBB-3Bj
		out	(10h), a
		xor	0
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_4C99
; ---------------------------------------------------------------------------

loc_4C99:				; CODE XREF: sub_4CBB-30j sub_4CBB-25j
		inc	hl
		jp	loc_4C9D
; ---------------------------------------------------------------------------

loc_4C9D:				; CODE XREF: sub_4CBB-21j
		jp	loc_4CA0
; ---------------------------------------------------------------------------

loc_4CA0:				; CODE XREF: sub_4CBB:loc_4C9Dj
		in	a, (12h)
		ld	a, 20h ; ' '
		xor	d
		rl	c
		jp	nc, loc_4CB5
		out	(10h), a
		xor	20h ; ' '
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_4CC0
; ---------------------------------------------------------------------------

loc_4CB5:				; CODE XREF: sub_4CBB-14j
		out	(10h), a
		xor	0
		ld	d, a
		dec	hl
; END OF FUNCTION CHUNK	FOR sub_4CBB

; =============== S U B	R O U T	I N E =======================================


sub_4CBB:

; FUNCTION CHUNK AT 4B67 SIZE 00000154 BYTES

		out	(10h), a
		jp	loc_4CC0
; ---------------------------------------------------------------------------

loc_4CC0:				; CODE XREF: sub_4CBB-9j sub_4CBB+2j
		inc	hl
		inc	hl
		nop
		dec	b
		jp	nz, loc_4B90
		ld	(iy+33h), d
		exx
		ld	a, (ix+1)
		inc	ix
		ld	(de), a
		add	a, (hl)
		ld	(bc), a
		ld	a, (de)
		exx
		cp	0FFh
		jp	nz, loc_4B85
		exx
		xor	a
		ld	(de), a
		ld	a, (hl)
		inc	a
		ld	(hl), a
		ld	(bc), a
		exx
		cp	28h ; '('
		jp	z, loc_4CF9
		ld	a, (iy+33h)
		or	40h ; '@'
		ld	(iy+33h), a
		out	(10h), a
		ld	b, 1
		call	STPIN
		jp	loc_4B67
; ---------------------------------------------------------------------------

loc_4CF9:				; CODE XREF: sub_4CBB+29j
		ld	a, (iy+33h)
		or	40h ; '@'
		ld	(iy+33h), a
		out	(10h), a
		ld	b, 27h ; '''
		call	STPOUT
		ld	(iy+12h), 0
		ld	(iy+11h), 0

loc_4D10:				; CODE XREF: sub_4CBB+7Ej
		ld	ix, sctr_intlce_lut ; sector interlace table
					; 16 sectors

loc_4D14:				; CODE XREF: sub_4CBB+68j
		call	IDAM
		jr	nz, loc_4D45
		ld	a, (ix+1)
		inc	ix
		ld	(iy+11h), a
		cp	0FFh
		jr	nz, loc_4D14
		xor	a
		ld	(iy+11h), a
		ld	a, (iy+12h)
		inc	a
		ld	(iy+12h), a
		cp	28h ; '('
		jr	z, loc_4D3B
		ld	b, 1
		call	STPIN
		jr	loc_4D10
; ---------------------------------------------------------------------------

loc_4D3B:				; CODE XREF: sub_4CBB+77j
		ld	b, 27h ; '''
		call	STPOUT
		call	PWOFF
		pop	hl
		ret
; ---------------------------------------------------------------------------

loc_4D45:				; CODE XREF: sub_4CBB+5Cj
		cp	11h
		jp	z, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ld	a, 6
		jp	ERROR		; Error	code in	A
; End of function sub_4CBB		; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
; ---------------------------------------------------------------------------
GAP1_BLOCK:	.db 80h, 80h, 80h, 80h,	80h, 80h, 0 ; DATA XREF: DOSROM:4B33o
					; GAP1
		.db 0FEh ; �		; IDAM
		.db 0E7h ; �
		.db  18h
		.db 0C3h ; �
		.db    0		; Trk#
		.db    0		; Sctr#
; ---------------------------------------------------------------------------
		nop			; Checksum
; ---------------------------------------------------------------------------
GAP2_BLOCK:	.db 80h, 80h, 80h, 80h,	80h, 0,	0C3h, 18h, 0E7h, 0FEh
					; DATA XREF: DOSROM:40C9o
					; GAP2
sctr_intlce_lut:.db    0		; DATA XREF: sub_4CBB-13Ao
					; sub_4CBB:loc_4D10o
					; sector interlace table
					; 16 sectors
		.db  0Bh
		.db    6
		.db    1
		.db  0Ch
		.db    7
		.db    2
		.db  0Dh
		.db    8
		.db    3
		.db  0Eh
		.db    9
		.db    4
		.db  0Fh
		.db  0Ah
		.db    5
		.db 0FFh

; =============== S U B	R O U T	I N E =======================================


dos_cmd_drive:				; DATA XREF: DOSROM:4387o
		call	2B1Ch
		or	a		; convert drv# from ASCII to decimal
		jp	z, 1E4Ah
		cp	3
		jp	nc, 1E4Ah
; End of function dos_cmd_drive


; =============== S U B	R O U T	I N E =======================================


set_active_drv:				; CODE XREF: sub_5219+3p sub_5275+3p
		cp	1
		jr	nz, drv_2_active ; Active drive	: 2
		ld	(iy+0Bh), 10h	; Active drive : 1
		ret
; ---------------------------------------------------------------------------

drv_2_active:				; CODE XREF: set_active_drv+2j
		ld	(iy+0Bh), 80h ;	'�' ; Active drive : 2
		ret
; End of function set_active_drv


; =============== S U B	R O U T	I N E =======================================


dos_cmd_in:				; DATA XREF: DOSROM:4389o

; FUNCTION CHUNK AT 0:1F04 SIZE	00000001 BYTES
; FUNCTION CHUNK AT 0:21BD SIZE	0000000C BYTES
; FUNCTION CHUNK AT 0:21EB SIZE	00000004 BYTES
; FUNCTION CHUNK AT 0:21F4 SIZE	00000007 BYTES
; FUNCTION CHUNK AT 0:21FD SIZE	00000035 BYTES
; FUNCTION CHUNK AT 0:2296 SIZE	00000020 BYTES

		call	2828h
		call	get_filename
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		rst	8
		inc	l
		push	hl
		call	sub_4778	; Used by dos command OPEN and CLOSE
		cp	8
		ld	a, 5
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		inc	de
		ld	a, (de)
		or	a
		ld	a, 0Fh
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		dec	de
		ld	a, (de)
		cp	2
		jr	z, loc_4DE2
		call	sub_4FA5
		ld	a, 2
		ld	(de), a
		ex	de, hl
		ld	de, 0Ah
		add	hl, de
		ld	a, (hl)
		inc	hl
		ld	(iy+12h), a
		ld	a, (hl)
		ld	(iy+11h), a
		di
		call	POWON
		push	bc
		ld	bc, 32h	; '2'
		call	DLY		; delay	ms
		pop	bc
		call	READ		; SECTOR READ ROUTINE
					;
					; retry	10 times
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ei
		call	PWOFF

loc_4DE2:				; CODE XREF: dos_cmd_in+23j
		ld	b, 0C7h	; '�'
		ld	hl, (78A7h)

loc_4DE7:				; CODE XREF: dos_cmd_in+5Ej
		call	loc_4DF9
		ld	(hl), a
		inc	hl
		cp	0Dh
		jr	z, loc_4DF2
		djnz	loc_4DE7

loc_4DF2:				; CODE XREF: dos_cmd_in+5Cj
		xor	a
		ld	(78A9h), a
		jp	21BDh
; End of function dos_cmd_in

; ---------------------------------------------------------------------------

loc_4DF9:				; CODE XREF: dos_cmd_in:loc_4DE7p
		push	hl
		push	de
		push	bc
		call	sub_4778	; Used by dos command OPEN and CLOSE
		ld	hl, 0Ch
		ex	de, hl
		add	hl, de
		ld	a, (hl)
		ex	de, hl
		ld	l, (iy+31h)
		ld	h, (iy+32h)
		add	a, l
		ld	l, a
		ld	a, 0
		adc	a, h
		ld	h, a
		ld	a, (hl)
		or	a
		jr	nz, loc_4E1A
		ld	c, 0Dh
		jr	loc_4E5A
; ---------------------------------------------------------------------------

loc_4E1A:				; CODE XREF: DOSROM:4E14j
		ld	c, a
		ld	a, (de)
		inc	a
		ld	(de), a
		cp	7Eh ; '~'
		jr	nz, loc_4E5A
		xor	a
		ld	(de), a
		ld	l, (iy+31h)
		ld	h, (iy+32h)
		push	de
		ld	de, 7Eh	; '~'
		add	hl, de
		pop	de
		ld	a, (hl)
		or	a
		jr	z, loc_4E5F
		ld	(iy+12h), a
		dec	de
		dec	de
		ld	(de), a
		inc	hl
		ld	a, (hl)
		ld	(iy+11h), a
		inc	de
		ld	(de), a
		di
		call	POWON
		push	bc
		ld	bc, 32h	; '2'
		call	DLY		; delay	ms
		pop	bc
		push	bc
		call	READ		; SECTOR READ ROUTINE
					;
					; retry	10 times
		pop	bc
		or	a
; ---------------------------------------------------------------------------
		.db 0C2h ; �
		.db  41h ; A
		.db  42h ; B
		.db 0CDh ; �
		.db  52h ; R
		.db  5Fh ; _
		.db 0FBh ; �
; ---------------------------------------------------------------------------

loc_4E5A:				; CODE XREF: DOSROM:4E18j DOSROM:4E20j ...
		ld	a, c
		pop	bc
		pop	de
		pop	hl
		ret
; ---------------------------------------------------------------------------

loc_4E5F:				; CODE XREF: DOSROM:4E32j
		ld	a, 7Fh ; ''
		ld	(de), a
		jr	loc_4E5A

; =============== S U B	R O U T	I N E =======================================


dos_cmd_pr:				; DATA XREF: DOSROM:438Bo

; FUNCTION CHUNK AT 4EB3 SIZE 00000007 BYTES

		call	2828h
		call	get_filename
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		push	hl
		call	sub_4778	; Used by dos command OPEN and CLOSE
		cp	8
		ld	a, 5
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		pop	hl
		rst	8
		inc	l

loc_4E7C:				; CODE XREF: dos_cmd_pr+46j
		dec	hl
		rst	10h
		call	z, sub_4EAC

loc_4E81:				; CODE XREF: dos_cmd_pr+54j
		ret	z
		push	hl
		cp	2Ch ; ','
		jp	z, loc_4EB3
		cp	3Ah ; ':'
		jr	z, loc_4EB7
		pop	bc
		call	2337h
		push	hl
		rst	20h
		jr	z, loc_4EA6
		call	0FBDh
		call	2865h
		ld	hl, (7921h)
		call	loc_4EBA
		ld	a, 20h ; ' '
		call	loc_4ECA
		or	a

loc_4EA6:				; CODE XREF: dos_cmd_pr+2Ej
		call	z, loc_4EBA
		pop	hl
		jr	loc_4E7C
; End of function dos_cmd_pr


; =============== S U B	R O U T	I N E =======================================


sub_4EAC:				; CODE XREF: dos_cmd_pr+1Ap
		ld	a, 0Dh
		call	loc_4ECA
		xor	a
		ret
; End of function sub_4EAC

; ---------------------------------------------------------------------------
; START	OF FUNCTION CHUNK FOR dos_cmd_pr

loc_4EB3:				; CODE XREF: dos_cmd_pr+21j
		call	loc_4ECA
		pop	hl

loc_4EB7:				; CODE XREF: dos_cmd_pr+26j
		rst	10h
		jr	loc_4E81
; END OF FUNCTION CHUNK	FOR dos_cmd_pr
; ---------------------------------------------------------------------------

loc_4EBA:				; CODE XREF: dos_cmd_pr+39p
					; dos_cmd_pr:loc_4EA6p
		call	29DAh
		call	9C4h
		inc	d

loc_4EC1:				; CODE XREF: DOSROM:4EC8j
		dec	d
		ret	z
		ld	a, (bc)
; ---------------------------------------------------------------------------
		.db 0CDh
		.dw 4ECAh
; ---------------------------------------------------------------------------
		inc	bc
		jr	loc_4EC1
; ---------------------------------------------------------------------------

loc_4ECA:				; CODE XREF: dos_cmd_pr+3Ep
					; sub_4EAC+2p ...
		push	hl
		push	de
		push	bc
		push	af
		call	sub_4778	; Used by dos command OPEN and CLOSE
		ex	de, hl
		inc	hl
		ld	a, (hl)
		or	a
		ld	a, 10h
		jp	z, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		dec	hl
		ld	a, (hl)
		cp	2
		jr	z, loc_4F0C
		call	sub_4FA5
		ld	de, 0Ah
		add	hl, de
		ld	a, (hl)
		inc	hl
		ld	(iy+12h), a
		ld	a, (hl)
		inc	hl
		ld	(iy+11h), a
		di
		call	POWON
		in	a, (13h)
		or	a
		ld	a, 4
		jp	m, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		push	hl
		call	READ		; SECTOR READ ROUTINE
					;
					; retry	10 times
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		pop	hl
		ld	de, 0FFF4h
		add	hl, de
		ld	(hl), 2

loc_4F0C:				; CODE XREF: DOSROM:4EDEj
		ld	de, 0Ch
		add	hl, de
		ld	e, (hl)
		inc	(hl)
		ld	d, 0
		ld	l, (iy+31h)
		ld	h, (iy+32h)
		add	hl, de
		pop	af
		push	af
		ld	(hl), a
		ld	a, e
		inc	a
		cp	7Eh ; '~'
		jr	nz, loc_4F9C
		di
		call	POWON
		push	bc
		ld	bc, 2
		call	DLY		; delay	ms
		pop	bc
		in	a, (13h)
		or	a
		ld	a, 4
		jp	m, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ld	e, (iy+11h)
		ld	d, (iy+12h)
		push	de
		call	WRITE
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		call	RDMAP
		or	a
		jp	nz, ERROR	; TODO : ?????
		call	MAP
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		call	SVMAP
		pop	de
		ld	(iy+11h), e
		ld	(iy+12h), d
		call	READ		; SECTOR READ ROUTINE
					;
					; retry	10 times
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ld	l, (iy+31h)
		ld	h, (iy+32h)
		ld	de, 7Eh	; '~'
		add	hl, de
		ld	a, (iy+16h)
		ld	(hl), a
		inc	hl
		ld	a, (iy+15h)
		ld	(hl), a
		call	WRITE
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		call	sub_4778	; Used by dos command OPEN and CLOSE
		ex	de, hl
		ld	de, 0Ah
		add	hl, de
		ld	a, (iy+16h)
		ld	(iy+12h), a
		ld	(hl), a
		inc	hl
		ld	a, (iy+15h)
		ld	(iy+11h), a
		ld	(hl), a
		inc	hl
		xor	a
		ld	(hl), a
		call	CLEAR		; Clear	a sector of the	disk

loc_4F9C:				; CODE XREF: DOSROM:4F22j
		call	PWOFF
		ei
		pop	af
		pop	bc
		pop	de
		pop	hl
		ret

; =============== S U B	R O U T	I N E =======================================


sub_4FA5:				; CODE XREF: dos_cmd_open+26p
					; dos_cmd_in+25p ...
		push	hl
		push	de
		push	iy
		pop	hl
		ld	de, 17h
		add	hl, de
		call	sub_4FBB
		ld	de, 0Dh
		add	hl, de
		call	sub_4FBB
		pop	de
		pop	hl
		ret
; End of function sub_4FA5


; =============== S U B	R O U T	I N E =======================================


sub_4FBB:				; CODE XREF: sub_4FA5+9p sub_4FA5+10p
		ld	a, (hl)
		or	a
		ret	z
		cp	2
		ret	nz
		ld	(hl), 1
		inc	hl
		ld	a, (hl)
		or	a
		dec	hl
		ret	z
		ld	de, 0Ah
		add	hl, de
		ld	a, (hl)
		ld	(iy+12h), a
		inc	hl
		ld	a, (hl)
		ld	(iy+11h), a
		di
		call	POWON
		push	bc
		ld	bc, 32h	; '2'
		call	DLY		; delay	ms
		pop	bc
		in	a, (13h)
		or	a
		ld	a, 4
		jp	m, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		push	hl
		call	WRITE
		pop	hl
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ld	de, 0FFF5h
		add	hl, de
		call	PWOFF
		ei
		ret
; End of function sub_4FBB


; =============== S U B	R O U T	I N E =======================================


dos_cmd_dcopy:				; DATA XREF: DOSROM:438Do

; FUNCTION CHUNK AT 5162 SIZE 00000006 BYTES

		ld	de, (78A2h)
		inc	de
		ld	a, d
		or	e
		ld	e, 16h
		jp	nz, 19A2h
		ld	(iy+39h), 1
		dec	hl
		rst	10h
		jr	z, loc_505D
		call	CSI
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		push	hl
		call	dcopy_con_input	; DCOPY	: get console input
					; Source disk
					; Destination disk
		call	sub_5219
		di
		call	POWON
		push	bc
		ld	bc, 32h	; '2'
		call	DLY		; delay	ms
		pop	bc
		call	SEARCH
		cp	2
		jr	z, loc_5039
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ld	a, 0Dh
		jp	ERROR		; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
; ---------------------------------------------------------------------------

loc_5039:				; CODE XREF: dos_cmd_dcopy+33j
		ld	a, (iy+0Ah)
		ld	(iy+9),	a
		cp	44h ; 'D'
		ld	a, 0Ch
		jp	z, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		call	loc_43D3
		or	a
		jp	nz, loc_5162
		call	sub_5275
		call	POWON
		call	SAVEOB		; Save a file to disk
		or	a
		jp	nz, loc_5162
		jp	loc_5137
; ---------------------------------------------------------------------------

loc_505D:				; CODE XREF: dos_cmd_dcopy+12j
		push	hl
		ld	hl, 0FFC6h
		add	hl, sp
		ld	de, 7AE9h
		or	a
		sbc	hl, de
		srl	h
		srl	h
		srl	h
		ld	(iy+36h), h
		ld	(iy+37h), 0
		ld	(iy+12h), 0
		ld	(iy+11h), 0
		call	sub_4FA5
		call	dcopy_con_input	; DCOPY	: get console input
					; Source disk
					; Destination disk

loc_5083:				; CODE XREF: dos_cmd_dcopy+139j
		ld	de, 7AE9h
		ld	(78A4h), de
		call	sub_5219
		di
		call	POWON

loc_5091:				; CODE XREF: dos_cmd_dcopy+B8j
					; dos_cmd_dcopy+CEj
		call	READ		; SECTOR READ ROUTINE
					;
					; retry	10 times
		or	a
		jp	nz, loc_5162
		ld	l, (iy+31h)
		ld	h, (iy+32h)
		ld	de, (78A4h)
		ld	bc, 80h	; '�'
		ldir
		ld	(78A4h), de
		inc	(iy+11h)
		ld	a, (iy+11h)
		cp	10h
		jr	nz, loc_5091
		ld	(iy+11h), 0
		inc	(iy+12h)
		ld	a, (iy+12h)
		cp	28h ; '('
		jr	z, loc_50CB
		sub	(iy+37h)
		sub	(iy+36h)
		jr	nz, loc_5091

loc_50CB:				; CODE XREF: dos_cmd_dcopy+C6j
		ld	a, (iy+37h)
		ld	(iy+12h), a
		call	PWOFF
		call	sub_5275
		di
		call	POWON
		push	bc
		ld	bc, 2
		call	DLY		; delay	ms
		pop	bc
		in	a, (13h)
		or	a
		ld	a, 4
		jp	m, loc_5162
		ld	hl, 7AE9h
		ld	(78A4h), hl

loc_50F1:				; CODE XREF: dos_cmd_dcopy+115j
					; dos_cmd_dcopy+12Bj
		ld	hl, (78A4h)
		ld	e, (iy+31h)
		ld	d, (iy+32h)
		ld	bc, 80h	; '�'
		ldir
		ld	(78A4h), hl
		call	WRITE
		or	a
		jr	nz, loc_5162
		inc	(iy+11h)
		ld	a, (iy+11h)
		cp	10h
		jr	nz, loc_50F1
		ld	(iy+11h), 0
		inc	(iy+12h)
		ld	a, (iy+12h)
		cp	28h ; '('
		jr	z, loc_5137
		sub	(iy+37h)
		sub	(iy+36h)
		jr	nz, loc_50F1
		ld	a, (iy+36h)
		add	a, (iy+37h)
		ld	(iy+37h), a
		call	PWOFF
		jp	loc_5083
; ---------------------------------------------------------------------------

loc_5137:				; CODE XREF: dos_cmd_dcopy+5Fj
					; dos_cmd_dcopy+123j
		call	PWOFF
		call	reset_basic_env
		ld	bc, 1A19h
		push	bc
		jp	1B4Dh
; End of function dos_cmd_dcopy


; =============== S U B	R O U T	I N E =======================================


reset_basic_env:			; CODE XREF: ERROR:loc_4246p
					; dos_cmd_dcopy+13Fp ...
		ld	hl, 7AE9h
		ld	(78A4h), hl
		ld	(hl), 0
		inc	hl
		ld	(hl), 0
		inc	hl
		ld	(78F9h), hl
		ld	(78FBh), hl
		ld	(78FDh), hl
		ld	(iy+0Bh), 10h
		ld	(iy+39h), 0
		ret
; End of function reset_basic_env

; ---------------------------------------------------------------------------
; START	OF FUNCTION CHUNK FOR dos_cmd_dcopy

loc_5162:				; CODE XREF: dos_cmd_dcopy+4Fj
					; dos_cmd_dcopy+5Cj ...
		call	reset_basic_env
		jp	ERROR		; Error	code in	A
; END OF FUNCTION CHUNK	FOR dos_cmd_dcopy ; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break

; =============== S U B	R O U T	I N E =======================================

; DCOPY	: get console input
; Source disk
; Destination disk

dcopy_con_input:			; CODE XREF: dos_cmd_dcopy+1Cp
					; dos_cmd_dcopy+85p
		ld	hl, aSourceDisk12 ; "\rSOURCE DISK(1/2)? "
		call	28A7h
		call	usr_input_keys	; Read one character from user input:  '1' or '2'.
					; Result is in 'C' register
		ld	a, c
		call	32Ah		; Echo char to screen
		and	3
		ld	(iy+0Dh), a
		ld	hl, aDestinationDisk ; "\rDESTINATION DISK(1/2)? "
		call	28A7h
		call	usr_input_keys	; Read one character from user input:  '1' or '2'.
					; Result is in 'C' register
		ld	a, c
		call	32Ah		; Echo char to screen
		and	3
		ld	(iy+10h), a
		ld	a, 0Dh
		call	32Ah		; Echo char to screen
		ret
; End of function dcopy_con_input


; =============== S U B	R O U T	I N E =======================================

; Read one character from user input:  '1' or '2'.
; Result is in 'C' register

usr_input_keys:				; CODE XREF: dcopy_con_input+6p
					; dcopy_con_input+18p ...
		ld	a, (7AAFh)
		or	a
		jr	nz, usr_input_keys ; Wait till a key is	pressed
		di
		ld	e, 10h
		ld	d, e
		ld	hl, (7820h)

read_key:				; CODE XREF: usr_input_keys+11j
					; usr_input_keys+46j
		ld	a, (6800h)
		or	a
		jp	m, read_key
		dec	d
		jr	nz, deflickr
		ld	d, e
		ld	a, 40h ; '@'
		xor	(hl)
		ld	(hl), a

deflickr:				; CODE XREF: usr_input_keys+15j
					; usr_input_keys+20j
		ld	a, (6800h)
		or	a
		jp	p, deflickr
		ld	a, (68DFh)
		bit	2, a
		jr	nz, key_pressed
		ld	a, (68FDh)
		bit	2, a
		jr	nz, key_pressed
		call	reset_basic_env
		ld	a, 11h
		jp	ERROR		; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
; ---------------------------------------------------------------------------

key_pressed:				; CODE XREF: usr_input_keys+28j
					; usr_input_keys+2Fj
		ld	a, (68F7h)
		bit	4, a		; Bit position for key '1' is 4, for key '2' is 1
		ld	c, 31h ; '1'
		jr	z, key_12_pressed
		bit	1, a
		ld	c, 32h ; '2'
		jr	nz, read_key

key_12_pressed:				; CODE XREF: usr_input_keys+40j
		push	bc
		ld	bc, 64h	; 'd'
		call	DLY		; delay	ms
		pop	bc

is_key_released:			; CODE XREF: usr_input_keys+56j
		ld	a, (6800h)
		or	80h ; '�'
		inc	a
		jr	nz, is_key_released
		ei
		ret
; End of function usr_input_keys

; ---------------------------------------------------------------------------
aSourceDisk12:	.db 0Dh			; DATA XREF: dcopy_con_inputo
		.text "SOURCE DISK(1/2)? "
		.db 0
aDestinationDisk:.db 0Dh		; DATA XREF: dcopy_con_input+12o
		.text "DESTINATION DISK(1/2)? "
		.db 0

; =============== S U B	R O U T	I N E =======================================


sub_5219:				; CODE XREF: dos_cmd_dcopy+1Fp
					; dos_cmd_dcopy+8Fp
		ld	a, (iy+0Dh)
		call	set_active_drv	; iy+0Dh : Source drv for DCOPY
		cp	(iy+10h)	; iy+10h : Dest	drv fro	DCOPY
		ret	nz
		ld	hl, aInsertSourceDis ; "\rINSERT SOURCE DISKETTE\r"

loc_5226:				; CODE XREF: sub_5275+Dj
		call	28A7h
		ld	hl, aPressSpaceWhenR ; "(PRESS SPACE WHEN READY)\r"
		call	28A7h

loc_522F:				; CODE XREF: sub_5219+1Aj
		ld	a, (7AAFh)
		or	a
		jr	nz, loc_522F
		di
		ld	e, 10h
		ld	d, e
		ld	hl, (7820h)

loc_523C:				; CODE XREF: sub_5219+27j sub_5219+54j
		ld	a, (6800h)
		or	a
		jp	m, loc_523C
		dec	d
		jr	nz, loc_524B
		ld	d, e
		ld	a, 40h ; '@'
		xor	(hl)
		ld	(hl), a

loc_524B:				; CODE XREF: sub_5219+2Bj sub_5219+36j
		ld	a, (6800h)
		or	a
		jp	p, loc_524B
		ld	a, (68DFh)
		bit	2, a
		jr	nz, loc_5268
		ld	a, (68FDh)
		bit	2, a
		jr	nz, loc_5268
		call	reset_basic_env
		ld	a, 11h
		jp	ERROR		; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
; ---------------------------------------------------------------------------

loc_5268:				; CODE XREF: sub_5219+3Ej sub_5219+45j
		ld	a, (68EFh)
		bit	4, a
		jr	nz, loc_523C
		ld	a, (783Ch)
		ld	(hl), a
		ei
		ret
; End of function sub_5219


; =============== S U B	R O U T	I N E =======================================


sub_5275:				; CODE XREF: dos_cmd_dcopy+52p
					; dos_cmd_dcopy+D9p
		ld	a, (iy+10h)
		call	set_active_drv
		cp	(iy+0Dh)
		ret	nz
		ld	hl, aInsertDestinati ; "\rINSERT DESTINATION DISKETTE\r"
		jr	loc_5226
; End of function sub_5275

; ---------------------------------------------------------------------------
aInsertSourceDis:.db 0Dh		; DATA XREF: sub_5219+Ao
		.text "INSERT SOURCE DISKETTE"
		.db 0Dh, 0
aPressSpaceWhenR:.text "(PRESS SPACE WHEN READY)" ; DATA XREF: sub_5219+10o
		.db 0Dh, 0
aInsertDestinati:.db 0Dh		; DATA XREF: sub_5275+Ao
		.text "INSERT DESTINATION DISKETTE"
		.db 0Dh, 0

; =============== S U B	R O U T	I N E =======================================

; DOS STATUS Command

dos_cmd_status:				; DATA XREF: DOSROM:438Fo
		push	hl
		di
		call	POWON
		push	bc
		ld	bc, 32h	; '2'   ; 50ms delay
		call	DLY		; delay	ms
		pop	bc
		ld	(iy+12h), 0	; User Spec, Track Number
		ld	(iy+11h), 0Fh	; User Spec, Sector Number
		call	READ		; SECTOR READ ROUTINE
					;
					; retry	10 times
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		call	PWOFF
		ld	l, (iy+31h)
		ld	h, (iy+32h)
		ld	e, 0
		ld	d, 0
		ld	c, 4Eh ; 'N'

loc_5300:				; CODE XREF: dos_cmd_status+37j
		ld	b, 8
		ld	a, (hl)

loc_5303:				; CODE XREF: dos_cmd_status:loc_5308j
		rrc	a
		jr	c, loc_5308
		inc	de

loc_5308:				; CODE XREF: dos_cmd_status+30j
		djnz	loc_5303
		inc	hl
		dec	c
		jr	nz, loc_5300
		ld	l, e
		ld	h, d
		push	hl
		call	0FAFh
		ld	hl, aRecordsFree ; String : ' RECORDS FREE\r'
		call	28A7h		; Display string
		pop	hl
		push	hl
		srl	h
		rr	l
		srl	h
		rr	l
		srl	h
		rr	l
		call	0FAFh
		ld	a, 2Eh ; '.'
		call	32Ah
		pop	hl
		ld	a, 7
		and	l
		inc	a
		ld	b, a
		ld	hl, 0FF83h
		ld	de, 7Dh	; '}'

loc_533C:				; CODE XREF: dos_cmd_status+68j
		add	hl, de
		djnz	loc_533C
		call	0FAFh
		ld	hl, aKBytesFree	; String: 'K BYTES FREE\r'
		call	28A7h
		pop	hl
; End of function dos_cmd_status

		ret
; ---------------------------------------------------------------------------
aRecordsFree:	.text " RECORDS FREE"   ; DATA XREF: dos_cmd_status+3Fo
		.db 0Dh, 0
aKBytesFree:	.text "K BYTES FREE"    ; DATA XREF: dos_cmd_status+6Do
		.db 0Dh, 0

; =============== S U B	R O U T	I N E =======================================


CSI:					; CODE XREF: DOSROM:401Dj
					; dos_cmd_loadp ...
		call	get_filename
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ld	a, (hl)
		or	a
		ret	z
		cp	3Ah ; ':'
		jp	nz, 1997h
		xor	a
		ret
; End of function CSI


; =============== S U B	R O U T	I N E =======================================


get_filename:				; CODE XREF: dos_cmd_open+3p
					; dos_cmd_bsavep ...
		push	iy
		ld	b, 8

loc_537C:				; CODE XREF: get_filename+Aj
		ld	(iy+1),	20h ; ' '
		inc	iy
		djnz	loc_537C
		pop	iy

loc_5386:				; CODE XREF: get_filename+12j
		ld	a, (hl)
		inc	hl
		cp	20h ; ' '
		jr	z, loc_5386
		dec	hl
		rst	8
		ld	(806h),	hl
		ld	a, (hl)
		cp	22h ; '"'
		jr	nz, loc_5399

loc_5396:				; CODE XREF: get_filename+35j
		ld	a, 1
		ret
; ---------------------------------------------------------------------------

loc_5399:				; CODE XREF: get_filename+1Cj
		push	iy

loc_539B:				; CODE XREF: get_filename+2Ej
		ld	a, (hl)
		inc	hl
		cp	22h ; '"'
		jr	z, loc_53B5
		ld	(iy+1),	a
		inc	iy
		djnz	loc_539B
		pop	iy

loc_53AA:				; CODE XREF: get_filename+3Bj
		ld	a, (hl)
		inc	hl
		or	a
		jr	z, loc_5396
		cp	22h ; '"'
		jr	z, loc_53B7
		jr	loc_53AA
; ---------------------------------------------------------------------------

loc_53B5:				; CODE XREF: get_filename+27j
		pop	iy

loc_53B7:				; CODE XREF: get_filename+39j
		xor	a
		ret
; End of function get_filename


; =============== S U B	R O U T	I N E =======================================


HEX:					; CODE XREF: DOSROM:4020j
					; dos_cmd_bsave+15p ...
		call	hexstr_val
		ret	c
		ld	d, e
		jp	hexstr_val	; ???What is this???
; End of function HEX


; =============== S U B	R O U T	I N E =======================================


hexstr_val:				; CODE XREF: HEXp HEX+5j
		ld	a, (hl)
		inc	hl
		call	hexchar_val
		ret	c
		rla
		rla
		rla
		rla
		ld	e, a
		ld	a, (hl)
		inc	hl
		call	hexchar_val
		ret	c
		or	e
		ld	e, a
		ret
; End of function hexstr_val


; =============== S U B	R O U T	I N E =======================================


hexchar_val:				; CODE XREF: hexstr_val+2p
					; hexstr_val+Dp
		cp	30h ; '0'
		ret	c
		cp	3Ah ; ':'
		jr	nc, loc_53DF
		and	0Fh
		ret
; ---------------------------------------------------------------------------

loc_53DF:				; CODE XREF: hexchar_val+5j
		cp	41h ; 'A'
		ret	c
		cp	47h ; 'G'
		jr	nc, loc_53E8
		add	a, 0C9h	; '�'

loc_53E8:				; CODE XREF: hexchar_val+Fj
		ccf
		ret
; End of function hexchar_val


; =============== S U B	R O U T	I N E =======================================


IDAM:					; CODE XREF: DOSROM:4023j
					; sub_4CBB:loc_4D14p ...
		ld	h, 0A5h	; '�'
		ld	l, 0Ah
		jr	loc_53FB	; User Spec, Track Number
; ---------------------------------------------------------------------------

loc_53F0:				; CODE XREF: IDAM+37Fj
		ld	l, 0Ah
		ld	(iy+38h), 11h
		ld	b, 28h ; '('
		call	STPOUT

loc_53FB:				; CODE XREF: IDAM+4j IDAM+37Cj
		ld	a, (iy+12h)	; User Spec, Track Number
		sub	(iy+14h)	; Current Track	Number
		jr	z, loc_541D
		jp	p, loc_5411
		neg
		ld	b, a
		call	STPOUT
		jr	loc_541D
; ---------------------------------------------------------------------------

goto_exit_key:				; CODE XREF: IDAM+4Cj
		jp	check_exit_key	; de-flickering, wait till '-' key is released, exit
; ---------------------------------------------------------------------------

loc_5411:				; CODE XREF: IDAM+19j
		ld	b, a
		call	STPIN
		push	bc
		ld	bc, 64h	; 'd'   ; 100ms
		call	DLY		; delay	ms
		pop	bc

loc_541D:				; CODE XREF: IDAM+17j IDAM+22j
		ld	c, 12h
		ld	a, (iy+12h)	; User Spec, Track Number
		add	a, (iy+11h)	; User Spec, Sector Number
		ld	d, a
		in	a, (11h)	; Read a byte

loc_5428:				; CODE XREF: IDAM+40j
		in	a, (c)		; polling
		jp	p, loc_5428	; polling
		nop
		nop
		nop
		nop

sync_to_0x80:				; CODE XREF: IDAM:loc_5443j IDAM+163j	...
		ld	a, (68DFh)
		and	4
		jr	z, goto_exit_key
		in	a, (11h)	; ready	a byte
		ld	b, a

loc_543B:				; CODE XREF: IDAM+53j
		in	a, (c)		; polling
		jp	p, loc_543B	; polling
		ld	a, b
		cp	80h ; '�'

loc_5443:
		jp	nz, sync_to_0x80

loc_5446:				; CODE XREF: IDAM+DEj
		nop
		nop
		nop
		ld	a, 0
		ld	a, 0
		in	a, (11h)	; ready	a byte

loc_544F:				; CODE XREF: IDAM+67j
		in	a, (c)		; polling
		jp	p, loc_544F	; polling
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)	; ready	a byte

loc_545F:				; CODE XREF: IDAM+77j
		in	a, (c)
		jp	p, loc_545F
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)	; ready	a byte

loc_546F:				; CODE XREF: IDAM+87j
		in	a, (c)
		jp	p, loc_546F
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)	; ready	a byte

loc_547F:				; CODE XREF: IDAM+97j
		in	a, (c)
		jp	p, loc_547F
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)	; ready	a byte

loc_548F:				; CODE XREF: IDAM+A7j
		in	a, (c)
		jp	p, loc_548F
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)	; ready	a byte

loc_549F:				; CODE XREF: IDAM+B7j
		in	a, (c)
		jp	p, loc_549F
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)	; ready	a byte

loc_54AF:				; CODE XREF: IDAM+C7j
		in	a, (c)
		jp	p, loc_54AF
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)	; ready	a byte
		ld	b, a

loc_54C0:				; CODE XREF: IDAM+D8j
		in	a, (c)
		jp	p, loc_54C0
		ld	a, b
		cp	80h ; '�'       ; 0x80
		jp	z, loc_5446
		nop
		nop
		nop
		ld	a, 0
		ld	a, 0
		in	a, (11h)	; ready	a byte

loc_54D4:				; CODE XREF: IDAM+ECj
		in	a, (c)
		jp	p, loc_54D4
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)	; ready	a byte

loc_54E4:				; CODE XREF: IDAM+FCj
		in	a, (c)
		jp	p, loc_54E4
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)	; ready	a byte

loc_54F4:				; CODE XREF: IDAM+10Cj
		in	a, (c)
		jp	p, loc_54F4
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)	; ready	a byte

loc_5504:				; CODE XREF: IDAM+11Cj
		in	a, (c)
		jp	p, loc_5504
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)	; ready	a byte

loc_5514:				; CODE XREF: IDAM+12Cj
		in	a, (c)
		jp	p, loc_5514
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)	; ready	a byte

loc_5524:				; CODE XREF: IDAM+13Cj
		in	a, (c)
		jp	p, loc_5524
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)	; ready	a byte

loc_5534:				; CODE XREF: IDAM+14Cj
		in	a, (c)
		jp	p, loc_5534
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)	; ready	a byte
		ld	b, a

loc_5545:				; CODE XREF: IDAM+15Dj
		in	a, (c)
		jp	p, loc_5545
		ld	a, b
		cp	0FEh ; '�'      ; GAP1:
					; 7 bytes of 0x80h
					; 1 bytes of 0x00h
					;
					; IDAM:
					; 7 bytes
					; FE, E7, 18, C3, Trk#,	Sctr#, checksum(1byte)
		jp	nz, sync_to_0x80
		nop
		nop
		nop
		ld	a, 0
		ld	a, 0
		in	a, (11h)

loc_5559:				; CODE XREF: IDAM+171j
		in	a, (c)
		jp	p, loc_5559
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_5569:				; CODE XREF: IDAM+181j
		in	a, (c)
		jp	p, loc_5569
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_5579:				; CODE XREF: IDAM+191j
		in	a, (c)
		jp	p, loc_5579
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_5589:				; CODE XREF: IDAM+1A1j
		in	a, (c)
		jp	p, loc_5589
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_5599:				; CODE XREF: IDAM+1B1j
		in	a, (c)
		jp	p, loc_5599
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_55A9:				; CODE XREF: IDAM+1C1j
		in	a, (c)
		jp	p, loc_55A9
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_55B9:				; CODE XREF: IDAM+1D1j
		in	a, (c)
		jp	p, loc_55B9
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)
		ld	b, a

loc_55CA:				; CODE XREF: IDAM+1E2j
		in	a, (c)
		jp	p, loc_55CA
		ld	a, b
		cp	0E7h ; '�'
		jp	nz, sync_to_0x80
		nop
		nop
		nop
		ld	a, 0
		ld	a, 0
		in	a, (11h)

loc_55DE:				; CODE XREF: IDAM+1F6j
		in	a, (c)
		jp	p, loc_55DE
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_55EE:				; CODE XREF: IDAM+206j
		in	a, (c)
		jp	p, loc_55EE
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_55FE:				; CODE XREF: IDAM+216j
		in	a, (c)
		jp	p, loc_55FE
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_560E:				; CODE XREF: IDAM+226j
		in	a, (c)
		jp	p, loc_560E
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_561E:				; CODE XREF: IDAM+236j
		in	a, (c)
		jp	p, loc_561E
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_562E:				; CODE XREF: IDAM+246j
		in	a, (c)
		jp	p, loc_562E
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_563E:				; CODE XREF: IDAM+256j
		in	a, (c)
		jp	p, loc_563E
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)
		ld	b, a

loc_564F:				; CODE XREF: IDAM+267j
		in	a, (c)
		jp	p, loc_564F
		ld	a, b
		cp	18h
		jp	nz, sync_to_0x80
		nop
		nop
		nop
		ld	a, 0
		ld	a, 0
		in	a, (11h)

loc_5663:				; CODE XREF: IDAM+27Bj
		in	a, (c)
		jp	p, loc_5663
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		ld	a, 0

loc_5673:				; CODE XREF: IDAM+28Dj
		in	a, (11h)

loc_5675:
		in	a, (c)
; CUSTOM_ROM : zzemu's IDAM sync path
		;jp	p, loc_5673	; DOS121_patch:	jp p, loc_5675
		jp p, loc_5675
; CUSTOM_ROM: END
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0

loc_5683:				; CODE XREF: IDAM+29Dj
		in	a, (11h)

loc_5685:
		in	a, (c)
; CUSTOM_ROM : zzemu's IDAM sync path
		;jp	p, loc_5683	; DOS121_patch:	jp p, loc_5685
		jp p, loc_5685
; CUSTOM_ROM: END
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		in	a, (11h)

loc_5693:				; CODE XREF: IDAM+2ABj
		in	a, (c)
		jp	p, loc_5693
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_56A3:				; CODE XREF: IDAM+2BBj
		in	a, (c)
		jp	p, loc_56A3
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_56B3:				; CODE XREF: IDAM+2CBj
		in	a, (c)
		jp	p, loc_56B3
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_56C3:				; CODE XREF: IDAM+2DBj
		in	a, (c)
		jp	p, loc_56C3
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)
		ld	b, a

loc_56D4:				; CODE XREF: IDAM+2ECj
		in	a, (c)
		jp	p, loc_56D4
		ld	a, b
		cp	0C3h ; '�'
		jp	nz, sync_to_0x80
		nop
		nop
		nop
		ld	a, 0
		ld	a, 0
		in	a, (11h)

loc_56E8:				; CODE XREF: IDAM+300j
		in	a, (c)
		jp	p, loc_56E8
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_56F8:				; CODE XREF: IDAM+310j
		in	a, (c)
		jp	p, loc_56F8
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_5708:				; CODE XREF: IDAM+320j
		in	a, (c)
		jp	p, loc_5708
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_5718:				; CODE XREF: IDAM+330j
		in	a, (c)
		jp	p, loc_5718
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_5728:				; CODE XREF: IDAM+340j
		in	a, (c)
		jp	p, loc_5728
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_5738:				; CODE XREF: IDAM+350j
		in	a, (c)
		jp	p, loc_5738
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_5748:				; CODE XREF: IDAM+360j
		in	a, (c)
		jp	p, loc_5748
		ld	a, (iy+12h)	; User Spec, track number
		ld	b, a
		nop
		jp	loc_5755
; ---------------------------------------------------------------------------

loc_5755:				; CODE XREF: IDAM+368j
		jp	loc_5758
; ---------------------------------------------------------------------------

loc_5758:				; CODE XREF: IDAM:loc_5755j
		in	a, (11h)
		ex	af, af'

loc_575B:				; CODE XREF: IDAM+373j
		in	a, (c)
		jp	p, loc_575B
		ex	af, af'
		cp	b
		jp	z, loc_576C
		dec	l
		jp	nz, loc_53FB	; User Spec, Track Number
		jp	loc_53F0
; ---------------------------------------------------------------------------

loc_576C:				; CODE XREF: IDAM+378j
		nop
		nop
		nop
		jp	loc_5772
; ---------------------------------------------------------------------------

loc_5772:				; CODE XREF: IDAM+385j
		ld	a, 0
		in	a, (11h)

loc_5776:				; CODE XREF: IDAM+38Ej
		in	a, (c)
		jp	p, loc_5776
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_5786:				; CODE XREF: IDAM+39Ej
		in	a, (c)
		jp	p, loc_5786
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_5796:				; CODE XREF: IDAM+3AEj
		in	a, (c)
		jp	p, loc_5796
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_57A6:				; CODE XREF: IDAM+3BEj
		in	a, (c)
		jp	p, loc_57A6
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_57B6:				; CODE XREF: IDAM+3CEj
		in	a, (c)
		jp	p, loc_57B6
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_57C6:				; CODE XREF: IDAM+3DEj
		in	a, (c)
		jp	p, loc_57C6
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_57D6:				; CODE XREF: IDAM+3EEj
		in	a, (c)
		jp	p, loc_57D6
		ld	a, (iy+11h)	; User Spec, sector number
		ld	b, a
		nop
		jp	loc_57E3
; ---------------------------------------------------------------------------

loc_57E3:				; CODE XREF: IDAM+3F6j
		jp	loc_57E6
; ---------------------------------------------------------------------------

loc_57E6:				; CODE XREF: IDAM:loc_57E3j
		in	a, (11h)
		ex	af, af'

loc_57E9:				; CODE XREF: IDAM+401j
		in	a, (c)
		jp	p, loc_57E9
		ex	af, af'
		cp	b
		jp	z, loc_57FB
		dec	h
		jp	nz, sync_to_0x80
		ld	a, 9
		or	a
		ret
; ---------------------------------------------------------------------------

loc_57FB:				; CODE XREF: IDAM+406j
		nop
		nop
		nop
		jp	loc_5801
; ---------------------------------------------------------------------------

loc_5801:				; CODE XREF: IDAM+414j
		ld	a, 0
		in	a, (11h)

loc_5805:				; CODE XREF: IDAM+41Dj
		in	a, (c)
		jp	p, loc_5805
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_5815:				; CODE XREF: IDAM+42Dj
		in	a, (c)
		jp	p, loc_5815
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_5825:				; CODE XREF: IDAM+43Dj
		in	a, (c)
		jp	p, loc_5825
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_5835:				; CODE XREF: IDAM+44Dj
		in	a, (c)
		jp	p, loc_5835
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_5845:				; CODE XREF: IDAM+45Dj
		in	a, (c)
		jp	p, loc_5845
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_5855:				; CODE XREF: IDAM+46Dj
		in	a, (c)
		jp	p, loc_5855
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

loc_5865:				; CODE XREF: IDAM+47Dj
		in	a, (c)
		jp	p, loc_5865
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)	; 1 byte checksum
		cp	d
		jp	nz, sync_to_0x80
		xor	a		; no error
		ret
; End of function IDAM


; =============== S U B	R O U T	I N E =======================================


CREATE:					; CODE XREF: DOSROM:4026j SAVEOB+3Ep ...
		call	SEARCH
		cp	0Dh
		jr	z, loc_5884
		or	a
		ret	nz

loc_5884:				; CODE XREF: CREATE+5j
		call	FIND
		or	a
		ret	nz
		ld	d, (iy+11h)
		push	de
		push	hl
		call	MAP
		pop	hl
		pop	de
		or	a
		ret	nz
		ld	(iy+11h), d
		push	hl
		call	READ		; SECTOR READ ROUTINE
					;
					; retry	10 times
		pop	hl
		or	a
		ret	nz
		ex	de, hl
		ld	a, (iy+9)
		ld	(de), a
		inc	de
		ld	a, 3Ah ; ':'
		ld	(de), a
		inc	de
		push	iy
		pop	hl
		inc	hl
		ld	bc, 8
		ldir
		ld	a, (iy+16h)
		ld	(de), a
		inc	de
		ld	a, (iy+15h)
		ld	(de), a
		call	WRITE
		ret
; End of function CREATE


; =============== S U B	R O U T	I N E =======================================


MAP:					; CODE XREF: DOSROM:4029j SAVEOB+54p ...
		ld	(iy+16h), 1
		ld	(iy+15h), 0
		ld	l, (iy+34h)
		ld	h, (iy+35h)
		dec	hl

loc_58CE:				; CODE XREF: MAP+3Bj
		inc	hl
		ld	c, (hl)

loc_58D0:				; CODE XREF: MAP+1Dj
		rrc	c
		jr	nc, loc_58FF
		inc	(iy+15h)
		ld	a, (iy+15h)
		cp	8
		jr	nz, loc_58D0
		inc	hl
		ld	c, (hl)

loc_58E0:				; CODE XREF: MAP+2Dj
		rrc	c
		jr	nc, loc_58FF
		inc	(iy+15h)
		ld	a, (iy+15h)
		cp	10h
		jr	nz, loc_58E0
		ld	(iy+15h), 0
		inc	(iy+16h)
		ld	a, (iy+16h)
		cp	28h ; '('
		jr	nz, loc_58CE
		ld	a, 7
		ret
; ---------------------------------------------------------------------------

loc_58FF:				; CODE XREF: MAP+13j MAP+23j
		rlc	c
		set	0, c
		ld	a, (iy+15h)
		and	7
		inc	a
		ld	b, a
		rrc	c

loc_590C:				; CODE XREF: MAP+4Fj
		rlc	c
		djnz	loc_590C
		ld	(hl), c
		xor	a
		ret
; End of function MAP


; =============== S U B	R O U T	I N E =======================================


SEARCH:					; CODE XREF: DOSROM:402Cj DOSROM:43BDp ...
		ld	l, (iy+31h)
		ld	h, (iy+32h)
		ld	(iy+12h), 0
		ld	(iy+11h), 0

loc_5921:				; CODE XREF: SEARCH+50j
		call	READ		; SECTOR READ ROUTINE
					;
					; retry	10 times
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ld	b, 8
		ld	l, (iy+31h)
		ld	h, (iy+32h)
		push	iy
		pop	de
		inc	de

loc_5934:				; CODE XREF: SEARCH+46j
		ld	a, (hl)
		or	a
		ret	z
		push	de
		push	hl
		cp	1
		jr	z, loc_5953
		ld	(iy+0Ah), a
		inc	hl
		inc	hl
		ld	c, 8
		ex	de, hl

loc_5945:				; CODE XREF: SEARCH+39j
		ld	a, (de)
		cp	(hl)
		jr	nz, loc_5953
		inc	hl
		inc	de
		dec	c
		jr	nz, loc_5945
		pop	af
		pop	af
		ld	a, 2
		ret
; ---------------------------------------------------------------------------

loc_5953:				; CODE XREF: SEARCH+28j SEARCH+34j
		pop	hl
		ld	de, 10h
		add	hl, de
		pop	de
		djnz	loc_5934
		inc	(iy+11h)
		ld	a, (iy+11h)
		cp	0Fh
		jr	nz, loc_5921
		ld	a, 0Dh
		ret
; End of function SEARCH


; =============== S U B	R O U T	I N E =======================================


FIND:					; CODE XREF: DOSROM:402Fj
					; CREATE:loc_5884p
		ld	l, (iy+31h)
		ld	h, (iy+32h)
		ld	(iy+12h), 0
		ld	(iy+11h), 0

loc_5976:				; CODE XREF: FIND+34j
		call	READ		; SECTOR READ ROUTINE
					;
					; retry	10 times
		or	a
		jp	nz, ERROR	; Error	code in	A
					; 0  - No error
					; 1  - Syntax error
					; 2  - File already exists
					; 3  - Directory full
					; 4  - Disk write protected
					; 5  - File not	open
					; 6  - Disk I/O	error
					; 7  - Disk full
					; 8  - File already open
					; 9  - Sector not found
					; 10 - Checksum	error
					; 11 - Unsupported device
					; 12 - File type mismatch
					; 13 - File not	found
					; 14 - Disk buffer full
					; 15 - Illegal read
					; 16 - Illegal write
					; 17 - Break
		ld	b, 8
		ld	l, (iy+31h)
		ld	h, (iy+32h)

loc_5985:				; CODE XREF: FIND+2Aj
		ld	a, (hl)
		or	a
		ret	z
		cp	1
		jr	nz, loc_598E
		xor	a
		ret
; ---------------------------------------------------------------------------

loc_598E:				; CODE XREF: FIND+22j
		ld	de, 10h
		add	hl, de
		djnz	loc_5985
		inc	(iy+11h)
		ld	a, (iy+11h)
		cp	0Fh
		jr	nz, loc_5976
		ld	a, 3
		ret
; End of function FIND


; =============== S U B	R O U T	I N E =======================================


WRITE:					; CODE XREF: DOSROM:4032j SAVEOB+6Cp ...
		call	checksum
		push	de
		push	iy
		pop	hl
		ld	de, 0CDh ; '�'
		add	hl, de
		pop	de
		ld	(hl), e
		inc	hl
		ld	(hl), d
		push	iy
		pop	hl
		ld	de, 43h	; 'C'
		add	hl, de
		ld	b, 8Ch ; '�'
		exx
		call	IDAM
		jp	z, loc_59C6
		cp	11h
		ret	z
		ld	a, 9
		ret
; ---------------------------------------------------------------------------

loc_59C6:				; CODE XREF: WRITE+1Cj
		exx
		ld	d, (iy+33h)
		res	6, d
		ld	a, d
		out	(10h), a

loc_59CF:				; CODE XREF: WRITE+162j
		ld	c, (hl)
		ld	a, 20h ; ' '
		xor	d
		rl	c
		jp	nc, loc_59E3
		out	(10h), a
		xor	20h ; ' '
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_59EE
; ---------------------------------------------------------------------------

loc_59E3:				; CODE XREF: WRITE+34j
		out	(10h), a
		xor	0
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_59EE
; ---------------------------------------------------------------------------

loc_59EE:				; CODE XREF: WRITE+3Fj	WRITE+4Aj
		inc	hl
		jp	loc_59F2
; ---------------------------------------------------------------------------

loc_59F2:				; CODE XREF: WRITE+4Ej
		jp	loc_59F5
; ---------------------------------------------------------------------------

loc_59F5:				; CODE XREF: WRITE:loc_59F2j
		in	a, (12h)
		ld	a, 20h ; ' '
		xor	d
		rl	c
		jp	nc, loc_5A0A
		out	(10h), a
		xor	20h ; ' '
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_5A15
; ---------------------------------------------------------------------------

loc_5A0A:				; CODE XREF: WRITE+5Bj
		out	(10h), a
		xor	0
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_5A15
; ---------------------------------------------------------------------------

loc_5A15:				; CODE XREF: WRITE+66j	WRITE+71j
		inc	hl
		jp	loc_5A19
; ---------------------------------------------------------------------------

loc_5A19:				; CODE XREF: WRITE+75j
		jp	loc_5A1C
; ---------------------------------------------------------------------------

loc_5A1C:				; CODE XREF: WRITE:loc_5A19j
		in	a, (12h)
		ld	a, 20h ; ' '
		xor	d
		rl	c
		jp	nc, loc_5A31
		out	(10h), a
		xor	20h ; ' '
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_5A3C
; ---------------------------------------------------------------------------

loc_5A31:				; CODE XREF: WRITE+82j
		out	(10h), a
		xor	0
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_5A3C
; ---------------------------------------------------------------------------

loc_5A3C:				; CODE XREF: WRITE+8Dj	WRITE+98j
		inc	hl
		jp	loc_5A40
; ---------------------------------------------------------------------------

loc_5A40:				; CODE XREF: WRITE+9Cj
		jp	loc_5A43
; ---------------------------------------------------------------------------

loc_5A43:				; CODE XREF: WRITE:loc_5A40j
		in	a, (12h)
		ld	a, 20h ; ' '
		xor	d
		rl	c
		jp	nc, loc_5A58
		out	(10h), a
		xor	20h ; ' '
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_5A63
; ---------------------------------------------------------------------------

loc_5A58:				; CODE XREF: WRITE+A9j
		out	(10h), a
		xor	0
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_5A63
; ---------------------------------------------------------------------------

loc_5A63:				; CODE XREF: WRITE+B4j	WRITE+BFj
		inc	hl
		jp	loc_5A67
; ---------------------------------------------------------------------------

loc_5A67:				; CODE XREF: WRITE+C3j
		jp	loc_5A6A
; ---------------------------------------------------------------------------

loc_5A6A:				; CODE XREF: WRITE:loc_5A67j
		in	a, (12h)
		ld	a, 20h ; ' '
		xor	d
		rl	c
		jp	nc, loc_5A7F
		out	(10h), a
		xor	20h ; ' '
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_5A8A
; ---------------------------------------------------------------------------

loc_5A7F:				; CODE XREF: WRITE+D0j
		out	(10h), a
		xor	0
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_5A8A
; ---------------------------------------------------------------------------

loc_5A8A:				; CODE XREF: WRITE+DBj	WRITE+E6j
		inc	hl
		jp	loc_5A8E
; ---------------------------------------------------------------------------

loc_5A8E:				; CODE XREF: WRITE+EAj
		jp	loc_5A91
; ---------------------------------------------------------------------------

loc_5A91:				; CODE XREF: WRITE:loc_5A8Ej
		in	a, (12h)
		ld	a, 20h ; ' '
		xor	d
		rl	c
		jp	nc, loc_5AA6
		out	(10h), a
		xor	20h ; ' '
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_5AB1
; ---------------------------------------------------------------------------

loc_5AA6:				; CODE XREF: WRITE+F7j
		out	(10h), a
		xor	0
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_5AB1
; ---------------------------------------------------------------------------

loc_5AB1:				; CODE XREF: WRITE+102j WRITE+10Dj
		inc	hl
		jp	loc_5AB5
; ---------------------------------------------------------------------------

loc_5AB5:				; CODE XREF: WRITE+111j
		jp	loc_5AB8
; ---------------------------------------------------------------------------

loc_5AB8:				; CODE XREF: WRITE:loc_5AB5j
		in	a, (12h)
		ld	a, 20h ; ' '
		xor	d
		rl	c
		jp	nc, loc_5ACD
		out	(10h), a
		xor	20h ; ' '
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_5AD8
; ---------------------------------------------------------------------------

loc_5ACD:				; CODE XREF: WRITE+11Ej
		out	(10h), a
		xor	0
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_5AD8
; ---------------------------------------------------------------------------

loc_5AD8:				; CODE XREF: WRITE+129j WRITE+134j
		inc	hl
		jp	loc_5ADC
; ---------------------------------------------------------------------------

loc_5ADC:				; CODE XREF: WRITE+138j
		jp	loc_5ADF
; ---------------------------------------------------------------------------

loc_5ADF:				; CODE XREF: WRITE:loc_5ADCj
		in	a, (12h)
		ld	a, 20h ; ' '
		xor	d
		rl	c
		jp	nc, loc_5AF4
		out	(10h), a
		xor	20h ; ' '
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_5AFF
; ---------------------------------------------------------------------------

loc_5AF4:				; CODE XREF: WRITE+145j
		out	(10h), a
		xor	0
		ld	d, a
		dec	hl
		out	(10h), a
		jp	loc_5AFF
; ---------------------------------------------------------------------------

loc_5AFF:				; CODE XREF: WRITE+150j WRITE+15Bj
		inc	hl
		inc	hl
		nop
		dec	b
		jp	nz, loc_59CF
		set	6, d
		ld	a, d
		out	(10h), a
		ld	(iy+33h), a
		xor	a
		ret
; End of function WRITE


; =============== S U B	R O U T	I N E =======================================


checksum:				; CODE XREF: WRITEp
					; READ:rd_sector_donep
		push	iy
		pop	hl
		ld	de, 4Dh	; 'M'   ; iy+4D = sector read buffer
		add	hl, de
		ld	e, (hl)
		ld	d, 0
		ld	b, 7Fh ; ''

loc_5B1C:				; CODE XREF: checksum+14j
		inc	hl
		ld	a, e
		add	a, (hl)
		ld	e, a
		ld	a, 0
		adc	a, d
		ld	d, a
		djnz	loc_5B1C
		ret
; End of function checksum


; =============== S U B	R O U T	I N E =======================================

; SECTOR READ ROUTINE
;
; retry	10 times

READ:					; CODE XREF: DOSROM:4035j
					; DOSROM:loc_43F3p ...
		ld	(iy+13h), 0Ah	; Retry	10 times

loc_5B2B:				; CODE XREF: READ+375j
		call	IDAM		; Sync to requested SECTOR/TRACK using IDAM
		jp	z, READ_SECTOR
		cp	11h		; Error	code : 0x11 = BREAK key	pressed
		ret	z		; Return if BREAK
		ld	a, 9		; Error	: sector not found
		ret
; ---------------------------------------------------------------------------

READ_SECTOR:				; CODE XREF: READ+7j
		push	iy
		pop	hl
		ld	de, 4Ch	; 'L'
		add	hl, de		; READ_SECTOR *buffer -> iy+4C
					; sector buffer	ptr= 0xff15, start saving bytes	in 0xff16
		ld	e, 83h ; '�'    ; # of bytes to read per sector is 0x82 (128bytes + 2 bytes checksum)
		jr	continue_read	; All done?
; ---------------------------------------------------------------------------

loc_5B42:				; CODE XREF: READ+2Ej
		jp	check_exit_key	; '-' pressed, exit
; ---------------------------------------------------------------------------

continue_read:				; CODE XREF: READ+19j
		in	a, (11h)	; port 11, read	a byte

loc_5B47:				; CODE XREF: READ+22j
		in	a, (c)		; polling
		jp	p, loc_5B47	; polling
		nop
		nop
		nop
		nop

sync_to_80:				; CODE XREF: READ+3Bj READ+145j
		ld	a, (68DFh)	; Check	BREAK first
					; Is '-' key pressed?
		and	4
		jr	z, loc_5B42	; '-' pressed, exit
		in	a, (11h)	; read a byte
		ld	b, a

sync80_poll:				; CODE XREF: READ+35j
		in	a, (c)		; polling
		jp	p, sync80_poll	; polling
		ld	a, b
		cp	80h ; '�'       ; GAP1, 7 bytes of 80h, 1 byte of 00h
		jp	nz, sync_to_80	; Check	BREAK first
					; Is '-' key pressed?

skip_all_80:				; CODE XREF: READ+C0j
		nop			; Gap2
					; 80h 5	bytes
					; 00h 1	bytes
					; C3h 1	bytes
					; 18h 1	bytes
					; E7h 1	bytes
					; FEh 1	bytes
		nop
		nop
		ld	a, 0
		ld	a, 0
		in	a, (11h)	; read a byte

skip80_poll_b0:				; CODE XREF: READ+49j
		in	a, (c)		; polling
		jp	p, skip80_poll_b0 ; polling
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)	; read a byte

skip80_poll_b1:				; CODE XREF: READ+59j
		in	a, (c)		; polling
		jp	p, skip80_poll_b1 ; polling
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)	; read a byte

skip80_poll_b2:				; CODE XREF: READ+69j
		in	a, (c)		; polling
		jp	p, skip80_poll_b2 ; polling
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)	; read a byte

skip80_poll_b3:				; CODE XREF: READ+79j
		in	a, (c)		; polling
		jp	p, skip80_poll_b3 ; polling
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)	; read a byte

skip80_poll_b4:				; CODE XREF: READ+89j
		in	a, (c)		; polling
		jp	p, skip80_poll_b4 ; polling
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)	; read a byte

skip80_poll_b5:				; CODE XREF: READ+99j
		in	a, (c)		; polling
		jp	p, skip80_poll_b5 ; polling
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)	; read a byte

skip80_poll_b6:				; CODE XREF: READ+A9j
		in	a, (c)		; polling
		jp	p, skip80_poll_b6 ; polling
		dec	hl		; 6 cycles
		inc	hl		; 6 cycles
		dec	hl		; 6 cycles
		inc	hl		; 6 cycles
		dec	hl		; 6 cycles
		inc	hl		; 6 cycles
		nop			; 4 cycles
		ld	a, 0		; 7 cycles
					;
					; Total	= 47 cycles between bits
		in	a, (11h)	; read a bit
		ld	b, a

skip80_poll_b7:				; CODE XREF: READ+BAj
		in	a, (c)		; polling
		jp	p, skip80_poll_b7 ; polling
		ld	a, b		; 4 cycles
		cp	80h ; '�'       ; 7 cycles
		jp	z, skip_all_80	; 10 cycles
					; loop if still	0x80,
					; Continue, assume this	byte is	0x00, next byte	is 0xC3
		nop			; 4 cycles
					; Timing fillers for first bit of next bytes
		nop			; 4 cycles
		nop			; 4 cycles
		ld	a, 0		; 7 cycles
		ld	a, 0		; 7 cycles
					;
					; Total	= 40 cycles between bytes
		in	a, (11h)	; Read 0xC3

rd_c3_poll_b0:				; CODE XREF: READ+CEj
		in	a, (c)
		jp	p, rd_c3_poll_b0
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_c3_poll_b1:				; CODE XREF: READ+DEj
		in	a, (c)
		jp	p, rd_c3_poll_b1
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_c3_poll_b2:				; CODE XREF: READ+EEj
		in	a, (c)
		jp	p, rd_c3_poll_b2
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_c3_poll_b3:				; CODE XREF: READ+FEj
		in	a, (c)
		jp	p, rd_c3_poll_b3
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_c3_poll_b4:				; CODE XREF: READ+10Ej
		in	a, (c)
		jp	p, rd_c3_poll_b4
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_c3_poll_b5:				; CODE XREF: READ+11Ej
		in	a, (c)
		jp	p, rd_c3_poll_b5
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_c3_poll_b6:				; CODE XREF: READ+12Ej
		in	a, (c)
		jp	p, rd_c3_poll_b6
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)
		ld	b, a

rd_c3_poll_b7:				; CODE XREF: READ+13Fj
		in	a, (c)
		jp	p, rd_c3_poll_b7
		ld	a, b
		cp	0C3h ; '�'      ; Gap2
					; 80h 5	bytes
					; 00h 1	bytes
					; C3h 1	bytes
					; 18h 1	bytes
					; E7h 1	bytes
					; FEh 1	bytes
		jp	nz, sync_to_80	; Check	BREAK first
					; Is '-' key pressed?
		nop
		nop
		nop
		ld	a, 0
		ld	a, 0
		in	a, (11h)	; Read 0x18

rd_18_poll_b0:				; CODE XREF: READ+153j
		in	a, (c)
		jp	p, rd_18_poll_b0
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_18_poll_b1:				; CODE XREF: READ+163j
		in	a, (c)
		jp	p, rd_18_poll_b1
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_18_poll_b2:				; CODE XREF: READ+173j
		in	a, (c)
		jp	p, rd_18_poll_b2
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_18_poll_b3:				; CODE XREF: READ+183j
		in	a, (c)
		jp	p, rd_18_poll_b3
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_18_poll_b4:				; CODE XREF: READ+193j
		in	a, (c)
		jp	p, rd_18_poll_b4
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_18_poll_b5:				; CODE XREF: READ+1A3j
		in	a, (c)
		jp	p, rd_18_poll_b5
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_18_poll_b6:				; CODE XREF: READ+1B3j
		in	a, (c)
		jp	p, rd_18_poll_b6
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)
		ld	b, a

rd_18_poll_b7:				; CODE XREF: READ+1C4j
		in	a, (c)
		jp	p, rd_18_poll_b7
		ld	a, b
		cp	18h		; Gap2
					; 80h 5	bytes
					; 00h 1	bytes
					; C3h 1	bytes
					; 18h 1	bytes
					; E7h 1	bytes
					; FEh 1	bytes
		jp	nz, READ	; SECTOR READ ROUTINE
					;
					; retry	10 times
		nop
		nop
		nop
		ld	a, 0
		ld	a, 0
		in	a, (11h)	; Read 0xE7

rd_E7_poll_b0:				; CODE XREF: READ+1D8j
		in	a, (c)
		jp	p, rd_E7_poll_b0
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_E7_poll_b1:				; CODE XREF: READ+1E8j
		in	a, (c)
		jp	p, rd_E7_poll_b1
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_E7_poll_b2:				; CODE XREF: READ+1F8j
		in	a, (c)
		jp	p, rd_E7_poll_b2
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_E7_poll_b3:				; CODE XREF: READ+208j
		in	a, (c)
		jp	p, rd_E7_poll_b3
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_E7_poll_b4:				; CODE XREF: READ+218j
		in	a, (c)
		jp	p, rd_E7_poll_b4
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_E7_poll_b5:				; CODE XREF: READ+228j
		in	a, (c)
		jp	p, rd_E7_poll_b5
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_E7_poll_b6:				; CODE XREF: READ+238j
		in	a, (c)
		jp	p, rd_E7_poll_b6
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)
		ld	b, a

rd_E7_poll_b7:				; CODE XREF: READ+249j
		in	a, (c)
		jp	p, rd_E7_poll_b7
		ld	a, b
		cp	0E7h ; '�'      ; Gap2
					; 80h 5	bytes
					; 00h 1	bytes
					; C3h 1	bytes
					; 18h 1	bytes
					; E7h 1	bytes
					; FEh 1	bytes
		jp	nz, READ	; SECTOR READ ROUTINE
					;
					; retry	10 times
		nop
		nop
		nop
		ld	a, 0
		ld	a, 0
		in	a, (11h)	; Read 0xFE

rd_FE_poll_b0:				; CODE XREF: READ+25Dj
		in	a, (c)
		jp	p, rd_FE_poll_b0
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_FE_poll_b1:				; CODE XREF: READ+26Dj
		in	a, (c)
		jp	p, rd_FE_poll_b1
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_FE_poll_b2:				; CODE XREF: READ+27Dj
		in	a, (c)
		jp	p, rd_FE_poll_b2
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_FE_poll_b3:				; CODE XREF: READ+28Dj
		in	a, (c)
		jp	p, rd_FE_poll_b3
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_FE_poll_b4:				; CODE XREF: READ+29Dj
		in	a, (c)
		jp	p, rd_FE_poll_b4
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_FE_poll_b5:				; CODE XREF: READ+2ADj
		in	a, (c)
		jp	p, rd_FE_poll_b5
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_FE_poll_b6:				; CODE XREF: READ+2BDj
		in	a, (c)
		jp	p, rd_FE_poll_b6
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)
		ld	b, a

rd_FE_poll_b7:				; CODE XREF: READ+2CEj
		in	a, (c)
		jp	p, rd_FE_poll_b7
		ld	a, b
		cp	0FEh ; '�'      ; Gap2
					; 80h 5	bytes
					; 00h 1	bytes
					; C3h 1	bytes
					; 18h 1	bytes
					; E7h 1	bytes
					; FEh 1	bytes
		jp	nz, READ	; SECTOR READ ROUTINE
					;
					; retry	10 times
		nop
		nop
		nop
		ld	a, 0
		ld	a, 0

sctr_rd_byte:				; CODE XREF: READ+35Ej
		in	a, (11h)	; read a byte, 8 times make a byte

rd_byte_poll_b0:			; CODE XREF: READ+2E2j
		in	a, (c)		; polling
		jp	p, rd_byte_poll_b0 ; polling
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_byte_poll_b1:			; CODE XREF: READ+2F2j
		in	a, (c)
		jp	p, rd_byte_poll_b1
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_byte_poll_b2:			; CODE XREF: READ+302j
		in	a, (c)
		jp	p, rd_byte_poll_b2
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_byte_poll_b3:			; CODE XREF: READ+312j
		in	a, (c)
		jp	p, rd_byte_poll_b3
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_byte_poll_b4:			; CODE XREF: READ+322j
		in	a, (c)
		jp	p, rd_byte_poll_b4
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_byte_poll_b5:			; CODE XREF: READ+332j
		in	a, (c)
		jp	p, rd_byte_poll_b5
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)

rd_byte_poll_b6:			; CODE XREF: READ+342j
		in	a, (c)
		jp	p, rd_byte_poll_b6
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		dec	hl
		inc	hl
		nop
		ld	a, 0
		in	a, (11h)
		ex	af, af'         ; 4 cycles
					; sector byte -> af'

rd_byte_poll_b7:			; CODE XREF: READ+353j
		in	a, (c)		; polling
		jp	p, rd_byte_poll_b7 ; polling
		inc	hl		; buffer++
					; buffer = 0xff16
		dec	e		; E=0x83h, 128+2bytes chk+1
		jr	z, rd_sector_done
		ex	af, af'
		ld	(hl), a		; sector byte -> (buffer)
		ld	a, r		; 4 cycles
					;
					; ???Timing filler???
		jp	sctr_rd_byte	; read a byte, 8 times make a byte
; ---------------------------------------------------------------------------

rd_sector_done:				; CODE XREF: READ+358j
		call	checksum
		inc	hl
		ld	a, (hl)
		cp	e
		jr	nz, loc_5E95
		inc	hl
		ld	a, (hl)
		cp	d
		jr	z, read_sector_done ; no error

loc_5E95:				; CODE XREF: READ+367j
		ld	a, (iy+13h)
		dec	a
		ld	(iy+13h), a
		jp	nz, loc_5B2B	; Sync to requested SECTOR/TRACK using IDAM
		ld	a, 0Ah		; checksum error
		ret
; ---------------------------------------------------------------------------

read_sector_done:			; CODE XREF: READ+36Cj
		xor	a		; no error
		ret
; ---------------------------------------------------------------------------

check_exit_key:				; CODE XREF: IDAM:goto_exit_keyj
					; READ:loc_5B42j ...
		ld	a, (68DFh)	; de-flickering, wait till '-' key is released, exit
		and	4
		jr	z, check_exit_key ; de-flickering, wait	till '-' key is released, exit
		push	bc
		ld	bc, 14h		; delay	20ms
		call	DLY		; delay	ms
		pop	bc
		ld	a, (68DFh)
		and	4
		jr	z, check_exit_key ; de-flickering, wait	till '-' key is released, exit
		ld	a, 11h
		or	a
		ret
; End of function READ


; =============== S U B	R O U T	I N E =======================================

; delay	ms

DLY:					; CODE XREF: DOSROM:4038j DOSROM:43B9p ...
		push	bc
		ld	bc, 89h	; '�'

loc_5EC2:				; CODE XREF: DLY+7j
		dec	bc
		ld	a, b
		or	c
		jr	nz, loc_5EC2
		pop	bc
		dec	bc
		ld	a, b
		or	c
		jr	nz, DLY		; delay	ms
		ret
; End of function DLY


; =============== S U B	R O U T	I N E =======================================


STPIN:					; CODE XREF: DOSROM:403Bj sub_4CBB+38p ...
		ld	a, (iy+14h)
		add	a, b		; IY+14h - Current Track Number
		cp	28h ; '('       ; Is current track at 40?
		jr	c, loc_5ED8
		ld	a, 27h ; '''

loc_5ED8:				; CODE XREF: STPIN+6j
		ld	(iy+14h), a
		sla	b

loc_5EDD:				; CODE XREF: STPIN+30j
		ld	a, (iy+38h)	; IY+38h - Stepper Phase
		ld	c, a
		rlca
		push	af
		ld	(iy+38h), a
		or	c
		call	copy_step_latch
		push	bc
		ld	bc, 2
		call	DLY		; delay	ms
		pop	bc
		pop	af
		call	copy_step_latch
		push	bc
		ld	bc, 0Eh
		call	DLY		; delay	ms
		pop	bc
		djnz	loc_5EDD	; IY+38h - Stepper Phase
		ret
; End of function STPIN


; =============== S U B	R O U T	I N E =======================================


STPOUT:					; CODE XREF: DOSROM:403Ej DOSROM:40E3p ...
		ld	a, (iy+14h)
		sub	b
		jp	p, loc_5F09
		xor	a

loc_5F09:				; CODE XREF: STPOUT+4j
		ld	(iy+14h), a
		sla	b

loc_5F0E:				; CODE XREF: STPOUT+2Ej
		ld	a, (iy+38h)
		ld	c, a
		rrca
		push	af
		ld	(iy+38h), a
		or	c
		call	copy_step_latch
		push	bc
		ld	bc, 2
		call	DLY		; delay	ms
		pop	bc
		pop	af
		call	copy_step_latch
		push	bc
		ld	bc, 0Eh
		call	DLY		; delay	ms
		pop	bc
		djnz	loc_5F0E
		ret
; End of function STPOUT


; =============== S U B	R O U T	I N E =======================================


copy_step_latch:			; CODE XREF: STPIN+19p	STPIN+25p ...
		and	0Fh
		ld	c, a
		ld	a, 0F0h	; '�'
		and	(iy+33h)	; IY+33h - Copy	of Latch
		or	c
		ld	(iy+33h), a
		out	(10h), a
		ret
; End of function copy_step_latch


; =============== S U B	R O U T	I N E =======================================


POWON:					; CODE XREF: DOSROM:4008j DOSROM:40DEp ...
		ld	a, (iy+38h)
		and	0Fh
		or	(iy+33h)
		or	(iy+0Bh)
		ld	(iy+33h), a
		out	(10h), a
		ret
; End of function POWON


; =============== S U B	R O U T	I N E =======================================


PWOFF:					; CODE XREF: DOSROM:400Bj DOSROM:40E6p ...
		ld	a, (iy+33h)
		or	40h ; '@'
		and	60h ; '`'
		ld	(iy+33h), a
		out	(10h), a
		ret
; End of function PWOFF

; ---------------------------------------------------------------------------
; end of 'DOSROM'

; =============== S U B	R O U T	I N E =======================================
; CUSTOM_ROM: Display a 16- or 8-bit number in hex.
DispHLHex:
		ld  c,h
   		call  OutHex8
		ld  c,l
OutHex8:
; Input: C
		ld  a,c
		rra
		rra
		rra
		rra
		call  Conv
		ld  a,c
Conv:
		and  $0F
		add  a,$90
		daa
		adc  a,$40
		daa
		call 033Ah  ;display char in A
		ret

aStartAddr:	.text "START: "
		.db 0
aEndAddr:	.text "H, END: "
		.db 0
aFinishPattern:	.text "H"
		.db 0Dh, 0
; =============== S U B	R O U T	I N E =======================================
; Custom RESET Command

cust_cmd_reset:
		ld	hl, aAreYouSure ; "\rARE YOU SURE(1/2)? "
		call	28A7h
		call	usr_input_keys	; Read one character from user input:  '1' or '2'
		ld	a, c
		call	32Ah			; Output char to screen
		cp '1'
		jr nz, no_reset
		jp 0000h
; End of function cust_cmd_status
no_reset:
		ret
aAreYouSure:
        .db 0Dh
		.text "ARE YOU SURE(1=Y/2=N)? "
		.db 0
; CUSTOM_ROM: END
		.end