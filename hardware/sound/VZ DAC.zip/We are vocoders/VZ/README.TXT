;	DMITRY MILK's We Are Vocoders.
;
;		This uses Port 14 which drives the printer interface where a DAC connected to an amplied speaker is exepected.
;
;
