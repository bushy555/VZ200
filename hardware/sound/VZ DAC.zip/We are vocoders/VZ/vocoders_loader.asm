;==============================================================================
; WE ARE VOCODERS - VZ200/VZ300 loader.   Loads and starts at $7B00.
;
; Stage 1 (at $7B00) copies the rest of the file to high RAM and jumps there.
; Stage 2 unpacks the five blocks to their final addresses, checks each one against a
; build-time checksum (halts with a report on screen if one is wrong), undeltas the waves
; and samples and hands over to the run-time code generator and the engine.
;
; This is the structure that was proven on real hardware (Ben Venn SD loader).  The menu /
; key code below is NOT used by this build (kept only so the code layout is exactly the
; hardware-tested one; build with -DAUTO=1 -DDELAY=0 -DPROD=1).
; NOTE: video RAM $7000-$7FE5 holds the SONG DATA - nothing may be stored there as a marker.
;==============================================================================
	device	noslot64k
	include	'codegen/main_symbols.asm'
	include	'codegen/sums.inc'

RES		equ	0FF00h			; status bytes at RES+0..4, sums at RES+16+2*i

	org	7B00h
loader_start:
	di
	ld	sp, loader_start
	ld	hl, stage2_src
	ld	de, STAGE2_DEST
	ld	bc, stage2_len
	ldir
	jp	STAGE2_DEST

stage2_src:
	phase	STAGE2_DEST
stage2_start:
	ld	sp, stage2_start
	xor	a
	ld	(6800h), a
	ld	hl, RES
	ld	de, RES + 1
	ld	bc, 63
	ld	(hl), a
	ldir

	IFDEF	AUTO
	IF	DELAY > 0
	ld	d, DELAY			; delay ~0.48 s per unit
dl0:	ld	bc, 0
dl1:	dec	bc
	ld	a, b
	or	c
	jr	nz, dl1
	dec	d
	jr	nz, dl0
	ENDIF
	xor	a
au1:	push	af
	call	run_one
	pop	af
	IFNDEF	PROD
	push	af
	ld	e, a
	ld	d, 0
	ld	hl, mk
	add	hl, de
	ld	a, (hl)
	ld	hl, 71E0h
	add	hl, de
	ld	(hl), a				; N W S R M markers (debug builds only)
	pop	af
	ENDIF
	inc	a
	cp	5
	jr	nz, au1
	IFDEF	PROD
	ld	hl, RES				; every block must have checksummed OK, else stop and show why
	ld	b, 5
ck1:	ld	a, (hl)
	cp	1
	jr	nz, fail
	inc	hl
	djnz	ck1
	ENDIF
	call	do_undelta
	IFNDEF	PROD
	ld	a, 04h
	ld	(71E5h), a			; 'D'
	ENDIF
	jp	go
fail:	call	draw				; lists the five blocks with OK / BAD and their sums
	ld	hl, 7040h			; blank the (unused) menu rows
	ld	de, 7041h
	ld	bc, 95
	ld	(hl), 20h
	ldir
	ld	de, 7000h
	ld	hl, s_err
	call	print
	jr	$
s_err:	db	"LOAD ERROR - RELOAD THE FILE",0
mk:	db	0Eh, 17h, 13h, 12h, 0Dh
	ENDIF

menu:	call	draw
wait:	call	getkey
	or	a
	jr	z, wait
	cp	6
	jr	z, all
	cp	7
	jr	z, undo
	cp	8
	jp	z, go
	dec	a
	call	run_one
	jr	menu
all:	xor	a
all1:	push	af
	call	run_one
	pop	af
	inc	a
	cp	5
	jr	nz, all1
	jr	menu

; key 7: undelta waves + samples (as the real loader does); no redraw, so the markers stay visible
undo:	ld	a, 31h
	ld	(71F0h), a			; '1' = started
	call	do_undelta
	ld	a, 32h
	ld	(71F1h), a			; '2' = finished
	jp	wait

do_undelta:
	ld	hl, block_waves
	ld	b, (endblock_waves - block_waves) / 256
	call	undelta
	ld	hl, block_samples
	ld	b, (endblock_samples - block_samples) / 256
	jp	undelta

; key 8: hand over to the run-time code generator and the engine, exactly like the real loader
go:
	IFNDEF	PROD
	ld	a, 07h
	ld	(71F2h), a			; 'G'
	ENDIF
	jp	runtime_codegen

undelta:
	sub	a
ud1:	add	a, (hl)
	ld	(hl), a
	inc	l
	jr	nz, ud1
	inc	h
	djnz	ud1
	ret

; ---- run block A (0-4) ------------------------------------------------------------------------
run_one:
	IFNDEF	PROD
	push	af
	ld	a, 12h			; 'R' on row 14: shows "running" unless the block overwrites video RAM
	ld	(7000h + 14*32), a
	pop	af
	ENDIF
	push	af			; (idx)
	ld	l, a
	ld	h, 0
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	de, tbl
	add	hl, de
	push	hl			; (entry, idx)
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	inc	hl
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ex	de, hl			; HL = packed
	ld	d, b
	ld	e, c			; DE = dest
	call	dzx0_standard
	pop	hl			; entry
	push	hl
	inc	hl
	inc	hl
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	inc	hl
	ld	c, (hl)
	inc	hl
	ld	b, (hl)			; BC = length
	ex	de, hl			; HL = dest
	ld	de, 0			; DE = 16-bit sum
cs:	ld	a, (hl)
	add	a, e
	ld	e, a
	jr	nc, cs1
	inc	d
cs1:	inc	hl
	dec	bc
	ld	a, b
	or	c
	jr	nz, cs
	pop	hl			; entry
	ld	bc, 6
	add	hl, bc
	ld	c, (hl)
	inc	hl
	ld	b, (hl)			; BC = expected
	pop	af			; idx
	push	af
	ld	l, a
	ld	h, 0FFh			; HL = RES + idx
	ld	a, d
	cp	b
	jr	nz, bad
	ld	a, e
	cp	c
	jr	nz, bad
	ld	(hl), 1
	jr	stsum
bad:	ld	(hl), 2
stsum:	pop	af
	add	a, a
	add	a, 16
	ld	l, a
	ld	h, 0FFh
	ld	(hl), e
	inc	hl
	ld	(hl), d
	ret

; ---- screen -----------------------------------------------------------------------------------
draw:	ld	hl, 7000h
	ld	de, 7001h
	ld	bc, 511
	ld	(hl), 20h
	ldir
	ld	de, 7000h
	ld	hl, s_title
	call	print
	ld	de, 7040h
	ld	hl, s_k1
	call	print
	ld	de, 7060h
	ld	hl, s_k2
	call	print
	ld	de, 7080h
	ld	hl, s_k3
	call	print
	ld	b, 0
dr1:	push	bc
	ld	a, b			; row = 7000h + (8+i)*32
	add	a, 8
	ld	l, a
	ld	h, 0
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	de, 7000h
	add	hl, de
	ex	de, hl			; DE = screen pos
	ld	a, b
	add	a, a
	add	a, a
	add	a, a
	add	a, a			; name table: 16 bytes each
	ld	l, a
	ld	h, 0
	ld	bc, names
	add	hl, bc
	call	print
	pop	bc
	push	bc
	ld	l, b
	ld	h, 0FFh
	ld	a, (hl)
	ld	hl, s_notrun
	cp	1
	jr	nz, dr2
	ld	hl, s_ok
	jr	dr3
dr2:	cp	2
	jr	nz, dr3
	ld	hl, s_bad
dr3:	call	print
	pop	bc
	push	bc
	ld	a, (RES + 0)		; keep register use simple: sum read below
	ld	a, b
	add	a, a
	add	a, 16
	ld	l, a
	ld	h, 0FFh
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	ld	a, l
	or	h
	jr	z, dr4
	ld	a, 20h
	ld	(de), a
	inc	de
	call	hex16
dr4:	pop	bc
	inc	b
	ld	a, b
	cp	5
	jr	nz, dr1
	ret

; ---- keys: 1-5 on row A3 ($68F7), 6 on row A5 ($68DF); returns 1-6 or 0; waits for release ---
getkey:	call	scan
	or	a
	ret	z
	push	af
gk1:	call	scan
	or	a
	jr	nz, gk1
	pop	af
	ret
scan:	ld	a, (68F7h)
	cpl
	and	3Eh
	jr	z, sc6
	bit	4, a
	ld	a, 1
	ret	nz
	ld	a, (68F7h)
	cpl
	bit	2, a
	ld	a, 2
	ret	nz
	ld	a, (68F7h)
	cpl
	bit	3, a
	ld	a, 3
	ret	nz
	ld	a, (68F7h)
	cpl
	bit	5, a
	ld	a, 4
	ret	nz
	ld	a, 5
	ret
sc6:	ld	a, (68DFh)
	cpl
	and	29h			; '6' = D0, '8' = D3, '7' = D5
	ret	z
	bit	0, a
	ld	a, 6
	ret	nz
	ld	a, (68DFh)
	cpl
	bit	5, a
	ld	a, 7
	ret	nz
	ld	a, 8
	ret

hex16:	ld	a, h
	call	hex8
	ld	a, l
hex8:	push	af
	rrca
	rrca
	rrca
	rrca
	call	nib
	pop	af
nib:	and	0Fh
	cp	10
	jr	c, nib_d
	sub	9
	jr	nib_o
nib_d:	add	a, 30h
nib_o:	ld	(de), a
	inc	de
	ret

print:	ld	a, (hl)
	or	a
	ret	z
	and	3Fh
	ld	(de), a
	inc	hl
	inc	de
	jr	print

s_title:	db	"UNPACK TEST (REAL-HW)",0
s_k1:		db	"1 NOTES  2 WAVES  3 SAMPLES",0
s_k2:		db	"4 RTCG   5 MAIN",0
s_k3:		db	"6 ALL  7 UNDELTA  8 GO (CODEGEN)",0
s_ok:		db	" OK",0
s_bad:		db	" BAD",0
s_notrun:	db	" --",0
names:		db	"NOTES  ",0,0,0,0,0,0,0,0,0
		db	"WAVES  ",0,0,0,0,0,0,0,0,0
		db	"SAMPLES",0,0,0,0,0,0,0,0,0
		db	"RTCG   ",0,0,0,0,0,0,0,0,0
		db	"MAIN   ",0,0,0,0,0,0,0,0,0
tbl:		dw	notes_packed,   block_notes,   L_NOTES,   S_NOTES
		dw	waves_packed,   block_waves,   L_WAVES,   S_WAVES
		dw	samples_packed, block_samples, L_SAMPLES, S_SAMPLES
		dw	rtcg_packed,    block_rtcg,    L_RTCG,    S_RTCG
		dw	main_packed,    block_main,    L_MAIN,    S_MAIN

	include	'compression/dzx0_standard.asm'
notes_packed:	incbin	'codegen/notes.zx0'
waves_packed:	incbin	'codegen/waves_delta.zx0'
samples_packed:	incbin	'codegen/samples_delta.zx0'
rtcg_packed:	incbin	'codegen/rtcg.zx0'
main_packed:	incbin	'codegen/main.zx0'
stage2_end:
	dephase
stage2_len	equ	stage2_end - stage2_start
