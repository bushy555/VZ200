	device	noslot64k			; flat 64K, VZ200/VZ300
	include	'song_data/core_defs.asm'
	include 'song_data/engine_defs.asm'

;============== MEMORY MAP (VZ200/VZ300, 32K expansion) ===========================
;  $7000-$7FE5  song note stream  (video RAM + user RAM; read only at note boundaries)
;  $7FE6-$7FFB  engine vars       (pop-ed through SP)
;  $8000-$B8FF  57 wave tables    (256 bytes each, 256-aligned)
;  $B900-$C1FF  snare (5 pages) + kick (4 pages); kick's 5th page IS the first 'zeros' page
;  $C200-$C6FF  'zeros' silence / RTCG scratch + RTCG code (zero-filled after codegen)
;  $C700-....   engine code, address table, frames
;  then         switchtables (256-aligned) + generated variants (run-time codegen)
;=======================================================================

	org	7000h
block_notes:
	include 'song_data/notedata.asm'
endblock_notes:
block_vars:
	include 'core/vars.asm'
endblock_vars:

	org	8000h
;============== ALIGNED DATA =======================================
block_waves:
	include 'song_data/waves.asm'
endblock_waves:

block_samples:
sample_snare	incbin	'samples/snare.dat'
sample_kick	incbin	'samples/kick.dat', 0, 1024	; 5th kick page (|v|<=1) is the zeros page that follows
endblock_samples:

	align	100h
zeros:
rtcg_buffer	defs	RTCG_BUFFER_SIZE

block_rtcg:
runtime_codegen	include	'core/runtime_codegen.asm'
	jp	init_engine
	include	'core/variants_template.asm'
	include 'song_data/rtcg_data.asm'
endblock_rtcg:

	org	zeros + QFRAME_LEN * 100h
zeros_end:

;=======================================================================
block_main:
	include 'song_data/addrtbl.asm'

;============== NON-ALIGNED DATA =======================================

nextframe:
	ex      af, af'		;= 4, save previous sample value
frmptr	equ $ + 1
	ld	sp, qframe0	;= 10
	pop	hl		;= 10
	sub	a		;= 4
	out     (DACPORT), a	;= 11, start fake pulse
	
	or	l		;= 4
	jr z,	nextnote	;= 5 / 12

memfilladdr equ $ + 1
	ld	hl, 5800h	;= 10
	nop			;= 4, ZX screen-attribute fill disabled on VZ (no writes)
memfillvalue equ $ + 1
	cp	0			;= 7, operand still patched by note code
memfillstep:
	nop			;= 4
	ld	(memfilladdr), hl	;= 16
	ld	h, a		;= 4
	inc     b		;= 4
	ld      c, FRAMEPAD	;= 7
	dec	sp		;= 6
nextframe_load:
	ld	a, 0FFh		;= 7
	out     (DACPORT), a	;= 11, end fake pulse
	
frmdst1	equ $ + 1
	ld	(wave1), hl	;= 16
	pop	hl		;= 10
frmdst2	equ $ + 1
	ld	(wave2+1), hl	;= 16
frmdst3	equ $ + 1
	ld	(wave3), hl	;= 16
	ld	(frmptr), sp	;= 20
	ex      af, af'		;= 4, restore previous sample value
iloop:
	include 'core/iloop.asm'
frmdst4	equ	fakevar
frmdst5	equ	fakevar

nextnote:
notesptr equ $ + 1
	ld	sp, section_main	;= 10
nextnote_inner:			; ----------- jump to this point requires a==0 --------
	pop	hl		;= 10
	dec	sp		;= 6
	or	l		;= 4
	ld	a, 0FFh		;= 7
	out     (DACPORT), a	;= 11, end fake pulse
	
	jp p,	storfrmseq	;= 10
	ld	h, addrtbl/256	;= 7
	ld	a, (hl)		;= 7
	inc	h		;= 4
	ld	h, (hl)		;= 7
	ld	l, a		;= 4
	jp	(hl)		;= 4

noteexit:
	pop	hl		;= 10
	dec	sp		;= 6
	
storfrmseq:
	ld	h, addrtbl/256	;= 7
	ld	a, (hl)		;= 7
	inc	h		;= 4
	ld	h, (hl)		;= 7
	ld	l, a		;= 4
	ld	(nwfrmptr), hl	;= 16
	ld	(notesptr), sp	;= 20
sequencer:
seqdst	equ	fakevar
seqptr  equ $ + 1
	ld	sp, seq_default	;= 10
	sub	a		;= 4
	out     (DACPORT), a	;= 11, start fake pulse
	
	pop	bc		;= 10
	ld      (seqptr), sp	;= 20
nwfrmptr equ $ + 1
	ld	sp, qframe0	;= 10
	dec	sp		;= 6
	pop	hl		;= 10
	jp	nextframe_load	;= 10
	
init_engine:
	ld	sp, zeros_end
	ld	hl, 0
	ld	c, ( zeros_end - zeros ) / 100h
fill_zeros1:
	ld	b, 128
fill_zeros2:
	push	hl
	djnz	fill_zeros2
	dec	c
	jr nz,	fill_zeros1
	
	pop	bc		; init voice 4 phase
	pop	de		; init voice 5 phase
	exx
	pop	de		; init voice 1 phase
	pop	ix		; init voice 2 phase
	pop	iy		; init voice 3 phase
	
	ld      bc, zeros	; init drum pointer and loop counter
	
	ld	sp, frmexit + 2
	ld      hl, nextframe
	push	hl		; init frmexit
	ld	hl, zeros
	push	hl		; init wave1
	push	hl		; init wave5
	push	hl		; init wave4
	push	hl		; init wave3
	push	hl		; init wave2
	ld	hl, 100h
	push	hl		; init freq5
	push	hl		; init freq4
	push	hl		; init freq3
	push	hl		; init freq2
	push	hl		; init freq1
	
	ld	hl, seq_default
	ld	(seqptr), hl
	
	ld      hl, section_main
	ld      (notesptr), hl
	
	sub     a
	ex      af, af'
	sub     a
	
	jp      nextnote
	
	include 'song_data/notecode.asm'
exit:
	jp	0

	include 'song_data/sequences.asm'
	include 'song_data/frames.asm'
;============== VARS ===============================================
fakevar	dw	0
callsave1 dw	0
callsave2 dw	0
callsave3 dw	0
endblock_main:


;============== GENERATED AT RUN TIME (run-time codegen) ===============
	align	100h
switchtables	defs	SWITCHTABLES_SIZE
variants	defs	VARIANTS_SIZE
end_of_ram_image:

	savebin	'codegen/block_notes.dat', block_notes, endblock_notes - block_notes
	savebin	'codegen/block_vars.dat', block_vars, endblock_vars - block_vars
	savebin	'codegen/block_rtcg.dat', block_rtcg, endblock_rtcg - block_rtcg
	savebin	'codegen/block_waves.dat', block_waves, endblock_waves - block_waves
	savebin	'codegen/block_samples.dat', block_samples, endblock_samples - block_samples
	savebin	'codegen/block_main.dat', block_main, endblock_main - block_main
