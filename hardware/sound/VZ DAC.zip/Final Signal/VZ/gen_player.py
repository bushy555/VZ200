import pickle, subprocess, sys, os
sys.path.insert(0,'.')
from zdis2 import dis
orig=open('/home/claude/code.bin','rb').read()
BASE=0x7000
img=bytearray(orig)
# ---- patches -------------------------------------------------------
n_out=0
for i in range(len(img)-1):
    if img[i]==0xD3 and img[i+1]==0xFE:
        img[i+1]=0x0E; n_out+=1
assert n_out==384
a=0xFAB7-BASE
assert bytes(orig[a:a+6])==bytes.fromhex('3e7fdbfee601')
img[a:a+6]=bytes.fromhex('3aef68cb6700')       # LD A,($68EF) / BIT 4,A / NOP  (25 T, same as original)
a=0xFAC1-BASE
assert bytes(orig[a-1:a+2])==bytes.fromhex('c37b70')
img[a:a+2]=b'\x00\x00'                         # JP $707B -> JP $0000 (ROM cold start)
import pickle as _pk
_aw=_pk.load(open('attrwords.pkl','rb'))
for sp,w in _aw.items():
    assert 0x5800<=w<0x5B00 and img[sp-BASE]==(w&255) and img[sp-BASE+1]==(w>>8)
    img[sp-BASE+1]=(w>>8)&0x3F                 # $58xx-$5Axx (ZX attributes) -> $18xx-$1Axx (ROM)
open('player_patched.bin','wb').write(img)

vis,outs=pickle.load(open('full.pkl','rb'))
vis=set(v for v in vis if BASE<=v<BASE+len(img))
# instruction starts in patched image
ins={}
for pc in sorted(vis):
    n,t,k,tg=dis(img,pc,BASE)
    ins[pc]=(n,t,k,tg)
# overlap sanity: drop instructions overlapping an earlier one
cov=set(); good={}
for pc in sorted(ins):
    n=ins[pc][0]
    if any((pc+j) in cov for j in range(n)): continue
    good[pc]=ins[pc]
    for j in range(n): cov.add(pc+j)
ins=good
names={0x7000:'INIT',0x707B:'EXIT_ZX',0xFAA5:'DISPATCH',0xFAB7:'KEYCHECK',0xFAC3:'RELOAD_A',0xFAD1:'RELOAD_B',0xFB04:'SAVED_SP'}
targets=set()
for pc,(n,t,k,tg) in ins.items():
    if tg is not None and tg in ins and k in('jmp','cond','call'): targets.add(tg)
def lab(a): return names.get(a,'L_%04X'%a)
fallback=set()
def render(pc):
    n,t,k,tg=ins[pc]
    if pc in fallback or t.startswith('DB') or 'OUT (C),0' in t or 'IN F,(C)' in t:
        return 'db '+','.join('$%02X'%img[pc-BASE+j] for j in range(n))+'   ; '+t
    if tg is not None and tg in ins and k in('jmp','cond','call'):
        t=t.replace('$%04X'%tg,lab(tg))
    import re
    t=t.lower()
    t=re.sub(r'l_([0-9a-f]{4})',lambda m:'L_'+m.group(1).upper(),t)
    for nm in names.values(): t=t.replace(nm.lower(),nm)
    return t
def build():
    out=[]
    out.append('; ====================================================================')
    out.append('; FINAL SIGNAL player - VZ200 version (1-bit demo by Dmitry_Milk, CC 2025)')
    out.append('; Disassembly of the ZX Spectrum code block "signal" ($7000, 35840 bytes)')
    out.append('; with the VZ200 changes applied:')
    out.append(';   * all 384 OUT ($FE),A  ->  OUT (14),A   (8-bit resistor DAC, printer port)')
    out.append(';   * key test:  LD A,$7F / IN A,($FE) / AND 1  ->  LD A,($68EF) / BIT 4,A / NOP')
    out.append(';       (VZ keyboard row $68EF, SPACE = bit 4, active low; still 25 T-states)')
    out.append(';   * the demo animates ZX screen attributes ($5821-$5A3F) with LD (HL),n at $FAFC;')
    out.append(';       on the VZ that range is cartridge space, so the 33 pointer words in the song')
    out.append(';       stream that feed the handlers at $F9C1/$F9D0/$F9DF/$F9EE/$FA23 were changed')
    out.append(';       from $58xx-$5Axx to $18xx-$1Axx: the writes now land harmlessly in ROM')
    out.append(';   * exit path: JP EXIT_ZX -> JP $0000 (ROM cold start; the system RAM at')
    out.append(';       $7800-$7AE8 is overwritten by the image, so BASIC cannot be re-entered)')
    out.append('; Everything is a plain assemble-and-compare listing: code that was reached while')
    out.append('; running the demo is shown as instructions, all other bytes (song data, tables,')
    out.append('; the push/pop write sleds at $D000-$D5FF) are DB lines.  Assembles with pasmo to')
    out.append('; a file identical to the patched image (36 KB, $7000-$FBFF).')
    out.append('; Memory use: $7000-$FBFF image + $FC00-$FFFF work buffer (cleared by INIT).')
    out.append('; ====================================================================')
    out.append('        org $7000')
    pc=BASE; end=BASE+len(img)
    while pc<end:
        if pc in targets or pc in names:
            out.append('%s:'%lab(pc))
        if pc in ins:
            out.append('        '+render(pc)+'   ; %04X'%pc if False else '        '+render(pc))
            pc+=ins[pc][0]
        else:
            # data run up to 16 bytes, stop at next code/label
            j=pc; row=[]
            while j<end and j not in ins and (j==pc or (j not in targets and j not in names)) and len(row)<16:
                row.append(img[j-BASE]); j+=1
            out.append('        db '+','.join('$%02X'%b for b in row))
            pc=j
    return '\n'.join(out)+'\n'
for it in range(40):
    src=build()
    open('finalsig_player.asm','w').write(src)
    r=subprocess.run(['pasmo','--bin','finalsig_player.asm','finalsig_player.bin'],capture_output=True,text=True)
    if r.returncode!=0:
        print(r.stdout[-300:],r.stderr[-300:]); 
        import re
        m=re.search(r'line (\d+)',r.stdout+r.stderr)
        ln=int(m.group(1)); 
        # find instruction at that source line
        lines=src.split('\n'); 
        # map line -> pc by re-walking
        pcs=[];pc=BASE
        # re-walk generation
        cnt=0
        raise SystemExit('assembler error line %d: %s'%(ln,lines[ln-1]))
    b=open('finalsig_player.bin','rb').read()
    if b==bytes(img): print('IDENTICAL after',it,'fallbacks; size',len(b)); break
    d=next(i for i in range(min(len(b),len(img))) if b[i]!=img[i]) if b[:len(img)]!=bytes(img) else None
    if d is None: print('length mismatch',len(b),len(img)); break
    adr=BASE+d
    st=max(p for p in ins if p<=adr)
    print('diff at %04X in instr %04X %s'%(adr,st,ins[st][1])); fallback.add(st)
print('lines',src.count('\n'),'fallbacks',len(fallback))
