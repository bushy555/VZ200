import subprocess, struct, sys
img=open('player_patched.bin','rb').read()
# ---------- LZ4-style block compressor (greedy + hash chains) ----------
def lz4(data,depth=256):
    n=len(data); head={}; prev=[-1]*n; out=bytearray(); i=0; lit0=0
    def emit(lit_end,mlen,off):
        L=lit_end-lit0; tok=(min(L,15)<<4)|(min(mlen-4,15) if mlen else 0)
        out.append(tok)
        if L>=15:
            r=L-15
            while r>=255: out.append(255); r-=255
            out.append(r)
        out.extend(data[lit0:lit_end])
        if mlen:
            out.extend(struct.pack('<H',off))
            if mlen-4>=15:
                r=mlen-4-15
                while r>=255: out.append(255); r-=255
                out.append(r)
    def ins(p):
        if p+4<=n:
            k=data[p:p+4]; prev[p]=head.get(k,-1); head[k]=p
    while i<n:
        best=0;bo=0
        if i+4<=n:
            c=head.get(data[i:i+4],-1); d=0
            while c>=0 and d<depth and i-c<=65535:
                l=0
                while i+l<n and data[c+l]==data[i+l]: l+=1
                if l>best: best,bo=l,i-c
                c=prev[c]; d+=1
        if best>=4:
            emit(i,best,bo)
            for p in range(i,i+best): ins(p)
            i+=best; lit0=i
        else:
            ins(i); i+=1
    emit(n,0,0)
    return bytes(out)
def unlz4(c,size):
    o=bytearray(); i=0
    while i<len(c):
        t=c[i]; i+=1; L=t>>4
        if L==15:
            while True:
                b=c[i]; i+=1; L+=b
                if b!=255: break
        o+=c[i:i+L]; i+=L
        if i>=len(c): break
        off=c[i]|c[i+1]<<8; i+=2; M=t&15
        if M==15:
            while True:
                b=c[i]; i+=1; M+=b
                if b!=255: break
        M+=4
        for _ in range(M): o.append(o[-off])
    return bytes(o)
lz=lz4(img)
assert unlz4(lz,len(img))==img
open('finalsig.lz','wb').write(lz)
print('image',len(img),'-> lz',len(lz))

HDR = '''; ====================================================================
; FINAL SIGNAL - VZ200 loader / unpacker  (%(vzname)s.VZ, loads at $7B00)  [%(desc)s]
;
; The ZX demo image needs $7000-$FFFF (36 KB incl. 1 KB work buffer), which
; is all the RAM a VZ200 + 32K has, so the file stores it LZ4-packed:
;   1. stub at $7B00 (interrupts off) moves [packed data + unpacker] to the very
;      top of RAM (LDDR, so the packed data ends at $FFFF)
;   2. the unpacker (position independent, SP=0 -> stack in the top 16 bytes)
;      expands it forwards to $7000 (in place; packed data stays ahead of
;      the write pointer)
;   3. short delay, then jump to INIT at $7000
; Player source: finalsig_player.asm  (org $7000, 35840 bytes)
; ====================================================================
'''
MACROS = '''
beep    macro
        local l1,l2,l3
        ld de,300
l1:     ld a,$01
        ld ($6800),a
        ld b,90
l2:     djnz l2
        ld a,$20
        ld ($6800),a
        ld b,90
l3:     djnz l3
        dec de
        ld a,d
        or e
        jr nz,l1
        xor a
        ld ($6800),a
        endm
gap     macro
        local g
        ld bc,0
g:      dec bc
        ld a,b
        or c
        jr nz,g
        endm
'''
PART1 = '''        org $7B00
body_len equ pad_end-lz_data
dec_len  equ dec_end-dec_code
dec_addr equ $FFFF-15-dec_len
lz_addr  equ dec_addr-lz_len
lz_len   equ %d

start:  di
'''
PART2 = '''        ld hl,pad_end-1
        ld de,$FFFF
        ld bc,body_len
        lddr
        jp dec_addr

lz_data:
        incbin "finalsig.lz"
dec_code:
        ld sp,0
        ld hl,lz_addr
        ld de,$7000
nexttok:ld a,(hl)
        inc hl
        push af                 ; keep token
        rrca
        rrca
        rrca
        rrca
        and 15
        ld c,a
        ld b,0
        cp 15
        jr nz,lit
lext:   ld a,(hl)
        inc hl
        push af
        add a,c
        ld c,a
        jr nc,lx1
        inc b
lx1:    pop af
        inc a
        jr z,lext               ; byte was 255 -> more
lit:    ld a,b
        or c
        jr z,nolit
        ldir
nolit:  ld a,l
        cp dec_addr & 255
        jr nz,more
        ld a,h
        cp dec_addr / 256
        jr z,done               ; last sequence has literals only
more:   pop af                  ; token
        and 15
        add a,4
        exx
        ld c,a                  ; BC' = match length (so far)
        ld b,0
        exx
        ld c,(hl)
        inc hl
        ld b,(hl)               ; BC = offset
        inc hl
        cp 19
        jr nz,mcopy
mext:   ld a,(hl)
        inc hl
        exx
        ld e,a
        add a,c
        ld c,a
        jr nc,mx1
        inc b
mx1:    ld a,e
        exx
        inc a
        jr z,mext
mcopy:  push hl                 ; source pointer
        ld h,d
        ld l,e
        and a
        sbc hl,bc               ; HL = dest - offset
        exx
        push bc
        exx
        pop bc                  ; BC = match length
        ldir
        pop hl
        jr nexttok
done:
'''
PART3 = '''        ld e,4                  ; ~2 s settle delay before starting the player
        ld bc,0
dly:    dec bc
        ld a,b
        or c
        jr nz,dly
        dec e
        jr nz,dly
'''
PART4 = '''        jp $7000
dec_end:
pad:    ds 16
pad_end:
'''
def make_asm(v):
    a = HDR % dict(vzname=v['name'], desc=v['desc'])
    if v['diag']: a += MACROS
    a += PART1 % len(lz)
    if v['diag']: a += '        beep                    ; beep 1: stub reached\n'
    a += PART2
    if v['diag']: a += '        beep                    ; beep x2: unpack finished\n        gap\n        beep\n'
    if v['nokey']: a += '        ld hl,$10F6             ; DIAGNOSTIC: key test -> OR $10 (SPACE can never exit)\n        ld ($FABA),hl\n'
    a += PART3
    if v['diag']: a += '        beep                    ; beeps x3: delay finished, about to jump\n        gap\n        beep\n        gap\n        beep\n'
    a += PART4
    return a
VARIANTS = [dict(name='FINALSIG', file='finalsig_vz.asm', diag=0, nokey=0, desc='release build'),
            dict(name='FSIGDIAG', file='finalsig_diag.asm', diag=1, nokey=0, desc='beep diagnostics: 1=stub, 2=unpacked, 3=delay done'),
            dict(name='FSIGNOKEY', file='finalsig_nokey.asm', diag=0, nokey=1, desc='diagnostic: SPACE exit disabled')]
for v in VARIANTS:
    open(v['file'], 'w').write(make_asm(v))
    bn = v['name'].lower() + '_body.bin'
    r = subprocess.run(['pasmo', '--bin', v['file'], bn], capture_output=True, text=True)
    print(v['name'], r.stdout.strip(), r.stderr.strip())
    body = open(bn, 'rb').read()
    hdr = b'VZF0' + v['name'].encode().ljust(17, b'\0') + bytes([0xF1]) + struct.pack('<H', 0x7B00)
    assert len(hdr) == 24
    open(v['name'] + '.VZ', 'wb').write(hdr + body)
    print(v['name'], 'body', len(body), 'file', 24 + len(body))
