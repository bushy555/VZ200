; ====================================================================
; FINAL SIGNAL - VZ200 loader / unpacker  (FINALSIG.VZ, loads at $7B00)  [release build]
;
; The ZX demo image needs $7000-$FFFF (36 KB incl. 1 KB work buffer), which
; is all the RAM a VZ200 + 32K has, so the file stores it LZ4-packed:
;   1. stub at $7B00 (interrupts off) moves [packed data + unpacker] to the very
;      top of RAM (LDDR, so the packed data ends at $FFFF)
;   2. the unpacker (position independent, SP=0 -> stack in the top 16 bytes)
;      expands it forwards to $7000 (in place; packed data stays ahead of
;      the write pointer)
;   3. short delay, then jump to INIT at $7000
; Player source: finalsig_player.asm  (org $7000, 35840 bytes)
; ====================================================================
        org $7B00
body_len equ pad_end-lz_data
dec_len  equ dec_end-dec_code
dec_addr equ $FFFF-15-dec_len
lz_addr  equ dec_addr-lz_len
lz_len   equ 15946

start:  di
        ld hl,pad_end-1
        ld de,$FFFF
        ld bc,body_len
        lddr
        jp dec_addr

lz_data:
        incbin "finalsig.lz"
dec_code:
        ld sp,0
        ld hl,lz_addr
        ld de,$7000
nexttok:ld a,(hl)
        inc hl
        push af                 ; keep token
        rrca
        rrca
        rrca
        rrca
        and 15
        ld c,a
        ld b,0
        cp 15
        jr nz,lit
lext:   ld a,(hl)
        inc hl
        push af
        add a,c
        ld c,a
        jr nc,lx1
        inc b
lx1:    pop af
        inc a
        jr z,lext               ; byte was 255 -> more
lit:    ld a,b
        or c
        jr z,nolit
        ldir
nolit:  ld a,l
        cp dec_addr & 255
        jr nz,more
        ld a,h
        cp dec_addr / 256
        jr z,done               ; last sequence has literals only
more:   pop af                  ; token
        and 15
        add a,4
        exx
        ld c,a                  ; BC' = match length (so far)
        ld b,0
        exx
        ld c,(hl)
        inc hl
        ld b,(hl)               ; BC = offset
        inc hl
        cp 19
        jr nz,mcopy
mext:   ld a,(hl)
        inc hl
        exx
        ld e,a
        add a,c
        ld c,a
        jr nc,mx1
        inc b
mx1:    ld a,e
        exx
        inc a
        jr z,mext
mcopy:  push hl                 ; source pointer
        ld h,d
        ld l,e
        and a
        sbc hl,bc               ; HL = dest - offset
        exx
        push bc
        exx
        pop bc                  ; BC = match length
        ldir
        pop hl
        jr nexttok
done:
        ld e,4                  ; ~2 s settle delay before starting the player
        ld bc,0
dly:    dec bc
        ld a,b
        or c
        jr nz,dly
        dec e
        jr nz,dly
        jp $7000
dec_end:
pad:    ds 16
pad_end:
