
Collection of Dmiltry_Milk's awesome four 1-bit music demos. 		Nov 2026.
VZ DAC 8-bit audio playing through the printer interface.   
Ported over to the VZ/Laser computer by dave.

NEED: an 8-bit resistor or IC0808 DAC circuit connected to the VZ/Laser printer interface module.  
The DAC is to be connected to either headphones or amplified speakers, such as to your 4000 watt 
stereo connected to your entertainment stereo system sitting beside your 120" tv in the lounge room.

Use a centronics female socket to plug into the VZ Printer Interfaces centronics plug.
In my attached photos of my simple resistor DAC circuit, I didnt have a female centronics socket 
so I chopped the IDE cable and used 25 pin serial plug/socket. This is not the ideal method.



Final Signal
------------
Source	: 
Youtube	: https://www.youtube.com/watch?v=XpV8q-GFtAU
Pouet	: https://www.pouet.net/prod.php?which=104852  (download .TAP)
	: https://zxart.ee/prod/574136
Released: Chaos Constructions'2025


Power Run
----------
Source	: 
Download: https://files.scene.org/browse/parties/2026/speccy_pl26/demo/demo_dmitrymilk_powerrun.zip
          https://files.scene.org/view/parties/2026/speccy_pl26/demo/demo_dmitrymilk_powerrun.zip
Youtube	: https://www.youtube.com/watch?v=98PJFIIJDiA
Pouet	: https://www.pouet.net/prod.php?which=106106
Released: Speccy.pl Party 2026



Beeperdrive
-----------
Source	: https://files.scene.org/view/parties/2026/dihalt_winter26/zx_spectrum_beeper_music/beeperdrive.zip
Youtube	: https://www.youtube.com/watch?v=PJQTfGJz_7g
Pouet	: https://www.pouet.net/prod.php?which=106230
demozoo : https://demozoo.org/productions/391719/
	  https://zxart.ee/prod/599359
Released: DiHALT Winter 2026


WE ARE Vocoders
---------------
Source	: https://github.com/DmitryMilk/we_are_vocoders
download: https://files.scene.org/view/parties/2026/dihalt_summer26/demo/we_are_vocoders.zip
youtube	: https://www.youtube.com/watch?v=-OKOHN6qFY8
Pouet	: https://www.pouet.net/prod.php?which=106678
Released: DiHALT Summer 2026.	https://zxart.ee/party/600806
	: https://zxart.ee/prod/600817













---


Final Signal	: https://www.youtube.com/watch?v=XpV8q-GFtAU
Power Run 	: https://www.youtube.com/watch?v=98PJFIIJDiA
Beeperdrive	: https://www.youtube.com/watch?v=PJQTfGJz_7g
WE ARE Vocoders : https://www.youtube.com/watch?v=-OKOHN6qFY8
