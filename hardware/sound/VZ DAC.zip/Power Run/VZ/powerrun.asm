; POWER RUN 1-bit demo - VZ200 port stub
; Original ZX Spectrum demo: compressed blob follows this stub at $8000
; ORG is set so the stub ends exactly at $8000 (no padding)
        org  07B00h
PIC     equ  1

BUF     equ  0E500h          ; temp buffer for decompressed ZX bitmap (6144 bytes)
VRAM    equ  07000h
LATCH   equ  06800h

entry:  di
        ld   sp,08000h       ; stack grows down through the unused padding below $8000
        jp   08000h          ; original unpacker (patched: screen -> BUF)

; ---------------------------------------------------------------- hookA
; reached from patched "JP $A599" after all blocks are decompressed
hookA:
        if PIC
        call showpic
        endif
        ld   hl,hookB
        ld   (0A634h),hl     ; redirect the "JP $D16D" that ends table generation
        jp   0A599h

; ---------------------------------------------------------------- hookB
; reached after the sound-code generator has finished
hookB:  ld   hl,08300h       ; generated sound code
        ld   bc,0A3A6h-08300h
        call patchout
        ld   hl,0D100h       ; static player core
        ld   bc,00070h
        call patchout
        ; replace the six "LD A,$7F / IN A,($FE) / AND 1 / JP Z,exit" key tests
        ld   hl,newkey
        ld   de,0D1C3h
        ld   bc,9
        ldir
        ld   hl,newkey
        ld   de,0D211h
        ld   bc,9
        ldir
        ld   hl,newkey
        ld   de,0D29Fh
        ld   bc,9
        ldir
        ld   hl,newkey
        ld   de,0D2C2h
        ld   bc,9
        ldir
        ld   hl,newkey
        ld   de,0D2DEh
        ld   bc,9
        ldir
        ld   hl,newkey
        ld   de,0D306h
        ld   bc,9
        ldir
        ; ~3 s settle delay after unpacking, before the player starts (interrupts are off)
        ld   d,6
dly1:   ld   bc,0
dly2:   dec  bc
        ld   a,b
        or   c
        jr   nz,dly2
        dec  d
        jr   nz,dly1
        jp   0D16Dh          ; start the player

; OUT ($FE),A -> OUT (14),A  : D3 FE -> D3 0E
patchout:
po1:    ld   a,0D3h
        cpir
        jr   nz,podone
        ld   a,(hl)
        cp   0FEh
        jr   nz,po2
        ld   (hl),00Eh
po2:    ld   a,b
        or   c
        jr   nz,po1
podone: ret

; SPACE key on VZ: row $68EF, bit 4 (active low)
newkey: db   03Ah,0EFh,068h  ; LD A,($68EF)
        db   0E6h,010h       ; AND $10
        db   000h            ; NOP (keeps 9 bytes)
        db   0CAh,059h,0D3h  ; JP Z,$D359

        if PIC
; ---------------------------------------------------------------- picture
; 256x192 ZX bitmap at BUF -> 128x64 2bpp VZ MODE(1) at $7000
; each output byte (4 px) = 1 source byte x 3 rows ; pair of src px x 3 rows = 0..6 ink
; <2 : yellow(1)  2..4 : green(0)  >=5 : blue(2)
showpic:
        ld   a,8
        ld   (LATCH),a       ; MODE(1), CSS0
        ld   hl,VRAM
        ld   (vptr),hl
        xor  a
        ld   (cury),a
rowlp:  ld   a,(cury)
        call rowaddr
        ld   (p0),hl
        ld   a,(cury)
        inc  a
        call rowaddr
        ld   (p1),hl
        ld   a,(cury)
        add  a,2
        call rowaddr
        ld   (p2),hl
        ld   a,32
        ld   (bxc),a
bxlp:   ld   hl,(p0)
        ld   b,(hl)
        inc  hl
        ld   (p0),hl
        ld   hl,(p1)
        ld   c,(hl)
        inc  hl
        ld   (p1),hl
        ld   hl,(p2)
        ld   d,(hl)
        inc  hl
        ld   (p2),hl
        ld   e,4
        ld   h,0
pair:   xor  a
        rlc  b
        adc  a,0
        rlc  b
        adc  a,0
        rlc  c
        adc  a,0
        rlc  c
        adc  a,0
        rlc  d
        adc  a,0
        rlc  d
        adc  a,0
        cp   2
        ld   l,1
        jr   c,got
        cp   5
        ld   l,0
        jr   c,got
        ld   l,2
got:    ld   a,h
        add  a,a
        add  a,a
        or   l
        ld   h,a
        dec  e
        jr   nz,pair
        ld   a,h
        ld   hl,(vptr)
        ld   (hl),a
        inc  hl
        ld   (vptr),hl
        ld   hl,bxc
        dec  (hl)
        jp   nz,bxlp
        ld   a,(cury)
        add  a,3
        ld   (cury),a
        cp   192
        jp   c,rowlp
        ret

; A = ZX pixel row y -> HL = BUF + ((y&C0)<<5 | (y&7)<<8 | (y&38)<<2)
rowaddr:
        ld   l,a
        and  0C0h
        rrca
        rrca
        rrca
        ld   h,a
        ld   a,l
        and  7
        or   h
        add  a,BUF/256
        ld   h,a
        ld   a,l
        and  38h
        add  a,a
        add  a,a
        ld   l,a
        ret

vptr:   dw   0
p0:     dw   0
p1:     dw   0
p2:     dw   0
cury:   db   0
bxc:    db   0
        endif
        ds   08000h-$        ; pad so the unpacker lands exactly at $8000
stubend:

; ================================================================ $8000
; Original Power Run unpacker (from the ZX Spectrum CODE block), VZ edits:
;   1. ZX attribute fill ($5800) removed
;   2. screen bitmap decompresses to BUF ($E500) instead of $4000 (PIC build only)
;   3. final "JP $A599" now goes through hookA
unpack: di
        ld   hl,09AC0h
        ld   de,0CF00h
        call 08058h
        ld   hl,09227h
        ld   de,0BF00h
        call 08058h
        ld   hl,08CCEh
        ld   de,0A700h
        call 08058h
        ld   hl,08B4Dh
        ld   de,0A3A6h
        call 08058h
        if PIC
        ld   hl,08106h       ; compressed ZX bitmap
        ld   de,BUF
        call 08058h
        endif
        jr   unp2
        ds   0803Bh-$        ; (was the attribute fill / old LDIR)
unp2:   ld   hl,0BF00h
        ld   b,010h
        call 0804Eh
        ld   hl,0A700h
        ld   b,018h
        call 0804Eh
        jp   hookA           ; was JP $A599
; ---- unchanged from here: delta decoder ($804E), decompressor ($8058) and the
; ---- compressed data blocks, exactly as in the original TAP
        db   097h,086h,077h,02Ch,020h,0FBh,024h,010h,0F8h,0C9h,0FDh,021h,041h,0A6h,07Eh,023h
        db   006h,034h,0D5h,0BFh,00Eh,010h,020h,005h,0DDh,069h,011h,001h,000h,0CBh,03Fh,0CCh
        db   002h,081h,0CBh,011h,030h,0F7h,00Ch,0E5h,021h,001h,000h,0FDh,071h,029h,00Dh,020h
        db   0FCh,0FDh,073h,0F5h,0FDh,072h,05Dh,019h,0EBh,0FDh,023h,0E1h,0DDh,02Dh,010h,0D4h
        db   0D1h,018h,013h,059h,005h,0C8h,0CBh,03Fh,0CCh,002h,081h,0CBh,013h,0CBh,012h,030h
        db   0F3h,042h,04Bh,0D1h,0EDh,0B0h,00Ch,0CBh,03Fh,0CCh,002h,081h,038h,0F6h,00Eh,0EFh
        db   0CBh,03Fh,0CCh,002h,081h,00Ch,030h,0F8h,0C8h,0D5h,050h,0F2h,091h,080h,0FDh,021h
        db   051h,0A5h,0CDh,0EFh,080h,0D5h,0CBh,002h,020h,007h,01Dh,001h,020h,002h,028h,00Ah
        db   01Dh,001h,010h,004h,028h,004h,011h,000h,000h,04Ah,0CDh,094h,080h,0FDh,021h,051h
        db   0A6h,0FDh,019h,0CDh,0EFh,080h,0C1h,0E3h,0E5h,0EDh,052h,0D1h,0EDh,0B0h,0E1h,018h
        db   0B5h,0FDh,009h,05Ah,0FDh,046h,029h,0CDh,092h,080h,0EBh,0FDh,04Eh,0F5h,0FDh,046h
        db   05Dh,009h,0EBh,0C9h,07Eh,023h,01Fh,0C9h,008h,091h,088h,018h,009h,010h,000h,000h
        db   000h,058h,008h,0D5h,01Ch,03Ch,022h,0B3h,01Ah,001h,000h,045h,059h,0D5h,054h,0C1h
        db   01Dh,000h,070h,000h,018h,009h,020h,094h,01Eh,001h,008h,0A6h,020h,007h,082h,009h
        db   040h,048h,0C1h,00Bh,080h,0A6h,030h,032h,060h,070h,0E2h,0FFh,081h,007h,0A4h,0A0h
        db   020h,04Ch,0F0h,044h,081h,004h,056h,020h,0CAh,0DFh,0FEh,084h,04Bh,078h,04Ah,002h
        db   006h,0ADh,0A0h,0FBh,024h,058h,0DFh,0DCh,03Dh,0E0h,001h,000h,003h,093h,097h,0C0h
        db   041h,002h,00Dh,060h,088h,03Fh,062h,093h,0FDh,065h,0C9h,010h,08Dh,070h,008h,003h
        db   040h,071h,00Eh,010h,001h,0C2h,01Ch,0FEh,040h,010h,073h,061h,010h,00Ch,065h,055h
        db   04Bh,048h,0B8h,05Ch,040h,0B0h,003h,0C0h,029h,001h,03Ch,07Ch,0C7h,07Ch,09Bh,03Eh
        db   0FEh,00Ah,07Eh,0A3h,074h,005h,013h,0F0h,031h,0A5h,07Bh,005h,070h,014h,004h,0E4h
        db   0F6h,038h,024h,0D8h,09Bh,016h,011h,010h,06Bh,0DFh,03Ch,042h,040h,082h,0DCh,044h
        db   026h,04Ah,0F7h,086h,0BFh,046h,0CAh,025h,0F0h,031h,0FCh,07Fh,0AAh,0B8h,0EBh,0CCh
        db   0E0h,006h,0DBh,0E3h,0F6h,0AAh,07Eh,0A9h,03Ch,00Bh,024h,067h,004h,038h,030h,0A2h
        db   006h,0BEh,0CEh,040h,00Eh,056h,0CDh,068h,084h,05Bh,078h,010h,02Bh,044h,0ADh,0ABh
        db   0D9h,083h,067h,020h,002h,0E0h,0F2h,09Fh,007h,0C4h,0FDh,0E2h,09Ch,010h,028h,028h
        db   077h,042h,008h,053h,037h,010h,046h,0E9h,00Ah,072h,08Fh,076h,005h,0C0h,043h,01Ch
        db   080h,008h,018h,0B1h,0EAh,038h,078h,004h,026h,0D1h,028h,068h,0FFh,062h,040h,0CDh
        db   044h,031h,048h,005h,0C9h,0BEh,087h,0D1h,0F8h,008h,040h,01Ah,059h,0FEh,096h,0FAh
        db   028h,094h,0F3h,0A9h,0C9h,06Eh,048h,08Fh,0DBh,03Bh,00Fh,0A1h,0CCh,064h,04Bh,00Eh
        db   000h,08Eh,040h,06Dh,001h,0EFh,010h,078h,030h,029h,040h,0F7h,0A5h,054h,04Eh,038h
        db   07Dh,010h,004h,025h,05Ah,03Ch,0B6h,030h,02Fh,080h,080h,0EDh,0CFh,0E5h,0CFh,01Ch
        db   02Ch,0CAh,008h,07Ch,05Eh,093h,041h,042h,049h,031h,083h,0F0h,04Bh,00Eh,033h,0A0h
        db   048h,0FCh,0EDh,0CFh,0A5h,09Fh,004h,06Ch,073h,09Eh,030h,06Dh,044h,07Bh,042h,052h
        db   08Dh,032h,01Eh,070h,057h,040h,0A8h,0F5h,0D9h,080h,051h,0E0h,05Dh,086h,0B6h,03Bh
        db   0A3h,029h,045h,08Dh,0EFh,039h,0C6h,03Ah,052h,028h,0D5h,017h,085h,0D9h,00Dh,04Bh
        db   004h,033h,060h,0E8h,060h,0F0h,088h,0A9h,03Dh,010h,0C5h,077h,0D1h,052h,078h,030h
        db   04Eh,06Bh,03Ch,065h,0E9h,04Fh,058h,052h,0CBh,024h,003h,0C1h,0F5h,006h,02Ch,0F4h
        db   0C0h,022h,06Ch,0F0h,058h,0C4h,03Eh,0CAh,0BFh,07Ch,0A4h,0F6h,03Fh,0BDh,0FDh,00Ch
        db   053h,007h,078h,058h,0CCh,0FBh,0C0h,0E5h,09Fh,00Fh,00Ah,080h,01Ch,0A0h,04Fh,030h
        db   078h,0E5h,09Fh,04Ah,006h,042h,03Eh,0BCh,0FCh,013h,0F9h,0AAh,068h,044h,034h,006h
        db   0E0h,01Dh,0FAh,0A8h,07Eh,042h,095h,0FEh,048h,074h,0BFh,091h,0EDh,004h,0E1h,0F2h
        db   0E7h,004h,09Bh,02Dh,04Ah,04Ch,080h,046h,004h,00Eh,00Bh,00Eh,0B3h,0EFh,0CEh,091h
        db   004h,0DAh,0DFh,00Fh,0CFh,040h,061h,0BAh,081h,080h,003h,0A4h,07Ah,000h,034h,0F5h
        db   073h,018h,004h,080h,00Dh,089h,085h,020h,043h,0A8h,071h,0E2h,0F0h,011h,006h,050h
        db   088h,03Ch,0ACh,0A0h,001h,00Bh,0E4h,050h,0B7h,028h,040h,004h,03Fh,046h,045h,002h
        db   0ABh,0E1h,0ADh,061h,03Eh,0B9h,07Fh,0F8h,052h,0FEh,040h,045h,0F7h,034h,018h,0A6h
        db   0CFh,0FEh,088h,046h,086h,089h,062h,006h,02Ch,0D7h,00Fh,080h,04Bh,0BFh,0C0h,0B3h
        db   075h,038h,0C1h,045h,03Ch,054h,0DFh,093h,070h,02Fh,040h,00Ch,03Ch,004h,005h,055h
        db   0A4h,0C9h,0ECh,035h,003h,08Eh,081h,0AEh,00Dh,0BCh,0FCh,0D3h,03Eh,0F4h,0CFh,010h
        db   0D3h,0BFh,040h,0A4h,0F6h,017h,05Dh,0F5h,052h,020h,000h,08Eh,0F1h,0B9h,0FCh,027h
        db   0A9h,0FCh,0A5h,0E6h,03Ch,025h,024h,039h,07Ah,042h,07Eh,007h,031h,02Bh,0CCh,06Bh
        db   084h,06Ah,0F2h,044h,01Bh,024h,005h,050h,006h,0F8h,004h,058h,007h,09Dh,0BFh,0FDh
        db   0C4h,0B5h,0B7h,010h,09Fh,0C3h,06Ch,0D0h,08Eh,0EDh,001h,030h,0C2h,00Ch,029h,048h
        db   023h,074h,0B6h,0A6h,001h,008h,002h,038h,046h,0F8h,030h,023h,0D0h,0A0h,0A9h,09Fh
        db   0EFh,016h,04Ah,080h,06Fh,002h,02Ch,002h,040h,01Dh,023h,0EFh,0E3h,001h,028h,0F9h
        db   0D1h,09Fh,0D6h,061h,0A5h,0C1h,020h,002h,0F7h,07Fh,0F7h,06Ch,045h,00Eh,0F1h,0F8h
        db   06Ah,000h,00Eh,0E5h,0E9h,0FEh,08Eh,0A4h,0C0h,062h,093h,0C7h,0B8h,082h,0FBh,07Dh
        db   0FFh,033h,0EBh,0B6h,0E7h,022h,0AFh,0A1h,0E0h,03Eh,0D8h,0FDh,03Eh,0D9h,020h,051h
        db   0E3h,0BEh,080h,03Eh,038h,010h,036h,0F1h,0B5h,012h,03Eh,06Ah,0B6h,001h,0DCh,0B8h
        db   01Eh,0CEh,023h,086h,0F9h,0AEh,017h,0E7h,06Ch,020h,002h,0F7h,0F6h,01Fh,0BCh,0BFh
        db   008h,052h,00Fh,083h,06Fh,077h,010h,089h,0EAh,043h,096h,067h,07Ch,0C6h,081h,083h
        db   0BFh,03Fh,0E0h,010h,0D9h,090h,0C1h,018h,0FDh,007h,0F7h,0FCh,075h,001h,0D2h,0A8h
        db   03Ah,01Eh,081h,015h,011h,0E8h,0F0h,038h,026h,047h,061h,027h,0B9h,0C2h,0C5h,0A7h
        db   010h,01Fh,0EEh,0E5h,05Bh,005h,025h,0B0h,005h,03Eh,008h,00Ah,063h,0FDh,011h,0B3h
        db   07Dh,001h,03Bh,0AEh,05Eh,074h,017h,0B8h,031h,010h,010h,0F8h,0CBh,0BEh,0B1h,0D0h
        db   023h,044h,0EDh,0C6h,0C4h,0BFh,01Ch,041h,008h,092h,06Fh,03Ah,0E3h,0C0h,003h,01Ah
        db   0C2h,04Dh,03Bh,01Fh,032h,028h,05Ch,020h,00Dh,0E2h,08Bh,0E1h,056h,01Eh,01Fh,058h
        db   02Dh,065h,0B6h,00Bh,08Ch,064h,0EFh,091h,05Bh,092h,002h,0F7h,0BCh,08Eh,005h,09Dh
        db   047h,0FDh,003h,0EAh,020h,066h,094h,08Ch,095h,00Fh,001h,07Ch,0CCh,0B9h,07Bh,001h
        db   0A0h,017h,0B2h,03Eh,0C0h,047h,095h,0F9h,07Fh,081h,0BFh,0C0h,014h,0D5h,030h,0C0h
        db   005h,090h,038h,0DFh,0F8h,03Fh,012h,09Fh,001h,0BFh,0E4h,080h,002h,07Ch,079h,043h
        db   080h,01Fh,02Fh,02Ah,0D0h,00Ah,0B7h,038h,080h,07Eh,03Fh,005h,0A7h,02Ch,0F9h,057h
        db   021h,01Ch,032h,0FCh,00Dh,07Bh,01Eh,0D3h,09Ch,0F4h,0E4h,088h,00Fh,0CDh,0BBh,08Dh
        db   0E7h,00Fh,093h,018h,081h,0C0h,08Bh,0E3h,0F2h,0C1h,0C6h,0C0h,053h,046h,02Fh,06Fh
        db   077h,017h,0A4h,07Fh,016h,025h,090h,018h,07Ch,03Bh,0C7h,0EBh,001h,03Ch,07Ch,06Ah
        db   05Eh,001h,019h,040h,0DBh,03Fh,01Ch,0C4h,0C0h,063h,0A7h,07Fh,062h,060h,027h,040h
        db   012h,034h,023h,0E0h,05Eh,00Eh,0DCh,0EDh,0C3h,007h,073h,0ACh,089h,0E7h,016h,032h
        db   019h,019h,041h,069h,03Ah,09Dh,01Ch,0A5h,097h,097h,03Bh,0CFh,0FBh,007h,069h,0F1h
        db   0D6h,040h,0A9h,0FAh,0B7h,034h,00Fh,0A9h,004h,078h,059h,0F4h,0C0h,0F6h,0FAh,0D2h
        db   055h,074h,063h,098h,000h,0FFh,0C8h,0E1h,0D8h,01Bh,03Ch,0C2h,058h,0E5h,080h,03Fh
        db   06Ch,0B4h,0B5h,0F2h,0DFh,0F6h,0D7h,0C1h,0CBh,07Dh,080h,0C0h,0D8h,0CAh,09Fh,0F2h
        db   003h,06Ah,072h,01Fh,0DFh,064h,04Ch,00Ch,01Eh,06Fh,0DFh,009h,0A9h,0F7h,0BAh,08Fh
        db   09Ch,000h,04Eh,016h,0D7h,0DFh,006h,081h,030h,03Ch,0F4h,09Eh,057h,08Dh,0FFh,0F6h
        db   036h,06Eh,04Ch,0D4h,04Bh,06Bh,004h,060h,0A3h,05Ch,010h,055h,0DCh,035h,021h,0B0h
        db   00Eh,00Fh,0FAh,0BAh,092h,0E0h,03Bh,077h,006h,073h,07Ch,066h,0C2h,037h,018h,0F7h
        db   002h,0D2h,0BAh,0DDh,020h,032h,093h,02Fh,02Eh,04Ah,073h,0C0h,0BAh,047h,0D8h,0EBh
        db   06Bh,0A0h,04Fh,0F1h,0F1h,068h,0F8h,0FDh,0B7h,01Eh,0BFh,002h,06Fh,0F5h,086h,07Ch
        db   07Fh,04Dh,046h,04Ah,04Fh,0F0h,09Eh,0D6h,048h,0F0h,0F6h,0C5h,0A2h,0FCh,08Fh,088h
        db   0C3h,07Fh,080h,020h,0C3h,03Fh,0A4h,037h,0D1h,06Dh,0BFh,029h,0F2h,0FDh,00Fh,060h
        db   0F4h,00Fh,050h,035h,066h,0F0h,030h,06Bh,0C5h,0B0h,017h,066h,00Fh,059h,08Ch,022h
        db   0D3h,066h,05Eh,068h,07Fh,019h,0B7h,0F6h,08Fh,04Bh,0FBh,0DDh,0B4h,0F9h,00Fh,0BBh
        db   080h,028h,0FBh,038h,03Ch,0F0h,031h,077h,0C6h,090h,014h,08Dh,0D8h,030h,0D5h,029h
        db   04Ah,0E4h,0E6h,070h,058h,002h,040h,0B2h,031h,0DCh,0A4h,029h,00Ch,02Bh,096h,0ECh
        db   07Bh,0F0h,0ACh,07Ah,094h,0C6h,006h,0BDh,060h,002h,07Fh,083h,0A4h,081h,0D7h,0F0h
        db   023h,055h,038h,034h,0E6h,010h,06Fh,0F6h,087h,085h,0DFh,0D3h,009h,07Ah,0EEh,085h
        db   065h,01Ch,06Bh,07Fh,048h,01Bh,044h,09Fh,0B7h,067h,0CFh,044h,03Dh,0D3h,030h,0B4h
        db   0C0h,022h,0E8h,0F4h,067h,082h,0FCh,077h,08Ch,007h,0F8h,09Ah,0FDh,0EAh,0A4h,018h
        db   01Bh,021h,0BEh,01Dh,0F8h,0FCh,010h,0FFh,0BEh,063h,060h,007h,08Bh,0F3h,0C4h,00Ch
        db   027h,0ACh,0F2h,0FEh,07Ah,028h,077h,0F8h,02Fh,0F3h,0BFh,008h,089h,01Ch,0E4h,02Bh
        db   0DFh,01Bh,07Bh,0FCh,07Ch,01Fh,067h,0F0h,0FFh,0C2h,069h,0E7h,00Fh,04Fh,002h,001h
        db   021h,0FAh,04Ah,06Ch,0ACh,007h,083h,062h,0DEh,00Eh,0C8h,0BAh,034h,012h,014h,02Ah
        db   03Fh,036h,028h,06Ah,002h,049h,03Fh,079h,018h,04Ch,001h,0BCh,032h,0BBh,0BFh,068h
        db   0F6h,0A0h,01Ah,08Bh,0BFh,0F1h,065h,003h,085h,095h,0FFh,012h,067h,01Ch,0F1h,047h
        db   0A9h,0DFh,0BFh,05Ah,069h,003h,0E8h,08Fh,03Fh,0FDh,0B7h,026h,0B7h,00Fh,00Eh,039h
        db   0E0h,0B2h,0F9h,081h,068h,0EAh,043h,0FEh,066h,050h,0FEh,068h,064h,0F1h,02Dh,00Ch
        db   06Dh,00Fh,0BDh,04Ch,01Fh,09Fh,070h,0F3h,017h,08Fh,077h,09Ch,06Fh,0F7h,07Eh,05Ch
        db   0C0h,008h,0D1h,08Ch,089h,052h,086h,0A6h,089h,052h,05Eh,07Fh,0CBh,061h,0B7h,022h
        db   0E3h,076h,02Ch,00Eh,0EBh,09Eh,093h,058h,003h,099h,0F3h,0C7h,0C0h,0CCh,0FDh,023h
        db   0CEh,001h,0A1h,0FEh,0FEh,00Eh,041h,0C1h,024h,092h,03Ch,00Eh,00Ah,070h,098h,060h
        db   020h,034h,04Dh,0C1h,003h,031h,02Fh,0FCh,04Dh,02Dh,0D0h,00Dh,02Dh,0E2h,0C3h,02Fh
        db   046h,0EFh,07Fh,0C9h,07Eh,075h,0F7h,08Eh,0FEh,068h,030h,078h,047h,001h,093h,03Dh
        db   0C6h,0E1h,0E0h,029h,019h,00Ch,02Bh,08Fh,076h,032h,0DBh,00Dh,08Fh,0AFh,0F6h,0F4h
        db   073h,03Ch,011h,0E7h,03Eh,0DDh,099h,081h,06Ch,0FDh,0FEh,08Fh,091h,03Fh,080h,003h
        db   0A6h,0F3h,007h,080h,008h,0F3h,07Fh,0DFh,0C2h,019h,04Fh,0A0h,0B2h,091h,01Fh,010h
        db   07Dh,0F9h,080h,06Fh,0FCh,080h,0A7h,001h,062h,060h,0E2h,00Ah,0E6h,019h,062h,039h
        db   01Ch,0A9h,0CEh,034h,0FEh,011h,0F4h,004h,07Bh,0B9h,0D7h,000h,00Ah,01Dh,04Dh,06Fh
        db   030h,016h,0BCh,0F5h,0D1h,0BEh,0B6h,0C0h,081h,046h,049h,0E0h,06Fh,0E1h,08Ah,080h
        db   0DEh,027h,034h,075h,0B2h,06Eh,074h,039h,010h,0C0h,027h,07Dh,0E7h,0EFh,0FBh,0C1h
        db   0A9h,063h,005h,093h,0FCh,08Bh,043h,0B0h,063h,00Eh,007h,048h,050h,02Ah,0E6h,0F1h
        db   099h,048h,0E3h,0CAh,081h,000h,077h,069h,05Fh,0EAh,01Dh,08Dh,0F5h,084h,0EBh,006h
        db   02Fh,03Fh,074h,0ABh,06Bh,0C7h,0EBh,0D9h,0F7h,019h,070h,005h,046h,0EAh,0D6h,0E1h
        db   0B1h,0FBh,042h,000h,04Fh,09Fh,0E0h,083h,0C8h,023h,03Ah,00Eh,099h,000h,0D6h,0C0h
        db   0FCh,0A7h,060h,030h,006h,09Ah,01Fh,0E0h,007h,0CEh,087h,0F0h,0BEh,07Bh,0F9h,0A9h
        db   055h,01Eh,025h,0C0h,0F2h,01Ch,0D8h,019h,010h,0D8h,0E4h,08Dh,088h,03Ch,074h,00Fh
        db   073h,0B7h,080h,0A1h,04Ah,0C0h,099h,035h,056h,003h,0A4h,029h,044h,099h,089h,0A7h
        db   0EEh,0F7h,0F8h,001h,0B1h,0C0h,0E7h,0E8h,043h,002h,079h,018h,06Ch,0EAh,07Ch,0C2h
        db   055h,0CCh,000h,087h,0E0h,068h,092h,006h,0EBh,0DDh,00Bh,001h,072h,005h,0FAh,086h
        db   055h,0FDh,0E3h,060h,063h,030h,020h,044h,051h,00Fh,00Eh,0A0h,015h,09Dh,01Ch,018h
        db   00Ch,0CBh,06Fh,07Fh,0F3h,010h,036h,010h,0CCh,007h,03Fh,070h,02Fh,015h,080h,030h
        db   002h,079h,05Ah,047h,047h,070h,01Dh,04Ah,02Dh,0F4h,03Ah,047h,04Bh,0F4h,0EDh,0E0h
        db   006h,0D0h,0D5h,06Bh,00Bh,08Dh,004h,085h,060h,012h,0C9h,058h,04Ch,03Ch,077h,032h
        db   0EFh,0FBh,037h,00Ch,0A2h,0E8h,0E0h,040h,020h,09Ch,0A2h,00Ch,094h,0C5h,0F8h,0C6h
        db   07Ch,078h,0BDh,090h,0F1h,0CDh,010h,04Bh,03Ch,07Ch,011h,07Eh,0F2h,015h,089h,03Ch
        db   0CCh,08Ah,0F7h,0EEh,00Bh,038h,0EEh,040h,002h,00Bh,037h,090h,045h,020h,08Dh,007h
        db   099h,0F9h,079h,00Ch,066h,0A5h,0B0h,0D2h,005h,0AEh,002h,0CEh,0EEh,086h,003h,043h
        db   0F7h,008h,040h,03Fh,0E0h,066h,0E1h,071h,0ECh,003h,0C1h,09Ah,0F2h,0E4h,0E9h,033h
        db   0ECh,092h,008h,0B4h,02Ch,0D4h,03Bh,080h,06Ch,007h,0B6h,043h,0D9h,098h,033h,0D0h
        db   0D2h,06Dh,003h,0B3h,034h,021h,054h,08Dh,0C5h,069h,084h,004h,07Ah,0E3h,0A0h,0E7h
        db   0C6h,002h,01Ch,076h,0B2h,0DAh,073h,0B3h,0C3h,0C0h,029h,017h,042h,01Ch,038h,0FCh
        db   064h,0A5h,0D0h,0BDh,0E6h,042h,0FCh,071h,063h,00Ah,061h,01Dh,03Dh,0C3h,03Ah,0EAh
        db   0AFh,0E3h,0DFh,0FBh,081h,002h,03Eh,068h,0D8h,0F1h,0AAh,0FBh,097h,047h,037h,0D0h
        db   0F2h,0C3h,080h,0B0h,04Eh,09Bh,03Ch,01Ah,00Ch,0B8h,00Ah,0A0h,0CFh,0E3h,060h,00Eh
        db   0ECh,036h,07Ch,0A1h,004h,0F8h,00Fh,0A1h,0EDh,078h,07Ch,0D7h,072h,079h,062h,0C7h
        db   0CEh,03Fh,010h,0A3h,006h,01Ch,0C5h,018h,001h,08Fh,00Ch,08Ah,079h,0B4h,082h,053h
        db   0E0h,0CDh,0BFh,020h,0C0h,008h,030h,072h,0D4h,063h,0D0h,0E8h,0DFh,098h,063h,003h
        db   041h,04Fh,0B0h,0C7h,073h,002h,003h,045h,0C9h,078h,042h,04Bh,00Eh,071h,020h,044h
        db   040h,081h,07Ch,03Ah,06Bh,078h,0CDh,010h,092h,0FCh,04Fh,01Fh,0EFh,044h,0AAh,040h
        db   0C9h,0ECh,097h,006h,007h,036h,040h,03Eh,0F2h,069h,0FBh,0A7h,003h,057h,079h,0D9h
        db   0A0h,0A6h,001h,081h,007h,00Ah,0CCh,007h,077h,0E0h,030h,018h,08Dh,0ECh,0CCh,03Fh
        db   098h,019h,0C1h,080h,0E3h,0E0h,026h,01Fh,036h,01Eh,010h,07Bh,0F9h,0F3h,0DFh,0ACh
        db   0F6h,02Ah,0C0h,0D8h,097h,0B6h,01Ch,020h,0F3h,0C1h,083h,07Fh,0E3h,0C0h,00Eh,09Fh
        db   093h,018h,09Eh,0C7h,01Dh,040h,029h,0BEh,010h,048h,060h,017h,00Ah,0ACh,02Dh,00Eh
        db   0DAh,001h,0EEh,04Bh,01Dh,020h,0B7h,08Eh,00Eh,0A0h,0F6h,0DFh,020h,078h,0BFh,044h
        db   03Eh,09Dh,0D2h,02Bh,0E9h,081h,0D4h,07Eh,087h,0E3h,0C8h,038h,0D1h,047h,0E6h,07Ch
        db   05Dh,08Ah,0EBh,00Ah,070h,038h,0E3h,05Dh,0F8h,081h,03Fh,0AFh,0BCh,078h,0F9h,018h
        db   095h,00Fh,054h,0F9h,0E3h,03Eh,038h,0D0h,00Ch,007h,017h,06Ah,005h,019h,00Fh,02Dh
        db   09Fh,0C0h,0C1h,00Ch,0C3h,0BAh,08Fh,0C5h,0C0h,018h,004h,0FFh,06Eh,028h,035h,0FDh
        db   00Fh,05Dh,0F2h,044h,004h,0E1h,0CAh,0ACh,08Eh,0BDh,0FDh,022h,0ADh,01Dh,010h,018h
        db   0EDh,000h,007h,06Ah,001h,083h,03Fh,060h,0C3h,080h,002h,001h,08Ch,03Ch,08Eh,0C0h
        db   038h,020h,07Eh,06Fh,0F4h,038h,073h,030h,010h,01Eh,067h,039h,0E1h,092h,040h,025h
        db   020h,019h,01Dh,044h,00Fh,0FAh,0BFh,008h,024h,09Ah,004h,0EAh,078h,023h,0E4h,01Ch
        db   023h,0E0h,0E1h,0E3h,0FDh,0C0h,04Eh,03Eh,0CEh,053h,00Dh,0A7h,09Fh,0FDh,013h,047h
        db   029h,04Ch,042h,09Eh,0A1h,05Dh,016h,054h,080h,0E1h,024h,090h,0CAh,007h,057h,040h
        db   043h,08Fh,0FDh,04Ch,00Bh,052h,0A2h,069h,0EDh,0CCh,032h,0C1h,0C2h,069h,00Eh,03Bh
        db   070h,007h,0B9h,0EEh,0F9h,099h,0E2h,0B1h,0FCh,0C0h,0ADh,081h,093h,0FDh,0B8h,089h
        db   079h,07Eh,0A5h,0C6h,007h,03Ah,0C0h,0F4h,021h,080h,006h,018h,0D6h,06Ch,020h,009h
        db   0DFh,0D6h,0EDh,00Fh,015h,048h,0EFh,065h,0E6h,095h,0EEh,0D5h,006h,0FFh,040h,062h
        db   03Ch,078h,0C1h,09Fh,04Eh,0EFh,038h,00Ch,066h,0E9h,0A5h,0E9h,0DFh,00Ch,086h,09Ah
        db   078h,0D2h,040h,0CCh,099h,002h,0F3h,043h,00Fh,0FEh,05Ch,01Bh,044h,008h,01Ah,022h
        db   02Ch,0B5h,001h,0B0h,0C9h,09Fh,0CFh,081h,01Eh,0E8h,062h,00Eh,007h,0E0h,0FCh,0EFh
        db   001h,03Dh,0FDh,021h,030h,07Fh,038h,046h,033h,0E0h,0E6h,0E3h,020h,00Ch,021h,0C1h
        db   0BEh,089h,010h,0C5h,0D0h,00Eh,029h,0CEh,0E7h,078h,005h,074h,00Ch,0C9h,03Dh,00Dh
        db   036h,018h,0FAh,0CAh,00Bh,018h,019h,0FAh,063h,0C0h,006h,0C7h,004h,06Fh,00Dh,0EEh
        db   080h,0C3h,00Eh,071h,002h,00Ch,060h,0A8h,02Dh,0F3h,0FBh,0FEh,0FBh,0A7h,01Fh,091h
        db   08Bh,0B1h,0E0h,02Dh,091h,0ADh,02Bh,0CFh,00Fh,080h,081h,037h,0C7h,000h,080h,008h
        db   080h,098h,000h,000h,000h,000h,000h,000h,008h,091h,080h,000h,048h,018h,085h,01Dh
        db   001h,000h,099h,000h,011h,081h,048h,011h,081h,0F8h,001h,005h,000h,042h,05Bh,07Eh
        db   05Bh,004h,088h,0B7h,01Dh,00Ah,040h,05Bh,044h,05Bh,007h,090h,09Eh,09Eh,0D6h,01Ch
        db   046h,0BFh,080h,020h,006h,041h,003h,042h,0F8h,048h,012h,044h,00Ch,022h,09Bh,005h
        db   028h,05Fh,024h,002h,050h,011h,046h,017h,04Ch,030h,07Fh,004h,051h,001h,052h,040h
        db   058h,010h,0FFh,003h,008h,07Bh,021h,080h,0DCh,0D7h,00Ah,006h,028h,018h,0C2h,0EEh
        db   088h,07Fh,009h,020h,081h,008h,0DBh,06Ah,004h,00Ch,010h,0FFh,00Ah,08Ch,018h,065h
        db   0A3h,092h,026h,080h,003h,02Bh,0A3h,004h,0B4h,020h,048h,040h,08Eh,010h,0E2h,0F8h
        db   095h,0E4h,061h,0E3h,050h,003h,0A1h,020h,004h,024h,04Fh,002h,084h,013h,083h,003h
        db   0E6h,04Eh,038h,005h,086h,003h,0BEh,008h,03Fh,080h,086h,002h,09Bh,030h,013h,0D4h
        db   005h,0F0h,0CBh,070h,013h,0E8h,00Ah,0E5h,040h,0F8h,000h,0C0h,06Eh,023h,029h,07Fh
        db   031h,0C9h,0E4h,0E1h,019h,0D1h,0DDh,062h,0FDh,0DDh,0EBh,0D9h,075h,009h,044h,04Dh
        db   0DAh,0A8h,0B9h,05Ch,01Ah,038h,097h,0D3h,0FEh,039h,013h,0B3h,0FBh,0EBh,086h,0E1h
        db   089h,068h,095h,06Ah,033h,069h,060h,069h,08Dh,00Ch,02Ch,097h,0C2h,09Fh,0D1h,0C9h
        db   03Eh,0FFh,02Fh,05Bh,000h,0FEh,008h,002h,0C1h,005h,02Eh,0BEh,021h,099h,0A5h,0DDh
        db   0F1h,044h,0A4h,031h,0A6h,077h,0A3h,006h,053h,096h,02Bh,01Bh,05Eh,000h,0DFh,056h
        db   0D5h,010h,0F6h,011h,09Eh,083h,0D9h,0E9h,0BFh,0A3h,0FDh,046h,0E3h,023h,001h,027h
        db   0FFh,080h,081h,0DFh,097h,0FEh,040h,038h,05Eh,0F8h,0C1h,030h,05Ah,0D9h,0EDh,047h
        db   053h,026h,0A6h,07Ah,07Fh,0F1h,0FAh,0F9h,0A5h,047h,0E1h,03Bh,08Fh,0F3h,030h,005h
        db   0DDh,0EBh,04Eh,000h,023h,020h,076h,0FDh,04Ah,0B5h,0DFh,0B7h,028h,00Bh,07Eh,06Ch
        db   0A1h,036h,003h,0B7h,012h,013h,05Fh,010h,0F5h,018h,0D9h,070h,0EDh,00Ah,0FDh,03Dh
        db   028h,00Fh,02Eh,0A7h,075h,034h,0B0h,035h,06Dh,0B1h,089h,0DDh,0E6h,0BFh,018h,0F1h
        db   0EEh,048h,0B3h,04Fh,0BCh,04Fh,0BDh,06Fh,0FDh,0A6h,0DDh,047h,0EBh,05Eh,0FDh,073h
        db   024h,072h,025h,08Eh,01Ch,03Dh,07Bh,03Fh,080h,020h,08Fh,0C3h,06Dh,0D1h,000h,080h
        db   008h,098h,088h,084h,005h,040h,080h,001h,000h,091h,059h,095h,04Ch,04Dh,03Ch,0B3h
        db   086h,040h,010h,091h,014h,004h,049h,08Ch,010h,090h,0F8h,0FAh,001h,000h,022h,024h
        db   0C6h,049h,00Ch,070h,000h,01Ah,0D3h,020h,0FFh,089h,068h,028h,034h,0C6h,0F4h,069h
        db   09Eh,08Eh,0DAh,070h,035h,0ACh,06Ah,01Ah,0A4h,0FEh,090h,0E2h,028h,014h,0A6h,084h
        db   0B2h,08Eh,072h,0AAh,068h,0BDh,0C2h,0D8h,0BCh,03Ah,086h,080h,03Bh,089h,0BBh,009h
        db   0F3h,004h,068h,0E9h,060h,02Ah,001h,08Fh,0C9h,018h,0A2h,069h,06Fh,0F9h,07Ch,080h
        db   087h,011h,01Ah,011h,065h,0FDh,0FBh,0FCh,025h,062h,0D8h,0E2h,0A6h,0F2h,020h,041h
        db   002h,026h,067h,0C1h,093h,0D6h,000h,07Ah,00Eh,0ECh,021h,06Bh,003h,06Ch,0BCh,0FFh
        db   0FCh,000h,0BEh,0ADh,070h,0D5h,07Fh,0FBh,0F3h,0F1h,0F4h,0FCh,002h,005h,045h,0A6h
        db   0AAh,0FDh,06Ch,064h,0C0h,07Bh,0DEh,0FBh,004h,08Eh,09Ch,006h,00Ah,007h,004h,003h
        db   020h,000h,057h,003h,040h,027h,0C2h,0FFh,029h,038h,0D3h,081h,0F1h,001h,0EFh,071h
        db   001h,05Eh,08Eh,00Bh,0C0h,018h,060h,00Eh,002h,09Eh,087h,073h,0C1h,0CBh,02Ch,00Ah
        db   0B3h,008h,0A5h,0F1h,018h,0BCh,018h,09Fh,065h,0E0h,09Ch,0FEh,098h,04Ch,0E0h,053h
        db   0E1h,031h,0C0h,069h,038h,015h,040h,01Ah,057h,041h,041h,00Ah,009h,0BFh,0F3h,02Ch
        db   096h,0CEh,055h,0D0h,08Ah,0C1h,097h,00Eh,090h,007h,05Eh,0FCh,07Ch,0C7h,000h,09Ah
        db   001h,0C2h,0B3h,000h,0C9h,003h,018h,0F2h,0D8h,04Ah,0FAh,088h,0A5h,080h,095h,0FDh
        db   021h,029h,0A6h,08Eh,091h,0C2h,040h,0EEh,088h,0C2h,0FBh,00Bh,0F8h,038h,000h,0C0h
        db   00Ah,000h,05Bh,0CDh,054h,091h,079h,057h,0FDh,0AAh,0FCh,0D6h,042h,092h,0E8h,032h
        db   0A6h,048h,0D8h,002h,03Ch,038h,0AEh,00Eh,05Ch,07Fh,009h,0F8h,0DCh,047h,029h,0B8h
        db   00Ah,0B8h,01Eh,038h,009h,0D3h,086h,05Eh,021h,0C2h,0D1h,034h,0EEh,01Fh,0FCh,0B0h
        db   081h,0C7h,003h,06Fh,028h,0BEh,002h,081h,0B7h,0EBh,071h,009h,0F0h,0D4h,0A2h,002h
        db   0B6h,0D0h,073h,003h,01Fh,013h,0FCh,098h,0C5h,055h,000h,02Bh,009h,036h,04Fh,0D1h
        db   0FCh,02Dh,08Ch,01Bh,034h,042h,027h,00Eh,08Ch,000h,0B3h,071h,012h,076h,0E7h,0F1h
        db   055h,0B8h,038h,082h,061h,0BDh,087h,0F7h,046h,063h,0EEh,06Ah,02Ch,0F3h,0FFh,0DCh
        db   09Ch,067h,0AEh,046h,0E1h,0C6h,034h,07Eh,01Dh,0E0h,010h,08Ch,021h,0C2h,0E6h,0C7h
        db   042h,0A2h,02Ah,0A1h,04Ch,082h,051h,03Ah,0B3h,002h,016h,092h,019h,01Ch,08Ah,000h
        db   0D3h,049h,0E6h,056h,0A7h,0A6h,02Bh,07Bh,0EBh,0C0h,0A6h,00Bh,0DDh,024h,05Ah,0A4h
        db   066h,02Bh,068h,051h,03Ch,046h,0CBh,028h,0DFh,039h,035h,0C4h,0BBh,0FCh,0FBh,0FAh
        db   068h,0D2h,026h,00Eh,011h,083h,016h,026h,088h,028h,038h,093h,0C1h,0A0h,03Ch,0D2h
        db   093h,0FDh,052h,0FCh,084h,02Ch,070h,0BBh,028h,043h,091h,046h,000h,0CAh,010h,0A6h
        db   044h,018h,059h,008h,011h,057h,0A5h,0C1h,01Dh,0C7h,029h,0C4h,023h,03Ah,0CAh,074h
        db   0D0h,026h,0D7h,029h,036h,018h,055h,091h,0FDh,0F2h,042h,02Bh,06Ah,008h,053h,0BDh
        db   0A5h,021h,0D7h,027h,0D4h,019h,068h,066h,0BFh,0FDh,0F9h,0F8h,0F7h,0FAh,0FCh,04Dh
        db   0D4h,003h,0ACh,054h,0C0h,006h,0C4h,099h,02Ah,0FEh,0D3h,021h,02Ah,084h,0B6h,089h
        db   05Eh,0F9h,0E9h,04Eh,033h,0C5h,060h,0F9h,0E0h,04Ch,0B8h,070h,038h,093h,034h,088h
        db   03Bh,0F9h,031h,0E9h,060h,023h,041h,03Ah,049h,0BAh,02Dh,0C4h,09Ah,064h,0EFh,04Ch
        db   0A6h,019h,078h,033h,0C5h,0C0h,0EAh,0F3h,0FEh,07Bh,091h,0C5h,01Ch,009h,06Ch,02Bh
        db   082h,03Fh,0ABh,072h,04Ch,038h,001h,0FAh,01Ch,0C7h,05Fh,08Ch,0C8h,002h,041h,008h
        db   0E0h,007h,039h,04Fh,041h,0F7h,004h,04Bh,0C1h,0A2h,083h,03Eh,009h,0E2h,02Ch,0D4h
        db   03Bh,09Ah,08Ah,0BBh,098h,002h,0F1h,00Ch,071h,00Ch,00Bh,085h,086h,014h,0A1h,0E7h
        db   014h,005h,038h,0A1h,034h,012h,00Dh,096h,02Ah,0B7h,0D4h,019h,083h,005h,085h,0FEh
        db   0DDh,0FEh,0E8h,0E8h,0C3h,05Fh,072h,061h,05Ah,030h,032h,0AFh,091h,008h,028h,0E4h
        db   015h,040h,057h,027h,0AEh,00Ah,055h,0C3h,065h,084h,02Ah,020h,011h,0BBh,066h,069h
        db   060h,00Bh,037h,071h,004h,0B5h,008h,093h,05Ch,042h,0D4h,079h,049h,00Bh,00Eh,002h
        db   071h,003h,09Fh,00Bh,0A8h,0C5h,019h,029h,0FDh,095h,094h,02Ah,022h,008h,0C1h,06Fh
        db   05Fh,046h,029h,08Dh,038h,0AFh,00Dh,0B8h,046h,044h,00Bh,0A5h,086h,04Ah,082h,09Eh
        db   0EAh,0E2h,0E6h,023h,0B1h,07Ah,060h,07Eh,022h,088h,0DFh,0D0h,042h,0FAh,040h,0F6h
        db   00Dh,0DDh,03Fh,06Eh,031h,038h,040h,02Dh,09Ah,0FAh,0B9h,0FBh,04Dh,094h,003h,09Dh
        db   035h,048h,0B4h,0FDh,0ECh,0E2h,0A7h,084h,009h,0D3h,00Ch,0EEh,015h,08Eh,0A5h,0A2h
        db   07Ch,004h,0A4h,0FEh,037h,011h,015h,095h,008h,0D1h,0E4h,04Bh,034h,011h,05Ch,054h
        db   007h,054h,01Ah,06Fh,082h,06Bh,023h,0D2h,04Bh,0F8h,0FAh,066h,0F5h,08Bh,0E5h,025h
        db   09Eh,008h,0D9h,030h,01Fh,0A5h,08Bh,04Dh,006h,089h,084h,0E9h,047h,032h,025h,022h
        db   0F9h,09Fh,038h,0DDh,078h,078h,064h,072h,0BBh,04Bh,0FAh,033h,000h,02Bh,096h,051h
        db   0C4h,08Bh,0FEh,0FFh,0F8h,0F5h,0F6h,0FAh,066h,003h,011h,0A8h,08Bh,09Ch,054h,09Ch
        db   087h,08Ah,048h,0FEh,06Dh,022h,032h,0A2h,073h,0FAh,0F6h,021h,022h,002h,088h,06Ah
        db   060h,096h,0E3h,09Eh,013h,05Bh,064h,004h,0B6h,006h,0F1h,09Eh,0F7h,0F8h,0FBh,0FEh
        db   04Ch,045h,0B0h,07Eh,080h,002h,058h,0E2h,019h,004h,0D9h,0ACh,0C2h,0FDh,0A6h,080h
        db   03Ch,0C0h,082h,03Fh,03Eh,0C3h,040h,0FFh,07Ch,0ABh,0E3h,02Fh,090h,0B8h,03Eh,050h
        db   006h,0EEh,014h,04Eh,0C5h,05Dh,006h,0C6h,0ABh,0BAh,01Bh,000h,0BEh,01Eh,0C0h,0D7h
        db   013h,048h,05Eh,008h,095h,02Fh,014h,09Ah,0CCh,053h,080h,0FEh,0C8h,04Bh,03Bh,08Ch
        db   090h,091h,002h,0DCh,041h,09Ch,0C6h,01Ah,038h,005h,075h,01Ch,030h,02Fh,057h,0C0h
        db   06Eh,003h,07Ah,075h,042h,082h,081h,0BFh,0FEh,0F1h,00Fh,09Fh,0F8h,001h,00Bh,03Fh
        db   0C1h,010h,01Bh,0DFh,019h,0F0h,073h,001h,0FAh,024h,08Fh,03Eh,035h,0B2h,008h,0DEh
        db   069h,0E8h,0F9h,083h,053h,030h,013h,04Eh,001h,007h,07Ch,031h,00Fh,018h,02Eh,0C8h
        db   000h,042h,04Fh,011h,08Fh,0E2h,01Fh,0B6h,049h,004h,01Dh,07Dh,0B0h,015h,063h,0F3h
        db   0B7h,032h,07Ch,074h,031h,0A6h,081h,074h,08Ch,02Bh,084h,077h,004h,069h,037h,04Bh
        db   0C1h,0AEh,04Ch,0F0h,00Eh,062h,02Eh,001h,07Dh,022h,02Bh,0D1h,054h,068h,04Dh,013h
        db   0B8h,068h,0D0h,0ABh,095h,07Dh,092h,0A9h,0FDh,078h,044h,0B3h,0B1h,0F3h,04Fh,0D8h
        db   013h,04Ch,0D1h,080h,025h,033h,0D5h,0D8h,04Fh,081h,0A0h,04Fh,0D9h,0C2h,090h,045h
        db   033h,005h,0A2h,0F9h,0DCh,0F1h,003h,007h,039h,0E9h,0F0h,001h,08Fh,03Fh,09Fh,0E2h
        db   037h,037h,0A4h,01Dh,088h,07Eh,0BCh,0E8h,0FCh,00Ch,0ECh,07Fh,013h,0F5h,005h,0FBh
        db   003h,006h,0F2h,067h,0FDh,0F9h,002h,004h,0F7h,007h,0FEh,0D6h,009h,0F4h,0A6h,0FFh
        db   0F8h,000h,011h,0FFh,0E8h,00Ah,00Eh,0E3h,01Ah,0F5h,0FBh,012h,0EDh,0EAh,0FCh,0DEh
        db   0FEh,009h,001h,0C7h,084h,0D0h,0E4h,0D1h,06Ch,029h,045h,090h,01Ah,084h,0B7h,0F2h
        db   065h,006h,0F4h,00Ah,07Bh,0FEh,004h,0CFh,007h,0F8h,04Eh,0ABh,0FFh,07Dh,0F9h,008h
        db   0F7h,0DFh,0F6h,00Ch,077h,0EFh,014h,0F3h,0DBh,065h,0FAh,00Eh,0F2h,073h,0FBh,0FCh
        db   073h,0F4h,0FEh,0EDh,020h,006h,0CCh,0F7h,0E9h,00Ch,0DFh,0ADh,002h,04Fh,0F9h,00Bh
        db   0F6h,004h,0E0h,00Dh,0F0h,076h,0FFh,0B3h,007h,0E3h,0F5h,010h,0EEh,05Bh,00Fh,0F8h
        db   013h,001h,0FEh,0EAh,003h,0F6h,00Dh,0A4h,09Ch,0F5h,0B6h,053h,011h,049h,06Ah,005h
        db   0FEh,0D1h,0EFh,0FDh,0FBh,00Fh,0EFh,0B2h,09Fh,007h,0F1h,00Eh,0FAh,0A0h,021h,0B2h
        db   089h,0E1h,000h,004h,0B3h,027h,0EBh,00Dh,0FDh,0F8h,00Bh,0F1h,009h,0FEh,002h,0BDh
        db   0FAh,089h,001h,07Fh,004h,0F5h,00Ch,062h,0D2h,04Bh,0A2h,0F8h,084h,047h,0ABh,00Ah
        db   09Ah,0FFh,002h,048h,017h,0EFh,007h,0FAh,036h,099h,007h,0B1h,0A5h,071h,009h,0F3h
        db   006h,0FDh,0EBh,015h,0F4h,003h,07Bh,001h,0FDh,015h,035h,0E2h,09Dh,0DBh,0FCh,002h
        db   0A6h,02Bh,009h,0E9h,02Ch,021h,07Dh,026h,0D1h,018h,075h,004h,005h,062h,0DDh,00Ch
        db   009h,0F8h,0E1h,039h,0F2h,00Dh,0F4h,000h,080h,048h,000h,000h,011h,031h,003h,000h
        db   000h,0B0h,088h,0A8h,0A9h,099h,0BAh,07Bh,064h,033h,031h,033h,093h,088h,0AAh,08Ah
        db   05Ah,000h,020h,0FDh,0FEh,007h,0FDh,00Ah,0F7h,00Eh,075h,009h,0DAh,004h,015h,006h
        db   0F9h,005h,0FCh,00Fh,0E7h,0CBh,028h,0B9h,0F5h,0FFh,0FAh,00Eh,0D8h,01Ah,0E3h,0FDh
        db   0FEh,0EAh,0A5h,003h,066h,0FCh,000h,080h,003h,0AEh,010h,003h,00Bh,0FCh,006h,009h
        db   00Dh,01Eh,0F0h,01Dh,007h,0F6h,017h,000h,060h,001h,02Fh,0F1h,002h,0F7h,0F6h,0C5h
        db   0FCh,0F5h,0CBh,0FDh,0EFh,0F8h,0CBh,0F3h,002h,0FAh,028h,003h,000h,001h,017h,002h
        db   005h,004h,04Bh,003h,006h,037h,032h,072h,007h,001h,009h,0A9h,0EAh,06Eh,008h,004h
        db   005h,092h,046h,09Ah,068h,076h,001h,000h,0C3h,0BDh,0FFh,0F5h,052h,0FBh,0BCh,0FCh
        db   0FDh,0FAh,0FEh,046h,0AEh,0F9h,001h,05Dh,0FFh,0FDh,094h,000h,01Ah,083h,05Eh,003h
        db   0FCh,002h,0FEh,0EAh,0C9h,0ADh,008h,043h,010h,044h,040h,0FFh,084h,095h,0FEh,0E4h
        db   022h,048h,018h,054h,0FEh,041h,0A0h,06Dh,055h,018h,023h,0DCh,050h,085h,058h,0EEh
        db   049h,0A8h,024h,008h,029h,06Dh,090h,089h,0BCh,0DAh,002h,014h,0A8h,012h,0A4h,02Bh
        db   004h,00Dh,093h,008h,0D0h,036h,003h,090h,050h,082h,015h,010h,059h,022h,0B4h,000h
        db   024h,099h,021h,0C8h,028h,051h,000h,068h,08Ah,012h,0A9h,002h,0CAh,002h,015h,042h
        db   035h,008h,006h,0A1h,010h,001h,038h,000h,0B2h,0D2h,012h,034h,0AFh,022h,090h,018h
        db   010h,00Ah,0CCh,00Fh,010h,01Fh,062h,080h,010h,048h,08Bh,060h,0B4h,022h,080h,0FAh
        db   04Eh,02Dh,041h,004h,088h,04Ch,044h,060h,004h,020h,010h,004h,081h,03Ch,020h,000h
        db   0E5h,00Ah,030h,032h,060h,040h,08Fh,001h,086h,00Ah,050h,0F5h,040h,07Dh,021h,00Ch
        db   051h,081h,08Bh,007h,0A9h,080h,0B3h,002h,023h,084h,040h,0A0h,0E8h,0C0h,0EDh,042h
        db   044h,009h,062h,003h,086h,00Fh,0A2h,001h,021h,007h,086h,0A9h,000h,093h,089h,060h
        db   0C0h,040h,080h,0ABh,083h,03Ah,003h,01Ch,000h,070h,042h,040h,0F5h,007h,0AEh,01Dh
        db   0AAh,00Bh,038h,00Fh,030h,004h,080h,063h,001h,067h,0D5h,002h,0C3h,000h,090h,0B4h
        db   000h,05Ah,08Fh,001h,080h,022h,002h,05Eh,030h,000h,004h,000h,096h,0D7h,028h,042h
        db   000h,008h,0BFh,0FFh,00Fh,00Bh,0E0h,01Ah,0F8h,0F5h,007h,0B9h,0FDh,0DCh,0AFh,0FCh
        db   008h,0FAh,003h,031h,0CBh,0D8h,00Ch,013h,0FBh,008h,007h,0A7h,0BFh,0FBh,003h,0F9h
        db   004h,0F7h,0F8h,0E8h,0F1h,0EEh,0ECh,0F6h,0FEh,0CDh,002h,05Bh,0FDh,007h,0F7h,010h
        db   00Eh,013h,00Ah,062h,006h,003h,027h,052h,0BEh,0F2h,002h,0F6h,0FCh,0FEh,076h,0F8h
        db   008h,0CDh,007h,0FBh,03Ch,046h,0CAh,0EBh,001h,0B5h,0FAh,07Fh,0F8h,0FFh,0F2h,007h
        db   0F9h,005h,000h,0ABh,065h,004h,08Ah,0CCh,003h,03Dh,014h,0D5h,011h,009h,0F2h,007h
        db   0FAh,001h,05Ch,0D7h,000h,085h,0FCh,0C6h,092h,0FAh,04Ah,0FDh,069h,08Fh,0F2h,02Bh
        db   003h,0F1h,01Bh,0FFh,0F9h,06Ah,05Dh,002h,073h,014h,087h,0DAh,0BEh,001h,007h,00Eh
        db   0DCh,006h,00Ah,0CEh,05Dh,00Dh,0BDh,004h,05Dh,077h,0FDh,008h,049h,0B3h,0D6h,001h
        db   0F6h,0BCh,0F7h,00Eh,0ECh,0FFh,0A6h,0FAh,0BDh,036h,0F6h,005h,0CCh,0E4h,0F7h,0E6h
        db   0FCh,013h,0E8h,008h,002h,004h,0FEh,0C6h,034h,0F6h,076h,00Fh,09Dh,0D5h,09Ah,0EDh
        db   0D7h,00Eh,0F8h,00Dh,0BFh,00Ah,0FBh,0FDh,00Ch,0C9h,0F7h,004h,0F6h,006h,0B4h,065h
        db   09Bh,0F9h,008h,0EDh,00Eh,0EAh,007h,0EDh,077h,00Dh,0FAh,00Ah,035h,0B7h,0D4h,0B6h
        db   0F6h,0F2h,0F5h,000h,007h,096h,049h,0E1h,0E0h,0FAh,06Bh,006h,0F5h,0DFh,008h,0F9h
        db   0FCh,004h,0E3h,0B4h,0E4h,0AEh,0DBh,006h,0F4h,0B5h,000h,0C6h,087h,0F7h,00Ah,0D5h
        db   0DAh,010h,0BBh,0F5h,00Bh,05Ah,002h,00Bh,0B4h,0BDh,0FBh,057h,09Bh,0F6h,05Eh,075h
        db   0FDh,0D9h,0EFh,0F2h,0F0h,005h,0FCh,0E5h,003h,001h,0FBh,08Ah,007h,02Fh,00Ch,0F6h
        db   00Ah,03Dh,0EDh,0B6h,075h,0F5h,00Dh,0F4h,07Dh,0F9h,00Ch,0EFh,008h,09Bh,03Eh,04Fh
        db   031h,044h,0B8h,090h,0E3h,0BAh,007h,0C1h,0FFh,00Ch,0DAh,009h,06Bh,005h,0EFh,078h
        db   048h,07Ch,043h,0FCh,026h,0F0h,0A8h,0F2h,0FAh,00Ch,0F7h,0FDh,05Ah,00Fh,028h,006h
        db   0FBh,0E6h,0F4h,0DBh,004h,003h,072h,05Ah,00Bh,0B8h,00Dh,0DAh,006h,07Eh,07Ah,007h
        db   0FFh,0F2h,008h,0FFh,0FBh,006h,0FCh,0AEh,0ECh,06Ch,05Fh,0EBh,00Fh,0F6h,00Bh,0F5h
        db   0EFh,0B6h,0BBh,000h,005h,0BDh,02Bh,045h,0FFh,05Fh,07Ch,0C8h,001h,006h,026h,0E3h
        db   02Eh,06Fh,0F7h,009h,0A3h,006h,09Fh,0CDh,0D7h,06Ah,03Ch,0DFh,0FDh,041h,0B6h,062h
        db   007h,066h,032h,049h,047h,049h,02Fh,0E1h,0DDh,06Eh,0F8h,0C3h,07Ah,03Bh,07Ah,097h
        db   0ADh,00Ch,0EBh,0FCh,0F7h,084h,005h,06Fh,009h,0F0h,013h,0F6h,0C6h,005h,0F9h,00Eh
        db   096h,0D6h,0B7h,0F8h,0B7h,0EBh,0F1h,0CCh,0FBh,09Ch,007h,06Bh,0FCh,005h,00Ch,0F5h
        db   0EDh,0ADh,0FFh,0B1h,0A7h,074h,02Ah,0C3h,0DDh,0DAh,061h,07Ah,07Bh,079h,0B0h,0F7h
        db   087h,058h,03Dh,05Fh,0E4h,07Ch,0FDh,00Ch,046h,059h,005h,065h,0DBh,04Eh,0A1h,0F5h
        db   056h,03Bh,07Ah,0ABh,05Fh,022h,007h,005h,091h,025h,0FBh,0AEh,017h,03Dh,032h,0B6h
        db   0F6h,00Fh,0D6h,010h,0C5h,0DBh,0FCh,066h,0F7h,0F3h,00Dh,0FBh,0F7h,0AEh,0FCh,00Ch
        db   033h,0BAh,008h,0F8h,00Dh,0EBh,0F4h,0BAh,0F5h,0B2h,0FBh,0CCh,0FAh,0B4h,0EEh,0B6h
        db   003h,005h,0F1h,002h,01Eh,094h,0CFh,0FEh,00Ch,0F4h,005h,0C2h,03Ah,047h,009h,065h
        db   0F7h,003h,0AFh,076h,0F0h,007h,0F6h,08Ah,0CBh,0AEh,0FAh,004h,074h,001h,0F2h,0FFh
        db   08Eh,06Ah,0F7h,08Bh,0E9h,028h,09Dh,089h,0FCh,0D2h,014h,0E3h,064h,042h,0F1h,05Ch
        db   00Bh,07Fh,046h,0FCh,0F6h,041h,06Fh,0F2h,0F9h,007h,04Dh,0F7h,0B0h,0C0h,0C5h,04Fh
        db   0F5h,00Fh,0FAh,0BBh,00Eh,0F4h,086h,004h,079h,0FCh,0C7h,0FCh,05Fh,036h,0FAh,004h
        db   004h,0BCh,01Eh,076h,0D3h,0D1h,0A1h,0FAh,0A6h,0DAh,06Ah,000h,09Eh,019h,0FDh,009h
        db   0F3h,03Bh,00Ah,0F2h,043h,008h,07Bh,058h,06Dh,03Bh,009h,047h,0E1h,0E6h,054h,0CFh
        db   01Eh,0FEh,087h,0F2h,0FEh,088h,00Ah,07Eh,02Ah,022h,0F2h,0BCh,0E2h,0A2h,078h,056h
        db   0F5h,0D3h,0BAh,0AEh,02Fh,035h,072h,006h,007h,0F2h,097h,032h,0C3h,00Fh,0E5h,0E7h
        db   012h,016h,02Bh,0D4h,0DDh,0E9h,09Dh,047h,0CDh,0FAh,07Bh,069h,08Dh,0E7h,0B9h,0D2h
        db   04Bh,0FAh,009h,0DFh,0ECh,070h,0E9h,0C7h,0E0h,0C3h,077h,0FEh,008h,06Fh,061h,0C7h
        db   035h,0C2h,0EFh,057h,0FDh,03Ah,08Eh,03Eh,0B5h,003h,087h,0DEh,06Bh,059h,047h,0E6h
        db   0D1h,019h,0E2h,0AEh,04Ah,006h,0B3h,031h,093h,0A5h,08Eh,06Fh,0FFh,0A1h,049h,08Eh
        db   036h,041h,065h,009h,0EDh,0CAh,048h,0B8h,03Eh,09Ch,072h,0FBh,0ABh,028h,0CFh,017h
        db   098h,0C9h,086h,0B8h,006h,09Bh,0AFh,031h,041h,0E8h,07Bh,00Ah,039h,061h,058h,012h
        db   0B6h,0D3h,054h,0CEh,054h,027h,073h,0FCh,049h,028h,0D3h,05Fh,09Ch,0F5h,099h,07Ch
        db   024h,0E7h,0DCh,004h,06Bh,024h,0A5h,071h,047h,072h,0FCh,036h,05Eh,0E5h,037h,055h
        db   0B8h,0E7h,0CDh,004h,0F3h,08Ch,0F9h,0F4h,08Eh,033h,0D3h,091h,0C4h,0CFh,0EDh,01Eh
        db   0CEh,0EBh,086h,09Eh,0F6h,084h,0EFh,0B6h,0BBh,08Bh,0D3h,007h,07Bh,0E1h,053h,0CCh
        db   006h,0BDh,0D2h,0B1h,054h,08Dh,0FEh,013h,097h,093h,0B2h,0DCh,08Dh,0F4h,066h,0D3h
        db   08Ch,0EBh,030h,0B3h,049h,0AAh,02Bh,079h,06Bh,005h,06Ch,098h,0C2h,008h,019h,07Dh
        db   0F6h,08Ch,0C8h,007h,070h,061h,0BAh,003h,08Dh,0F3h,037h,0FEh,062h,075h,0FCh,046h
        db   043h,0E3h,0CCh,0C5h,040h,099h,0CCh,07Ch,0BFh,098h,009h,058h,036h,0C5h,0F7h,0B0h
        db   068h,076h,050h,038h,039h,052h,029h,07Ah,087h,026h,001h,012h,0DDh,0F5h,077h,072h
        db   006h,0ECh,000h,02Eh,08Eh,0D0h,0E7h,00Ah,0F1h,0C8h,004h,0B0h,05Dh,0CAh,0D5h,06Dh
        db   0F2h,034h,051h,06Fh,0A9h,0B3h,06Dh,08Ch,03Ah,07Bh,069h,002h,03Ah,061h,007h,01Fh
        db   0C4h,0C7h,019h,0E5h,0E3h,04Bh,092h,04Dh,0B4h,001h,07Bh,0A0h,0B2h,02Eh,0A7h,007h
        db   0F7h,004h,013h,068h,054h,092h,0C6h,0C5h,0D3h,008h,0B2h,01Fh,057h,063h,086h,093h
        db   039h,0D4h,0CFh,025h,0CDh,065h,0A1h,0D5h,009h,06Dh,0F9h,050h,075h,02Ah,06Fh,07Ah
        db   0FBh,04Ah,0E4h,0CEh,03Bh,080h,08Bh,084h,027h,0D2h,01Dh,0D9h,05Ah,02Ah,02Eh,088h
        db   0EBh,078h,017h,0F0h,066h,0FAh,0EEh,0DCh,0A6h,030h,03Eh,0ACh,0B9h,02Fh,056h,059h
        db   0E0h,0F8h,05Ah,0F3h,029h,04Ch,092h,014h,07Bh,066h,089h,0D3h,0B2h,0F4h,018h,090h
        db   0C2h,0FDh,0C4h,05Ch,0B3h,0FEh,00Ah,025h,0C8h,0C7h,011h,0DBh,046h,039h,0D2h,081h
        db   0FEh,0DFh,002h,0CEh,04Fh,02Dh,0D9h,003h,0ECh,03Bh,02Bh,0EEh,034h,0A8h,025h,067h
        db   062h,037h,08Fh,0A1h,00Fh,05Ah,002h,02Dh,051h,039h,040h,07Bh,0E3h,015h,0D1h,051h
        db   07Fh,0D5h,0AFh,049h,03Dh,07Dh,07Bh,003h,09Ah,0EFh,0F5h,06Ah,09Ch,0B0h,0CFh,0E2h
        db   0BEh,00Bh,08Eh,0CEh,063h,054h,0DDh,06Bh,0E8h,000h,0A7h,082h,0AFh,063h,0DFh,0CAh
        db   06Eh,033h,027h,083h,0C5h,0D7h,0B4h,04Ah,02Ah,07Ch,0ADh,079h,0A4h,009h,00Bh,009h
        db   07Fh,009h,0AEh,0AFh,0A0h,04Dh,027h,025h,082h,0D5h,04Ch,069h,02Fh,0C1h,063h,086h
        db   00Eh,0D8h,0F4h,0EDh,0C2h,034h,033h,06Dh,09Bh,0C9h,08Dh,061h,02Dh,019h,0ADh,0B3h
        db   0F0h,0C4h,043h,0D1h,078h,067h,019h,074h,005h,074h,054h,071h,009h,06Fh,046h,016h
        db   00Bh,0F5h,082h,00Eh,052h,092h,0B7h,062h,062h,0DBh,068h,08Bh,067h,097h,0D8h,054h
        db   097h,01Dh,064h,05Eh,08Ah,096h,0ECh,030h,0D9h,0C9h,0C6h,0ACh,039h,003h,071h,01Dh
        db   083h,0CAh,0FAh,041h,012h,087h,094h,0C6h,029h,08Fh,042h,005h,079h,018h,075h,0FEh
        db   08Ah,0E3h,060h,014h,08Ah,016h,04Ch,04Dh,085h,04Ch,0A0h,0B7h,08Ch,049h,087h,051h
        db   010h,047h,0FAh,040h,049h,0C7h,0ECh,0C2h,076h,05Bh,0C9h,012h,062h,07Eh,0B4h,046h
        db   030h,0B3h,04Bh,0CEh,091h,0C2h,005h,041h,04Eh,0AAh,030h,022h,0BBh,090h,00Ah,071h
        db   091h,094h,0CAh,092h,050h,083h,0AEh,009h,09Ch,036h,031h,050h,098h,002h,0EFh,090h
        db   0D0h,0B0h,0E2h,048h,0C7h,02Dh,032h,09Ch,024h,064h,020h,0B2h,082h,0B5h,0F5h,032h
        db   09Eh,022h,088h,08Bh,0BDh,0E7h,028h,0E8h,00Eh,0D6h,054h,030h,00Fh,014h,00Bh,067h
        db   048h,08Bh,0A8h,015h,00Dh,039h,082h,0F2h,029h,09Eh,093h,041h,004h,006h,047h,0D7h
        db   0A8h,02Bh,02Dh,0F1h,090h,011h,040h,0BDh,068h,014h,00Fh,01Ch,0C7h,009h,003h,041h
        db   0C7h,089h,0C2h,0F5h,047h,024h,02Eh,00Eh,0D1h,080h,010h,09Ah,009h,0C6h,0CAh,01Bh
        db   045h,07Dh,011h,001h,0CDh,00Ah,0AAh,089h,034h,016h,091h,0DDh,022h,00Ch,085h,056h
        db   051h,006h,0E5h,082h,05Fh,060h,02Eh,029h,0D2h,093h,0D6h,052h,068h,08Ah,091h,0B3h
        db   0EEh,040h,034h,037h,091h,00Dh,0D4h,060h,013h,089h,0C1h,06Ch,090h,099h,09Ah,040h
        db   044h,076h,005h,091h,035h,0B0h,000h,016h,008h,036h,005h,0D1h,071h,081h,030h,062h
        db   02Ah,047h,074h,0F2h,002h,0FBh,034h,082h,009h,02Dh,043h,017h,0A1h,011h,074h,09Ch
        db   0C4h,024h,042h,00Dh,025h,07Bh,047h,062h,0DAh,026h,0D8h,032h,068h,05Eh,082h,0E5h
        db   022h,008h,0B6h,00Dh,069h,0ACh,023h,01Ah,027h,082h,07Ch,01Ah,0D0h,082h,01Eh,06Bh
        db   08Eh,061h,029h,090h,002h,0D4h,002h,05Eh,02Fh,028h,012h,0B2h,063h,06Dh,0A0h,08Ah
        db   004h,093h,057h,0C5h,0A2h,012h,00Bh,02Bh,041h,028h,072h,022h,003h,0A3h,082h,030h
        db   030h,029h,0E4h,08Dh,0FDh,070h,056h,01Ah,0C3h,047h,045h,004h,0B2h,019h,086h,0FDh
        db   065h,05Bh,050h,043h,013h,0A0h,012h,008h,065h,06Ch,0D0h,06Dh,02Eh,005h,0E6h,040h
        db   0F1h,058h,01Dh,01Eh,06Eh,0A6h,025h,03Ah,053h,0E3h,084h,030h,0A9h,095h,030h,04Dh
        db   003h,054h,012h,034h,045h,072h,01Ch,019h,021h,0A0h,0CEh,036h,0B0h,01Bh,09Ch,028h
        db   022h,051h,022h,0D8h,07Ah,009h,06Ah,083h,02Eh,033h,02Fh,08Ah,040h,08Bh,008h,042h
        db   07Bh,0A8h,00Dh,02Ah,0C9h,03Dh,021h,03Ah,008h,042h,09Fh,024h,006h,0C8h,0AAh,0A3h
        db   07Ch,038h,03Eh,081h,082h,0A1h,024h,0C2h,031h,03Ah,0E8h,017h,04Eh,0C8h,09Eh,0D8h
        db   036h,018h,01Eh,0D2h,010h,008h,00Bh,003h,066h,094h,060h,0EDh,050h,008h,014h,0C5h
        db   0D2h,063h,066h,0D8h,074h,0C1h,0EAh,022h,025h,0AEh,001h,0C9h,090h,01Dh,02Dh,048h
        db   0D4h,007h,077h,01Fh,0EBh,085h,082h,061h,031h,0B0h,07Ah,0D4h,01Fh,0CEh,01Ch,0B3h
        db   040h,06Ah,08Ch,086h,00Dh,042h,083h,030h,031h,08Dh,040h,061h,0B8h,0CEh,0E8h,002h
        db   0DEh,04Fh,0DCh,025h,0D8h,066h,032h,081h,0B6h,020h,0A5h,000h,023h,041h,0DBh,0A0h
        db   097h,0B6h,040h,037h,021h,01Ah,00Ah,0C6h,081h,0A2h,0C2h,068h,00Ah,02Ch,00Ah,0B9h
        db   024h,0A9h,011h,057h,040h,02Ah,0EAh,008h,0A7h,006h,0E3h,085h,056h,071h,06Ah,044h
        db   0C0h,038h,0A0h,04Ch,090h,09Dh,0C6h,040h,0C5h,038h,056h,009h,0FBh,01Dh,0FEh,0B2h
        db   000h,0FFh,043h,0C2h,0A9h,0A1h,061h,044h,045h,0B0h,025h,048h,009h,09Dh,037h,018h
        db   0ADh,091h,00Bh,012h,083h,0F3h,081h,054h,018h,028h,03Ah,00Eh,04Eh,003h,05Ch,035h
        db   06Ch,028h,0B8h,02Ch,0D0h,016h,005h,081h,0D6h,030h,02Fh,0C8h,064h,001h,021h,060h
        db   007h,020h,029h,04Ah,082h,086h,0A8h,016h,094h,085h,02Ah,0C2h,089h,042h,0A7h,0C0h
        db   0D0h,021h,0ABh,000h,063h,086h,08Eh,023h,01Ch,026h,000h,062h,013h,0ADh,051h,024h
        db   000h,080h,002h,044h,024h,042h,006h,056h,060h,001h,000h,062h,006h,021h,050h,051h
        db   033h,0A7h,06Ch,002h,020h,022h,044h,064h,016h,011h,075h,044h,024h,000h,000h,002h
        db   0B0h,003h,053h,068h,07Dh,092h,0A7h,0BCh,0D1h,0E6h,0FBh,010h,025h,03Ah,04Fh,064h
        db   079h,08Eh,0A3h,0B8h,0CDh,0E2h,0F7h,00Ch,021h,036h,04Bh,060h,075h,08Ah,09Fh,0B4h
        db   0C9h,0DEh,0F3h,008h,01Dh,032h,047h,05Ch,071h,086h,09Bh,0B0h,0C5h,0DAh,0EFh,004h
        db   019h,02Eh,043h,058h,06Dh,082h,097h,0ACh,000h,0C0h,001h,000h,000h,004h,020h,005h
        db   011h,0DAh,0E2h,0B0h,080h,0F5h,022h,02Ah,0B7h,0EDh,03Bh,04Bh,043h,0DAh,0F1h,000h
        db   007h,031h,052h,006h,05Bh,0D0h,062h,08Bh,00Dh,0B3h,0C2h,08Fh,0D6h,097h,09Bh,0F2h
        db   016h,04Dh,041h,056h,000h,000h,002h,0A1h,0E0h,040h,0E1h,010h,020h,0E2h,008h,010h
        db   0E3h,004h,008h,0E4h,005h,000h,0E0h,00Bh,0DDh,0D2h,0D1h,080h,06Ch,0D0h,010h,0C1h
        db   026h,084h,088h,0D3h,051h,018h,048h,0D3h,000h,000h,0E0h,040h,0FFh,008h,031h,053h
        db   0E0h,0E1h,097h,0D3h,0FFh,0FEh,0BDh,0CAh,034h,0D1h,00Eh,000h,022h,04Bh,0D4h,0E4h
        db   0A5h,0D5h,0E1h,05Bh,03Bh,02Fh,0D3h,0B6h,0D8h,050h,0D9h,0BAh,0F1h,032h,0DCh,0FCh
        db   0EDh,073h,002h,0D1h,0FFh,004h,008h,06Fh,026h,081h,07Eh,024h,066h,02Ah,039h,078h
        db   0E9h,031h,0B9h,0DFh,097h,07Eh,0B5h,0F2h,04Ah,0D1h,026h,0CFh,0A6h,0DDh,0E9h,03Eh
        db   0FFh,0CEh,09Ah,025h,046h,033h,0E5h,022h,064h,0D1h,0EEh,02Eh,035h,0BFh,031h,0F3h
        db   0DFh,0C1h,0D9h,05Ch,05Ah,04Ah,09Eh,097h,0A4h,037h,0C3h,00Eh,07Fh,000h,0A7h,021h
        db   0DFh,02Ah,006h,016h,0E5h,0BEh,010h,0FCh,0C1h,0D1h,0D9h,078h,0DDh,0E1h,0FDh,0F1h
        db   001h,000h,0A3h,077h,031h,0DFh,0E4h,058h,0D1h,0E5h,036h,02Fh,033h,060h,036h,001h
        db   046h,07Bh,0BCh,022h,047h,0D5h,0B9h,026h,02Fh,02Fh,097h,008h,03Ah,0DCh,0CFh,0C3h
        db   034h,007h,0AEh,07Bh,0C5h,0E4h,069h,037h,04Fh,015h,037h,01Ah,035h,0D9h,055h,01Dh
        db   0FFh,03Eh,07Fh,0DBh,0FEh,0E6h,001h,0CAh,027h,059h,0D3h,0E1h,027h,05Ch,0DBh,021h
        db   0C1h,00Eh,0B2h,0DEh,0B2h,0A4h,031h,09Ch,0CDh,0E0h,0CBh,004h,077h,0CFh,06Fh,044h
        db   024h,06Eh,053h,0C9h,066h,051h,038h,08Dh,051h,055h,021h,0ECh,0C2h,069h,0B0h,060h
        db   0ACh,047h,0CBh,07Eh,0B1h,033h,0A0h,064h,0CCh,070h,0E9h,0C9h,02Ch,0ADh,0F1h,0BFh
        db   0FDh,0AAh,0F9h,07Eh,035h,0D5h,0A0h,070h,00Dh,070h,067h,0E6h,023h,0D8h,06Ch,01Ah
        db   0C2h,026h,0DAh,02Ch,037h,004h,0F5h,0C4h,0EEh,03Ch,00Eh,00Bh,0C4h,0D5h,007h,0D1h
        db   02Ah,019h,017h,08Eh,0E5h,0DCh,00Ch,021h,001h,0C9h,03Ah,0C2h,003h,080h,0BCh,0E0h
        db   034h,028h,02Fh,078h,089h,0E0h,01Ah,0B4h,02Bh,03Ah,0B1h,091h,00Fh,063h,019h,0CFh
        db   0CEh,0D4h,0D5h,014h,012h,02Fh,048h,048h,002h,03Ah,0D0h,03Ch,080h,0C3h,068h,000h
        db   092h,017h,0A5h,000h,0C2h,080h,0F3h,0BFh,0DFh,088h,010h,045h,003h,07Eh,05Ch,047h
        db   05Eh,000h,001h,044h,010h,0D1h,0BEh,047h,009h,0ACh,003h,041h,0DCh,0AEh,0A6h,081h
        db   033h,04Eh,039h,0E7h,04Ch,002h,0BDh,0ADh,075h,07Bh,05Bh,017h,05Eh,082h,081h,005h
        db   084h,0D4h,0D6h,004h,030h,051h,08Bh,008h,093h,006h,083h,0ABh,011h,06Bh,021h,08Bh
        db   02Fh,0FCh,020h,08Fh,083h,0F8h,0FDh,08Eh,012h,058h,007h,083h,072h,05Dh,0D9h,0F3h
        db   0CEh,038h,0E5h,09Ch,033h,09Eh,0B7h,0B5h,06Eh,06Fh,04Bh,07Eh,02Fh,002h,00Bh,008h
        db   092h,05Fh,026h,046h,005h,004h,0F2h,0BBh,003h,0E0h,06Fh,05Dh,0A2h,001h,0A3h,0F4h
        db   0ADh,007h,0A7h,008h,084h,044h,0FCh,005h,009h,00Dh,093h,06Bh,00Ah,030h,031h,008h
        db   0C9h,068h,0D4h,0D5h,08Bh,001h,0D7h,05Dh,0AEh,0ECh,085h,066h,09Bh,00Bh,054h,081h
        db   0C5h,0ABh,0A2h,04Ch,0E2h,059h,086h,0D8h,04Fh,05Fh,00Ch,00Dh,0C7h,064h,083h,05Bh
        db   00Eh,087h,0CAh,00Fh,051h,07Eh,038h,0FBh,0F2h,0C3h,001h,044h,094h,09Fh,0CFh,01Eh
        db   0FDh,044h,0EFh,0B8h,0D9h,075h,0EFh,058h,0E5h,028h,0ABh,090h,028h,0BFh,004h,047h
        db   011h,0D5h,03Bh,096h,0BCh,0D3h,088h,05Dh,0EFh,000h,0A3h,0D4h,009h,019h,02Fh,054h
        db   0CBh,0FFh,010h,089h,000h,0ABh,03Ch,008h,044h,0A2h,0E1h,011h,06Dh,08Ah,0ADh,072h
        db   074h,03Eh,075h,011h,08Bh,0F3h,073h,012h,08Ch,03Ah,0C7h,010h,08Ch,0EFh,081h,0A2h
        db   0A3h,0D3h,0A4h,0F4h,085h,0D4h,0FEh,00Ah,06Ah,08Dh,01Fh,0F4h,0ACh,00Fh,04Fh,013h
        db   08Bh,0D4h,08Ch,09Ch,0C8h,0B6h,012h,02Eh,084h,067h,0E9h,010h,0E6h,062h,0B9h,00Ch
        db   0B0h,057h,0EAh,011h,012h,054h,0B1h,077h,0D6h,00Fh,002h,089h,094h,0AEh,08Eh,035h
        db   0FFh,08Dh,012h,050h,0C0h,022h,004h,045h,01Eh,00Fh,0E0h,054h,02Ch,061h,0EFh,033h
        db   056h,03Dh,0E0h,057h,0B2h,048h,056h,0D5h,067h,050h,069h,09Dh,08Dh,0DEh,033h,0E0h
        db   059h,09Fh,0B1h,09Eh,012h,02Ah,062h,031h,0C3h,08Eh,0FBh,014h,08Fh,063h,051h,015h
        db   0C6h,016h,079h,085h,062h,073h,014h,084h,061h,077h,015h,017h,090h,0C9h,0D7h,03Ch
        db   080h,00Fh,0E8h,00Ch,08Bh,0E6h,0E7h,00Dh,08Ch,096h,0EDh,0EFh,018h,019h,091h,0DFh
        db   070h,047h,000h,0D8h,0DAh,090h,088h,05Dh,010h,0FBh,0F3h,006h,05Fh,001h,061h,0E2h
        db   0C2h,002h,0AFh,01Ah,01Bh,084h,0BFh,098h,059h,01Ch,01Dh,0C3h,0E4h,01Eh,09Ah,08Ah
        db   0CFh,0CDh,007h,018h,003h,0D4h,08Eh,0FFh,012h,01Fh,01Bh,08Dh,08Ah,001h,043h,0E0h
        db   0E5h,08Ch,020h,0CEh,06Ch,015h,003h,0AFh,09Ah,0B1h,06Ah,0D9h,065h,0BCh,0CFh,0A9h
        db   013h,07Bh,097h,095h,0F7h,079h,08Ah,0B7h,00Dh,06Fh,011h,08Ah,06Bh,095h,06Bh,0EDh
        db   07Dh,0FBh,0CDh,08Bh,0E3h,0DDh,051h,060h,03Ch,05Dh,039h,0AEh,089h,094h,085h,0E2h
        db   016h,0FDh,0E1h,015h,035h,059h,0C7h,035h,0D9h,0C2h,06Bh,01Ah,0C5h,018h,09Dh,055h
        db   015h,0EDh,0DEh,0E1h,099h,052h,0BAh,08Eh,0D6h,0FCh,05Ch,04Ah,040h,001h,03Ch,059h
        db   00Fh,070h,02Ah,0BCh,0DBh,0FBh,08Ch,055h,00Fh,0CCh,0BAh,00Eh,022h,055h,0ADh,09Fh
        db   0E1h,0D2h,0E0h,0BBh,075h,0F8h,0EEh,008h,070h,0F7h,025h,0D0h,0DDh,053h,078h,0B7h
        db   047h,03Bh,077h,004h,080h,0ADh,03Dh,083h,092h,05Ch,0D3h,03Dh,0F0h,0BEh,0E7h,00Dh
        db   0C0h,002h,0DEh,05Ch,0C2h,00Eh,000h,07Bh,0E8h,0D4h,002h,0DBh,05Ah,0B7h,0B7h,0C5h
        db   00Fh,0E1h,093h,0AEh,0FCh,021h,022h,081h,09Bh,00Fh,091h,062h,016h,0DAh,0C2h,000h
        db   024h,004h,018h,0DDh,0B9h,023h,0A1h,002h,0C1h,03Bh,081h,005h,05Bh,084h,006h,00Eh
        db   0B6h,0B7h,085h,03Dh,012h,0DDh,0B7h,02Dh,006h,007h,0CAh,031h,097h,003h,004h,024h
        db   0CFh,093h,03Bh,0E0h,0A8h,092h,0D9h,0A4h,0F3h,0CEh,01Bh,0AEh,097h,0BDh,0C9h,060h
        db   08Fh,002h,08Fh,0DAh,05Ah,067h,0CFh,0A0h,025h,02Eh,036h,01Fh,08Bh,09Eh,0F2h,044h
        db   000h,098h,044h,002h,018h,09Dh,04Ah,00Ch,025h,00Dh,0DEh,002h,00Bh,0D9h,008h,032h
        db   070h,0B0h,0BDh,02Dh,0ACh,044h,0F7h,0EDh,05Bh,00Ch,081h,062h,032h,02Ah,031h,04Bh
        db   02Ah,0F1h,094h,092h,0ECh,0E9h,0D3h,0D8h,0FBh,07Dh,0F8h,062h,045h,007h,007h,03Bh
        db   00Bh,035h,063h,091h,02Fh,022h,03Dh,0DAh,058h,0B8h,00Ah,019h,044h,04Ch,008h,017h
        db   037h,033h,05Dh,0DCh,01Ah,069h,01Bh,028h,0F3h,018h,003h,025h,09Ch,009h,085h,01Dh
        db   026h,00Bh,0B2h,083h,033h,056h,09Dh,042h,097h,063h,01Ch,00Bh,0D0h,038h,0BFh,01Bh
        db   03Ch,0CEh,02Ah,070h,0DCh,080h,043h,03Dh,0E0h,0C9h,0D7h,0CAh,0DFh,019h,00Ch,00Dh
        db   079h,017h,0A3h,00Fh,0EBh,005h,023h,0FAh,08Dh,053h,041h,0D4h,098h,0BFh,003h,00Dh
        db   04Bh,08Eh,0CFh,073h,06Fh,058h,0C5h,061h,000h,0ABh,0A7h,031h,071h,0F5h,0DEh,0F7h
        db   01Bh,0DDh,0ECh,07Ah,00Bh,022h,073h,0F5h,056h,0A1h,0D5h,007h,01Dh,08Dh,01Bh,008h
        db   00Bh,03Ch,0CEh,02Ah,0A0h,0AAh,0F7h,024h,097h,03Fh,062h,00Ch,0C0h,0EAh,0FFh,096h
        db   0D4h,095h,000h,0A3h,044h,008h,09Ch,097h,01Fh,095h,0E8h,0C9h,04Fh,04Ch,097h,08Fh
        db   069h,07Ch,0F9h,0F8h,0AEh,0D8h,05Ch,014h,0D6h,090h,009h,021h,040h,0F8h,0C8h,0D0h
        db   007h,025h,0F8h,0C8h,0A0h,074h,000h,03Eh,03Ah,08Ch,0FBh,0F4h,0D7h,0D7h,026h,01Dh
        db   031h,0D5h,0E9h,027h,0F0h,0F8h,023h,0F7h,02Ch,01Fh,08Bh,0D1h,028h,0C0h,089h,07Ah
        db   096h,097h,041h,04Eh,031h,007h,008h,0A2h,0ABh,0C2h,094h,097h,0F3h,0F9h,000h,0BBh
        db   043h,0E9h,0BEh,01Bh,0D3h,013h,0E0h,0BBh,06Fh,08Bh,0F2h,0A9h,001h,05Ch,0EBh,036h
        db   09Bh,0E4h,0E0h,0DEh,084h,04Fh,0D8h,0E8h,0D1h,004h,0B7h,0CBh,0B8h,098h,0C6h,0ECh
        db   032h,0ECh,0BDh,09Ah,08Ah,01Fh,0ECh,0ECh,0F1h,0C0h,000h,002h,0F9h,08Ah,044h,0B1h
        db   050h,0BBh,0B2h,0B5h,06Eh,07Ch,099h,081h,005h,0B0h,095h,0DEh,07Bh,0ABh,08Bh,0ABh
        db   03Bh,004h,099h,056h,0A6h,09Dh,04Dh,005h,0F4h,0A1h,044h,03Fh,006h,098h,09Dh,0F9h
        db   086h,03Dh,0D8h,060h,0EEh,093h,098h,06Fh,03Eh,053h,02Ch,094h,094h,07Ch,027h,090h
        db   038h,08Ch,015h,09Ah,088h,0D0h,009h,084h,06Eh,080h,0F1h,09Ah,023h,0E0h,0D5h,07Ch
        db   021h,0FAh,079h,0F2h,022h,08Ah,07Ch,0A9h,08Bh,016h,0D5h,091h,075h,04Eh,0C2h,05Ch
        db   0F7h,072h,024h,04Ch,028h,06Fh,069h,05Dh,06Ch,097h,0CBh,068h,0E5h,023h,065h,08Eh
        db   053h,098h,063h,04Eh,0D8h,0A7h,068h,08Bh,060h,08Ah,04Dh,05Dh,091h,009h,05Ah,04Eh
        db   058h,0F8h,055h,084h,04Eh,053h,070h,050h,0EAh,032h,04Eh,060h,0BAh,00Ch,04Ch,0D2h
        db   065h,04Ah,0B2h,048h,0A8h,0CBh,046h,0A8h,0CBh,044h,0A8h,0CBh,042h,090h,02Eh,0A3h
        db   040h,02Eh,093h,03Eh,06Fh,0D8h,063h,006h,0E6h,03Eh,03Ch,0EAh,0D2h,03Ah,00Bh,025h
        db   03Ah,0DFh,009h,039h,04Eh,037h,085h,026h,036h,074h,034h,082h,053h,032h,0A1h,0C9h
        db   031h,03Dh,0ECh,071h,0B8h,08Bh,030h,00Fh,0BFh,09Ah,047h,0E0h,02Eh,05Ah,024h,05Fh
        db   02Dh,02Eh,006h,097h,02Ch,0ADh,0B7h,02Ah,02Eh,0B7h,029h,04Ah,0CFh,0CFh,006h,0F3h
        db   094h,09Bh,08Bh,0C9h,01Ch,0BFh,0C1h,0FDh,0AAh,029h,02Fh,085h,062h,00Ch,05Bh,086h
        db   02Ah,0BCh,0B8h,0AAh,0B1h,07Ah,07Ah,0CDh,0DBh,023h,03Ah,035h,063h,09Eh,01Dh,05Ah
        db   0DCh,029h,08Eh,049h,04Ch,0BFh,0A9h,013h,09Dh,0C8h,02Fh,031h,0C2h,087h,08Eh,068h
        db   01Dh,098h,0F9h,033h,0C4h,056h,083h,075h,0A3h,0F3h,0D8h,0BCh,0E9h,06Eh,0A8h,039h
        db   072h,0E0h,02Bh,08Ch,038h,078h,02Ch,08Bh,027h,067h,02Dh,08Ch,031h,0DBh,02Eh,0B8h
        db   050h,0F4h,0F5h,066h,009h,05Ch,03Ah,0B0h,057h,000h,08Ah,0D2h,0F9h,0E9h,0BAh,02Bh
        db   09Ch,045h,057h,0BDh,0E9h,0BAh,02Fh,03Ah,08Dh,0D3h,0DBh,017h,02Eh,0DAh,08Dh,025h
        db   03Bh,0AEh,02Fh,0CBh,084h,054h,078h,07Eh,0FCh,07Dh,005h,0CFh,0CFh,0AFh,04Fh,0E0h
        db   0FCh,0ACh,000h,0E7h,0C7h,01Ah,0F0h,010h,0D9h,080h,087h,0C8h,006h,03Ah,044h,01Ch
        db   08Ch,087h,0C8h,062h,0B6h,000h,058h,0FAh,03Eh,01Ah,045h,02Eh,0B8h,076h,0C5h,018h
        db   0B6h,091h,087h,0E8h,0AAh,037h,05Dh,0F7h,045h,0A7h,071h,07Ah,07Bh,01Ah,0A2h,05Dh
        db   04Bh,062h,01Ah,022h,053h,055h,03Ah,059h,032h,0F4h,064h,07Dh,031h,006h,013h,0E0h
        db   02Dh,039h,030h,07Dh,007h,08Bh,03Fh,0E9h,031h,0ADh,0C4h,027h,0ABh,041h,0AAh,0A7h
        db   093h,065h,05Fh,0D4h,0DBh,0CEh,07Ch,08Ah,016h,061h,087h,0A6h,030h,09Dh,08Eh,0C4h
        db   0F4h,008h,08Bh,00Bh,002h,03Ch,01Dh,0C2h,077h,08Eh,0E4h,052h,0B4h,02Dh,098h,07Ah
        db   0D1h,059h,036h,0F3h,06Eh,074h,01Eh,009h,0A0h,0FAh,0D8h,008h,0DFh,08Eh,091h,00Fh
        db   093h,02Dh,08Bh,0B0h,066h,072h,0DDh,059h,096h,0B1h,065h,011h,0D6h,04Ch,0AEh,03Bh
        db   0F2h,09Ch,0BCh,0E9h,0A8h,0C0h,04Eh,0D5h,030h,09Dh,07Eh,0B3h,0CBh,03Bh,0F5h,0DFh
        db   03Fh,032h,085h,04Bh,098h,0D8h,0ADh,089h,0DDh,046h,033h,054h,015h,051h,055h,044h
        db   0DDh,034h,09Eh,0FAh,0F3h,0DFh,0B6h,05Ah,044h,057h,011h,03Dh,035h,052h,054h,044h
        db   055h,001h,049h,08Dh,094h,092h,0B9h,007h,0D0h,03Ah,040h,06Ah,09Fh,07Eh,0D6h,0BBh
        db   0FBh,034h,094h,0A0h,066h,02Eh,0A1h,051h,0D7h,02Dh,06Ah,0D8h,02Dh,014h,0D9h,095h
        db   0BEh,0CEh,0A2h,095h,0DAh,098h,052h,019h,0DCh,01Ah,06Bh,0DEh,048h,008h,093h,058h
        db   068h,07Ch,0DFh,08Fh,007h,0A2h,002h,043h,0BEh,0D0h,0C5h,0C2h,0C6h,062h,0CAh,028h
        db   019h,008h,02Dh,003h,08Ah,01Ch,0C2h,03Bh,0C7h,078h,0F3h,010h,058h,0DCh,0B5h,0ABh
        db   0E0h,0A3h,0B6h,00Dh,0ACh,02Ah,01Bh,0B7h,0ADh,0C4h,0D8h,000h,088h,037h,0B4h,0AAh
        db   008h,047h,0D8h,021h,024h,08Bh,060h,004h,0E6h,0B0h,03Ah,0D1h,0C2h,0B1h,0ACh,006h
        db   095h,0B2h,00Dh,0ADh,02Ah,01Bh,0B3h,0AEh,0B4h,063h,024h,0C6h,031h,063h,084h,0B7h
        db   065h,091h,092h,048h,006h,07Dh,0A1h,0ACh,041h,048h,0BAh,0AFh,00Dh,0AAh,0AAh,0ECh
        db   013h,023h,098h,064h,057h,0A7h,0A0h,024h,005h,0A8h,092h,032h,04Fh,065h,018h,060h
        db   02Bh,0A9h,020h,0F6h,06Dh,062h,023h,0B1h,091h,019h,050h,066h,001h,030h,066h,022h
        db   026h,011h,096h,044h,0CCh,0E6h,0DBh,0EDh,0BDh,0FCh,091h,0BCh,0E6h,0FDh,0AAh,0BBh
        db   076h,07Eh,067h,0BAh,032h,013h,0B1h,011h,0CAh,046h,066h,07Fh,084h,0D3h,029h,09Ch
        db   02Eh,0ACh,0ACh,08Ch,0AFh,01Ch,0E9h,069h,062h,023h,031h,06Eh,0A8h,0BDh,040h,05Ch
        db   0BCh,020h,02Eh,0BBh,010h,017h,0BAh,0D8h,0ECh,032h,0B9h,02Bh,0CCh,00Ah,0B3h,042h
        db   02Ch,00Bh,064h,046h,032h,023h,099h,091h,0BDh,000h,092h,0C9h,028h,009h,057h,0ABh
        db   070h,019h,0C4h,0E6h,061h,0ECh,0DBh,0C4h,046h,058h,0C1h,026h,020h,066h,003h,00Ch
        db   07Bh,091h,0BAh,031h,052h,037h,05Eh,0CBh,0BBh,091h,0DCh,08Dh,089h,0AAh,025h,004h
        db   0B3h,0C2h,0ACh,0A0h,0A9h,092h,0F9h,09Fh,064h,079h,0B7h,068h,0D1h,0B8h,0A8h,04Dh
        db   064h,084h,060h,026h,023h,004h,0B1h,089h,0D8h,048h,0ECh,036h,062h,023h,0B3h,089h
        db   0D8h,008h,0CAh,016h,080h,018h,01Bh,020h,0D3h,091h,001h,02Ah,012h,0FCh,0B2h,091h
        db   026h,0D2h,079h,067h,024h,0C6h,031h,023h,084h,01Dh,00Ch,087h,09Dh,0E0h,0F3h,00Eh
        db   0BFh,0E8h,07Ch,0B9h,019h,041h,00Ch,097h,082h,01Bh,0B7h,0CEh,0A3h,036h,0E6h,0BCh
        db   082h,0A9h,00Ch,023h,097h,061h,042h,0D5h,0C2h,019h,00Fh,08Dh,0D8h,008h,06Dh,0C8h
        db   0C8h,096h,0ABh,00Fh,069h,0ACh,03Eh,05Ch,0F9h,0ADh,070h,011h,096h,00Ch,080h,088h
        db   00Bh,0AEh,07Ch,0E4h,04Dh,0C4h,046h,028h,01Bh,0D9h,04Ch,0C4h,046h,062h,0B7h,0C1h
        db   0BCh,098h,090h,017h,050h,0B6h,000h,018h,0F6h,01Ah,098h,017h,0DFh,067h,02Fh,080h
        db   062h,0CBh,044h,0B6h,06Ch,080h,088h,044h,04Eh,0AAh,000h,0B3h,055h,062h,0ABh,0C4h
        db   056h,021h,00Ch,046h,086h,0B3h,009h,010h,00Ch,003h,0C2h,001h,040h,03Bh,008h,038h
        db   029h,0D1h,000h,080h
