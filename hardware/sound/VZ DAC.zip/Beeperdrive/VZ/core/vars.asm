	align	2
vars:
freq1	dw	100h 		; voice 1 phase delta
freq2	dw	100h		; voice 2 phase delta
freq3	dw	100h		; voice 3 phase delta
freq4	dw	100h		; voice 4 phase delta
freq5	dw	100h		; voice 5 phase delta
wave2	dw	zeros		; voice 2 wave pointer (aligned 256)
wave3	dw	zeros		; voice 3 wave pointer (aligned 256)
wave4	dw	zeros		; voice 4 wave pointer (aligned 256)
wave5	dw	zeros		; voice 5 wave pointer (aligned 256)
wave1	dw	zeros		; voice 1 wave pointer (aligned 256)
frmexit	dw      iloop		; address to exit, when frame finished
