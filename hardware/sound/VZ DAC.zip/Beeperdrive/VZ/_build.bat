echo off
cls
echo.
echo Assembles BEEPER DRIVE for the VZ/Laser.
echo Requires SJASMplus assembler.
echo Edit this batch file and point SJASM below to the correct directory.
echo.
pause
echo.
\vz\tasm\_utils\sjasmplus BEEPERDR.asm
echo.
pause
