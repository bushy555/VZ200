framelen	equ	256
framepad	equ	0

qframe0:
	db  wave4bp0 / 256, wave4bp0 / 256, wave4bp0 / 256, wave4bp0 / 256, wavelead5 / 256
	db  wave4bp2 / 256, wave4bp2 / 256, wave4bp2 / 256, wave4bp2 / 256, wavelead4 / 256
	db  wave4bp4 / 256, wave4bp4 / 256, wave4bp4 / 256, wave4bp4 / 256, wavelead3 / 256
	db  wave4bp4 / 256, wave4bp4 / 256, wave4bp4 / 256, wave4bp4 / 256, wavelead2 / 256
	db  0

qframe1:
	db  wave4bp3 / 256, wave4bp3 / 256, wave4bp3 / 256, wave4bp3 / 256, zeros / 256
	db  wave4bp3 / 256, wave4bp3 / 256, wave4bp3 / 256, wave4bp3 / 256, zeros / 256
	db  wave4bp2 / 256, wave4bp2 / 256, wave4bp2 / 256, wave4bp2 / 256, zeros / 256
	db  wave4bp2 / 256, wave4bp2 / 256, wave4bp2 / 256, wave4bp2 / 256, zeros / 256
	db  0

qframe2:
	db  wave4bp1 / 256, wave4bp1 / 256, wave4bp1 / 256, wave4bp1 / 256, zeros / 256
	db  wave4bp1 / 256, wave4bp1 / 256, wave4bp1 / 256, wave4bp1 / 256, zeros / 256
	db  wave4bp0 / 256, wave4bp0 / 256, wave4bp0 / 256, wave4bp0 / 256, zeros / 256
	db  wave4bp0 / 256, wave4bp0 / 256, wave4bp0 / 256, wave4bp0 / 256, zeros / 256
	db  0

qframe3:
	db  wave4bp0 / 256, wave4bp0 / 256, wave4bp0 / 256, wave4bp0 / 256, zeros / 256
	db  wave4bp1 / 256, wave4bp1 / 256, wave4bp1 / 256, wave4bp1 / 256, zeros / 256
	db  wave4bp2 / 256, wave4bp2 / 256, wave4bp2 / 256, wave4bp2 / 256, zeros / 256
	db  wave4bp2 / 256, wave4bp2 / 256, wave4bp2 / 256, wave4bp2 / 256, zeros / 256
	db  0

qframe4:
	db  wave4bp0 / 256, wave4bp0 / 256, wave4bp0 / 256, wave4bp0 / 256, wavelead5 / 256
	db  wave4bp0 / 256, wave4bp0 / 256, wave4bp0 / 256, wave4bp0 / 256, wavelead4 / 256
	db  wave4bp0 / 256, wave4bp0 / 256, wave4bp0 / 256, wave4bp0 / 256, wavelead3 / 256
	db  wave4bp0 / 256, wave4bp0 / 256, wave4bp0 / 256, wave4bp0 / 256, wavelead2 / 256
	db  0

qframe5:
	db  zeros / 256, zeros / 256, zeros / 256, zeros / 256, zeros / 256
	db  zeros / 256, zeros / 256, zeros / 256, zeros / 256, zeros / 256
	db  zeros / 256, zeros / 256, zeros / 256, zeros / 256, zeros / 256
	db  zeros / 256, zeros / 256, zeros / 256, zeros / 256, zeros / 256
	db  0

qframe6:
	db  zeros / 256, zeros / 256, wave4bp0 / 256, wavebp0 / 256, wavelead5 / 256
	db  zeros / 256, zeros / 256, wave4bp2 / 256, wavebp2 / 256, wavelead4 / 256
	db  wavebass0 / 256, wavebass0 / 256, wave4bp4 / 256, wavebp4 / 256, wavelead3 / 256
	db  wavebass0 / 256, wavebass0 / 256, wave4bp4 / 256, wavebp4 / 256, wavelead2 / 256
	db  0

qframe7:
	db  wavebass2 / 256, wavebass2 / 256, wave4bp3 / 256, wavebp3 / 256, wavelead5 / 256
	db  wavebass1 / 256, wavebass1 / 256, wave4bp3 / 256, wavebp3 / 256, wavelead4 / 256
	db  wavebass0 / 256, wavebass0 / 256, wave4bp2 / 256, wavebp2 / 256, wavelead3 / 256
	db  wavebass0 / 256, wavebass0 / 256, wave4bp2 / 256, wavebp2 / 256, wavelead2 / 256
	db  0

qframe8:
	db  wavebass2 / 256, wavebass2 / 256, wave4bp1 / 256, wavebp1 / 256, wavelead5 / 256
	db  wavebass1 / 256, wavebass1 / 256, wave4bp1 / 256, wavebp1 / 256, wavelead4 / 256
	db  wavebass0 / 256, wavebass0 / 256, wave4bp0 / 256, wavebp0 / 256, wavelead3 / 256
	db  wavebass0 / 256, wavebass0 / 256, wave4bp0 / 256, wavebp0 / 256, wavelead2 / 256
	db  0

qframe9:
	db  wavebass2 / 256, wavebass2 / 256, wave4bp0 / 256, wavebp0 / 256, wavelead5 / 256
	db  wavebass1 / 256, wavebass1 / 256, wave4bp1 / 256, wavebp1 / 256, wavelead4 / 256
	db  wavebass0 / 256, wavebass0 / 256, wave4bp2 / 256, wavebp2 / 256, wavelead3 / 256
	db  wavebass0 / 256, wavebass0 / 256, wave4bp2 / 256, wavebp2 / 256, wavelead2 / 256
	db  0

qframe10:
	db  wavebass2 / 256, wavebass2 / 256, wave4bp2 / 256, wavebp2 / 256, wavelead5 / 256
	db  wavebass1 / 256, wavebass1 / 256, wave4bp0 / 256, wavebp0 / 256, wavelead4 / 256
	db  wavebass0 / 256, wavebass0 / 256, zeros / 256, zeros / 256, wavelead3 / 256
	db  wavebass0 / 256, wavebass0 / 256, zeros / 256, zeros / 256, wavelead2 / 256
	db  0

qframe11:
	db  wavebass2 / 256, wavebass2 / 256, zeros / 256, zeros / 256, wavelead5 / 256
	db  wavebass1 / 256, wavebass1 / 256, zeros / 256, zeros / 256, wavelead4 / 256
	db  wavebass0 / 256, wavebass0 / 256, zeros / 256, zeros / 256, wavelead3 / 256
	db  wavebass0 / 256, wavebass0 / 256, zeros / 256, zeros / 256, wavelead2 / 256
	db  0

qframe12:
	db  wavebass2 / 256, wavebass2 / 256, wave4bp0 / 256, wavebp0 / 256, wavelead5 / 256
	db  wavebass1 / 256, wavebass1 / 256, wave4bp1 / 256, wavebp1 / 256, wavelead4 / 256
	db  wavebass0 / 256, wavebass0 / 256, wave4bp0 / 256, wavebp0 / 256, wavelead3 / 256
	db  wavebass0 / 256, wavebass0 / 256, zeros / 256, zeros / 256, wavelead2 / 256
	db  0

qframe13:
	db  zeros / 256, zeros / 256, zeros / 256, zeros / 256, wavelead5 / 256
	db  zeros / 256, zeros / 256, zeros / 256, zeros / 256, wavelead4 / 256
	db  wavebass0 / 256, wavebass0 / 256, zeros / 256, zeros / 256, wavelead3 / 256
	db  wavebass0 / 256, wavebass0 / 256, zeros / 256, zeros / 256, wavelead2 / 256
	db  0

qframe14:
	db  wavebass2 / 256, wavebass2 / 256, wave4bp0 / 256, wavebp0 / 256, wavelead5 / 256
	db  wavebass1 / 256, wavebass1 / 256, wave4bp2 / 256, wavebp2 / 256, wavelead4 / 256
	db  wavebass0 / 256, wavebass0 / 256, wave4bp4 / 256, wavebp4 / 256, wavelead3 / 256
	db  wavebass0 / 256, wavebass0 / 256, wave4bp4 / 256, wavebp4 / 256, wavelead2 / 256
	db  0

qframe15:
	db  zeros / 256, zeros / 256, wave4bp1 / 256, wavebp1 / 256, wavelead5 / 256
	db  zeros / 256, zeros / 256, wave4bp1 / 256, wavebp1 / 256, wavelead4 / 256
	db  wavebass0 / 256, wavebass0 / 256, wave4bp0 / 256, wavebp0 / 256, wavelead3 / 256
	db  wavebass0 / 256, wavebass0 / 256, wave4bp0 / 256, wavebp0 / 256, wavelead2 / 256
	db  0

qframe16:
	db  wavebass2 / 256, wavebass2 / 256, wave4bp0 / 256, wavebp0 / 256, wavelead5 / 256
	db  wavebass1 / 256, wavebass1 / 256, wave4bp0 / 256, wavebp0 / 256, wavelead4 / 256
	db  wavebass0 / 256, wavebass0 / 256, wave4bp0 / 256, wavebp0 / 256, wavelead3 / 256
	db  wavebass0 / 256, wavebass0 / 256, wave4bp0 / 256, wavebp0 / 256, wavelead2 / 256
	db  0

qframe17:
	db  zeros / 256, zeros / 256, wave4bp0 / 256, wavebp0 / 256, wavelead5 / 256
	db  zeros / 256, zeros / 256, wave4bp0 / 256, wavebp0 / 256, wavelead4 / 256
	db  wavebass0 / 256, wavebass0 / 256, wave4bp0 / 256, wavebp0 / 256, wavelead3 / 256
	db  wavebass0 / 256, wavebass0 / 256, wave4bp0 / 256, wavebp0 / 256, wavelead2 / 256
	db  0

qframe18:
	db  zeros / 256, zeros / 256, wave5bp0 / 256, wavebp0 / 256, wavelead5 / 256
	db  zeros / 256, zeros / 256, wave5bp2 / 256, wavebp2 / 256, wavelead4 / 256
	db  wavebass0 / 256, wavebass0 / 256, wave5bp4 / 256, wavebp4 / 256, wavelead3 / 256
	db  wavebass0 / 256, wavebass0 / 256, wave5bp4 / 256, wavebp4 / 256, wavelead2 / 256
	db  0

qframe19:
	db  wavebass2 / 256, wavebass2 / 256, wave5bp3 / 256, wavebp3 / 256, wavelead5 / 256
	db  wavebass1 / 256, wavebass1 / 256, wave5bp3 / 256, wavebp3 / 256, wavelead4 / 256
	db  wavebass0 / 256, wavebass0 / 256, wave5bp2 / 256, wavebp2 / 256, wavelead3 / 256
	db  wavebass0 / 256, wavebass0 / 256, wave5bp2 / 256, wavebp2 / 256, wavelead2 / 256
	db  0

qframe20:
	db  wavebass2 / 256, wavebass2 / 256, wave5bp1 / 256, wavebp1 / 256, wavelead5 / 256
	db  wavebass1 / 256, wavebass1 / 256, wave5bp1 / 256, wavebp1 / 256, wavelead4 / 256
	db  wavebass0 / 256, wavebass0 / 256, wave5bp0 / 256, wavebp0 / 256, wavelead3 / 256
	db  wavebass0 / 256, wavebass0 / 256, wave5bp0 / 256, wavebp0 / 256, wavelead2 / 256
	db  0

qframe21:
	db  wavebass2 / 256, wavebass2 / 256, wave5bp0 / 256, wavebp0 / 256, wavelead5 / 256
	db  wavebass1 / 256, wavebass1 / 256, wave5bp1 / 256, wavebp1 / 256, wavelead4 / 256
	db  wavebass0 / 256, wavebass0 / 256, wave5bp2 / 256, wavebp2 / 256, wavelead3 / 256
	db  wavebass0 / 256, wavebass0 / 256, wave5bp2 / 256, wavebp2 / 256, wavelead2 / 256
	db  0

qframe22:
	db  wavebass2 / 256, wavebass2 / 256, wave5bp0 / 256, wavebp0 / 256, wavelead5 / 256
	db  wavebass1 / 256, wavebass1 / 256, wave5bp2 / 256, wavebp2 / 256, wavelead4 / 256
	db  wavebass0 / 256, wavebass0 / 256, wave5bp4 / 256, wavebp4 / 256, wavelead3 / 256
	db  wavebass0 / 256, wavebass0 / 256, wave5bp4 / 256, wavebp4 / 256, wavelead2 / 256
	db  0

qframe23:
	db  wavebass2 / 256, wavebass2 / 256, wave5bp2 / 256, wavebp2 / 256, wavelead5 / 256
	db  wavebass1 / 256, wavebass1 / 256, wave5bp0 / 256, wavebp0 / 256, wavelead4 / 256
	db  wavebass0 / 256, wavebass0 / 256, zeros / 256, zeros / 256, wavelead3 / 256
	db  wavebass0 / 256, wavebass0 / 256, zeros / 256, zeros / 256, wavelead2 / 256
	db  0

qframe24:
	db  wavebass2 / 256, wavebass2 / 256, wave5bp0 / 256, wavebp0 / 256, wavelead5 / 256
	db  wavebass1 / 256, wavebass1 / 256, wave5bp1 / 256, wavebp1 / 256, wavelead4 / 256
	db  wavebass0 / 256, wavebass0 / 256, wave5bp0 / 256, wavebp0 / 256, wavelead3 / 256
	db  wavebass0 / 256, wavebass0 / 256, zeros / 256, zeros / 256, wavelead2 / 256
	db  0

qframe25:
	db  zeros / 256, zeros / 256, wavelead8 / 256, zeros / 256, wavelead8 / 256
	db  zeros / 256, zeros / 256, wavelead7 / 256, zeros / 256, wavelead7 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead6 / 256, zeros / 256, wavelead6 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead5 / 256, zeros / 256, wavelead5 / 256
	db  0

qframe26:
	db  wavebass2 / 256, wavebass2 / 256, wavelead4 / 256, zeros / 256, wavelead4 / 256
	db  wavebass1 / 256, wavebass1 / 256, wavelead3 / 256, zeros / 256, wavelead3 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead2 / 256, zeros / 256, wavelead2 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead1 / 256, zeros / 256, wavelead1 / 256
	db  0

qframe27:
	db  wavebass2 / 256, wavebass2 / 256, wavelead1 / 256, zeros / 256, wavelead1 / 256
	db  wavebass1 / 256, wavebass1 / 256, wavelead1 / 256, zeros / 256, wavelead1 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead1 / 256, zeros / 256, wavelead1 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead1 / 256, zeros / 256, wavelead1 / 256
	db  0

qframe28:
	db  wavebass2 / 256, wavebass2 / 256, wavelead7 / 256, zeros / 256, wavelead7 / 256
	db  wavebass1 / 256, wavebass1 / 256, wavelead6 / 256, zeros / 256, wavelead6 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead5 / 256, zeros / 256, wavelead5 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead4 / 256, zeros / 256, wavelead4 / 256
	db  0

qframe29:
	db  zeros / 256, zeros / 256, wavelead3 / 256, zeros / 256, wavelead3 / 256
	db  zeros / 256, zeros / 256, wavelead2 / 256, zeros / 256, wavelead2 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead1 / 256, zeros / 256, wavelead1 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead1 / 256, zeros / 256, wavelead1 / 256
	db  0

qframe30:
	db  wavebass2 / 256, wavebass2 / 256, wavelead0 / 256, zeros / 256, wavelead0 / 256
	db  wavebass1 / 256, wavebass1 / 256, wavelead0 / 256, zeros / 256, wavelead0 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead0 / 256, zeros / 256, wavelead0 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead0 / 256, zeros / 256, wavelead0 / 256
	db  0

qframe31:
	db  wavebass2 / 256, wavebass2 / 256, wavelead5 / 256, zeros / 256, wavelead8 / 256
	db  wavebass1 / 256, wavebass1 / 256, wavelead4 / 256, zeros / 256, wavelead7 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead3 / 256, zeros / 256, wavelead6 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead3 / 256, zeros / 256, wavelead5 / 256
	db  0

qframe32:
	db  wavebass2 / 256, wavebass2 / 256, wavelead2 / 256, zeros / 256, wavelead4 / 256
	db  wavebass1 / 256, wavebass1 / 256, wavelead2 / 256, zeros / 256, wavelead3 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead1 / 256, zeros / 256, wavelead2 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead1 / 256, zeros / 256, wavelead1 / 256
	db  0

qframe33:
	db  zeros / 256, zeros / 256, wavelead0 / 256, zeros / 256, wavelead1 / 256
	db  zeros / 256, zeros / 256, wavelead0 / 256, zeros / 256, wavelead1 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead0 / 256, zeros / 256, wavelead1 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead0 / 256, zeros / 256, wavelead1 / 256
	db  0

qframe34:
	db  wavebass2 / 256, wavebass2 / 256, wavelead3 / 256, zeros / 256, wavelead7 / 256
	db  wavebass1 / 256, wavebass1 / 256, wavelead3 / 256, zeros / 256, wavelead6 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead2 / 256, zeros / 256, wavelead5 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead2 / 256, zeros / 256, wavelead4 / 256
	db  0

qframe35:
	db  wavebass2 / 256, wavebass2 / 256, wavelead1 / 256, zeros / 256, wavelead3 / 256
	db  wavebass1 / 256, wavebass1 / 256, wavelead1 / 256, zeros / 256, wavelead2 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead1 / 256, zeros / 256, wavelead1 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead1 / 256, zeros / 256, wavelead1 / 256
	db  0

qframe36:
	db  zeros / 256, zeros / 256, wavelead5 / 256, zeros / 256, wavelead5 / 256
	db  zeros / 256, zeros / 256, wavelead4 / 256, zeros / 256, wavelead4 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead3 / 256, zeros / 256, wavelead3 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead3 / 256, zeros / 256, wavelead3 / 256
	db  0

qframe37:
	db  wavebass2 / 256, wavebass2 / 256, wavelead2 / 256, zeros / 256, wavelead2 / 256
	db  wavebass1 / 256, wavebass1 / 256, wavelead2 / 256, zeros / 256, wavelead2 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead1 / 256, zeros / 256, wavelead1 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead1 / 256, zeros / 256, wavelead1 / 256
	db  0

qframe38:
	db  wavebass2 / 256, wavebass2 / 256, wavelead3 / 256, zeros / 256, wavelead3 / 256
	db  wavebass1 / 256, wavebass1 / 256, wavelead3 / 256, zeros / 256, wavelead3 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead2 / 256, zeros / 256, wavelead2 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead2 / 256, zeros / 256, wavelead2 / 256
	db  0

qframe39:
	db  zeros / 256, zeros / 256, wavelead1 / 256, zeros / 256, wavelead1 / 256
	db  zeros / 256, zeros / 256, wavelead1 / 256, zeros / 256, wavelead1 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead1 / 256, zeros / 256, wavelead1 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead1 / 256, zeros / 256, wavelead1 / 256
	db  0

qframe40:
	db  zeros / 256, zeros / 256, wavelead0 / 256, zeros / 256, wavelead0 / 256
	db  zeros / 256, zeros / 256, wavelead0 / 256, zeros / 256, wavelead0 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead0 / 256, zeros / 256, wavelead0 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead0 / 256, zeros / 256, wavelead0 / 256
	db  0

qframe41:
	db  zeros / 256, zeros / 256, wavelead3 / 256, zeros / 256, wavelead3 / 256
	db  zeros / 256, zeros / 256, wavelead3 / 256, zeros / 256, wavelead3 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead2 / 256, zeros / 256, wavelead2 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead2 / 256, zeros / 256, wavelead2 / 256
	db  0

qframe42:
	db  wavebass2 / 256, wavebass2 / 256, wavelead7 / 256, zeros / 256, wavelead8 / 256
	db  wavebass1 / 256, wavebass1 / 256, wavelead6 / 256, zeros / 256, wavelead7 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead5 / 256, zeros / 256, wavelead6 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead4 / 256, zeros / 256, wavelead5 / 256
	db  0

qframe43:
	db  zeros / 256, zeros / 256, wavelead3 / 256, zeros / 256, wavelead4 / 256
	db  zeros / 256, zeros / 256, wavelead2 / 256, zeros / 256, wavelead3 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead1 / 256, zeros / 256, wavelead2 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead1 / 256, zeros / 256, wavelead1 / 256
	db  0

qframe44:
	db  wavebass2 / 256, wavebass2 / 256, wavelead0 / 256, zeros / 256, wavelead1 / 256
	db  wavebass1 / 256, wavebass1 / 256, wavelead0 / 256, zeros / 256, wavelead1 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead0 / 256, zeros / 256, wavelead1 / 256
	db  wavebass0 / 256, wavebass0 / 256, wavelead0 / 256, zeros / 256, wavelead1 / 256
	db  0

