seq_default:
seq_D_default:
	dw	sample_kick + framepad - 256, 251h
	dw	zeros + framepad - 256, 6F3h
	dw	zeros + framepad - 256, 947h
	dw	zeros + framepad - 256, 0B08h
	dw	sample_snare + framepad - 256, 0EBAh
	dw	sample_snare + 400h + framepad - 256, 0DE7h
	dw	sample_snare + 800h + framepad - 256, 947h
	dw	zeros + framepad - 256, 0B08h

seq_D_interbrk:
	dw	sample_kick + framepad - 256, 251h
	dw	sample_snare + framepad - 256, 6F3h
	dw	sample_snare + 400h + framepad - 256, 947h
	dw	sample_snare + 800h + framepad - 256, 0B08h
	dw	sample_snare + framepad - 256, 0EBAh
	dw	sample_snare + 400h + framepad - 256, 0DE7h
	dw	sample_snare + 800h + framepad - 256, 947h
	dw	zeros + framepad - 256, 0B08h

seq_D_rest:
	dw	zeros + framepad - 256, 4A3h
	dw	zeros + framepad - 256, 6F3h
	dw	zeros + framepad - 256, 947h
	dw	zeros + framepad - 256, 0B08h
	dw	zeros + framepad - 256, 0EBAh
	dw	zeros + framepad - 256, 0DE7h
	dw	zeros + framepad - 256, 947h
	dw	zeros + framepad - 256, 0B08h

seq_D_kicks:
	dw	sample_kick + framepad - 256, 251h
	dw	zeros + framepad - 256, 6F3h
	dw	zeros + framepad - 256, 947h
	dw	zeros + framepad - 256, 0B08h
	dw	sample_kick + framepad - 256, 0EBAh
	dw	zeros + framepad - 256, 0DE7h
	dw	zeros + framepad - 256, 947h
	dw	zeros + framepad - 256, 0B08h

seq_B_default:
	dw	sample_kick + framepad - 256, 3AEh
	dw	zeros + framepad - 256, 6F3h
	dw	zeros + framepad - 256, 75Dh
	dw	zeros + framepad - 256, 947h
	dw	sample_snare + framepad - 256, 0EBAh
	dw	sample_snare + 400h + framepad - 256, 0DE7h
	dw	sample_snare + 800h + framepad - 256, 947h
	dw	zeros + framepad - 256, 0B08h

seq_B_break:
	dw	sample_kick + framepad - 256, 3AEh
	dw	sample_snare + framepad - 256, 6F3h
	dw	sample_snare + 400h + framepad - 256, 75Dh
	dw	sample_kick + framepad - 256, 947h
	dw	sample_snare + framepad - 256, 0EBAh
	dw	sample_snare + 400h + framepad - 256, 0DE7h
	dw	sample_snare + framepad - 256, 947h
	dw	sample_snare + framepad - 256, 0B08h

