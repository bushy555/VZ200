
plsvariant0:
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7, =balance_many
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant1:
	nop			;= 4, =balance_many
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant2:
	ret nz			;= 5, =balance_many
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant3:
	inc     hl		;= 6, =balance_many
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant4:
	ld      l, (hl)		;= 7, =balance_many
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant5:
	ret nz			;= 5, =balance_many
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant6:
	inc     hl		;= 6, =balance_many
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant7:
	ld      l, (hl)		;= 7, =balance_many
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant8:
	add     hl, hl		;= 11, =balance_many
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant9:
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant10:
	ld      sp, vars	;= 10
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant11:
	nop			;= 4, =balance_many
	ld      sp, vars	;= 10
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant12:
	ret nz			;= 5, =balance_many
	ld      sp, vars	;= 10
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	inc     de		;= 6, =balance_many
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant13:
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant14:
	ld      l, (hl)		;= 7, =balance_many
	ld      sp, vars	;= 10
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant15:
	ret nz			;= 5, =balance_many
	ld      sp, vars	;= 10
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant16:
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	pop     de		;= 10, wave3
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant17:
	ld      l, (hl)		;= 7, =balance_many
	ld      sp, vars	;= 10
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant18:
	add     hl, hl		;= 11, =balance_many
	ld      sp, vars	;= 10
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant19:
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant20:
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant21:
	nop			;= 4, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	pop     de		;= 10, wave3
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant22:
	ret nz			;= 5, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant23:
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant24:
	ld      l, (hl)		;= 7, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	ex      de, hl		;= 4
	add     (hl)		;= 7
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant25:
	ret nz			;= 5, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant26:
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant27:
	ld      l, (hl)		;= 7, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant28:
	add     hl, hl		;= 11, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	add     (hl)		;= 7
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant29:
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant30:
	ld      l, (hl)		;= 7, =balance_many
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant31:
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant32:
	nop			;= 4, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant33:
	ret nz			;= 5, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant34:
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant35:
	ld      l, (hl)		;= 7, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	add     hl, hl		;= 11, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant36:
	ret nz			;= 5, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant37:
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant38:
	ld      l, (hl)		;= 7, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant39:
	add     hl, hl		;= 11, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant40:
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	add     hl, hl		;= 11, =balance_many
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant41:
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	inc     de		;= 6, =balance_many
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant42:
	nop			;= 4, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant43:
	ret nz			;= 5, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant44:
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant45:
	ld      l, (hl)		;= 7, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	add     hl, hl		;= 11, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant46:
	ret nz			;= 5, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant47:
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant48:
	ld      l, (hl)		;= 7, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant49:
	add     hl, hl		;= 11, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	add     hl, hl		;= 11, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant50:
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant51:
	ld      l, (hl)		;= 7, =balance_many
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant52:
	add     hl, hl		;= 11, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant53:
	nop			;= 4, =balance_many
	add     hl, hl		;= 11, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant54:
	ret nz			;= 5, =balance_many
	add     hl, hl		;= 11, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant55:
	inc     hl		;= 6, =balance_many
	add     hl, hl		;= 11, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant56:
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	add     hl, hl		;= 11, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant57:
	nop			;= 4, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant58:
	ret nz			;= 5, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant59:
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant60:
	ld      l, (hl)		;= 7, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant61:
	ret nz			;= 5, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant62:
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	inc     de		;= 6, =balance_many
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant63:
	ld      l, (hl)		;= 7, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant64:
	add     hl, hl		;= 11, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant65:
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant66:
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	add     hl, hl		;= 11, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant67:
	nop			;= 4, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant68:
	ret nz			;= 5, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant69:
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant70:
	ld      l, (hl)		;= 7, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	add     hl, hl		;= 11, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant71:
	ret nz			;= 5, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant72:
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant73:
	ld      l, (hl)		;= 7, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant74:
	add     hl, hl		;= 11, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant75:
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant76:
	ld      l, (hl)		;= 7, =balance_many
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant77:
	add     hl, hl		;= 11, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	add     hl, hl		;= 11, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant78:
	nop			;= 4, =balance_many
	add     hl, hl		;= 11, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant79:
	ret nz			;= 5, =balance_many
	add     hl, hl		;= 11, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant80:
	inc     hl		;= 6, =balance_many
	add     hl, hl		;= 11, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant81:
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	add     hl, hl		;= 11, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant82:
	nop			;= 4, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant83:
	ret nz			;= 5, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant84:
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant85:
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant86:
	nop			;= 4, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant87:
	ret nz			;= 5, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	inc     de		;= 6, =balance_many
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant88:
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant89:
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant90:
	nop			;= 4, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant91:
	ret nz			;= 5, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	add     hl, hl		;= 11, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant92:
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant93:
	ld      l, (hl)		;= 7, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant94:
	ret nz			;= 5, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant95:
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	add     hl, hl		;= 11, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant96:
	ld      l, (hl)		;= 7, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant97:
	add     hl, hl		;= 11, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant98:
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant99:
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant100:
	nop			;= 4, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant101:
	ret nz			;= 5, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant102:
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	add     hl, hl		;= 11, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant103:
	ld      l, (hl)		;= 7, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant104:
	ret nz			;= 5, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant105:
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant106:
	ld      l, (hl)		;= 7, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	add     hl, hl		;= 11, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant107:
	add     hl, hl		;= 11, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant108:
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant109:
	ld      l, (hl)		;= 7, =balance_many
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant110:
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	add     hl, hl		;= 11, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant111:
	nop			;= 4, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	ld      b, h		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant112:
	ret nz			;= 5, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant113:
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	ld      b, h		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant114:
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant115:
	nop			;= 4, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	ld      c, l		;= 4
	inc     hl		;= 6, =balance_many
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	inc     c		;= 4
	ld      l, (hl)		;= 7, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant116:
	ret nz			;= 5, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	inc     c		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant117:
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	ld      c, l		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	inc     c		;= 4
	add     hl, hl		;= 11, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant118:
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	inc     c		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant119:
	nop			;= 4, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	inc     hl		;= 6, =balance_many
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	ld      l, (hl)		;= 7, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant120:
	ret nz			;= 5, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant121:
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	add     hl, hl		;= 11, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant122:
	ld      l, (hl)		;= 7, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant123:
	ret nz			;= 5, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	inc     hl		;= 6, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	ld      a, (de)		;= 7, =balance_many
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant124:
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ex      af, af'		;= 4
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant125:
	ld      l, (hl)		;= 7, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	ld      a, $ff 		;= 7, =balance_set_include_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ex      af, af'		;= 4
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ex      af, af'		;= 4
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	ld      l, (hl)		;= 7, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant126:
	add     hl, hl		;= 11, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	ret nz			;= 5, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	add     hl, hl		;= 11, =balance_many
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ex      af, af'		;= 4
	inc     hl		;= 6, =balance_many
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant127:
	inc     hl		;= 6, =balance_many
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	inc     de		;= 6, =balance_many
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	ret nz			;= 5, =balance_many
	ex      af, af'		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]

plsvariant128:
	ld      l, (hl)		;= 7, =balance_many
	inc     hl		;= 6, =balance_many
	ld      sp, vars	;= 10
	pop     hl		;= 10, freq1
	add     hl, de		;= 11
	pop     de		;= 10, freq2
	add     ix, de		;= 15
	pop     de		;= 10, freq3
	add     iy, de		;= 15
	ex      de, hl		;= 4
	exx			;= 4
	pop     hl		;= 10, freq4
	add     hl, bc		;= 11
	ld      b, h		;= 4
	ld      c, l		;= 4
	cpl			;= 4, =balance_set_exclude_pulse1start
	out     (12), a	;= 11
	; end of pulse 1
	nop			;= 4, =balance_many
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	pop     hl		;= 10, freq5
	add     hl, de		;= 11
	pop     de		;= 10, wave2
	ld      e, ixh		;= 8
	sub     a		;= 4
	out     (12), a	;= 11
	; start of pulse 2
	ld      a, (de)		;= 7, =balance_many
	ld      a, (de)		;= 7
	inc     de		;= 6, =balance_many
	pop     de		;= 10, wave3
	ld      e, iyh		;= 8
	ex      de, hl		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave4
	ld      l, b		;= 4
	add     (hl)		;= 7
	pop     hl		;= 10, wave5
	ld      l, d		;= 4
	add     (hl)		;= 7
	exx			;= 4
	pop     hl		;= 10, wave1
	ld      l, d		;= 4
	add     (hl)		;= 7
	ld      h, b		;= 4, oneshot sample
	ld      l, c		;= 4
	add     (hl)		;= 7
	inc     c		;= 4
	ex      af, af'		;= 4
	out     (12), a	;= 11
	; end of pulse 2
	nop			;= 4, =balance_many
	ex      af, af'		;= 4
	jp nz,	iloop		;= 10
	ret			;= 10, jump [frmexit]
