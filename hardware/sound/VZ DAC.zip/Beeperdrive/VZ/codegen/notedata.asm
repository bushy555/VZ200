section_prelude:
	db	80h
	dw	24Fh, 2BFh, seq_D_rest + 0, 251h, 2C2h
	db	0h
	db	1h
	db	2h
	db	3h
	db	2h
	db	4h
	db	3h
	db	2h
	db	81h
	dw	seq_D_rest + 0
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	81h
	dw	seq_D_rest + 0
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	81h
	dw	seq_D_rest + 0
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	82h
	dw	seq_D_rest + 0
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	81h
	dw	seq_D_rest + 0
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	81h
	dw	seq_D_rest + 0
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	81h
	dw	seq_D_rest + 0
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	81h
	dw	seq_D_kicks + 0
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	81h
	dw	seq_D_kicks + 0
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	4h
	db	83h
	dw	seq_D_kicks + 0, wave4bp1, wave4bp1, wave4bp1, wave4bp1
	db	0h
	db	0h
	db	0h
	db	0h
	db	84h
	dw	wave4bp2, wave4bp2, wave4bp2, wave4bp2
	db	0h
	db	0h
	db	0h
	db	0h
	db	85h
	dw	seq_D_kicks + 0, wave4bp3, wave4bp3, wave4bp3, wave4bp3
	db	0h
	db	0h
	db	0h
	db	0h
	db	84h
	dw	wave4bp4, wave4bp4, wave4bp4, wave4bp4
	db	0h
	db	0h
	db	0h
	db	0h
	db	86h
section_interlude:
	db	87h
	dw	wave4bp0, wave4bp0, wave4bp0, wave4bp0, 24Fh, 2BFh, seq_D_kicks + 0, 251h, 2C2h
	db	0h
	db	0h
	db	0h
	db	0h
	db	0h
	db	0h
	db	0h
	db	0h
	db	81h
	dw	seq_D_kicks + 0
	db	0h
	db	0h
	db	0h
	db	0h
	db	0h
	db	0h
	db	0h
	db	0h
	db	81h
	dw	seq_D_kicks + 0
	db	0h
	db	0h
	db	0h
	db	0h
	db	0h
	db	0h
	db	0h
	db	0h
	db	81h
	dw	seq_D_kicks + 0
	db	0h
	db	0h
	db	0h
	db	0h
	db	0h
	db	0h
	db	0h
	db	0h
	db	81h
	dw	seq_D_kicks + 0
	db	0h
	db	0h
	db	0h
	db	0h
	db	0h
	db	0h
	db	0h
	db	0h
	db	81h
	dw	seq_D_kicks + 0
	db	0h
	db	0h
	db	0h
	db	0h
	db	0h
	db	0h
	db	0h
	db	0h
	db	85h
	dw	seq_D_kicks + 0, wave4bp1, wave4bp1, wave4bp1, wave4bp1
	db	0h
	db	0h
	db	0h
	db	0h
	db	84h
	dw	wave4bp2, wave4bp2, wave4bp2, wave4bp2
	db	0h
	db	0h
	db	0h
	db	0h
	db	85h
	dw	seq_D_kicks + 0, wave4bp3, wave4bp3, wave4bp3, wave4bp3
	db	0h
	db	0h
	db	0h
	db	0h
	db	84h
	dw	wave4bp4, wave4bp4, wave4bp4, wave4bp4
	db	0h
	db	0h
	db	0h
	db	0h
	db	86h
section_final:
	db	88h
	dw	wavereso15, 128h, 2C2h, 251h, 24Fh, 2BFh, seq_D_rest + 0
	db	0h
	db	89h
	dw	wavereso14
	db	1h
	db	89h
	dw	wavereso13
	db	2h
	db	89h
	dw	wavereso12
	db	3h
	db	89h
	dw	wavereso11
	db	2h
	db	89h
	dw	wavereso10
	db	4h
	db	89h
	dw	wavereso9
	db	3h
	db	89h
	dw	wavereso8
	db	2h
	db	8Ah
	dw	seq_D_rest + 0, wavereso7
	db	4h
	db	89h
	dw	wavereso6
	db	3h
	db	89h
	dw	wavereso5
	db	2h
	db	89h
	dw	wavereso4
	db	4h
	db	89h
	dw	wavereso3
	db	3h
	db	89h
	dw	wavereso2
	db	2h
	db	89h
	dw	wavereso1
	db	4h
	db	89h
	dw	wavereso0
	db	2h
	db	81h
	dw	seq_D_rest + 0
	db	5h
	db	5h
	db	5h
	db	5h
	db	5h
	db	5h
	db	5h
	db	5h
	db	86h
section_intro1p1:
	db	8Bh
	dw	127h, 251h, seq_D_default + 0
	db	6h
	db	7h
	db	7h
	db	7h
	db	6h
	db	7h
	db	7h
	db	7h
	db	81h
	dw	seq_D_default + 0
	db	6h
	db	7h
	db	7h
	db	7h
	db	6h
	db	7h
	db	7h
	db	7h
	db	81h
	dw	seq_D_default + 0
	db	6h
	db	7h
	db	7h
	db	7h
	db	6h
	db	7h
	db	7h
	db	7h
	db	81h
	dw	seq_D_default + 0
	db	6h
	db	7h
	db	7h
	db	7h
	db	6h
	db	7h
	db	7h
	db	7h
	db	8Bh
	dw	107h, 211h, seq_D_default + 0
	db	6h
	db	7h
	db	7h
	db	7h
	db	6h
	db	7h
	db	7h
	db	7h
	db	81h
	dw	seq_D_default + 0
	db	6h
	db	7h
	db	7h
	db	7h
	db	6h
	db	7h
	db	7h
	db	7h
	db	81h
	dw	seq_D_default + 0
	db	6h
	db	7h
	db	7h
	db	7h
	db	6h
	db	7h
	db	7h
	db	7h
	db	81h
	dw	seq_D_interbrk + 0
	db	6h
	db	7h
	db	7h
	db	7h
	db	6h
	db	7h
	db	7h
	db	7h
	db	8Bh
	dw	18Ah, 318h, seq_B_default + 0
	db	6h
	db	7h
	db	7h
	db	7h
	db	6h
	db	7h
	db	7h
	db	7h
	db	81h
	dw	seq_B_default + 0
	db	6h
	db	7h
	db	7h
	db	7h
	db	6h
	db	7h
	db	7h
	db	7h
	db	81h
	dw	seq_B_default + 0
	db	6h
	db	7h
	db	7h
	db	7h
	db	6h
	db	7h
	db	7h
	db	7h
	db	81h
	dw	seq_B_default + 0
	db	6h
	db	7h
	db	7h
	db	7h
	db	6h
	db	7h
	db	7h
	db	7h
	db	8Bh
	dw	0EAh, 1D7h, seq_B_default + 0
	db	6h
	db	7h
	db	7h
	db	7h
	db	6h
	db	7h
	db	7h
	db	7h
	db	81h
	dw	seq_B_default + 0
	db	6h
	db	7h
	db	7h
	db	7h
	db	6h
	db	7h
	db	7h
	db	7h
	db	81h
	dw	seq_B_default + 0
	db	6h
	db	7h
	db	7h
	db	7h
	db	6h
	db	7h
	db	7h
	db	7h
	db	81h
	dw	seq_B_break + 0
	db	6h
	db	7h
	db	7h
	db	7h
	db	6h
	db	7h
	db	7h
	db	7h
	db	86h
section_intro1p2:
	db	80h
	dw	127h, 251h, seq_D_default + 0, 251h, 0B08h
	db	6h
	db	7h
	db	8h
	db	9h
	db	8Ch
	dw	211h, 0A6Ah
	db	6h
	db	0Ah
	db	0Bh
	db	0Ch
	db	81h
	dw	seq_D_default + 0
	db	0Dh
	db	0Bh
	db	8Ch
	dw	251h, 0B08h
	db	0Eh
	db	0Ah
	db	0Dh
	db	0Ch
	db	8Ch
	dw	211h, 0A6Ah
	db	0Eh
	db	7h
	db	81h
	dw	seq_D_default + 0
	db	0Fh
	db	9h
	db	8h
	db	10h
	db	11h
	db	10h
	db	8Ch
	dw	251h, 0B08h
	db	0Eh
	db	0Ah
	db	81h
	dw	seq_D_default + 0
	db	0Dh
	db	0Ch
	db	0Eh
	db	0Ah
	db	8Ch
	dw	211h, 0A6Ah
	db	6h
	db	7h
	db	8h
	db	9h
	db	80h
	dw	107h, 211h, seq_D_default + 0, 251h, 0B08h
	db	6h
	db	7h
	db	8h
	db	9h
	db	8Dh
	dw	0A6Ah
	db	6h
	db	0Ah
	db	0Bh
	db	0Ch
	db	81h
	dw	seq_D_default + 0
	db	0Dh
	db	0Bh
	db	8Dh
	dw	0B08h
	db	0Eh
	db	0Ah
	db	0Dh
	db	0Ch
	db	8Dh
	dw	0A6Ah
	db	0Eh
	db	7h
	db	81h
	dw	seq_D_default + 0
	db	0Fh
	db	9h
	db	8h
	db	10h
	db	11h
	db	10h
	db	8Dh
	dw	0C62h
	db	0Eh
	db	0Ah
	db	81h
	dw	seq_D_interbrk + 0
	db	0Dh
	db	0Ch
	db	0Eh
	db	0Ah
	db	8Dh
	dw	0A6Ah
	db	6h
	db	7h
	db	8h
	db	9h
	db	80h
	dw	18Ah, 318h, seq_B_default + 0, 3AEh, 947h
	db	12h
	db	13h
	db	14h
	db	15h
	db	8Ch
	dw	211h, 0A6Ah
	db	6h
	db	0Ah
	db	0Bh
	db	0Ch
	db	81h
	dw	seq_B_default + 0
	db	0Dh
	db	0Bh
	db	8Ch
	dw	3AEh, 947h
	db	16h
	db	17h
	db	0Dh
	db	18h
	db	8Ch
	dw	1D7h, 947h
	db	0Eh
	db	7h
	db	81h
	dw	seq_B_default + 0
	db	0Fh
	db	9h
	db	8h
	db	10h
	db	11h
	db	10h
	db	10h
	db	10h
	db	81h
	dw	seq_B_default + 0
	db	11h
	db	10h
	db	10h
	db	10h
	db	11h
	db	10h
	db	10h
	db	10h
	db	80h
	dw	0EAh, 1D7h, seq_B_default + 0, 3AEh, 947h
	db	12h
	db	13h
	db	14h
	db	15h
	db	8Ch
	dw	211h, 0A6Ah
	db	6h
	db	0Ah
	db	0Bh
	db	0Ch
	db	81h
	dw	seq_B_default + 0
	db	0Dh
	db	0Bh
	db	8Ch
	dw	3AEh, 947h
	db	16h
	db	17h
	db	0Dh
	db	18h
	db	8Ch
	dw	211h, 0A6Ah
	db	0Eh
	db	7h
	db	8Bh
	dw	107h, 211h, seq_D_default + 0
	db	0Fh
	db	9h
	db	8h
	db	10h
	db	11h
	db	10h
	db	10h
	db	10h
	db	81h
	dw	seq_B_break + 0
	db	11h
	db	10h
	db	10h
	db	10h
	db	11h
	db	10h
	db	10h
	db	10h
	db	86h
section_verse1p1:
	db	8Eh
	dw	wave5bp0, 4A3h, 127h, 251h, seq_D_default + 0, 6E9h, 6FDh
	db	19h
	db	1Ah
	db	1Bh
	db	1Ch
	db	1Dh
	db	1Eh
	db	8Fh
	dw	0B19h
	db	1Fh
	db	20h
	db	81h
	dw	seq_D_default + 0
	db	21h
	db	22h
	db	23h
	db	1Eh
	db	90h
	dw	0AF8h
	db	24h
	db	25h
	db	1Eh
	db	26h
	db	81h
	dw	seq_D_default + 0
	db	27h
	db	1Eh
	db	26h
	db	1Bh
	db	28h
	db	26h
	db	1Bh
	db	1Eh
	db	81h
	dw	seq_D_default + 0
	db	29h
	db	1Bh
	db	1Eh
	db	26h
	db	27h
	db	1Eh
	db	26h
	db	1Bh
	db	91h
	dw	0A79h, 422h, 0A5Bh, 107h, 211h, seq_D_default + 0
	db	19h
	db	1Ah
	db	1Bh
	db	1Ch
	db	1Dh
	db	1Eh
	db	8Fh
	dw	12AAh
	db	1Fh
	db	20h
	db	81h
	dw	seq_D_default + 0
	db	21h
	db	22h
	db	23h
	db	1Eh
	db	90h
	dw	1273h
	db	24h
	db	25h
	db	1Eh
	db	26h
	db	81h
	dw	seq_D_default + 0
	db	27h
	db	1Eh
	db	26h
	db	1Bh
	db	28h
	db	26h
	db	1Bh
	db	1Eh
	db	81h
	dw	seq_D_default + 0
	db	29h
	db	1Bh
	db	1Eh
	db	26h
	db	27h
	db	1Eh
	db	26h
	db	1Bh
	db	91h
	dw	0ED0h, 3AEh, 0EA5h, 18Ah, 318h, seq_B_default + 0
	db	19h
	db	1Ah
	db	1Bh
	db	1Ch
	db	1Dh
	db	1Eh
	db	8Fh
	dw	955h
	db	1Fh
	db	20h
	db	81h
	dw	seq_B_default + 0
	db	21h
	db	22h
	db	23h
	db	1Eh
	db	90h
	dw	939h
	db	24h
	db	25h
	db	1Eh
	db	26h
	db	81h
	dw	seq_B_default + 0
	db	27h
	db	1Eh
	db	26h
	db	1Bh
	db	28h
	db	26h
	db	1Bh
	db	1Eh
	db	81h
	dw	seq_B_default + 0
	db	29h
	db	1Bh
	db	1Eh
	db	26h
	db	27h
	db	1Eh
	db	26h
	db	1Bh
	db	92h
	dw	0EAh, 1D7h, seq_B_default + 0, 0AF8h, 0B19h
	db	19h
	db	1Ah
	db	1Bh
	db	8Fh
	dw	844h
	db	2Ah
	db	2Bh
	db	2Ch
	db	8Fh
	dw	955h
	db	1Fh
	db	20h
	db	81h
	dw	seq_B_default + 0
	db	21h
	db	22h
	db	23h
	db	1Eh
	db	90h
	dw	939h
	db	24h
	db	25h
	db	1Eh
	db	26h
	db	81h
	dw	seq_B_default + 0
	db	27h
	db	1Eh
	db	26h
	db	1Bh
	db	28h
	db	26h
	db	1Bh
	db	1Eh
	db	81h
	dw	seq_B_break + 0
	db	29h
	db	1Bh
	db	1Eh
	db	26h
	db	27h
	db	1Eh
	db	26h
	db	1Bh
	db	86h
section_verse1p2:
	db	93h
	dw	wave4bp0, wave4bp0, 2C2h, 127h, 251h, seq_D_default + 0, 251h, 6F3h
	db	19h
	db	1Ah
	db	1Bh
	db	1Ch
	db	1Dh
	db	1Eh
	db	8Fh
	dw	0B08h
	db	1Fh
	db	1Ah
	db	81h
	dw	seq_D_default + 0
	db	21h
	db	1Ch
	db	23h
	db	1Eh
	db	24h
	db	25h
	db	1Eh
	db	26h
	db	94h
	dw	wave4bp1, wave4bp1, seq_D_default + 0
	db	21h
	db	1Eh
	db	26h
	db	1Bh
	db	95h
	dw	wave4bp2, wave4bp2
	db	28h
	db	26h
	db	1Bh
	db	1Eh
	db	94h
	dw	wave4bp3, wave4bp3, seq_D_default + 0
	db	29h
	db	1Bh
	db	1Eh
	db	26h
	db	95h
	dw	wave4bp4, wave4bp4
	db	21h
	db	1Eh
	db	26h
	db	1Bh
	db	93h
	dw	wave4bp0, wavebp0, 0A6Ah, 107h, 211h, seq_D_default + 0, 211h, 0A6Ah
	db	19h
	db	1Ah
	db	1Bh
	db	1Ch
	db	1Dh
	db	1Eh
	db	8Fh
	dw	128Eh
	db	1Fh
	db	1Ah
	db	81h
	dw	seq_D_default + 0
	db	21h
	db	1Ch
	db	23h
	db	1Eh
	db	24h
	db	25h
	db	1Eh
	db	26h
	db	94h
	dw	wave4bp1, wavebp1, seq_D_default + 0
	db	21h
	db	1Eh
	db	26h
	db	1Bh
	db	95h
	dw	wavebp2, wave4bp2
	db	28h
	db	26h
	db	1Bh
	db	1Eh
	db	94h
	dw	wave4bp3, wavebp3, seq_D_default + 0
	db	29h
	db	1Bh
	db	1Eh
	db	26h
	db	95h
	dw	wavebp4, wave4bp4
	db	21h
	db	1Eh
	db	26h
	db	1Bh
	db	93h
	dw	wave4bp0, wave5bp0, 3AEh, 18Ah, 318h, seq_B_default + 0, 251h, 0EBAh
	db	19h
	db	1Ah
	db	8Fh
	dw	0DE7h
	db	1Fh
	db	1Ah
	db	8Fh
	dw	947h
	db	19h
	db	1Ah
	db	8Fh
	dw	0C62h
	db	1Fh
	db	1Ah
	db	81h
	dw	seq_B_default + 0
	db	21h
	db	1Ch
	db	23h
	db	1Eh
	db	24h
	db	25h
	db	1Eh
	db	26h
	db	94h
	dw	wave4bp1, wave5bp1, seq_B_default + 0
	db	21h
	db	1Eh
	db	26h
	db	1Bh
	db	95h
	dw	wave5bp2, wave4bp2
	db	28h
	db	26h
	db	1Bh
	db	1Eh
	db	94h
	dw	wave4bp3, wave5bp3, seq_B_default + 0
	db	29h
	db	1Bh
	db	1Eh
	db	26h
	db	95h
	dw	wave5bp4, wave4bp4
	db	21h
	db	1Eh
	db	26h
	db	1Bh
	db	93h
	dw	wave4bp0, wavebp0, 0B08h, 0EAh, 1D7h, seq_B_default + 0, 251h, 0B08h
	db	19h
	db	1Ah
	db	1Bh
	db	8Fh
	dw	844h
	db	1Fh
	db	2Bh
	db	1Bh
	db	8Fh
	dw	955h
	db	1Fh
	db	1Ah
	db	81h
	dw	seq_B_default + 0
	db	21h
	db	1Ch
	db	23h
	db	1Eh
	db	24h
	db	25h
	db	1Eh
	db	26h
	db	93h
	dw	wave5bp1, wavebp1, 0DE7h, 0DDh, 1BCh, seq_B_default + 0, 379h, 6F3h
	db	19h
	db	1Ah
	db	1Bh
	db	8Fh
	dw	0A6Ah
	db	1Fh
	db	95h
	dw	wavebp2, wave5bp2
	db	2Bh
	db	1Bh
	db	8Fh
	dw	0DE7h
	db	1Fh
	db	1Ah
	db	94h
	dw	wave5bp3, wavebp3, seq_B_break + 0
	db	21h
	db	1Ch
	db	23h
	db	1Eh
	db	95h
	dw	wavebp4, wave5bp4
	db	24h
	db	25h
	db	1Eh
	db	26h
	db	86h
section_verse2p1:
	db	8Eh
	dw	wave5bp0, 4A3h, 127h, 251h, seq_D_default + 0, 6E9h, 6FDh
	db	19h
	db	1Ah
	db	1Bh
	db	1Ch
	db	1Dh
	db	1Eh
	db	8Fh
	dw	0B19h
	db	1Fh
	db	20h
	db	81h
	dw	seq_D_default + 0
	db	21h
	db	22h
	db	23h
	db	1Eh
	db	90h
	dw	0AF8h
	db	24h
	db	25h
	db	1Eh
	db	26h
	db	96h
	dw	wavereso15, seq_D_default + 0
	db	27h
	db	97h
	dw	wavereso14
	db	1Eh
	db	97h
	dw	wavereso13
	db	26h
	db	97h
	dw	wavereso12
	db	1Bh
	db	97h
	dw	wavereso11
	db	28h
	db	97h
	dw	wavereso10
	db	26h
	db	97h
	dw	wavereso9
	db	1Bh
	db	97h
	dw	wavereso8
	db	1Eh
	db	98h
	dw	wavereso7, seq_D_default + 0
	db	29h
	db	97h
	dw	wavereso6
	db	1Bh
	db	97h
	dw	wavereso5
	db	1Eh
	db	97h
	dw	wavereso4
	db	26h
	db	97h
	dw	wavereso3
	db	27h
	db	97h
	dw	wavereso2
	db	1Eh
	db	97h
	dw	wavereso1
	db	26h
	db	97h
	dw	wavereso0
	db	1Bh
	db	99h
	dw	422h, 0A79h, 107h, 0A5Bh, 211h, seq_D_default + 0
	db	19h
	db	1Ah
	db	1Bh
	db	1Ch
	db	1Dh
	db	1Eh
	db	8Fh
	dw	12AAh
	db	1Fh
	db	20h
	db	81h
	dw	seq_D_default + 0
	db	21h
	db	22h
	db	23h
	db	1Eh
	db	90h
	dw	1273h
	db	24h
	db	25h
	db	1Eh
	db	26h
	db	96h
	dw	wavereso15, seq_D_default + 0
	db	27h
	db	97h
	dw	wavereso14
	db	1Eh
	db	97h
	dw	wavereso13
	db	26h
	db	97h
	dw	wavereso12
	db	1Bh
	db	97h
	dw	wavereso11
	db	28h
	db	97h
	dw	wavereso10
	db	26h
	db	97h
	dw	wavereso9
	db	1Bh
	db	97h
	dw	wavereso8
	db	1Eh
	db	98h
	dw	wavereso7, seq_D_default + 0
	db	29h
	db	97h
	dw	wavereso6
	db	1Bh
	db	97h
	dw	wavereso5
	db	1Eh
	db	97h
	dw	wavereso4
	db	26h
	db	97h
	dw	wavereso3
	db	27h
	db	97h
	dw	wavereso2
	db	1Eh
	db	97h
	dw	wavereso1
	db	26h
	db	97h
	dw	wavereso0
	db	1Bh
	db	99h
	dw	3AEh, 0ED0h, 18Ah, 0EA5h, 318h, seq_B_default + 0
	db	19h
	db	1Ah
	db	1Bh
	db	1Ch
	db	1Dh
	db	1Eh
	db	8Fh
	dw	955h
	db	1Fh
	db	20h
	db	81h
	dw	seq_B_default + 0
	db	21h
	db	22h
	db	23h
	db	1Eh
	db	90h
	dw	939h
	db	24h
	db	25h
	db	1Eh
	db	26h
	db	96h
	dw	wavereso15, seq_B_default + 0
	db	27h
	db	97h
	dw	wavereso14
	db	1Eh
	db	97h
	dw	wavereso13
	db	26h
	db	97h
	dw	wavereso12
	db	1Bh
	db	97h
	dw	wavereso11
	db	28h
	db	97h
	dw	wavereso10
	db	26h
	db	97h
	dw	wavereso9
	db	1Bh
	db	97h
	dw	wavereso8
	db	1Eh
	db	98h
	dw	wavereso7, seq_B_default + 0
	db	29h
	db	97h
	dw	wavereso6
	db	1Bh
	db	97h
	dw	wavereso5
	db	1Eh
	db	97h
	dw	wavereso4
	db	26h
	db	97h
	dw	wavereso3
	db	27h
	db	97h
	dw	wavereso2
	db	1Eh
	db	97h
	dw	wavereso1
	db	26h
	db	97h
	dw	wavereso0
	db	1Bh
	db	9Ah
	dw	0B19h, 0EAh, 0AF8h, 1D7h, seq_B_default + 0
	db	19h
	db	1Ah
	db	1Bh
	db	8Fh
	dw	844h
	db	2Ah
	db	2Bh
	db	2Ch
	db	8Fh
	dw	955h
	db	1Fh
	db	20h
	db	81h
	dw	seq_B_default + 0
	db	21h
	db	22h
	db	23h
	db	1Eh
	db	90h
	dw	939h
	db	24h
	db	25h
	db	1Eh
	db	26h
	db	96h
	dw	wavereso15, seq_B_default + 0
	db	27h
	db	97h
	dw	wavereso14
	db	1Eh
	db	97h
	dw	wavereso13
	db	26h
	db	97h
	dw	wavereso12
	db	1Bh
	db	97h
	dw	wavereso11
	db	28h
	db	97h
	dw	wavereso10
	db	26h
	db	97h
	dw	wavereso9
	db	1Bh
	db	97h
	dw	wavereso8
	db	1Eh
	db	98h
	dw	wavereso7, seq_B_break + 0
	db	29h
	db	97h
	dw	wavereso6
	db	1Bh
	db	97h
	dw	wavereso5
	db	1Eh
	db	97h
	dw	wavereso4
	db	26h
	db	97h
	dw	wavereso3
	db	27h
	db	97h
	dw	wavereso2
	db	1Eh
	db	97h
	dw	wavereso1
	db	26h
	db	97h
	dw	wavereso0
	db	1Bh
	db	86h
section_verse2p2:
	db	9Bh
	dw	wavereso15, wave4bp0, wave4bp0, 2C2h, 127h, 251h, seq_D_default + 0, 251h, 6F3h
	db	19h
	db	97h
	dw	wavereso14
	db	1Ah
	db	97h
	dw	wavereso13
	db	1Bh
	db	97h
	dw	wavereso12
	db	1Ch
	db	97h
	dw	wavereso11
	db	1Dh
	db	97h
	dw	wavereso10
	db	1Eh
	db	9Ch
	dw	wavereso9, 0B08h
	db	1Fh
	db	97h
	dw	wavereso8
	db	1Ah
	db	98h
	dw	wavereso7, seq_D_default + 0
	db	21h
	db	97h
	dw	wavereso6
	db	1Ch
	db	97h
	dw	wavereso5
	db	23h
	db	97h
	dw	wavereso4
	db	1Eh
	db	97h
	dw	wavereso3
	db	24h
	db	97h
	dw	wavereso2
	db	25h
	db	97h
	dw	wavereso1
	db	1Eh
	db	97h
	dw	wavereso0
	db	26h
	db	9Dh
	dw	wave4bp1, wave4bp1, seq_D_default + 0
	db	21h
	db	1Eh
	db	26h
	db	1Bh
	db	95h
	dw	wave4bp2, wave4bp2
	db	28h
	db	26h
	db	1Bh
	db	1Eh
	db	94h
	dw	wave4bp3, wave4bp3, seq_D_default + 0
	db	29h
	db	1Bh
	db	1Eh
	db	26h
	db	95h
	dw	wave4bp4, wave4bp4
	db	21h
	db	1Eh
	db	26h
	db	1Bh
	db	9Eh
	dw	wavereso15, wave4bp0, wavebp0, 0A6Ah, 107h, 211h, seq_D_default + 0, 211h, 0A6Ah
	db	19h
	db	97h
	dw	wavereso14
	db	1Ah
	db	97h
	dw	wavereso13
	db	1Bh
	db	97h
	dw	wavereso12
	db	1Ch
	db	97h
	dw	wavereso11
	db	1Dh
	db	97h
	dw	wavereso10
	db	1Eh
	db	9Ch
	dw	wavereso9, 128Eh
	db	1Fh
	db	97h
	dw	wavereso8
	db	1Ah
	db	98h
	dw	wavereso7, seq_D_default + 0
	db	21h
	db	97h
	dw	wavereso6
	db	1Ch
	db	97h
	dw	wavereso5
	db	23h
	db	97h
	dw	wavereso4
	db	1Eh
	db	97h
	dw	wavereso3
	db	24h
	db	97h
	dw	wavereso2
	db	25h
	db	97h
	dw	wavereso1
	db	1Eh
	db	97h
	dw	wavereso0
	db	26h
	db	9Dh
	dw	wave4bp1, wavebp1, seq_D_default + 0
	db	21h
	db	1Eh
	db	26h
	db	1Bh
	db	95h
	dw	wavebp2, wave4bp2
	db	28h
	db	26h
	db	1Bh
	db	1Eh
	db	94h
	dw	wave4bp3, wavebp3, seq_D_default + 0
	db	29h
	db	1Bh
	db	1Eh
	db	26h
	db	95h
	dw	wavebp4, wave4bp4
	db	21h
	db	1Eh
	db	26h
	db	1Bh
	db	9Eh
	dw	wavereso15, wave4bp0, wave5bp0, 3AEh, 18Ah, 318h, seq_B_default + 0, 251h, 0EBAh
	db	19h
	db	97h
	dw	wavereso14
	db	1Ah
	db	9Ch
	dw	wavereso13, 0DE7h
	db	1Fh
	db	97h
	dw	wavereso12
	db	1Ah
	db	9Ch
	dw	wavereso11, 947h
	db	19h
	db	97h
	dw	wavereso10
	db	1Ah
	db	9Ch
	dw	wavereso9, 0C62h
	db	1Fh
	db	97h
	dw	wavereso8
	db	1Ah
	db	98h
	dw	wavereso7, seq_B_default + 0
	db	21h
	db	97h
	dw	wavereso6
	db	1Ch
	db	97h
	dw	wavereso5
	db	23h
	db	97h
	dw	wavereso4
	db	1Eh
	db	97h
	dw	wavereso3
	db	24h
	db	97h
	dw	wavereso2
	db	25h
	db	97h
	dw	wavereso1
	db	1Eh
	db	97h
	dw	wavereso0
	db	26h
	db	9Dh
	dw	wave4bp1, wave5bp1, seq_B_default + 0
	db	21h
	db	1Eh
	db	26h
	db	1Bh
	db	95h
	dw	wave5bp2, wave4bp2
	db	28h
	db	26h
	db	1Bh
	db	1Eh
	db	94h
	dw	wave4bp3, wave5bp3, seq_B_default + 0
	db	29h
	db	1Bh
	db	1Eh
	db	26h
	db	95h
	dw	wave5bp4, wave4bp4
	db	21h
	db	1Eh
	db	26h
	db	1Bh
	db	9Eh
	dw	wavereso15, wave4bp0, wavebp0, 0B08h, 0EAh, 1D7h, seq_B_default + 0, 251h, 0B08h
	db	19h
	db	97h
	dw	wavereso14
	db	1Ah
	db	97h
	dw	wavereso13
	db	1Bh
	db	9Ch
	dw	wavereso12, 844h
	db	1Fh
	db	97h
	dw	wavereso11
	db	2Bh
	db	97h
	dw	wavereso10
	db	1Bh
	db	9Ch
	dw	wavereso9, 955h
	db	1Fh
	db	97h
	dw	wavereso8
	db	1Ah
	db	98h
	dw	wavereso7, seq_B_default + 0
	db	21h
	db	97h
	dw	wavereso6
	db	1Ch
	db	97h
	dw	wavereso5
	db	23h
	db	97h
	dw	wavereso4
	db	1Eh
	db	97h
	dw	wavereso3
	db	24h
	db	97h
	dw	wavereso2
	db	25h
	db	97h
	dw	wavereso1
	db	1Eh
	db	97h
	dw	wavereso0
	db	26h
	db	9Bh
	dw	wavereso15, wave5bp1, wavebp1, 0DE7h, 0DDh, 1BCh, seq_B_default + 0, 379h, 6F3h
	db	19h
	db	97h
	dw	wavereso14
	db	1Ah
	db	97h
	dw	wavereso13
	db	1Bh
	db	9Ch
	dw	wavereso12, 0A6Ah
	db	1Fh
	db	9Fh
	dw	wavebp2, wave5bp2, wavereso11
	db	2Bh
	db	97h
	dw	wavereso10
	db	1Bh
	db	9Ch
	dw	wavereso9, 0DE7h
	db	1Fh
	db	97h
	dw	wavereso8
	db	1Ah
	db	0A0h
	dw	wavereso7, seq_B_break + 0, wavebp3, wave5bp3
	db	21h
	db	97h
	dw	wavereso6
	db	1Ch
	db	97h
	dw	wavereso5
	db	23h
	db	97h
	dw	wavereso4
	db	1Eh
	db	9Fh
	dw	wavebp4, wave5bp4, wavereso3
	db	24h
	db	97h
	dw	wavereso2
	db	25h
	db	97h
	dw	wavereso1
	db	1Eh
	db	97h
	dw	wavereso0
	db	26h
	db	86h
section_main:
	db	0A1h
	dw	zeros
	db	0A2h
	dw	section_prelude
	db	0A3h
	dw	zeros, zeros, section_intro1p1
	db	0A4h
	dw	section_intro1p2
	db	0A5h
	dw	section_verse1p1
	db	0A6h
	dw	section_verse1p2
	db	0A7h
	dw	section_interlude
	db	0A8h
	dw	section_intro1p2
	db	0A5h
	dw	section_verse2p1
	db	0A6h
	dw	section_verse2p2
	db	0A9h
	dw	section_interlude
	db	0A3h
	dw	zeros, zeros, section_intro1p1
	db	0A4h
	dw	section_intro1p2
	db	0AAh
	dw	section_final
	db	0ABh
