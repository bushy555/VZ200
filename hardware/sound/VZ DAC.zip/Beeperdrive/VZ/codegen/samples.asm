sample_kick	incbin	samples/kick.dat
sample_snare	incbin	samples/snare.dat
