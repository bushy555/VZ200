nts_v1i_seq_end:
	ld	hl, wave1 + 1		;= 10
	ld	(frmdst1), hl	;= 16
	pop	hl		;= 10, load seq
	ld	(seqptr), hl	;= 16
	jp	noteexit	;= 10

nts_v4w_v2w_v5w_v3w_seq_w3_w5_w4_w2_end:
	ld	hl, fakevar		;= 10
	ld	(frmdst4), hl	;= 16
	ld	hl, fakevar		;= 10
	ld	(frmdst2), hl	;= 16
	ld	hl, fakevar		;= 10
	ld	(frmdst5), hl	;= 16
	ld	hl, fakevar		;= 10
	ld	(frmdst3), hl	;= 16
nts_seq_w3_w5_w4_w2_end:
	pop	hl		;= 10, load seq
	ld	(seqptr), hl	;= 16
nts_w3_w5_w4_w2_end:
	pop	af		;= 10, load wave3
	ld	(wave3 + 1), a	;= 13
nts_w5_w4_w2_end:
	pop	af		;= 10, load wave5
	ld	(wave5 + 1), a	;= 13
	pop	af		;= 10, load wave4
	ld	(wave4 + 1), a	;= 13
nts_w2_end:
	pop	af		;= 10, load wave2
	ld	(wave2 + 1), a	;= 13
	jp	noteexit	;= 10

nts_ret1:
	ld	sp, (callsave1)	;= 20
	jp	nextnote_inner	;= 10

nts_w2_w5_w4_w3_f2_f3_seq_f4_f5_end:
	pop	af		;= 10, load wave2
	ld	(wave2 + 1), a	;= 13
	pop	af		;= 10, load wave5
	ld	(wave5 + 1), a	;= 13
	pop	af		;= 10, load wave4
	ld	(wave4 + 1), a	;= 13
	pop	af		;= 10, load wave3
	ld	(wave3 + 1), a	;= 13
nts_f2_f3_seq_f4_f5_end:
	pop	hl		;= 10, load freq2
	ld	(freq2), hl	;= 16
	pop	hl		;= 10, load freq3
	ld	(freq3), hl	;= 16
	pop	hl		;= 10, load seq
	ld	(seqptr), hl	;= 16
nts_f4_f5_end:
	pop	hl		;= 10, load freq4
	ld	(freq4), hl	;= 16
nts_f5_end:
	pop	hl		;= 10, load freq5
	ld	(freq5), hl	;= 16
	jp	noteexit	;= 10

nts_w1_f1_f5_f4_f2_f3_seq_end:
	pop	af		;= 10, load wave1
	ld	(wave1 + 1), a	;= 13
nts_f1_f5_f4_f2_f3_seq_end:
	pop	hl		;= 10, load freq1
	ld	(freq1), hl	;= 16
	pop	hl		;= 10, load freq5
	ld	(freq5), hl	;= 16
	pop	hl		;= 10, load freq4
	ld	(freq4), hl	;= 16
nts_f2_f3_seq_end:
	pop	hl		;= 10, load freq2
	ld	(freq2), hl	;= 16
	pop	hl		;= 10, load freq3
	ld	(freq3), hl	;= 16
	pop	hl		;= 10, load seq
	ld	(seqptr), hl	;= 16
	jp	noteexit	;= 10

nts_seq_w1_end:
	pop	hl		;= 10, load seq
	ld	(seqptr), hl	;= 16
nts_w1_end:
	pop	af		;= 10, load wave1
	ld	(wave1 + 1), a	;= 13
	jp	noteexit	;= 10

nts_f4_end:
	pop	hl		;= 10, load freq4
	ld	(freq4), hl	;= 16
	jp	noteexit	;= 10

nts_v2w_w2_seq_end:
	ld	hl, fakevar		;= 10
	ld	(frmdst2), hl	;= 16
nts_w2_seq_end:
	pop	af		;= 10, load wave2
	ld	(wave2 + 1), a	;= 13
	pop	hl		;= 10, load seq
	ld	(seqptr), hl	;= 16
	jp	noteexit	;= 10

nts_f5_f1_f2_f4_v2i_f3_seq_end:
	pop	hl		;= 10, load freq5
	ld	(freq5), hl	;= 16
nts_f1_f2_f4_v2i_f3_seq_end:
	pop	hl		;= 10, load freq1
	ld	(freq1), hl	;= 16
	pop	hl		;= 10, load freq2
	ld	(freq2), hl	;= 16
	pop	hl		;= 10, load freq4
	ld	(freq4), hl	;= 16
	ld	hl, wave2 + 1		;= 10
	ld	(frmdst2), hl	;= 16
	pop	hl		;= 10, load freq3
	ld	(freq3), hl	;= 16
nts_seq_end:
	pop	hl		;= 10, load seq
	ld	(seqptr), hl	;= 16
	jp	noteexit	;= 10

nts_w2_f1_end:
	pop	af		;= 10, load wave2
	ld	(wave2 + 1), a	;= 13
	pop	hl		;= 10, load freq1
	ld	(freq1), hl	;= 16
	jp	noteexit	;= 10

nts_v2i_w4_w5_seq_end:
	ld	hl, wave2 + 1		;= 10
	ld	(frmdst2), hl	;= 16
nts_w4_w5_seq_end:
	pop	af		;= 10, load wave4
	ld	(wave4 + 1), a	;= 13
	pop	af		;= 10, load wave5
	ld	(wave5 + 1), a	;= 13
	pop	hl		;= 10, load seq
	ld	(seqptr), hl	;= 16
	jp	noteexit	;= 10

nts_v2w_w2_w4_w5_f5_f2_f3_seq_f4_f1_end:
	ld	hl, fakevar		;= 10
	ld	(frmdst2), hl	;= 16
nts_w2_w4_w5_f5_f2_f3_seq_f4_f1_end:
	pop	af		;= 10, load wave2
	ld	(wave2 + 1), a	;= 13
nts_w4_w5_f5_f2_f3_seq_f4_f1_end:
	pop	af		;= 10, load wave4
	ld	(wave4 + 1), a	;= 13
nts_w5_f5_f2_f3_seq_f4_f1_end:
	pop	af		;= 10, load wave5
	ld	(wave5 + 1), a	;= 13
	pop	hl		;= 10, load freq5
	ld	(freq5), hl	;= 16
nts_f2_f3_seq_f4_f1_end:
	pop	hl		;= 10, load freq2
	ld	(freq2), hl	;= 16
	pop	hl		;= 10, load freq3
	ld	(freq3), hl	;= 16
	pop	hl		;= 10, load seq
	ld	(seqptr), hl	;= 16
	pop	hl		;= 10, load freq4
	ld	(freq4), hl	;= 16
nts_f1_end:
	pop	hl		;= 10, load freq1
	ld	(freq1), hl	;= 16
	jp	noteexit	;= 10

nts_w2_seq_w5_w4_end:
	pop	af		;= 10, load wave2
	ld	(wave2 + 1), a	;= 13
	pop	hl		;= 10, load seq
	ld	(seqptr), hl	;= 16
nts_w5_w4_end:
	pop	af		;= 10, load wave5
	ld	(wave5 + 1), a	;= 13
	pop	af		;= 10, load wave4
	ld	(wave4 + 1), a	;= 13
	jp	noteexit	;= 10

nts_vs1_v1w_v2i_v3i_w1_v4i_v5i_cont:
	ld	hl, freq1	;= 10
	ld	(seqdst), hl		;= 16
	ld	hl, fakevar		;= 10
	ld	(frmdst1), hl	;= 16
	ld	hl, wave2 + 1		;= 10
	ld	(frmdst2), hl	;= 16
	ld	hl, wave3		;= 10
	ld	(frmdst3), hl	;= 16
	pop	af		;= 10, load wave1
	ld	(wave1 + 1), a	;= 13
	ld	hl, wave4 + 1		;= 10
	ld	(frmdst4), hl	;= 16
	ld	hl, wave5		;= 10
	ld	(frmdst5), hl	;= 16
	jp	nextnote_inner	;= 10

nts_v2i_w5_w4_v3i_call1:
	ld	hl, wave2 + 1		;= 10
	ld	(frmdst2), hl	;= 16
	pop	af		;= 10, load wave5
	ld	(wave5 + 1), a	;= 13
	pop	af		;= 10, load wave4
	ld	(wave4 + 1), a	;= 13
	ld	hl, wave3		;= 10
	ld	(frmdst3), hl	;= 16
nts_call1:
	pop	hl		;= 10, load addr
	ld	(callsave1), sp	;= 20
	ld	sp, hl		;= 6
	jp	nextnote_inner	;= 10

nts_novs_v5w_call1:
	ld	hl, fakevar		;= 10
	ld	(seqdst), hl		;= 16
	ld	hl, fakevar		;= 10
	ld	(frmdst5), hl	;= 16
	pop	hl		;= 10, load addr
	ld	(callsave1), sp	;= 20
	ld	sp, hl		;= 6
	jp	nextnote_inner	;= 10

nts_v4w_call1:
	ld	hl, fakevar		;= 10
	ld	(frmdst4), hl	;= 16
	pop	hl		;= 10, load addr
	ld	(callsave1), sp	;= 20
	ld	sp, hl		;= 6
	jp	nextnote_inner	;= 10

nts_v2w_v3w_vs1_call1:
	ld	hl, fakevar		;= 10
	ld	(frmdst2), hl	;= 16
nts_v3w_vs1_call1:
	ld	hl, fakevar		;= 10
	ld	(frmdst3), hl	;= 16
	ld	hl, freq1	;= 10
	ld	(seqdst), hl		;= 16
	pop	hl		;= 10, load addr
	ld	(callsave1), sp	;= 20
	ld	sp, hl		;= 6
	jp	nextnote_inner	;= 10

nts_v2i_v3i_v4i_v5i_call1:
	ld	hl, wave2 + 1		;= 10
	ld	(frmdst2), hl	;= 16
	ld	hl, wave3		;= 10
	ld	(frmdst3), hl	;= 16
nts_v4i_v5i_call1:
	ld	hl, wave4 + 1		;= 10
	ld	(frmdst4), hl	;= 16
	ld	hl, wave5		;= 10
	ld	(frmdst5), hl	;= 16
	pop	hl		;= 10, load addr
	ld	(callsave1), sp	;= 20
	ld	sp, hl		;= 6
	jp	nextnote_inner	;= 10

nts_novs_v1w_call1:
	ld	hl, fakevar		;= 10
	ld	(seqdst), hl		;= 16
	ld	hl, fakevar		;= 10
	ld	(frmdst1), hl	;= 16
	pop	hl		;= 10, load addr
	ld	(callsave1), sp	;= 20
	ld	sp, hl		;= 6
	jp	nextnote_inner	;= 10

nts_quit:
	jp	exit	;= 10

