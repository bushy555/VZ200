;	DMITRY MILK's BEEPERDRIVE.
;	Released at DieHard 2026 Winter compo.
;	Feb-Mar-Apr 2026.
; 	Mind blowing 1-bit audio.
;
;	Ported to the VZ/Laser by Dave Aug 26, but does require a DAC hanging on the printer port.
;	Need to :get a VZ/Laser printer interfaceface (PI-20 or PI30 or whatever that name is), 
;		:make a resistor ladder circuit. Simple or complicated. Or use a 4050 IC chip DAC.
;		:cut Printer interface ribbon cable and connect D0-D7 to input of DAC.
;		: possible use a 2.2uf cap in both output lines to an amplified speaker.
;		: Run this!
;
;		This uses Port 12 which drives the printer interface.  Ports ~10-1A drives the printer interface.
;
;
;	Use SJASMPLUS to assemble to an object file.
;	Use the VZ/Laser header linker utility "RBINARY.EXE" by Guy Thomason, to object link to the .VZ file.
;	<OR> add the 24byte header to this below, which I really should just add. But cant be bothered. You be on your own.
;



MAIN.VZ		: Beeperdrive for the VZ/Laser.
BEEPERDRIVE.TAP	: Original TAP file for the ZX Spectrum. Use the ZX Speccy 'FUSE' emulator on the PC for best results.

