	;; Generic crt0.s for a Z80
	.globl	_main

	.area _HEADER (ABS)
	;; Reset vector

init:	di
        ;; Initialise global variables
        ;call    gsinit
        call	_main
		jp	_exit

	;; Ordering of segments for the linker.
        .area   _GSINIT
        .area   _GSFINAL
		.area	_DATA
        .area   _BSS

        .area   _CODE
_exit::
	;; Exit - special code to the emulator
1$:		halt
		jr	1$


;gsinit::
;        ret
