void xyputs(unsigned char x, unsigned char y, unsigned char *p)
{
	unsigned char *pscr=(unsigned char *)0x7000;
	pscr=&pscr[y*32+x];
	while (*p) *pscr++=(*p++)&63;
}


main()
{
	xyputs(11,8,"HOLA MUNDO");
	while(1);
}
