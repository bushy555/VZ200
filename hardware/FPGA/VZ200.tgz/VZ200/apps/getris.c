////////////////////////////////////////////////////
//    Tetris port to Laser-200 (4KB RAM minimum)
//     Graphics mode (128x64, 4-color) 
//     Compiler: sdcc -mz80
//     J. Arias (2025)
////////////////////////////////////////////////////

#include <stdint.h>

#define ANCHO 	10	// Game field width 
#define ALTO	20  // Game field heigth

///// Variables /////
struct {	// System variables grouped into a struct...
	uint8_t		syso;	// +0 (hardware output register copy)
	uint8_t		sysi;	// +1 (hardware  input register copy)
}svar;

uint8_t *pvideo;		// video RAM pointer

///////////////////////////////////////////////////
//               system routines                 //
///////////////////////////////////////////////////

static uint16_t srand;
uint16_t rand()	// random number via LFSR
{
   	if (srand&0x8000) {srand+=srand; srand^=0x1021;}
   	else srand+=srand;
    return srand;
}

// delay: n falling edges in FS (vertical retrace)
// Interrupts must be disabled or it hangs
void fsdelay(uint8_t n)
{
	uint8_t i;
	for(i=n;i;i--){
		while (!((*(volatile uint8_t *)0x68ff)&0x80));	// wait while L
		while (  (*(volatile uint8_t *)0x68ff)&0x80 );	// wait while H
	}
}

// sets pvideo depending on x and y
//   x = horizontal byte, not pixel (x=pixel_x/4)
void gotoxy(uint8_t x,uint8_t y)
{
	pvideo=(uint8_t *)0x7000;
	pvideo=&pvideo[y*96+x+8];
}

// Draw an square block (4x3 pixels)
// x, y: position
// tipo: color & shape (0: background, 1 to 8: tetronims, 9: field frame)
void cuadro(unsigned char x,unsigned char y, unsigned char tipo)
{
	uint8_t d;
	static const uint8_t cblk[10]={0xaa, 0x00,0x55,0xff, 0x00,0x55,0xff, 0x00,0x55,0xc3};
	gotoxy(x,y);
    d=cblk[tipo];
    *pvideo=d; pvideo=&pvideo[32];
    *pvideo=(tipo)?d^0x3C: d; pvideo=&pvideo[32];
    *pvideo=d; pvideo=&pvideo[32];
}

// Some text as bitmapped images
const uint8_t maximg[4*5]={	// "MAX": 16x5 pixels
  0x2A,0x29,0x6b,0xab,
  0x08,0x26,0x9A,0xee,
  0x22,0x26,0x9A,0xba,
  0x2A,0x25,0x5a,0xee,
  0x2A,0x26,0x9b,0xab
};
const uint8_t digitos[10*5]={ // ten digits of 4x5 pixels
  0x95,0x99,0x99,0x99,0x95,	// 0
  0xa9,0xa5,0xa9,0xa9,0xa9,	// 1
  0x95,0xa9,0x95,0x9a,0x95,	// 2
  0x95,0xa9,0xa5,0xa9,0x95,	// 3
  0x99,0x99,0x95,0xa9,0xa9,	// 4
  0x95,0x9a,0x95,0xa9,0x95,	// 5
  0x95,0x9a,0x95,0x99,0x95,	// 6
  0x95,0xa9,0xa9,0xa9,0xa9,	// 7
  0x95,0x99,0x95,0x99,0x95,	// 8
  0x95,0x99,0x95,0xa9,0xa9	// 9
};
const uint8_t gameover[10*7]={ // 40x7 pixels
  0xaa,0xaa,0xaa,0xaa,0xaa,  0xaa,0xaa,0xaa,0xaa,0xaa,
  0x82,0xaf,0xa6,0xa6,0x02,  0xbe,0x9a,0x98,0x0b,0xfa,
  0x2a,0xba,0xe5,0x96,0x2a,  0xeb,0x9a,0x98,0xab,0xae,
  0x20,0xba,0xe6,0x66,0x0a,  0xeb,0x9a,0x98,0x2b,0xae,
  0x28,0xbf,0xe6,0xa6,0x2a,  0xeb,0xa6,0x68,0xab,0xfa,
  0x82,0xba,0xe6,0xa6,0x02,  0xbe,0xa9,0xa8,0x0b,0xae,
  0xaa,0xaa,0xaa,0xaa,0xaa,  0xaa,0xaa,0xaa,0xaa,0xaa
};

// Draws image (at the position pointed by pvideo)
//  pdata: pointer to image data
//  nx: number of horizontal bytes
//  ny: number of lines
void putimg(uint8_t *pdata, uint8_t nx,uint8_t ny)
{
    uint8_t i,j;
    for (i=0;i<ny;i++) {
    	for(j=0;j<nx;j++) {
    	    *pvideo++=*pdata++;
    	}
    	pvideo=&pvideo[32-nx];
    }
}

// print a decimal number (0 to 255, at the position pointed by pvideo)
void prtnum(uint8_t x)
{
	uint8_t *p;
	p=&pvideo[2];
	do {
		pvideo=p;
		putimg(&digitos[5*(x%10)],1,5);
		x/=10; p--;
	} while (x);
}


// scan keyboard and return:
//  0: no key pressed
//  other: The ASCII code of the key pressed (lowercase)

char getch_vt()
{
	uint8_t a;
	rand();
	a=*(volatile uint8_t *)0x687F;
	if (!(a&0x20)) return 'j';
	if (!(a&0x08)) return 'k';
	if (!(a&0x02)) return 'l';
	if (!((*(volatile uint8_t *)0x68EF)&0x10)) return ' ';
	if (!((*(volatile uint8_t *)0x68BF)&0x10)) return 'p';
	if (!((*(volatile uint8_t *)0x68FB)&0x08)) return 'c';
	return 0;	// sin teclas pulsadas
}

// Control keys for playing
#define K_L	'j'
#define K_R	'l'
#define K_U	'k'
#define K_D	' '

// Init screen. Text mode
const uint8_t initxt[]={	// 32*9 characters
0x80,0x80,0x80,0x80,0x9f,0x9f,0x9f,0x9f,0x9f,0x9f,0x9f,0x9f,0x9f,0x9f,0x9f,0x9f,
0x9f,0x9f,0x9f,0x9f,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,
0x80,0x80,0x80,0x80,0x9f,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,
0x80,0x80,0x80,0x9f,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,
0x80,0x80,0x80,0x80,0x9f,0x80,0x0c,0x01,0x13,0x05,0x12,0x2d,0x32,0x30,0x30,0x80,
0x36,0x0b,0x80,0x9f,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,
0x80,0x80,0x80,0x80,0x9f,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,
0x80,0x80,0x80,0x9f,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,
0x80,0x80,0x80,0x80,0x9f,0x9f,0x9f,0x9f,0x9f,0x9f,0x9f,0x9f,0x80,0x14,0x14,0x12,
0x09,0x13,0x80,0x9f,0x9f,0x9f,0x9f,0x9f,0x9f,0x9f,0x9f,0x80,0x80,0x80,0x80,0x80,
0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x9f,0x80,0x80,0x80,0x80,
0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x9f,0x80,0x80,0x80,0x80,0x80,
0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x9f,0x80,0x0a,0x2e,0x01,
0x12,0x09,0x01,0x13,0x80,0x32,0x30,0x32,0x35,0x80,0x9f,0x80,0x80,0x80,0x80,0x80,
0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x9f,0x80,0x80,0x80,0x80,
0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x9f,0x80,0x80,0x80,0x80,0x80,
0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x9f,0x9f,0x9f,0x9f,0x9f,
0x9f,0x9f,0x9f,0x9f,0x9f,0x9f,0x9f,0x9f,0x9f,0x9f,0x9f,0x80,0x80,0x80,0x80,0x80,
};

void initsrcn()
{
	uint8_t i, *pd,*ps;
	svar.syso=0x20;
    *(volatile uint8_t *)0x68ff=svar.syso;	// Text mode

	pd=(uint8_t *)0x7000;
	ps=initxt;
	for (i=0;i<32*3;i++) *pd++=0x80;
	for (i=0;i<144;i++) {
		*pd++=*ps++;
		*pd++=*ps++;
	}
	for (i=0;i<32*4;i++) *pd++=0x80;
	while (getch_vt());
	while (getch_vt()==0);
	svar.syso=0x28;
    *(volatile uint8_t *)0x68ff=svar.syso;	// Graphics mode
}

//////////////////////////////////////////////////
//                 TETRIS CORE                  //
//////////////////////////////////////////////////

// current and previous game fields
//  horizontal size = 16 instead of ANCHO+2 helps with addressing
uint8_t campo[ALTO+1][16],oldc[ALTO+1][16]; 
uint8_t pieza[4][4];	// bitmap for current tetronim

// All possible tetronims
const uint8_t piezas[7][2][4]={
        {{1,1,1,1},        // 0 Bar
         {0,0,0,0}},
        {{2,2,2,0},        // 1 /L
         {0,0,2,0}},
        {{0,3,3,3},        // 2 L
         {0,3,0,0}},
        {{0,0,4,4},        // 3 S
         {0,4,4,0}},
        {{5,5,0,0},        // 4 /S
         {0,5,5,0}},
        {{0,6,6,6},        // 5 T
         {0,0,6,0}},
        {{0,7,7,0},        // 6 Square
         {0,7,7,0}}
};

signed char xp,yp;	// current tetronim position

// Test if the current tetronim colides with something
signed char testpos(signed char x, signed char y)
{
	register unsigned char i,j;
	for (i=0;i<4;i++)
		for (j=0;j<4;j++) {
			if (x+j<0) continue;
			if (x+j>ANCHO+1) continue;
			if (y+i<0) continue;
			if (y+i>ALTO) continue;
			if (campo[y+i][x+j] && pieza[i][j]) return 1;
		}
	return 0;	// no colission
}

// turn the current tetronim +90 o -90 degrees
void rota(signed char giro)
{
	register unsigned char i,j;
	uint8_t tmp[4][4];
	if (giro>0) {		//counterclockwise
		for (i=0;i<4;i++)
			for (j=0;j<4;j++) tmp[3-j][i]=pieza[i][j];
		for (i=0;i<4;i++)
			for (j=0;j<4;j++) pieza[i][j]=tmp[i][j];
	}
	if (giro<0) {		//clockwise
		for (i=0;i<4;i++)
			for (j=0;j<4;j++) tmp[j][3-i]=pieza[i][j];
		for (i=0;i<4;i++)
			for (j=0;j<4;j++) pieza[i][j]=tmp[i][j];
	}
}

// set initial values for variables and clear screen
void init()
{
	register unsigned char i,j;

	for (i=0;i<ALTO;i++) {
		for (j=1;j<ANCHO+1;j++) campo[i][j]=0;
		campo[i][0]=campo[i][ANCHO+1]=9;
	}
	for (j=0;j<ANCHO+2;j++) campo[i][j]=9;
	for (i=0;i<ALTO+1;i++) for(j=0;j<ANCHO+2;j++) oldc[i][j]=0xff;
	for (i=0;i<4;i++) for (j=0;j<4;j++) pieza[i][j]=0;
	xp=4; yp=-4;

	// CLS
	pvideo=(uint8_t *)0x7000;
	for (i=0;i<64;i++)
	    for (j=0;j<32;j++) *pvideo++=0xAA;	// Blue background

	fsdelay(30);

}

// Display the changes since the last update
void display()
{
	register char i,j,ip,jp,ch;

	for (i=0;i<ALTO+1;i++) {
	    for (j=0;j<ANCHO+2;j++) {
			ch=0;
			if (campo[i][j]) ch=campo[i][j];
			ip=i-yp;
			if (ip>=0 && ip<4) {
				jp=j-xp;
				if (jp>=0 && jp<4) if (pieza[ip][jp]) ch=pieza[ip][jp];
			}
			if (oldc[i][j]!=ch) {
				oldc[i][j]=ch;
				cuadro(j,i,ch);
			}
	    }
	}
}

//////////////////////////////////////////////
//               MAIN program               //
//////////////////////////////////////////////

#define INIDEL 15	//initial falling delay (15*60ms = 900ms)
#define DELSTEP 10	//increment speed every DELSTEP lines

main()
{
    signed char i,j,k,np,sigp,del,dl,npiezas;
    unsigned char nlineas,max;

	initsrcn();

    srand=0x1234;
    max=0;
    
    while(1) {
		init();
		display();
		gotoxy(14,10);
		putimg(maximg,4,5);
		gotoxy(14,13);
		prtnum(max);

		sigp=rand()%7;
		npiezas=nlineas=0;
		while(1) {
			// random next tetronim
			npiezas++;
			np=sigp;
			sigp=rand()%7;
			// draw it outside the field (next to fall)
			for (i=0;i<2;i++)
				for(j=0;j<4;j++)
					cuadro(ANCHO+3+j,i,piezas[sigp][i][j]);
			// load the current tetronim to its bitmap
			for (i=0;i<4;i++)
				for (j=0;j<4;j++)
				pieza[i][j]=(i==0 || i==3)?0:piezas[np][i-1][j];
			// initail position
			xp=4; yp=-2;
			// collision on init?: Game Over
			if (testpos(xp,yp)) break;
			// set speed
			del=INIDEL-nlineas/DELSTEP; if (del<1) del=1; 
			dl=del;
			for (;;) { // falling loop
				// keyboard controls
				np=0;	// redraw flag
				switch(getch_vt()) {
				case K_L:	
					if (!testpos(xp-1,yp)) xp--;
					np=1;
					break;
				case K_R:	
					if (!testpos(xp+1,yp)) xp++;
					np=1;break;
				case K_U:	
					rota(1);
					if(testpos(xp,yp)) rota(-1);
					np=1;
					break;
				case K_D:	// Down => drop it completely
					while (!testpos(xp,yp+1)) {
						yp++;
						display();
						fsdelay(3);
					}
					goto nuevapieza;
				case 'p':	// Pause / Continue
					while(getch_vt()!='c') fsdelay(3);
					break;
				}
				// Timed fall
				if (!(--dl)) {	
					dl=del;
					if (testpos(xp,yp+1)) break;
					yp++;
					np=1;
				}
				if (np) display();	// update screen if needed
				fsdelay(3);			// 60ms delay
			}
	nuevapieza:	// The current tetronim cannot drop more: add it to the field
			for (i=0;i<4;i++)
				for (j=0;j<4;j++)
					if (yp+i>=0 && yp+i<ALTO && xp+j>0 && xp+j<ANCHO+1)
					    campo[yp+i][xp+j]|=pieza[i][j];
			// Do we have some line to "burn"?
			xp=yp=-4;
			for (i=0;i<ALTO;i++) {
				for (j=1;j<ANCHO+1;j++) if (!campo[i][j]) break;
				if (j==ANCHO+1) {	// full line => "burn it"
					// Flash	
					for (k=0;k<8;k++) {
						svar.syso^=0x10;;
					    *(volatile uint8_t *)0x68ff=svar.syso;	// Graphics mode
						fsdelay(2);
					}
					// delete that line and scrool down upper lines
					for (j=1;j<ANCHO+1;j++)
						for (k=i;k>=0;k--)
							campo[k][j]=(k)?campo[k-1][j]:0;
					// Update scores
					nlineas++;		
				    gotoxy(14,7);
				    prtnum(nlineas);
					if (nlineas>max) {
						max=nlineas;
					    gotoxy(14,13);
					    prtnum(max);
					}
					display();
					fsdelay(6);
				}
			}
		}
		// Game over
		gotoxy(1,9);
		putimg(gameover,10,7);
		while(getch_vt()==0) rand();	// wait for key press
		initsrcn();				// Display init screen again
    }
}
