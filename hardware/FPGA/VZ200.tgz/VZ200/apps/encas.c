/*-----------------------------------------------------------------------------
	BIN to .CAS file converter (cassette image files for Vtech VZ200)
							J. Arias (2025)
-----------------------------------------------------------------------------*/

#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>

#define SZ	(64<<10)
#define SADDR	(0x7B00)	// default start address

uint8_t buf[SZ],obuf[256];

void usage(char *name)
{
	printf("usage: %s [options] <file.bin> <file.cas>\n",name);
	printf("  options:\n");
	printf("  -t <type byte> (in hex: 0xF0: BASIC, 0xF1: Binary, 0xF4: Data)\n");
	printf("  -s <start address> (in hex)\n");
	printf("  -f <filename> (no spaces)\n");
	exit(0);
}

int main (int argc, char **argv)
{
	int i,iarg,j,k,nbytes,type,chk,sa,ea;
	char *fname;
	FILE *fp;
	
	sa=SADDR;		// default Start ADDRESS
	type=0xF1;		// default Type
	fname=NULL;
	
	for (iarg=1;iarg<argc;iarg++) {
		if (argv[iarg][0]=='-') {
			switch(argv[iarg][1]) {
			case 't':	type=strtoul(argv[++iarg],NULL,0); break;
			case 's':	sa=strtoul(argv[++iarg],NULL,0); break;
			case 'f':	fname=argv[++iarg]; break;
			default: 	usage(argv[0]);
			}
		} else break;
	}
	if (iarg+2 > argc) usage(argv[0]);
	
	if (!fname) fname=argv[iarg+1];
	 
	// Read .BIN file
	if ((fp=fopen(argv[iarg],"rb"))==NULL) {fprintf(stderr,"fopen (rd) failed: %s\n",argv[iarg]); exit(1);}
	nbytes=fread(buf,1,SZ,fp);
	fclose(fp);

	// get values 
	ea=sa+nbytes;
	chk=(sa&0xff)+(sa>>8)+(ea&0xff)+(ea>>8);
	for (i=0;i<nbytes;i++) chk+=buf[i];
	chk&=0xffff;
	printf("\nType:          $%02X\n",type);
	printf(  "Start address: $%04X\n",sa);
	printf(  "End address:   $%04X\n",ea);
	printf(  "Checksum:      $%04X\n",chk);


	// Write .CAS file
	if ((fp=fopen(argv[iarg+1],"wb"))==NULL) {fprintf(stderr,"fopen (wr) failed: %s\n",argv[iarg+1]); exit(1);}

	// start header
	for (i=0;i<128;i++) obuf[i]=0x80;		// Sync bytes
	for (;i<128+5;i++) obuf[i]=0xFE;		// Preamble
	obuf[i++]=type;							// type
	j=0; do {								// filename (uppercase)
		k=fname[j++];
		if (k>='a' && k<='z') k-=32;
		obuf[i++]=k;
	} while (k);
	obuf[i++]=sa&0xff;						// Start Address
	obuf[i++]=sa>>8;
	obuf[i++]=ea&0xff;						// End Address
	obuf[i++]=ea>>8;
	fwrite (obuf,1,i,fp);
	fwrite (buf,1,nbytes,fp);		// data
	i=0;
	obuf[i++]=chk&0xff;						// Checksum
	obuf[i++]=chk>>8;
	for (;i<19+2;i++) obuf[i]=0;			// Trailing zeroes (not really needed)
	fwrite (obuf,1,i,fp);
	fclose(fp);
	
	return 0;
}
