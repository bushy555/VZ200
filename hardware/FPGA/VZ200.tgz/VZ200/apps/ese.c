#include <stdio.h>
#include <stdint.h>

const uint8_t txt[]=
"    ****************            "
"    *              *            "
"    * LASER-200 6K *            "
"    *              *            "
"    ******** TTRIS ********     "
"           *              *     "
"           * J.ARIAS 2025 *     "
"           *              *     "
"           ****************     "
;

main()
{
	int i,j,d;
	printf("const uint8_t initxt[]={\n");
	for (i=0;i<9*32;i+=16){
		for (j=0;j<16;j++) {
			d=txt[i+j];
			if (d==' ') d=0x80;	// black
			else {
				if (d=='*') d=0x80+(1<<4)+15;
				else d&=63;
			}
			printf("0x%02x,",d);
		}
		putchar('\n');
	}
	printf("};\n");

}
