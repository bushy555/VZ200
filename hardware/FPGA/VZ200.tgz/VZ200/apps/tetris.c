
/************* Variables Globales ************/

typedef unsigned char uchar;

#define ANCHO 	10
#define ALTO	15
//#define REVERSE

uchar campo[ALTO+1][16],oldc[ALTO+1][16];
uchar pieza[4][4];

uchar piezas[7][2][4];
const uchar ptab[56]={
        1,1,1,1,        // 0 Barra
        0,0,0,0,
        2,2,2,0,        // 1 /L
        0,0,2,0,
        0,3,3,3,        // 2 L
        0,3,0,0,
        0,0,4,4,        // 3 S
        0,4,4,0,
        5,5,0,0,        // 4 /S
        0,5,5,0,
        0,6,6,6,        // 5 T
        0,0,6,0,
        0,7,7,0,        // 6 Cuadrado
        0,7,7,0
};

void initpt()
{
        uchar *p,*pp,i;
        pp=(uchar *)piezas;
        p=(uchar *)ptab;
        for (i=0;i<56;i++) *pp++=*p++;
}

signed char xp,yp;	// Posici�n de la pieza

/************** RUTINAS asociadas al SISTEMA ****************/

static unsigned long srand;
int rand()
{
    srand=srand* 1103515245 + 12345;
    return (srand>>16)&0x7fff;
}

uchar *pvideo;	// puntero a memoria de video

void _putch(unsigned char a)
{
        *pvideo++=a;
}

void puts(char *p)
{
        while (*p) _putch(*p++);
}

void fsdelay(uchar n)
{
        uchar i;
        for(i=n;i;i--){
        	while (!((*(volatile uchar *)0x68ff)&0x80));	// espera mientras bajo
        	while ((*(volatile uchar *)0x68ff)&0x80);		// espera mientras alto
        }
}

void gotoxy(uchar x,uchar y)
{
	pvideo=(uchar *)0x7000;
	pvideo=&pvideo[(y<<5)+x];
}
void prtnum(uchar x)
{
        _putch('0'+x/100);
        _putch('0'+(x/10)%10);
        _putch('0'+x%10);
}

void cuadro(unsigned char x,unsigned char y, unsigned char tipo)
{
	gotoxy(x,y);
	if (tipo>8) _putch(128+(7<<4)+6);
    else _putch((tipo)? 128+15+((tipo-1)<<4): 128);
}

#define K_L	'j'
#define K_R	'l'
#define K_U	'k'
#define K_D	' '

char getch_vt()
{
	uchar a;
	a=*(volatile uchar *)0x687F;
	if (!(a&0x20)) return 'j';
	if (!(a&0x08)) return 'k';
	if (!(a&0x02)) return 'l';
	if (!((*(volatile uchar *)0x68EF)&0x10)) return ' ';
	if (!((*(volatile uchar *)0x68BF)&0x10)) return 'p';
	if (!((*(volatile uchar *)0x68FB)&0x08)) return 'c';

	return 0;	// sin teclas pulsadas
}

/**************** Rutinas del CORE del programa ***************/

signed char testpos(signed char x, signed char y)
{
	register unsigned char i,j;
	for (i=0;i<4;i++)
		for (j=0;j<4;j++) {
			if (x+j<0) continue;
			if (x+j>ANCHO+1) continue;
			if (y+i<0) continue;
			if (y+i>ALTO) continue;
			if (campo[y+i][x+j] && pieza[i][j]) return 1;
		}
	return 0;
}

void rota(signed char giro)
{
	register unsigned char i,j;
	uchar tmp[4][4];
	if (giro>0) {		//Giro antihorario de 90 grados
		for (i=0;i<4;i++)
			for (j=0;j<4;j++) tmp[3-j][i]=pieza[i][j];
		for (i=0;i<4;i++)
			for (j=0;j<4;j++) pieza[i][j]=tmp[i][j];
	}
	if (giro<0) {		//Giro horario de 90 grados
		for (i=0;i<4;i++)
			for (j=0;j<4;j++) tmp[j][3-i]=pieza[i][j];
		for (i=0;i<4;i++)
			for (j=0;j<4;j++) pieza[i][j]=tmp[i][j];
	}
}

void init()
{
	register unsigned char i,j;

	for (i=0;i<ALTO;i++) {
		for (j=1;j<ANCHO+1;j++) campo[i][j]=0;
		campo[i][0]=campo[i][ANCHO+1]=9;
	}
	for (j=0;j<ANCHO+2;j++) campo[i][j]=9;
	for (i=0;i<ALTO+1;i++) for(j=0;j<ANCHO+2;j++) oldc[i][j]=0xff;
	for (i=0;i<4;i++) for (j=0;j<4;j++) pieza[i][j]=0;
	xp=4; yp=-4;

	pvideo=(uchar *)0x7000;
	for (i=0;i<16;i++)
	    for (j=0;j<32;j++) *pvideo++=0x80;

        fsdelay(30);

	srand=0x1234;
}

void display()
{
	register char i,j,ip,jp,ch;

	for (i=0;i<ALTO+1;i++) {
	    for (j=0;j<ANCHO+2;j++) {
		ch=0;
		if (campo[i][j]) ch=campo[i][j];
		ip=i-yp;
		if (ip>=0 && ip<4) {
		    jp=j-xp;
		    if (jp>=0 && jp<4) if (pieza[ip][jp]) ch=pieza[ip][jp];
		}
		if (oldc[i][j]!=ch) {
		    oldc[i][j]=ch;
		    cuadro(j,i,ch);
		}
	    }
	}
        gotoxy(16,12);
}

/************** Programa **************/
#define INIDEL 15	//0.5 Seg
#define DELSTEP 10	//incremento de velocidad cada DELSTEP lineas


main()
{
    signed char i,j,k,np,sigp,del,dl,npiezas;
    unsigned char nlineas,max;

    initpt();
    max=0;
    for(;;) {
	init();
	display();
	sigp=rand()%7;
	npiezas=nlineas=0;
        gotoxy(14,12);
        puts("MAX");
        gotoxy(14,13);
        prtnum(max);
	for(;;) {
		// Sacamos una pieza aleatoria
		npiezas++;
		np=sigp;
		sigp=rand()%7;
		// Dibujamos la siguiente pieza
		for (i=0;i<2;i++)
		    for(j=0;j<4;j++)
		    	cuadro(ANCHO+3+j,i,piezas[sigp][i][j]);
		// Copiamos pieza actual a su bitmap
		for (i=0;i<4;i++)
		    for (j=0;j<4;j++)
			pieza[i][j]=(i==0 || i==3)?0:piezas[np][i-1][j];
		// Posiciones iniciales
		xp=4; yp=-2;
		// Si no se puede ni empezar: Game Over
		if (testpos(xp,yp)) break;
		del=INIDEL-nlineas/DELSTEP; if (del<1) del=1; dl=del;
		for (;;) { // Bucle de caida
			np=0;
			switch(getch_vt()) {
			case K_L:	if (!testpos(xp-1,yp)) xp--;
					np=1;
					break;
			case K_R:	if (!testpos(xp+1,yp)) xp++;
					np=1;break;
			case K_U:	rota(1);
					if(testpos(xp,yp)) rota(-1);
					np=1;
					break;
			case K_D:	while (!testpos(xp,yp+1)) {
						yp++;
						display();
						fsdelay(3);
						}
					goto nuevapieza;
			case 'p':	while(getch_vt()!='c')
						fsdelay(3);
					break;

			}
			if (!(--dl)) {	// ABAJO
				dl=del;
				if (testpos(xp,yp+1)) break;
				yp++;
				np=1;
			}
			if (np) display();
			fsdelay(3);
		}
nuevapieza:	// A�adimos la pieza al campo
		for (i=0;i<4;i++)
		    for (j=0;j<4;j++)
		    	if (yp+i>=0 && yp+i<ALTO && xp+j>0 && xp+j<ANCHO+1)
		    	    campo[yp+i][xp+j]|=pieza[i][j];
		// Comprobamos si hay que "quemar" alguna l�nea
		xp=yp=-4;
		for (i=0;i<ALTO;i++) {
		    for (j=1;j<ANCHO+1;j++) if (!campo[i][j]) break;
		    if (j==ANCHO+1) {	// Linea completa: Scroll hacia abajo
			for (j=1;j<ANCHO+1;j++)
			    for (k=i;k>=0;k--)
				campo[k][j]=(k)?campo[k-1][j]:0;
			nlineas++;
                        gotoxy(14,10);
                        //puts("\033[01;30m"); 
                        prtnum(nlineas);
			if (nlineas>max) {
				max=nlineas;
                                gotoxy(14,13);
                                //puts("\033[01;30m"); 
                                prtnum(max);
			}
			display();
			fsdelay(6);
		    }
		}
	}
    while(getch_vt()!=K_U) fsdelay(3);	
    }
}
