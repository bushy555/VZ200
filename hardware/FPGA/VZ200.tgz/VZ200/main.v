///////////////////////////////////////////////////////
// Vtech Laser 200 computer recreated
//  by Jesus Arias (2025)
//

`include "system.v"

`ifndef ALHAMBRA		// SIMRETRO board
`include "pll.v"
	module main(		// TOP module with actual FPGA pins
		output TXD, 
		input  RXD, 
		input  CLKIN, 	// 16 MHz
		output HSYN, 
		output VSYN, 
		output [3:0]R,
		output [3:0]G,
		output [3:0]B,
		inout  [15:0]XD,
		output [15:0]XA,
		output XWE,
		output XOE,
		output XBHE,
		output XBLE,
		
		input  MISO,
		output MOSI,
		output SCK,
		output SSBF,
		output SSBSD,
			
		output PWM,
		input  KCLK,
		input  KDAT,
		
	);
	assign XOE=1;
	assign XWE=1;
	assign XBLE=1;
	assign XBHE=1;
	wire [7:0]LED;
`else					// ALHAMBRA-II board
	`include "pllal.v"
	module main(
		input  CLK, 		// 12MHz
		
		input  FTTX,		// Serial port
		output FTRX,

		input  MISO,		// Flash SPI
		output MOSI,
		output SCK,
		output SS,
			
		output [7:0]LED,	// LED, switches
		input  SW1,
		input  SW2,
		
		inout  [13:0]D,		// Digital pins
		inout  [5:0]DD,		// Digital / Analog pins
		
		inout  ADC_SDA,		// I2C pins
		inout  ADC_SCL,
		input  ADC_INT
	);

	wire [3:0]R;
	wire [3:0]G;
	wire [3:0]B;
	wire CLKIN, HSYN, VSYN, KCLK, KDAT, SSBF, SSBSD,PWM;
	wire TXD,RXD;
	assign CLKIN=CLK;
	assign D[0]=R[3];	// AP-VGA pinout
	assign D[1]=R[2];
	assign D[2]=G[3];
	assign D[3]=G[2];
	assign D[4]=B[3];
	assign D[5]=B[2];
	assign D[6]=HSYN;
	assign D[7]=VSYN;
	assign KCLK=D[8];	// PS2 keyboard
	assign KDAT=D[9];
	assign D[10]=PWM;	// Audio output
	assign SS=SSBF;		// Flash chip select
	assign FTRX=TXD;
	assign RXD=FTTX;
	
`endif

wire clk50,pll_lock;
//-- PLL instance (50MHz)
pll
  pll1(
	.clock_in(CLKIN),
	.clock_out(clk50),
	.locked(pll_lock)
	);

//-- System instance

SYSTEM sys1(
		.clk(clk50), .reset(reset),
	    .hsyn(HSYN), .vsyn(VSYN), .video({R,G,B}),
		.sck(SCK), .miso(MISO), .mosi(MOSI), .ss1(SSBF), .ss2(SSBSD), 
		.sound(PWM), 
		.txd(TXD), .rxd(RXD), 
		.kclk(KCLK), .kdat(KDAT)
		, .debug(LED)
);


// Internal RESET: 31 VSYN (~0.5sec)
wire reset;
reg [4:0]cnt=5'b11111;
assign reset=(cnt!=0);

always @(posedge VSYN) cnt<=reset ? cnt-1: cnt;


endmodule


