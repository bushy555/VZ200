/*-----------------------------------------------------------------------------
	.CAS to .WAV file converter (cassette image files for Vtech VZ200)
							J. Arias (2025)
-----------------------------------------------------------------------------*/

#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>

const uint8_t abuf0[18]={
	200,200,200,55,55,55,
	200,200,200,200,200,200,55,55,55,55,55,55
};
const uint8_t abuf1[18]={
	200,200,200,55,55,55,
	200,200,200,55,55,55,
	200,200,200,55,55,55
};
#define SZ	(65<<10)		// File buffer

uint8_t buf[SZ];

int main (int argc, char **argv)
{
	int i,j,nbytes,d;
	FILE *fp;
	
	if (argc<3) {
		printf("usage: %s <file.cas> <file.wav>\n",argv[0]);
		exit(0);
	}
	// Read .CAS file
	if ((fp=fopen(argv[1],"rb"))==NULL) {fprintf(stderr,"fopen (rd) failed: %s\n",argv[1]); exit(1);}
	nbytes=fread(buf,1,SZ,fp);
	fclose(fp);

	// Write .RAW file
	if ((fp=fopen("__tmp__","wb"))==NULL) {fprintf(stderr,"fopen (wr) failed: __tmp__\n"); exit(1);}
	for (i=0;i<nbytes;i++) {
		d=buf[i];
		for (j=0;j<8;j++) {
			fwrite((d&0x80)?abuf1:abuf0,1,18,fp);
			d<<=1;
		}
	}
	fclose(fp);
	
	// Convert RAW file to WAV using sox
	sprintf(buf,"sox -t raw -e unsigned-integer -b 8 -c 1 -r 10000 __tmp__  -r 8000 %s",argv[2]);
	system(buf);
	system("rm __tmp__");
	
	return 0;
}
