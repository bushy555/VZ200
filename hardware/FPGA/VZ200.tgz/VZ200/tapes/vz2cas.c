/*-----------------------------------------------------------------------------
	.VZ to .CAS file converter (cassette image files for Vtech VZ200)
							J. Arias (2025)
-----------------------------------------------------------------------------*/

#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>

#define SZ	(1<<16)

uint8_t buf[SZ],obuf[256];

int main (int argc, char **argv)
{
	int i,j,nbytes,type,chk,sa,ea;
	FILE *fp;
	
	if (argc<3) {
		printf("usage: %s <file.vz> <file.cas>\n",argv[0]);
		exit(0);
	}
	// Read .VZ file
	if ((fp=fopen(argv[1],"rb"))==NULL) {fprintf(stderr,"fopen (rd) failed: %s\n",argv[1]); exit(1);}
	nbytes=fread(buf,1,SZ,fp);
	fclose(fp);

	// Check for valid file 
	if ((buf[20]!=0) || ((buf[21]&0xFA)!=0xF0)) {fprintf(stderr,"Invalid file: %s\n",argv[1]); exit(1);} 

	// Change filename to uppercase
	for (i=4,j=0;buf[i];i++) if (buf[i]>='a' && buf[i]<='z') {buf[i]-=32; j=1;}
	
	// print info
	printf("VZ filename:   %s%s\n",&buf[4],(j)?" (changed to uppercase)":"");
	printf("Type:          $%02X   ",buf[21]);
	if (buf[21]==0xf0) printf("(T: BASIC)");
	if (buf[21]==0xf1) printf("(B: Binary)");
	if (buf[21]==0xf4) printf("(A: Data)");
	sa=buf[22] | (buf[23]<<8);
	ea=sa+nbytes-24;
	chk=(sa&0xff)+(sa>>8)+(ea&0xff)+(ea>>8);
	for (i=24;i<nbytes;i++) chk+=buf[i];
	chk&=0xffff;
	printf("\nStart address: $%04X\n",sa);
	printf(  "End address:   $%04X\n",ea);
	printf(  "Checksum:      $%04X\n",chk);

	// Write .CAS file
	if ((fp=fopen(argv[2],"wb"))==NULL) {fprintf(stderr,"fopen (wr) failed: %s\n",argv[2]); exit(1);}
	for (i=0;i<128;i++) obuf[i]=0x80;		// Sync bytes
	for (;i<128+5;i++) obuf[i]=0xFE;		// Preamble
	obuf[i++]=buf[21];						// type
	for (j=4;buf[j];j++) obuf[i++]=buf[j];	// filename
	obuf[i++]=0;							// terminator
	obuf[i++]=sa&0xff;						// Start Address
	obuf[i++]=sa>>8;
	obuf[i++]=ea&0xff;						// End Address
	obuf[i++]=ea>>8;
	fwrite (obuf,1,i,fp);
	fwrite (&buf[24],1,nbytes-24,fp);		// data
	i=0;
	obuf[i++]=chk&0xff;						// Checksum
	obuf[i++]=chk>>8;
	for (;i<19+2;i++) obuf[i]=0;			// Trailing zeroes (not really needed)
	fwrite (obuf,1,i,fp);
	fclose(fp);
	
	return 0;
}
