#include <stdlib.h>
#include <stdio.h>

#define MAXB	(1<<16)
unsigned char mem[MAXB];

main()
{
	int i,j,k,x,y,d,nb;
	FILE *fp;
	unsigned char *pic;
	
	if ((fp=fopen("6847charset.pbm","rb"))==NULL) exit(1);
	fgets(mem,MAXB,fp);
	if (mem[0]!='P' || mem[1]!='4') exit(1);
	do {
		fgets(mem,MAXB,fp);
	} while (mem[0]=='#');
	nb=fread(mem,1,MAXB,fp);
	fclose(fp);
	
	printf("%d bytes\n",nb);
	if ((fp=fopen("6847chargen.list","w"))==NULL) exit(1);

	for (i=0;i<64;i++) {
		x=i&31; y=(i/32)*12+3;
		for (j=0;j<8;j++) {
			d=0xFF^mem[(y+j)*32+x];
			fprintf(fp,"%02x\n",d>>1);
			for (k=0;k<5;k++) putchar((d&(1<<(5-k)))? '#' : '_');
			putchar('\n');
		}
		putchar('\n');
	}

	fclose(fp);
}
