z80dasm: Portable Z80 disassembler
Copyright (C) Marcel de Kogel 1996,1997
    di                     ; 000000 F3 
    xor    a               ; 000001 AF 
    ld     ($6800),a       ; 000002 32 00 68 
    jp     $0674           ; 000005 C3 74 06 
    jp     $7800           ; 000008 C3 00 78 
    pop    hl              ; 00000B E1 
    jp     (hl)            ; 00000C E9 
    nop                    ; 00000D 00 
    nop                    ; 00000E 00 
    nop                    ; 00000F 00 
    jp     $7803           ; 000010 C3 03 78 
    push   bc              ; 000013 C5 
    ld     b,$01           ; 000014 06 01 
    jr     $0046           ; 000016 18 2E 
    jp     $7806           ; 000018 C3 06 78 
    push   bc              ; 00001B C5 
    ld     b,$02           ; 00001C 06 02 
    jr     $0046           ; 00001E 18 26 
    jp     $7809           ; 000020 C3 09 78 
    push   bc              ; 000023 C5 
    ld     b,$04           ; 000024 06 04 
    jr     $0046           ; 000026 18 1E 
    jp     $780c           ; 000028 C3 0C 78 
    ld     de,$7815        ; 00002B 11 15 78 
    jr     $0013           ; 00002E 18 E3 
    jp     $780f           ; 000030 C3 0F 78 
    ld     de,$781d        ; 000033 11 1D 78 
    jr     $001b           ; 000036 18 E3 
    jp     $2eb8           ; 000038 C3 B8 2E 
    ld     de,$7825        ; 00003B 11 25 78 
    jr     $001b           ; 00003E 18 DB 
    jp     $2efd           ; 000040 C3 FD 2E 
    ret                    ; 000043 C9 
    nop                    ; 000044 00 
    nop                    ; 000045 00 
    jp     $03c2           ; 000046 C3 C2 03 
    call   $002b           ; 000049 CD 2B 00 
    or     a               ; 00004C B7 
    ret    nz              ; 00004D C0 
    jr     $0049           ; 00004E 18 F9 
    ld     hl,($7820)      ; 000050 2A 20 78 
    ld     a,(hl)          ; 000053 7E 
    ld     ($783c),a       ; 000054 32 3C 78 
    ret                    ; 000057 C9 
    ld     c,h             ; 000058 4C 
    cp     $54             ; 000059 FE 54 
    jr     nz,$0033        ; 00005B 20 D6 
    ld     iy,$0bf1        ; 00005D FD 21 F1 0B 
    ld     a,b             ; 000061 78 
    or     c               ; 000062 B1 
    jr     nz,$0060        ; 000063 20 FB 
    ret                    ; 000065 C9 
    ld     sp,$0600        ; 000066 31 00 06 
    ld     a,($68ec)       ; 000069 3A EC 68 
    inc    a               ; 00006C 3C 
    cp     $02             ; 00006D FE 02 
    jp     nc,$0000        ; 00006F D2 00 00 
    jp     $06cc           ; 000072 C3 CC 06 
    ld     de,$7880        ; 000075 11 80 78 
    ld     hl,$18f7        ; 000078 21 F7 18 
    ld     bc,$0027        ; 00007B 01 27 00 
    ldir                   ; 00007E ED B0 
    ld     hl,$79e5        ; 000080 21 E5 79 
    ld     (hl),$3a        ; 000083 36 3A 
    inc    hl              ; 000085 23 
    ld     (hl),b          ; 000086 70 
    inc    hl              ; 000087 23 
    ld     (hl),$2c        ; 000088 36 2C 
    inc    hl              ; 00008A 23 
    ld     ($78a7),hl      ; 00008B 22 A7 78 
    ld     de,$012d        ; 00008E 11 2D 01 
    ld     b,$1c           ; 000091 06 1C 
    ld     hl,$7952        ; 000093 21 52 79 
    ld     (hl),$c3        ; 000096 36 C3 
    inc    hl              ; 000098 23 
    ld     (hl),e          ; 000099 73 
    inc    hl              ; 00009A 23 
    ld     (hl),d          ; 00009B 72 
    inc    hl              ; 00009C 23 
    djnz   $0096           ; 00009D 10 F7 
    ld     b,$15           ; 00009F 06 15 
    ld     (hl),$c9        ; 0000A1 36 C9 
    inc    hl              ; 0000A3 23 
    inc    hl              ; 0000A4 23 
    inc    hl              ; 0000A5 23 
    djnz   $00a1           ; 0000A6 10 F9 
    ld     hl,$7ae8        ; 0000A8 21 E8 7A 
    ld     (hl),b          ; 0000AB 70 
    ld     sp,$79f8        ; 0000AC 31 F8 79 
    call   $1b8f           ; 0000AF CD 8F 1B 
    call   $01c9           ; 0000B2 CD C9 01 
    nop                    ; 0000B5 00 
    nop                    ; 0000B6 00 
    nop                    ; 0000B7 00 
    nop                    ; 0000B8 00 
    nop                    ; 0000B9 00 
    nop                    ; 0000BA 00 
    nop                    ; 0000BB 00 
    nop                    ; 0000BC 00 
    nop                    ; 0000BD 00 
    jr     $00c4           ; 0000BE 18 04 
    rst    10h             ; 0000C0 D7 
    or     a               ; 0000C1 B7 
    jr     nz,$00d6        ; 0000C2 20 12 
    ld     hl,$7b4c        ; 0000C4 21 4C 7B 
    inc    hl              ; 0000C7 23 
    ld     a,h             ; 0000C8 7C 
    or     l               ; 0000C9 B5 
    jr     z,$00e7         ; 0000CA 28 1B 
    ld     a,(hl)          ; 0000CC 7E 
    ld     b,a             ; 0000CD 47 
    cpl                    ; 0000CE 2F 
    ld     (hl),a          ; 0000CF 77 
    cp     (hl)            ; 0000D0 BE 
    ld     (hl),b          ; 0000D1 70 
    jr     z,$00c7         ; 0000D2 28 F3 
    jr     $00e7           ; 0000D4 18 11 
    call   $1e5a           ; 0000D6 CD 5A 1E 
    or     a               ; 0000D9 B7 
    jp     nz,$1997        ; 0000DA C2 97 19 
    ex     de,hl           ; 0000DD EB 
    dec    hl              ; 0000DE 2B 
    ld     a,$8f           ; 0000DF 3E 8F 
    ld     b,(hl)          ; 0000E1 46 
    ld     (hl),a          ; 0000E2 77 
    cp     (hl)            ; 0000E3 BE 
    ld     (hl),b          ; 0000E4 70 
    jr     nz,$00b5        ; 0000E5 20 CE 
    dec    hl              ; 0000E7 2B 
    ld     de,$7c14        ; 0000E8 11 14 7C 
    rst    18h             ; 0000EB DF 
    jp     c,$197a         ; 0000EC DA 7A 19 
    ld     de,$ffce        ; 0000EF 11 CE FF 
    ld     ($78b1),hl      ; 0000F2 22 B1 78 
    add    hl,de           ; 0000F5 19 
    ld     ($78a0),hl      ; 0000F6 22 A0 78 
    call   $1b4d           ; 0000F9 CD 4D 1B 
    call   $3484           ; 0000FC CD 84 34 
    ld     hl,$010f        ; 0000FF 21 0F 01 
    call   $28a7           ; 000102 CD A7 28 
    im     1               ; 000105 ED 56 
    jp     $068e           ; 000107 C3 8E 06 
    nop                    ; 00010A 00 
    ld     a,(hl)          ; 00010B 7E 
    inc    hl              ; 00010C 23 
    cp     $0d             ; 00010D FE 0D 
    ld     d,(hl)          ; 00010F 56 
    ld     c,c             ; 000110 49 
    ld     b,h             ; 000111 44 
    ld     b,l             ; 000112 45 
    ld     c,a             ; 000113 4F 
    jr     nz,$016a        ; 000114 20 54 
    ld     b,l             ; 000116 45 
    ld     b,e             ; 000117 43 
    ld     c,b             ; 000118 48 
    ld     c,(hl)          ; 000119 4E 
    ld     c,a             ; 00011A 4F 
    ld     c,h             ; 00011B 4C 
    ld     c,a             ; 00011C 4F 
    ld     b,a             ; 00011D 47 
    ld     e,c             ; 00011E 59 
    dec    c               ; 00011F 0D 
    ld     b,d             ; 000120 42 
    ld     b,c             ; 000121 41 
    ld     d,e             ; 000122 53 
    ld     c,c             ; 000123 49 
    ld     b,e             ; 000124 43 
    jr     nz,$017d        ; 000125 20 56 
    ld     ($302e),a       ; 000127 32 2E 30 
    dec    c               ; 00012A 0D 
    dec    c               ; 00012B 0D 
    nop                    ; 00012C 00 
    ld     e,$2c           ; 00012D 1E 2C 
    jp     $19a2           ; 00012F C3 A2 19 
    rst    10h             ; 000132 D7 
    xor    a               ; 000133 AF 
    ld     bc,$803e        ; 000134 01 3E 80 
    ld     bc,$013e        ; 000137 01 3E 01 
    push   af              ; 00013A F5 
    rst    08h             ; 00013B CF 
    jr     z,$010b         ; 00013C 28 CD 
    inc    e               ; 00013E 1C 
    dec    hl              ; 00013F 2B 
    cp     $80             ; 000140 FE 80 
    jp     nc,$1e4a        ; 000142 D2 4A 1E 
    push   af              ; 000145 F5 
    rst    08h             ; 000146 CF 
    inc    l               ; 000147 2C 
    call   $2b1c           ; 000148 CD 1C 2B 
    cp     $40             ; 00014B FE 40 
    jp     nc,$1e4a        ; 00014D D2 4A 1E 
    ld     e,a             ; 000150 5F 
    xor    a               ; 000151 AF 
    ld     d,a             ; 000152 57 
    ex     de,hl           ; 000153 EB 
    add    hl,hl           ; 000154 29 
    add    hl,hl           ; 000155 29 
    add    hl,hl           ; 000156 29 
    add    hl,hl           ; 000157 29 
    add    hl,hl           ; 000158 29 
    ex     de,hl           ; 000159 EB 
    pop    af              ; 00015A F1 
    push   af              ; 00015B F5 
    srl    a               ; 00015C CB 3F 
    srl    a               ; 00015E CB 3F 
    add    a,e             ; 000160 83 
    ld     e,a             ; 000161 5F 
    ld     a,d             ; 000162 7A 
    or     $70             ; 000163 F6 70 
    ld     d,a             ; 000165 57 
    pop    af              ; 000166 F1 
    and    $03             ; 000167 E6 03 
    add    a,a             ; 000169 87 
    ld     b,a             ; 00016A 47 
    pop    af              ; 00016B F1 
    or     a               ; 00016C B7 
    jp     z,$38e7         ; 00016D CA E7 38 
    push   af              ; 000170 F5 
    ld     c,$3f           ; 000171 0E 3F 
    ld     a,($7846)       ; 000173 3A 46 78 
    sla    a               ; 000176 CB 27 
    sla    a               ; 000178 CB 27 
    rrc    a               ; 00017A CB 0F 
    rrc    c               ; 00017C CB 09 
    djnz   $017a           ; 00017E 10 FA 
    jp     $3903           ; 000180 C3 03 39 
    ld     hl,$7839        ; 000183 21 39 78 
    res    3,(hl)          ; 000186 CB 9E 
    ld     hl,$0384        ; 000188 21 84 03 
    call   $28a7           ; 00018B CD A7 28 
    jp     $36cf           ; 00018E C3 CF 36 
    pop    af              ; 000191 F1 
    cp     $20             ; 000192 FE 20 
    jr     nz,$01aa        ; 000194 20 14 
    ld     a,(de)          ; 000196 1A 
    inc    de              ; 000197 13 
    cp     $20             ; 000198 FE 20 
    jr     z,$0196         ; 00019A 28 FA 
    cp     $d7             ; 00019C FE D7 
    push   hl              ; 00019E E5 
    ld     a,($7899)       ; 00019F 3A 99 78 
    or     a               ; 0001A2 B7 
    jr     nz,$01ab        ; 0001A3 20 06 
    call   $0358           ; 0001A5 CD 58 03 
    or     a               ; 0001A8 B7 
    jr     z,$01bc         ; 0001A9 28 11 
    push   af              ; 0001AB F5 
    xor    a               ; 0001AC AF 
    ld     ($7899),a       ; 0001AD 32 99 78 
    inc    a               ; 0001B0 3C 
    call   $2857           ; 0001B1 CD 57 28 
    pop    af              ; 0001B4 F1 
    ld     hl,($78d4)      ; 0001B5 2A D4 78 
    ld     (hl),a          ; 0001B8 77 
    jp     $2884           ; 0001B9 C3 84 28 
    ld     hl,$1928        ; 0001BC 21 28 19 
    ld     ($7921),hl      ; 0001BF 22 21 79 
    ld     a,$03           ; 0001C2 3E 03 
    ld     ($78af),a       ; 0001C4 32 AF 78 
    pop    hl              ; 0001C7 E1 
    ret                    ; 0001C8 C9 
    ld     a,$1c           ; 0001C9 3E 1C 
    call   $033a           ; 0001CB CD 3A 03 
    ld     a,$1f           ; 0001CE 3E 1F 
    jp     $033a           ; 0001D0 C3 3A 03 
    ld     a,r             ; 0001D3 ED 5F 
    ld     ($78ab),a       ; 0001D5 32 AB 78 
    ret                    ; 0001D8 C9 
    ld     d,h             ; 0001D9 54 
    ld     b,a             ; 0001DA 47 
    ld     b,d             ; 0001DB 42 
    dec    (hl)            ; 0001DC 35 
    ld     c,(hl)          ; 0001DD 4E 
    ld     (hl),$59        ; 0001DE 36 59 
    ld     c,b             ; 0001E0 48 
    ld     d,a             ; 0001E1 57 
    ld     d,e             ; 0001E2 53 
    ld     e,b             ; 0001E3 58 
    ld     ($392e),a       ; 0001E4 32 2E 39 
    ld     c,a             ; 0001E7 4F 
    ld     c,h             ; 0001E8 4C 
    nop                    ; 0001E9 00 
    nop                    ; 0001EA 00 
    nop                    ; 0001EB 00 
    nop                    ; 0001EC 00 
    nop                    ; 0001ED 00 
    dec    l               ; 0001EE 2D 
    dec    c               ; 0001EF 0D 
    ld     a,($4445)       ; 0001F0 3A 45 44 
    ld     b,e             ; 0001F3 43 
    inc    sp              ; 0001F4 33 
    inc    l               ; 0001F5 2C 
    jr     c,$0241         ; 0001F6 38 49 
    ld     c,e             ; 0001F8 4B 
    ld     d,c             ; 0001F9 51 
    ld     b,c             ; 0001FA 41 
    ld     e,d             ; 0001FB 5A 
    ld     sp,$3020        ; 0001FC 31 20 30 
    ld     d,b             ; 0001FF 50 
    dec    sp              ; 000200 3B 
    ld     d,d             ; 000201 52 
    ld     b,(hl)          ; 000202 46 
    ld     d,(hl)          ; 000203 56 
    inc    (hl)            ; 000204 34 
    ld     c,l             ; 000205 4D 
    scf                    ; 000206 37 
    ld     d,l             ; 000207 55 
    ld     c,d             ; 000208 4A 
    adc    a,h             ; 000209 8C 
    adc    a,c             ; 00020A 89 
    nop                    ; 00020B 00 
    dec    h               ; 00020C 25 
    ld     e,(hl)          ; 00020D 5E 
    ld     h,$83           ; 00020E 26 83 
    add    a,(hl)          ; 000210 86 
    adc    a,l             ; 000211 8D 
    add    a,d             ; 000212 82 
    nop                    ; 000213 00 
    ld     ($293e),hl      ; 000214 22 3E 29 
    ld     e,e             ; 000217 5B 
    ccf                    ; 000218 3F 
    nop                    ; 000219 00 
    nop                    ; 00021A 00 
    nop                    ; 00021B 00 
    nop                    ; 00021C 00 
    nop                    ; 00021D 00 
    dec    a               ; 00021E 3D 
    dec    c               ; 00021F 0D 
    ld     hl,($848b)      ; 000220 2A 8B 84 
    nop                    ; 000223 00 
    inc    hl              ; 000224 23 
    inc    a               ; 000225 3C 
    jr     z,$01ad         ; 000226 28 85 
    cpl                    ; 000228 2F 
    adc    a,(hl)          ; 000229 8E 
    add    a,c             ; 00022A 81 
    add    a,b             ; 00022B 80 
    ld     hl,$4020        ; 00022C 21 20 40 
    ld     e,l             ; 00022F 5D 
    dec    hl              ; 000230 2B 
    add    a,a             ; 000231 87 
    adc    a,b             ; 000232 88 
    nop                    ; 000233 00 
    inc    h               ; 000234 24 
    ld     e,h             ; 000235 5C 
    daa                    ; 000236 27 
    adc    a,d             ; 000237 8A 
    adc    a,a             ; 000238 8F 
    jp     z,$b58d         ; 000239 CA 8D B5 
    or     h               ; 00023C B4 
    sub    a               ; 00023D 97 
    adc    a,(hl)          ; 00023E 8E 
    sub    l               ; 00023F 95 
    add    a,h             ; 000240 84 
    cp     l               ; 000241 BD 
    call   z,$b9b1         ; 000242 CC B1 B9 
    dec    de              ; 000245 1B 
    adc    a,e             ; 000246 8B 
    adc    a,h             ; 000247 8C 
    dec    d               ; 000248 15 
    nop                    ; 000249 00 
    nop                    ; 00024A 00 
    nop                    ; 00024B 00 
    nop                    ; 00024C 00 
    nop                    ; 00024D 00 
    ld     bc,$0000        ; 00024E 01 00 00 
    add    a,a             ; 000251 87 
    adc    a,d             ; 000252 8A 
    or     e               ; 000253 B3 
    sbc    a,h             ; 000254 9C 
    add    hl,bc           ; 000255 09 
    cp     e               ; 000256 BB 
    adc    a,c             ; 000257 89 
    cp     h               ; 000258 BC 
    add    a,c             ; 000259 81 
    sbc    a,l             ; 00025A 9D 
    push   hl              ; 00025B E5 
    cp     d               ; 00025C BA 
    ld     a,(bc)          ; 00025D 0A 
    adc    a,b             ; 00025E 88 
    or     d               ; 00025F B2 
    ld     a,a             ; 000260 7F 
    sub    d               ; 000261 92 
    sub    c               ; 000262 91 
    xor    a               ; 000263 AF 
    sbc    a,b             ; 000264 98 
    ex     af,af'          ; 000265 08 
    add    a,b             ; 000266 80 
    adc    a,a             ; 000267 8F 
    sub    e               ; 000268 93 
    jp     m,$9e94         ; 000269 FA 94 9E 
    rst    18h             ; 00026C DF 
    cp     a               ; 00026D BF 
    ret    po              ; 00026E E0 
    ld     sp,hl           ; 00026F F9 
    add    a,e             ; 000270 83 
    push   af              ; 000271 F5 
    call   p,$e1a0         ; 000272 F4 A0 E1 
    nop                    ; 000275 00 
    exx                    ; 000276 D9 
    out    ($00),a         ; 000277 D3 00 
    nop                    ; 000279 00 
    nop                    ; 00027A 00 
    nop                    ; 00027B 00 
    nop                    ; 00027C 00 
    nop                    ; 00027D 00 
    ld     bc,$0000        ; 00027E 01 00 00 
    di                     ; 000281 F3 
    sub    b               ; 000282 90 
    sub    (hl)            ; 000283 96 
    ex     (sp),hl         ; 000284 E3 
    nop                    ; 000285 00 
    db     $dd             ; 000286 DD 
    jp     nc,$f7c6        ; 000287 D2 C6 F7 
    or     $db             ; 00028A F6 DB 
    jp     po,$d800        ; 00028C E2 00 D8 
    rlc    b               ; 00028F CB 00 
    ret    m               ; 000291 F8 
    sbc    a,$c1           ; 000292 DE C1 
    call   po,$d700        ; 000294 E4 00 D7 
    ret                    ; 000297 C9 
    add    a,d             ; 000298 82 
    jp     po,$e3e1        ; 000299 E2 E1 E3 
    call   po,$e0df        ; 00029C E4 DF E0 
    rst    10h             ; 00029F D7 
    db     $dd             ; 0002A0 DD 
    exx                    ; 0002A1 D9 
    ret    c               ; 0002A2 D8 
    rst    30h             ; 0002A3 F7 
    push   af              ; 0002A4 F5 
    di                     ; 0002A5 F3 
    ret    m               ; 0002A6 F8 
    rst    30h             ; 0002A7 F7 
    ld     sp,hl           ; 0002A8 F9 
    sbc    a,l             ; 0002A9 9D 
    or     $f4             ; 0002AA F6 F4 
    sbc    a,$e5           ; 0002AC DE E5 
    jp     m,$8080         ; 0002AE FA 80 80 
    add    a,b             ; 0002B1 80 
    cp     b               ; 0002B2 B8 
    cp     b               ; 0002B3 B8 
    add    a,b             ; 0002B4 80 
    cp     b               ; 0002B5 B8 
    cp     b               ; 0002B6 B8 
    add    a,b             ; 0002B7 80 
    add    a,a             ; 0002B8 87 
    add    a,b             ; 0002B9 80 
    cp     a               ; 0002BA BF 
    cp     b               ; 0002BB B8 
    add    a,a             ; 0002BC 87 
    cp     b               ; 0002BD B8 
    cp     a               ; 0002BE BF 
    add    a,a             ; 0002BF 87 
    add    a,b             ; 0002C0 80 
    add    a,a             ; 0002C1 87 
    cp     b               ; 0002C2 B8 
    cp     a               ; 0002C3 BF 
    add    a,b             ; 0002C4 80 
    cp     a               ; 0002C5 BF 
    cp     b               ; 0002C6 B8 
    add    a,a             ; 0002C7 87 
    add    a,a             ; 0002C8 87 
    add    a,a             ; 0002C9 87 
    cp     a               ; 0002CA BF 
    cp     a               ; 0002CB BF 
    add    a,a             ; 0002CC 87 
    cp     a               ; 0002CD BF 
    cp     a               ; 0002CE BF 
    ld     (hl),d          ; 0002CF 72 
    ld     (bc),a          ; 0002D0 02 
    ld     c,a             ; 0002D1 4F 
    ld     (bc),a          ; 0002D2 02 
    ld     l,$02           ; 0002D3 2E 02 
    ld     c,$02           ; 0002D5 0E 02 
    pop    af              ; 0002D7 F1 
    ld     bc,$01d5        ; 0002D8 01 D5 01 
    or     a               ; 0002DB B7 
    ld     bc,$019e        ; 0002DC 01 9E 01 
    add    a,(hl)          ; 0002DF 86 
    ld     bc,$0170        ; 0002E0 01 70 01 
    ld     e,e             ; 0002E3 5B 
    ld     bc,$0148        ; 0002E4 01 48 01 
    dec    (hl)            ; 0002E7 35 
    ld     bc,$0123        ; 0002E8 01 23 01 
    inc    de              ; 0002EB 13 
    ld     bc,$0103        ; 0002EC 01 03 01 
    call   p,$e600         ; 0002EF F4 00 E6 
    nop                    ; 0002F2 00 
    exx                    ; 0002F3 D9 
    nop                    ; 0002F4 00 
    call   $c100           ; 0002F5 CD 00 C1 
    nop                    ; 0002F8 00 
    or     (hl)            ; 0002F9 B6 
    nop                    ; 0002FA 00 
    xor    e               ; 0002FB AB 
    nop                    ; 0002FC 00 
    and    c               ; 0002FD A1 
    nop                    ; 0002FE 00 
    sbc    a,b             ; 0002FF 98 
    nop                    ; 000300 00 
    adc    a,a             ; 000301 8F 
    nop                    ; 000302 00 
    add    a,a             ; 000303 87 
    nop                    ; 000304 00 
    ld     a,a             ; 000305 7F 
    nop                    ; 000306 00 
    ld     a,b             ; 000307 78 
    nop                    ; 000308 00 
    ld     (hl),b          ; 000309 70 
    nop                    ; 00030A 00 
    ld     l,d             ; 00030B 6A 
    nop                    ; 00030C 00 
    ld     b,a             ; 00030D 47 
    ld     a,($783c)       ; 00030E 3A 3C 78 
    ld     hl,($7820)      ; 000311 2A 20 78 
    ld     (hl),a          ; 000314 77 
    ld     a,b             ; 000315 78 
    ret                    ; 000316 C9 
    ld     bc,$0020        ; 000317 01 20 00 
    or     a               ; 00031A B7 
    sbc    hl,bc           ; 00031B ED 42 
    ld     ($7820),hl      ; 00031D 22 20 78 
    ret                    ; 000320 C9 
    ld     bc,$0302        ; 000321 01 02 03 
    inc    b               ; 000324 04 
    ld     b,$08           ; 000325 06 08 
    inc    c               ; 000327 0C 
    djnz   $0342           ; 000328 10 18 
    push   bc              ; 00032A C5 
    ld     c,a             ; 00032B 4F 
    call   $79c1           ; 00032C CD C1 79 
    ld     a,($789c)       ; 00032F 3A 9C 78 
    or     a               ; 000332 B7 
    ld     a,c             ; 000333 79 
    pop    bc              ; 000334 C1 
    jp     m,$3b54         ; 000335 FA 54 3B 
    jr     nz,$039c        ; 000338 20 62 
    push   de              ; 00033A D5 
    push   af              ; 00033B F5 
    push   bc              ; 00033C C5 
    push   hl              ; 00033D E5 
    call   $308b           ; 00033E CD 8B 30 
    pop    hl              ; 000341 E1 
    pop    bc              ; 000342 C1 
    nop                    ; 000343 00 
    nop                    ; 000344 00 
    pop    af              ; 000345 F1 
    pop    de              ; 000346 D1 
    ret                    ; 000347 C9 
    ld     a,($783d)       ; 000348 3A 3D 78 
    and    $08             ; 00034B E6 08 
    ld     a,($7820)       ; 00034D 3A 20 78 
    jr     z,$0355         ; 000350 28 03 
    rrca                   ; 000352 0F 
    and    $1f             ; 000353 E6 1F 
    and    $1f             ; 000355 E6 1F 
    ret                    ; 000357 C9 
    call   $79c4           ; 000358 CD C4 79 
    push   de              ; 00035B D5 
    call   $002b           ; 00035C CD 2B 00 
    pop    de              ; 00035F D1 
    ret                    ; 000360 C9 
    ld     a,(bc)          ; 000361 0A 
    dec    bc              ; 000362 0B 
    inc    c               ; 000363 0C 
    inc    c               ; 000364 0C 
    dec    c               ; 000365 0D 
    ld     c,$0f           ; 000366 0E 0F 
    rrca                   ; 000368 0F 
    djnz   $037c           ; 000369 10 11 
    ld     (de),a          ; 00036B 12 
    inc    de              ; 00036C 13 
    dec    d               ; 00036D 15 
    ld     d,$17           ; 00036E 16 17 
    add    hl,de           ; 000370 19 
    ld     a,(de)          ; 000371 1A 
    inc    e               ; 000372 1C 
    dec    e               ; 000373 1D 
    rra                    ; 000374 1F 
    ld     hl,$2523        ; 000375 21 23 25 
    daa                    ; 000378 27 
    add    hl,hl           ; 000379 29 
    inc    l               ; 00037A 2C 
    ld     l,$31           ; 00037B 2E 31 
    inc    (hl)            ; 00037D 34 
    dec    (hl)            ; 00037E 35 
    ld     a,($4b4f)       ; 00037F 3A 4F 4B 
    dec    c               ; 000382 0D 
    nop                    ; 000383 00 
    ld     b,l             ; 000384 45 
    ld     d,d             ; 000385 52 
    ld     d,d             ; 000386 52 
    ld     c,a             ; 000387 4F 
    ld     d,d             ; 000388 52 
    dec    c               ; 000389 0D 
    nop                    ; 00038A 00 
    xor    a               ; 00038B AF 
    ld     ($789c),a       ; 00038C 32 9C 78 
    ld     a,($789b)       ; 00038F 3A 9B 78 
    or     a               ; 000392 B7 
    ret    z               ; 000393 C8 
    ld     a,$0d           ; 000394 3E 0D 
    push   de              ; 000396 D5 
    call   $039c           ; 000397 CD 9C 03 
    pop    de              ; 00039A D1 
    ret                    ; 00039B C9 
    push   af              ; 00039C F5 
    push   de              ; 00039D D5 
    push   bc              ; 00039E C5 
    ld     c,a             ; 00039F 4F 
    ld     e,$00           ; 0003A0 1E 00 
    cp     $0c             ; 0003A2 FE 0C 
    jr     z,$03b6         ; 0003A4 28 10 
    cp     $0a             ; 0003A6 FE 0A 
    jr     nz,$03ad        ; 0003A8 20 03 
    ld     a,$0d           ; 0003AA 3E 0D 
    ld     c,a             ; 0003AC 4F 
    cp     $0d             ; 0003AD FE 0D 
    jr     z,$03b6         ; 0003AF 28 05 
    ld     a,($789b)       ; 0003B1 3A 9B 78 
    inc    a               ; 0003B4 3C 
    ld     e,a             ; 0003B5 5F 
    ld     a,e             ; 0003B6 7B 
    ld     ($789b),a       ; 0003B7 32 9B 78 
    ld     a,c             ; 0003BA 79 
    call   $003b           ; 0003BB CD 3B 00 
    pop    bc              ; 0003BE C1 
    pop    de              ; 0003BF D1 
    pop    af              ; 0003C0 F1 
    ret                    ; 0003C1 C9 
    push   hl              ; 0003C2 E5 
    push   ix              ; 0003C3 DD E5 
    push   de              ; 0003C5 D5 
    pop    ix              ; 0003C6 DD E1 
    push   de              ; 0003C8 D5 
    ld     hl,$03dd        ; 0003C9 21 DD 03 
    push   hl              ; 0003CC E5 
    ld     c,a             ; 0003CD 4F 
    ld     a,(de)          ; 0003CE 1A 
    and    b               ; 0003CF A0 
    cp     b               ; 0003D0 B8 
    jp     nz,$7833        ; 0003D1 C2 33 78 
    cp     $02             ; 0003D4 FE 02 
    ld     l,(ix+$01)      ; 0003D6 DD 6E 01 
    ld     h,(ix+$02)      ; 0003D9 DD 66 02 
    jp     (hl)            ; 0003DC E9 
    pop    de              ; 0003DD D1 
    pop    ix              ; 0003DE DD E1 
    pop    hl              ; 0003E0 E1 
    pop    bc              ; 0003E1 C1 
    ret                    ; 0003E2 C9 
    ld     hl,$7839        ; 0003E3 21 39 78 
    set    5,(hl)          ; 0003E6 CB EE 
    ld     hl,($7820)      ; 0003E8 2A 20 78 
    call   $0053           ; 0003EB CD 53 00 
    ld     a,h             ; 0003EE 7C 
    cp     $71             ; 0003EF FE 71 
    jr     nz,$0403        ; 0003F1 20 10 
    ld     a,l             ; 0003F3 7D 
    cp     $e0             ; 0003F4 FE E0 
    jr     nz,$0403        ; 0003F6 20 0B 
    ld     a,($7ad7)       ; 0003F8 3A D7 7A 
    or     a               ; 0003FB B7 
    jr     nz,$0403        ; 0003FC 20 05 
    ld     a,$0d           ; 0003FE 3E 0D 
    call   $308b           ; 000400 CD 8B 30 
    ld     b,c             ; 000403 41 
    push   bc              ; 000404 C5 
    ld     hl,$7839        ; 000405 21 39 78 
    res    0,(hl)          ; 000408 CB 86 
    res    2,(hl)          ; 00040A CB 96 
    bit    0,(hl)          ; 00040C CB 46 
    jr     z,$040c         ; 00040E 28 FC 
    ld     a,($78a6)       ; 000410 3A A6 78 
    ld     c,a             ; 000413 4F 
    xor    a               ; 000414 AF 
    ld     ($78a6),a       ; 000415 32 A6 78 
    ld     b,a             ; 000418 47 
    ld     hl,($7820)      ; 000419 2A 20 78 
    sbc    hl,bc           ; 00041C ED 42 
    ld     ($7820),hl      ; 00041E 22 20 78 
    ld     de,$79e8        ; 000421 11 E8 79 
    pop    bc              ; 000424 C1 
    ld     hl,$7839        ; 000425 21 39 78 
    bit    4,(hl)          ; 000428 CB 66 
    ld     hl,($7820)      ; 00042A 2A 20 78 
    jr     z,$0471         ; 00042D 28 42 
    push   bc              ; 00042F C5 
    push   hl              ; 000430 E5 
    call   $33a8           ; 000431 CD A8 33 
    pop    hl              ; 000434 E1 
    pop    bc              ; 000435 C1 
    or     a               ; 000436 B7 
    jr     nz,$0441        ; 000437 20 08 
    ld     a,l             ; 000439 7D 
    sub    $20             ; 00043A D6 20 
    ld     l,a             ; 00043C 6F 
    ld     a,h             ; 00043D 7C 
    sbc    a,$00           ; 00043E DE 00 
    ld     h,a             ; 000440 67 
    ld     c,b             ; 000441 48 
    ld     a,(de)          ; 000442 1A 
    cp     (hl)            ; 000443 BE 
    jr     nz,$044d        ; 000444 20 07 
    inc    hl              ; 000446 23 
    inc    de              ; 000447 13 
    djnz   $0442           ; 000448 10 F8 
    push   bc              ; 00044A C5 
    jr     $0451           ; 00044B 18 04 
    ld     bc,$0000        ; 00044D 01 00 00 
    push   bc              ; 000450 C5 
    push   hl              ; 000451 E5 
    call   $33a8           ; 000452 CD A8 33 
    pop    hl              ; 000455 E1 
    pop    bc              ; 000456 C1 
    push   bc              ; 000457 C5 
    cp     $80             ; 000458 FE 80 
    jr     z,$0466         ; 00045A 28 0A 
    ld     a,$40           ; 00045C 3E 40 
    sub    c               ; 00045E 91 
    ld     b,a             ; 00045F 47 
    pop    de              ; 000460 D1 
    ld     e,$00           ; 000461 1E 00 
    push   de              ; 000463 D5 
    jr     $046b           ; 000464 18 05 
    ld     b,$20           ; 000466 06 20 
    ld     hl,($7820)      ; 000468 2A 20 78 
    ld     de,$79e8        ; 00046B 11 E8 79 
    jp     $3ea8           ; 00046E C3 A8 3E 
    ld     bc,$0000        ; 000471 01 00 00 
    push   bc              ; 000474 C5 
    push   hl              ; 000475 E5 
    call   $33a8           ; 000476 CD A8 33 
    pop    hl              ; 000479 E1 
    cp     $80             ; 00047A FE 80 
    jr     z,$048c         ; 00047C 28 0E 
    cp     $81             ; 00047E FE 81 
    jr     z,$0488         ; 000480 28 06 
    ld     bc,$0020        ; 000482 01 20 00 
    or     a               ; 000485 B7 
    sbc    hl,bc           ; 000486 ED 42 
    ld     b,$40           ; 000488 06 40 
    jr     $048e           ; 00048A 18 02 
    ld     b,$20           ; 00048C 06 20 
    ld     a,($7818)       ; 00048E 3A 18 78 
    or     a               ; 000491 B7 
    jp     z,$3e40         ; 000492 CA 40 3E 
    ld     a,(hl)          ; 000495 7E 
    cp     $40             ; 000496 FE 40 
    jp     c,$04ae         ; 000498 DA AE 04 
    pop    bc              ; 00049B C1 
    ld     de,$04a4        ; 00049C 11 A4 04 
    push   de              ; 00049F D5 
    push   bc              ; 0004A0 C5 
    jp     $0502           ; 0004A1 C3 02 05 
    ret    c               ; 0004A4 D8 
    ld     hl,$3e1a        ; 0004A5 21 1A 3E 
    call   $28a7           ; 0004A8 CD A7 28 
    jp     $03e3           ; 0004AB C3 E3 03 
    cp     $22             ; 0004AE FE 22 
    jr     nz,$04e3        ; 0004B0 20 31 
    ld     (de),a          ; 0004B2 12 
    inc    hl              ; 0004B3 23 
    inc    de              ; 0004B4 13 
    dec    b               ; 0004B5 05 
    jr     z,$04ee         ; 0004B6 28 36 
    ld     a,(hl)          ; 0004B8 7E 
    cp     $40             ; 0004B9 FE 40 
    jp     c,$04c9         ; 0004BB DA C9 04 
    cp     $80             ; 0004BE FE 80 
    jp     c,$04c5         ; 0004C0 DA C5 04 
    and    $8f             ; 0004C3 E6 8F 
    or     $80             ; 0004C5 F6 80 
    jr     $04dc           ; 0004C7 18 13 
    cp     $22             ; 0004C9 FE 22 
    jr     nz,$04d6        ; 0004CB 20 09 
    push   hl              ; 0004CD E5 
    ld     hl,$7839        ; 0004CE 21 39 78 
    bit    4,(hl)          ; 0004D1 CB 66 
    pop    hl              ; 0004D3 E1 
    jr     z,$04e3         ; 0004D4 28 0D 
    bit    5,a             ; 0004D6 CB 6F 
    jr     nz,$04dc        ; 0004D8 20 02 
    or     $40             ; 0004DA F6 40 
    ld     (de),a          ; 0004DC 12 
    inc    hl              ; 0004DD 23 
    inc    de              ; 0004DE 13 
    djnz   $04b8           ; 0004DF 10 D7 
    jr     $04ee           ; 0004E1 18 0B 
    bit    5,a             ; 0004E3 CB 6F 
    jr     nz,$04e9        ; 0004E5 20 02 
    or     $40             ; 0004E7 F6 40 
    ld     (de),a          ; 0004E9 12 
    inc    hl              ; 0004EA 23 
    inc    de              ; 0004EB 13 
    djnz   $0495           ; 0004EC 10 A7 
    dec    de              ; 0004EE 1B 
    ld     a,d             ; 0004EF 7A 
    cp     $79             ; 0004F0 FE 79 
    jr     nz,$04fa        ; 0004F2 20 06 
    ld     a,e             ; 0004F4 7B 
    cp     $e8             ; 0004F5 FE E8 
    jp     c,$04ff         ; 0004F7 DA FF 04 
    ld     a,(de)          ; 0004FA 1A 
    cp     $20             ; 0004FB FE 20 
    jr     z,$04ee         ; 0004FD 28 EF 
    inc    de              ; 0004FF 13 
    xor    a               ; 000500 AF 
    ld     (de),a          ; 000501 12 
    call   $33a8           ; 000502 CD A8 33 
    ld     hl,($7820)      ; 000505 2A 20 78 
    cp     $81             ; 000508 FE 81 
    call   $0053           ; 00050A CD 53 00 
    jr     nz,$0513        ; 00050D 20 04 
    xor    a               ; 00050F AF 
    call   $308b           ; 000510 CD 8B 30 
    xor    a               ; 000513 AF 
    call   $308b           ; 000514 CD 8B 30 
    ld     a,($7838)       ; 000517 3A 38 78 
    and    $fd             ; 00051A E6 FD 
    ld     ($7838),a       ; 00051C 32 38 78 
    ld     hl,$7839        ; 00051F 21 39 78 
    bit    2,(hl)          ; 000522 CB 56 
    jr     z,$052b         ; 000524 28 05 
    ld     a,$01           ; 000526 3E 01 
    scf                    ; 000528 37 
    jr     $052c           ; 000529 18 01 
    xor    a               ; 00052B AF 
    ld     hl,$7839        ; 00052C 21 39 78 
    res    4,(hl)          ; 00052F CB A6 
    ld     hl,$79e8        ; 000531 21 E8 79 
    pop    bc              ; 000534 C1 
    push   af              ; 000535 F5 
    add    hl,bc           ; 000536 09 
    jp     $3e29           ; 000537 C3 29 3E 
    ld     a,($7aaf)       ; 00053A 3A AF 7A 
    or     a               ; 00053D B7 
    jr     nz,$053a        ; 00053E 20 FA 
    ld     b,$40           ; 000540 06 40 
    ld     hl,$79e8        ; 000542 21 E8 79 
    ld     a,$20           ; 000545 3E 20 
    ld     (hl),a          ; 000547 77 
    inc    hl              ; 000548 23 
    djnz   $0547           ; 000549 10 FC 
    xor    a               ; 00054B AF 
    ld     (hl),a          ; 00054C 77 
    call   $33a8           ; 00054D CD A8 33 
    or     a               ; 000550 B7 
    ld     a,($78a6)       ; 000551 3A A6 78 
    jr     nz,$0558        ; 000554 20 02 
    add    a,$20           ; 000556 C6 20 
    ld     c,a             ; 000558 4F 
    xor    a               ; 000559 AF 
    ld     b,a             ; 00055A 47 
    ld     hl,($7820)      ; 00055B 2A 20 78 
    sbc    hl,bc           ; 00055E ED 42 
    ld     de,$79e8        ; 000560 11 E8 79 
    push   bc              ; 000563 C5 
    ldir                   ; 000564 ED B0 
    pop    bc              ; 000566 C1 
    ld     hl,$7839        ; 000567 21 39 78 
    set    4,(hl)          ; 00056A CB E6 
    call   $03e3           ; 00056C CD E3 03 
    ret                    ; 00056F C9 
    ld     d,d             ; 000570 52 
    ld     d,l             ; 000571 55 
    ld     c,(hl)          ; 000572 4E 
    nop                    ; 000573 00 
    call   nz,$3233        ; 000574 C4 33 32 
    call   $1aa3           ; 000577 CD A3 1A 
    call   $17d8           ; 00057A CD D8 17 
    call   $190d           ; 00057D CD 0D 19 
    jp     z,$125a         ; 000580 CA 5A 12 
    call   $1f49           ; 000583 CD 49 1F 
    jr     c,$05a0         ; 000586 38 18 
    rst    28h             ; 000588 EF 
    ld     a,($0438)       ; 000589 3A 38 04 
    db     $dd             ; 00058C DD 
    ld     a,c             ; 00058D 79 
    or     a               ; 00058E B7 
    jr     z,$05c4         ; 00058F 28 33 
    cp     $0b             ; 000591 FE 0B 
    jr     z,$059f         ; 000593 28 0A 
    cp     $0c             ; 000595 FE 0C 
    jr     nz,$05ad        ; 000597 20 14 
    xor    a               ; 000599 AF 
    or     (ix+$03)        ; 00059A DD B6 03 
    jr     z,$05ad         ; 00059D 28 0E 
    ld     a,(ix+$03)      ; 00059F DD 7E 03 
    sub    (ix+$04)        ; 0005A2 DD 96 04 
    ld     b,a             ; 0005A5 47 
    call   $3ae2           ; 0005A6 CD E2 3A 
    djnz   $05a6           ; 0005A9 10 FB 
    jr     $05bf           ; 0005AB 18 12 
    call   $3ab6           ; 0005AD CD B6 3A 
    ld     a,c             ; 0005B0 79 
    cp     $0d             ; 0005B1 FE 0D 
    ret    nz              ; 0005B3 C0 
    inc    (ix+$04)        ; 0005B4 DD 34 04 
    ld     a,(ix+$04)      ; 0005B7 DD 7E 04 
    cp     (ix+$03)        ; 0005BA DD BE 03 
    ld     a,c             ; 0005BD 79 
    ret    nz              ; 0005BE C0 
    ld     (ix+$04),$00    ; 0005BF DD 36 04 00 
    ret                    ; 0005C3 C9 
    in     a,($00)         ; 0005C4 DB 00 
    and    $01             ; 0005C6 E6 01 
    ret                    ; 0005C8 C9 
    push   bc              ; 0005C9 C5 
    push   hl              ; 0005CA E5 
    ld     b,$04           ; 0005CB 06 04 
    ld     hl,$7ad2        ; 0005CD 21 D2 7A 
    ld     (hl),a          ; 0005D0 77 
    inc    hl              ; 0005D1 23 
    djnz   $05d0           ; 0005D2 10 FC 
    pop    hl              ; 0005D4 E1 
    pop    bc              ; 0005D5 C1 
    ret                    ; 0005D6 C9 
    ld     hl,$7838        ; 0005D7 21 38 78 
    bit    2,(hl)          ; 0005DA CB 56 
    jr     z,$05f3         ; 0005DC 28 15 
    ld     d,a             ; 0005DE 57 
    ld     a,($783a)       ; 0005DF 3A 3A 78 
    or     a               ; 0005E2 B7 
    jr     z,$05f4         ; 0005E3 28 0F 
    inc    a               ; 0005E5 3C 
    ld     ($783a),a       ; 0005E6 32 3A 78 
    cp     $2a             ; 0005E9 FE 2A 
    jr     z,$05ef         ; 0005EB 28 02 
    xor    a               ; 0005ED AF 
    ret                    ; 0005EE C9 
    res    2,(hl)          ; 0005EF CB 96 
    xor    a               ; 0005F1 AF 
    ret                    ; 0005F2 C9 
    ld     d,a             ; 0005F3 57 
    ld     hl,$7838        ; 0005F4 21 38 78 
    ld     a,(hl)          ; 0005F7 7E 
    and    $18             ; 0005F8 E6 18 
    jr     nz,$0607        ; 0005FA 20 0B 
    set    3,(hl)          ; 0005FC CB DE 
    xor    a               ; 0005FE AF 
    ld     ($7837),a       ; 0005FF 32 37 78 
    ld     a,d             ; 000602 7A 
    ld     ($7836),a       ; 000603 32 36 78 
    ret                    ; 000606 C9 
    bit    4,(hl)          ; 000607 CB 66 
    jr     nz,$0635        ; 000609 20 2A 
    ld     a,($7836)       ; 00060B 3A 36 78 
    cp     d               ; 00060E BA 
    jr     nz,$0632        ; 00060F 20 21 
    ld     bc,($7842)      ; 000611 ED 4B 42 78 
    ld     hl,($7844)      ; 000615 2A 44 78 
    ld     a,e             ; 000618 7B 
    call   $2f35           ; 000619 CD 35 2F 
    cp     d               ; 00061C BA 
    jp     z,$2fd7         ; 00061D CA D7 2F 
    cp     $00             ; 000620 FE 00 
    jp     z,$2fd7         ; 000622 CA D7 2F 
    ld     hl,$7838        ; 000625 21 38 78 
    set    3,(hl)          ; 000628 CB DE 
    set    4,(hl)          ; 00062A CB E6 
    res    2,(hl)          ; 00062C CB 96 
    ld     ($7837),a       ; 00062E 32 37 78 
    ret                    ; 000631 C9 
    ld     a,d             ; 000632 7A 
    jr     $0625           ; 000633 18 F0 
    ld     a,($7836)       ; 000635 3A 36 78 
    cp     d               ; 000638 BA 
    jr     z,$0643         ; 000639 28 08 
    ld     a,($7837)       ; 00063B 3A 37 78 
    cp     d               ; 00063E BA 
    jr     z,$0643         ; 00063F 28 02 
    xor    a               ; 000641 AF 
    ret                    ; 000642 C9 
    ld     bc,($7842)      ; 000643 ED 4B 42 78 
    ld     hl,($7844)      ; 000647 2A 44 78 
    ld     a,e             ; 00064A 7B 
    call   $2f35           ; 00064B CD 35 2F 
    cp     d               ; 00064E BA 
    jr     z,$0656         ; 00064F 28 05 
    cp     $00             ; 000651 FE 00 
    jp     nz,$2fd7        ; 000653 C2 D7 2F 
    ld     hl,$7838        ; 000656 21 38 78 
    set    3,(hl)          ; 000659 CB DE 
    res    4,(hl)          ; 00065B CB A6 
    ld     a,($7836)       ; 00065D 3A 36 78 
    cp     d               ; 000660 BA 
    jr     nz,$0668        ; 000661 20 05 
    xor    a               ; 000663 AF 
    ld     ($7837),a       ; 000664 32 37 78 
    ret                    ; 000667 C9 
    ld     a,($7837)       ; 000668 3A 37 78 
    ld     ($7836),a       ; 00066B 32 36 78 
    jr     $0663           ; 00066E 18 F3 
    set    2,(ix+$09)      ; 000670 DD CB 09 D6 
    nop                    ; 000674 00 
    nop                    ; 000675 00 
    ld     hl,$06d2        ; 000676 21 D2 06 
    ld     de,$7800        ; 000679 11 00 78 
    ld     bc,$0036        ; 00067C 01 36 00 
    ldir                   ; 00067F ED B0 
    dec    a               ; 000681 3D 
    dec    a               ; 000682 3D 
    jr     nz,$0676        ; 000683 20 F1 
    ld     b,$27           ; 000685 06 27 
    ld     (de),a          ; 000687 12 
    inc    de              ; 000688 13 
    djnz   $0687           ; 000689 10 FC 
    jp     $0075           ; 00068B C3 75 00 
    ld     hl,$4000        ; 00068E 21 00 40 
    call   $06a4           ; 000691 CD A4 06 
    ld     hl,$6000        ; 000694 21 00 60 
    call   $06a4           ; 000697 CD A4 06 
    ld     hl,$8000        ; 00069A 21 00 80 
    call   $06a4           ; 00069D CD A4 06 
    ei                     ; 0006A0 FB 
    jp     $1a19           ; 0006A1 C3 19 1A 
    ld     a,$aa           ; 0006A4 3E AA 
    cp     (hl)            ; 0006A6 BE 
    inc    hl              ; 0006A7 23 
    ret    nz              ; 0006A8 C0 
    cpl                    ; 0006A9 2F 
    cp     (hl)            ; 0006AA BE 
    inc    hl              ; 0006AB 23 
    ret    nz              ; 0006AC C0 
    ld     a,$e7           ; 0006AD 3E E7 
    cp     (hl)            ; 0006AF BE 
    inc    hl              ; 0006B0 23 
    ret    nz              ; 0006B1 C0 
    cpl                    ; 0006B2 2F 
    cp     (hl)            ; 0006B3 BE 
    inc    hl              ; 0006B4 23 
    ret    nz              ; 0006B5 C0 
    ei                     ; 0006B6 FB 
    jp     (hl)            ; 0006B7 E9 
    ld     c,$02           ; 0006B8 0E 02 
    call   $1a59           ; 0006BA CD 59 1A 
    call   $34b8           ; 0006BD CD B8 34 
    call   $18e3           ; 0006C0 CD E3 18 
    jr     z,$0685         ; 0006C3 28 C0 
    rst    28h             ; 0006C5 EF 
    inc    l               ; 0006C6 2C 
    jr     z,$06dd         ; 0006C7 28 14 
    call   $34f1           ; 0006C9 CD F1 34 
    ld     bc,$1a18        ; 0006CC 01 18 1A 
    jp     $19ae           ; 0006CF C3 AE 19 
    jp     $1c96           ; 0006D2 C3 96 1C 
    jp     $1d78           ; 0006D5 C3 78 1D 
    jp     $1c90           ; 0006D8 C3 90 1C 
    jp     $25d9           ; 0006DB C3 D9 25 
    ret                    ; 0006DE C9 
    nop                    ; 0006DF 00 
    nop                    ; 0006E0 00 
    ret                    ; 0006E1 C9 
    nop                    ; 0006E2 00 
    nop                    ; 0006E3 00 
    ei                     ; 0006E4 FB 
    ret                    ; 0006E5 C9 
    nop                    ; 0006E6 00 
    ld     bc,$2ef4        ; 0006E7 01 F4 2E 
    nop                    ; 0006EA 00 
    nop                    ; 0006EB 00 
    nop                    ; 0006EC 00 
    ld     c,e             ; 0006ED 4B 
    ld     c,c             ; 0006EE 49 
    nop                    ; 0006EF 00 
    nop                    ; 0006F0 00 
    nop                    ; 0006F1 00 
    nop                    ; 0006F2 00 
    ld     (hl),b          ; 0006F3 70 
    nop                    ; 0006F4 00 
    nop                    ; 0006F5 00 
    nop                    ; 0006F6 00 
    ld     b,$8d           ; 0006F7 06 8D 
    dec    b               ; 0006F9 05 
    ld     b,e             ; 0006FA 43 
    nop                    ; 0006FB 00 
    nop                    ; 0006FC 00 
    ld     d,b             ; 0006FD 50 
    ld     d,d             ; 0006FE 52 
    jp     $5000           ; 0006FF C3 00 50 
    rst    00h             ; 000702 C7 
    nop                    ; 000703 00 
    nop                    ; 000704 00 
    ld     a,$00           ; 000705 3E 00 
    ret                    ; 000707 C9 
    ld     hl,$1380        ; 000708 21 80 13 
    call   $09c2           ; 00070B CD C2 09 
    jr     $0716           ; 00070E 18 06 
    call   $09c2           ; 000710 CD C2 09 
    call   $0982           ; 000713 CD 82 09 
    ld     a,b             ; 000716 78 
    or     a               ; 000717 B7 
    ret    z               ; 000718 C8 
    ld     a,($7924)       ; 000719 3A 24 79 
    or     a               ; 00071C B7 
    jp     z,$09b4         ; 00071D CA B4 09 
    sub    b               ; 000720 90 
    jr     nc,$072f        ; 000721 30 0C 
    cpl                    ; 000723 2F 
    inc    a               ; 000724 3C 
    ex     de,hl           ; 000725 EB 
    call   $09a4           ; 000726 CD A4 09 
    ex     de,hl           ; 000729 EB 
    call   $09b4           ; 00072A CD B4 09 
    pop    bc              ; 00072D C1 
    pop    de              ; 00072E D1 
    cp     $19             ; 00072F FE 19 
    ret    nc              ; 000731 D0 
    push   af              ; 000732 F5 
    call   $09df           ; 000733 CD DF 09 
    ld     h,a             ; 000736 67 
    pop    af              ; 000737 F1 
    call   $07d7           ; 000738 CD D7 07 
    or     h               ; 00073B B4 
    ld     hl,$7921        ; 00073C 21 21 79 
    jp     p,$0754         ; 00073F F2 54 07 
    call   $07b7           ; 000742 CD B7 07 
    jp     nc,$0796        ; 000745 D2 96 07 
    inc    hl              ; 000748 23 
    inc    (hl)            ; 000749 34 
    jp     z,$07b2         ; 00074A CA B2 07 
    ld     l,$01           ; 00074D 2E 01 
    call   $07eb           ; 00074F CD EB 07 
    jr     $0796           ; 000752 18 42 
    xor    a               ; 000754 AF 
    sub    b               ; 000755 90 
    ld     b,a             ; 000756 47 
    ld     a,(hl)          ; 000757 7E 
    sbc    a,e             ; 000758 9B 
    ld     e,a             ; 000759 5F 
    inc    hl              ; 00075A 23 
    ld     a,(hl)          ; 00075B 7E 
    sbc    a,d             ; 00075C 9A 
    ld     d,a             ; 00075D 57 
    inc    hl              ; 00075E 23 
    ld     a,(hl)          ; 00075F 7E 
    sbc    a,c             ; 000760 99 
    ld     c,a             ; 000761 4F 
    call   c,$07c3         ; 000762 DC C3 07 
    ld     l,b             ; 000765 68 
    ld     h,e             ; 000766 63 
    xor    a               ; 000767 AF 
    ld     b,a             ; 000768 47 
    ld     a,c             ; 000769 79 
    or     a               ; 00076A B7 
    jr     nz,$0785        ; 00076B 20 18 
    ld     c,d             ; 00076D 4A 
    ld     d,h             ; 00076E 54 
    ld     h,l             ; 00076F 65 
    ld     l,a             ; 000770 6F 
    ld     a,b             ; 000771 78 
    sub    $08             ; 000772 D6 08 
    cp     $e0             ; 000774 FE E0 
    jr     nz,$0768        ; 000776 20 F0 
    xor    a               ; 000778 AF 
    ld     ($7924),a       ; 000779 32 24 79 
    ret                    ; 00077C C9 
    dec    b               ; 00077D 05 
    add    hl,hl           ; 00077E 29 
    ld     a,d             ; 00077F 7A 
    rla                    ; 000780 17 
    ld     d,a             ; 000781 57 
    ld     a,c             ; 000782 79 
    adc    a,a             ; 000783 8F 
    ld     c,a             ; 000784 4F 
    jp     p,$077d         ; 000785 F2 7D 07 
    ld     a,b             ; 000788 78 
    ld     e,h             ; 000789 5C 
    ld     b,l             ; 00078A 45 
    or     a               ; 00078B B7 
    jr     z,$0796         ; 00078C 28 08 
    ld     hl,$7924        ; 00078E 21 24 79 
    add    a,(hl)          ; 000791 86 
    ld     (hl),a          ; 000792 77 
    jr     nc,$0778        ; 000793 30 E3 
    ret    z               ; 000795 C8 
    ld     a,b             ; 000796 78 
    ld     hl,$7924        ; 000797 21 24 79 
    or     a               ; 00079A B7 
    call   m,$07a8         ; 00079B FC A8 07 
    ld     b,(hl)          ; 00079E 46 
    inc    hl              ; 00079F 23 
    ld     a,(hl)          ; 0007A0 7E 
    and    $80             ; 0007A1 E6 80 
    xor    c               ; 0007A3 A9 
    ld     c,a             ; 0007A4 4F 
    jp     $09b4           ; 0007A5 C3 B4 09 
    inc    e               ; 0007A8 1C 
    ret    nz              ; 0007A9 C0 
    inc    d               ; 0007AA 14 
    ret    nz              ; 0007AB C0 
    inc    c               ; 0007AC 0C 
    ret    nz              ; 0007AD C0 
    ld     c,$80           ; 0007AE 0E 80 
    inc    (hl)            ; 0007B0 34 
    ret    nz              ; 0007B1 C0 
    ld     e,$0a           ; 0007B2 1E 0A 
    jp     $19a2           ; 0007B4 C3 A2 19 
    ld     a,(hl)          ; 0007B7 7E 
    add    a,e             ; 0007B8 83 
    ld     e,a             ; 0007B9 5F 
    inc    hl              ; 0007BA 23 
    ld     a,(hl)          ; 0007BB 7E 
    adc    a,d             ; 0007BC 8A 
    ld     d,a             ; 0007BD 57 
    inc    hl              ; 0007BE 23 
    ld     a,(hl)          ; 0007BF 7E 
    adc    a,c             ; 0007C0 89 
    ld     c,a             ; 0007C1 4F 
    ret                    ; 0007C2 C9 
    ld     hl,$7925        ; 0007C3 21 25 79 
    ld     a,(hl)          ; 0007C6 7E 
    cpl                    ; 0007C7 2F 
    ld     (hl),a          ; 0007C8 77 
    xor    a               ; 0007C9 AF 
    ld     l,a             ; 0007CA 6F 
    sub    b               ; 0007CB 90 
    ld     b,a             ; 0007CC 47 
    ld     a,l             ; 0007CD 7D 
    sbc    a,e             ; 0007CE 9B 
    ld     e,a             ; 0007CF 5F 
    ld     a,l             ; 0007D0 7D 
    sbc    a,d             ; 0007D1 9A 
    ld     d,a             ; 0007D2 57 
    ld     a,l             ; 0007D3 7D 
    sbc    a,c             ; 0007D4 99 
    ld     c,a             ; 0007D5 4F 
    ret                    ; 0007D6 C9 
    ld     b,$00           ; 0007D7 06 00 
    sub    $08             ; 0007D9 D6 08 
    jr     c,$07e4         ; 0007DB 38 07 
    ld     b,e             ; 0007DD 43 
    ld     e,d             ; 0007DE 5A 
    ld     d,c             ; 0007DF 51 
    ld     c,$00           ; 0007E0 0E 00 
    jr     $07d9           ; 0007E2 18 F5 
    add    a,$09           ; 0007E4 C6 09 
    ld     l,a             ; 0007E6 6F 
    xor    a               ; 0007E7 AF 
    dec    l               ; 0007E8 2D 
    ret    z               ; 0007E9 C8 
    ld     a,c             ; 0007EA 79 
    rra                    ; 0007EB 1F 
    ld     c,a             ; 0007EC 4F 
    ld     a,d             ; 0007ED 7A 
    rra                    ; 0007EE 1F 
    ld     d,a             ; 0007EF 57 
    ld     a,e             ; 0007F0 7B 
    rra                    ; 0007F1 1F 
    ld     e,a             ; 0007F2 5F 
    ld     a,b             ; 0007F3 78 
    rra                    ; 0007F4 1F 
    ld     b,a             ; 0007F5 47 
    jr     $07e7           ; 0007F6 18 EF 
    nop                    ; 0007F8 00 
    nop                    ; 0007F9 00 
    nop                    ; 0007FA 00 
    add    a,c             ; 0007FB 81 
    inc    bc              ; 0007FC 03 
    xor    d               ; 0007FD AA 
    ld     d,(hl)          ; 0007FE 56 
    add    hl,de           ; 0007FF 19 
    add    a,b             ; 000800 80 
    pop    af              ; 000801 F1 
    ld     ($8076),hl      ; 000802 22 76 80 
    ld     b,l             ; 000805 45 
    xor    d               ; 000806 AA 
    jr     c,$078b         ; 000807 38 82 
    call   $0955           ; 000809 CD 55 09 
    or     a               ; 00080C B7 
    jp     pe,$1e4a        ; 00080D EA 4A 1E 
    ld     hl,$7924        ; 000810 21 24 79 
    ld     a,(hl)          ; 000813 7E 
    ld     bc,$8035        ; 000814 01 35 80 
    ld     de,$04f3        ; 000817 11 F3 04 
    sub    b               ; 00081A 90 
    push   af              ; 00081B F5 
    ld     (hl),b          ; 00081C 70 
    push   de              ; 00081D D5 
    push   bc              ; 00081E C5 
    call   $0716           ; 00081F CD 16 07 
    pop    bc              ; 000822 C1 
    pop    de              ; 000823 D1 
    inc    b               ; 000824 04 
    call   $08a2           ; 000825 CD A2 08 
    ld     hl,$07f8        ; 000828 21 F8 07 
    call   $0710           ; 00082B CD 10 07 
    ld     hl,$07fc        ; 00082E 21 FC 07 
    call   $149a           ; 000831 CD 9A 14 
    ld     bc,$8080        ; 000834 01 80 80 
    ld     de,$0000        ; 000837 11 00 00 
    call   $0716           ; 00083A CD 16 07 
    pop    af              ; 00083D F1 
    call   $0f89           ; 00083E CD 89 0F 
    ld     bc,$8031        ; 000841 01 31 80 
    ld     de,$7218        ; 000844 11 18 72 
    call   $0955           ; 000847 CD 55 09 
    ret    z               ; 00084A C8 
    ld     l,$00           ; 00084B 2E 00 
    call   $0914           ; 00084D CD 14 09 
    ld     a,c             ; 000850 79 
    ld     ($794f),a       ; 000851 32 4F 79 
    ex     de,hl           ; 000854 EB 
    ld     ($7950),hl      ; 000855 22 50 79 
    ld     bc,$0000        ; 000858 01 00 00 
    ld     d,b             ; 00085B 50 
    ld     e,b             ; 00085C 58 
    ld     hl,$0765        ; 00085D 21 65 07 
    push   hl              ; 000860 E5 
    ld     hl,$0869        ; 000861 21 69 08 
    push   hl              ; 000864 E5 
    push   hl              ; 000865 E5 
    ld     hl,$7921        ; 000866 21 21 79 
    ld     a,(hl)          ; 000869 7E 
    inc    hl              ; 00086A 23 
    or     a               ; 00086B B7 
    jr     z,$0892         ; 00086C 28 24 
    push   hl              ; 00086E E5 
    ld     l,$08           ; 00086F 2E 08 
    rra                    ; 000871 1F 
    ld     h,a             ; 000872 67 
    ld     a,c             ; 000873 79 
    jr     nc,$0881        ; 000874 30 0B 
    push   hl              ; 000876 E5 
    ld     hl,($7950)      ; 000877 2A 50 79 
    add    hl,de           ; 00087A 19 
    ex     de,hl           ; 00087B EB 
    pop    hl              ; 00087C E1 
    ld     a,($794f)       ; 00087D 3A 4F 79 
    adc    a,c             ; 000880 89 
    rra                    ; 000881 1F 
    ld     c,a             ; 000882 4F 
    ld     a,d             ; 000883 7A 
    rra                    ; 000884 1F 
    ld     d,a             ; 000885 57 
    ld     a,e             ; 000886 7B 
    rra                    ; 000887 1F 
    ld     e,a             ; 000888 5F 
    ld     a,b             ; 000889 78 
    rra                    ; 00088A 1F 
    ld     b,a             ; 00088B 47 
    dec    l               ; 00088C 2D 
    ld     a,h             ; 00088D 7C 
    jr     nz,$0871        ; 00088E 20 E1 
    pop    hl              ; 000890 E1 
    ret                    ; 000891 C9 
    ld     b,e             ; 000892 43 
    ld     e,d             ; 000893 5A 
    ld     d,c             ; 000894 51 
    ld     c,a             ; 000895 4F 
    ret                    ; 000896 C9 
    call   $09a4           ; 000897 CD A4 09 
    ld     hl,$0dd8        ; 00089A 21 D8 0D 
    call   $09b1           ; 00089D CD B1 09 
    pop    bc              ; 0008A0 C1 
    pop    de              ; 0008A1 D1 
    call   $0955           ; 0008A2 CD 55 09 
    jp     z,$199a         ; 0008A5 CA 9A 19 
    ld     l,$ff           ; 0008A8 2E FF 
    call   $0914           ; 0008AA CD 14 09 
    inc    (hl)            ; 0008AD 34 
    inc    (hl)            ; 0008AE 34 
    dec    hl              ; 0008AF 2B 
    ld     a,(hl)          ; 0008B0 7E 
    ld     ($7889),a       ; 0008B1 32 89 78 
    dec    hl              ; 0008B4 2B 
    ld     a,(hl)          ; 0008B5 7E 
    ld     ($7885),a       ; 0008B6 32 85 78 
    dec    hl              ; 0008B9 2B 
    ld     a,(hl)          ; 0008BA 7E 
    ld     ($7881),a       ; 0008BB 32 81 78 
    ld     b,c             ; 0008BE 41 
    ex     de,hl           ; 0008BF EB 
    xor    a               ; 0008C0 AF 
    ld     c,a             ; 0008C1 4F 
    ld     d,a             ; 0008C2 57 
    ld     e,a             ; 0008C3 5F 
    ld     ($788c),a       ; 0008C4 32 8C 78 
    push   hl              ; 0008C7 E5 
    push   bc              ; 0008C8 C5 
    ld     a,l             ; 0008C9 7D 
    call   $7880           ; 0008CA CD 80 78 
    sbc    a,$00           ; 0008CD DE 00 
    ccf                    ; 0008CF 3F 
    jr     nc,$08d9        ; 0008D0 30 07 
    ld     ($788c),a       ; 0008D2 32 8C 78 
    pop    af              ; 0008D5 F1 
    pop    af              ; 0008D6 F1 
    scf                    ; 0008D7 37 
    jp     nc,$e1c1        ; 0008D8 D2 C1 E1 
    ld     a,c             ; 0008DB 79 
    inc    a               ; 0008DC 3C 
    dec    a               ; 0008DD 3D 
    rra                    ; 0008DE 1F 
    jp     m,$0797         ; 0008DF FA 97 07 
    rla                    ; 0008E2 17 
    ld     a,e             ; 0008E3 7B 
    rla                    ; 0008E4 17 
    ld     e,a             ; 0008E5 5F 
    ld     a,d             ; 0008E6 7A 
    rla                    ; 0008E7 17 
    ld     d,a             ; 0008E8 57 
    ld     a,c             ; 0008E9 79 
    rla                    ; 0008EA 17 
    ld     c,a             ; 0008EB 4F 
    add    hl,hl           ; 0008EC 29 
    ld     a,b             ; 0008ED 78 
    rla                    ; 0008EE 17 
    ld     b,a             ; 0008EF 47 
    ld     a,($788c)       ; 0008F0 3A 8C 78 
    rla                    ; 0008F3 17 
    ld     ($788c),a       ; 0008F4 32 8C 78 
    ld     a,c             ; 0008F7 79 
    or     d               ; 0008F8 B2 
    or     e               ; 0008F9 B3 
    jr     nz,$08c7        ; 0008FA 20 CB 
    push   hl              ; 0008FC E5 
    ld     hl,$7924        ; 0008FD 21 24 79 
    dec    (hl)            ; 000900 35 
    pop    hl              ; 000901 E1 
    jr     nz,$08c7        ; 000902 20 C3 
    jp     $07b2           ; 000904 C3 B2 07 
    ld     a,$ff           ; 000907 3E FF 
    ld     l,$af           ; 000909 2E AF 
    ld     hl,$792d        ; 00090B 21 2D 79 
    ld     c,(hl)          ; 00090E 4E 
    inc    hl              ; 00090F 23 
    xor    (hl)            ; 000910 AE 
    ld     b,a             ; 000911 47 
    ld     l,$00           ; 000912 2E 00 
    ld     a,b             ; 000914 78 
    or     a               ; 000915 B7 
    jr     z,$0937         ; 000916 28 1F 
    ld     a,l             ; 000918 7D 
    ld     hl,$7924        ; 000919 21 24 79 
    xor    (hl)            ; 00091C AE 
    add    a,b             ; 00091D 80 
    ld     b,a             ; 00091E 47 
    rra                    ; 00091F 1F 
    xor    b               ; 000920 A8 
    ld     a,b             ; 000921 78 
    jp     p,$0936         ; 000922 F2 36 09 
    add    a,$80           ; 000925 C6 80 
    ld     (hl),a          ; 000927 77 
    jp     z,$0890         ; 000928 CA 90 08 
    call   $09df           ; 00092B CD DF 09 
    ld     (hl),a          ; 00092E 77 
    dec    hl              ; 00092F 2B 
    ret                    ; 000930 C9 
    call   $0955           ; 000931 CD 55 09 
    cpl                    ; 000934 2F 
    pop    hl              ; 000935 E1 
    or     a               ; 000936 B7 
    pop    hl              ; 000937 E1 
    jp     p,$0778         ; 000938 F2 78 07 
    jp     $07b2           ; 00093B C3 B2 07 
    call   $09bf           ; 00093E CD BF 09 
    ld     a,b             ; 000941 78 
    or     a               ; 000942 B7 
    ret    z               ; 000943 C8 
    add    a,$02           ; 000944 C6 02 
    jp     c,$07b2         ; 000946 DA B2 07 
    ld     b,a             ; 000949 47 
    call   $0716           ; 00094A CD 16 07 
    ld     hl,$7924        ; 00094D 21 24 79 
    inc    (hl)            ; 000950 34 
    ret    nz              ; 000951 C0 
    jp     $07b2           ; 000952 C3 B2 07 
    ld     a,($7924)       ; 000955 3A 24 79 
    or     a               ; 000958 B7 
    ret    z               ; 000959 C8 
    ld     a,($7923)       ; 00095A 3A 23 79 
    cp     $2f             ; 00095D FE 2F 
    rla                    ; 00095F 17 
    sbc    a,a             ; 000960 9F 
    ret    nz              ; 000961 C0 
    inc    a               ; 000962 3C 
    ret                    ; 000963 C9 
    ld     b,$88           ; 000964 06 88 
    ld     de,$0000        ; 000966 11 00 00 
    ld     hl,$7924        ; 000969 21 24 79 
    ld     c,a             ; 00096C 4F 
    ld     (hl),b          ; 00096D 70 
    ld     b,$00           ; 00096E 06 00 
    inc    hl              ; 000970 23 
    ld     (hl),$80        ; 000971 36 80 
    rla                    ; 000973 17 
    jp     $0762           ; 000974 C3 62 07 
    call   $0994           ; 000977 CD 94 09 
    ret    p               ; 00097A F0 
    rst    20h             ; 00097B E7 
    jp     m,$0c5b         ; 00097C FA 5B 0C 
    jp     z,$0af6         ; 00097F CA F6 0A 
    ld     hl,$7923        ; 000982 21 23 79 
    ld     a,(hl)          ; 000985 7E 
    xor    $80             ; 000986 EE 80 
    ld     (hl),a          ; 000988 77 
    ret                    ; 000989 C9 
    call   $0994           ; 00098A CD 94 09 
    ld     l,a             ; 00098D 6F 
    rla                    ; 00098E 17 
    sbc    a,a             ; 00098F 9F 
    ld     h,a             ; 000990 67 
    jp     $0a9a           ; 000991 C3 9A 0A 
    rst    20h             ; 000994 E7 
    jp     z,$0af6         ; 000995 CA F6 0A 
    jp     p,$0955         ; 000998 F2 55 09 
    ld     hl,($7921)      ; 00099B 2A 21 79 
    ld     a,h             ; 00099E 7C 
    or     l               ; 00099F B5 
    ret    z               ; 0009A0 C8 
    ld     a,h             ; 0009A1 7C 
    jr     $095f           ; 0009A2 18 BB 
    ex     de,hl           ; 0009A4 EB 
    ld     hl,($7921)      ; 0009A5 2A 21 79 
    ex     (sp),hl         ; 0009A8 E3 
    push   hl              ; 0009A9 E5 
    ld     hl,($7923)      ; 0009AA 2A 23 79 
    ex     (sp),hl         ; 0009AD E3 
    push   hl              ; 0009AE E5 
    ex     de,hl           ; 0009AF EB 
    ret                    ; 0009B0 C9 
    call   $09c2           ; 0009B1 CD C2 09 
    ex     de,hl           ; 0009B4 EB 
    ld     ($7921),hl      ; 0009B5 22 21 79 
    ld     h,b             ; 0009B8 60 
    ld     l,c             ; 0009B9 69 
    ld     ($7923),hl      ; 0009BA 22 23 79 
    ex     de,hl           ; 0009BD EB 
    ret                    ; 0009BE C9 
    ld     hl,$7921        ; 0009BF 21 21 79 
    ld     e,(hl)          ; 0009C2 5E 
    inc    hl              ; 0009C3 23 
    ld     d,(hl)          ; 0009C4 56 
    inc    hl              ; 0009C5 23 
    ld     c,(hl)          ; 0009C6 4E 
    inc    hl              ; 0009C7 23 
    ld     b,(hl)          ; 0009C8 46 
    inc    hl              ; 0009C9 23 
    ret                    ; 0009CA C9 
    ld     de,$7921        ; 0009CB 11 21 79 
    ld     b,$04           ; 0009CE 06 04 
    jr     $09d7           ; 0009D0 18 05 
    ex     de,hl           ; 0009D2 EB 
    ld     a,($78af)       ; 0009D3 3A AF 78 
    ld     b,a             ; 0009D6 47 
    ld     a,(de)          ; 0009D7 1A 
    ld     (hl),a          ; 0009D8 77 
    inc    de              ; 0009D9 13 
    inc    hl              ; 0009DA 23 
    dec    b               ; 0009DB 05 
    jr     nz,$09d7        ; 0009DC 20 F9 
    ret                    ; 0009DE C9 
    ld     hl,$7923        ; 0009DF 21 23 79 
    ld     a,(hl)          ; 0009E2 7E 
    rlca                   ; 0009E3 07 
    scf                    ; 0009E4 37 
    rra                    ; 0009E5 1F 
    ld     (hl),a          ; 0009E6 77 
    ccf                    ; 0009E7 3F 
    rra                    ; 0009E8 1F 
    inc    hl              ; 0009E9 23 
    inc    hl              ; 0009EA 23 
    ld     (hl),a          ; 0009EB 77 
    ld     a,c             ; 0009EC 79 
    rlca                   ; 0009ED 07 
    scf                    ; 0009EE 37 
    rra                    ; 0009EF 1F 
    ld     c,a             ; 0009F0 4F 
    rra                    ; 0009F1 1F 
    xor    (hl)            ; 0009F2 AE 
    ret                    ; 0009F3 C9 
    ld     hl,$7927        ; 0009F4 21 27 79 
    ld     de,$09d2        ; 0009F7 11 D2 09 
    jr     $0a02           ; 0009FA 18 06 
    ld     hl,$7927        ; 0009FC 21 27 79 
    ld     de,$09d3        ; 0009FF 11 D3 09 
    push   de              ; 000A02 D5 
    ld     de,$7921        ; 000A03 11 21 79 
    rst    20h             ; 000A06 E7 
    ret    c               ; 000A07 D8 
    ld     de,$791d        ; 000A08 11 1D 79 
    ret                    ; 000A0B C9 
    ld     a,b             ; 000A0C 78 
    or     a               ; 000A0D B7 
    jp     z,$0955         ; 000A0E CA 55 09 
    ld     hl,$095e        ; 000A11 21 5E 09 
    push   hl              ; 000A14 E5 
    call   $0955           ; 000A15 CD 55 09 
    ld     a,c             ; 000A18 79 
    ret    z               ; 000A19 C8 
    ld     hl,$7923        ; 000A1A 21 23 79 
    xor    (hl)            ; 000A1D AE 
    ld     a,c             ; 000A1E 79 
    ret    m               ; 000A1F F8 
    call   $0a26           ; 000A20 CD 26 0A 
    rra                    ; 000A23 1F 
    xor    c               ; 000A24 A9 
    ret                    ; 000A25 C9 
    inc    hl              ; 000A26 23 
    ld     a,b             ; 000A27 78 
    cp     (hl)            ; 000A28 BE 
    ret    nz              ; 000A29 C0 
    dec    hl              ; 000A2A 2B 
    ld     a,c             ; 000A2B 79 
    cp     (hl)            ; 000A2C BE 
    ret    nz              ; 000A2D C0 
    dec    hl              ; 000A2E 2B 
    ld     a,d             ; 000A2F 7A 
    cp     (hl)            ; 000A30 BE 
    ret    nz              ; 000A31 C0 
    dec    hl              ; 000A32 2B 
    ld     a,e             ; 000A33 7B 
    sub    (hl)            ; 000A34 96 
    ret    nz              ; 000A35 C0 
    pop    hl              ; 000A36 E1 
    pop    hl              ; 000A37 E1 
    ret                    ; 000A38 C9 
    ld     a,d             ; 000A39 7A 
    xor    h               ; 000A3A AC 
    ld     a,h             ; 000A3B 7C 
    jp     m,$095f         ; 000A3C FA 5F 09 
    cp     d               ; 000A3F BA 
    jp     nz,$0960        ; 000A40 C2 60 09 
    ld     a,l             ; 000A43 7D 
    sub    e               ; 000A44 93 
    jp     nz,$0960        ; 000A45 C2 60 09 
    ret                    ; 000A48 C9 
    ld     hl,$7927        ; 000A49 21 27 79 
    call   $09d3           ; 000A4C CD D3 09 
    ld     de,$792e        ; 000A4F 11 2E 79 
    ld     a,(de)          ; 000A52 1A 
    or     a               ; 000A53 B7 
    jp     z,$0955         ; 000A54 CA 55 09 
    ld     hl,$095e        ; 000A57 21 5E 09 
    push   hl              ; 000A5A E5 
    call   $0955           ; 000A5B CD 55 09 
    dec    de              ; 000A5E 1B 
    ld     a,(de)          ; 000A5F 1A 
    ld     c,a             ; 000A60 4F 
    ret    z               ; 000A61 C8 
    ld     hl,$7923        ; 000A62 21 23 79 
    xor    (hl)            ; 000A65 AE 
    ld     a,c             ; 000A66 79 
    ret    m               ; 000A67 F8 
    inc    de              ; 000A68 13 
    inc    hl              ; 000A69 23 
    ld     b,$08           ; 000A6A 06 08 
    ld     a,(de)          ; 000A6C 1A 
    sub    (hl)            ; 000A6D 96 
    jp     nz,$0a23        ; 000A6E C2 23 0A 
    dec    de              ; 000A71 1B 
    dec    hl              ; 000A72 2B 
    dec    b               ; 000A73 05 
    jr     nz,$0a6c        ; 000A74 20 F6 
    pop    bc              ; 000A76 C1 
    ret                    ; 000A77 C9 
    call   $0a4f           ; 000A78 CD 4F 0A 
    jp     nz,$095e        ; 000A7B C2 5E 09 
    ret                    ; 000A7E C9 
    rst    20h             ; 000A7F E7 
    ld     hl,($7921)      ; 000A80 2A 21 79 
    ret    m               ; 000A83 F8 
    jp     z,$0af6         ; 000A84 CA F6 0A 
    call   nc,$0ab9        ; 000A87 D4 B9 0A 
    ld     hl,$07b2        ; 000A8A 21 B2 07 
    push   hl              ; 000A8D E5 
    ld     a,($7924)       ; 000A8E 3A 24 79 
    cp     $90             ; 000A91 FE 90 
    jr     nc,$0aa3        ; 000A93 30 0E 
    call   $0afb           ; 000A95 CD FB 0A 
    ex     de,hl           ; 000A98 EB 
    pop    de              ; 000A99 D1 
    ld     ($7921),hl      ; 000A9A 22 21 79 
    ld     a,$02           ; 000A9D 3E 02 
    ld     ($78af),a       ; 000A9F 32 AF 78 
    ret                    ; 000AA2 C9 
    ld     bc,$9080        ; 000AA3 01 80 90 
    ld     de,$0000        ; 000AA6 11 00 00 
    call   $0a0c           ; 000AA9 CD 0C 0A 
    ret    nz              ; 000AAC C0 
    ld     h,c             ; 000AAD 61 
    ld     l,d             ; 000AAE 6A 
    jr     $0a99           ; 000AAF 18 E8 
    rst    20h             ; 000AB1 E7 
    ret    po              ; 000AB2 E0 
    jp     m,$0acc         ; 000AB3 FA CC 0A 
    jp     z,$0af6         ; 000AB6 CA F6 0A 
    call   $09bf           ; 000AB9 CD BF 09 
    call   $0aef           ; 000ABC CD EF 0A 
    ld     a,b             ; 000ABF 78 
    or     a               ; 000AC0 B7 
    ret    z               ; 000AC1 C8 
    call   $09df           ; 000AC2 CD DF 09 
    ld     hl,$7920        ; 000AC5 21 20 79 
    ld     b,(hl)          ; 000AC8 46 
    jp     $0796           ; 000AC9 C3 96 07 
    ld     hl,($7921)      ; 000ACC 2A 21 79 
    call   $0aef           ; 000ACF CD EF 0A 
    ld     a,h             ; 000AD2 7C 
    ld     d,l             ; 000AD3 55 
    ld     e,$00           ; 000AD4 1E 00 
    ld     b,$90           ; 000AD6 06 90 
    jp     $0969           ; 000AD8 C3 69 09 
    rst    20h             ; 000ADB E7 
    ret    nc              ; 000ADC D0 
    jp     z,$0af6         ; 000ADD CA F6 0A 
    call   m,$0acc         ; 000AE0 FC CC 0A 
    ld     hl,$0000        ; 000AE3 21 00 00 
    ld     ($791d),hl      ; 000AE6 22 1D 79 
    ld     ($791f),hl      ; 000AE9 22 1F 79 
    ld     a,$08           ; 000AEC 3E 08 
    ld     bc,$043e        ; 000AEE 01 3E 04 
    jp     $0a9f           ; 000AF1 C3 9F 0A 
    rst    20h             ; 000AF4 E7 
    ret    z               ; 000AF5 C8 
    ld     e,$18           ; 000AF6 1E 18 
    jp     $19a2           ; 000AF8 C3 A2 19 
    ld     b,a             ; 000AFB 47 
    ld     c,a             ; 000AFC 4F 
    ld     d,a             ; 000AFD 57 
    ld     e,a             ; 000AFE 5F 
    or     a               ; 000AFF B7 
    ret    z               ; 000B00 C8 
    push   hl              ; 000B01 E5 
    call   $09bf           ; 000B02 CD BF 09 
    call   $09df           ; 000B05 CD DF 09 
    xor    (hl)            ; 000B08 AE 
    ld     h,a             ; 000B09 67 
    call   m,$0b1f         ; 000B0A FC 1F 0B 
    ld     a,$98           ; 000B0D 3E 98 
    sub    b               ; 000B0F 90 
    call   $07d7           ; 000B10 CD D7 07 
    ld     a,h             ; 000B13 7C 
    rla                    ; 000B14 17 
    call   c,$07a8         ; 000B15 DC A8 07 
    ld     b,$00           ; 000B18 06 00 
    call   c,$07c3         ; 000B1A DC C3 07 
    pop    hl              ; 000B1D E1 
    ret                    ; 000B1E C9 
    dec    de              ; 000B1F 1B 
    ld     a,d             ; 000B20 7A 
    and    e               ; 000B21 A3 
    inc    a               ; 000B22 3C 
    ret    nz              ; 000B23 C0 
    dec    bc              ; 000B24 0B 
    ret                    ; 000B25 C9 
    rst    20h             ; 000B26 E7 
    ret    m               ; 000B27 F8 
    call   $0955           ; 000B28 CD 55 09 
    jp     p,$0b37         ; 000B2B F2 37 0B 
    call   $0982           ; 000B2E CD 82 09 
    call   $0b37           ; 000B31 CD 37 0B 
    jp     $097b           ; 000B34 C3 7B 09 
    rst    20h             ; 000B37 E7 
    ret    m               ; 000B38 F8 
    jr     nc,$0b59        ; 000B39 30 1E 
    jr     z,$0af6         ; 000B3B 28 B9 
    call   $0a8e           ; 000B3D CD 8E 0A 
    ld     hl,$7924        ; 000B40 21 24 79 
    ld     a,(hl)          ; 000B43 7E 
    cp     $98             ; 000B44 FE 98 
    ld     a,($7921)       ; 000B46 3A 21 79 
    ret    nc              ; 000B49 D0 
    ld     a,(hl)          ; 000B4A 7E 
    call   $0afb           ; 000B4B CD FB 0A 
    ld     (hl),$98        ; 000B4E 36 98 
    ld     a,e             ; 000B50 7B 
    push   af              ; 000B51 F5 
    ld     a,c             ; 000B52 79 
    rla                    ; 000B53 17 
    call   $0762           ; 000B54 CD 62 07 
    pop    af              ; 000B57 F1 
    ret                    ; 000B58 C9 
    ld     hl,$7924        ; 000B59 21 24 79 
    ld     a,(hl)          ; 000B5C 7E 
    cp     $90             ; 000B5D FE 90 
    jp     c,$0a7f         ; 000B5F DA 7F 0A 
    jr     nz,$0b78        ; 000B62 20 14 
    ld     c,a             ; 000B64 4F 
    dec    hl              ; 000B65 2B 
    ld     a,(hl)          ; 000B66 7E 
    xor    $80             ; 000B67 EE 80 
    ld     b,$06           ; 000B69 06 06 
    dec    hl              ; 000B6B 2B 
    or     (hl)            ; 000B6C B6 
    dec    b               ; 000B6D 05 
    jr     nz,$0b6b        ; 000B6E 20 FB 
    or     a               ; 000B70 B7 
    ld     hl,$8000        ; 000B71 21 00 80 
    jp     z,$0a9a         ; 000B74 CA 9A 0A 
    ld     a,c             ; 000B77 79 
    cp     $b8             ; 000B78 FE B8 
    ret    nc              ; 000B7A D0 
    push   af              ; 000B7B F5 
    call   $09bf           ; 000B7C CD BF 09 
    call   $09df           ; 000B7F CD DF 09 
    xor    (hl)            ; 000B82 AE 
    dec    hl              ; 000B83 2B 
    ld     (hl),$b8        ; 000B84 36 B8 
    push   af              ; 000B86 F5 
    call   m,$0ba0         ; 000B87 FC A0 0B 
    ld     hl,$7923        ; 000B8A 21 23 79 
    ld     a,$b8           ; 000B8D 3E B8 
    sub    b               ; 000B8F 90 
    call   $0d69           ; 000B90 CD 69 0D 
    pop    af              ; 000B93 F1 
    call   m,$0d20         ; 000B94 FC 20 0D 
    xor    a               ; 000B97 AF 
    ld     ($791c),a       ; 000B98 32 1C 79 
    pop    af              ; 000B9B F1 
    ret    nc              ; 000B9C D0 
    jp     $0cd8           ; 000B9D C3 D8 0C 
    ld     hl,$791d        ; 000BA0 21 1D 79 
    ld     a,(hl)          ; 000BA3 7E 
    dec    (hl)            ; 000BA4 35 
    or     a               ; 000BA5 B7 
    inc    hl              ; 000BA6 23 
    jr     z,$0ba3         ; 000BA7 28 FA 
    ret                    ; 000BA9 C9 
    push   hl              ; 000BAA E5 
    ld     hl,$0000        ; 000BAB 21 00 00 
    ld     a,b             ; 000BAE 78 
    or     c               ; 000BAF B1 
    jr     z,$0bc4         ; 000BB0 28 12 
    ld     a,$10           ; 000BB2 3E 10 
    add    hl,hl           ; 000BB4 29 
    jp     c,$273d         ; 000BB5 DA 3D 27 
    ex     de,hl           ; 000BB8 EB 
    add    hl,hl           ; 000BB9 29 
    ex     de,hl           ; 000BBA EB 
    jr     nc,$0bc1        ; 000BBB 30 04 
    add    hl,bc           ; 000BBD 09 
    jp     c,$273d         ; 000BBE DA 3D 27 
    dec    a               ; 000BC1 3D 
    jr     nz,$0bb4        ; 000BC2 20 F0 
    ex     de,hl           ; 000BC4 EB 
    pop    hl              ; 000BC5 E1 
    ret                    ; 000BC6 C9 
    ld     a,h             ; 000BC7 7C 
    rla                    ; 000BC8 17 
    sbc    a,a             ; 000BC9 9F 
    ld     b,a             ; 000BCA 47 
    call   $0c51           ; 000BCB CD 51 0C 
    ld     a,c             ; 000BCE 79 
    sbc    a,b             ; 000BCF 98 
    jr     $0bd5           ; 000BD0 18 03 
    ld     a,h             ; 000BD2 7C 
    rla                    ; 000BD3 17 
    sbc    a,a             ; 000BD4 9F 
    ld     b,a             ; 000BD5 47 
    push   hl              ; 000BD6 E5 
    ld     a,d             ; 000BD7 7A 
    rla                    ; 000BD8 17 
    sbc    a,a             ; 000BD9 9F 
    add    hl,de           ; 000BDA 19 
    adc    a,b             ; 000BDB 88 
    rrca                   ; 000BDC 0F 
    xor    h               ; 000BDD AC 
    jp     p,$0a99         ; 000BDE F2 99 0A 
    push   bc              ; 000BE1 C5 
    ex     de,hl           ; 000BE2 EB 
    call   $0acf           ; 000BE3 CD CF 0A 
    pop    af              ; 000BE6 F1 
    pop    hl              ; 000BE7 E1 
    call   $09a4           ; 000BE8 CD A4 09 
    ex     de,hl           ; 000BEB EB 
    call   $0c6b           ; 000BEC CD 6B 0C 
    jp     $0f8f           ; 000BEF C3 8F 0F 
    ld     a,h             ; 000BF2 7C 
    or     l               ; 000BF3 B5 
    jp     z,$0a9a         ; 000BF4 CA 9A 0A 
    push   hl              ; 000BF7 E5 
    push   de              ; 000BF8 D5 
    call   $0c45           ; 000BF9 CD 45 0C 
    push   bc              ; 000BFC C5 
    ld     b,h             ; 000BFD 44 
    ld     c,l             ; 000BFE 4D 
    ld     hl,$0000        ; 000BFF 21 00 00 
    ld     a,$10           ; 000C02 3E 10 
    add    hl,hl           ; 000C04 29 
    jr     c,$0c26         ; 000C05 38 1F 
    ex     de,hl           ; 000C07 EB 
    add    hl,hl           ; 000C08 29 
    ex     de,hl           ; 000C09 EB 
    jr     nc,$0c10        ; 000C0A 30 04 
    add    hl,bc           ; 000C0C 09 
    jp     c,$0c26         ; 000C0D DA 26 0C 
    dec    a               ; 000C10 3D 
    jr     nz,$0c04        ; 000C11 20 F1 
    pop    bc              ; 000C13 C1 
    pop    de              ; 000C14 D1 
    ld     a,h             ; 000C15 7C 
    or     a               ; 000C16 B7 
    jp     m,$0c1f         ; 000C17 FA 1F 0C 
    pop    de              ; 000C1A D1 
    ld     a,b             ; 000C1B 78 
    jp     $0c4d           ; 000C1C C3 4D 0C 
    xor    $80             ; 000C1F EE 80 
    or     l               ; 000C21 B5 
    jr     z,$0c37         ; 000C22 28 13 
    ex     de,hl           ; 000C24 EB 
    ld     bc,$e1c1        ; 000C25 01 C1 E1 
    call   $0acf           ; 000C28 CD CF 0A 
    pop    hl              ; 000C2B E1 
    call   $09a4           ; 000C2C CD A4 09 
    call   $0acf           ; 000C2F CD CF 0A 
    pop    bc              ; 000C32 C1 
    pop    de              ; 000C33 D1 
    jp     $0847           ; 000C34 C3 47 08 
    ld     a,b             ; 000C37 78 
    or     a               ; 000C38 B7 
    pop    bc              ; 000C39 C1 
    jp     m,$0a9a         ; 000C3A FA 9A 0A 
    push   de              ; 000C3D D5 
    call   $0acf           ; 000C3E CD CF 0A 
    pop    de              ; 000C41 D1 
    jp     $0982           ; 000C42 C3 82 09 
    ld     a,h             ; 000C45 7C 
    xor    d               ; 000C46 AA 
    ld     b,a             ; 000C47 47 
    call   $0c4c           ; 000C48 CD 4C 0C 
    ex     de,hl           ; 000C4B EB 
    ld     a,h             ; 000C4C 7C 
    or     a               ; 000C4D B7 
    jp     p,$0a9a         ; 000C4E F2 9A 0A 
    xor    a               ; 000C51 AF 
    ld     c,a             ; 000C52 4F 
    sub    l               ; 000C53 95 
    ld     l,a             ; 000C54 6F 
    ld     a,c             ; 000C55 79 
    sbc    a,h             ; 000C56 9C 
    ld     h,a             ; 000C57 67 
    jp     $0a9a           ; 000C58 C3 9A 0A 
    ld     hl,($7921)      ; 000C5B 2A 21 79 
    call   $0c51           ; 000C5E CD 51 0C 
    ld     a,h             ; 000C61 7C 
    xor    $80             ; 000C62 EE 80 
    or     l               ; 000C64 B5 
    ret    nz              ; 000C65 C0 
    ex     de,hl           ; 000C66 EB 
    call   $0aef           ; 000C67 CD EF 0A 
    xor    a               ; 000C6A AF 
    ld     b,$98           ; 000C6B 06 98 
    jp     $0969           ; 000C6D C3 69 09 
    ld     hl,$792d        ; 000C70 21 2D 79 
    ld     a,(hl)          ; 000C73 7E 
    xor    $80             ; 000C74 EE 80 
    ld     (hl),a          ; 000C76 77 
    ld     hl,$792e        ; 000C77 21 2E 79 
    ld     a,(hl)          ; 000C7A 7E 
    or     a               ; 000C7B B7 
    ret    z               ; 000C7C C8 
    ld     b,a             ; 000C7D 47 
    dec    hl              ; 000C7E 2B 
    ld     c,(hl)          ; 000C7F 4E 
    ld     de,$7924        ; 000C80 11 24 79 
    ld     a,(de)          ; 000C83 1A 
    or     a               ; 000C84 B7 
    jp     z,$09f4         ; 000C85 CA F4 09 
    sub    b               ; 000C88 90 
    jr     nc,$0ca1        ; 000C89 30 16 
    cpl                    ; 000C8B 2F 
    inc    a               ; 000C8C 3C 
    push   af              ; 000C8D F5 
    ld     c,$08           ; 000C8E 0E 08 
    inc    hl              ; 000C90 23 
    push   hl              ; 000C91 E5 
    ld     a,(de)          ; 000C92 1A 
    ld     b,(hl)          ; 000C93 46 
    ld     (hl),a          ; 000C94 77 
    ld     a,b             ; 000C95 78 
    ld     (de),a          ; 000C96 12 
    dec    de              ; 000C97 1B 
    dec    hl              ; 000C98 2B 
    dec    c               ; 000C99 0D 
    jr     nz,$0c92        ; 000C9A 20 F6 
    pop    hl              ; 000C9C E1 
    ld     b,(hl)          ; 000C9D 46 
    dec    hl              ; 000C9E 2B 
    ld     c,(hl)          ; 000C9F 4E 
    pop    af              ; 000CA0 F1 
    cp     $39             ; 000CA1 FE 39 
    ret    nc              ; 000CA3 D0 
    push   af              ; 000CA4 F5 
    call   $09df           ; 000CA5 CD DF 09 
    inc    hl              ; 000CA8 23 
    ld     (hl),$00        ; 000CA9 36 00 
    ld     b,a             ; 000CAB 47 
    pop    af              ; 000CAC F1 
    ld     hl,$792d        ; 000CAD 21 2D 79 
    call   $0d69           ; 000CB0 CD 69 0D 
    ld     a,($7926)       ; 000CB3 3A 26 79 
    ld     ($791c),a       ; 000CB6 32 1C 79 
    ld     a,b             ; 000CB9 78 
    or     a               ; 000CBA B7 
    jp     p,$0ccf         ; 000CBB F2 CF 0C 
    call   $0d33           ; 000CBE CD 33 0D 
    jp     nc,$0d0e        ; 000CC1 D2 0E 0D 
    ex     de,hl           ; 000CC4 EB 
    inc    (hl)            ; 000CC5 34 
    jp     z,$07b2         ; 000CC6 CA B2 07 
    call   $0d90           ; 000CC9 CD 90 0D 
    jp     $0d0e           ; 000CCC C3 0E 0D 
    call   $0d45           ; 000CCF CD 45 0D 
    ld     hl,$7925        ; 000CD2 21 25 79 
    call   c,$0d57         ; 000CD5 DC 57 0D 
    xor    a               ; 000CD8 AF 
    ld     b,a             ; 000CD9 47 
    ld     a,($7923)       ; 000CDA 3A 23 79 
    or     a               ; 000CDD B7 
    jr     nz,$0cfe        ; 000CDE 20 1E 
    ld     hl,$791c        ; 000CE0 21 1C 79 
    ld     c,$08           ; 000CE3 0E 08 
    ld     d,(hl)          ; 000CE5 56 
    ld     (hl),a          ; 000CE6 77 
    ld     a,d             ; 000CE7 7A 
    inc    hl              ; 000CE8 23 
    dec    c               ; 000CE9 0D 
    jr     nz,$0ce5        ; 000CEA 20 F9 
    ld     a,b             ; 000CEC 78 
    sub    $08             ; 000CED D6 08 
    cp     $c0             ; 000CEF FE C0 
    jr     nz,$0cd9        ; 000CF1 20 E6 
    jp     $0778           ; 000CF3 C3 78 07 
    dec    b               ; 000CF6 05 
    ld     hl,$791c        ; 000CF7 21 1C 79 
    call   $0d97           ; 000CFA CD 97 0D 
    or     a               ; 000CFD B7 
    jp     p,$0cf6         ; 000CFE F2 F6 0C 
    ld     a,b             ; 000D01 78 
    or     a               ; 000D02 B7 
    jr     z,$0d0e         ; 000D03 28 09 
    ld     hl,$7924        ; 000D05 21 24 79 
    add    a,(hl)          ; 000D08 86 
    ld     (hl),a          ; 000D09 77 
    jp     nc,$0778        ; 000D0A D2 78 07 
    ret    z               ; 000D0D C8 
    ld     a,($791c)       ; 000D0E 3A 1C 79 
    or     a               ; 000D11 B7 
    call   m,$0d20         ; 000D12 FC 20 0D 
    ld     hl,$7925        ; 000D15 21 25 79 
    ld     a,(hl)          ; 000D18 7E 
    and    $80             ; 000D19 E6 80 
    dec    hl              ; 000D1B 2B 
    dec    hl              ; 000D1C 2B 
    xor    (hl)            ; 000D1D AE 
    ld     (hl),a          ; 000D1E 77 
    ret                    ; 000D1F C9 
    ld     hl,$791d        ; 000D20 21 1D 79 
    ld     b,$07           ; 000D23 06 07 
    inc    (hl)            ; 000D25 34 
    ret    nz              ; 000D26 C0 
    inc    hl              ; 000D27 23 
    dec    b               ; 000D28 05 
    jr     nz,$0d25        ; 000D29 20 FA 
    inc    (hl)            ; 000D2B 34 
    jp     z,$07b2         ; 000D2C CA B2 07 
    dec    hl              ; 000D2F 2B 
    ld     (hl),$80        ; 000D30 36 80 
    ret                    ; 000D32 C9 
    ld     hl,$7927        ; 000D33 21 27 79 
    ld     de,$791d        ; 000D36 11 1D 79 
    ld     c,$07           ; 000D39 0E 07 
    xor    a               ; 000D3B AF 
    ld     a,(de)          ; 000D3C 1A 
    adc    a,(hl)          ; 000D3D 8E 
    ld     (de),a          ; 000D3E 12 
    inc    de              ; 000D3F 13 
    inc    hl              ; 000D40 23 
    dec    c               ; 000D41 0D 
    jr     nz,$0d3c        ; 000D42 20 F8 
    ret                    ; 000D44 C9 
    ld     hl,$7927        ; 000D45 21 27 79 
    ld     de,$791d        ; 000D48 11 1D 79 
    ld     c,$07           ; 000D4B 0E 07 
    xor    a               ; 000D4D AF 
    ld     a,(de)          ; 000D4E 1A 
    sbc    a,(hl)          ; 000D4F 9E 
    ld     (de),a          ; 000D50 12 
    inc    de              ; 000D51 13 
    inc    hl              ; 000D52 23 
    dec    c               ; 000D53 0D 
    jr     nz,$0d4e        ; 000D54 20 F8 
    ret                    ; 000D56 C9 
    ld     a,(hl)          ; 000D57 7E 
    cpl                    ; 000D58 2F 
    ld     (hl),a          ; 000D59 77 
    ld     hl,$791c        ; 000D5A 21 1C 79 
    ld     b,$08           ; 000D5D 06 08 
    xor    a               ; 000D5F AF 
    ld     c,a             ; 000D60 4F 
    ld     a,c             ; 000D61 79 
    sbc    a,(hl)          ; 000D62 9E 
    ld     (hl),a          ; 000D63 77 
    inc    hl              ; 000D64 23 
    dec    b               ; 000D65 05 
    jr     nz,$0d61        ; 000D66 20 F9 
    ret                    ; 000D68 C9 
    ld     (hl),c          ; 000D69 71 
    push   hl              ; 000D6A E5 
    sub    $08             ; 000D6B D6 08 
    jr     c,$0d7d         ; 000D6D 38 0E 
    pop    hl              ; 000D6F E1 
    push   hl              ; 000D70 E5 
    ld     de,$0800        ; 000D71 11 00 08 
    ld     c,(hl)          ; 000D74 4E 
    ld     (hl),e          ; 000D75 73 
    ld     e,c             ; 000D76 59 
    dec    hl              ; 000D77 2B 
    dec    d               ; 000D78 15 
    jr     nz,$0d74        ; 000D79 20 F9 
    jr     $0d6b           ; 000D7B 18 EE 
    add    a,$09           ; 000D7D C6 09 
    ld     d,a             ; 000D7F 57 
    xor    a               ; 000D80 AF 
    pop    hl              ; 000D81 E1 
    dec    d               ; 000D82 15 
    ret    z               ; 000D83 C8 
    push   hl              ; 000D84 E5 
    ld     e,$08           ; 000D85 1E 08 
    ld     a,(hl)          ; 000D87 7E 
    rra                    ; 000D88 1F 
    ld     (hl),a          ; 000D89 77 
    dec    hl              ; 000D8A 2B 
    dec    e               ; 000D8B 1D 
    jr     nz,$0d87        ; 000D8C 20 F9 
    jr     $0d80           ; 000D8E 18 F0 
    ld     hl,$7923        ; 000D90 21 23 79 
    ld     d,$01           ; 000D93 16 01 
    jr     $0d84           ; 000D95 18 ED 
    ld     c,$08           ; 000D97 0E 08 
    ld     a,(hl)          ; 000D99 7E 
    rla                    ; 000D9A 17 
    ld     (hl),a          ; 000D9B 77 
    inc    hl              ; 000D9C 23 
    dec    c               ; 000D9D 0D 
    jr     nz,$0d99        ; 000D9E 20 F9 
    ret                    ; 000DA0 C9 
    call   $0955           ; 000DA1 CD 55 09 
    ret    z               ; 000DA4 C8 
    call   $090a           ; 000DA5 CD 0A 09 
    call   $0e39           ; 000DA8 CD 39 0E 
    ld     (hl),c          ; 000DAB 71 
    inc    de              ; 000DAC 13 
    ld     b,$07           ; 000DAD 06 07 
    ld     a,(de)          ; 000DAF 1A 
    inc    de              ; 000DB0 13 
    or     a               ; 000DB1 B7 
    push   de              ; 000DB2 D5 
    jr     z,$0dcc         ; 000DB3 28 17 
    ld     c,$08           ; 000DB5 0E 08 
    push   bc              ; 000DB7 C5 
    rra                    ; 000DB8 1F 
    ld     b,a             ; 000DB9 47 
    call   c,$0d33         ; 000DBA DC 33 0D 
    call   $0d90           ; 000DBD CD 90 0D 
    ld     a,b             ; 000DC0 78 
    pop    bc              ; 000DC1 C1 
    dec    c               ; 000DC2 0D 
    jr     nz,$0db7        ; 000DC3 20 F2 
    pop    de              ; 000DC5 D1 
    dec    b               ; 000DC6 05 
    jr     nz,$0daf        ; 000DC7 20 E6 
    jp     $0cd8           ; 000DC9 C3 D8 0C 
    ld     hl,$7923        ; 000DCC 21 23 79 
    call   $0d70           ; 000DCF CD 70 0D 
    jr     $0dc5           ; 000DD2 18 F1 
    nop                    ; 000DD4 00 
    nop                    ; 000DD5 00 
    nop                    ; 000DD6 00 
    nop                    ; 000DD7 00 
    nop                    ; 000DD8 00 
    nop                    ; 000DD9 00 
    jr     nz,$0d60        ; 000DDA 20 84 
    ld     de,$0dd4        ; 000DDC 11 D4 0D 
    ld     hl,$7927        ; 000DDF 21 27 79 
    call   $09d3           ; 000DE2 CD D3 09 
    ld     a,($792e)       ; 000DE5 3A 2E 79 
    or     a               ; 000DE8 B7 
    jp     z,$199a         ; 000DE9 CA 9A 19 
    call   $0907           ; 000DEC CD 07 09 
    inc    (hl)            ; 000DEF 34 
    inc    (hl)            ; 000DF0 34 
    call   $0e39           ; 000DF1 CD 39 0E 
    ld     hl,$7951        ; 000DF4 21 51 79 
    ld     (hl),c          ; 000DF7 71 
    ld     b,c             ; 000DF8 41 
    ld     de,$794a        ; 000DF9 11 4A 79 
    ld     hl,$7927        ; 000DFC 21 27 79 
    call   $0d4b           ; 000DFF CD 4B 0D 
    ld     a,(de)          ; 000E02 1A 
    sbc    a,c             ; 000E03 99 
    ccf                    ; 000E04 3F 
    jr     c,$0e12         ; 000E05 38 0B 
    ld     de,$794a        ; 000E07 11 4A 79 
    ld     hl,$7927        ; 000E0A 21 27 79 
    call   $0d39           ; 000E0D CD 39 0D 
    xor    a               ; 000E10 AF 
    jp     c,$0412         ; 000E11 DA 12 04 
    ld     a,($7923)       ; 000E14 3A 23 79 
    inc    a               ; 000E17 3C 
    dec    a               ; 000E18 3D 
    rra                    ; 000E19 1F 
    jp     m,$0d11         ; 000E1A FA 11 0D 
    rla                    ; 000E1D 17 
    ld     hl,$791d        ; 000E1E 21 1D 79 
    ld     c,$07           ; 000E21 0E 07 
    call   $0d99           ; 000E23 CD 99 0D 
    ld     hl,$794a        ; 000E26 21 4A 79 
    call   $0d97           ; 000E29 CD 97 0D 
    ld     a,b             ; 000E2C 78 
    or     a               ; 000E2D B7 
    jr     nz,$0df9        ; 000E2E 20 C9 
    ld     hl,$7924        ; 000E30 21 24 79 
    dec    (hl)            ; 000E33 35 
    jr     nz,$0df9        ; 000E34 20 C3 
    jp     $07b2           ; 000E36 C3 B2 07 
    ld     a,c             ; 000E39 79 
    ld     ($792d),a       ; 000E3A 32 2D 79 
    dec    hl              ; 000E3D 2B 
    ld     de,$7950        ; 000E3E 11 50 79 
    ld     bc,$0700        ; 000E41 01 00 07 
    ld     a,(hl)          ; 000E44 7E 
    ld     (de),a          ; 000E45 12 
    ld     (hl),c          ; 000E46 71 
    dec    de              ; 000E47 1B 
    dec    hl              ; 000E48 2B 
    dec    b               ; 000E49 05 
    jr     nz,$0e44        ; 000E4A 20 F8 
    ret                    ; 000E4C C9 
    call   $09fc           ; 000E4D CD FC 09 
    ex     de,hl           ; 000E50 EB 
    dec    hl              ; 000E51 2B 
    ld     a,(hl)          ; 000E52 7E 
    or     a               ; 000E53 B7 
    ret    z               ; 000E54 C8 
    add    a,$02           ; 000E55 C6 02 
    jp     c,$07b2         ; 000E57 DA B2 07 
    ld     (hl),a          ; 000E5A 77 
    push   hl              ; 000E5B E5 
    call   $0c77           ; 000E5C CD 77 0C 
    pop    hl              ; 000E5F E1 
    inc    (hl)            ; 000E60 34 
    ret    nz              ; 000E61 C0 
    jp     $07b2           ; 000E62 C3 B2 07 
    call   $0778           ; 000E65 CD 78 07 
    call   $0aec           ; 000E68 CD EC 0A 
    or     $af             ; 000E6B F6 AF 
    ex     de,hl           ; 000E6D EB 
    ld     bc,$00ff        ; 000E6E 01 FF 00 
    ld     h,b             ; 000E71 60 
    ld     l,b             ; 000E72 68 
    call   z,$0a9a         ; 000E73 CC 9A 0A 
    ex     de,hl           ; 000E76 EB 
    ld     a,(hl)          ; 000E77 7E 
    cp     $2d             ; 000E78 FE 2D 
    push   af              ; 000E7A F5 
    jp     z,$0e83         ; 000E7B CA 83 0E 
    cp     $2b             ; 000E7E FE 2B 
    jr     z,$0e83         ; 000E80 28 01 
    dec    hl              ; 000E82 2B 
    rst    10h             ; 000E83 D7 
    jp     c,$0f29         ; 000E84 DA 29 0F 
    cp     $2e             ; 000E87 FE 2E 
    jp     z,$0ee4         ; 000E89 CA E4 0E 
    cp     $45             ; 000E8C FE 45 
    jr     z,$0ea4         ; 000E8E 28 14 
    cp     $25             ; 000E90 FE 25 
    jp     z,$0eee         ; 000E92 CA EE 0E 
    cp     $23             ; 000E95 FE 23 
    jp     z,$0ef5         ; 000E97 CA F5 0E 
    cp     $21             ; 000E9A FE 21 
    jp     z,$0ef6         ; 000E9C CA F6 0E 
    cp     $44             ; 000E9F FE 44 
    jr     nz,$0ec7        ; 000EA1 20 24 
    or     a               ; 000EA3 B7 
    call   $0efb           ; 000EA4 CD FB 0E 
    push   hl              ; 000EA7 E5 
    ld     hl,$0ebd        ; 000EA8 21 BD 0E 
    ex     (sp),hl         ; 000EAB E3 
    rst    10h             ; 000EAC D7 
    dec    d               ; 000EAD 15 
    cp     $ce             ; 000EAE FE CE 
    ret    z               ; 000EB0 C8 
    cp     $2d             ; 000EB1 FE 2D 
    ret    z               ; 000EB3 C8 
    inc    d               ; 000EB4 14 
    cp     $cd             ; 000EB5 FE CD 
    ret    z               ; 000EB7 C8 
    cp     $2b             ; 000EB8 FE 2B 
    ret    z               ; 000EBA C8 
    dec    hl              ; 000EBB 2B 
    pop    af              ; 000EBC F1 
    rst    10h             ; 000EBD D7 
    jp     c,$0f94         ; 000EBE DA 94 0F 
    inc    d               ; 000EC1 14 
    jr     nz,$0ec7        ; 000EC2 20 03 
    xor    a               ; 000EC4 AF 
    sub    e               ; 000EC5 93 
    ld     e,a             ; 000EC6 5F 
    push   hl              ; 000EC7 E5 
    ld     a,e             ; 000EC8 7B 
    sub    b               ; 000EC9 90 
    call   p,$0f0a         ; 000ECA F4 0A 0F 
    call   m,$0f18         ; 000ECD FC 18 0F 
    jr     nz,$0eca        ; 000ED0 20 F8 
    pop    hl              ; 000ED2 E1 
    pop    af              ; 000ED3 F1 
    push   hl              ; 000ED4 E5 
    call   z,$097b         ; 000ED5 CC 7B 09 
    pop    hl              ; 000ED8 E1 
    rst    20h             ; 000ED9 E7 
    ret    pe              ; 000EDA E8 
    push   hl              ; 000EDB E5 
    ld     hl,$0890        ; 000EDC 21 90 08 
    push   hl              ; 000EDF E5 
    call   $0aa3           ; 000EE0 CD A3 0A 
    ret                    ; 000EE3 C9 
    rst    20h             ; 000EE4 E7 
    inc    c               ; 000EE5 0C 
    jr     nz,$0ec7        ; 000EE6 20 DF 
    call   c,$0efb         ; 000EE8 DC FB 0E 
    jp     $0e83           ; 000EEB C3 83 0E 
    rst    20h             ; 000EEE E7 
    jp     p,$1997         ; 000EEF F2 97 19 
    inc    hl              ; 000EF2 23 
    jr     $0ec7           ; 000EF3 18 D2 
    or     a               ; 000EF5 B7 
    call   $0efb           ; 000EF6 CD FB 0E 
    jr     $0ef2           ; 000EF9 18 F7 
    push   hl              ; 000EFB E5 
    push   de              ; 000EFC D5 
    push   bc              ; 000EFD C5 
    push   af              ; 000EFE F5 
    call   z,$0ab1         ; 000EFF CC B1 0A 
    pop    af              ; 000F02 F1 
    call   nz,$0adb        ; 000F03 C4 DB 0A 
    pop    bc              ; 000F06 C1 
    pop    de              ; 000F07 D1 
    pop    hl              ; 000F08 E1 
    ret                    ; 000F09 C9 
    ret    z               ; 000F0A C8 
    push   af              ; 000F0B F5 
    rst    20h             ; 000F0C E7 
    push   af              ; 000F0D F5 
    call   po,$093e        ; 000F0E E4 3E 09 
    pop    af              ; 000F11 F1 
    call   pe,$0e4d        ; 000F12 EC 4D 0E 
    pop    af              ; 000F15 F1 
    dec    a               ; 000F16 3D 
    ret                    ; 000F17 C9 
    push   de              ; 000F18 D5 
    push   hl              ; 000F19 E5 
    push   af              ; 000F1A F5 
    rst    20h             ; 000F1B E7 
    push   af              ; 000F1C F5 
    call   po,$0897        ; 000F1D E4 97 08 
    pop    af              ; 000F20 F1 
    call   pe,$0ddc        ; 000F21 EC DC 0D 
    pop    af              ; 000F24 F1 
    pop    hl              ; 000F25 E1 
    pop    de              ; 000F26 D1 
    inc    a               ; 000F27 3C 
    ret                    ; 000F28 C9 
    push   de              ; 000F29 D5 
    ld     a,b             ; 000F2A 78 
    adc    a,c             ; 000F2B 89 
    ld     b,a             ; 000F2C 47 
    push   bc              ; 000F2D C5 
    push   hl              ; 000F2E E5 
    ld     a,(hl)          ; 000F2F 7E 
    sub    $30             ; 000F30 D6 30 
    push   af              ; 000F32 F5 
    rst    20h             ; 000F33 E7 
    jp     p,$0f5d         ; 000F34 F2 5D 0F 
    ld     hl,($7921)      ; 000F37 2A 21 79 
    ld     de,$0ccd        ; 000F3A 11 CD 0C 
    rst    18h             ; 000F3D DF 
    jr     nc,$0f59        ; 000F3E 30 19 
    ld     d,h             ; 000F40 54 
    ld     e,l             ; 000F41 5D 
    add    hl,hl           ; 000F42 29 
    add    hl,hl           ; 000F43 29 
    add    hl,de           ; 000F44 19 
    add    hl,hl           ; 000F45 29 
    pop    af              ; 000F46 F1 
    ld     c,a             ; 000F47 4F 
    add    hl,bc           ; 000F48 09 
    ld     a,h             ; 000F49 7C 
    or     a               ; 000F4A B7 
    jp     m,$0f57         ; 000F4B FA 57 0F 
    ld     ($7921),hl      ; 000F4E 22 21 79 
    pop    hl              ; 000F51 E1 
    pop    bc              ; 000F52 C1 
    pop    de              ; 000F53 D1 
    jp     $0e83           ; 000F54 C3 83 0E 
    ld     a,c             ; 000F57 79 
    push   af              ; 000F58 F5 
    call   $0acc           ; 000F59 CD CC 0A 
    scf                    ; 000F5C 37 
    jr     nc,$0f77        ; 000F5D 30 18 
    ld     bc,$9474        ; 000F5F 01 74 94 
    ld     de,$2400        ; 000F62 11 00 24 
    call   $0a0c           ; 000F65 CD 0C 0A 
    jp     p,$0f74         ; 000F68 F2 74 0F 
    call   $093e           ; 000F6B CD 3E 09 
    pop    af              ; 000F6E F1 
    call   $0f89           ; 000F6F CD 89 0F 
    jr     $0f51           ; 000F72 18 DD 
    call   $0ae3           ; 000F74 CD E3 0A 
    call   $0e4d           ; 000F77 CD 4D 0E 
    call   $09fc           ; 000F7A CD FC 09 
    pop    af              ; 000F7D F1 
    call   $0964           ; 000F7E CD 64 09 
    call   $0ae3           ; 000F81 CD E3 0A 
    call   $0c77           ; 000F84 CD 77 0C 
    jr     $0f51           ; 000F87 18 C8 
    call   $09a4           ; 000F89 CD A4 09 
    call   $0964           ; 000F8C CD 64 09 
    pop    bc              ; 000F8F C1 
    pop    de              ; 000F90 D1 
    jp     $0716           ; 000F91 C3 16 07 
    ld     a,e             ; 000F94 7B 
    cp     $0a             ; 000F95 FE 0A 
    jr     nc,$0fa2        ; 000F97 30 09 
    rlca                   ; 000F99 07 
    rlca                   ; 000F9A 07 
    add    a,e             ; 000F9B 83 
    rlca                   ; 000F9C 07 
    add    a,(hl)          ; 000F9D 86 
    sub    $30             ; 000F9E D6 30 
    ld     e,a             ; 000FA0 5F 
    jp     m,$321e         ; 000FA1 FA 1E 32 
    jp     $0ebd           ; 000FA4 C3 BD 0E 
    push   hl              ; 000FA7 E5 
    ld     hl,$1924        ; 000FA8 21 24 19 
    call   $28a7           ; 000FAB CD A7 28 
    pop    hl              ; 000FAE E1 
    call   $0a9a           ; 000FAF CD 9A 0A 
    xor    a               ; 000FB2 AF 
    call   $1034           ; 000FB3 CD 34 10 
    or     (hl)            ; 000FB6 B6 
    call   $0fd9           ; 000FB7 CD D9 0F 
    jp     $28a6           ; 000FBA C3 A6 28 
    xor    a               ; 000FBD AF 
    call   $1034           ; 000FBE CD 34 10 
    and    $08             ; 000FC1 E6 08 
    jr     z,$0fc7         ; 000FC3 28 02 
    ld     (hl),$2b        ; 000FC5 36 2B 
    ex     de,hl           ; 000FC7 EB 
    call   $0994           ; 000FC8 CD 94 09 
    ex     de,hl           ; 000FCB EB 
    jp     p,$0fd9         ; 000FCC F2 D9 0F 
    ld     (hl),$2d        ; 000FCF 36 2D 
    push   bc              ; 000FD1 C5 
    push   hl              ; 000FD2 E5 
    call   $097b           ; 000FD3 CD 7B 09 
    pop    hl              ; 000FD6 E1 
    pop    bc              ; 000FD7 C1 
    or     h               ; 000FD8 B4 
    inc    hl              ; 000FD9 23 
    ld     (hl),$30        ; 000FDA 36 30 
    ld     a,($78d8)       ; 000FDC 3A D8 78 
    ld     d,a             ; 000FDF 57 
    rla                    ; 000FE0 17 
    ld     a,($78af)       ; 000FE1 3A AF 78 
    jp     c,$109a         ; 000FE4 DA 9A 10 
    jp     z,$1092         ; 000FE7 CA 92 10 
    cp     $04             ; 000FEA FE 04 
    jp     nc,$103d        ; 000FEC D2 3D 10 
    ld     bc,$0000        ; 000FEF 01 00 00 
    call   $132f           ; 000FF2 CD 2F 13 
    ld     hl,$7930        ; 000FF5 21 30 79 
    ld     b,(hl)          ; 000FF8 46 
    ld     c,$20           ; 000FF9 0E 20 
    ld     a,($78d8)       ; 000FFB 3A D8 78 
    ld     e,a             ; 000FFE 5F 
    and    $20             ; 000FFF E6 20 
    jr     z,$100a         ; 001001 28 07 
    ld     a,b             ; 001003 78 
    cp     c               ; 001004 B9 
    ld     c,$2a           ; 001005 0E 2A 
    jr     nz,$100a        ; 001007 20 01 
    ld     b,c             ; 001009 41 
    ld     (hl),c          ; 00100A 71 
    rst    10h             ; 00100B D7 
    jr     z,$1022         ; 00100C 28 14 
    cp     $45             ; 00100E FE 45 
    jr     z,$1022         ; 001010 28 10 
    cp     $44             ; 001012 FE 44 
    jr     z,$1022         ; 001014 28 0C 
    cp     $30             ; 001016 FE 30 
    jr     z,$100a         ; 001018 28 F0 
    cp     $2c             ; 00101A FE 2C 
    jr     z,$100a         ; 00101C 28 EC 
    cp     $2e             ; 00101E FE 2E 
    jr     nz,$1025        ; 001020 20 03 
    dec    hl              ; 001022 2B 
    ld     (hl),$30        ; 001023 36 30 
    ld     a,e             ; 001025 7B 
    and    $10             ; 001026 E6 10 
    jr     z,$102d         ; 001028 28 03 
    dec    hl              ; 00102A 2B 
    ld     (hl),$24        ; 00102B 36 24 
    ld     a,e             ; 00102D 7B 
    and    $04             ; 00102E E6 04 
    ret    nz              ; 001030 C0 
    dec    hl              ; 001031 2B 
    ld     (hl),b          ; 001032 70 
    ret                    ; 001033 C9 
    ld     ($78d8),a       ; 001034 32 D8 78 
    ld     hl,$7930        ; 001037 21 30 79 
    ld     (hl),$20        ; 00103A 36 20 
    ret                    ; 00103C C9 
    cp     $05             ; 00103D FE 05 
    push   hl              ; 00103F E5 
    sbc    a,$00           ; 001040 DE 00 
    rla                    ; 001042 17 
    ld     d,a             ; 001043 57 
    inc    d               ; 001044 14 
    call   $1201           ; 001045 CD 01 12 
    ld     bc,$0300        ; 001048 01 00 03 
    add    a,d             ; 00104B 82 
    jp     m,$1057         ; 00104C FA 57 10 
    inc    d               ; 00104F 14 
    cp     d               ; 001050 BA 
    jr     nc,$1057        ; 001051 30 04 
    inc    a               ; 001053 3C 
    ld     b,a             ; 001054 47 
    ld     a,$02           ; 001055 3E 02 
    sub    $02             ; 001057 D6 02 
    pop    hl              ; 001059 E1 
    push   af              ; 00105A F5 
    call   $1291           ; 00105B CD 91 12 
    ld     (hl),$30        ; 00105E 36 30 
    call   z,$09c9         ; 001060 CC C9 09 
    call   $12a4           ; 001063 CD A4 12 
    dec    hl              ; 001066 2B 
    ld     a,(hl)          ; 001067 7E 
    cp     $30             ; 001068 FE 30 
    jr     z,$1066         ; 00106A 28 FA 
    cp     $2e             ; 00106C FE 2E 
    call   nz,$09c9        ; 00106E C4 C9 09 
    pop    af              ; 001071 F1 
    jr     z,$1093         ; 001072 28 1F 
    push   af              ; 001074 F5 
    rst    20h             ; 001075 E7 
    ld     a,$22           ; 001076 3E 22 
    adc    a,a             ; 001078 8F 
    ld     (hl),a          ; 001079 77 
    inc    hl              ; 00107A 23 
    pop    af              ; 00107B F1 
    ld     (hl),$2b        ; 00107C 36 2B 
    jp     p,$1085         ; 00107E F2 85 10 
    ld     (hl),$2d        ; 001081 36 2D 
    cpl                    ; 001083 2F 
    inc    a               ; 001084 3C 
    ld     b,$2f           ; 001085 06 2F 
    inc    b               ; 001087 04 
    sub    $0a             ; 001088 D6 0A 
    jr     nc,$1087        ; 00108A 30 FB 
    add    a,$3a           ; 00108C C6 3A 
    inc    hl              ; 00108E 23 
    ld     (hl),b          ; 00108F 70 
    inc    hl              ; 001090 23 
    ld     (hl),a          ; 001091 77 
    inc    hl              ; 001092 23 
    ld     (hl),$00        ; 001093 36 00 
    ex     de,hl           ; 001095 EB 
    ld     hl,$7930        ; 001096 21 30 79 
    ret                    ; 001099 C9 
    inc    hl              ; 00109A 23 
    push   bc              ; 00109B C5 
    cp     $04             ; 00109C FE 04 
    ld     a,d             ; 00109E 7A 
    jp     nc,$1109        ; 00109F D2 09 11 
    rra                    ; 0010A2 1F 
    jp     c,$11a3         ; 0010A3 DA A3 11 
    ld     bc,$0603        ; 0010A6 01 03 06 
    call   $1289           ; 0010A9 CD 89 12 
    pop    de              ; 0010AC D1 
    ld     a,d             ; 0010AD 7A 
    sub    $05             ; 0010AE D6 05 
    call   p,$1269         ; 0010B0 F4 69 12 
    call   $132f           ; 0010B3 CD 2F 13 
    ld     a,e             ; 0010B6 7B 
    or     a               ; 0010B7 B7 
    call   z,$092f         ; 0010B8 CC 2F 09 
    dec    a               ; 0010BB 3D 
    call   p,$1269         ; 0010BC F4 69 12 
    push   hl              ; 0010BF E5 
    call   $0ff5           ; 0010C0 CD F5 0F 
    pop    hl              ; 0010C3 E1 
    jr     z,$10c8         ; 0010C4 28 02 
    ld     (hl),b          ; 0010C6 70 
    inc    hl              ; 0010C7 23 
    ld     (hl),$00        ; 0010C8 36 00 
    ld     hl,$792f        ; 0010CA 21 2F 79 
    inc    hl              ; 0010CD 23 
    ld     a,($78f3)       ; 0010CE 3A F3 78 
    sub    l               ; 0010D1 95 
    sub    d               ; 0010D2 92 
    ret    z               ; 0010D3 C8 
    ld     a,(hl)          ; 0010D4 7E 
    cp     $20             ; 0010D5 FE 20 
    jr     z,$10cd         ; 0010D7 28 F4 
    cp     $2a             ; 0010D9 FE 2A 
    jr     z,$10cd         ; 0010DB 28 F0 
    dec    hl              ; 0010DD 2B 
    push   hl              ; 0010DE E5 
    push   af              ; 0010DF F5 
    ld     bc,$10df        ; 0010E0 01 DF 10 
    push   bc              ; 0010E3 C5 
    rst    10h             ; 0010E4 D7 
    cp     $2d             ; 0010E5 FE 2D 
    ret    z               ; 0010E7 C8 
    cp     $2b             ; 0010E8 FE 2B 
    ret    z               ; 0010EA C8 
    cp     $24             ; 0010EB FE 24 
    ret    z               ; 0010ED C8 
    pop    bc              ; 0010EE C1 
    cp     $30             ; 0010EF FE 30 
    jr     nz,$1102        ; 0010F1 20 0F 
    inc    hl              ; 0010F3 23 
    rst    10h             ; 0010F4 D7 
    jr     nc,$1102        ; 0010F5 30 0B 
    dec    hl              ; 0010F7 2B 
    ld     bc,$772b        ; 0010F8 01 2B 77 
    pop    af              ; 0010FB F1 
    jr     z,$10f9         ; 0010FC 28 FB 
    pop    bc              ; 0010FE C1 
    jp     $10ce           ; 0010FF C3 CE 10 
    pop    af              ; 001102 F1 
    jr     z,$1102         ; 001103 28 FD 
    pop    hl              ; 001105 E1 
    ld     (hl),$25        ; 001106 36 25 
    ret                    ; 001108 C9 
    push   hl              ; 001109 E5 
    rra                    ; 00110A 1F 
    jp     c,$11aa         ; 00110B DA AA 11 
    jr     z,$1124         ; 00110E 28 14 
    ld     de,$1384        ; 001110 11 84 13 
    call   $0a49           ; 001113 CD 49 0A 
    ld     d,$10           ; 001116 16 10 
    jp     m,$1132         ; 001118 FA 32 11 
    pop    hl              ; 00111B E1 
    pop    bc              ; 00111C C1 
    call   $0fbd           ; 00111D CD BD 0F 
    dec    hl              ; 001120 2B 
    ld     (hl),$25        ; 001121 36 25 
    ret                    ; 001123 C9 
    ld     bc,$b60e        ; 001124 01 0E B6 
    ld     de,$1bca        ; 001127 11 CA 1B 
    call   $0a0c           ; 00112A CD 0C 0A 
    jp     p,$111b         ; 00112D F2 1B 11 
    ld     d,$06           ; 001130 16 06 
    call   $0955           ; 001132 CD 55 09 
    call   nz,$1201        ; 001135 C4 01 12 
    pop    hl              ; 001138 E1 
    pop    bc              ; 001139 C1 
    jp     m,$1157         ; 00113A FA 57 11 
    push   bc              ; 00113D C5 
    ld     e,a             ; 00113E 5F 
    ld     a,b             ; 00113F 78 
    sub    d               ; 001140 92 
    sub    e               ; 001141 93 
    call   p,$1269         ; 001142 F4 69 12 
    call   $127d           ; 001145 CD 7D 12 
    call   $12a4           ; 001148 CD A4 12 
    or     e               ; 00114B B3 
    call   nz,$1277        ; 00114C C4 77 12 
    or     e               ; 00114F B3 
    call   nz,$1291        ; 001150 C4 91 12 
    pop    de              ; 001153 D1 
    jp     $10b6           ; 001154 C3 B6 10 
    ld     e,a             ; 001157 5F 
    ld     a,c             ; 001158 79 
    or     a               ; 001159 B7 
    call   nz,$0f16        ; 00115A C4 16 0F 
    add    a,e             ; 00115D 83 
    jp     m,$1162         ; 00115E FA 62 11 
    xor    a               ; 001161 AF 
    push   bc              ; 001162 C5 
    push   af              ; 001163 F5 
    call   m,$0f18         ; 001164 FC 18 0F 
    jp     m,$1164         ; 001167 FA 64 11 
    pop    bc              ; 00116A C1 
    ld     a,e             ; 00116B 7B 
    sub    b               ; 00116C 90 
    pop    bc              ; 00116D C1 
    ld     e,a             ; 00116E 5F 
    add    a,d             ; 00116F 82 
    ld     a,b             ; 001170 78 
    jp     m,$117f         ; 001171 FA 7F 11 
    sub    d               ; 001174 92 
    sub    e               ; 001175 93 
    call   p,$1269         ; 001176 F4 69 12 
    push   bc              ; 001179 C5 
    call   $127d           ; 00117A CD 7D 12 
    jr     $1190           ; 00117D 18 11 
    call   $1269           ; 00117F CD 69 12 
    ld     a,c             ; 001182 79 
    call   $1294           ; 001183 CD 94 12 
    ld     c,a             ; 001186 4F 
    xor    a               ; 001187 AF 
    sub    d               ; 001188 92 
    sub    e               ; 001189 93 
    call   $1269           ; 00118A CD 69 12 
    push   bc              ; 00118D C5 
    ld     b,a             ; 00118E 47 
    ld     c,a             ; 00118F 4F 
    call   $12a4           ; 001190 CD A4 12 
    pop    bc              ; 001193 C1 
    or     c               ; 001194 B1 
    jr     nz,$119a        ; 001195 20 03 
    ld     hl,($78f3)      ; 001197 2A F3 78 
    add    a,e             ; 00119A 83 
    dec    a               ; 00119B 3D 
    call   p,$1269         ; 00119C F4 69 12 
    ld     d,b             ; 00119F 50 
    jp     $10bf           ; 0011A0 C3 BF 10 
    push   hl              ; 0011A3 E5 
    push   de              ; 0011A4 D5 
    call   $0acc           ; 0011A5 CD CC 0A 
    pop    de              ; 0011A8 D1 
    xor    a               ; 0011A9 AF 
    jp     z,$11b0         ; 0011AA CA B0 11 
    ld     e,$10           ; 0011AD 1E 10 
    ld     bc,$061e        ; 0011AF 01 1E 06 
    call   $0955           ; 0011B2 CD 55 09 
    scf                    ; 0011B5 37 
    call   nz,$1201        ; 0011B6 C4 01 12 
    pop    hl              ; 0011B9 E1 
    pop    bc              ; 0011BA C1 
    push   af              ; 0011BB F5 
    ld     a,c             ; 0011BC 79 
    or     a               ; 0011BD B7 
    push   af              ; 0011BE F5 
    call   nz,$0f16        ; 0011BF C4 16 0F 
    add    a,b             ; 0011C2 80 
    ld     c,a             ; 0011C3 4F 
    ld     a,d             ; 0011C4 7A 
    and    $04             ; 0011C5 E6 04 
    cp     $01             ; 0011C7 FE 01 
    sbc    a,a             ; 0011C9 9F 
    ld     d,a             ; 0011CA 57 
    add    a,c             ; 0011CB 81 
    ld     c,a             ; 0011CC 4F 
    sub    e               ; 0011CD 93 
    push   af              ; 0011CE F5 
    push   bc              ; 0011CF C5 
    call   m,$0f18         ; 0011D0 FC 18 0F 
    jp     m,$11d0         ; 0011D3 FA D0 11 
    pop    bc              ; 0011D6 C1 
    pop    af              ; 0011D7 F1 
    push   bc              ; 0011D8 C5 
    push   af              ; 0011D9 F5 
    jp     m,$11de         ; 0011DA FA DE 11 
    xor    a               ; 0011DD AF 
    cpl                    ; 0011DE 2F 
    inc    a               ; 0011DF 3C 
    add    a,b             ; 0011E0 80 
    inc    a               ; 0011E1 3C 
    add    a,d             ; 0011E2 82 
    ld     b,a             ; 0011E3 47 
    ld     c,$00           ; 0011E4 0E 00 
    call   $12a4           ; 0011E6 CD A4 12 
    pop    af              ; 0011E9 F1 
    call   p,$1271         ; 0011EA F4 71 12 
    pop    bc              ; 0011ED C1 
    pop    af              ; 0011EE F1 
    call   z,$092f         ; 0011EF CC 2F 09 
    pop    af              ; 0011F2 F1 
    jr     c,$11f8         ; 0011F3 38 03 
    add    a,e             ; 0011F5 83 
    sub    b               ; 0011F6 90 
    sub    d               ; 0011F7 92 
    push   bc              ; 0011F8 C5 
    call   $1074           ; 0011F9 CD 74 10 
    ex     de,hl           ; 0011FC EB 
    pop    de              ; 0011FD D1 
    jp     $10bf           ; 0011FE C3 BF 10 
    push   de              ; 001201 D5 
    xor    a               ; 001202 AF 
    push   af              ; 001203 F5 
    rst    20h             ; 001204 E7 
    jp     po,$1222        ; 001205 E2 22 12 
    ld     a,($7924)       ; 001208 3A 24 79 
    cp     $91             ; 00120B FE 91 
    jp     nc,$1222        ; 00120D D2 22 12 
    ld     de,$1364        ; 001210 11 64 13 
    ld     hl,$7927        ; 001213 21 27 79 
    call   $09d3           ; 001216 CD D3 09 
    call   $0da1           ; 001219 CD A1 0D 
    pop    af              ; 00121C F1 
    sub    $0a             ; 00121D D6 0A 
    push   af              ; 00121F F5 
    jr     $1208           ; 001220 18 E6 
    call   $124f           ; 001222 CD 4F 12 
    rst    20h             ; 001225 E7 
    jp     pe,$1234        ; 001226 EA 34 12 
    ld     bc,$9143        ; 001229 01 43 91 
    ld     de,$4ff9        ; 00122C 11 F9 4F 
    call   $0a0c           ; 00122F CD 0C 0A 
    jr     $123a           ; 001232 18 06 
    ld     de,$136c        ; 001234 11 6C 13 
    call   $0a49           ; 001237 CD 49 0A 
    jp     p,$124c         ; 00123A F2 4C 12 
    pop    af              ; 00123D F1 
    call   $0f0b           ; 00123E CD 0B 0F 
    push   af              ; 001241 F5 
    jr     $1225           ; 001242 18 E1 
    pop    af              ; 001244 F1 
    call   $0f18           ; 001245 CD 18 0F 
    push   af              ; 001248 F5 
    call   $124f           ; 001249 CD 4F 12 
    pop    af              ; 00124C F1 
    pop    de              ; 00124D D1 
    ret                    ; 00124E C9 
    rst    20h             ; 00124F E7 
    jp     pe,$125e        ; 001250 EA 5E 12 
    ld     bc,$9474        ; 001253 01 74 94 
    ld     de,$23f8        ; 001256 11 F8 23 
    call   $0a0c           ; 001259 CD 0C 0A 
    jr     $1264           ; 00125C 18 06 
    ld     de,$1374        ; 00125E 11 74 13 
    call   $0a49           ; 001261 CD 49 0A 
    pop    hl              ; 001264 E1 
    jp     p,$1244         ; 001265 F2 44 12 
    jp     (hl)            ; 001268 E9 
    or     a               ; 001269 B7 
    ret    z               ; 00126A C8 
    dec    a               ; 00126B 3D 
    ld     (hl),$30        ; 00126C 36 30 
    inc    hl              ; 00126E 23 
    jr     $126a           ; 00126F 18 F9 
    jr     nz,$1277        ; 001271 20 04 
    ret    z               ; 001273 C8 
    call   $1291           ; 001274 CD 91 12 
    ld     (hl),$30        ; 001277 36 30 
    inc    hl              ; 001279 23 
    dec    a               ; 00127A 3D 
    jr     $1273           ; 00127B 18 F6 
    ld     a,e             ; 00127D 7B 
    add    a,d             ; 00127E 82 
    inc    a               ; 00127F 3C 
    ld     b,a             ; 001280 47 
    inc    a               ; 001281 3C 
    sub    $03             ; 001282 D6 03 
    jr     nc,$1282        ; 001284 30 FC 
    add    a,$05           ; 001286 C6 05 
    ld     c,a             ; 001288 4F 
    ld     a,($78d8)       ; 001289 3A D8 78 
    and    $40             ; 00128C E6 40 
    ret    nz              ; 00128E C0 
    ld     c,a             ; 00128F 4F 
    ret                    ; 001290 C9 
    dec    b               ; 001291 05 
    jr     nz,$129c        ; 001292 20 08 
    ld     (hl),$2e        ; 001294 36 2E 
    ld     ($78f3),hl      ; 001296 22 F3 78 
    inc    hl              ; 001299 23 
    ld     c,b             ; 00129A 48 
    ret                    ; 00129B C9 
    dec    c               ; 00129C 0D 
    ret    nz              ; 00129D C0 
    ld     (hl),$2c        ; 00129E 36 2C 
    inc    hl              ; 0012A0 23 
    ld     c,$03           ; 0012A1 0E 03 
    ret                    ; 0012A3 C9 
    push   de              ; 0012A4 D5 
    rst    20h             ; 0012A5 E7 
    jp     po,$12ea        ; 0012A6 E2 EA 12 
    push   bc              ; 0012A9 C5 
    push   hl              ; 0012AA E5 
    call   $09fc           ; 0012AB CD FC 09 
    ld     hl,$137c        ; 0012AE 21 7C 13 
    call   $09f7           ; 0012B1 CD F7 09 
    call   $0c77           ; 0012B4 CD 77 0C 
    xor    a               ; 0012B7 AF 
    call   $0b7b           ; 0012B8 CD 7B 0B 
    pop    hl              ; 0012BB E1 
    pop    bc              ; 0012BC C1 
    ld     de,$138c        ; 0012BD 11 8C 13 
    ld     a,$0a           ; 0012C0 3E 0A 
    call   $1291           ; 0012C2 CD 91 12 
    push   bc              ; 0012C5 C5 
    push   af              ; 0012C6 F5 
    push   hl              ; 0012C7 E5 
    push   de              ; 0012C8 D5 
    ld     b,$2f           ; 0012C9 06 2F 
    inc    b               ; 0012CB 04 
    pop    hl              ; 0012CC E1 
    push   hl              ; 0012CD E5 
    call   $0d48           ; 0012CE CD 48 0D 
    jr     nc,$12cb        ; 0012D1 30 F8 
    pop    hl              ; 0012D3 E1 
    call   $0d36           ; 0012D4 CD 36 0D 
    ex     de,hl           ; 0012D7 EB 
    pop    hl              ; 0012D8 E1 
    ld     (hl),b          ; 0012D9 70 
    inc    hl              ; 0012DA 23 
    pop    af              ; 0012DB F1 
    pop    bc              ; 0012DC C1 
    dec    a               ; 0012DD 3D 
    jr     nz,$12c2        ; 0012DE 20 E2 
    push   bc              ; 0012E0 C5 
    push   hl              ; 0012E1 E5 
    ld     hl,$791d        ; 0012E2 21 1D 79 
    call   $09b1           ; 0012E5 CD B1 09 
    jr     $12f6           ; 0012E8 18 0C 
    push   bc              ; 0012EA C5 
    push   hl              ; 0012EB E5 
    call   $0708           ; 0012EC CD 08 07 
    inc    a               ; 0012EF 3C 
    call   $0afb           ; 0012F0 CD FB 0A 
    call   $09b4           ; 0012F3 CD B4 09 
    pop    hl              ; 0012F6 E1 
    pop    bc              ; 0012F7 C1 
    xor    a               ; 0012F8 AF 
    ld     de,$13d2        ; 0012F9 11 D2 13 
    ccf                    ; 0012FC 3F 
    call   $1291           ; 0012FD CD 91 12 
    push   bc              ; 001300 C5 
    push   af              ; 001301 F5 
    push   hl              ; 001302 E5 
    push   de              ; 001303 D5 
    call   $09bf           ; 001304 CD BF 09 
    pop    hl              ; 001307 E1 
    ld     b,$2f           ; 001308 06 2F 
    inc    b               ; 00130A 04 
    ld     a,e             ; 00130B 7B 
    sub    (hl)            ; 00130C 96 
    ld     e,a             ; 00130D 5F 
    inc    hl              ; 00130E 23 
    ld     a,d             ; 00130F 7A 
    sbc    a,(hl)          ; 001310 9E 
    ld     d,a             ; 001311 57 
    inc    hl              ; 001312 23 
    ld     a,c             ; 001313 79 
    sbc    a,(hl)          ; 001314 9E 
    ld     c,a             ; 001315 4F 
    dec    hl              ; 001316 2B 
    dec    hl              ; 001317 2B 
    jr     nc,$130a        ; 001318 30 F0 
    call   $07b7           ; 00131A CD B7 07 
    inc    hl              ; 00131D 23 
    call   $09b4           ; 00131E CD B4 09 
    ex     de,hl           ; 001321 EB 
    pop    hl              ; 001322 E1 
    ld     (hl),b          ; 001323 70 
    inc    hl              ; 001324 23 
    pop    af              ; 001325 F1 
    pop    bc              ; 001326 C1 
    jr     c,$12fc         ; 001327 38 D3 
    inc    de              ; 001329 13 
    inc    de              ; 00132A 13 
    ld     a,$04           ; 00132B 3E 04 
    jr     $1335           ; 00132D 18 06 
    push   de              ; 00132F D5 
    ld     de,$13d8        ; 001330 11 D8 13 
    ld     a,$05           ; 001333 3E 05 
    call   $1291           ; 001335 CD 91 12 
    push   bc              ; 001338 C5 
    push   af              ; 001339 F5 
    push   hl              ; 00133A E5 
    ex     de,hl           ; 00133B EB 
    ld     c,(hl)          ; 00133C 4E 
    inc    hl              ; 00133D 23 
    ld     b,(hl)          ; 00133E 46 
    push   bc              ; 00133F C5 
    inc    hl              ; 001340 23 
    ex     (sp),hl         ; 001341 E3 
    ex     de,hl           ; 001342 EB 
    ld     hl,($7921)      ; 001343 2A 21 79 
    ld     b,$2f           ; 001346 06 2F 
    inc    b               ; 001348 04 
    ld     a,l             ; 001349 7D 
    sub    e               ; 00134A 93 
    ld     l,a             ; 00134B 6F 
    ld     a,h             ; 00134C 7C 
    sbc    a,d             ; 00134D 9A 
    ld     h,a             ; 00134E 67 
    jr     nc,$1348        ; 00134F 30 F7 
    add    hl,de           ; 001351 19 
    ld     ($7921),hl      ; 001352 22 21 79 
    pop    de              ; 001355 D1 
    pop    hl              ; 001356 E1 
    ld     (hl),b          ; 001357 70 
    inc    hl              ; 001358 23 
    pop    af              ; 001359 F1 
    pop    bc              ; 00135A C1 
    dec    a               ; 00135B 3D 
    jr     nz,$1335        ; 00135C 20 D7 
    call   $1291           ; 00135E CD 91 12 
    ld     (hl),a          ; 001361 77 
    pop    de              ; 001362 D1 
    ret                    ; 001363 C9 
    nop                    ; 001364 00 
    nop                    ; 001365 00 
    nop                    ; 001366 00 
    nop                    ; 001367 00 
    ld     sp,hl           ; 001368 F9 
    ld     (bc),a          ; 001369 02 
    dec    d               ; 00136A 15 
    and    d               ; 00136B A2 
    db     $fd             ; 00136C FD 
    rst    38h             ; 00136D FF 
    sbc    a,a             ; 00136E 9F 
    ld     sp,$5fa9        ; 00136F 31 A9 5F 
    ld     h,e             ; 001372 63 
    or     d               ; 001373 B2 
    cp     $ff             ; 001374 FE FF 
    inc    bc              ; 001376 03 
    cp     a               ; 001377 BF 
    ret                    ; 001378 C9 
    dec    de              ; 001379 1B 
    ld     c,$b6           ; 00137A 0E B6 
    nop                    ; 00137C 00 
    nop                    ; 00137D 00 
    nop                    ; 00137E 00 
    nop                    ; 00137F 00 
    nop                    ; 001380 00 
    nop                    ; 001381 00 
    nop                    ; 001382 00 
    add    a,b             ; 001383 80 
    nop                    ; 001384 00 
    nop                    ; 001385 00 
    inc    b               ; 001386 04 
    cp     a               ; 001387 BF 
    ret                    ; 001388 C9 
    dec    de              ; 001389 1B 
    ld     c,$b6           ; 00138A 0E B6 
    nop                    ; 00138C 00 
    add    a,b             ; 00138D 80 
    add    a,$a4           ; 00138E C6 A4 
    ld     a,(hl)          ; 001390 7E 
    adc    a,l             ; 001391 8D 
    inc    bc              ; 001392 03 
    nop                    ; 001393 00 
    ld     b,b             ; 001394 40 
    ld     a,d             ; 001395 7A 
    djnz   $138b           ; 001396 10 F3 
    ld     e,d             ; 001398 5A 
    nop                    ; 001399 00 
    nop                    ; 00139A 00 
    and    b               ; 00139B A0 
    ld     (hl),d          ; 00139C 72 
    ld     c,(hl)          ; 00139D 4E 
    jr     $13a9           ; 00139E 18 09 
    nop                    ; 0013A0 00 
    nop                    ; 0013A1 00 
    djnz   $1349           ; 0013A2 10 A5 
    call   nc,$00e8        ; 0013A4 D4 E8 00 
    nop                    ; 0013A7 00 
    nop                    ; 0013A8 00 
    ret    pe              ; 0013A9 E8 
    halt                   ; 0013AA 76 
    ld     c,b             ; 0013AB 48 
    rla                    ; 0013AC 17 
    nop                    ; 0013AD 00 
    nop                    ; 0013AE 00 
    nop                    ; 0013AF 00 
    call   po,$540b        ; 0013B0 E4 0B 54 
    ld     (bc),a          ; 0013B3 02 
    nop                    ; 0013B4 00 
    nop                    ; 0013B5 00 
    nop                    ; 0013B6 00 
    jp     z,$3b9a         ; 0013B7 CA 9A 3B 
    nop                    ; 0013BA 00 
    nop                    ; 0013BB 00 
    nop                    ; 0013BC 00 
    nop                    ; 0013BD 00 
    pop    hl              ; 0013BE E1 
    push   af              ; 0013BF F5 
    dec    b               ; 0013C0 05 
    nop                    ; 0013C1 00 
    nop                    ; 0013C2 00 
    nop                    ; 0013C3 00 
    add    a,b             ; 0013C4 80 
    sub    (hl)            ; 0013C5 96 
    sbc    a,b             ; 0013C6 98 
    nop                    ; 0013C7 00 
    nop                    ; 0013C8 00 
    nop                    ; 0013C9 00 
    nop                    ; 0013CA 00 
    ld     b,b             ; 0013CB 40 
    ld     b,d             ; 0013CC 42 
    rrca                   ; 0013CD 0F 
    nop                    ; 0013CE 00 
    nop                    ; 0013CF 00 
    nop                    ; 0013D0 00 
    nop                    ; 0013D1 00 
    and    b               ; 0013D2 A0 
    add    a,(hl)          ; 0013D3 86 
    ld     bc,$2710        ; 0013D4 01 10 27 
    nop                    ; 0013D7 00 
    djnz   $1401           ; 0013D8 10 27 
    ret    pe              ; 0013DA E8 
    inc    bc              ; 0013DB 03 
    ld     h,h             ; 0013DC 64 
    nop                    ; 0013DD 00 
    ld     a,(bc)          ; 0013DE 0A 
    nop                    ; 0013DF 00 
    ld     bc,$2100        ; 0013E0 01 00 21 
    add    a,d             ; 0013E3 82 
    add    hl,bc           ; 0013E4 09 
    ex     (sp),hl         ; 0013E5 E3 
    jp     (hl)            ; 0013E6 E9 
    call   $09a4           ; 0013E7 CD A4 09 
    ld     hl,$1380        ; 0013EA 21 80 13 
    call   $09b1           ; 0013ED CD B1 09 
    jr     $13f5           ; 0013F0 18 03 
    call   $0ab1           ; 0013F2 CD B1 0A 
    pop    bc              ; 0013F5 C1 
    pop    de              ; 0013F6 D1 
    call   $0955           ; 0013F7 CD 55 09 
    ld     a,b             ; 0013FA 78 
    jr     z,$1439         ; 0013FB 28 3C 
    jp     p,$1404         ; 0013FD F2 04 14 
    or     a               ; 001400 B7 
    jp     z,$199a         ; 001401 CA 9A 19 
    or     a               ; 001404 B7 
    jp     z,$0779         ; 001405 CA 79 07 
    push   de              ; 001408 D5 
    push   bc              ; 001409 C5 
    ld     a,c             ; 00140A 79 
    or     $7f             ; 00140B F6 7F 
    call   $09bf           ; 00140D CD BF 09 
    jp     p,$1421         ; 001410 F2 21 14 
    push   de              ; 001413 D5 
    push   bc              ; 001414 C5 
    call   $0b40           ; 001415 CD 40 0B 
    pop    bc              ; 001418 C1 
    pop    de              ; 001419 D1 
    push   af              ; 00141A F5 
    call   $0a0c           ; 00141B CD 0C 0A 
    pop    hl              ; 00141E E1 
    ld     a,h             ; 00141F 7C 
    rra                    ; 001420 1F 
    pop    hl              ; 001421 E1 
    ld     ($7923),hl      ; 001422 22 23 79 
    pop    hl              ; 001425 E1 
    ld     ($7921),hl      ; 001426 22 21 79 
    call   c,$13e2         ; 001429 DC E2 13 
    call   z,$0982         ; 00142C CC 82 09 
    push   de              ; 00142F D5 
    push   bc              ; 001430 C5 
    call   $0809           ; 001431 CD 09 08 
    pop    bc              ; 001434 C1 
    pop    de              ; 001435 D1 
    call   $0847           ; 001436 CD 47 08 
    call   $09a4           ; 001439 CD A4 09 
    ld     bc,$8138        ; 00143C 01 38 81 
    ld     de,$aa3b        ; 00143F 11 3B AA 
    call   $0847           ; 001442 CD 47 08 
    ld     a,($7924)       ; 001445 3A 24 79 
    cp     $88             ; 001448 FE 88 
    jp     nc,$0931        ; 00144A D2 31 09 
    call   $0b40           ; 00144D CD 40 0B 
    add    a,$80           ; 001450 C6 80 
    add    a,$02           ; 001452 C6 02 
    jp     c,$0931         ; 001454 DA 31 09 
    push   af              ; 001457 F5 
    ld     hl,$07f8        ; 001458 21 F8 07 
    call   $070b           ; 00145B CD 0B 07 
    call   $0841           ; 00145E CD 41 08 
    pop    af              ; 001461 F1 
    pop    bc              ; 001462 C1 
    pop    de              ; 001463 D1 
    push   af              ; 001464 F5 
    call   $0713           ; 001465 CD 13 07 
    call   $0982           ; 001468 CD 82 09 
    ld     hl,$1479        ; 00146B 21 79 14 
    call   $14a9           ; 00146E CD A9 14 
    ld     de,$0000        ; 001471 11 00 00 
    pop    bc              ; 001474 C1 
    ld     c,d             ; 001475 4A 
    jp     $0847           ; 001476 C3 47 08 
    ex     af,af'          ; 001479 08 
    ld     b,b             ; 00147A 40 
    ld     l,$94           ; 00147B 2E 94 
    ld     (hl),h          ; 00147D 74 
    ld     (hl),b          ; 00147E 70 
    ld     c,a             ; 00147F 4F 
    ld     l,$77           ; 001480 2E 77 
    ld     l,(hl)          ; 001482 6E 
    ld     (bc),a          ; 001483 02 
    adc    a,b             ; 001484 88 
    ld     a,d             ; 001485 7A 
    and    $a0             ; 001486 E6 A0 
    ld     hl,($507c)      ; 001488 2A 7C 50 
    xor    d               ; 00148B AA 
    xor    d               ; 00148C AA 
    ld     a,(hl)          ; 00148D 7E 
    rst    38h             ; 00148E FF 
    rst    38h             ; 00148F FF 
    ld     a,a             ; 001490 7F 
    ld     a,a             ; 001491 7F 
    nop                    ; 001492 00 
    nop                    ; 001493 00 
    add    a,b             ; 001494 80 
    add    a,c             ; 001495 81 
    nop                    ; 001496 00 
    nop                    ; 001497 00 
    nop                    ; 001498 00 
    add    a,c             ; 001499 81 
    call   $09a4           ; 00149A CD A4 09 
    ld     de,$0c32        ; 00149D 11 32 0C 
    push   de              ; 0014A0 D5 
    push   hl              ; 0014A1 E5 
    call   $09bf           ; 0014A2 CD BF 09 
    call   $0847           ; 0014A5 CD 47 08 
    pop    hl              ; 0014A8 E1 
    call   $09a4           ; 0014A9 CD A4 09 
    ld     a,(hl)          ; 0014AC 7E 
    inc    hl              ; 0014AD 23 
    call   $09b1           ; 0014AE CD B1 09 
    ld     b,$f1           ; 0014B1 06 F1 
    pop    bc              ; 0014B3 C1 
    pop    de              ; 0014B4 D1 
    dec    a               ; 0014B5 3D 
    ret    z               ; 0014B6 C8 
    push   de              ; 0014B7 D5 
    push   bc              ; 0014B8 C5 
    push   af              ; 0014B9 F5 
    push   hl              ; 0014BA E5 
    call   $0847           ; 0014BB CD 47 08 
    pop    hl              ; 0014BE E1 
    call   $09c2           ; 0014BF CD C2 09 
    push   hl              ; 0014C2 E5 
    call   $0716           ; 0014C3 CD 16 07 
    pop    hl              ; 0014C6 E1 
    jr     $14b2           ; 0014C7 18 E9 
    call   $0a7f           ; 0014C9 CD 7F 0A 
    ld     a,h             ; 0014CC 7C 
    or     a               ; 0014CD B7 
    jp     m,$1e4a         ; 0014CE FA 4A 1E 
    or     l               ; 0014D1 B5 
    jp     z,$14f0         ; 0014D2 CA F0 14 
    push   hl              ; 0014D5 E5 
    call   $14f0           ; 0014D6 CD F0 14 
    call   $09bf           ; 0014D9 CD BF 09 
    ex     de,hl           ; 0014DC EB 
    ex     (sp),hl         ; 0014DD E3 
    push   bc              ; 0014DE C5 
    call   $0acf           ; 0014DF CD CF 0A 
    pop    bc              ; 0014E2 C1 
    pop    de              ; 0014E3 D1 
    call   $0847           ; 0014E4 CD 47 08 
    ld     hl,$07f8        ; 0014E7 21 F8 07 
    call   $070b           ; 0014EA CD 0B 07 
    jp     $0b40           ; 0014ED C3 40 0B 
    ld     hl,$7890        ; 0014F0 21 90 78 
    push   hl              ; 0014F3 E5 
    ld     de,$0000        ; 0014F4 11 00 00 
    ld     c,e             ; 0014F7 4B 
    ld     h,$03           ; 0014F8 26 03 
    ld     l,$08           ; 0014FA 2E 08 
    ex     de,hl           ; 0014FC EB 
    add    hl,hl           ; 0014FD 29 
    ex     de,hl           ; 0014FE EB 
    ld     a,c             ; 0014FF 79 
    rla                    ; 001500 17 
    ld     c,a             ; 001501 4F 
    ex     (sp),hl         ; 001502 E3 
    ld     a,(hl)          ; 001503 7E 
    rlca                   ; 001504 07 
    ld     (hl),a          ; 001505 77 
    ex     (sp),hl         ; 001506 E3 
    jp     nc,$1516        ; 001507 D2 16 15 
    push   hl              ; 00150A E5 
    ld     hl,($78aa)      ; 00150B 2A AA 78 
    add    hl,de           ; 00150E 19 
    ex     de,hl           ; 00150F EB 
    ld     a,($78ac)       ; 001510 3A AC 78 
    adc    a,c             ; 001513 89 
    ld     c,a             ; 001514 4F 
    pop    hl              ; 001515 E1 
    dec    l               ; 001516 2D 
    jp     nz,$14fc        ; 001517 C2 FC 14 
    ex     (sp),hl         ; 00151A E3 
    inc    hl              ; 00151B 23 
    ex     (sp),hl         ; 00151C E3 
    dec    h               ; 00151D 25 
    jp     nz,$14fa        ; 00151E C2 FA 14 
    pop    hl              ; 001521 E1 
    ld     hl,$b065        ; 001522 21 65 B0 
    add    hl,de           ; 001525 19 
    ld     ($78aa),hl      ; 001526 22 AA 78 
    call   $0aef           ; 001529 CD EF 0A 
    ld     a,$05           ; 00152C 3E 05 
    adc    a,c             ; 00152E 89 
    ld     ($78ac),a       ; 00152F 32 AC 78 
    ex     de,hl           ; 001532 EB 
    ld     b,$80           ; 001533 06 80 
    ld     hl,$7925        ; 001535 21 25 79 
    ld     (hl),b          ; 001538 70 
    dec    hl              ; 001539 2B 
    ld     (hl),b          ; 00153A 70 
    ld     c,a             ; 00153B 4F 
    ld     b,$00           ; 00153C 06 00 
    jp     $0765           ; 00153E C3 65 07 
    ld     hl,$158b        ; 001541 21 8B 15 
    call   $070b           ; 001544 CD 0B 07 
    call   $09a4           ; 001547 CD A4 09 
    ld     bc,$8349        ; 00154A 01 49 83 
    ld     de,$0fdb        ; 00154D 11 DB 0F 
    call   $09b4           ; 001550 CD B4 09 
    pop    bc              ; 001553 C1 
    pop    de              ; 001554 D1 
    call   $08a2           ; 001555 CD A2 08 
    call   $09a4           ; 001558 CD A4 09 
    call   $0b40           ; 00155B CD 40 0B 
    pop    bc              ; 00155E C1 
    pop    de              ; 00155F D1 
    call   $0713           ; 001560 CD 13 07 
    ld     hl,$158f        ; 001563 21 8F 15 
    call   $0710           ; 001566 CD 10 07 
    call   $0955           ; 001569 CD 55 09 
    scf                    ; 00156C 37 
    jp     p,$1577         ; 00156D F2 77 15 
    call   $0708           ; 001570 CD 08 07 
    call   $0955           ; 001573 CD 55 09 
    or     a               ; 001576 B7 
    push   af              ; 001577 F5 
    call   p,$0982         ; 001578 F4 82 09 
    ld     hl,$158f        ; 00157B 21 8F 15 
    call   $070b           ; 00157E CD 0B 07 
    pop    af              ; 001581 F1 
    call   nc,$0982        ; 001582 D4 82 09 
    ld     hl,$1593        ; 001585 21 93 15 
    jp     $149a           ; 001588 C3 9A 14 
    in     a,($0f)         ; 00158B DB 0F 
    ld     c,c             ; 00158D 49 
    add    a,c             ; 00158E 81 
    nop                    ; 00158F 00 
    nop                    ; 001590 00 
    nop                    ; 001591 00 
    ld     a,a             ; 001592 7F 
    dec    b               ; 001593 05 
    cp     d               ; 001594 BA 
    rst    10h             ; 001595 D7 
    ld     e,$86           ; 001596 1E 86 
    ld     h,h             ; 001598 64 
    ld     h,$99           ; 001599 26 99 
    add    a,a             ; 00159B 87 
    ld     e,b             ; 00159C 58 
    inc    (hl)            ; 00159D 34 
    inc    hl              ; 00159E 23 
    add    a,a             ; 00159F 87 
    ret    po              ; 0015A0 E0 
    ld     e,l             ; 0015A1 5D 
    and    l               ; 0015A2 A5 
    add    a,(hl)          ; 0015A3 86 
    jp     c,$490f         ; 0015A4 DA 0F 49 
    add    a,e             ; 0015A7 83 
    call   $09a4           ; 0015A8 CD A4 09 
    call   $1547           ; 0015AB CD 47 15 
    pop    bc              ; 0015AE C1 
    pop    hl              ; 0015AF E1 
    call   $09a4           ; 0015B0 CD A4 09 
    ex     de,hl           ; 0015B3 EB 
    call   $09b4           ; 0015B4 CD B4 09 
    call   $1541           ; 0015B7 CD 41 15 
    jp     $08a0           ; 0015BA C3 A0 08 
    call   $0955           ; 0015BD CD 55 09 
    call   m,$13e2         ; 0015C0 FC E2 13 
    call   m,$0982         ; 0015C3 FC 82 09 
    ld     a,($7924)       ; 0015C6 3A 24 79 
    cp     $81             ; 0015C9 FE 81 
    jr     c,$15d9         ; 0015CB 38 0C 
    ld     bc,$8100        ; 0015CD 01 00 81 
    ld     d,c             ; 0015D0 51 
    ld     e,c             ; 0015D1 59 
    call   $08a2           ; 0015D2 CD A2 08 
    ld     hl,$0710        ; 0015D5 21 10 07 
    push   hl              ; 0015D8 E5 
    ld     hl,$15e3        ; 0015D9 21 E3 15 
    call   $149a           ; 0015DC CD 9A 14 
    ld     hl,$158b        ; 0015DF 21 8B 15 
    ret                    ; 0015E2 C9 
    add    hl,bc           ; 0015E3 09 
    ld     c,d             ; 0015E4 4A 
    rst    10h             ; 0015E5 D7 
    dec    sp              ; 0015E6 3B 
    ld     a,b             ; 0015E7 78 
    ld     (bc),a          ; 0015E8 02 
    ld     l,(hl)          ; 0015E9 6E 
    add    a,h             ; 0015EA 84 
    ld     a,e             ; 0015EB 7B 
    cp     $c1             ; 0015EC FE C1 
    cpl                    ; 0015EE 2F 
    ld     a,h             ; 0015EF 7C 
    ld     (hl),h          ; 0015F0 74 
    ld     sp,$7d9a        ; 0015F1 31 9A 7D 
    add    a,h             ; 0015F4 84 
    dec    a               ; 0015F5 3D 
    ld     e,d             ; 0015F6 5A 
    ld     a,l             ; 0015F7 7D 
    ret    z               ; 0015F8 C8 
    ld     a,a             ; 0015F9 7F 
    sub    c               ; 0015FA 91 
    ld     a,(hl)          ; 0015FB 7E 
    call   po,$4cbb        ; 0015FC E4 BB 4C 
    ld     a,(hl)          ; 0015FF 7E 
    ld     l,h             ; 001600 6C 
    xor    d               ; 001601 AA 
    xor    d               ; 001602 AA 
    ld     a,a             ; 001603 7F 
    nop                    ; 001604 00 
    nop                    ; 001605 00 
    nop                    ; 001606 00 
    add    a,c             ; 001607 81 
    adc    a,d             ; 001608 8A 
    add    hl,bc           ; 001609 09 
    scf                    ; 00160A 37 
    dec    bc              ; 00160B 0B 
    ld     (hl),a          ; 00160C 77 
    add    hl,bc           ; 00160D 09 
    call   nc,$ef27        ; 00160E D4 27 EF 
    ld     hl,($27f5)      ; 001611 2A F5 27 
    rst    20h             ; 001614 E7 
    inc    de              ; 001615 13 
    ret                    ; 001616 C9 
    inc    d               ; 001617 14 
    add    hl,bc           ; 001618 09 
    ex     af,af'          ; 001619 08 
    add    hl,sp           ; 00161A 39 
    inc    d               ; 00161B 14 
    ld     b,c             ; 00161C 41 
    dec    d               ; 00161D 15 
    ld     b,a             ; 00161E 47 
    dec    d               ; 00161F 15 
    xor    b               ; 001620 A8 
    dec    d               ; 001621 15 
    cp     l               ; 001622 BD 
    dec    d               ; 001623 15 
    xor    d               ; 001624 AA 
    inc    l               ; 001625 2C 
    ld     d,d             ; 001626 52 
    ld     a,c             ; 001627 79 
    ld     e,b             ; 001628 58 
    ld     a,c             ; 001629 79 
    ld     e,(hl)          ; 00162A 5E 
    ld     a,c             ; 00162B 79 
    ld     h,c             ; 00162C 61 
    ld     a,c             ; 00162D 79 
    ld     h,h             ; 00162E 64 
    ld     a,c             ; 00162F 79 
    ld     h,a             ; 001630 67 
    ld     a,c             ; 001631 79 
    ld     l,d             ; 001632 6A 
    ld     a,c             ; 001633 79 
    ld     l,l             ; 001634 6D 
    ld     a,c             ; 001635 79 
    ld     (hl),b          ; 001636 70 
    ld     a,c             ; 001637 79 
    ld     a,a             ; 001638 7F 
    ld     a,(bc)          ; 001639 0A 
    or     c               ; 00163A B1 
    ld     a,(bc)          ; 00163B 0A 
    in     a,($0a)         ; 00163C DB 0A 
    ld     h,$0b           ; 00163E 26 0B 
    inc    bc              ; 001640 03 
    ld     hl,($2836)      ; 001641 2A 36 28 
    push   bc              ; 001644 C5 
    ld     hl,($2a0f)      ; 001645 2A 0F 2A 
    rra                    ; 001648 1F 
    ld     hl,($2a61)      ; 001649 2A 61 2A 
    sub    c               ; 00164C 91 
    ld     hl,($2a9a)      ; 00164D 2A 9A 2A 
    push   bc              ; 001650 C5 
    ld     c,(hl)          ; 001651 4E 
    ld     b,h             ; 001652 44 
    add    a,$4f           ; 001653 C6 4F 
    ld     d,d             ; 001655 52 
    jp     nc,$5345        ; 001656 D2 45 53 
    ld     b,l             ; 001659 45 
    ld     d,h             ; 00165A 54 
    out    ($45),a         ; 00165B D3 45 
    ld     d,h             ; 00165D 54 
    jp     $534c           ; 00165E C3 4C 53 
    add    a,c             ; 001661 81 
    nop                    ; 001662 00 
    nop                    ; 001663 00 
    add    a,c             ; 001664 81 
    nop                    ; 001665 00 
    nop                    ; 001666 00 
    nop                    ; 001667 00 
    nop                    ; 001668 00 
    nop                    ; 001669 00 
    adc    a,$45           ; 00166A CE 45 
    ld     e,b             ; 00166C 58 
    ld     d,h             ; 00166D 54 
    call   nz,$5441        ; 00166E C4 41 54 
    ld     b,c             ; 001671 41 
    ret                    ; 001672 C9 
    ld     c,(hl)          ; 001673 4E 
    ld     d,b             ; 001674 50 
    ld     d,l             ; 001675 55 
    ld     d,h             ; 001676 54 
    call   nz,$4d49        ; 001677 C4 49 4D 
    jp     nc,$4145        ; 00167A D2 45 41 
    ld     b,h             ; 00167D 44 
    call   z,$5445         ; 00167E CC 45 54 
    rst    00h             ; 001681 C7 
    ld     c,a             ; 001682 4F 
    ld     d,h             ; 001683 54 
    ld     c,a             ; 001684 4F 
    jp     nc,$4e55        ; 001685 D2 55 4E 
    ret                    ; 001688 C9 
    ld     b,(hl)          ; 001689 46 
    jp     nc,$5345        ; 00168A D2 45 53 
    ld     d,h             ; 00168D 54 
    ld     c,a             ; 00168E 4F 
    ld     d,d             ; 00168F 52 
    ld     b,l             ; 001690 45 
    rst    00h             ; 001691 C7 
    ld     c,a             ; 001692 4F 
    ld     d,e             ; 001693 53 
    ld     d,l             ; 001694 55 
    ld     b,d             ; 001695 42 
    jp     nc,$5445        ; 001696 D2 45 54 
    ld     d,l             ; 001699 55 
    ld     d,d             ; 00169A 52 
    ld     c,(hl)          ; 00169B 4E 
    jp     nc,$4d45        ; 00169C D2 45 4D 
    out    ($54),a         ; 00169F D3 54 
    ld     c,a             ; 0016A1 4F 
    ld     d,b             ; 0016A2 50 
    push   bc              ; 0016A3 C5 
    ld     c,h             ; 0016A4 4C 
    ld     d,e             ; 0016A5 53 
    ld     b,l             ; 0016A6 45 
    jp     $504f           ; 0016A7 C3 4F 50 
    ld     e,c             ; 0016AA 59 
    jp     $4c4f           ; 0016AB C3 4F 4C 
    ld     c,a             ; 0016AE 4F 
    ld     d,d             ; 0016AF 52 
    sub    $45             ; 0016B0 D6 45 
    ld     d,d             ; 0016B2 52 
    ld     c,c             ; 0016B3 49 
    ld     b,(hl)          ; 0016B4 46 
    ld     e,c             ; 0016B5 59 
    add    a,c             ; 0016B6 81 
    nop                    ; 0016B7 00 
    nop                    ; 0016B8 00 
    nop                    ; 0016B9 00 
    nop                    ; 0016BA 00 
    nop                    ; 0016BB 00 
    add    a,c             ; 0016BC 81 
    nop                    ; 0016BD 00 
    nop                    ; 0016BE 00 
    nop                    ; 0016BF 00 
    nop                    ; 0016C0 00 
    nop                    ; 0016C1 00 
    add    a,c             ; 0016C2 81 
    nop                    ; 0016C3 00 
    nop                    ; 0016C4 00 
    nop                    ; 0016C5 00 
    nop                    ; 0016C6 00 
    nop                    ; 0016C7 00 
    jp     $5552           ; 0016C8 C3 52 55 
    ld     c,(hl)          ; 0016CB 4E 
    call   $444f           ; 0016CC CD 4F 44 
    ld     b,l             ; 0016CF 45 
    out    ($4f),a         ; 0016D0 D3 4F 
    ld     d,l             ; 0016D2 55 
    ld     c,(hl)          ; 0016D3 4E 
    ld     b,h             ; 0016D4 44 
    add    a,c             ; 0016D5 81 
    nop                    ; 0016D6 00 
    nop                    ; 0016D7 00 
    nop                    ; 0016D8 00 
    nop                    ; 0016D9 00 
    nop                    ; 0016DA 00 
    rst    08h             ; 0016DB CF 
    ld     d,l             ; 0016DC 55 
    ld     d,h             ; 0016DD 54 
    add    a,c             ; 0016DE 81 
    nop                    ; 0016DF 00 
    add    a,c             ; 0016E0 81 
    nop                    ; 0016E1 00 
    nop                    ; 0016E2 00 
    nop                    ; 0016E3 00 
    add    a,c             ; 0016E4 81 
    nop                    ; 0016E5 00 
    nop                    ; 0016E6 00 
    nop                    ; 0016E7 00 
    nop                    ; 0016E8 00 
    add    a,c             ; 0016E9 81 
    nop                    ; 0016EA 00 
    nop                    ; 0016EB 00 
    add    a,c             ; 0016EC 81 
    nop                    ; 0016ED 00 
    nop                    ; 0016EE 00 
    add    a,c             ; 0016EF 81 
    nop                    ; 0016F0 00 
    nop                    ; 0016F1 00 
    nop                    ; 0016F2 00 
    nop                    ; 0016F3 00 
    add    a,c             ; 0016F4 81 
    nop                    ; 0016F5 00 
    nop                    ; 0016F6 00 
    nop                    ; 0016F7 00 
    add    a,c             ; 0016F8 81 
    nop                    ; 0016F9 00 
    nop                    ; 0016FA 00 
    nop                    ; 0016FB 00 
    nop                    ; 0016FC 00 
    add    a,c             ; 0016FD 81 
    nop                    ; 0016FE 00 
    nop                    ; 0016FF 00 
    nop                    ; 001700 00 
    add    a,c             ; 001701 81 
    nop                    ; 001702 00 
    nop                    ; 001703 00 
    nop                    ; 001704 00 
    add    a,c             ; 001705 81 
    nop                    ; 001706 00 
    nop                    ; 001707 00 
    nop                    ; 001708 00 
    add    a,c             ; 001709 81 
    nop                    ; 00170A 00 
    nop                    ; 00170B 00 
    nop                    ; 00170C 00 
    add    a,c             ; 00170D 81 
    nop                    ; 00170E 00 
    nop                    ; 00170F 00 
    nop                    ; 001710 00 
    add    a,c             ; 001711 81 
    nop                    ; 001712 00 
    nop                    ; 001713 00 
    nop                    ; 001714 00 
    nop                    ; 001715 00 
    nop                    ; 001716 00 
    call   z,$5250         ; 001717 CC 50 52 
    ld     c,c             ; 00171A 49 
    ld     c,(hl)          ; 00171B 4E 
    ld     d,h             ; 00171C 54 
    add    a,c             ; 00171D 81 
    nop                    ; 00171E 00 
    nop                    ; 00171F 00 
    ret    nc              ; 001720 D0 
    ld     c,a             ; 001721 4F 
    ld     c,e             ; 001722 4B 
    ld     b,l             ; 001723 45 
    ret    nc              ; 001724 D0 
    ld     d,d             ; 001725 52 
    ld     c,c             ; 001726 49 
    ld     c,(hl)          ; 001727 4E 
    ld     d,h             ; 001728 54 
    jp     $4e4f           ; 001729 C3 4F 4E 
    ld     d,h             ; 00172C 54 
    call   z,$5349         ; 00172D CC 49 53 
    ld     d,h             ; 001730 54 
    call   z,$494c         ; 001731 CC 4C 49 
    ld     d,e             ; 001734 53 
    ld     d,h             ; 001735 54 
    add    a,c             ; 001736 81 
    nop                    ; 001737 00 
    nop                    ; 001738 00 
    nop                    ; 001739 00 
    nop                    ; 00173A 00 
    nop                    ; 00173B 00 
    add    a,c             ; 00173C 81 
    nop                    ; 00173D 00 
    nop                    ; 00173E 00 
    nop                    ; 00173F 00 
    jp     $454c           ; 001740 C3 4C 45 
    ld     b,c             ; 001743 41 
    ld     d,d             ; 001744 52 
    jp     $4f4c           ; 001745 C3 4C 4F 
    ld     b,c             ; 001748 41 
    ld     b,h             ; 001749 44 
    jp     $4153           ; 00174A C3 53 41 
    ld     d,(hl)          ; 00174D 56 
    ld     b,l             ; 00174E 45 
    adc    a,$45           ; 00174F CE 45 
    ld     d,a             ; 001751 57 
    call   nc,$4241        ; 001752 D4 41 42 
    jr     z,$172b         ; 001755 28 D4 
    ld     c,a             ; 001757 4F 
    add    a,c             ; 001758 81 
    nop                    ; 001759 00 
    push   de              ; 00175A D5 
    ld     d,e             ; 00175B 53 
    ld     c,c             ; 00175C 49 
    ld     c,(hl)          ; 00175D 4E 
    ld     b,a             ; 00175E 47 
    add    a,c             ; 00175F 81 
    nop                    ; 001760 00 
    nop                    ; 001761 00 
    nop                    ; 001762 00 
    nop                    ; 001763 00 
    nop                    ; 001764 00 
    push   de              ; 001765 D5 
    ld     d,e             ; 001766 53 
    ld     d,d             ; 001767 52 
    add    a,c             ; 001768 81 
    nop                    ; 001769 00 
    nop                    ; 00176A 00 
    add    a,c             ; 00176B 81 
    nop                    ; 00176C 00 
    nop                    ; 00176D 00 
    add    a,c             ; 00176E 81 
    nop                    ; 00176F 00 
    nop                    ; 001770 00 
    nop                    ; 001771 00 
    nop                    ; 001772 00 
    nop                    ; 001773 00 
    nop                    ; 001774 00 
    add    a,c             ; 001775 81 
    nop                    ; 001776 00 
    nop                    ; 001777 00 
    nop                    ; 001778 00 
    nop                    ; 001779 00 
    ret    nc              ; 00177A D0 
    ld     c,a             ; 00177B 4F 
    ld     c,c             ; 00177C 49 
    ld     c,(hl)          ; 00177D 4E 
    ld     d,h             ; 00177E 54 
    add    a,c             ; 00177F 81 
    nop                    ; 001780 00 
    nop                    ; 001781 00 
    nop                    ; 001782 00 
    nop                    ; 001783 00 
    add    a,c             ; 001784 81 
    nop                    ; 001785 00 
    nop                    ; 001786 00 
    ret                    ; 001787 C9 
    ld     c,(hl)          ; 001788 4E 
    ld     c,e             ; 001789 4B 
    ld     b,l             ; 00178A 45 
    ld     e,c             ; 00178B 59 
    inc    h               ; 00178C 24 
    call   nc,$4548        ; 00178D D4 48 45 
    ld     c,(hl)          ; 001790 4E 
    adc    a,$4f           ; 001791 CE 4F 
    ld     d,h             ; 001793 54 
    out    ($54),a         ; 001794 D3 54 
    ld     b,l             ; 001796 45 
    ld     d,b             ; 001797 50 
    xor    e               ; 001798 AB 
    xor    l               ; 001799 AD 
    xor    d               ; 00179A AA 
    xor    a               ; 00179B AF 
    sbc    a,$c1           ; 00179C DE C1 
    ld     c,(hl)          ; 00179E 4E 
    ld     b,h             ; 00179F 44 
    rst    08h             ; 0017A0 CF 
    ld     d,d             ; 0017A1 52 
    cp     (hl)            ; 0017A2 BE 
    cp     l               ; 0017A3 BD 
    cp     h               ; 0017A4 BC 
    out    ($47),a         ; 0017A5 D3 47 
    ld     c,(hl)          ; 0017A7 4E 
    ret                    ; 0017A8 C9 
    ld     c,(hl)          ; 0017A9 4E 
    ld     d,h             ; 0017AA 54 
    pop    bc              ; 0017AB C1 
    ld     b,d             ; 0017AC 42 
    ld     d,e             ; 0017AD 53 
    add    a,c             ; 0017AE 81 
    nop                    ; 0017AF 00 
    nop                    ; 0017B0 00 
    ret                    ; 0017B1 C9 
    ld     c,(hl)          ; 0017B2 4E 
    ld     d,b             ; 0017B3 50 
    add    a,c             ; 0017B4 81 
    nop                    ; 0017B5 00 
    nop                    ; 0017B6 00 
    out    ($51),a         ; 0017B7 D3 51 
    ld     d,d             ; 0017B9 52 
    jp     nc,$444e        ; 0017BA D2 4E 44 
    call   z,$474f         ; 0017BD CC 4F 47 
    push   bc              ; 0017C0 C5 
    ld     e,b             ; 0017C1 58 
    ld     d,b             ; 0017C2 50 
    jp     $534f           ; 0017C3 C3 4F 53 
    out    ($49),a         ; 0017C6 D3 49 
    ld     c,(hl)          ; 0017C8 4E 
    call   nc,$4e41        ; 0017C9 D4 41 4E 
    pop    bc              ; 0017CC C1 
    ld     d,h             ; 0017CD 54 
    ld     c,(hl)          ; 0017CE 4E 
    ret    nc              ; 0017CF D0 
    ld     b,l             ; 0017D0 45 
    ld     b,l             ; 0017D1 45 
    ld     c,e             ; 0017D2 4B 
    add    a,c             ; 0017D3 81 
    nop                    ; 0017D4 00 
    nop                    ; 0017D5 00 
    add    a,c             ; 0017D6 81 
    nop                    ; 0017D7 00 
    nop                    ; 0017D8 00 
    add    a,c             ; 0017D9 81 
    nop                    ; 0017DA 00 
    nop                    ; 0017DB 00 
    add    a,c             ; 0017DC 81 
    nop                    ; 0017DD 00 
    nop                    ; 0017DE 00 
    add    a,c             ; 0017DF 81 
    nop                    ; 0017E0 00 
    nop                    ; 0017E1 00 
    add    a,c             ; 0017E2 81 
    nop                    ; 0017E3 00 
    nop                    ; 0017E4 00 
    add    a,c             ; 0017E5 81 
    nop                    ; 0017E6 00 
    nop                    ; 0017E7 00 
    nop                    ; 0017E8 00 
    add    a,c             ; 0017E9 81 
    nop                    ; 0017EA 00 
    nop                    ; 0017EB 00 
    nop                    ; 0017EC 00 
    add    a,c             ; 0017ED 81 
    nop                    ; 0017EE 00 
    nop                    ; 0017EF 00 
    nop                    ; 0017F0 00 
    add    a,c             ; 0017F1 81 
    nop                    ; 0017F2 00 
    nop                    ; 0017F3 00 
    nop                    ; 0017F4 00 
    add    a,c             ; 0017F5 81 
    nop                    ; 0017F6 00 
    nop                    ; 0017F7 00 
    nop                    ; 0017F8 00 
    add    a,c             ; 0017F9 81 
    nop                    ; 0017FA 00 
    nop                    ; 0017FB 00 
    nop                    ; 0017FC 00 
    add    a,c             ; 0017FD 81 
    nop                    ; 0017FE 00 
    nop                    ; 0017FF 00 
    call   z,$4e45         ; 001800 CC 45 4E 
    out    ($54),a         ; 001803 D3 54 
    ld     d,d             ; 001805 52 
    inc    h               ; 001806 24 
    sub    $41             ; 001807 D6 41 
    ld     c,h             ; 001809 4C 
    pop    bc              ; 00180A C1 
    ld     d,e             ; 00180B 53 
    ld     b,e             ; 00180C 43 
    jp     $5248           ; 00180D C3 48 52 
    inc    h               ; 001810 24 
    call   z,$4645         ; 001811 CC 45 46 
    ld     d,h             ; 001814 54 
    inc    h               ; 001815 24 
    jp     nc,$4749        ; 001816 D2 49 47 
    ld     c,b             ; 001819 48 
    ld     d,h             ; 00181A 54 
    inc    h               ; 00181B 24 
    call   $4449           ; 00181C CD 49 44 
    inc    h               ; 00181F 24 
    and    a               ; 001820 A7 
    add    a,b             ; 001821 80 
    xor    (hl)            ; 001822 AE 
    dec    e               ; 001823 1D 
    and    c               ; 001824 A1 
    inc    e               ; 001825 1C 
    jr     c,$1829         ; 001826 38 01 
    dec    (hl)            ; 001828 35 
    ld     bc,$01c9        ; 001829 01 C9 01 
    ld     (hl),e          ; 00182C 73 
    ld     a,c             ; 00182D 79 
    out    ($01),a         ; 00182E D3 01 
    or     (hl)            ; 001830 B6 
    ld     ($1f05),hl      ; 001831 22 05 1F 
    sbc    a,d             ; 001834 9A 
    ld     hl,$2608        ; 001835 21 08 26 
    rst    28h             ; 001838 EF 
    ld     hl,$1f21        ; 001839 21 21 1F 
    jp     nz,$a31e        ; 00183C C2 1E A3 
    ld     e,$39           ; 00183F 1E 39 
    jr     nz,$17d4        ; 001841 20 91 
    dec    e               ; 001843 1D 
    or     c               ; 001844 B1 
    ld     e,$de           ; 001845 1E DE 
    ld     e,$07           ; 001847 1E 07 
    rra                    ; 001849 1F 
    xor    c               ; 00184A A9 
    dec    e               ; 00184B 1D 
    rlca                   ; 00184C 07 
    rra                    ; 00184D 1F 
    ld     (de),a          ; 00184E 12 
    add    hl,sp           ; 00184F 39 
    sbc    a,l             ; 001850 9D 
    jr     c,$188b         ; 001851 38 38 
    scf                    ; 001853 37 
    inc    bc              ; 001854 03 
    ld     e,$06           ; 001855 1E 06 
    ld     e,$09           ; 001857 1E 09 
    ld     e,$2e           ; 001859 1E 2E 
    scf                    ; 00185B 37 
    ld     h,e             ; 00185C 63 
    ld     l,$f5           ; 00185D 2E F5 
    dec    hl              ; 00185F 2B 
    xor    a               ; 001860 AF 
    rra                    ; 001861 1F 
    ei                     ; 001862 FB 
    ld     hl,($1f6c)      ; 001863 2A 6C 1F 
    ld     a,c             ; 001866 79 
    ld     a,c             ; 001867 79 
    ld     a,h             ; 001868 7C 
    ld     a,c             ; 001869 79 
    ld     a,a             ; 00186A 7F 
    ld     a,c             ; 00186B 79 
    add    a,d             ; 00186C 82 
    ld     a,c             ; 00186D 79 
    add    a,l             ; 00186E 85 
    ld     a,c             ; 00186F 79 
    adc    a,b             ; 001870 88 
    ld     a,c             ; 001871 79 
    adc    a,e             ; 001872 8B 
    ld     a,c             ; 001873 79 
    adc    a,(hl)          ; 001874 8E 
    ld     a,c             ; 001875 79 
    sub    c               ; 001876 91 
    ld     a,c             ; 001877 79 
    sub    a               ; 001878 97 
    ld     a,c             ; 001879 79 
    sbc    a,d             ; 00187A 9A 
    ld     a,c             ; 00187B 79 
    and    b               ; 00187C A0 
    ld     a,c             ; 00187D 79 
    nop                    ; 00187E 00 
    nop                    ; 00187F 00 
    ld     h,a             ; 001880 67 
    jr     nz,$18de        ; 001881 20 5B 
    ld     a,c             ; 001883 79 
    or     c               ; 001884 B1 
    inc    l               ; 001885 2C 
    ld     l,a             ; 001886 6F 
    jr     nz,$186d        ; 001887 20 E4 
    dec    e               ; 001889 1D 
    ld     l,$2b           ; 00188A 2E 2B 
    add    hl,hl           ; 00188C 29 
    dec    hl              ; 00188D 2B 
    add    a,$2b           ; 00188E C6 2B 
    ex     af,af'          ; 001890 08 
    jr     nz,$190d        ; 001891 20 7A 
    ld     e,$56           ; 001893 1E 56 
    ld     (hl),$a9        ; 001895 36 A9 
    inc    (hl)            ; 001897 34 
    ld     c,c             ; 001898 49 
    dec    de              ; 001899 1B 
    ld     a,c             ; 00189A 79 
    ld     a,c             ; 00189B 79 
    ld     a,h             ; 00189C 7C 
    ld     a,h             ; 00189D 7C 
    ld     a,a             ; 00189E 7F 
    ld     d,b             ; 00189F 50 
    ld     b,(hl)          ; 0018A0 46 
    in     a,($0a)         ; 0018A1 DB 0A 
    nop                    ; 0018A3 00 
    nop                    ; 0018A4 00 
    ld     a,a             ; 0018A5 7F 
    ld     a,(bc)          ; 0018A6 0A 
    call   p,$b10a         ; 0018A7 F4 0A B1 
    ld     a,(bc)          ; 0018AA 0A 
    ld     (hl),a          ; 0018AB 77 
    inc    c               ; 0018AC 0C 
    ld     (hl),b          ; 0018AD 70 
    inc    c               ; 0018AE 0C 
    and    c               ; 0018AF A1 
    dec    c               ; 0018B0 0D 
    push   hl              ; 0018B1 E5 
    dec    c               ; 0018B2 0D 
    ld     a,b             ; 0018B3 78 
    ld     a,(bc)          ; 0018B4 0A 
    ld     d,$07           ; 0018B5 16 07 
    inc    de              ; 0018B7 13 
    rlca                   ; 0018B8 07 
    ld     b,a             ; 0018B9 47 
    ex     af,af'          ; 0018BA 08 
    and    d               ; 0018BB A2 
    ex     af,af'          ; 0018BC 08 
    inc    c               ; 0018BD 0C 
    ld     a,(bc)          ; 0018BE 0A 
    jp     nc,$c70b        ; 0018BF D2 0B C7 
    dec    bc              ; 0018C2 0B 
    jp     p,$900b         ; 0018C3 F2 0B 90 
    inc    h               ; 0018C6 24 
    add    hl,sp           ; 0018C7 39 
    ld     a,(bc)          ; 0018C8 0A 
    ld     c,(hl)          ; 0018C9 4E 
    ld     b,(hl)          ; 0018CA 46 
    ld     d,e             ; 0018CB 53 
    ld     c,(hl)          ; 0018CC 4E 
    ld     d,d             ; 0018CD 52 
    ld     b,a             ; 0018CE 47 
    ld     c,a             ; 0018CF 4F 
    ld     b,h             ; 0018D0 44 
    ld     b,(hl)          ; 0018D1 46 
    ld     b,e             ; 0018D2 43 
    ld     c,a             ; 0018D3 4F 
    ld     d,(hl)          ; 0018D4 56 
    ld     c,a             ; 0018D5 4F 
    ld     c,l             ; 0018D6 4D 
    ld     d,l             ; 0018D7 55 
    ld     c,h             ; 0018D8 4C 
    ld     b,d             ; 0018D9 42 
    ld     d,e             ; 0018DA 53 
    ld     b,h             ; 0018DB 44 
    ld     b,h             ; 0018DC 44 
    cpl                    ; 0018DD 2F 
    jr     nc,$1929        ; 0018DE 30 49 
    ld     b,h             ; 0018E0 44 
    ld     d,h             ; 0018E1 54 
    ld     c,l             ; 0018E2 4D 
    ld     c,a             ; 0018E3 4F 
    ld     d,e             ; 0018E4 53 
    ld     c,h             ; 0018E5 4C 
    ld     d,e             ; 0018E6 53 
    ld     d,e             ; 0018E7 53 
    ld     d,h             ; 0018E8 54 
    ld     b,e             ; 0018E9 43 
    ld     c,(hl)          ; 0018EA 4E 
    ld     c,(hl)          ; 0018EB 4E 
    ld     d,d             ; 0018EC 52 
    ld     d,d             ; 0018ED 52 
    ld     d,a             ; 0018EE 57 
    ld     d,l             ; 0018EF 55 
    ld     b,l             ; 0018F0 45 
    ld     c,l             ; 0018F1 4D 
    ld     c,a             ; 0018F2 4F 
    ld     b,(hl)          ; 0018F3 46 
    ld     b,h             ; 0018F4 44 
    ld     c,h             ; 0018F5 4C 
    inc    sp              ; 0018F6 33 
    sub    $00             ; 0018F7 D6 00 
    ld     l,a             ; 0018F9 6F 
    ld     a,h             ; 0018FA 7C 
    sbc    a,$00           ; 0018FB DE 00 
    ld     h,a             ; 0018FD 67 
    ld     a,b             ; 0018FE 78 
    sbc    a,$00           ; 0018FF DE 00 
    ld     b,a             ; 001901 47 
    ld     a,$00           ; 001902 3E 00 
    ret                    ; 001904 C9 
    ld     c,d             ; 001905 4A 
    ld     e,$40           ; 001906 1E 40 
    and    $4d             ; 001908 E6 4D 
    in     a,($00)         ; 00190A DB 00 
    ret                    ; 00190C C9 
    out    ($00),a         ; 00190D D3 00 
    ret                    ; 00190F C9 
    nop                    ; 001910 00 
    nop                    ; 001911 00 
    nop                    ; 001912 00 
    nop                    ; 001913 00 
    ld     b,b             ; 001914 40 
    jr     nc,$1917        ; 001915 30 00 
    ld     c,h             ; 001917 4C 
    ld     a,e             ; 001918 7B 
    cp     $ff             ; 001919 FE FF 
    jp     (hl)            ; 00191B E9 
    ld     a,d             ; 00191C 7A 
    jr     nz,$1964        ; 00191D 20 45 
    ld     d,d             ; 00191F 52 
    ld     d,d             ; 001920 52 
    ld     c,a             ; 001921 4F 
    ld     d,d             ; 001922 52 
    nop                    ; 001923 00 
    jr     nz,$196f        ; 001924 20 49 
    ld     c,(hl)          ; 001926 4E 
    jr     nz,$1929        ; 001927 20 00 
    ld     d,d             ; 001929 52 
    ld     b,l             ; 00192A 45 
    ld     b,c             ; 00192B 41 
    ld     b,h             ; 00192C 44 
    ld     e,c             ; 00192D 59 
    dec    c               ; 00192E 0D 
    nop                    ; 00192F 00 
    ld     b,d             ; 001930 42 
    ld     d,d             ; 001931 52 
    ld     b,l             ; 001932 45 
    ld     b,c             ; 001933 41 
    ld     c,e             ; 001934 4B 
    nop                    ; 001935 00 
    ld     hl,$0004        ; 001936 21 04 00 
    add    hl,sp           ; 001939 39 
    ld     a,(hl)          ; 00193A 7E 
    inc    hl              ; 00193B 23 
    cp     $81             ; 00193C FE 81 
    ret    nz              ; 00193E C0 
    ld     c,(hl)          ; 00193F 4E 
    inc    hl              ; 001940 23 
    ld     b,(hl)          ; 001941 46 
    inc    hl              ; 001942 23 
    push   hl              ; 001943 E5 
    ld     l,c             ; 001944 69 
    ld     h,b             ; 001945 60 
    ld     a,d             ; 001946 7A 
    or     e               ; 001947 B3 
    ex     de,hl           ; 001948 EB 
    jr     z,$194d         ; 001949 28 02 
    ex     de,hl           ; 00194B EB 
    rst    18h             ; 00194C DF 
    ld     bc,$000e        ; 00194D 01 0E 00 
    pop    hl              ; 001950 E1 
    ret    z               ; 001951 C8 
    add    hl,bc           ; 001952 09 
    jr     $193a           ; 001953 18 E5 
    call   $196c           ; 001955 CD 6C 19 
    push   bc              ; 001958 C5 
    ex     (sp),hl         ; 001959 E3 
    pop    bc              ; 00195A C1 
    rst    18h             ; 00195B DF 
    ld     a,(hl)          ; 00195C 7E 
    ld     (bc),a          ; 00195D 02 
    ret    z               ; 00195E C8 
    dec    bc              ; 00195F 0B 
    dec    hl              ; 001960 2B 
    jr     $195b           ; 001961 18 F8 
    push   hl              ; 001963 E5 
    ld     hl,($78fd)      ; 001964 2A FD 78 
    ld     b,$00           ; 001967 06 00 
    add    hl,bc           ; 001969 09 
    add    hl,bc           ; 00196A 09 
    ld     a,$e5           ; 00196B 3E E5 
    ld     a,$c6           ; 00196D 3E C6 
    sub    l               ; 00196F 95 
    ld     l,a             ; 001970 6F 
    ld     a,$ff           ; 001971 3E FF 
    sbc    a,h             ; 001973 9C 
    jr     c,$197a         ; 001974 38 04 
    ld     h,a             ; 001976 67 
    add    hl,sp           ; 001977 39 
    pop    hl              ; 001978 E1 
    ret    c               ; 001979 D8 
    ld     e,$0c           ; 00197A 1E 0C 
    jr     $19a2           ; 00197C 18 24 
    ld     hl,($78a2)      ; 00197E 2A A2 78 
    ld     a,h             ; 001981 7C 
    and    l               ; 001982 A5 
    inc    a               ; 001983 3C 
    jr     z,$198e         ; 001984 28 08 
    ld     a,($78f2)       ; 001986 3A F2 78 
    or     a               ; 001989 B7 
    ld     e,$22           ; 00198A 1E 22 
    jr     nz,$19a2        ; 00198C 20 14 
    jp     $1dc1           ; 00198E C3 C1 1D 
    ld     hl,($78da)      ; 001991 2A DA 78 
    ld     ($78a2),hl      ; 001994 22 A2 78 
    ld     e,$02           ; 001997 1E 02 
    ld     bc,$141e        ; 001999 01 1E 14 
    ld     bc,$001e        ; 00199C 01 1E 00 
    ld     bc,$241e        ; 00199F 01 1E 24 
    ld     hl,($78a2)      ; 0019A2 2A A2 78 
    ld     ($78ea),hl      ; 0019A5 22 EA 78 
    ld     ($78ec),hl      ; 0019A8 22 EC 78 
    ld     bc,$19b4        ; 0019AB 01 B4 19 
    ld     hl,($78e8)      ; 0019AE 2A E8 78 
    jp     $1b9a           ; 0019B1 C3 9A 1B 
    pop    bc              ; 0019B4 C1 
    ld     a,e             ; 0019B5 7B 
    ld     c,e             ; 0019B6 4B 
    ld     ($789a),a       ; 0019B7 32 9A 78 
    ld     hl,($78e6)      ; 0019BA 2A E6 78 
    ld     ($78ee),hl      ; 0019BD 22 EE 78 
    ex     de,hl           ; 0019C0 EB 
    ld     hl,($78ea)      ; 0019C1 2A EA 78 
    ld     a,h             ; 0019C4 7C 
    and    l               ; 0019C5 A5 
    inc    a               ; 0019C6 3C 
    jr     z,$19d0         ; 0019C7 28 07 
    ld     ($78f5),hl      ; 0019C9 22 F5 78 
    ex     de,hl           ; 0019CC EB 
    ld     ($78f7),hl      ; 0019CD 22 F7 78 
    ld     hl,($78f0)      ; 0019D0 2A F0 78 
    ld     a,h             ; 0019D3 7C 
    or     l               ; 0019D4 B5 
    ex     de,hl           ; 0019D5 EB 
    ld     hl,$78f2        ; 0019D6 21 F2 78 
    jr     z,$19e3         ; 0019D9 28 08 
    and    (hl)            ; 0019DB A6 
    jr     nz,$19e3        ; 0019DC 20 05 
    dec    (hl)            ; 0019DE 35 
    ex     de,hl           ; 0019DF EB 
    jp     $1d36           ; 0019E0 C3 36 1D 
    xor    a               ; 0019E3 AF 
    ld     (hl),a          ; 0019E4 77 
    ld     e,c             ; 0019E5 59 
    call   $20f9           ; 0019E6 CD F9 20 
    ld     hl,$3cec        ; 0019E9 21 EC 3C 
    call   $79a6           ; 0019EC CD A6 79 
    ld     d,a             ; 0019EF 57 
    ld     a,$3f           ; 0019F0 3E 3F 
    call   $032a           ; 0019F2 CD 2A 03 
    call   $3cd4           ; 0019F5 CD D4 3C 
    nop                    ; 0019F8 00 
    nop                    ; 0019F9 00 
    nop                    ; 0019FA 00 
    nop                    ; 0019FB 00 
    nop                    ; 0019FC 00 
    nop                    ; 0019FD 00 
    ld     hl,$191d        ; 0019FE 21 1D 19 
    push   hl              ; 001A01 E5 
    ld     hl,($78ea)      ; 001A02 2A EA 78 
    ex     (sp),hl         ; 001A05 E3 
    call   $28a7           ; 001A06 CD A7 28 
    pop    hl              ; 001A09 E1 
    ld     de,$fffe        ; 001A0A 11 FE FF 
    rst    18h             ; 001A0D DF 
    jp     z,$0674         ; 001A0E CA 74 06 
    ld     a,h             ; 001A11 7C 
    and    l               ; 001A12 A5 
    inc    a               ; 001A13 3C 
    call   nz,$0fa7        ; 001A14 C4 A7 0F 
    ld     a,$c1           ; 001A17 3E C1 
    call   $038b           ; 001A19 CD 8B 03 
    call   $79ac           ; 001A1C CD AC 79 
    nop                    ; 001A1F 00 
    nop                    ; 001A20 00 
    nop                    ; 001A21 00 
    call   $20f9           ; 001A22 CD F9 20 
    ld     hl,$1929        ; 001A25 21 29 19 
    call   $28a7           ; 001A28 CD A7 28 
    ld     a,($789a)       ; 001A2B 3A 9A 78 
    sub    $02             ; 001A2E D6 02 
    nop                    ; 001A30 00 
    nop                    ; 001A31 00 
    nop                    ; 001A32 00 
    ld     hl,$ffff        ; 001A33 21 FF FF 
    ld     ($78a2),hl      ; 001A36 22 A2 78 
    ld     a,($78e1)       ; 001A39 3A E1 78 
    or     a               ; 001A3C B7 
    jr     z,$1a79         ; 001A3D 28 3A 
    ld     hl,($78e2)      ; 001A3F 2A E2 78 
    push   hl              ; 001A42 E5 
    call   $0faf           ; 001A43 CD AF 0F 
    ld     a,$20           ; 001A46 3E 20 
    call   $032a           ; 001A48 CD 2A 03 
    pop    de              ; 001A4B D1 
    push   de              ; 001A4C D5 
    call   $1b2c           ; 001A4D CD 2C 1B 
    call   c,$2e53         ; 001A50 DC 53 2E 
    nop                    ; 001A53 00 
    call   $03e3           ; 001A54 CD E3 03 
    pop    de              ; 001A57 D1 
    jr     nc,$1a60        ; 001A58 30 06 
    xor    a               ; 001A5A AF 
    ld     ($78e1),a       ; 001A5B 32 E1 78 
    jr     $1a19           ; 001A5E 18 B9 
    ld     hl,($78e4)      ; 001A60 2A E4 78 
    add    hl,de           ; 001A63 19 
    jr     c,$1a5a         ; 001A64 38 F4 
    push   de              ; 001A66 D5 
    ld     de,$fff9        ; 001A67 11 F9 FF 
    rst    18h             ; 001A6A DF 
    pop    de              ; 001A6B D1 
    jr     nc,$1a5a        ; 001A6C 30 EC 
    ld     ($78e2),hl      ; 001A6E 22 E2 78 
    nop                    ; 001A71 00 
    nop                    ; 001A72 00 
    ld     hl,$79e7        ; 001A73 21 E7 79 
    jp     $1a81           ; 001A76 C3 81 1A 
    nop                    ; 001A79 00 
    nop                    ; 001A7A 00 
    call   $03e3           ; 001A7B CD E3 03 
    jp     c,$1a33         ; 001A7E DA 33 1A 
    rst    10h             ; 001A81 D7 
    inc    a               ; 001A82 3C 
    dec    a               ; 001A83 3D 
    jp     z,$1a33         ; 001A84 CA 33 1A 
    push   af              ; 001A87 F5 
    call   $1e5a           ; 001A88 CD 5A 1E 
    dec    hl              ; 001A8B 2B 
    ld     a,(hl)          ; 001A8C 7E 
    cp     $20             ; 001A8D FE 20 
    jr     z,$1a8b         ; 001A8F 28 FA 
    inc    hl              ; 001A91 23 
    ld     a,(hl)          ; 001A92 7E 
    cp     $20             ; 001A93 FE 20 
    call   z,$09c9         ; 001A95 CC C9 09 
    push   de              ; 001A98 D5 
    call   $1bc0           ; 001A99 CD C0 1B 
    pop    de              ; 001A9C D1 
    pop    af              ; 001A9D F1 
    ld     ($78e6),hl      ; 001A9E 22 E6 78 
    call   $79b2           ; 001AA1 CD B2 79 
    jp     nc,$1d5a        ; 001AA4 D2 5A 1D 
    push   de              ; 001AA7 D5 
    push   bc              ; 001AA8 C5 
    xor    a               ; 001AA9 AF 
    ld     ($78dd),a       ; 001AAA 32 DD 78 
    rst    10h             ; 001AAD D7 
    or     a               ; 001AAE B7 
    push   af              ; 001AAF F5 
    ex     de,hl           ; 001AB0 EB 
    ld     ($78ec),hl      ; 001AB1 22 EC 78 
    ex     de,hl           ; 001AB4 EB 
    call   $1b2c           ; 001AB5 CD 2C 1B 
    push   bc              ; 001AB8 C5 
    call   c,$2be4         ; 001AB9 DC E4 2B 
    pop    de              ; 001ABC D1 
    pop    af              ; 001ABD F1 
    push   de              ; 001ABE D5 
    jr     z,$1ae8         ; 001ABF 28 27 
    pop    de              ; 001AC1 D1 
    ld     hl,($78f9)      ; 001AC2 2A F9 78 
    ex     (sp),hl         ; 001AC5 E3 
    pop    bc              ; 001AC6 C1 
    add    hl,bc           ; 001AC7 09 
    push   hl              ; 001AC8 E5 
    call   $1955           ; 001AC9 CD 55 19 
    pop    hl              ; 001ACC E1 
    ld     ($78f9),hl      ; 001ACD 22 F9 78 
    ex     de,hl           ; 001AD0 EB 
    ld     (hl),h          ; 001AD1 74 
    pop    de              ; 001AD2 D1 
    push   hl              ; 001AD3 E5 
    inc    hl              ; 001AD4 23 
    inc    hl              ; 001AD5 23 
    ld     (hl),e          ; 001AD6 73 
    inc    hl              ; 001AD7 23 
    ld     (hl),d          ; 001AD8 72 
    inc    hl              ; 001AD9 23 
    ex     de,hl           ; 001ADA EB 
    ld     hl,($78a7)      ; 001ADB 2A A7 78 
    ex     de,hl           ; 001ADE EB 
    dec    de              ; 001ADF 1B 
    dec    de              ; 001AE0 1B 
    ld     a,(de)          ; 001AE1 1A 
    ld     (hl),a          ; 001AE2 77 
    inc    hl              ; 001AE3 23 
    inc    de              ; 001AE4 13 
    or     a               ; 001AE5 B7 
    jr     nz,$1ae1        ; 001AE6 20 F9 
    pop    de              ; 001AE8 D1 
    call   $1afc           ; 001AE9 CD FC 1A 
    call   $79b5           ; 001AEC CD B5 79 
    call   $1b5d           ; 001AEF CD 5D 1B 
    call   $79b8           ; 001AF2 CD B8 79 
    jp     $1a33           ; 001AF5 C3 33 1A 
    ld     hl,($78a4)      ; 001AF8 2A A4 78 
    ex     de,hl           ; 001AFB EB 
    ld     h,d             ; 001AFC 62 
    ld     l,e             ; 001AFD 6B 
    ld     a,(hl)          ; 001AFE 7E 
    inc    hl              ; 001AFF 23 
    or     (hl)            ; 001B00 B6 
    ret    z               ; 001B01 C8 
    inc    hl              ; 001B02 23 
    inc    hl              ; 001B03 23 
    inc    hl              ; 001B04 23 
    xor    a               ; 001B05 AF 
    cp     (hl)            ; 001B06 BE 
    inc    hl              ; 001B07 23 
    jr     nz,$1b06        ; 001B08 20 FC 
    ex     de,hl           ; 001B0A EB 
    ld     (hl),e          ; 001B0B 73 
    inc    hl              ; 001B0C 23 
    ld     (hl),d          ; 001B0D 72 
    jr     $1afc           ; 001B0E 18 EC 
    ld     de,$0000        ; 001B10 11 00 00 
    push   de              ; 001B13 D5 
    jr     z,$1b1f         ; 001B14 28 09 
    pop    de              ; 001B16 D1 
    call   $1e4f           ; 001B17 CD 4F 1E 
    push   de              ; 001B1A D5 
    jr     z,$1b28         ; 001B1B 28 0B 
    rst    08h             ; 001B1D CF 
    adc    a,$11           ; 001B1E CE 11 
    jp     m,$c4ff         ; 001B20 FA FF C4 
    ld     c,a             ; 001B23 4F 
    ld     e,$c2           ; 001B24 1E C2 
    sub    a               ; 001B26 97 
    add    hl,de           ; 001B27 19 
    ex     de,hl           ; 001B28 EB 
    pop    de              ; 001B29 D1 
    ex     (sp),hl         ; 001B2A E3 
    push   hl              ; 001B2B E5 
    ld     hl,($78a4)      ; 001B2C 2A A4 78 
    ld     b,h             ; 001B2F 44 
    ld     c,l             ; 001B30 4D 
    ld     a,(hl)          ; 001B31 7E 
    inc    hl              ; 001B32 23 
    or     (hl)            ; 001B33 B6 
    dec    hl              ; 001B34 2B 
    ret    z               ; 001B35 C8 
    inc    hl              ; 001B36 23 
    inc    hl              ; 001B37 23 
    ld     a,(hl)          ; 001B38 7E 
    inc    hl              ; 001B39 23 
    ld     h,(hl)          ; 001B3A 66 
    ld     l,a             ; 001B3B 6F 
    rst    18h             ; 001B3C DF 
    ld     h,b             ; 001B3D 60 
    ld     l,c             ; 001B3E 69 
    ld     a,(hl)          ; 001B3F 7E 
    inc    hl              ; 001B40 23 
    ld     h,(hl)          ; 001B41 66 
    ld     l,a             ; 001B42 6F 
    ccf                    ; 001B43 3F 
    ret    z               ; 001B44 C8 
    ccf                    ; 001B45 3F 
    ret    nc              ; 001B46 D0 
    jr     $1b2f           ; 001B47 18 E6 
    ret    nz              ; 001B49 C0 
    call   $01c9           ; 001B4A CD C9 01 
    ld     hl,($78a4)      ; 001B4D 2A A4 78 
    call   $1df8           ; 001B50 CD F8 1D 
    ld     ($78e1),a       ; 001B53 32 E1 78 
    ld     (hl),a          ; 001B56 77 
    inc    hl              ; 001B57 23 
    ld     (hl),a          ; 001B58 77 
    inc    hl              ; 001B59 23 
    ld     ($78f9),hl      ; 001B5A 22 F9 78 
    ld     hl,($78a4)      ; 001B5D 2A A4 78 
    dec    hl              ; 001B60 2B 
    ld     ($78df),hl      ; 001B61 22 DF 78 
    ld     b,$1a           ; 001B64 06 1A 
    ld     hl,$7901        ; 001B66 21 01 79 
    ld     (hl),$04        ; 001B69 36 04 
    inc    hl              ; 001B6B 23 
    djnz   $1b69           ; 001B6C 10 FB 
    xor    a               ; 001B6E AF 
    ld     ($78f2),a       ; 001B6F 32 F2 78 
    ld     l,a             ; 001B72 6F 
    ld     h,a             ; 001B73 67 
    ld     ($78f0),hl      ; 001B74 22 F0 78 
    ld     ($78f7),hl      ; 001B77 22 F7 78 
    ld     hl,($78b1)      ; 001B7A 2A B1 78 
    ld     ($78d6),hl      ; 001B7D 22 D6 78 
    call   $1d91           ; 001B80 CD 91 1D 
    ld     hl,($78f9)      ; 001B83 2A F9 78 
    ld     ($78fb),hl      ; 001B86 22 FB 78 
    ld     ($78fd),hl      ; 001B89 22 FD 78 
    call   $79bb           ; 001B8C CD BB 79 
    pop    bc              ; 001B8F C1 
    ld     hl,($78a0)      ; 001B90 2A A0 78 
    dec    hl              ; 001B93 2B 
    dec    hl              ; 001B94 2B 
    ld     ($78e8),hl      ; 001B95 22 E8 78 
    inc    hl              ; 001B98 23 
    inc    hl              ; 001B99 23 
    ld     sp,hl           ; 001B9A F9 
    ld     hl,$78b5        ; 001B9B 21 B5 78 
    ld     ($78b3),hl      ; 001B9E 22 B3 78 
    call   $038b           ; 001BA1 CD 8B 03 
    call   $2169           ; 001BA4 CD 69 21 
    xor    a               ; 001BA7 AF 
    ld     h,a             ; 001BA8 67 
    ld     l,a             ; 001BA9 6F 
    ld     ($78dc),a       ; 001BAA 32 DC 78 
    push   hl              ; 001BAD E5 
    push   bc              ; 001BAE C5 
    ld     hl,($78df)      ; 001BAF 2A DF 78 
    ret                    ; 001BB2 C9 
    ld     a,$3f           ; 001BB3 3E 3F 
    call   $032a           ; 001BB5 CD 2A 03 
    ld     a,$20           ; 001BB8 3E 20 
    call   $032a           ; 001BBA CD 2A 03 
    jp     $053a           ; 001BBD C3 3A 05 
    xor    a               ; 001BC0 AF 
    ld     ($78b0),a       ; 001BC1 32 B0 78 
    ld     c,a             ; 001BC4 4F 
    ex     de,hl           ; 001BC5 EB 
    ld     hl,($78a7)      ; 001BC6 2A A7 78 
    dec    hl              ; 001BC9 2B 
    dec    hl              ; 001BCA 2B 
    ex     de,hl           ; 001BCB EB 
    ld     a,(hl)          ; 001BCC 7E 
    cp     $20             ; 001BCD FE 20 
    jp     z,$1c5b         ; 001BCF CA 5B 1C 
    ld     b,a             ; 001BD2 47 
    cp     $22             ; 001BD3 FE 22 
    jp     z,$1c77         ; 001BD5 CA 77 1C 
    or     a               ; 001BD8 B7 
    jp     z,$1c7d         ; 001BD9 CA 7D 1C 
    ld     a,($78b0)       ; 001BDC 3A B0 78 
    or     a               ; 001BDF B7 
    ld     a,(hl)          ; 001BE0 7E 
    jp     nz,$1c5b        ; 001BE1 C2 5B 1C 
    cp     $3f             ; 001BE4 FE 3F 
    ld     a,$b2           ; 001BE6 3E B2 
    jp     z,$1c5b         ; 001BE8 CA 5B 1C 
    ld     a,(hl)          ; 001BEB 7E 
    cp     $30             ; 001BEC FE 30 
    jr     c,$1bf5         ; 001BEE 38 05 
    cp     $3c             ; 001BF0 FE 3C 
    jp     c,$1c5b         ; 001BF2 DA 5B 1C 
    push   de              ; 001BF5 D5 
    ld     de,$164f        ; 001BF6 11 4F 16 
    push   bc              ; 001BF9 C5 
    ld     bc,$1c3d        ; 001BFA 01 3D 1C 
    push   bc              ; 001BFD C5 
    ld     b,$7f           ; 001BFE 06 7F 
    ld     a,(hl)          ; 001C00 7E 
    cp     $61             ; 001C01 FE 61 
    jr     c,$1c0c         ; 001C03 38 07 
    cp     $7b             ; 001C05 FE 7B 
    jr     nc,$1c0c        ; 001C07 30 03 
    and    $5f             ; 001C09 E6 5F 
    ld     (hl),a          ; 001C0B 77 
    ld     c,(hl)          ; 001C0C 4E 
    ex     de,hl           ; 001C0D EB 
    inc    hl              ; 001C0E 23 
    or     (hl)            ; 001C0F B6 
    jp     p,$1c0e         ; 001C10 F2 0E 1C 
    inc    b               ; 001C13 04 
    ld     a,(hl)          ; 001C14 7E 
    and    $7f             ; 001C15 E6 7F 
    ret    z               ; 001C17 C8 
    cp     c               ; 001C18 B9 
    jr     nz,$1c0e        ; 001C19 20 F3 
    ex     de,hl           ; 001C1B EB 
    push   hl              ; 001C1C E5 
    inc    de              ; 001C1D 13 
    ld     a,(de)          ; 001C1E 1A 
    or     a               ; 001C1F B7 
    jp     m,$1c39         ; 001C20 FA 39 1C 
    ld     c,a             ; 001C23 4F 
    ld     a,b             ; 001C24 78 
    cp     $8d             ; 001C25 FE 8D 
    jr     nz,$1c2b        ; 001C27 20 02 
    rst    10h             ; 001C29 D7 
    dec    hl              ; 001C2A 2B 
    inc    hl              ; 001C2B 23 
    ld     a,(hl)          ; 001C2C 7E 
    cp     $61             ; 001C2D FE 61 
    jr     c,$1c33         ; 001C2F 38 02 
    and    $5f             ; 001C31 E6 5F 
    cp     c               ; 001C33 B9 
    jr     z,$1c1d         ; 001C34 28 E7 
    pop    hl              ; 001C36 E1 
    jr     $1c0c           ; 001C37 18 D3 
    ld     c,b             ; 001C39 48 
    pop    af              ; 001C3A F1 
    ex     de,hl           ; 001C3B EB 
    ret                    ; 001C3C C9 
    ex     de,hl           ; 001C3D EB 
    ld     a,c             ; 001C3E 79 
    pop    bc              ; 001C3F C1 
    pop    de              ; 001C40 D1 
    ex     de,hl           ; 001C41 EB 
    cp     $95             ; 001C42 FE 95 
    ld     (hl),$3a        ; 001C44 36 3A 
    jr     nz,$1c4a        ; 001C46 20 02 
    inc    c               ; 001C48 0C 
    inc    hl              ; 001C49 23 
    cp     $fb             ; 001C4A FE FB 
    jr     nz,$1c5a        ; 001C4C 20 0C 
    ld     (hl),$3a        ; 001C4E 36 3A 
    inc    hl              ; 001C50 23 
    ld     b,$93           ; 001C51 06 93 
    ld     (hl),b          ; 001C53 70 
    inc    hl              ; 001C54 23 
    ex     de,hl           ; 001C55 EB 
    inc    c               ; 001C56 0C 
    inc    c               ; 001C57 0C 
    jr     $1c77           ; 001C58 18 1D 
    ex     de,hl           ; 001C5A EB 
    inc    hl              ; 001C5B 23 
    ld     (de),a          ; 001C5C 12 
    inc    de              ; 001C5D 13 
    inc    c               ; 001C5E 0C 
    sub    $3a             ; 001C5F D6 3A 
    jr     z,$1c67         ; 001C61 28 04 
    cp     $4e             ; 001C63 FE 4E 
    jr     nz,$1c6a        ; 001C65 20 03 
    ld     ($78b0),a       ; 001C67 32 B0 78 
    sub    $59             ; 001C6A D6 59 
    jp     nz,$1bcc        ; 001C6C C2 CC 1B 
    ld     b,a             ; 001C6F 47 
    ld     a,(hl)          ; 001C70 7E 
    or     a               ; 001C71 B7 
    jr     z,$1c7d         ; 001C72 28 09 
    cp     b               ; 001C74 B8 
    jr     z,$1c5b         ; 001C75 28 E4 
    inc    hl              ; 001C77 23 
    ld     (de),a          ; 001C78 12 
    inc    c               ; 001C79 0C 
    inc    de              ; 001C7A 13 
    jr     $1c70           ; 001C7B 18 F3 
    ld     hl,$0005        ; 001C7D 21 05 00 
    ld     b,h             ; 001C80 44 
    add    hl,bc           ; 001C81 09 
    ld     b,h             ; 001C82 44 
    ld     c,l             ; 001C83 4D 
    ld     hl,($78a7)      ; 001C84 2A A7 78 
    dec    hl              ; 001C87 2B 
    dec    hl              ; 001C88 2B 
    dec    hl              ; 001C89 2B 
    ld     (de),a          ; 001C8A 12 
    inc    de              ; 001C8B 13 
    ld     (de),a          ; 001C8C 12 
    inc    de              ; 001C8D 13 
    ld     (de),a          ; 001C8E 12 
    ret                    ; 001C8F C9 
    ld     a,h             ; 001C90 7C 
    sub    d               ; 001C91 92 
    ret    nz              ; 001C92 C0 
    ld     a,l             ; 001C93 7D 
    sub    e               ; 001C94 93 
    ret                    ; 001C95 C9 
    ld     a,(hl)          ; 001C96 7E 
    ex     (sp),hl         ; 001C97 E3 
    cp     (hl)            ; 001C98 BE 
    inc    hl              ; 001C99 23 
    ex     (sp),hl         ; 001C9A E3 
    jp     z,$1d78         ; 001C9B CA 78 1D 
    jp     $1997           ; 001C9E C3 97 19 
    ld     a,$64           ; 001CA1 3E 64 
    ld     ($78dc),a       ; 001CA3 32 DC 78 
    call   $1f21           ; 001CA6 CD 21 1F 
    ex     (sp),hl         ; 001CA9 E3 
    call   $1936           ; 001CAA CD 36 19 
    pop    de              ; 001CAD D1 
    jr     nz,$1cb5        ; 001CAE 20 05 
    add    hl,bc           ; 001CB0 09 
    ld     sp,hl           ; 001CB1 F9 
    ld     ($78e8),hl      ; 001CB2 22 E8 78 
    ex     de,hl           ; 001CB5 EB 
    ld     c,$08           ; 001CB6 0E 08 
    call   $1963           ; 001CB8 CD 63 19 
    push   hl              ; 001CBB E5 
    call   $1f05           ; 001CBC CD 05 1F 
    ex     (sp),hl         ; 001CBF E3 
    push   hl              ; 001CC0 E5 
    ld     hl,($78a2)      ; 001CC1 2A A2 78 
    ex     (sp),hl         ; 001CC4 E3 
    rst    08h             ; 001CC5 CF 
    cp     l               ; 001CC6 BD 
    rst    20h             ; 001CC7 E7 
    jp     z,$0af6         ; 001CC8 CA F6 0A 
    jp     nc,$0af6        ; 001CCB D2 F6 0A 
    push   af              ; 001CCE F5 
    call   $2337           ; 001CCF CD 37 23 
    pop    af              ; 001CD2 F1 
    push   hl              ; 001CD3 E5 
    jp     p,$1cec         ; 001CD4 F2 EC 1C 
    call   $0a7f           ; 001CD7 CD 7F 0A 
    ex     (sp),hl         ; 001CDA E3 
    ld     de,$0001        ; 001CDB 11 01 00 
    ld     a,(hl)          ; 001CDE 7E 
    cp     $cc             ; 001CDF FE CC 
    call   z,$2b01         ; 001CE1 CC 01 2B 
    push   de              ; 001CE4 D5 
    push   hl              ; 001CE5 E5 
    ex     de,hl           ; 001CE6 EB 
    call   $099e           ; 001CE7 CD 9E 09 
    jr     $1d0e           ; 001CEA 18 22 
    call   $0ab1           ; 001CEC CD B1 0A 
    call   $09bf           ; 001CEF CD BF 09 
    pop    hl              ; 001CF2 E1 
    push   bc              ; 001CF3 C5 
    push   de              ; 001CF4 D5 
    ld     bc,$8100        ; 001CF5 01 00 81 
    ld     d,c             ; 001CF8 51 
    ld     e,d             ; 001CF9 5A 
    ld     a,(hl)          ; 001CFA 7E 
    cp     $cc             ; 001CFB FE CC 
    ld     a,$01           ; 001CFD 3E 01 
    jr     nz,$1d0f        ; 001CFF 20 0E 
    call   $2338           ; 001D01 CD 38 23 
    push   hl              ; 001D04 E5 
    call   $0ab1           ; 001D05 CD B1 0A 
    call   $09bf           ; 001D08 CD BF 09 
    call   $0955           ; 001D0B CD 55 09 
    pop    hl              ; 001D0E E1 
    push   bc              ; 001D0F C5 
    push   de              ; 001D10 D5 
    ld     c,a             ; 001D11 4F 
    rst    20h             ; 001D12 E7 
    ld     b,a             ; 001D13 47 
    push   bc              ; 001D14 C5 
    push   hl              ; 001D15 E5 
    ld     hl,($78df)      ; 001D16 2A DF 78 
    ex     (sp),hl         ; 001D19 E3 
    ld     b,$81           ; 001D1A 06 81 
    push   bc              ; 001D1C C5 
    inc    sp              ; 001D1D 33 
    call   $0358           ; 001D1E CD 58 03 
    or     a               ; 001D21 B7 
    call   nz,$1da0        ; 001D22 C4 A0 1D 
    ld     ($78e6),hl      ; 001D25 22 E6 78 
    ld     ($78e8),sp      ; 001D28 ED 73 E8 78 
    ld     a,(hl)          ; 001D2C 7E 
    cp     $3a             ; 001D2D FE 3A 
    jr     z,$1d5a         ; 001D2F 28 29 
    or     a               ; 001D31 B7 
    jp     nz,$1997        ; 001D32 C2 97 19 
    inc    hl              ; 001D35 23 
    ld     a,(hl)          ; 001D36 7E 
    inc    hl              ; 001D37 23 
    or     (hl)            ; 001D38 B6 
    jp     z,$197e         ; 001D39 CA 7E 19 
    inc    hl              ; 001D3C 23 
    ld     e,(hl)          ; 001D3D 5E 
    inc    hl              ; 001D3E 23 
    ld     d,(hl)          ; 001D3F 56 
    ex     de,hl           ; 001D40 EB 
    ld     ($78a2),hl      ; 001D41 22 A2 78 
    ld     a,($791b)       ; 001D44 3A 1B 79 
    or     a               ; 001D47 B7 
    jr     z,$1d59         ; 001D48 28 0F 
    push   de              ; 001D4A D5 
    ld     a,$3c           ; 001D4B 3E 3C 
    call   $032a           ; 001D4D CD 2A 03 
    call   $0faf           ; 001D50 CD AF 0F 
    ld     a,$3e           ; 001D53 3E 3E 
    call   $032a           ; 001D55 CD 2A 03 
    pop    de              ; 001D58 D1 
    ex     de,hl           ; 001D59 EB 
    rst    10h             ; 001D5A D7 
    ld     de,$1d1e        ; 001D5B 11 1E 1D 
    push   de              ; 001D5E D5 
    ret    z               ; 001D5F C8 
    sub    $80             ; 001D60 D6 80 
    jp     c,$1f21         ; 001D62 DA 21 1F 
    cp     $3c             ; 001D65 FE 3C 
    jp     nc,$2ae7        ; 001D67 D2 E7 2A 
    rlca                   ; 001D6A 07 
    ld     c,a             ; 001D6B 4F 
    ld     b,$00           ; 001D6C 06 00 
    ex     de,hl           ; 001D6E EB 
    ld     hl,$1822        ; 001D6F 21 22 18 
    add    hl,bc           ; 001D72 09 
    ld     c,(hl)          ; 001D73 4E 
    inc    hl              ; 001D74 23 
    ld     b,(hl)          ; 001D75 46 
    push   bc              ; 001D76 C5 
    ex     de,hl           ; 001D77 EB 
    inc    hl              ; 001D78 23 
    ld     a,(hl)          ; 001D79 7E 
    cp     $3a             ; 001D7A FE 3A 
    ret    nc              ; 001D7C D0 
    cp     $20             ; 001D7D FE 20 
    jp     z,$1d78         ; 001D7F CA 78 1D 
    cp     $0b             ; 001D82 FE 0B 
    jr     nc,$1d8b        ; 001D84 30 05 
    cp     $09             ; 001D86 FE 09 
    jp     nc,$1d78        ; 001D88 D2 78 1D 
    cp     $30             ; 001D8B FE 30 
    ccf                    ; 001D8D 3F 
    inc    a               ; 001D8E 3C 
    dec    a               ; 001D8F 3D 
    ret                    ; 001D90 C9 
    ex     de,hl           ; 001D91 EB 
    ld     hl,($78a4)      ; 001D92 2A A4 78 
    dec    hl              ; 001D95 2B 
    ld     ($78ff),hl      ; 001D96 22 FF 78 
    ex     de,hl           ; 001D99 EB 
    ret                    ; 001D9A C9 
    call   $0358           ; 001D9B CD 58 03 
    or     a               ; 001D9E B7 
    ret    z               ; 001D9F C8 
    nop                    ; 001DA0 00 
    nop                    ; 001DA1 00 
    nop                    ; 001DA2 00 
    nop                    ; 001DA3 00 
    nop                    ; 001DA4 00 
    ld     ($7899),a       ; 001DA5 32 99 78 
    dec    a               ; 001DA8 3D 
    ret    nz              ; 001DA9 C0 
    inc    a               ; 001DAA 3C 
    jp     $1db4           ; 001DAB C3 B4 1D 
    ret    nz              ; 001DAE C0 
    push   af              ; 001DAF F5 
    call   z,$79bb         ; 001DB0 CC BB 79 
    pop    af              ; 001DB3 F1 
    ld     ($78e6),hl      ; 001DB4 22 E6 78 
    ld     hl,$78b5        ; 001DB7 21 B5 78 
    ld     ($78b3),hl      ; 001DBA 22 B3 78 
    ld     hl,$fff6        ; 001DBD 21 F6 FF 
    pop    bc              ; 001DC0 C1 
    ld     hl,($78a2)      ; 001DC1 2A A2 78 
    push   hl              ; 001DC4 E5 
    push   af              ; 001DC5 F5 
    ld     a,l             ; 001DC6 7D 
    and    h               ; 001DC7 A4 
    inc    a               ; 001DC8 3C 
    jr     z,$1dd4         ; 001DC9 28 09 
    ld     ($78f5),hl      ; 001DCB 22 F5 78 
    ld     hl,($78e6)      ; 001DCE 2A E6 78 
    ld     ($78f7),hl      ; 001DD1 22 F7 78 
    call   $038b           ; 001DD4 CD 8B 03 
    call   $20f9           ; 001DD7 CD F9 20 
    pop    af              ; 001DDA F1 
    ld     hl,$1930        ; 001DDB 21 30 19 
    jp     nz,$1a06        ; 001DDE C2 06 1A 
    jp     $1a18           ; 001DE1 C3 18 1A 
    ld     hl,($78f7)      ; 001DE4 2A F7 78 
    ld     a,h             ; 001DE7 7C 
    or     l               ; 001DE8 B5 
    ld     e,$20           ; 001DE9 1E 20 
    jp     z,$19a2         ; 001DEB CA A2 19 
    ex     de,hl           ; 001DEE EB 
    ld     hl,($78f5)      ; 001DEF 2A F5 78 
    ld     ($78a2),hl      ; 001DF2 22 A2 78 
    ex     de,hl           ; 001DF5 EB 
    ret                    ; 001DF6 C9 
    ld     a,$af           ; 001DF7 3E AF 
    ld     ($791b),a       ; 001DF9 32 1B 79 
    ret                    ; 001DFC C9 
    pop    af              ; 001DFD F1 
    pop    hl              ; 001DFE E1 
    ret                    ; 001DFF C9 
    ld     e,$03           ; 001E00 1E 03 
    ld     bc,$021e        ; 001E02 01 1E 02 
    ld     bc,$041e        ; 001E05 01 1E 04 
    ld     bc,$081e        ; 001E08 01 1E 08 
    call   $1e3d           ; 001E0B CD 3D 1E 
    ld     bc,$1997        ; 001E0E 01 97 19 
    push   bc              ; 001E11 C5 
    ret    c               ; 001E12 D8 
    sub    $41             ; 001E13 D6 41 
    ld     c,a             ; 001E15 4F 
    ld     b,a             ; 001E16 47 
    rst    10h             ; 001E17 D7 
    cp     $ce             ; 001E18 FE CE 
    jr     nz,$1e25        ; 001E1A 20 09 
    rst    10h             ; 001E1C D7 
    call   $1e3d           ; 001E1D CD 3D 1E 
    ret    c               ; 001E20 D8 
    sub    $41             ; 001E21 D6 41 
    ld     b,a             ; 001E23 47 
    rst    10h             ; 001E24 D7 
    ld     a,b             ; 001E25 78 
    sub    c               ; 001E26 91 
    ret    c               ; 001E27 D8 
    inc    a               ; 001E28 3C 
    ex     (sp),hl         ; 001E29 E3 
    ld     hl,$7901        ; 001E2A 21 01 79 
    ld     b,$00           ; 001E2D 06 00 
    add    hl,bc           ; 001E2F 09 
    ld     (hl),e          ; 001E30 73 
    inc    hl              ; 001E31 23 
    dec    a               ; 001E32 3D 
    jr     nz,$1e30        ; 001E33 20 FB 
    pop    hl              ; 001E35 E1 
    ld     a,(hl)          ; 001E36 7E 
    cp     $2c             ; 001E37 FE 2C 
    ret    nz              ; 001E39 C0 
    rst    10h             ; 001E3A D7 
    jr     $1e0b           ; 001E3B 18 CE 
    ld     a,(hl)          ; 001E3D 7E 
    cp     $41             ; 001E3E FE 41 
    ret    c               ; 001E40 D8 
    cp     $5b             ; 001E41 FE 5B 
    ccf                    ; 001E43 3F 
    ret                    ; 001E44 C9 
    rst    10h             ; 001E45 D7 
    call   $2b02           ; 001E46 CD 02 2B 
    ret    p               ; 001E49 F0 
    ld     e,$08           ; 001E4A 1E 08 
    jp     $19a2           ; 001E4C C3 A2 19 
    ld     a,(hl)          ; 001E4F 7E 
    cp     $2e             ; 001E50 FE 2E 
    ex     de,hl           ; 001E52 EB 
    ld     hl,($78ec)      ; 001E53 2A EC 78 
    ex     de,hl           ; 001E56 EB 
    jp     z,$1d78         ; 001E57 CA 78 1D 
    dec    hl              ; 001E5A 2B 
    ld     de,$0000        ; 001E5B 11 00 00 
    rst    10h             ; 001E5E D7 
    ret    nc              ; 001E5F D0 
    push   hl              ; 001E60 E5 
    push   af              ; 001E61 F5 
    ld     hl,$1998        ; 001E62 21 98 19 
    rst    18h             ; 001E65 DF 
    jp     c,$1997         ; 001E66 DA 97 19 
    ld     h,d             ; 001E69 62 
    ld     l,e             ; 001E6A 6B 
    add    hl,de           ; 001E6B 19 
    add    hl,hl           ; 001E6C 29 
    add    hl,de           ; 001E6D 19 
    add    hl,hl           ; 001E6E 29 
    pop    af              ; 001E6F F1 
    sub    $30             ; 001E70 D6 30 
    ld     e,a             ; 001E72 5F 
    ld     d,$00           ; 001E73 16 00 
    add    hl,de           ; 001E75 19 
    ex     de,hl           ; 001E76 EB 
    pop    hl              ; 001E77 E1 
    jr     $1e5e           ; 001E78 18 E4 
    jp     z,$1b61         ; 001E7A CA 61 1B 
    call   $1e46           ; 001E7D CD 46 1E 
    dec    hl              ; 001E80 2B 
    rst    10h             ; 001E81 D7 
    ret    nz              ; 001E82 C0 
    push   hl              ; 001E83 E5 
    ld     hl,($78b1)      ; 001E84 2A B1 78 
    ld     a,l             ; 001E87 7D 
    sub    e               ; 001E88 93 
    ld     e,a             ; 001E89 5F 
    ld     a,h             ; 001E8A 7C 
    sbc    a,d             ; 001E8B 9A 
    ld     d,a             ; 001E8C 57 
    jp     c,$197a         ; 001E8D DA 7A 19 
    ld     hl,($78f9)      ; 001E90 2A F9 78 
    ld     bc,$0028        ; 001E93 01 28 00 
    add    hl,bc           ; 001E96 09 
    rst    18h             ; 001E97 DF 
    jp     nc,$197a        ; 001E98 D2 7A 19 
    ex     de,hl           ; 001E9B EB 
    ld     ($78a0),hl      ; 001E9C 22 A0 78 
    pop    hl              ; 001E9F E1 
    jp     $1b61           ; 001EA0 C3 61 1B 
    jp     z,$1b5d         ; 001EA3 CA 5D 1B 
    call   $79c7           ; 001EA6 CD C7 79 
    call   $1b61           ; 001EA9 CD 61 1B 
    ld     bc,$1d1e        ; 001EAC 01 1E 1D 
    jr     $1ec1           ; 001EAF 18 10 
    ld     c,$03           ; 001EB1 0E 03 
    call   $1963           ; 001EB3 CD 63 19 
    pop    bc              ; 001EB6 C1 
    push   hl              ; 001EB7 E5 
    push   hl              ; 001EB8 E5 
    ld     hl,($78a2)      ; 001EB9 2A A2 78 
    ex     (sp),hl         ; 001EBC E3 
    ld     a,$91           ; 001EBD 3E 91 
    push   af              ; 001EBF F5 
    inc    sp              ; 001EC0 33 
    push   bc              ; 001EC1 C5 
    call   $1e5a           ; 001EC2 CD 5A 1E 
    call   $1f07           ; 001EC5 CD 07 1F 
    push   hl              ; 001EC8 E5 
    ld     hl,($78a2)      ; 001EC9 2A A2 78 
    rst    18h             ; 001ECC DF 
    pop    hl              ; 001ECD E1 
    inc    hl              ; 001ECE 23 
    call   c,$1b2f         ; 001ECF DC 2F 1B 
    call   nc,$1b2c        ; 001ED2 D4 2C 1B 
    ld     h,b             ; 001ED5 60 
    ld     l,c             ; 001ED6 69 
    dec    hl              ; 001ED7 2B 
    ret    c               ; 001ED8 D8 
    ld     e,$0e           ; 001ED9 1E 0E 
    jp     $19a2           ; 001EDB C3 A2 19 
    ret    nz              ; 001EDE C0 
    ld     d,$ff           ; 001EDF 16 FF 
    call   $1936           ; 001EE1 CD 36 19 
    ld     sp,hl           ; 001EE4 F9 
    ld     ($78e8),hl      ; 001EE5 22 E8 78 
    cp     $91             ; 001EE8 FE 91 
    ld     e,$04           ; 001EEA 1E 04 
    jp     nz,$19a2        ; 001EEC C2 A2 19 
    pop    hl              ; 001EEF E1 
    ld     ($78a2),hl      ; 001EF0 22 A2 78 
    inc    hl              ; 001EF3 23 
    ld     a,h             ; 001EF4 7C 
    or     l               ; 001EF5 B5 
    jr     nz,$1eff        ; 001EF6 20 07 
    ld     a,($78dd)       ; 001EF8 3A DD 78 
    or     a               ; 001EFB B7 
    jp     nz,$1a18        ; 001EFC C2 18 1A 
    ld     hl,$1d1e        ; 001EFF 21 1E 1D 
    ex     (sp),hl         ; 001F02 E3 
    ld     a,$e1           ; 001F03 3E E1 
    ld     bc,$0e3a        ; 001F05 01 3A 0E 
    nop                    ; 001F08 00 
    ld     b,$00           ; 001F09 06 00 
    ld     a,c             ; 001F0B 79 
    ld     c,b             ; 001F0C 48 
    ld     b,a             ; 001F0D 47 
    ld     a,(hl)          ; 001F0E 7E 
    or     a               ; 001F0F B7 
    ret    z               ; 001F10 C8 
    cp     b               ; 001F11 B8 
    ret    z               ; 001F12 C8 
    inc    hl              ; 001F13 23 
    cp     $22             ; 001F14 FE 22 
    jr     z,$1f0b         ; 001F16 28 F3 
    sub    $8f             ; 001F18 D6 8F 
    jr     nz,$1f0e        ; 001F1A 20 F2 
    cp     b               ; 001F1C B8 
    adc    a,d             ; 001F1D 8A 
    ld     d,a             ; 001F1E 57 
    jr     $1f0e           ; 001F1F 18 ED 
    call   $260d           ; 001F21 CD 0D 26 
    rst    08h             ; 001F24 CF 
    push   de              ; 001F25 D5 
    ex     de,hl           ; 001F26 EB 
    ld     ($78df),hl      ; 001F27 22 DF 78 
    ex     de,hl           ; 001F2A EB 
    push   de              ; 001F2B D5 
    rst    20h             ; 001F2C E7 
    push   af              ; 001F2D F5 
    call   $2337           ; 001F2E CD 37 23 
    pop    af              ; 001F31 F1 
    ex     (sp),hl         ; 001F32 E3 
    add    a,$03           ; 001F33 C6 03 
    call   $2819           ; 001F35 CD 19 28 
    call   $0a03           ; 001F38 CD 03 0A 
    push   hl              ; 001F3B E5 
    jr     nz,$1f66        ; 001F3C 20 28 
    ld     hl,($7921)      ; 001F3E 2A 21 79 
    push   hl              ; 001F41 E5 
    inc    hl              ; 001F42 23 
    ld     e,(hl)          ; 001F43 5E 
    inc    hl              ; 001F44 23 
    ld     d,(hl)          ; 001F45 56 
    ld     hl,($78a4)      ; 001F46 2A A4 78 
    rst    18h             ; 001F49 DF 
    jr     nc,$1f5a        ; 001F4A 30 0E 
    ld     hl,($78a0)      ; 001F4C 2A A0 78 
    rst    18h             ; 001F4F DF 
    pop    de              ; 001F50 D1 
    jr     nc,$1f62        ; 001F51 30 0F 
    ld     hl,($78f9)      ; 001F53 2A F9 78 
    rst    18h             ; 001F56 DF 
    jr     nc,$1f62        ; 001F57 30 09 
    ld     a,$d1           ; 001F59 3E D1 
    call   $29f5           ; 001F5B CD F5 29 
    ex     de,hl           ; 001F5E EB 
    call   $2843           ; 001F5F CD 43 28 
    call   $29f5           ; 001F62 CD F5 29 
    ex     (sp),hl         ; 001F65 E3 
    call   $09d3           ; 001F66 CD D3 09 
    pop    de              ; 001F69 D1 
    pop    hl              ; 001F6A E1 
    ret                    ; 001F6B C9 
    cp     $9e             ; 001F6C FE 9E 
    jr     nz,$1f95        ; 001F6E 20 25 
    rst    10h             ; 001F70 D7 
    rst    08h             ; 001F71 CF 
    adc    a,l             ; 001F72 8D 
    call   $1e5a           ; 001F73 CD 5A 1E 
    ld     a,d             ; 001F76 7A 
    or     e               ; 001F77 B3 
    jr     z,$1f83         ; 001F78 28 09 
    call   $1b2a           ; 001F7A CD 2A 1B 
    ld     d,b             ; 001F7D 50 
    ld     e,c             ; 001F7E 59 
    pop    hl              ; 001F7F E1 
    jp     nc,$1ed9        ; 001F80 D2 D9 1E 
    ex     de,hl           ; 001F83 EB 
    ld     ($78f0),hl      ; 001F84 22 F0 78 
    ex     de,hl           ; 001F87 EB 
    ret    c               ; 001F88 D8 
    ld     a,($78f2)       ; 001F89 3A F2 78 
    or     a               ; 001F8C B7 
    ret    z               ; 001F8D C8 
    ld     a,($789a)       ; 001F8E 3A 9A 78 
    ld     e,a             ; 001F91 5F 
    jp     $19ab           ; 001F92 C3 AB 19 
    call   $2b1c           ; 001F95 CD 1C 2B 
    ld     a,(hl)          ; 001F98 7E 
    ld     b,a             ; 001F99 47 
    cp     $91             ; 001F9A FE 91 
    jr     z,$1fa1         ; 001F9C 28 03 
    rst    08h             ; 001F9E CF 
    adc    a,l             ; 001F9F 8D 
    dec    hl              ; 001FA0 2B 
    ld     c,e             ; 001FA1 4B 
    dec    c               ; 001FA2 0D 
    ld     a,b             ; 001FA3 78 
    jp     z,$1d60         ; 001FA4 CA 60 1D 
    call   $1e5b           ; 001FA7 CD 5B 1E 
    cp     $2c             ; 001FAA FE 2C 
    ret    nz              ; 001FAC C0 
    jr     $1fa2           ; 001FAD 18 F3 
    ld     de,$78f2        ; 001FAF 11 F2 78 
    ld     a,(de)          ; 001FB2 1A 
    or     a               ; 001FB3 B7 
    jp     z,$19a0         ; 001FB4 CA A0 19 
    inc    a               ; 001FB7 3C 
    ld     ($789a),a       ; 001FB8 32 9A 78 
    ld     (de),a          ; 001FBB 12 
    ld     a,(hl)          ; 001FBC 7E 
    cp     $87             ; 001FBD FE 87 
    jr     z,$1fcd         ; 001FBF 28 0C 
    call   $1e5a           ; 001FC1 CD 5A 1E 
    ret    nz              ; 001FC4 C0 
    ld     a,d             ; 001FC5 7A 
    or     e               ; 001FC6 B3 
    jp     nz,$1ec5        ; 001FC7 C2 C5 1E 
    inc    a               ; 001FCA 3C 
    jr     $1fcf           ; 001FCB 18 02 
    rst    10h             ; 001FCD D7 
    ret    nz              ; 001FCE C0 
    ld     hl,($78ee)      ; 001FCF 2A EE 78 
    ex     de,hl           ; 001FD2 EB 
    ld     hl,($78ea)      ; 001FD3 2A EA 78 
    ld     ($78a2),hl      ; 001FD6 22 A2 78 
    ex     de,hl           ; 001FD9 EB 
    ret    nz              ; 001FDA C0 
    ld     a,(hl)          ; 001FDB 7E 
    or     a               ; 001FDC B7 
    jr     nz,$1fe3        ; 001FDD 20 04 
    inc    hl              ; 001FDF 23 
    inc    hl              ; 001FE0 23 
    inc    hl              ; 001FE1 23 
    inc    hl              ; 001FE2 23 
    inc    hl              ; 001FE3 23 
    ld     a,d             ; 001FE4 7A 
    and    e               ; 001FE5 A3 
    inc    a               ; 001FE6 3C 
    jp     nz,$1f05        ; 001FE7 C2 05 1F 
    ld     a,($78dd)       ; 001FEA 3A DD 78 
    dec    a               ; 001FED 3D 
    jp     z,$1dbe         ; 001FEE CA BE 1D 
    jp     $1f05           ; 001FF1 C3 05 1F 
    call   $2b1c           ; 001FF4 CD 1C 2B 
    ret    nz              ; 001FF7 C0 
    or     a               ; 001FF8 B7 
    jp     z,$1e4a         ; 001FF9 CA 4A 1E 
    dec    a               ; 001FFC 3D 
    add    a,a             ; 001FFD 87 
    ld     e,a             ; 001FFE 5F 
    cp     $2d             ; 001FFF FE 2D 
    jr     c,$2005         ; 002001 38 02 
    ld     e,$26           ; 002003 1E 26 
    jp     $19a2           ; 002005 C3 A2 19 
    ld     de,$000a        ; 002008 11 0A 00 
    push   de              ; 00200B D5 
    jr     z,$2025         ; 00200C 28 17 
    call   $1e4f           ; 00200E CD 4F 1E 
    ex     de,hl           ; 002011 EB 
    ex     (sp),hl         ; 002012 E3 
    jr     z,$2026         ; 002013 28 11 
    ex     de,hl           ; 002015 EB 
    rst    08h             ; 002016 CF 
    inc    l               ; 002017 2C 
    ex     de,hl           ; 002018 EB 
    ld     hl,($78e4)      ; 002019 2A E4 78 
    ex     de,hl           ; 00201C EB 
    jr     z,$2025         ; 00201D 28 06 
    call   $1e5a           ; 00201F CD 5A 1E 
    jp     nz,$1997        ; 002022 C2 97 19 
    ex     de,hl           ; 002025 EB 
    ld     a,h             ; 002026 7C 
    or     l               ; 002027 B5 
    jp     z,$1e4a         ; 002028 CA 4A 1E 
    ld     ($78e4),hl      ; 00202B 22 E4 78 
    ld     ($78e1),a       ; 00202E 32 E1 78 
    pop    hl              ; 002031 E1 
    ld     ($78e2),hl      ; 002032 22 E2 78 
    pop    bc              ; 002035 C1 
    jp     $1a33           ; 002036 C3 33 1A 
    call   $2337           ; 002039 CD 37 23 
    ld     a,(hl)          ; 00203C 7E 
    cp     $2c             ; 00203D FE 2C 
    call   z,$1d78         ; 00203F CC 78 1D 
    cp     $ca             ; 002042 FE CA 
    call   z,$1d78         ; 002044 CC 78 1D 
    dec    hl              ; 002047 2B 
    push   hl              ; 002048 E5 
    call   $0994           ; 002049 CD 94 09 
    pop    hl              ; 00204C E1 
    jr     z,$2056         ; 00204D 28 07 
    rst    10h             ; 00204F D7 
    jp     c,$1ec2         ; 002050 DA C2 1E 
    jp     $1d5f           ; 002053 C3 5F 1D 
    ld     d,$01           ; 002056 16 01 
    call   $1f05           ; 002058 CD 05 1F 
    or     a               ; 00205B B7 
    ret    z               ; 00205C C8 
    rst    10h             ; 00205D D7 
    cp     $95             ; 00205E FE 95 
    jr     nz,$2058        ; 002060 20 F6 
    dec    d               ; 002062 15 
    jr     nz,$2058        ; 002063 20 F3 
    jr     $204f           ; 002065 18 E8 
    ld     a,$01           ; 002067 3E 01 
    ld     ($789c),a       ; 002069 32 9C 78 
    jp     $209b           ; 00206C C3 9B 20 
    call   $79ca           ; 00206F CD CA 79 
    cp     $40             ; 002072 FE 40 
    jr     nz,$208f        ; 002074 20 19 
    call   $2b01           ; 002076 CD 01 2B 
    cp     $02             ; 002079 FE 02 
    jp     nc,$1e4a        ; 00207B D2 4A 1E 
    push   hl              ; 00207E E5 
    ld     hl,$7000        ; 00207F 21 00 70 
    add    hl,de           ; 002082 19 
    ld     ($7820),hl      ; 002083 22 20 78 
    ld     a,e             ; 002086 7B 
    and    $1f             ; 002087 E6 1F 
    ld     ($78a6),a       ; 002089 32 A6 78 
    pop    hl              ; 00208C E1 
    rst    08h             ; 00208D CF 
    inc    l               ; 00208E 2C 
    cp     $23             ; 00208F FE 23 
    jr     nz,$209b        ; 002091 20 08 
    call   $3b58           ; 002093 CD 58 3B 
    ld     a,$80           ; 002096 3E 80 
    ld     ($789c),a       ; 002098 32 9C 78 
    dec    hl              ; 00209B 2B 
    rst    10h             ; 00209C D7 
    call   z,$20fe         ; 00209D CC FE 20 
    jp     z,$2169         ; 0020A0 CA 69 21 
    cp     $bf             ; 0020A3 FE BF 
    jp     z,$2cbd         ; 0020A5 CA BD 2C 
    cp     $bc             ; 0020A8 FE BC 
    jp     z,$2137         ; 0020AA CA 37 21 
    push   hl              ; 0020AD E5 
    cp     $2c             ; 0020AE FE 2C 
    jp     z,$2108         ; 0020B0 CA 08 21 
    cp     $3b             ; 0020B3 FE 3B 
    jp     z,$3b0c         ; 0020B5 CA 0C 3B 
    pop    bc              ; 0020B8 C1 
    call   $2337           ; 0020B9 CD 37 23 
    push   hl              ; 0020BC E5 
    rst    20h             ; 0020BD E7 
    jr     z,$20f2         ; 0020BE 28 32 
    call   $0fbd           ; 0020C0 CD BD 0F 
    call   $2865           ; 0020C3 CD 65 28 
    call   $79cd           ; 0020C6 CD CD 79 
    ld     hl,($7921)      ; 0020C9 2A 21 79 
    ld     a,($789c)       ; 0020CC 3A 9C 78 
    or     a               ; 0020CF B7 
    jp     m,$20e9         ; 0020D0 FA E9 20 
    jr     z,$20dd         ; 0020D3 28 08 
    ld     a,($789b)       ; 0020D5 3A 9B 78 
    add    a,(hl)          ; 0020D8 86 
    cp     $84             ; 0020D9 FE 84 
    jr     $20e6           ; 0020DB 18 09 
    ld     a,($789d)       ; 0020DD 3A 9D 78 
    ld     b,a             ; 0020E0 47 
    ld     a,($78a6)       ; 0020E1 3A A6 78 
    add    a,(hl)          ; 0020E4 86 
    cp     b               ; 0020E5 B8 
    call   nc,$20fe        ; 0020E6 D4 FE 20 
    call   $28aa           ; 0020E9 CD AA 28 
    ld     a,$20           ; 0020EC 3E 20 
    call   $032a           ; 0020EE CD 2A 03 
    or     a               ; 0020F1 B7 
    call   z,$28aa         ; 0020F2 CC AA 28 
    pop    hl              ; 0020F5 E1 
    jp     $209b           ; 0020F6 C3 9B 20 
    call   $3b1c           ; 0020F9 CD 1C 3B 
    or     a               ; 0020FC B7 
    ret    z               ; 0020FD C8 
    ld     a,$0d           ; 0020FE 3E 0D 
    call   $032a           ; 002100 CD 2A 03 
    call   $79d0           ; 002103 CD D0 79 
    xor    a               ; 002106 AF 
    ret                    ; 002107 C9 
    call   $79d3           ; 002108 CD D3 79 
    ld     a,($789c)       ; 00210B 3A 9C 78 
    or     a               ; 00210E B7 
    jp     p,$2119         ; 00210F F2 19 21 
    ld     a,$2c           ; 002112 3E 2C 
    call   $032a           ; 002114 CD 2A 03 
    jr     $2164           ; 002117 18 4B 
    jr     z,$2123         ; 002119 28 08 
    ld     a,($789b)       ; 00211B 3A 9B 78 
    cp     $70             ; 00211E FE 70 
    jp     $212b           ; 002120 C3 2B 21 
    ld     a,($789e)       ; 002123 3A 9E 78 
    ld     b,a             ; 002126 47 
    ld     a,($7aae)       ; 002127 3A AE 7A 
    cp     b               ; 00212A B8 
    call   nc,$20fe        ; 00212B D4 FE 20 
    jr     nc,$2164        ; 00212E 30 34 
    sub    $10             ; 002130 D6 10 
    jr     nc,$2130        ; 002132 30 FC 
    cpl                    ; 002134 2F 
    jr     $215a           ; 002135 18 23 
    call   $2b1b           ; 002137 CD 1B 2B 
    and    $3f             ; 00213A E6 3F 
    ld     e,a             ; 00213C 5F 
    rst    08h             ; 00213D CF 
    add    hl,hl           ; 00213E 29 
    dec    hl              ; 00213F 2B 
    push   hl              ; 002140 E5 
    call   $79d3           ; 002141 CD D3 79 
    ld     a,($789c)       ; 002144 3A 9C 78 
    or     a               ; 002147 B7 
    jp     m,$1e4a         ; 002148 FA 4A 1E 
    jp     z,$2153         ; 00214B CA 53 21 
    ld     a,($789b)       ; 00214E 3A 9B 78 
    jr     $2156           ; 002151 18 03 
    ld     a,($78a6)       ; 002153 3A A6 78 
    cpl                    ; 002156 2F 
    add    a,e             ; 002157 83 
    jr     nc,$2164        ; 002158 30 0A 
    inc    a               ; 00215A 3C 
    ld     b,a             ; 00215B 47 
    ld     a,$20           ; 00215C 3E 20 
    call   $032a           ; 00215E CD 2A 03 
    dec    b               ; 002161 05 
    jr     nz,$215e        ; 002162 20 FA 
    pop    hl              ; 002164 E1 
    rst    10h             ; 002165 D7 
    jp     $20a0           ; 002166 C3 A0 20 
    ld     a,($789c)       ; 002169 3A 9C 78 
    nop                    ; 00216C 00 
    nop                    ; 00216D 00 
    nop                    ; 00216E 00 
    nop                    ; 00216F 00 
    xor    a               ; 002170 AF 
    ld     ($789c),a       ; 002171 32 9C 78 
    call   $79be           ; 002174 CD BE 79 
    ret                    ; 002177 C9 
    ccf                    ; 002178 3F 
    ld     d,d             ; 002179 52 
    ld     b,l             ; 00217A 45 
    ld     b,h             ; 00217B 44 
    ld     c,a             ; 00217C 4F 
    dec    c               ; 00217D 0D 
    nop                    ; 00217E 00 
    ld     a,($78de)       ; 00217F 3A DE 78 
    or     a               ; 002182 B7 
    jp     nz,$1991        ; 002183 C2 91 19 
    ld     a,($78a9)       ; 002186 3A A9 78 
    or     a               ; 002189 B7 
    ld     e,$2a           ; 00218A 1E 2A 
    jp     z,$19a2         ; 00218C CA A2 19 
    pop    bc              ; 00218F C1 
    ld     hl,$2178        ; 002190 21 78 21 
    call   $28a7           ; 002193 CD A7 28 
    ld     hl,($78e6)      ; 002196 2A E6 78 
    ret                    ; 002199 C9 
    call   $2828           ; 00219A CD 28 28 
    ld     a,(hl)          ; 00219D 7E 
    call   $79d6           ; 00219E CD D6 79 
    sub    $23             ; 0021A1 D6 23 
    ld     ($78a9),a       ; 0021A3 32 A9 78 
    ld     a,(hl)          ; 0021A6 7E 
    jr     nz,$21c9        ; 0021A7 20 20 
    call   $3b68           ; 0021A9 CD 68 3B 
    push   hl              ; 0021AC E5 
    ld     b,$fa           ; 0021AD 06 FA 
    ld     hl,($78a7)      ; 0021AF 2A A7 78 
    call   $3b88           ; 0021B2 CD 88 3B 
    ld     (hl),a          ; 0021B5 77 
    inc    hl              ; 0021B6 23 
    cp     $0d             ; 0021B7 FE 0D 
    jr     z,$21bd         ; 0021B9 28 02 
    djnz   $21b2           ; 0021BB 10 F5 
    dec    hl              ; 0021BD 2B 
    ld     (hl),$00        ; 0021BE 36 00 
    nop                    ; 0021C0 00 
    nop                    ; 0021C1 00 
    nop                    ; 0021C2 00 
    ld     hl,($78a7)      ; 0021C3 2A A7 78 
    dec    hl              ; 0021C6 2B 
    jr     $21eb           ; 0021C7 18 22 
    ld     bc,$21db        ; 0021C9 01 DB 21 
    push   bc              ; 0021CC C5 
    cp     $22             ; 0021CD FE 22 
    ret    nz              ; 0021CF C0 
    call   $2866           ; 0021D0 CD 66 28 
    rst    08h             ; 0021D3 CF 
    dec    sp              ; 0021D4 3B 
    push   hl              ; 0021D5 E5 
    call   $28aa           ; 0021D6 CD AA 28 
    pop    hl              ; 0021D9 E1 
    ret                    ; 0021DA C9 
    push   hl              ; 0021DB E5 
    call   $1bb3           ; 0021DC CD B3 1B 
    pop    bc              ; 0021DF C1 
    jp     c,$1dbe         ; 0021E0 DA BE 1D 
    inc    hl              ; 0021E3 23 
    ld     a,(hl)          ; 0021E4 7E 
    or     a               ; 0021E5 B7 
    dec    hl              ; 0021E6 2B 
    push   bc              ; 0021E7 C5 
    jp     z,$1f04         ; 0021E8 CA 04 1F 
    ld     (hl),$2c        ; 0021EB 36 2C 
    jr     $21f4           ; 0021ED 18 05 
    push   hl              ; 0021EF E5 
    ld     hl,($78ff)      ; 0021F0 2A FF 78 
    or     $af             ; 0021F3 F6 AF 
    ld     ($78de),a       ; 0021F5 32 DE 78 
    ex     (sp),hl         ; 0021F8 E3 
    jr     $21fd           ; 0021F9 18 02 
    rst    08h             ; 0021FB CF 
    inc    l               ; 0021FC 2C 
    call   $260d           ; 0021FD CD 0D 26 
    ex     (sp),hl         ; 002200 E3 
    push   de              ; 002201 D5 
    ld     a,(hl)          ; 002202 7E 
    cp     $2c             ; 002203 FE 2C 
    jr     z,$222d         ; 002205 28 26 
    ld     a,($78de)       ; 002207 3A DE 78 
    or     a               ; 00220A B7 
    jp     nz,$2296        ; 00220B C2 96 22 
    ld     a,($78a9)       ; 00220E 3A A9 78 
    or     a               ; 002211 B7 
    ld     e,$06           ; 002212 1E 06 
    jp     z,$19a2         ; 002214 CA A2 19 
    ld     a,$3f           ; 002217 3E 3F 
    call   $032a           ; 002219 CD 2A 03 
    call   $1bb3           ; 00221C CD B3 1B 
    pop    de              ; 00221F D1 
    pop    bc              ; 002220 C1 
    jp     c,$1dbe         ; 002221 DA BE 1D 
    inc    hl              ; 002224 23 
    ld     a,(hl)          ; 002225 7E 
    or     a               ; 002226 B7 
    dec    hl              ; 002227 2B 
    push   bc              ; 002228 C5 
    jp     z,$1f04         ; 002229 CA 04 1F 
    push   de              ; 00222C D5 
    call   $79dc           ; 00222D CD DC 79 
    rst    20h             ; 002230 E7 
    push   af              ; 002231 F5 
    jr     nz,$224d        ; 002232 20 19 
    rst    10h             ; 002234 D7 
    ld     d,a             ; 002235 57 
    ld     b,a             ; 002236 47 
    cp     $22             ; 002237 FE 22 
    jr     z,$2240         ; 002239 28 05 
    ld     d,$3a           ; 00223B 16 3A 
    ld     b,$2c           ; 00223D 06 2C 
    dec    hl              ; 00223F 2B 
    call   $2869           ; 002240 CD 69 28 
    pop    af              ; 002243 F1 
    ex     de,hl           ; 002244 EB 
    ld     hl,$225a        ; 002245 21 5A 22 
    ex     (sp),hl         ; 002248 E3 
    push   de              ; 002249 D5 
    jp     $1f33           ; 00224A C3 33 1F 
    rst    10h             ; 00224D D7 
    pop    af              ; 00224E F1 
    push   af              ; 00224F F5 
    ld     bc,$2243        ; 002250 01 43 22 
    push   bc              ; 002253 C5 
    jp     c,$0e6c         ; 002254 DA 6C 0E 
    jp     nc,$0e65        ; 002257 D2 65 0E 
    dec    hl              ; 00225A 2B 
    rst    10h             ; 00225B D7 
    jr     z,$2263         ; 00225C 28 05 
    cp     $2c             ; 00225E FE 2C 
    jp     nz,$217f        ; 002260 C2 7F 21 
    ex     (sp),hl         ; 002263 E3 
    dec    hl              ; 002264 2B 
    rst    10h             ; 002265 D7 
    jp     nz,$21fb        ; 002266 C2 FB 21 
    pop    de              ; 002269 D1 
    nop                    ; 00226A 00 
    nop                    ; 00226B 00 
    nop                    ; 00226C 00 
    nop                    ; 00226D 00 
    nop                    ; 00226E 00 
    ld     a,($78de)       ; 00226F 3A DE 78 
    or     a               ; 002272 B7 
    ex     de,hl           ; 002273 EB 
    jp     nz,$1d96        ; 002274 C2 96 1D 
    push   de              ; 002277 D5 
    call   $79df           ; 002278 CD DF 79 
    or     (hl)            ; 00227B B6 
    ld     hl,$2286        ; 00227C 21 86 22 
    call   nz,$28a7        ; 00227F C4 A7 28 
    pop    hl              ; 002282 E1 
    jp     $2169           ; 002283 C3 69 21 
    ccf                    ; 002286 3F 
    ld     b,l             ; 002287 45 
    ld     e,b             ; 002288 58 
    ld     d,h             ; 002289 54 
    ld     d,d             ; 00228A 52 
    ld     b,c             ; 00228B 41 
    jr     nz,$22d7        ; 00228C 20 49 
    ld     b,a             ; 00228E 47 
    ld     c,(hl)          ; 00228F 4E 
    ld     c,a             ; 002290 4F 
    ld     d,d             ; 002291 52 
    ld     b,l             ; 002292 45 
    ld     b,h             ; 002293 44 
    dec    c               ; 002294 0D 
    nop                    ; 002295 00 
    call   $1f05           ; 002296 CD 05 1F 
    or     a               ; 002299 B7 
    jr     nz,$22ae        ; 00229A 20 12 
    inc    hl              ; 00229C 23 
    ld     a,(hl)          ; 00229D 7E 
    inc    hl              ; 00229E 23 
    or     (hl)            ; 00229F B6 
    ld     e,$06           ; 0022A0 1E 06 
    jp     z,$19a2         ; 0022A2 CA A2 19 
    inc    hl              ; 0022A5 23 
    ld     e,(hl)          ; 0022A6 5E 
    inc    hl              ; 0022A7 23 
    ld     d,(hl)          ; 0022A8 56 
    ex     de,hl           ; 0022A9 EB 
    ld     ($78da),hl      ; 0022AA 22 DA 78 
    ex     de,hl           ; 0022AD EB 
    rst    10h             ; 0022AE D7 
    cp     $88             ; 0022AF FE 88 
    jr     nz,$2296        ; 0022B1 20 E3 
    jp     $222d           ; 0022B3 C3 2D 22 
    ld     de,$0000        ; 0022B6 11 00 00 
    call   nz,$260d        ; 0022B9 C4 0D 26 
    ld     ($78df),hl      ; 0022BC 22 DF 78 
    call   $1936           ; 0022BF CD 36 19 
    jp     nz,$199d        ; 0022C2 C2 9D 19 
    ld     sp,hl           ; 0022C5 F9 
    ld     ($78e8),hl      ; 0022C6 22 E8 78 
    push   de              ; 0022C9 D5 
    ld     a,(hl)          ; 0022CA 7E 
    inc    hl              ; 0022CB 23 
    push   af              ; 0022CC F5 
    push   de              ; 0022CD D5 
    ld     a,(hl)          ; 0022CE 7E 
    inc    hl              ; 0022CF 23 
    or     a               ; 0022D0 B7 
    jp     m,$22ea         ; 0022D1 FA EA 22 
    call   $09b1           ; 0022D4 CD B1 09 
    ex     (sp),hl         ; 0022D7 E3 
    push   hl              ; 0022D8 E5 
    call   $070b           ; 0022D9 CD 0B 07 
    pop    hl              ; 0022DC E1 
    call   $09cb           ; 0022DD CD CB 09 
    pop    hl              ; 0022E0 E1 
    call   $09c2           ; 0022E1 CD C2 09 
    push   hl              ; 0022E4 E5 
    call   $0a0c           ; 0022E5 CD 0C 0A 
    jr     $2313           ; 0022E8 18 29 
    inc    hl              ; 0022EA 23 
    inc    hl              ; 0022EB 23 
    inc    hl              ; 0022EC 23 
    inc    hl              ; 0022ED 23 
    ld     c,(hl)          ; 0022EE 4E 
    inc    hl              ; 0022EF 23 
    ld     b,(hl)          ; 0022F0 46 
    inc    hl              ; 0022F1 23 
    ex     (sp),hl         ; 0022F2 E3 
    ld     e,(hl)          ; 0022F3 5E 
    inc    hl              ; 0022F4 23 
    ld     d,(hl)          ; 0022F5 56 
    push   hl              ; 0022F6 E5 
    ld     l,c             ; 0022F7 69 
    ld     h,b             ; 0022F8 60 
    call   $0bd2           ; 0022F9 CD D2 0B 
    ld     a,($78af)       ; 0022FC 3A AF 78 
    cp     $04             ; 0022FF FE 04 
    jp     z,$07b2         ; 002301 CA B2 07 
    ex     de,hl           ; 002304 EB 
    pop    hl              ; 002305 E1 
    ld     (hl),d          ; 002306 72 
    dec    hl              ; 002307 2B 
    ld     (hl),e          ; 002308 73 
    pop    hl              ; 002309 E1 
    push   de              ; 00230A D5 
    ld     e,(hl)          ; 00230B 5E 
    inc    hl              ; 00230C 23 
    ld     d,(hl)          ; 00230D 56 
    inc    hl              ; 00230E 23 
    ex     (sp),hl         ; 00230F E3 
    call   $0a39           ; 002310 CD 39 0A 
    pop    hl              ; 002313 E1 
    pop    bc              ; 002314 C1 
    sub    b               ; 002315 90 
    call   $09c2           ; 002316 CD C2 09 
    jr     z,$2324         ; 002319 28 09 
    ex     de,hl           ; 00231B EB 
    ld     ($78a2),hl      ; 00231C 22 A2 78 
    ld     l,c             ; 00231F 69 
    ld     h,b             ; 002320 60 
    jp     $1d1a           ; 002321 C3 1A 1D 
    ld     sp,hl           ; 002324 F9 
    ld     ($78e8),hl      ; 002325 22 E8 78 
    ld     hl,($78df)      ; 002328 2A DF 78 
    ld     a,(hl)          ; 00232B 7E 
    cp     $2c             ; 00232C FE 2C 
    jp     nz,$1d1e        ; 00232E C2 1E 1D 
    rst    10h             ; 002331 D7 
    call   $22b9           ; 002332 CD B9 22 
    rst    08h             ; 002335 CF 
    jr     z,$2363         ; 002336 28 2B 
    ld     d,$00           ; 002338 16 00 
    push   de              ; 00233A D5 
    ld     c,$01           ; 00233B 0E 01 
    call   $1963           ; 00233D CD 63 19 
    call   $249f           ; 002340 CD 9F 24 
    ld     ($78f3),hl      ; 002343 22 F3 78 
    ld     hl,($78f3)      ; 002346 2A F3 78 
    pop    bc              ; 002349 C1 
    ld     a,(hl)          ; 00234A 7E 
    ld     d,$00           ; 00234B 16 00 
    sub    $d4             ; 00234D D6 D4 
    jr     c,$2364         ; 00234F 38 13 
    cp     $03             ; 002351 FE 03 
    jr     nc,$2364        ; 002353 30 0F 
    cp     $01             ; 002355 FE 01 
    rla                    ; 002357 17 
    xor    d               ; 002358 AA 
    cp     d               ; 002359 BA 
    ld     d,a             ; 00235A 57 
    jp     c,$1997         ; 00235B DA 97 19 
    ld     ($78d8),hl      ; 00235E 22 D8 78 
    rst    10h             ; 002361 D7 
    jr     $234d           ; 002362 18 E9 
    ld     a,d             ; 002364 7A 
    or     a               ; 002365 B7 
    jp     nz,$23ec        ; 002366 C2 EC 23 
    ld     a,(hl)          ; 002369 7E 
    ld     ($78d8),hl      ; 00236A 22 D8 78 
    sub    $cd             ; 00236D D6 CD 
    ret    c               ; 00236F D8 
    cp     $07             ; 002370 FE 07 
    ret    nc              ; 002372 D0 
    ld     e,a             ; 002373 5F 
    ld     a,($78af)       ; 002374 3A AF 78 
    sub    $03             ; 002377 D6 03 
    or     e               ; 002379 B3 
    jp     z,$298f         ; 00237A CA 8F 29 
    ld     hl,$189a        ; 00237D 21 9A 18 
    add    hl,de           ; 002380 19 
    ld     a,b             ; 002381 78 
    ld     d,(hl)          ; 002382 56 
    cp     d               ; 002383 BA 
    ret    nc              ; 002384 D0 
    push   bc              ; 002385 C5 
    ld     bc,$2346        ; 002386 01 46 23 
    push   bc              ; 002389 C5 
    ld     a,d             ; 00238A 7A 
    cp     $7f             ; 00238B FE 7F 
    jp     z,$23d4         ; 00238D CA D4 23 
    cp     $51             ; 002390 FE 51 
    jp     c,$23e1         ; 002392 DA E1 23 
    ld     hl,$7921        ; 002395 21 21 79 
    or     a               ; 002398 B7 
    ld     a,($78af)       ; 002399 3A AF 78 
    dec    a               ; 00239C 3D 
    dec    a               ; 00239D 3D 
    dec    a               ; 00239E 3D 
    jp     z,$0af6         ; 00239F CA F6 0A 
    ld     c,(hl)          ; 0023A2 4E 
    inc    hl              ; 0023A3 23 
    ld     b,(hl)          ; 0023A4 46 
    push   bc              ; 0023A5 C5 
    jp     m,$23c5         ; 0023A6 FA C5 23 
    inc    hl              ; 0023A9 23 
    ld     c,(hl)          ; 0023AA 4E 
    inc    hl              ; 0023AB 23 
    ld     b,(hl)          ; 0023AC 46 
    push   bc              ; 0023AD C5 
    push   af              ; 0023AE F5 
    or     a               ; 0023AF B7 
    jp     po,$23c4        ; 0023B0 E2 C4 23 
    pop    af              ; 0023B3 F1 
    inc    hl              ; 0023B4 23 
    jr     c,$23ba         ; 0023B5 38 03 
    ld     hl,$791d        ; 0023B7 21 1D 79 
    ld     c,(hl)          ; 0023BA 4E 
    inc    hl              ; 0023BB 23 
    ld     b,(hl)          ; 0023BC 46 
    inc    hl              ; 0023BD 23 
    push   bc              ; 0023BE C5 
    ld     c,(hl)          ; 0023BF 4E 
    inc    hl              ; 0023C0 23 
    ld     b,(hl)          ; 0023C1 46 
    push   bc              ; 0023C2 C5 
    ld     b,$f1           ; 0023C3 06 F1 
    add    a,$03           ; 0023C5 C6 03 
    ld     c,e             ; 0023C7 4B 
    ld     b,a             ; 0023C8 47 
    push   bc              ; 0023C9 C5 
    ld     bc,$2406        ; 0023CA 01 06 24 
    push   bc              ; 0023CD C5 
    ld     hl,($78d8)      ; 0023CE 2A D8 78 
    jp     $233a           ; 0023D1 C3 3A 23 
    call   $0ab1           ; 0023D4 CD B1 0A 
    call   $09a4           ; 0023D7 CD A4 09 
    ld     bc,$13f2        ; 0023DA 01 F2 13 
    ld     d,$7f           ; 0023DD 16 7F 
    jr     $23cd           ; 0023DF 18 EC 
    push   de              ; 0023E1 D5 
    call   $0a7f           ; 0023E2 CD 7F 0A 
    pop    de              ; 0023E5 D1 
    push   hl              ; 0023E6 E5 
    ld     bc,$25e9        ; 0023E7 01 E9 25 
    jr     $23cd           ; 0023EA 18 E1 
    ld     a,b             ; 0023EC 78 
    cp     $64             ; 0023ED FE 64 
    ret    nc              ; 0023EF D0 
    push   bc              ; 0023F0 C5 
    push   de              ; 0023F1 D5 
    ld     de,$6404        ; 0023F2 11 04 64 
    ld     hl,$25b8        ; 0023F5 21 B8 25 
    push   hl              ; 0023F8 E5 
    rst    20h             ; 0023F9 E7 
    jp     nz,$2395        ; 0023FA C2 95 23 
    ld     hl,($7921)      ; 0023FD 2A 21 79 
    push   hl              ; 002400 E5 
    ld     bc,$258c        ; 002401 01 8C 25 
    jr     $23cd           ; 002404 18 C7 
    pop    bc              ; 002406 C1 
    ld     a,c             ; 002407 79 
    ld     ($78b0),a       ; 002408 32 B0 78 
    ld     a,b             ; 00240B 78 
    cp     $08             ; 00240C FE 08 
    jr     z,$2438         ; 00240E 28 28 
    ld     a,($78af)       ; 002410 3A AF 78 
    cp     $08             ; 002413 FE 08 
    jp     z,$2460         ; 002415 CA 60 24 
    ld     d,a             ; 002418 57 
    ld     a,b             ; 002419 78 
    cp     $04             ; 00241A FE 04 
    jp     z,$2472         ; 00241C CA 72 24 
    ld     a,d             ; 00241F 7A 
    cp     $03             ; 002420 FE 03 
    jp     z,$0af6         ; 002422 CA F6 0A 
    jp     nc,$247c        ; 002425 D2 7C 24 
    ld     hl,$18bf        ; 002428 21 BF 18 
    ld     b,$00           ; 00242B 06 00 
    add    hl,bc           ; 00242D 09 
    add    hl,bc           ; 00242E 09 
    ld     c,(hl)          ; 00242F 4E 
    inc    hl              ; 002430 23 
    ld     b,(hl)          ; 002431 46 
    pop    de              ; 002432 D1 
    ld     hl,($7921)      ; 002433 2A 21 79 
    push   bc              ; 002436 C5 
    ret                    ; 002437 C9 
    call   $0adb           ; 002438 CD DB 0A 
    call   $09fc           ; 00243B CD FC 09 
    pop    hl              ; 00243E E1 
    ld     ($791f),hl      ; 00243F 22 1F 79 
    pop    hl              ; 002442 E1 
    ld     ($791d),hl      ; 002443 22 1D 79 
    pop    bc              ; 002446 C1 
    pop    de              ; 002447 D1 
    call   $09b4           ; 002448 CD B4 09 
    call   $0adb           ; 00244B CD DB 0A 
    ld     hl,$18ab        ; 00244E 21 AB 18 
    ld     a,($78b0)       ; 002451 3A B0 78 
    rlca                   ; 002454 07 
    push   bc              ; 002455 C5 
    ld     c,a             ; 002456 4F 
    ld     b,$00           ; 002457 06 00 
    add    hl,bc           ; 002459 09 
    pop    bc              ; 00245A C1 
    ld     a,(hl)          ; 00245B 7E 
    inc    hl              ; 00245C 23 
    ld     h,(hl)          ; 00245D 66 
    ld     l,a             ; 00245E 6F 
    jp     (hl)            ; 00245F E9 
    push   bc              ; 002460 C5 
    call   $09fc           ; 002461 CD FC 09 
    pop    af              ; 002464 F1 
    ld     ($78af),a       ; 002465 32 AF 78 
    cp     $04             ; 002468 FE 04 
    jr     z,$2446         ; 00246A 28 DA 
    pop    hl              ; 00246C E1 
    ld     ($7921),hl      ; 00246D 22 21 79 
    jr     $244b           ; 002470 18 D9 
    call   $0ab1           ; 002472 CD B1 0A 
    pop    bc              ; 002475 C1 
    pop    de              ; 002476 D1 
    ld     hl,$18b5        ; 002477 21 B5 18 
    jr     $2451           ; 00247A 18 D5 
    pop    hl              ; 00247C E1 
    call   $09a4           ; 00247D CD A4 09 
    call   $0acf           ; 002480 CD CF 0A 
    call   $09bf           ; 002483 CD BF 09 
    pop    hl              ; 002486 E1 
    ld     ($7923),hl      ; 002487 22 23 79 
    pop    hl              ; 00248A E1 
    ld     ($7921),hl      ; 00248B 22 21 79 
    jr     $2477           ; 00248E 18 E7 
    push   hl              ; 002490 E5 
    ex     de,hl           ; 002491 EB 
    call   $0acf           ; 002492 CD CF 0A 
    pop    hl              ; 002495 E1 
    call   $09a4           ; 002496 CD A4 09 
    call   $0acf           ; 002499 CD CF 0A 
    jp     $08a0           ; 00249C C3 A0 08 
    rst    10h             ; 00249F D7 
    ld     e,$28           ; 0024A0 1E 28 
    jp     z,$19a2         ; 0024A2 CA A2 19 
    jp     c,$0e6c         ; 0024A5 DA 6C 0E 
    call   $1e3d           ; 0024A8 CD 3D 1E 
    jp     nc,$2540        ; 0024AB D2 40 25 
    cp     $cd             ; 0024AE FE CD 
    jr     z,$249f         ; 0024B0 28 ED 
    cp     $2e             ; 0024B2 FE 2E 
    jp     z,$0e6c         ; 0024B4 CA 6C 0E 
    cp     $ce             ; 0024B7 FE CE 
    jp     z,$2532         ; 0024B9 CA 32 25 
    cp     $22             ; 0024BC FE 22 
    jp     z,$2866         ; 0024BE CA 66 28 
    cp     $cb             ; 0024C1 FE CB 
    jp     z,$25c4         ; 0024C3 CA C4 25 
    cp     $26             ; 0024C6 FE 26 
    jp     z,$7994         ; 0024C8 CA 94 79 
    cp     $c3             ; 0024CB FE C3 
    jr     nz,$24d9        ; 0024CD 20 0A 
    rst    10h             ; 0024CF D7 
    ld     a,($789a)       ; 0024D0 3A 9A 78 
    push   hl              ; 0024D3 E5 
    call   $27f8           ; 0024D4 CD F8 27 
    pop    hl              ; 0024D7 E1 
    ret                    ; 0024D8 C9 
    cp     $c2             ; 0024D9 FE C2 
    jr     nz,$24e7        ; 0024DB 20 0A 
    rst    10h             ; 0024DD D7 
    push   hl              ; 0024DE E5 
    ld     hl,($78ea)      ; 0024DF 2A EA 78 
    call   $0c66           ; 0024E2 CD 66 0C 
    pop    hl              ; 0024E5 E1 
    ret                    ; 0024E6 C9 
    cp     $c0             ; 0024E7 FE C0 
    jr     nz,$24ff        ; 0024E9 20 14 
    rst    10h             ; 0024EB D7 
    rst    08h             ; 0024EC CF 
    jr     z,$24bc         ; 0024ED 28 CD 
    dec    c               ; 0024EF 0D 
    ld     h,$cf           ; 0024F0 26 CF 
    add    hl,hl           ; 0024F2 29 
    push   hl              ; 0024F3 E5 
    ex     de,hl           ; 0024F4 EB 
    ld     a,h             ; 0024F5 7C 
    or     l               ; 0024F6 B5 
    jp     z,$1e4a         ; 0024F7 CA 4A 1E 
    call   $0a9a           ; 0024FA CD 9A 0A 
    pop    hl              ; 0024FD E1 
    ret                    ; 0024FE C9 
    cp     $c1             ; 0024FF FE C1 
    jp     z,$27fe         ; 002501 CA FE 27 
    cp     $c5             ; 002504 FE C5 
    jp     z,$799d         ; 002506 CA 9D 79 
    cp     $c8             ; 002509 FE C8 
    jp     z,$27c9         ; 00250B CA C9 27 
    cp     $c7             ; 00250E FE C7 
    jp     z,$7976         ; 002510 CA 76 79 
    cp     $c6             ; 002513 FE C6 
    jp     z,$0132         ; 002515 CA 32 01 
    cp     $c9             ; 002518 FE C9 
    jp     z,$019d         ; 00251A CA 9D 01 
    cp     $c4             ; 00251D FE C4 
    jp     z,$2a2f         ; 00251F CA 2F 2A 
    cp     $be             ; 002522 FE BE 
    jp     z,$7955         ; 002524 CA 55 79 
    sub    $d7             ; 002527 D6 D7 
    jp     nc,$254e        ; 002529 D2 4E 25 
    call   $2335           ; 00252C CD 35 23 
    rst    08h             ; 00252F CF 
    add    hl,hl           ; 002530 29 
    ret                    ; 002531 C9 
    ld     d,$7d           ; 002532 16 7D 
    call   $233a           ; 002534 CD 3A 23 
    ld     hl,($78f3)      ; 002537 2A F3 78 
    push   hl              ; 00253A E5 
    call   $097b           ; 00253B CD 7B 09 
    pop    hl              ; 00253E E1 
    ret                    ; 00253F C9 
    call   $260d           ; 002540 CD 0D 26 
    push   hl              ; 002543 E5 
    ex     de,hl           ; 002544 EB 
    ld     ($7921),hl      ; 002545 22 21 79 
    rst    20h             ; 002548 E7 
    call   nz,$09f7        ; 002549 C4 F7 09 
    pop    hl              ; 00254C E1 
    ret                    ; 00254D C9 
    ld     b,$00           ; 00254E 06 00 
    rlca                   ; 002550 07 
    ld     c,a             ; 002551 4F 
    push   bc              ; 002552 C5 
    rst    10h             ; 002553 D7 
    ld     a,c             ; 002554 79 
    cp     $41             ; 002555 FE 41 
    jr     c,$256f         ; 002557 38 16 
    call   $2335           ; 002559 CD 35 23 
    rst    08h             ; 00255C CF 
    inc    l               ; 00255D 2C 
    call   $0af4           ; 00255E CD F4 0A 
    ex     de,hl           ; 002561 EB 
    ld     hl,($7921)      ; 002562 2A 21 79 
    ex     (sp),hl         ; 002565 E3 
    push   hl              ; 002566 E5 
    ex     de,hl           ; 002567 EB 
    call   $2b1c           ; 002568 CD 1C 2B 
    ex     de,hl           ; 00256B EB 
    ex     (sp),hl         ; 00256C E3 
    jr     $2583           ; 00256D 18 14 
    call   $252c           ; 00256F CD 2C 25 
    ex     (sp),hl         ; 002572 E3 
    ld     a,l             ; 002573 7D 
    cp     $0c             ; 002574 FE 0C 
    jr     c,$257f         ; 002576 38 07 
    cp     $1b             ; 002578 FE 1B 
    push   hl              ; 00257A E5 
    call   c,$0ab1         ; 00257B DC B1 0A 
    pop    hl              ; 00257E E1 
    ld     de,$253e        ; 00257F 11 3E 25 
    push   de              ; 002582 D5 
    ld     bc,$1608        ; 002583 01 08 16 
    add    hl,bc           ; 002586 09 
    ld     c,(hl)          ; 002587 4E 
    inc    hl              ; 002588 23 
    ld     h,(hl)          ; 002589 66 
    ld     l,c             ; 00258A 69 
    jp     (hl)            ; 00258B E9 
    call   $29d7           ; 00258C CD D7 29 
    ld     a,(hl)          ; 00258F 7E 
    inc    hl              ; 002590 23 
    ld     c,(hl)          ; 002591 4E 
    inc    hl              ; 002592 23 
    ld     b,(hl)          ; 002593 46 
    pop    de              ; 002594 D1 
    push   bc              ; 002595 C5 
    push   af              ; 002596 F5 
    call   $29de           ; 002597 CD DE 29 
    pop    de              ; 00259A D1 
    ld     e,(hl)          ; 00259B 5E 
    inc    hl              ; 00259C 23 
    ld     c,(hl)          ; 00259D 4E 
    inc    hl              ; 00259E 23 
    ld     b,(hl)          ; 00259F 46 
    pop    hl              ; 0025A0 E1 
    ld     a,e             ; 0025A1 7B 
    or     d               ; 0025A2 B2 
    ret    z               ; 0025A3 C8 
    ld     a,d             ; 0025A4 7A 
    sub    $01             ; 0025A5 D6 01 
    ret    c               ; 0025A7 D8 
    xor    a               ; 0025A8 AF 
    cp     e               ; 0025A9 BB 
    inc    a               ; 0025AA 3C 
    ret    nc              ; 0025AB D0 
    dec    d               ; 0025AC 15 
    dec    e               ; 0025AD 1D 
    ld     a,(bc)          ; 0025AE 0A 
    cp     (hl)            ; 0025AF BE 
    inc    hl              ; 0025B0 23 
    inc    bc              ; 0025B1 03 
    jr     z,$25a1         ; 0025B2 28 ED 
    ccf                    ; 0025B4 3F 
    jp     $0960           ; 0025B5 C3 60 09 
    inc    a               ; 0025B8 3C 
    adc    a,a             ; 0025B9 8F 
    pop    bc              ; 0025BA C1 
    and    b               ; 0025BB A0 
    add    a,$ff           ; 0025BC C6 FF 
    sbc    a,a             ; 0025BE 9F 
    call   $098d           ; 0025BF CD 8D 09 
    jr     $25d6           ; 0025C2 18 12 
    ld     d,$5a           ; 0025C4 16 5A 
    call   $233a           ; 0025C6 CD 3A 23 
    call   $0a7f           ; 0025C9 CD 7F 0A 
    ld     a,l             ; 0025CC 7D 
    cpl                    ; 0025CD 2F 
    ld     l,a             ; 0025CE 6F 
    ld     a,h             ; 0025CF 7C 
    cpl                    ; 0025D0 2F 
    ld     h,a             ; 0025D1 67 
    ld     ($7921),hl      ; 0025D2 22 21 79 
    pop    bc              ; 0025D5 C1 
    jp     $2346           ; 0025D6 C3 46 23 
    ld     a,($78af)       ; 0025D9 3A AF 78 
    cp     $08             ; 0025DC FE 08 
    jr     nc,$25e5        ; 0025DE 30 05 
    sub    $03             ; 0025E0 D6 03 
    or     a               ; 0025E2 B7 
    scf                    ; 0025E3 37 
    ret                    ; 0025E4 C9 
    sub    $03             ; 0025E5 D6 03 
    or     a               ; 0025E7 B7 
    ret                    ; 0025E8 C9 
    push   bc              ; 0025E9 C5 
    call   $0a7f           ; 0025EA CD 7F 0A 
    pop    af              ; 0025ED F1 
    pop    de              ; 0025EE D1 
    ld     bc,$27fa        ; 0025EF 01 FA 27 
    push   bc              ; 0025F2 C5 
    cp     $46             ; 0025F3 FE 46 
    jr     nz,$25fd        ; 0025F5 20 06 
    ld     a,e             ; 0025F7 7B 
    or     l               ; 0025F8 B5 
    ld     l,a             ; 0025F9 6F 
    ld     a,h             ; 0025FA 7C 
    or     d               ; 0025FB B2 
    ret                    ; 0025FC C9 
    ld     a,e             ; 0025FD 7B 
    and    l               ; 0025FE A5 
    ld     l,a             ; 0025FF 6F 
    ld     a,h             ; 002600 7C 
    and    d               ; 002601 A2 
    ret                    ; 002602 C9 
    dec    hl              ; 002603 2B 
    rst    10h             ; 002604 D7 
    ret    z               ; 002605 C8 
    rst    08h             ; 002606 CF 
    inc    l               ; 002607 2C 
    ld     bc,$2603        ; 002608 01 03 26 
    push   bc              ; 00260B C5 
    or     $af             ; 00260C F6 AF 
    ld     ($78ae),a       ; 00260E 32 AE 78 
    ld     b,(hl)          ; 002611 46 
    call   $1e3d           ; 002612 CD 3D 1E 
    jp     c,$1997         ; 002615 DA 97 19 
    xor    a               ; 002618 AF 
    ld     c,a             ; 002619 4F 
    rst    10h             ; 00261A D7 
    jr     c,$2622         ; 00261B 38 05 
    call   $1e3d           ; 00261D CD 3D 1E 
    jr     c,$262b         ; 002620 38 09 
    ld     c,a             ; 002622 4F 
    rst    10h             ; 002623 D7 
    jr     c,$2623         ; 002624 38 FD 
    call   $1e3d           ; 002626 CD 3D 1E 
    jr     nc,$2623        ; 002629 30 F8 
    ld     de,$2652        ; 00262B 11 52 26 
    push   de              ; 00262E D5 
    ld     d,$02           ; 00262F 16 02 
    cp     $25             ; 002631 FE 25 
    ret    z               ; 002633 C8 
    inc    d               ; 002634 14 
    cp     $24             ; 002635 FE 24 
    ret    z               ; 002637 C8 
    nop                    ; 002638 00 
    nop                    ; 002639 00 
    nop                    ; 00263A 00 
    nop                    ; 00263B 00 
    nop                    ; 00263C 00 
    nop                    ; 00263D 00 
    nop                    ; 00263E 00 
    nop                    ; 00263F 00 
    nop                    ; 002640 00 
    ld     a,b             ; 002641 78 
    sub    $41             ; 002642 D6 41 
    and    $7f             ; 002644 E6 7F 
    ld     e,a             ; 002646 5F 
    ld     d,$00           ; 002647 16 00 
    push   hl              ; 002649 E5 
    ld     hl,$7901        ; 00264A 21 01 79 
    add    hl,de           ; 00264D 19 
    ld     d,(hl)          ; 00264E 56 
    pop    hl              ; 00264F E1 
    dec    hl              ; 002650 2B 
    ret                    ; 002651 C9 
    ld     a,d             ; 002652 7A 
    ld     ($78af),a       ; 002653 32 AF 78 
    rst    10h             ; 002656 D7 
    ld     a,($78dc)       ; 002657 3A DC 78 
    or     a               ; 00265A B7 
    jp     nz,$2664        ; 00265B C2 64 26 
    ld     a,(hl)          ; 00265E 7E 
    sub    $28             ; 00265F D6 28 
    jp     z,$26e9         ; 002661 CA E9 26 
    xor    a               ; 002664 AF 
    ld     ($78dc),a       ; 002665 32 DC 78 
    push   hl              ; 002668 E5 
    push   de              ; 002669 D5 
    ld     hl,($78f9)      ; 00266A 2A F9 78 
    ex     de,hl           ; 00266D EB 
    ld     hl,($78fb)      ; 00266E 2A FB 78 
    rst    18h             ; 002671 DF 
    pop    hl              ; 002672 E1 
    jr     z,$268e         ; 002673 28 19 
    ld     a,(de)          ; 002675 1A 
    ld     l,a             ; 002676 6F 
    cp     h               ; 002677 BC 
    inc    de              ; 002678 13 
    jr     nz,$2686        ; 002679 20 0B 
    ld     a,(de)          ; 00267B 1A 
    cp     c               ; 00267C B9 
    jr     nz,$2686        ; 00267D 20 07 
    inc    de              ; 00267F 13 
    ld     a,(de)          ; 002680 1A 
    cp     b               ; 002681 B8 
    jp     z,$26cc         ; 002682 CA CC 26 
    ld     a,$13           ; 002685 3E 13 
    inc    de              ; 002687 13 
    push   hl              ; 002688 E5 
    ld     h,$00           ; 002689 26 00 
    add    hl,de           ; 00268B 19 
    jr     $266d           ; 00268C 18 DF 
    ld     a,h             ; 00268E 7C 
    pop    hl              ; 00268F E1 
    ex     (sp),hl         ; 002690 E3 
    push   af              ; 002691 F5 
    push   de              ; 002692 D5 
    ld     de,$24f1        ; 002693 11 F1 24 
    rst    18h             ; 002696 DF 
    jr     z,$26cf         ; 002697 28 36 
    ld     de,$2543        ; 002699 11 43 25 
    rst    18h             ; 00269C DF 
    pop    de              ; 00269D D1 
    jr     z,$26d5         ; 00269E 28 35 
    pop    af              ; 0026A0 F1 
    ex     (sp),hl         ; 0026A1 E3 
    push   hl              ; 0026A2 E5 
    push   bc              ; 0026A3 C5 
    ld     c,a             ; 0026A4 4F 
    ld     b,$00           ; 0026A5 06 00 
    push   bc              ; 0026A7 C5 
    inc    bc              ; 0026A8 03 
    inc    bc              ; 0026A9 03 
    inc    bc              ; 0026AA 03 
    ld     hl,($78fd)      ; 0026AB 2A FD 78 
    push   hl              ; 0026AE E5 
    add    hl,bc           ; 0026AF 09 
    pop    bc              ; 0026B0 C1 
    push   hl              ; 0026B1 E5 
    call   $1955           ; 0026B2 CD 55 19 
    pop    hl              ; 0026B5 E1 
    ld     ($78fd),hl      ; 0026B6 22 FD 78 
    ld     h,b             ; 0026B9 60 
    ld     l,c             ; 0026BA 69 
    ld     ($78fb),hl      ; 0026BB 22 FB 78 
    dec    hl              ; 0026BE 2B 
    ld     (hl),$00        ; 0026BF 36 00 
    rst    18h             ; 0026C1 DF 
    jr     nz,$26be        ; 0026C2 20 FA 
    pop    de              ; 0026C4 D1 
    ld     (hl),e          ; 0026C5 73 
    inc    hl              ; 0026C6 23 
    pop    de              ; 0026C7 D1 
    ld     (hl),e          ; 0026C8 73 
    inc    hl              ; 0026C9 23 
    ld     (hl),d          ; 0026CA 72 
    ex     de,hl           ; 0026CB EB 
    inc    de              ; 0026CC 13 
    pop    hl              ; 0026CD E1 
    ret                    ; 0026CE C9 
    ld     d,a             ; 0026CF 57 
    ld     e,a             ; 0026D0 5F 
    pop    af              ; 0026D1 F1 
    pop    af              ; 0026D2 F1 
    ex     (sp),hl         ; 0026D3 E3 
    ret                    ; 0026D4 C9 
    ld     ($7924),a       ; 0026D5 32 24 79 
    pop    bc              ; 0026D8 C1 
    ld     h,a             ; 0026D9 67 
    ld     l,a             ; 0026DA 6F 
    ld     ($7921),hl      ; 0026DB 22 21 79 
    rst    20h             ; 0026DE E7 
    jr     nz,$26e7        ; 0026DF 20 06 
    ld     hl,$1928        ; 0026E1 21 28 19 
    ld     ($7921),hl      ; 0026E4 22 21 79 
    pop    hl              ; 0026E7 E1 
    ret                    ; 0026E8 C9 
    push   hl              ; 0026E9 E5 
    ld     hl,($78ae)      ; 0026EA 2A AE 78 
    ex     (sp),hl         ; 0026ED E3 
    ld     d,a             ; 0026EE 57 
    push   de              ; 0026EF D5 
    push   bc              ; 0026F0 C5 
    call   $1e45           ; 0026F1 CD 45 1E 
    pop    bc              ; 0026F4 C1 
    pop    af              ; 0026F5 F1 
    ex     de,hl           ; 0026F6 EB 
    ex     (sp),hl         ; 0026F7 E3 
    push   hl              ; 0026F8 E5 
    ex     de,hl           ; 0026F9 EB 
    inc    a               ; 0026FA 3C 
    ld     d,a             ; 0026FB 57 
    ld     a,(hl)          ; 0026FC 7E 
    cp     $2c             ; 0026FD FE 2C 
    jr     z,$26ef         ; 0026FF 28 EE 
    rst    08h             ; 002701 CF 
    add    hl,hl           ; 002702 29 
    ld     ($78f3),hl      ; 002703 22 F3 78 
    pop    hl              ; 002706 E1 
    ld     ($78ae),hl      ; 002707 22 AE 78 
    push   de              ; 00270A D5 
    ld     hl,($78fb)      ; 00270B 2A FB 78 
    ld     a,$19           ; 00270E 3E 19 
    ex     de,hl           ; 002710 EB 
    ld     hl,($78fd)      ; 002711 2A FD 78 
    ex     de,hl           ; 002714 EB 
    rst    18h             ; 002715 DF 
    ld     a,($78af)       ; 002716 3A AF 78 
    jr     z,$2742         ; 002719 28 27 
    cp     (hl)            ; 00271B BE 
    inc    hl              ; 00271C 23 
    jr     nz,$2727        ; 00271D 20 08 
    ld     a,(hl)          ; 00271F 7E 
    cp     c               ; 002720 B9 
    inc    hl              ; 002721 23 
    jr     nz,$2728        ; 002722 20 04 
    ld     a,(hl)          ; 002724 7E 
    cp     b               ; 002725 B8 
    ld     a,$23           ; 002726 3E 23 
    inc    hl              ; 002728 23 
    ld     e,(hl)          ; 002729 5E 
    inc    hl              ; 00272A 23 
    ld     d,(hl)          ; 00272B 56 
    inc    hl              ; 00272C 23 
    jr     nz,$270f        ; 00272D 20 E0 
    ld     a,($78ae)       ; 00272F 3A AE 78 
    or     a               ; 002732 B7 
    ld     e,$12           ; 002733 1E 12 
    jp     nz,$19a2        ; 002735 C2 A2 19 
    pop    af              ; 002738 F1 
    sub    (hl)            ; 002739 96 
    jp     z,$2795         ; 00273A CA 95 27 
    ld     e,$10           ; 00273D 1E 10 
    jp     $19a2           ; 00273F C3 A2 19 
    ld     (hl),a          ; 002742 77 
    inc    hl              ; 002743 23 
    ld     e,a             ; 002744 5F 
    ld     d,$00           ; 002745 16 00 
    pop    af              ; 002747 F1 
    ld     (hl),c          ; 002748 71 
    inc    hl              ; 002749 23 
    ld     (hl),b          ; 00274A 70 
    inc    hl              ; 00274B 23 
    ld     c,a             ; 00274C 4F 
    call   $1963           ; 00274D CD 63 19 
    inc    hl              ; 002750 23 
    inc    hl              ; 002751 23 
    ld     ($78d8),hl      ; 002752 22 D8 78 
    ld     (hl),c          ; 002755 71 
    inc    hl              ; 002756 23 
    ld     a,($78ae)       ; 002757 3A AE 78 
    rla                    ; 00275A 17 
    ld     a,c             ; 00275B 79 
    ld     bc,$000b        ; 00275C 01 0B 00 
    jr     nc,$2763        ; 00275F 30 02 
    pop    bc              ; 002761 C1 
    inc    bc              ; 002762 03 
    ld     (hl),c          ; 002763 71 
    inc    hl              ; 002764 23 
    ld     (hl),b          ; 002765 70 
    inc    hl              ; 002766 23 
    push   af              ; 002767 F5 
    call   $0baa           ; 002768 CD AA 0B 
    pop    af              ; 00276B F1 
    dec    a               ; 00276C 3D 
    jr     nz,$275c        ; 00276D 20 ED 
    push   af              ; 00276F F5 
    ld     b,d             ; 002770 42 
    ld     c,e             ; 002771 4B 
    ex     de,hl           ; 002772 EB 
    add    hl,de           ; 002773 19 
    jr     c,$273d         ; 002774 38 C7 
    call   $196c           ; 002776 CD 6C 19 
    ld     ($78fd),hl      ; 002779 22 FD 78 
    dec    hl              ; 00277C 2B 
    ld     (hl),$00        ; 00277D 36 00 
    rst    18h             ; 00277F DF 
    jr     nz,$277c        ; 002780 20 FA 
    inc    bc              ; 002782 03 
    ld     d,a             ; 002783 57 
    ld     hl,($78d8)      ; 002784 2A D8 78 
    ld     e,(hl)          ; 002787 5E 
    ex     de,hl           ; 002788 EB 
    add    hl,hl           ; 002789 29 
    add    hl,bc           ; 00278A 09 
    ex     de,hl           ; 00278B EB 
    dec    hl              ; 00278C 2B 
    dec    hl              ; 00278D 2B 
    ld     (hl),e          ; 00278E 73 
    inc    hl              ; 00278F 23 
    ld     (hl),d          ; 002790 72 
    inc    hl              ; 002791 23 
    pop    af              ; 002792 F1 
    jr     c,$27c5         ; 002793 38 30 
    ld     b,a             ; 002795 47 
    ld     c,a             ; 002796 4F 
    ld     a,(hl)          ; 002797 7E 
    inc    hl              ; 002798 23 
    ld     d,$e1           ; 002799 16 E1 
    ld     e,(hl)          ; 00279B 5E 
    inc    hl              ; 00279C 23 
    ld     d,(hl)          ; 00279D 56 
    inc    hl              ; 00279E 23 
    ex     (sp),hl         ; 00279F E3 
    push   af              ; 0027A0 F5 
    rst    18h             ; 0027A1 DF 
    jp     nc,$273d        ; 0027A2 D2 3D 27 
    call   $0baa           ; 0027A5 CD AA 0B 
    add    hl,de           ; 0027A8 19 
    pop    af              ; 0027A9 F1 
    dec    a               ; 0027AA 3D 
    ld     b,h             ; 0027AB 44 
    ld     c,l             ; 0027AC 4D 
    jr     nz,$279a        ; 0027AD 20 EB 
    ld     a,($78af)       ; 0027AF 3A AF 78 
    ld     b,h             ; 0027B2 44 
    ld     c,l             ; 0027B3 4D 
    add    hl,hl           ; 0027B4 29 
    sub    $04             ; 0027B5 D6 04 
    jr     c,$27bd         ; 0027B7 38 04 
    add    hl,hl           ; 0027B9 29 
    jr     z,$27c2         ; 0027BA 28 06 
    add    hl,hl           ; 0027BC 29 
    or     a               ; 0027BD B7 
    jp     po,$27c2        ; 0027BE E2 C2 27 
    add    hl,bc           ; 0027C1 09 
    pop    bc              ; 0027C2 C1 
    add    hl,bc           ; 0027C3 09 
    ex     de,hl           ; 0027C4 EB 
    ld     hl,($78f3)      ; 0027C5 2A F3 78 
    ret                    ; 0027C8 C9 
    xor    a               ; 0027C9 AF 
    push   hl              ; 0027CA E5 
    ld     ($78af),a       ; 0027CB 32 AF 78 
    call   $27d4           ; 0027CE CD D4 27 
    pop    hl              ; 0027D1 E1 
    rst    10h             ; 0027D2 D7 
    ret                    ; 0027D3 C9 
    ld     hl,($78fd)      ; 0027D4 2A FD 78 
    ex     de,hl           ; 0027D7 EB 
    ld     hl,$0000        ; 0027D8 21 00 00 
    add    hl,sp           ; 0027DB 39 
    rst    20h             ; 0027DC E7 
    jr     nz,$27ec        ; 0027DD 20 0D 
    call   $29da           ; 0027DF CD DA 29 
    call   $28e6           ; 0027E2 CD E6 28 
    ld     hl,($78a0)      ; 0027E5 2A A0 78 
    ex     de,hl           ; 0027E8 EB 
    ld     hl,($78d6)      ; 0027E9 2A D6 78 
    ld     a,l             ; 0027EC 7D 
    sub    e               ; 0027ED 93 
    ld     l,a             ; 0027EE 6F 
    ld     a,h             ; 0027EF 7C 
    sbc    a,d             ; 0027F0 9A 
    ld     h,a             ; 0027F1 67 
    jp     $0c66           ; 0027F2 C3 66 0C 
    ld     a,($78a6)       ; 0027F5 3A A6 78 
    ld     l,a             ; 0027F8 6F 
    xor    a               ; 0027F9 AF 
    ld     h,a             ; 0027FA 67 
    jp     $0a9a           ; 0027FB C3 9A 0A 
    call   $79a9           ; 0027FE CD A9 79 
    rst    10h             ; 002801 D7 
    call   $252c           ; 002802 CD 2C 25 
    push   hl              ; 002805 E5 
    ld     hl,$0890        ; 002806 21 90 08 
    push   hl              ; 002809 E5 
    ld     a,($78af)       ; 00280A 3A AF 78 
    push   af              ; 00280D F5 
    cp     $03             ; 00280E FE 03 
    call   z,$29da         ; 002810 CC DA 29 
    pop    af              ; 002813 F1 
    ex     de,hl           ; 002814 EB 
    ld     hl,($788e)      ; 002815 2A 8E 78 
    jp     (hl)            ; 002818 E9 
    push   hl              ; 002819 E5 
    and    $07             ; 00281A E6 07 
    ld     hl,$18a1        ; 00281C 21 A1 18 
    ld     c,a             ; 00281F 4F 
    ld     b,$00           ; 002820 06 00 
    add    hl,bc           ; 002822 09 
    call   $2586           ; 002823 CD 86 25 
    pop    hl              ; 002826 E1 
    ret                    ; 002827 C9 
    push   hl              ; 002828 E5 
    ld     hl,($78a2)      ; 002829 2A A2 78 
    inc    hl              ; 00282C 23 
    ld     a,h             ; 00282D 7C 
    or     l               ; 00282E B5 
    pop    hl              ; 00282F E1 
    ret    nz              ; 002830 C0 
    ld     e,$16           ; 002831 1E 16 
    jp     $19a2           ; 002833 C3 A2 19 
    call   $0fbd           ; 002836 CD BD 0F 
    call   $2865           ; 002839 CD 65 28 
    call   $29da           ; 00283C CD DA 29 
    ld     bc,$2a2b        ; 00283F 01 2B 2A 
    push   bc              ; 002842 C5 
    ld     a,(hl)          ; 002843 7E 
    inc    hl              ; 002844 23 
    push   hl              ; 002845 E5 
    call   $28bf           ; 002846 CD BF 28 
    pop    hl              ; 002849 E1 
    ld     c,(hl)          ; 00284A 4E 
    inc    hl              ; 00284B 23 
    ld     b,(hl)          ; 00284C 46 
    call   $285a           ; 00284D CD 5A 28 
    push   hl              ; 002850 E5 
    ld     l,a             ; 002851 6F 
    call   $29ce           ; 002852 CD CE 29 
    pop    de              ; 002855 D1 
    ret                    ; 002856 C9 
    call   $28bf           ; 002857 CD BF 28 
    ld     hl,$78d3        ; 00285A 21 D3 78 
    push   hl              ; 00285D E5 
    ld     (hl),a          ; 00285E 77 
    inc    hl              ; 00285F 23 
    ld     (hl),e          ; 002860 73 
    inc    hl              ; 002861 23 
    ld     (hl),d          ; 002862 72 
    pop    hl              ; 002863 E1 
    ret                    ; 002864 C9 
    dec    hl              ; 002865 2B 
    ld     b,$22           ; 002866 06 22 
    ld     d,b             ; 002868 50 
    push   hl              ; 002869 E5 
    ld     c,$ff           ; 00286A 0E FF 
    inc    hl              ; 00286C 23 
    ld     a,(hl)          ; 00286D 7E 
    inc    c               ; 00286E 0C 
    or     a               ; 00286F B7 
    jr     z,$2878         ; 002870 28 06 
    cp     d               ; 002872 BA 
    jr     z,$2878         ; 002873 28 03 
    cp     b               ; 002875 B8 
    jr     nz,$286c        ; 002876 20 F4 
    cp     $22             ; 002878 FE 22 
    call   z,$1d78         ; 00287A CC 78 1D 
    ex     (sp),hl         ; 00287D E3 
    inc    hl              ; 00287E 23 
    ex     de,hl           ; 00287F EB 
    ld     a,c             ; 002880 79 
    call   $285a           ; 002881 CD 5A 28 
    ld     de,$78d3        ; 002884 11 D3 78 
    ld     a,$d5           ; 002887 3E D5 
    ld     hl,($78b3)      ; 002889 2A B3 78 
    ld     ($7921),hl      ; 00288C 22 21 79 
    ld     a,$03           ; 00288F 3E 03 
    ld     ($78af),a       ; 002891 32 AF 78 
    call   $09d3           ; 002894 CD D3 09 
    ld     de,$78d6        ; 002897 11 D6 78 
    rst    18h             ; 00289A DF 
    ld     ($78b3),hl      ; 00289B 22 B3 78 
    pop    hl              ; 00289E E1 
    ld     a,(hl)          ; 00289F 7E 
    ret    nz              ; 0028A0 C0 
    ld     e,$1e           ; 0028A1 1E 1E 
    jp     $19a2           ; 0028A3 C3 A2 19 
    inc    hl              ; 0028A6 23 
    call   $2865           ; 0028A7 CD 65 28 
    call   $29da           ; 0028AA CD DA 29 
    call   $09c4           ; 0028AD CD C4 09 
    inc    d               ; 0028B0 14 
    dec    d               ; 0028B1 15 
    ret    z               ; 0028B2 C8 
    ld     a,(bc)          ; 0028B3 0A 
    call   $032a           ; 0028B4 CD 2A 03 
    cp     $0d             ; 0028B7 FE 0D 
    call   z,$2103         ; 0028B9 CC 03 21 
    inc    bc              ; 0028BC 03 
    jr     $28b1           ; 0028BD 18 F2 
    or     a               ; 0028BF B7 
    ld     c,$f1           ; 0028C0 0E F1 
    push   af              ; 0028C2 F5 
    ld     hl,($78a0)      ; 0028C3 2A A0 78 
    ex     de,hl           ; 0028C6 EB 
    ld     hl,($78d6)      ; 0028C7 2A D6 78 
    cpl                    ; 0028CA 2F 
    ld     c,a             ; 0028CB 4F 
    ld     b,$ff           ; 0028CC 06 FF 
    add    hl,bc           ; 0028CE 09 
    inc    hl              ; 0028CF 23 
    rst    18h             ; 0028D0 DF 
    jr     c,$28da         ; 0028D1 38 07 
    ld     ($78d6),hl      ; 0028D3 22 D6 78 
    inc    hl              ; 0028D6 23 
    ex     de,hl           ; 0028D7 EB 
    pop    af              ; 0028D8 F1 
    ret                    ; 0028D9 C9 
    pop    af              ; 0028DA F1 
    ld     e,$1a           ; 0028DB 1E 1A 
    jp     z,$19a2         ; 0028DD CA A2 19 
    cp     a               ; 0028E0 BF 
    push   af              ; 0028E1 F5 
    ld     bc,$28c1        ; 0028E2 01 C1 28 
    push   bc              ; 0028E5 C5 
    ld     hl,($78b1)      ; 0028E6 2A B1 78 
    ld     ($78d6),hl      ; 0028E9 22 D6 78 
    ld     hl,$0000        ; 0028EC 21 00 00 
    push   hl              ; 0028EF E5 
    ld     hl,($78a0)      ; 0028F0 2A A0 78 
    push   hl              ; 0028F3 E5 
    ld     hl,$78b5        ; 0028F4 21 B5 78 
    ex     de,hl           ; 0028F7 EB 
    ld     hl,($78b3)      ; 0028F8 2A B3 78 
    ex     de,hl           ; 0028FB EB 
    rst    18h             ; 0028FC DF 
    ld     bc,$28f7        ; 0028FD 01 F7 28 
    jp     nz,$294a        ; 002900 C2 4A 29 
    ld     hl,($78f9)      ; 002903 2A F9 78 
    ex     de,hl           ; 002906 EB 
    ld     hl,($78fb)      ; 002907 2A FB 78 
    ex     de,hl           ; 00290A EB 
    rst    18h             ; 00290B DF 
    jr     z,$2921         ; 00290C 28 13 
    ld     a,(hl)          ; 00290E 7E 
    inc    hl              ; 00290F 23 
    inc    hl              ; 002910 23 
    inc    hl              ; 002911 23 
    cp     $03             ; 002912 FE 03 
    jr     nz,$291a        ; 002914 20 04 
    call   $294b           ; 002916 CD 4B 29 
    xor    a               ; 002919 AF 
    ld     e,a             ; 00291A 5F 
    ld     d,$00           ; 00291B 16 00 
    add    hl,de           ; 00291D 19 
    jr     $2906           ; 00291E 18 E6 
    pop    bc              ; 002920 C1 
    ex     de,hl           ; 002921 EB 
    ld     hl,($78fd)      ; 002922 2A FD 78 
    ex     de,hl           ; 002925 EB 
    rst    18h             ; 002926 DF 
    jp     z,$296b         ; 002927 CA 6B 29 
    ld     a,(hl)          ; 00292A 7E 
    inc    hl              ; 00292B 23 
    call   $09c2           ; 00292C CD C2 09 
    push   hl              ; 00292F E5 
    add    hl,bc           ; 002930 09 
    cp     $03             ; 002931 FE 03 
    jr     nz,$2920        ; 002933 20 EB 
    ld     ($78d8),hl      ; 002935 22 D8 78 
    pop    hl              ; 002938 E1 
    ld     c,(hl)          ; 002939 4E 
    ld     b,$00           ; 00293A 06 00 
    add    hl,bc           ; 00293C 09 
    add    hl,bc           ; 00293D 09 
    inc    hl              ; 00293E 23 
    ex     de,hl           ; 00293F EB 
    ld     hl,($78d8)      ; 002940 2A D8 78 
    ex     de,hl           ; 002943 EB 
    rst    18h             ; 002944 DF 
    jr     z,$2921         ; 002945 28 DA 
    ld     bc,$293f        ; 002947 01 3F 29 
    push   bc              ; 00294A C5 
    xor    a               ; 00294B AF 
    or     (hl)            ; 00294C B6 
    inc    hl              ; 00294D 23 
    ld     e,(hl)          ; 00294E 5E 
    inc    hl              ; 00294F 23 
    ld     d,(hl)          ; 002950 56 
    inc    hl              ; 002951 23 
    ret    z               ; 002952 C8 
    ld     b,h             ; 002953 44 
    ld     c,l             ; 002954 4D 
    ld     hl,($78d6)      ; 002955 2A D6 78 
    rst    18h             ; 002958 DF 
    ld     h,b             ; 002959 60 
    ld     l,c             ; 00295A 69 
    ret    c               ; 00295B D8 
    pop    hl              ; 00295C E1 
    ex     (sp),hl         ; 00295D E3 
    rst    18h             ; 00295E DF 
    ex     (sp),hl         ; 00295F E3 
    push   hl              ; 002960 E5 
    ld     h,b             ; 002961 60 
    ld     l,c             ; 002962 69 
    ret    nc              ; 002963 D0 
    pop    bc              ; 002964 C1 
    pop    af              ; 002965 F1 
    pop    af              ; 002966 F1 
    push   hl              ; 002967 E5 
    push   de              ; 002968 D5 
    push   bc              ; 002969 C5 
    ret                    ; 00296A C9 
    pop    de              ; 00296B D1 
    pop    hl              ; 00296C E1 
    ld     a,l             ; 00296D 7D 
    or     h               ; 00296E B4 
    ret    z               ; 00296F C8 
    dec    hl              ; 002970 2B 
    ld     b,(hl)          ; 002971 46 
    dec    hl              ; 002972 2B 
    ld     c,(hl)          ; 002973 4E 
    push   hl              ; 002974 E5 
    dec    hl              ; 002975 2B 
    ld     l,(hl)          ; 002976 6E 
    ld     h,$00           ; 002977 26 00 
    add    hl,bc           ; 002979 09 
    ld     d,b             ; 00297A 50 
    ld     e,c             ; 00297B 59 
    dec    hl              ; 00297C 2B 
    ld     b,h             ; 00297D 44 
    ld     c,l             ; 00297E 4D 
    ld     hl,($78d6)      ; 00297F 2A D6 78 
    call   $1958           ; 002982 CD 58 19 
    pop    hl              ; 002985 E1 
    ld     (hl),c          ; 002986 71 
    inc    hl              ; 002987 23 
    ld     (hl),b          ; 002988 70 
    ld     l,c             ; 002989 69 
    ld     h,b             ; 00298A 60 
    dec    hl              ; 00298B 2B 
    jp     $28e9           ; 00298C C3 E9 28 
    push   bc              ; 00298F C5 
    push   hl              ; 002990 E5 
    ld     hl,($7921)      ; 002991 2A 21 79 
    ex     (sp),hl         ; 002994 E3 
    call   $249f           ; 002995 CD 9F 24 
    ex     (sp),hl         ; 002998 E3 
    call   $0af4           ; 002999 CD F4 0A 
    ld     a,(hl)          ; 00299C 7E 
    push   hl              ; 00299D E5 
    ld     hl,($7921)      ; 00299E 2A 21 79 
    push   hl              ; 0029A1 E5 
    add    a,(hl)          ; 0029A2 86 
    ld     e,$1c           ; 0029A3 1E 1C 
    jp     c,$19a2         ; 0029A5 DA A2 19 
    call   $2857           ; 0029A8 CD 57 28 
    pop    de              ; 0029AB D1 
    call   $29de           ; 0029AC CD DE 29 
    ex     (sp),hl         ; 0029AF E3 
    call   $29dd           ; 0029B0 CD DD 29 
    push   hl              ; 0029B3 E5 
    ld     hl,($78d4)      ; 0029B4 2A D4 78 
    ex     de,hl           ; 0029B7 EB 
    call   $29c6           ; 0029B8 CD C6 29 
    call   $29c6           ; 0029BB CD C6 29 
    ld     hl,$2349        ; 0029BE 21 49 23 
    ex     (sp),hl         ; 0029C1 E3 
    push   hl              ; 0029C2 E5 
    jp     $2884           ; 0029C3 C3 84 28 
    pop    hl              ; 0029C6 E1 
    ex     (sp),hl         ; 0029C7 E3 
    ld     a,(hl)          ; 0029C8 7E 
    inc    hl              ; 0029C9 23 
    ld     c,(hl)          ; 0029CA 4E 
    inc    hl              ; 0029CB 23 
    ld     b,(hl)          ; 0029CC 46 
    ld     l,a             ; 0029CD 6F 
    inc    l               ; 0029CE 2C 
    dec    l               ; 0029CF 2D 
    ret    z               ; 0029D0 C8 
    ld     a,(bc)          ; 0029D1 0A 
    ld     (de),a          ; 0029D2 12 
    inc    bc              ; 0029D3 03 
    inc    de              ; 0029D4 13 
    jr     $29cf           ; 0029D5 18 F8 
    call   $0af4           ; 0029D7 CD F4 0A 
    ld     hl,($7921)      ; 0029DA 2A 21 79 
    ex     de,hl           ; 0029DD EB 
    call   $29f5           ; 0029DE CD F5 29 
    ex     de,hl           ; 0029E1 EB 
    ret    nz              ; 0029E2 C0 
    push   de              ; 0029E3 D5 
    ld     d,b             ; 0029E4 50 
    ld     e,c             ; 0029E5 59 
    dec    de              ; 0029E6 1B 
    ld     c,(hl)          ; 0029E7 4E 
    ld     hl,($78d6)      ; 0029E8 2A D6 78 
    rst    18h             ; 0029EB DF 
    jr     nz,$29f3        ; 0029EC 20 05 
    ld     b,a             ; 0029EE 47 
    add    hl,bc           ; 0029EF 09 
    ld     ($78d6),hl      ; 0029F0 22 D6 78 
    pop    hl              ; 0029F3 E1 
    ret                    ; 0029F4 C9 
    ld     hl,($78b3)      ; 0029F5 2A B3 78 
    dec    hl              ; 0029F8 2B 
    ld     b,(hl)          ; 0029F9 46 
    dec    hl              ; 0029FA 2B 
    ld     c,(hl)          ; 0029FB 4E 
    dec    hl              ; 0029FC 2B 
    rst    18h             ; 0029FD DF 
    ret    nz              ; 0029FE C0 
    ld     ($78b3),hl      ; 0029FF 22 B3 78 
    ret                    ; 002A02 C9 
    ld     bc,$27f8        ; 002A03 01 F8 27 
    push   bc              ; 002A06 C5 
    call   $29d7           ; 002A07 CD D7 29 
    xor    a               ; 002A0A AF 
    ld     d,a             ; 002A0B 57 
    ld     a,(hl)          ; 002A0C 7E 
    or     a               ; 002A0D B7 
    ret                    ; 002A0E C9 
    ld     bc,$27f8        ; 002A0F 01 F8 27 
    push   bc              ; 002A12 C5 
    call   $2a07           ; 002A13 CD 07 2A 
    jp     z,$1e4a         ; 002A16 CA 4A 1E 
    inc    hl              ; 002A19 23 
    ld     e,(hl)          ; 002A1A 5E 
    inc    hl              ; 002A1B 23 
    ld     d,(hl)          ; 002A1C 56 
    ld     a,(de)          ; 002A1D 1A 
    ret                    ; 002A1E C9 
    ld     a,$01           ; 002A1F 3E 01 
    call   $2857           ; 002A21 CD 57 28 
    call   $2b1f           ; 002A24 CD 1F 2B 
    ld     hl,($78d4)      ; 002A27 2A D4 78 
    ld     (hl),e          ; 002A2A 73 
    pop    bc              ; 002A2B C1 
    jp     $2884           ; 002A2C C3 84 28 
    rst    10h             ; 002A2F D7 
    rst    08h             ; 002A30 CF 
    jr     z,$2a00         ; 002A31 28 CD 
    inc    e               ; 002A33 1C 
    dec    hl              ; 002A34 2B 
    push   de              ; 002A35 D5 
    rst    08h             ; 002A36 CF 
    inc    l               ; 002A37 2C 
    call   $2337           ; 002A38 CD 37 23 
    rst    08h             ; 002A3B CF 
    add    hl,hl           ; 002A3C 29 
    ex     (sp),hl         ; 002A3D E3 
    push   hl              ; 002A3E E5 
    rst    20h             ; 002A3F E7 
    jr     z,$2a47         ; 002A40 28 05 
    call   $2b1f           ; 002A42 CD 1F 2B 
    jr     $2a4a           ; 002A45 18 03 
    call   $2a13           ; 002A47 CD 13 2A 
    pop    de              ; 002A4A D1 
    push   af              ; 002A4B F5 
    push   af              ; 002A4C F5 
    ld     a,e             ; 002A4D 7B 
    call   $2857           ; 002A4E CD 57 28 
    ld     e,a             ; 002A51 5F 
    pop    af              ; 002A52 F1 
    inc    e               ; 002A53 1C 
    dec    e               ; 002A54 1D 
    jr     z,$2a2b         ; 002A55 28 D4 
    ld     hl,($78d4)      ; 002A57 2A D4 78 
    ld     (hl),a          ; 002A5A 77 
    inc    hl              ; 002A5B 23 
    dec    e               ; 002A5C 1D 
    jr     nz,$2a5a        ; 002A5D 20 FB 
    jr     $2a2b           ; 002A5F 18 CA 
    call   $2adf           ; 002A61 CD DF 2A 
    xor    a               ; 002A64 AF 
    ex     (sp),hl         ; 002A65 E3 
    ld     c,a             ; 002A66 4F 
    ld     a,$e5           ; 002A67 3E E5 
    push   hl              ; 002A69 E5 
    ld     a,(hl)          ; 002A6A 7E 
    cp     b               ; 002A6B B8 
    jr     c,$2a70         ; 002A6C 38 02 
    ld     a,b             ; 002A6E 78 
    ld     de,$000e        ; 002A6F 11 0E 00 
    push   bc              ; 002A72 C5 
    call   $28bf           ; 002A73 CD BF 28 
    pop    bc              ; 002A76 C1 
    pop    hl              ; 002A77 E1 
    push   hl              ; 002A78 E5 
    inc    hl              ; 002A79 23 
    ld     b,(hl)          ; 002A7A 46 
    inc    hl              ; 002A7B 23 
    ld     h,(hl)          ; 002A7C 66 
    ld     l,b             ; 002A7D 68 
    ld     b,$00           ; 002A7E 06 00 
    add    hl,bc           ; 002A80 09 
    ld     b,h             ; 002A81 44 
    ld     c,l             ; 002A82 4D 
    call   $285a           ; 002A83 CD 5A 28 
    ld     l,a             ; 002A86 6F 
    call   $29ce           ; 002A87 CD CE 29 
    pop    de              ; 002A8A D1 
    call   $29de           ; 002A8B CD DE 29 
    jp     $2884           ; 002A8E C3 84 28 
    call   $2adf           ; 002A91 CD DF 2A 
    pop    de              ; 002A94 D1 
    push   de              ; 002A95 D5 
    ld     a,(de)          ; 002A96 1A 
    sub    b               ; 002A97 90 
    jr     $2a65           ; 002A98 18 CB 
    ex     de,hl           ; 002A9A EB 
    ld     a,(hl)          ; 002A9B 7E 
    call   $2ae2           ; 002A9C CD E2 2A 
    inc    b               ; 002A9F 04 
    dec    b               ; 002AA0 05 
    jp     z,$1e4a         ; 002AA1 CA 4A 1E 
    push   bc              ; 002AA4 C5 
    ld     e,$ff           ; 002AA5 1E FF 
    cp     $29             ; 002AA7 FE 29 
    jr     z,$2ab0         ; 002AA9 28 05 
    rst    08h             ; 002AAB CF 
    inc    l               ; 002AAC 2C 
    call   $2b1c           ; 002AAD CD 1C 2B 
    rst    08h             ; 002AB0 CF 
    add    hl,hl           ; 002AB1 29 
    pop    af              ; 002AB2 F1 
    ex     (sp),hl         ; 002AB3 E3 
    ld     bc,$2a69        ; 002AB4 01 69 2A 
    push   bc              ; 002AB7 C5 
    dec    a               ; 002AB8 3D 
    cp     (hl)            ; 002AB9 BE 
    ld     b,$00           ; 002ABA 06 00 
    ret    nc              ; 002ABC D0 
    ld     c,a             ; 002ABD 4F 
    ld     a,(hl)          ; 002ABE 7E 
    sub    c               ; 002ABF 91 
    cp     e               ; 002AC0 BB 
    ld     b,a             ; 002AC1 47 
    ret    c               ; 002AC2 D8 
    ld     b,e             ; 002AC3 43 
    ret                    ; 002AC4 C9 
    call   $2a07           ; 002AC5 CD 07 2A 
    jp     z,$27f8         ; 002AC8 CA F8 27 
    ld     e,a             ; 002ACB 5F 
    inc    hl              ; 002ACC 23 
    ld     a,(hl)          ; 002ACD 7E 
    inc    hl              ; 002ACE 23 
    ld     h,(hl)          ; 002ACF 66 
    ld     l,a             ; 002AD0 6F 
    push   hl              ; 002AD1 E5 
    add    hl,de           ; 002AD2 19 
    ld     b,(hl)          ; 002AD3 46 
    ld     (hl),d          ; 002AD4 72 
    ex     (sp),hl         ; 002AD5 E3 
    push   bc              ; 002AD6 C5 
    ld     a,(hl)          ; 002AD7 7E 
    call   $0e65           ; 002AD8 CD 65 0E 
    pop    bc              ; 002ADB C1 
    pop    hl              ; 002ADC E1 
    ld     (hl),b          ; 002ADD 70 
    ret                    ; 002ADE C9 
    ex     de,hl           ; 002ADF EB 
    rst    08h             ; 002AE0 CF 
    add    hl,hl           ; 002AE1 29 
    pop    bc              ; 002AE2 C1 
    pop    de              ; 002AE3 D1 
    push   bc              ; 002AE4 C5 
    ld     b,e             ; 002AE5 43 
    ret                    ; 002AE6 C9 
    cp     $7a             ; 002AE7 FE 7A 
    jp     nz,$1997        ; 002AE9 C2 97 19 
    jp     $79d9           ; 002AEC C3 D9 79 
    call   $2b1f           ; 002AEF CD 1F 2B 
    ld     ($7894),a       ; 002AF2 32 94 78 
    call   $7893           ; 002AF5 CD 93 78 
    jp     $27f8           ; 002AF8 C3 F8 27 
    call   $2b0e           ; 002AFB CD 0E 2B 
    jp     $7896           ; 002AFE C3 96 78 
    rst    10h             ; 002B01 D7 
    call   $2337           ; 002B02 CD 37 23 
    push   hl              ; 002B05 E5 
    call   $0a7f           ; 002B06 CD 7F 0A 
    ex     de,hl           ; 002B09 EB 
    pop    hl              ; 002B0A E1 
    ld     a,d             ; 002B0B 7A 
    or     a               ; 002B0C B7 
    ret                    ; 002B0D C9 
    call   $2b1c           ; 002B0E CD 1C 2B 
    ld     ($7894),a       ; 002B11 32 94 78 
    ld     ($7897),a       ; 002B14 32 97 78 
    rst    08h             ; 002B17 CF 
    inc    l               ; 002B18 2C 
    jr     $2b1c           ; 002B19 18 01 
    rst    10h             ; 002B1B D7 
    call   $2337           ; 002B1C CD 37 23 
    call   $2b05           ; 002B1F CD 05 2B 
    jp     nz,$1e4a        ; 002B22 C2 4A 1E 
    dec    hl              ; 002B25 2B 
    rst    10h             ; 002B26 D7 
    ld     a,e             ; 002B27 7B 
    ret                    ; 002B28 C9 
    ld     a,$01           ; 002B29 3E 01 
    ld     ($789c),a       ; 002B2B 32 9C 78 
    pop    bc              ; 002B2E C1 
    call   $1b10           ; 002B2F CD 10 1B 
    push   bc              ; 002B32 C5 
    call   $3b25           ; 002B33 CD 25 3B 
    ld     ($78a2),hl      ; 002B36 22 A2 78 
    pop    hl              ; 002B39 E1 
    pop    de              ; 002B3A D1 
    ld     c,(hl)          ; 002B3B 4E 
    inc    hl              ; 002B3C 23 
    ld     b,(hl)          ; 002B3D 46 
    inc    hl              ; 002B3E 23 
    ld     a,b             ; 002B3F 78 
    or     c               ; 002B40 B1 
    jp     z,$1a19         ; 002B41 CA 19 1A 
    call   $79df           ; 002B44 CD DF 79 
    call   $1d9b           ; 002B47 CD 9B 1D 
    push   bc              ; 002B4A C5 
    ld     c,(hl)          ; 002B4B 4E 
    inc    hl              ; 002B4C 23 
    ld     b,(hl)          ; 002B4D 46 
    inc    hl              ; 002B4E 23 
    push   bc              ; 002B4F C5 
    ex     (sp),hl         ; 002B50 E3 
    ex     de,hl           ; 002B51 EB 
    rst    18h             ; 002B52 DF 
    pop    bc              ; 002B53 C1 
    jp     c,$1a18         ; 002B54 DA 18 1A 
    ex     (sp),hl         ; 002B57 E3 
    push   hl              ; 002B58 E5 
    push   bc              ; 002B59 C5 
    ex     de,hl           ; 002B5A EB 
    ld     ($78ec),hl      ; 002B5B 22 EC 78 
    call   $0faf           ; 002B5E CD AF 0F 
    ld     a,$20           ; 002B61 3E 20 
    pop    hl              ; 002B63 E1 
    call   $032a           ; 002B64 CD 2A 03 
    call   $2b7e           ; 002B67 CD 7E 2B 
    ld     hl,($78a7)      ; 002B6A 2A A7 78 
    call   $2b75           ; 002B6D CD 75 2B 
    call   $20fe           ; 002B70 CD FE 20 
    jr     $2b33           ; 002B73 18 BE 
    ld     a,(hl)          ; 002B75 7E 
    or     a               ; 002B76 B7 
    ret    z               ; 002B77 C8 
    call   $032a           ; 002B78 CD 2A 03 
    inc    hl              ; 002B7B 23 
    jr     $2b75           ; 002B7C 18 F7 
    push   hl              ; 002B7E E5 
    ld     hl,($78a7)      ; 002B7F 2A A7 78 
    ld     b,h             ; 002B82 44 
    ld     c,l             ; 002B83 4D 
    pop    hl              ; 002B84 E1 
    ld     d,$ff           ; 002B85 16 FF 
    jr     $2b8c           ; 002B87 18 03 
    inc    bc              ; 002B89 03 
    dec    d               ; 002B8A 15 
    ret    z               ; 002B8B C8 
    ld     a,(hl)          ; 002B8C 7E 
    or     a               ; 002B8D B7 
    inc    hl              ; 002B8E 23 
    ld     (bc),a          ; 002B8F 02 
    ret    z               ; 002B90 C8 
    jp     $2e9d           ; 002B91 C3 9D 2E 
    cp     $fb             ; 002B94 FE FB 
    jr     nz,$2ba0        ; 002B96 20 08 
    dec    bc              ; 002B98 0B 
    dec    bc              ; 002B99 0B 
    dec    bc              ; 002B9A 0B 
    dec    bc              ; 002B9B 0B 
    inc    d               ; 002B9C 14 
    inc    d               ; 002B9D 14 
    inc    d               ; 002B9E 14 
    inc    d               ; 002B9F 14 
    cp     $95             ; 002BA0 FE 95 
    call   z,$0b24         ; 002BA2 CC 24 0B 
    sub    $7f             ; 002BA5 D6 7F 
    push   hl              ; 002BA7 E5 
    ld     e,a             ; 002BA8 5F 
    ld     hl,$1650        ; 002BA9 21 50 16 
    ld     a,(hl)          ; 002BAC 7E 
    or     a               ; 002BAD B7 
    inc    hl              ; 002BAE 23 
    jp     p,$2bac         ; 002BAF F2 AC 2B 
    dec    e               ; 002BB2 1D 
    jr     nz,$2bac        ; 002BB3 20 F7 
    and    $7f             ; 002BB5 E6 7F 
    ld     (bc),a          ; 002BB7 02 
    inc    bc              ; 002BB8 03 
    dec    d               ; 002BB9 15 
    jp     z,$28d8         ; 002BBA CA D8 28 
    ld     a,(hl)          ; 002BBD 7E 
    inc    hl              ; 002BBE 23 
    or     a               ; 002BBF B7 
    jp     p,$2bb7         ; 002BC0 F2 B7 2B 
    pop    hl              ; 002BC3 E1 
    jr     $2b8c           ; 002BC4 18 C6 
    call   $1b10           ; 002BC6 CD 10 1B 
    pop    de              ; 002BC9 D1 
    push   bc              ; 002BCA C5 
    push   bc              ; 002BCB C5 
    call   $1b2c           ; 002BCC CD 2C 1B 
    jr     nc,$2bd6        ; 002BCF 30 05 
    ld     d,h             ; 002BD1 54 
    ld     e,l             ; 002BD2 5D 
    ex     (sp),hl         ; 002BD3 E3 
    push   hl              ; 002BD4 E5 
    rst    18h             ; 002BD5 DF 
    jp     nc,$1e4a        ; 002BD6 D2 4A 1E 
    ld     hl,$1929        ; 002BD9 21 29 19 
    call   $28a7           ; 002BDC CD A7 28 
    pop    bc              ; 002BDF C1 
    ld     hl,$1ae8        ; 002BE0 21 E8 1A 
    ex     (sp),hl         ; 002BE3 E3 
    ex     de,hl           ; 002BE4 EB 
    ld     hl,($78f9)      ; 002BE5 2A F9 78 
    ld     a,(de)          ; 002BE8 1A 
    ld     (bc),a          ; 002BE9 02 
    inc    bc              ; 002BEA 03 
    inc    de              ; 002BEB 13 
    rst    18h             ; 002BEC DF 
    jr     nz,$2be8        ; 002BED 20 F9 
    ld     h,b             ; 002BEF 60 
    ld     l,c             ; 002BF0 69 
    ld     ($78f9),hl      ; 002BF1 22 F9 78 
    ret                    ; 002BF4 C9 
    call   $2b1c           ; 002BF5 CD 1C 2B 
    cp     $20             ; 002BF8 FE 20 
    jp     nc,$1e4a        ; 002BFA D2 4A 1E 
    ld     ($7ad2),a       ; 002BFD 32 D2 7A 
    rst    08h             ; 002C00 CF 
    inc    l               ; 002C01 2C 
    call   $2b1c           ; 002C02 CD 1C 2B 
    or     a               ; 002C05 B7 
    jp     z,$1e4a         ; 002C06 CA 4A 1E 
    cp     $0a             ; 002C09 FE 0A 
    jp     nc,$1e4a        ; 002C0B D2 4A 1E 
    di                     ; 002C0E F3 
    push   hl              ; 002C0F E5 
    dec    a               ; 002C10 3D 
    push   af              ; 002C11 F5 
    ld     a,($7ad2)       ; 002C12 3A D2 7A 
    or     a               ; 002C15 B7 
    jr     z,$2c58         ; 002C16 28 40 
    dec    a               ; 002C18 3D 
    sla    a               ; 002C19 CB 27 
    ld     c,a             ; 002C1B 4F 
    xor    a               ; 002C1C AF 
    ld     b,a             ; 002C1D 47 
    pop    af              ; 002C1E F1 
    ld     hl,$02cf        ; 002C1F 21 CF 02 
    add    hl,bc           ; 002C22 09 
    ld     e,(hl)          ; 002C23 5E 
    inc    hl              ; 002C24 23 
    ld     d,(hl)          ; 002C25 56 
    push   de              ; 002C26 D5 
    ld     hl,$0361        ; 002C27 21 61 03 
    srl    c               ; 002C2A CB 39 
    add    hl,bc           ; 002C2C 09 
    ld     e,(hl)          ; 002C2D 5E 
    ld     d,$00           ; 002C2E 16 00 
    ld     hl,$0321        ; 002C30 21 21 03 
    ld     c,a             ; 002C33 4F 
    add    hl,bc           ; 002C34 09 
    ld     b,(hl)          ; 002C35 46 
    push   de              ; 002C36 D5 
    pop    hl              ; 002C37 E1 
    add    hl,de           ; 002C38 19 
    djnz   $2c38           ; 002C39 10 FD 
    push   hl              ; 002C3B E5 
    pop    bc              ; 002C3C C1 
    pop    hl              ; 002C3D E1 
    call   $3af8           ; 002C3E CD F8 3A 
    ld     a,($783b)       ; 002C41 3A 3B 78 
    ld     d,a             ; 002C44 57 
    call   $3469           ; 002C45 CD 69 34 
    dec    bc              ; 002C48 0B 
    ld     a,c             ; 002C49 79 
    or     b               ; 002C4A B0 
    jr     nz,$2c3e        ; 002C4B 20 F1 
    pop    hl              ; 002C4D E1 
    ei                     ; 002C4E FB 
    ld     a,(hl)          ; 002C4F 7E 
    inc    hl              ; 002C50 23 
    cp     $3b             ; 002C51 FE 3B 
    jp     z,$2bf5         ; 002C53 CA F5 2B 
    dec    hl              ; 002C56 2B 
    ret                    ; 002C57 C9 
    pop    af              ; 002C58 F1 
    ld     c,a             ; 002C59 4F 
    xor    a               ; 002C5A AF 
    ld     b,a             ; 002C5B 47 
    ld     hl,$0321        ; 002C5C 21 21 03 
    add    hl,bc           ; 002C5F 09 
    ld     b,(hl)          ; 002C60 46 
    ld     hl,$1936        ; 002C61 21 36 19 
    push   hl              ; 002C64 E5 
    pop    de              ; 002C65 D1 
    add    hl,de           ; 002C66 19 
    djnz   $2c66           ; 002C67 10 FD 
    call   $3af8           ; 002C69 CD F8 3A 
    dec    hl              ; 002C6C 2B 
    ld     a,l             ; 002C6D 7D 
    or     h               ; 002C6E B4 
    jr     nz,$2c69        ; 002C6F 20 F8 
    jr     $2c4d           ; 002C71 18 DA 
    push   bc              ; 002C73 C5 
    ld     b,a             ; 002C74 47 
    ld     a,$08           ; 002C75 3E 08 
    call   $3aba           ; 002C77 CD BA 3A 
    ld     a,b             ; 002C7A 78 
    and    $0f             ; 002C7B E6 0F 
    push   hl              ; 002C7D E5 
    sla    a               ; 002C7E CB 27 
    ld     c,a             ; 002C80 4F 
    xor    a               ; 002C81 AF 
    ld     b,a             ; 002C82 47 
    ld     hl,$02af        ; 002C83 21 AF 02 
    add    hl,bc           ; 002C86 09 
    ld     a,(hl)          ; 002C87 7E 
    ld     b,a             ; 002C88 47 
    inc    hl              ; 002C89 23 
    ld     a,(hl)          ; 002C8A 7E 
    ld     c,a             ; 002C8B 4F 
    ld     a,b             ; 002C8C 78 
    call   $3aba           ; 002C8D CD BA 3A 
    call   $3aba           ; 002C90 CD BA 3A 
    call   $3aba           ; 002C93 CD BA 3A 
    ld     a,c             ; 002C96 79 
    call   $3aba           ; 002C97 CD BA 3A 
    call   $3aba           ; 002C9A CD BA 3A 
    call   $3aba           ; 002C9D CD BA 3A 
    pop    hl              ; 002CA0 E1 
    pop    bc              ; 002CA1 C1 
    ld     a,$0f           ; 002CA2 3E 0F 
    call   $3aba           ; 002CA4 CD BA 3A 
    ret                    ; 002CA7 C9 
    jr     nc,$2c47        ; 002CA8 30 9D 
    call   $0a7f           ; 002CAA CD 7F 0A 
    ld     a,(hl)          ; 002CAD 7E 
    jp     $27f8           ; 002CAE C3 F8 27 
    call   $2b02           ; 002CB1 CD 02 2B 
    push   de              ; 002CB4 D5 
    rst    08h             ; 002CB5 CF 
    inc    l               ; 002CB6 2C 
    call   $2b1c           ; 002CB7 CD 1C 2B 
    pop    de              ; 002CBA D1 
    ld     (de),a          ; 002CBB 12 
    ret                    ; 002CBC C9 
    call   $2338           ; 002CBD CD 38 23 
    call   $0af4           ; 002CC0 CD F4 0A 
    rst    08h             ; 002CC3 CF 
    dec    sp              ; 002CC4 3B 
    ex     de,hl           ; 002CC5 EB 
    ld     hl,($7921)      ; 002CC6 2A 21 79 
    jr     $2cd3           ; 002CC9 18 08 
    ld     a,($78de)       ; 002CCB 3A DE 78 
    or     a               ; 002CCE B7 
    jr     z,$2cdd         ; 002CCF 28 0C 
    pop    de              ; 002CD1 D1 
    ex     de,hl           ; 002CD2 EB 
    push   hl              ; 002CD3 E5 
    xor    a               ; 002CD4 AF 
    ld     ($78de),a       ; 002CD5 32 DE 78 
    cp     d               ; 002CD8 BA 
    push   af              ; 002CD9 F5 
    push   de              ; 002CDA D5 
    ld     b,(hl)          ; 002CDB 46 
    or     b               ; 002CDC B0 
    jp     z,$1e4a         ; 002CDD CA 4A 1E 
    inc    hl              ; 002CE0 23 
    ld     c,(hl)          ; 002CE1 4E 
    inc    hl              ; 002CE2 23 
    ld     h,(hl)          ; 002CE3 66 
    ld     l,c             ; 002CE4 69 
    jr     $2d03           ; 002CE5 18 1C 
    ld     e,b             ; 002CE7 58 
    push   hl              ; 002CE8 E5 
    ld     c,$02           ; 002CE9 0E 02 
    ld     a,(hl)          ; 002CEB 7E 
    inc    hl              ; 002CEC 23 
    cp     $25             ; 002CED FE 25 
    jp     z,$2e17         ; 002CEF CA 17 2E 
    cp     $20             ; 002CF2 FE 20 
    jr     nz,$2cf9        ; 002CF4 20 03 
    inc    c               ; 002CF6 0C 
    djnz   $2ceb           ; 002CF7 10 F2 
    pop    hl              ; 002CF9 E1 
    ld     b,e             ; 002CFA 43 
    ld     a,$25           ; 002CFB 3E 25 
    call   $2e49           ; 002CFD CD 49 2E 
    call   $032a           ; 002D00 CD 2A 03 
    xor    a               ; 002D03 AF 
    ld     e,a             ; 002D04 5F 
    ld     d,a             ; 002D05 57 
    call   $2e49           ; 002D06 CD 49 2E 
    ld     d,a             ; 002D09 57 
    ld     a,(hl)          ; 002D0A 7E 
    inc    hl              ; 002D0B 23 
    cp     $21             ; 002D0C FE 21 
    jp     z,$2e14         ; 002D0E CA 14 2E 
    cp     $23             ; 002D11 FE 23 
    jr     z,$2d4c         ; 002D13 28 37 
    dec    b               ; 002D15 05 
    jp     z,$2dfe         ; 002D16 CA FE 2D 
    cp     $2b             ; 002D19 FE 2B 
    ld     a,$08           ; 002D1B 3E 08 
    jr     z,$2d06         ; 002D1D 28 E7 
    dec    hl              ; 002D1F 2B 
    ld     a,(hl)          ; 002D20 7E 
    inc    hl              ; 002D21 23 
    cp     $2e             ; 002D22 FE 2E 
    jr     z,$2d66         ; 002D24 28 40 
    cp     $25             ; 002D26 FE 25 
    jr     z,$2ce7         ; 002D28 28 BD 
    cp     (hl)            ; 002D2A BE 
    jr     nz,$2cfd        ; 002D2B 20 D0 
    cp     $24             ; 002D2D FE 24 
    jr     z,$2d45         ; 002D2F 28 14 
    cp     $2a             ; 002D31 FE 2A 
    jr     nz,$2cfd        ; 002D33 20 C8 
    ld     a,b             ; 002D35 78 
    cp     $02             ; 002D36 FE 02 
    inc    hl              ; 002D38 23 
    jr     c,$2d3e         ; 002D39 38 03 
    ld     a,(hl)          ; 002D3B 7E 
    cp     $24             ; 002D3C FE 24 
    ld     a,$20           ; 002D3E 3E 20 
    jr     nz,$2d49        ; 002D40 20 07 
    dec    b               ; 002D42 05 
    inc    e               ; 002D43 1C 
    cp     $af             ; 002D44 FE AF 
    add    a,$10           ; 002D46 C6 10 
    inc    hl              ; 002D48 23 
    inc    e               ; 002D49 1C 
    add    a,d             ; 002D4A 82 
    ld     d,a             ; 002D4B 57 
    inc    e               ; 002D4C 1C 
    ld     c,$00           ; 002D4D 0E 00 
    dec    b               ; 002D4F 05 
    jr     z,$2d99         ; 002D50 28 47 
    ld     a,(hl)          ; 002D52 7E 
    inc    hl              ; 002D53 23 
    cp     $2e             ; 002D54 FE 2E 
    jr     z,$2d70         ; 002D56 28 18 
    cp     $23             ; 002D58 FE 23 
    jr     z,$2d4c         ; 002D5A 28 F0 
    cp     $2c             ; 002D5C FE 2C 
    jr     nz,$2d7a        ; 002D5E 20 1A 
    ld     a,d             ; 002D60 7A 
    or     $40             ; 002D61 F6 40 
    ld     d,a             ; 002D63 57 
    jr     $2d4c           ; 002D64 18 E6 
    ld     a,(hl)          ; 002D66 7E 
    cp     $23             ; 002D67 FE 23 
    ld     a,$2e           ; 002D69 3E 2E 
    jr     nz,$2cfd        ; 002D6B 20 90 
    ld     c,$01           ; 002D6D 0E 01 
    inc    hl              ; 002D6F 23 
    inc    c               ; 002D70 0C 
    dec    b               ; 002D71 05 
    jr     z,$2d99         ; 002D72 28 25 
    ld     a,(hl)          ; 002D74 7E 
    inc    hl              ; 002D75 23 
    cp     $23             ; 002D76 FE 23 
    jr     z,$2d70         ; 002D78 28 F6 
    push   de              ; 002D7A D5 
    ld     de,$2d97        ; 002D7B 11 97 2D 
    push   de              ; 002D7E D5 
    ld     d,h             ; 002D7F 54 
    ld     e,l             ; 002D80 5D 
    cp     $5b             ; 002D81 FE 5B 
    ret    nz              ; 002D83 C0 
    cp     (hl)            ; 002D84 BE 
    ret    nz              ; 002D85 C0 
    inc    hl              ; 002D86 23 
    cp     (hl)            ; 002D87 BE 
    ret    nz              ; 002D88 C0 
    inc    hl              ; 002D89 23 
    cp     (hl)            ; 002D8A BE 
    ret    nz              ; 002D8B C0 
    inc    hl              ; 002D8C 23 
    ld     a,b             ; 002D8D 78 
    sub    $04             ; 002D8E D6 04 
    ret    c               ; 002D90 D8 
    pop    de              ; 002D91 D1 
    pop    de              ; 002D92 D1 
    ld     b,a             ; 002D93 47 
    inc    d               ; 002D94 14 
    inc    hl              ; 002D95 23 
    jp     z,$d1eb         ; 002D96 CA EB D1 
    ld     a,d             ; 002D99 7A 
    dec    hl              ; 002D9A 2B 
    inc    e               ; 002D9B 1C 
    and    $08             ; 002D9C E6 08 
    jr     nz,$2db5        ; 002D9E 20 15 
    dec    e               ; 002DA0 1D 
    ld     a,b             ; 002DA1 78 
    or     a               ; 002DA2 B7 
    jr     z,$2db5         ; 002DA3 28 10 
    ld     a,(hl)          ; 002DA5 7E 
    sub    $2d             ; 002DA6 D6 2D 
    jr     z,$2db0         ; 002DA8 28 06 
    cp     $fe             ; 002DAA FE FE 
    jr     nz,$2db5        ; 002DAC 20 07 
    ld     a,$08           ; 002DAE 3E 08 
    add    a,$04           ; 002DB0 C6 04 
    add    a,d             ; 002DB2 82 
    ld     d,a             ; 002DB3 57 
    dec    b               ; 002DB4 05 
    pop    hl              ; 002DB5 E1 
    pop    af              ; 002DB6 F1 
    jr     z,$2e09         ; 002DB7 28 50 
    push   bc              ; 002DB9 C5 
    push   de              ; 002DBA D5 
    call   $2337           ; 002DBB CD 37 23 
    pop    de              ; 002DBE D1 
    pop    bc              ; 002DBF C1 
    push   bc              ; 002DC0 C5 
    push   hl              ; 002DC1 E5 
    ld     b,e             ; 002DC2 43 
    ld     a,b             ; 002DC3 78 
    add    a,c             ; 002DC4 81 
    cp     $19             ; 002DC5 FE 19 
    jp     nc,$1e4a        ; 002DC7 D2 4A 1E 
    ld     a,d             ; 002DCA 7A 
    or     $80             ; 002DCB F6 80 
    call   $0fbe           ; 002DCD CD BE 0F 
    call   $28a7           ; 002DD0 CD A7 28 
    pop    hl              ; 002DD3 E1 
    dec    hl              ; 002DD4 2B 
    rst    10h             ; 002DD5 D7 
    scf                    ; 002DD6 37 
    jr     z,$2de6         ; 002DD7 28 0D 
    ld     ($78de),a       ; 002DD9 32 DE 78 
    cp     $3b             ; 002DDC FE 3B 
    jr     z,$2de5         ; 002DDE 28 05 
    cp     $2c             ; 002DE0 FE 2C 
    jp     nz,$1997        ; 002DE2 C2 97 19 
    rst    10h             ; 002DE5 D7 
    pop    bc              ; 002DE6 C1 
    ex     de,hl           ; 002DE7 EB 
    pop    hl              ; 002DE8 E1 
    push   hl              ; 002DE9 E5 
    push   af              ; 002DEA F5 
    push   de              ; 002DEB D5 
    ld     a,(hl)          ; 002DEC 7E 
    sub    b               ; 002DED 90 
    inc    hl              ; 002DEE 23 
    ld     c,(hl)          ; 002DEF 4E 
    inc    hl              ; 002DF0 23 
    ld     h,(hl)          ; 002DF1 66 
    ld     l,c             ; 002DF2 69 
    ld     d,$00           ; 002DF3 16 00 
    ld     e,a             ; 002DF5 5F 
    add    hl,de           ; 002DF6 19 
    ld     a,b             ; 002DF7 78 
    or     a               ; 002DF8 B7 
    jp     nz,$2d03        ; 002DF9 C2 03 2D 
    jr     $2e04           ; 002DFC 18 06 
    call   $2e49           ; 002DFE CD 49 2E 
    call   $032a           ; 002E01 CD 2A 03 
    pop    hl              ; 002E04 E1 
    pop    af              ; 002E05 F1 
    jp     nz,$2ccb        ; 002E06 C2 CB 2C 
    call   c,$20fe         ; 002E09 DC FE 20 
    ex     (sp),hl         ; 002E0C E3 
    call   $29dd           ; 002E0D CD DD 29 
    pop    hl              ; 002E10 E1 
    jp     $2169           ; 002E11 C3 69 21 
    ld     c,$01           ; 002E14 0E 01 
    ld     a,$f1           ; 002E16 3E F1 
    dec    b               ; 002E18 05 
    call   $2e49           ; 002E19 CD 49 2E 
    pop    hl              ; 002E1C E1 
    pop    af              ; 002E1D F1 
    jr     z,$2e09         ; 002E1E 28 E9 
    push   bc              ; 002E20 C5 
    call   $2337           ; 002E21 CD 37 23 
    call   $0af4           ; 002E24 CD F4 0A 
    pop    bc              ; 002E27 C1 
    push   bc              ; 002E28 C5 
    push   hl              ; 002E29 E5 
    ld     hl,($7921)      ; 002E2A 2A 21 79 
    ld     b,c             ; 002E2D 41 
    ld     c,$00           ; 002E2E 0E 00 
    push   bc              ; 002E30 C5 
    call   $2a68           ; 002E31 CD 68 2A 
    call   $28aa           ; 002E34 CD AA 28 
    ld     hl,($7921)      ; 002E37 2A 21 79 
    pop    af              ; 002E3A F1 
    sub    (hl)            ; 002E3B 96 
    ld     b,a             ; 002E3C 47 
    ld     a,$20           ; 002E3D 3E 20 
    inc    b               ; 002E3F 04 
    dec    b               ; 002E40 05 
    jp     z,$2dd3         ; 002E41 CA D3 2D 
    call   $032a           ; 002E44 CD 2A 03 
    jr     $2e40           ; 002E47 18 F7 
    push   af              ; 002E49 F5 
    ld     a,d             ; 002E4A 7A 
    or     a               ; 002E4B B7 
    ld     a,$2b           ; 002E4C 3E 2B 
    call   nz,$032a        ; 002E4E C4 2A 03 
    pop    af              ; 002E51 F1 
    ret                    ; 002E52 C9 
    ld     h,b             ; 002E53 60 
    ld     l,c             ; 002E54 69 
    inc    hl              ; 002E55 23 
    inc    hl              ; 002E56 23 
    inc    hl              ; 002E57 23 
    inc    hl              ; 002E58 23 
    call   $2b7e           ; 002E59 CD 7E 2B 
    ld     hl,($78a7)      ; 002E5C 2A A7 78 
    call   $2b75           ; 002E5F CD 75 2B 
    ret                    ; 002E62 C9 
    rst    08h             ; 002E63 CF 
    jr     z,$2e33         ; 002E64 28 CD 
    inc    e               ; 002E66 1C 
    dec    hl              ; 002E67 2B 
    or     a               ; 002E68 B7 
    jr     z,$2e7d         ; 002E69 28 12 
    dec    a               ; 002E6B 3D 
    jr     z,$2e71         ; 002E6C 28 03 
    jp     $1e4a           ; 002E6E C3 4A 1E 
    ld     d,$00           ; 002E71 16 00 
    ld     a,($783b)       ; 002E73 3A 3B 78 
    or     $08             ; 002E76 F6 08 
    ld     ($783b),a       ; 002E78 32 3B 78 
    jr     $2e87           ; 002E7B 18 0A 
    ld     d,$20           ; 002E7D 16 20 
    ld     a,($783b)       ; 002E7F 3A 3B 78 
    and    $f7             ; 002E82 E6 F7 
    ld     ($783b),a       ; 002E84 32 3B 78 
    ld     ($6800),a       ; 002E87 32 00 68 
    push   hl              ; 002E8A E5 
    ld     hl,$7000        ; 002E8B 21 00 70 
    ld     bc,$0800        ; 002E8E 01 00 08 
    ld     a,d             ; 002E91 7A 
    ld     (hl),a          ; 002E92 77 
    inc    hl              ; 002E93 23 
    dec    bc              ; 002E94 0B 
    ld     a,b             ; 002E95 78 
    or     c               ; 002E96 B1 
    jr     nz,$2e91        ; 002E97 20 F8 
    pop    hl              ; 002E99 E1 
    rst    08h             ; 002E9A CF 
    add    hl,hl           ; 002E9B 29 
    ret                    ; 002E9C C9 
    cp     $22             ; 002E9D FE 22 
    jp     z,$2eb3         ; 002E9F CA B3 2E 
    or     a               ; 002EA2 B7 
    jp     p,$2b89         ; 002EA3 F2 89 2B 
    jp     $2b94           ; 002EA6 C3 94 2B 
    ld     a,(hl)          ; 002EA9 7E 
    or     a               ; 002EAA B7 
    inc    hl              ; 002EAB 23 
    ld     (bc),a          ; 002EAC 02 
    ret    z               ; 002EAD C8 
    cp     $22             ; 002EAE FE 22 
    jp     z,$2b89         ; 002EB0 CA 89 2B 
    inc    bc              ; 002EB3 03 
    dec    d               ; 002EB4 15 
    ret    z               ; 002EB5 C8 
    jr     $2ea9           ; 002EB6 18 F1 
    push   af              ; 002EB8 F5 
    push   bc              ; 002EB9 C5 
    push   de              ; 002EBA D5 
    push   hl              ; 002EBB E5 
    call   $787d           ; 002EBC CD 7D 78 
    call   $3f7b           ; 002EBF CD 7B 3F 
    call   $2edc           ; 002EC2 CD DC 2E 
    call   $2efd           ; 002EC5 CD FD 2E 
    push   af              ; 002EC8 F5 
    ld     hl,$7839        ; 002EC9 21 39 78 
    bit    0,(hl)          ; 002ECC CB 46 
    call   z,$301b         ; 002ECE CC 1B 30 
    pop    af              ; 002ED1 F1 
    call   $3430           ; 002ED2 CD 30 34 
    pop    hl              ; 002ED5 E1 
    pop    de              ; 002ED6 D1 
    pop    bc              ; 002ED7 C1 
    pop    af              ; 002ED8 F1 
    ei                     ; 002ED9 FB 
    reti                   ; 002EDA ED 4D 
    ld     a,($7839)       ; 002EDC 3A 39 78 
    bit    0,a             ; 002EDF CB 47 
    ret    nz              ; 002EE1 C0 
    ld     hl,$7841        ; 002EE2 21 41 78 
    dec    (hl)            ; 002EE5 35 
    ret    nz              ; 002EE6 C0 
    ld     a,$10           ; 002EE7 3E 10 
    ld     ($7841),a       ; 002EE9 32 41 78 
    ld     hl,($7820)      ; 002EEC 2A 20 78 
    ld     a,$40           ; 002EEF 3E 40 
    xor    (hl)            ; 002EF1 AE 
    ld     (hl),a          ; 002EF2 77 
    ret                    ; 002EF3 C9 
    call   $2efd           ; 002EF4 CD FD 2E 
    push   af              ; 002EF7 F5 
    call   $2f0e           ; 002EF8 CD 0E 2F 
    pop    af              ; 002EFB F1 
    ret                    ; 002EFC C9 
    ld     a,($6800)       ; 002EFD 3A 00 68 
    or     $c0             ; 002F00 F6 C0 
    cpl                    ; 002F02 2F 
    cp     $00             ; 002F03 FE 00 
    jr     z,$2f0e         ; 002F05 28 07 
    call   $2f28           ; 002F07 CD 28 2F 
    or     a               ; 002F0A B7 
    jp     nz,$05d7        ; 002F0B C2 D7 05 
    ld     hl,$7838        ; 002F0E 21 38 78 
    bit    2,(hl)          ; 002F11 CB 56 
    jr     z,$2f1d         ; 002F13 28 08 
    ld     a,($783a)       ; 002F15 3A 3A 78 
    or     a               ; 002F18 B7 
    jr     z,$2f1d         ; 002F19 28 02 
    res    2,(hl)          ; 002F1B CB 96 
    ld     a,(hl)          ; 002F1D 7E 
    and    $06             ; 002F1E E6 06 
    ld     ($7838),a       ; 002F20 32 38 78 
    xor    a               ; 002F23 AF 
    ld     ($7836),a       ; 002F24 32 36 78 
    ret                    ; 002F27 C9 
    ld     hl,$68fe        ; 002F28 21 FE 68 
    ld     c,$08           ; 002F2B 0E 08 
    ld     b,$06           ; 002F2D 06 06 
    ld     a,(hl)          ; 002F2F 7E 
    or     $04             ; 002F30 F6 04 
    rra                    ; 002F32 1F 
    jr     nc,$2f62        ; 002F33 30 2D 
    djnz   $2f32           ; 002F35 10 FB 
    rlc    l               ; 002F37 CB 05 
    dec    c               ; 002F39 0D 
    jr     nz,$2f2d        ; 002F3A 20 F1 
    ld     b,$04           ; 002F3C 06 04 
    ld     hl,$68df        ; 002F3E 21 DF 68 
    ld     a,(hl)          ; 002F41 7E 
    bit    2,a             ; 002F42 CB 57 
    jr     z,$2f56         ; 002F44 28 10 
    rlc    l               ; 002F46 CB 05 
    ld     a,(hl)          ; 002F48 7E 
    bit    2,a             ; 002F49 CB 57 
    jr     z,$2f5a         ; 002F4B 28 0D 
    rlc    l               ; 002F4D CB 05 
    ld     a,(hl)          ; 002F4F 7E 
    bit    2,a             ; 002F50 CB 57 
    jr     z,$2f5e         ; 002F52 28 0A 
    xor    a               ; 002F54 AF 
    ret                    ; 002F55 C9 
    ld     c,$03           ; 002F56 0E 03 
    jr     $2f60           ; 002F58 18 06 
    ld     c,$02           ; 002F5A 0E 02 
    jr     $2f60           ; 002F5C 18 02 
    ld     c,$01           ; 002F5E 0E 01 
    or     $04             ; 002F60 F6 04 
    ld     e,a             ; 002F62 5F 
    ld     a,$06           ; 002F63 3E 06 
    sub    b               ; 002F65 90 
    sla    a               ; 002F66 CB 27 
    sla    a               ; 002F68 CB 27 
    sla    a               ; 002F6A CB 27 
    add    a,$08           ; 002F6C C6 08 
    sub    c               ; 002F6E 91 
    ld     ($7842),bc      ; 002F6F ED 43 42 78 
    ld     ($7844),hl      ; 002F73 22 44 78 
    ld     hl,$01d9        ; 002F76 21 D9 01 
    ld     c,a             ; 002F79 4F 
    ld     b,$00           ; 002F7A 06 00 
    ld     a,($68fb)       ; 002F7C 3A FB 68 
    bit    2,a             ; 002F7F CB 57 
    jr     nz,$2f8d        ; 002F81 20 0A 
    ld     hl,$7838        ; 002F83 21 38 78 
    set    0,(hl)          ; 002F86 CB C6 
    ld     hl,$0209        ; 002F88 21 09 02 
    jr     $2fca           ; 002F8B 18 3D 
    ld     a,($68fd)       ; 002F8D 3A FD 68 
    bit    2,a             ; 002F90 CB 57 
    jr     nz,$2fcd        ; 002F92 20 39 
    ld     a,($687f)       ; 002F94 3A 7F 68 
    bit    2,a             ; 002F97 CB 57 
    jr     nz,$2fa9        ; 002F99 20 0E 
    ld     hl,$7838        ; 002F9B 21 38 78 
    bit    5,(hl)          ; 002F9E CB 6E 
    jr     nz,$2fa6        ; 002FA0 20 04 
    ld     a,(hl)          ; 002FA2 7E 
    xor    $22             ; 002FA3 EE 22 
    ld     (hl),a          ; 002FA5 77 
    xor    a               ; 002FA6 AF 
    pop    bc              ; 002FA7 C1 
    ret                    ; 002FA8 C9 
    ld     hl,$7838        ; 002FA9 21 38 78 
    set    7,(hl)          ; 002FAC CB FE 
    bit    2,(hl)          ; 002FAE CB 56 
    jr     z,$2fb7         ; 002FB0 28 05 
    ld     hl,$0269        ; 002FB2 21 69 02 
    jr     $2fca           ; 002FB5 18 13 
    ld     a,($68bf)       ; 002FB7 3A BF 68 
    bit    2,a             ; 002FBA CB 57 
    jr     nz,$2fc5        ; 002FBC 20 07 
    set    2,(hl)          ; 002FBE CB D6 
    xor    a               ; 002FC0 AF 
    ld     ($783a),a       ; 002FC1 32 3A 78 
    ret                    ; 002FC4 C9 
    res    2,(hl)          ; 002FC5 CB 96 
    ld     hl,$0239        ; 002FC7 21 39 02 
    add    hl,bc           ; 002FCA 09 
    ld     a,(hl)          ; 002FCB 7E 
    ret                    ; 002FCC C9 
    ld     a,($7838)       ; 002FCD 3A 38 78 
    and    $81             ; 002FD0 E6 81 
    jr     z,$2fca         ; 002FD2 28 F6 
    xor    a               ; 002FD4 AF 
    pop    hl              ; 002FD5 E1 
    ret                    ; 002FD6 C9 
    ld     hl,$7838        ; 002FD7 21 38 78 
    bit    5,(hl)          ; 002FDA CB 6E 
    jr     z,$3003         ; 002FDC 28 25 
    ld     a,($783a)       ; 002FDE 3A 3A 78 
    inc    a               ; 002FE1 3C 
    ld     ($783a),a       ; 002FE2 32 3A 78 
    cp     $2a             ; 002FE5 FE 2A 
    jr     z,$2feb         ; 002FE7 28 02 
    xor    a               ; 002FE9 AF 
    ret                    ; 002FEA C9 
    ld     a,(hl)          ; 002FEB 7E 
    and    $df             ; 002FEC E6 DF 
    or     $40             ; 002FEE F6 40 
    ld     ($7838),a       ; 002FF0 32 38 78 
    xor    a               ; 002FF3 AF 
    ld     ($783a),a       ; 002FF4 32 3A 78 
    bit    4,(hl)          ; 002FF7 CB 66 
    jr     nz,$2fff        ; 002FF9 20 04 
    ld     a,($7836)       ; 002FFB 3A 36 78 
    ret                    ; 002FFE C9 
    ld     a,($7837)       ; 002FFF 3A 37 78 
    ret                    ; 003002 C9 
    bit    6,(hl)          ; 003003 CB 76 
    jr     nz,$300e        ; 003005 20 07 
    set    5,(hl)          ; 003007 CB EE 
    xor    a               ; 003009 AF 
    ld     ($783a),a       ; 00300A 32 3A 78 
    ret                    ; 00300D C9 
    ld     a,($783a)       ; 00300E 3A 3A 78 
    inc    a               ; 003011 3C 
    ld     ($783a),a       ; 003012 32 3A 78 
    cp     $06             ; 003015 FE 06 
    jr     z,$2ff3         ; 003017 28 DA 
    xor    a               ; 003019 AF 
    ret                    ; 00301A C9 
    or     a               ; 00301B B7 
    ret    z               ; 00301C C8 
    push   af              ; 00301D F5 
    call   $3039           ; 00301E CD 39 30 
    pop    af              ; 003021 F1 
    cp     $0d             ; 003022 FE 0D 
    ret    z               ; 003024 C8 
    cp     $01             ; 003025 FE 01 
    ret    z               ; 003027 C8 
    ld     a,($7839)       ; 003028 3A 39 78 
    bit    0,a             ; 00302B CB 47 
    ret    nz              ; 00302D C0 
    ld     a,$20           ; 00302E 3E 20 
    ld     ($7841),a       ; 003030 32 41 78 
    ld     hl,($7820)      ; 003033 2A 20 78 
    jp     $3eb2           ; 003036 C3 B2 3E 
    ld     hl,$7838        ; 003039 21 38 78 
    bit    7,(hl)          ; 00303C CB 7E 
    jp     z,$3157         ; 00303E CA 57 31 
    or     a               ; 003041 B7 
    jp     p,$3157         ; 003042 F2 57 31 
    push   af              ; 003045 F5 
    sub    $80             ; 003046 D6 80 
    inc    a               ; 003048 3C 
    ld     b,a             ; 003049 47 
    ld     hl,$164f        ; 00304A 21 4F 16 
    inc    hl              ; 00304D 23 
    bit    7,(hl)          ; 00304E CB 7E 
    jr     z,$304d         ; 003050 28 FB 
    djnz   $304d           ; 003052 10 F9 
    ld     a,(hl)          ; 003054 7E 
    call   $3082           ; 003055 CD 82 30 
    ld     a,(hl)          ; 003058 7E 
    bit    7,a             ; 003059 CB 7F 
    jr     z,$3055         ; 00305B 28 F8 
    pop    af              ; 00305D F1 
    ld     b,$16           ; 00305E 06 16 
    ld     hl,$0299        ; 003060 21 99 02 
    cp     (hl)            ; 003063 BE 
    jr     z,$307c         ; 003064 28 16 
    inc    hl              ; 003066 23 
    djnz   $3063           ; 003067 10 FA 
    cp     $b0             ; 003069 FE B0 
    ret    nz              ; 00306B C0 
    ld     a,$20           ; 00306C 3E 20 
    call   $3082           ; 00306E CD 82 30 
    ld     a,$46           ; 003071 3E 46 
    call   $3082           ; 003073 CD 82 30 
    ld     a,$4e           ; 003076 3E 4E 
    call   $3082           ; 003078 CD 82 30 
    ret                    ; 00307B C9 
    ld     a,$28           ; 00307C 3E 28 
    call   $3082           ; 00307E CD 82 30 
    ret                    ; 003081 C9 
    and    $7f             ; 003082 E6 7F 
    push   hl              ; 003084 E5 
    call   $3157           ; 003085 CD 57 31 
    pop    hl              ; 003088 E1 
    inc    hl              ; 003089 23 
    ret                    ; 00308A C9 
    push   af              ; 00308B F5 
    ld     a,($783b)       ; 00308C 3A 3B 78 
    bit    3,a             ; 00308F CB 5F 
    jr     z,$30aa         ; 003091 28 17 
    and    $f7             ; 003093 E6 F7 
    ld     ($783b),a       ; 003095 32 3B 78 
    ld     ($6800),a       ; 003098 32 00 68 
    ld     bc,$0200        ; 00309B 01 00 02 
    ld     hl,$7000        ; 00309E 21 00 70 
    call   $3ebe           ; 0030A1 CD BE 3E 
    inc    hl              ; 0030A4 23 
    dec    bc              ; 0030A5 0B 
    ld     a,c             ; 0030A6 79 
    or     b               ; 0030A7 B0 
    jr     nz,$30a1        ; 0030A8 20 F7 
    pop    af              ; 0030AA F1 
    ld     hl,$7839        ; 0030AB 21 39 78 
    bit    5,(hl)          ; 0030AE CB 6E 
    jp     z,$3106         ; 0030B0 CA 06 31 
    cp     $20             ; 0030B3 FE 20 
    jp     nc,$30c0        ; 0030B5 D2 C0 30 
    push   af              ; 0030B8 F5 
    ld     a,($7aaf)       ; 0030B9 3A AF 7A 
    or     a               ; 0030BC B7 
    jr     nz,$30b9        ; 0030BD 20 FA 
    pop    af              ; 0030BF F1 
    di                     ; 0030C0 F3 
    ld     hl,($7ab0)      ; 0030C1 2A B0 7A 
    ld     (hl),a          ; 0030C4 77 
    inc    hl              ; 0030C5 23 
    ld     ($7ab0),hl      ; 0030C6 22 B0 7A 
    ld     hl,$7aaf        ; 0030C9 21 AF 7A 
    inc    (hl)            ; 0030CC 34 
    push   af              ; 0030CD F5 
    ld     a,($78a6)       ; 0030CE 3A A6 78 
    add    a,(hl)          ; 0030D1 86 
    ld     ($7aae),a       ; 0030D2 32 AE 7A 
    pop    af              ; 0030D5 F1 
    ei                     ; 0030D6 FB 
    cp     $20             ; 0030D7 FE 20 
    jp     c,$30e3         ; 0030D9 DA E3 30 
    ld     a,$14           ; 0030DC 3E 14 
    cp     (hl)            ; 0030DE BE 
    jp     c,$30de         ; 0030DF DA DE 30 
    ret                    ; 0030E2 C9 
    xor    a               ; 0030E3 AF 
    cp     (hl)            ; 0030E4 BE 
    jr     nz,$30e4        ; 0030E5 20 FD 
    ret                    ; 0030E7 C9 
    ld     a,($7aaf)       ; 0030E8 3A AF 7A 
    or     a               ; 0030EB B7 
    ret    z               ; 0030EC C8 
    ld     b,a             ; 0030ED 47 
    ld     hl,$7ab2        ; 0030EE 21 B2 7A 
    push   hl              ; 0030F1 E5 
    ld     a,(hl)          ; 0030F2 7E 
    inc    hl              ; 0030F3 23 
    push   hl              ; 0030F4 E5 
    push   bc              ; 0030F5 C5 
    call   $3106           ; 0030F6 CD 06 31 
    pop    bc              ; 0030F9 C1 
    pop    hl              ; 0030FA E1 
    djnz   $30f2           ; 0030FB 10 F5 
    pop    hl              ; 0030FD E1 
    ld     ($7ab0),hl      ; 0030FE 22 B0 7A 
    xor    a               ; 003101 AF 
    ld     ($7aaf),a       ; 003102 32 AF 7A 
    ret                    ; 003105 C9 
    call   $030d           ; 003106 CD 0D 03 
    or     a               ; 003109 B7 
    jr     z,$3110         ; 00310A 28 04 
    cp     $0d             ; 00310C FE 0D 
    jr     nz,$315a        ; 00310E 20 4A 
    push   af              ; 003110 F5 
    ld     hl,($7820)      ; 003111 2A 20 78 
    ld     a,($78a6)       ; 003114 3A A6 78 
    ld     c,a             ; 003117 4F 
    xor    a               ; 003118 AF 
    ld     b,a             ; 003119 47 
    ld     ($78a6),a       ; 00311A 32 A6 78 
    sbc    hl,bc           ; 00311D ED 42 
    ld     bc,$0020        ; 00311F 01 20 00 
    add    hl,bc           ; 003122 09 
    ld     a,h             ; 003123 7C 
    cp     $72             ; 003124 FE 72 
    call   p,$33f3         ; 003126 F4 F3 33 
    ld     ($7820),hl      ; 003129 22 20 78 
    call   $0053           ; 00312C CD 53 00 
    pop    af              ; 00312F F1 
    or     a               ; 003130 B7 
    ret    z               ; 003131 C8 
    call   $33a8           ; 003132 CD A8 33 
    cp     $80             ; 003135 FE 80 
    ret    z               ; 003137 C8 
    cp     $81             ; 003138 FE 81 
    jr     nz,$3141        ; 00313A 20 05 
    dec    a               ; 00313C 3D 
    ld     (hl),a          ; 00313D 77 
    inc    hl              ; 00313E 23 
    ld     (hl),a          ; 00313F 77 
    ret                    ; 003140 C9 
    ld     a,$80           ; 003141 3E 80 
    ld     (hl),a          ; 003143 77 
    ret                    ; 003144 C9 
    bit    6,a             ; 003145 CB 77 
    jr     z,$314d         ; 003147 28 04 
    jp     $3f60           ; 003149 C3 60 3F 
    nop                    ; 00314C 00 
    and    $8f             ; 00314D E6 8F 
    ld     b,a             ; 00314F 47 
    ld     a,($7846)       ; 003150 3A 46 78 
    or     b               ; 003153 B0 
    ld     b,a             ; 003154 47 
    jr     $31b6           ; 003155 18 5F 
    call   $030d           ; 003157 CD 0D 03 
    or     a               ; 00315A B7 
    jp     m,$3145         ; 00315B FA 45 31 
    cp     $0d             ; 00315E FE 0D 
    ret    z               ; 003160 C8 
    cp     $08             ; 003161 FE 08 
    jp     z,$3227         ; 003163 CA 27 32 
    cp     $1b             ; 003166 FE 1B 
    jp     z,$3253         ; 003168 CA 53 32 
    cp     $0a             ; 00316B FE 0A 
    jp     z,$326d         ; 00316D CA 6D 32 
    cp     $08             ; 003170 FE 08 
    jp     z,$3227         ; 003172 CA 27 32 
    cp     $09             ; 003175 FE 09 
    jp     z,$31b8         ; 003177 CA B8 31 
    cp     $01             ; 00317A FE 01 
    ret    z               ; 00317C C8 
    cp     $7f             ; 00317D FE 7F 
    jp     z,$33cb         ; 00317F CA CB 33 
    cp     $15             ; 003182 FE 15 
    jp     z,$32c6         ; 003184 CA C6 32 
    cp     $18             ; 003187 FE 18 
    jp     z,$3227         ; 003189 CA 27 32 
    cp     $19             ; 00318C FE 19 
    jp     z,$31b8         ; 00318E CA B8 31 
    cp     $1b             ; 003191 FE 1B 
    jp     z,$3253         ; 003193 CA 53 32 
    cp     $1c             ; 003196 FE 1C 
    jp     z,$3287         ; 003198 CA 87 32 
    cp     $1d             ; 00319B FE 1D 
    jp     z,$32b4         ; 00319D CA B4 32 
    cp     $1f             ; 0031A0 FE 1F 
    jp     z,$3292         ; 0031A2 CA 92 32 
    cp     $20             ; 0031A5 FE 20 
    ret    m               ; 0031A7 F8 
    jp     $3eca           ; 0031A8 C3 CA 3E 
    ld     hl,$7838        ; 0031AB 21 38 78 
    bit    1,(hl)          ; 0031AE CB 4E 
    pop    hl              ; 0031B0 E1 
    jr     z,$31b5         ; 0031B1 28 02 
    or     $40             ; 0031B3 F6 40 
    ld     b,a             ; 0031B5 47 
    ld     a,b             ; 0031B6 78 
    ld     (hl),a          ; 0031B7 77 
    call   $31bf           ; 0031B8 CD BF 31 
    call   $0050           ; 0031BB CD 50 00 
    ret                    ; 0031BE C9 
    ld     a,($78a6)       ; 0031BF 3A A6 78 
    inc    a               ; 0031C2 3C 
    cp     $20             ; 0031C3 FE 20 
    jr     nz,$31f2        ; 0031C5 20 2B 
    call   $33a8           ; 0031C7 CD A8 33 
    cp     $81             ; 0031CA FE 81 
    jr     z,$31f1         ; 0031CC 28 23 
    or     a               ; 0031CE B7 
    jr     nz,$3206        ; 0031CF 20 35 
    ld     b,a             ; 0031D1 47 
    ld     a,($7839)       ; 0031D2 3A 39 78 
    bit    0,a             ; 0031D5 CB 47 
    ld     a,b             ; 0031D7 78 
    ret    z               ; 0031D8 C8 
    xor    a               ; 0031D9 AF 
    inc    hl              ; 0031DA 23 
    ld     (hl),a          ; 0031DB 77 
    inc    hl              ; 0031DC 23 
    push   hl              ; 0031DD E5 
    ld     bc,($78a4)      ; 0031DE ED 4B A4 78 
    dec    bc              ; 0031E2 0B 
    dec    bc              ; 0031E3 0B 
    or     a               ; 0031E4 B7 
    sbc    hl,bc           ; 0031E5 ED 42 
    pop    hl              ; 0031E7 E1 
    jr     nc,$31f1        ; 0031E8 30 07 
    ld     a,(hl)          ; 0031EA 7E 
    or     a               ; 0031EB B7 
    jr     nz,$31f1        ; 0031EC 20 03 
    ld     a,$80           ; 0031EE 3E 80 
    ld     (hl),a          ; 0031F0 77 
    xor    a               ; 0031F1 AF 
    ld     ($78a6),a       ; 0031F2 32 A6 78 
    ld     hl,($7820)      ; 0031F5 2A 20 78 
    ld     bc,$0001        ; 0031F8 01 01 00 
    add    hl,bc           ; 0031FB 09 
    ld     a,h             ; 0031FC 7C 
    cp     $72             ; 0031FD FE 72 
    call   p,$33f3         ; 0031FF F4 F3 33 
    ld     ($7820),hl      ; 003202 22 20 78 
    ret                    ; 003205 C9 
    push   af              ; 003206 F5 
    ld     de,($7820)      ; 003207 ED 5B 20 78 
    inc    de              ; 00320B 13 
    ld     a,d             ; 00320C 7A 
    cp     $72             ; 00320D FE 72 
    jr     z,$3221         ; 00320F 28 10 
    push   hl              ; 003211 E5 
    ld     hl,$7839        ; 003212 21 39 78 
    bit    0,(hl)          ; 003215 CB 46 
    jr     nz,$3220        ; 003217 20 07 
    bit    4,(hl)          ; 003219 CB 66 
    jr     nz,$3220        ; 00321B 20 03 
    call   $332c           ; 00321D CD 2C 33 
    pop    hl              ; 003220 E1 
    pop    af              ; 003221 F1 
    inc    a               ; 003222 3C 
    ld     (hl),a          ; 003223 77 
    jp     $31d9           ; 003224 C3 D9 31 
    ld     a,($78a6)       ; 003227 3A A6 78 
    dec    a               ; 00322A 3D 
    jp     p,$3235         ; 00322B F2 35 32 
    call   $33a8           ; 00322E CD A8 33 
    or     a               ; 003231 B7 
    ret    nz              ; 003232 C0 
    ld     a,$1f           ; 003233 3E 1F 
    ld     ($78a6),a       ; 003235 32 A6 78 
    ld     bc,$0001        ; 003238 01 01 00 
    ld     hl,($7820)      ; 00323B 2A 20 78 
    xor    a               ; 00323E AF 
    sbc    hl,bc           ; 00323F ED 42 
    ld     a,h             ; 003241 7C 
    cp     $70             ; 003242 FE 70 
    jp     c,$324e         ; 003244 DA 4E 32 
    ld     ($7820),hl      ; 003247 22 20 78 
    call   $0053           ; 00324A CD 53 00 
    ret                    ; 00324D C9 
    xor    a               ; 00324E AF 
    ld     ($78a6),a       ; 00324F 32 A6 78 
    ret                    ; 003252 C9 
    ld     hl,$7839        ; 003253 21 39 78 
    bit    4,(hl)          ; 003256 CB 66 
    ret    nz              ; 003258 C0 
    ld     bc,$0020        ; 003259 01 20 00 
    ld     hl,($7820)      ; 00325C 2A 20 78 
    xor    a               ; 00325F AF 
    sbc    hl,bc           ; 003260 ED 42 
    ld     a,h             ; 003262 7C 
    cp     $70             ; 003263 FE 70 
    ret    m               ; 003265 F8 
    ld     ($7820),hl      ; 003266 22 20 78 
    call   $0053           ; 003269 CD 53 00 
    ret                    ; 00326C C9 
    ld     hl,$7839        ; 00326D 21 39 78 
    bit    4,(hl)          ; 003270 CB 66 
    ret    nz              ; 003272 C0 
    ld     bc,$0020        ; 003273 01 20 00 
    ld     hl,($7820)      ; 003276 2A 20 78 
    add    hl,bc           ; 003279 09 
    ld     a,h             ; 00327A 7C 
    cp     $72             ; 00327B FE 72 
    call   p,$3424         ; 00327D F4 24 34 
    ld     ($7820),hl      ; 003280 22 20 78 
    call   $0053           ; 003283 CD 53 00 
    ret                    ; 003286 C9 
    ld     hl,$7000        ; 003287 21 00 70 
    ld     ($7820),hl      ; 00328A 22 20 78 
    xor    a               ; 00328D AF 
    ld     ($78a6),a       ; 00328E 32 A6 78 
    ret                    ; 003291 C9 
    ld     hl,$7000        ; 003292 21 00 70 
    ld     ($7820),hl      ; 003295 22 20 78 
    ld     bc,$0200        ; 003298 01 00 02 
    call   $3ebe           ; 00329B CD BE 3E 
    inc    hl              ; 00329E 23 
    dec    bc              ; 00329F 0B 
    ld     a,c             ; 0032A0 79 
    or     b               ; 0032A1 B0 
    jr     nz,$329b        ; 0032A2 20 F7 
    xor    a               ; 0032A4 AF 
    ld     ($78a6),a       ; 0032A5 32 A6 78 
    ld     b,$10           ; 0032A8 06 10 
    ld     a,$80           ; 0032AA 3E 80 
    ld     hl,$7ad7        ; 0032AC 21 D7 7A 
    ld     (hl),a          ; 0032AF 77 
    inc    hl              ; 0032B0 23 
    djnz   $32af           ; 0032B1 10 FC 
    ret                    ; 0032B3 C9 
    ld     hl,($7820)      ; 0032B4 2A 20 78 
    ld     a,($78a6)       ; 0032B7 3A A6 78 
    ld     c,a             ; 0032BA 4F 
    xor    a               ; 0032BB AF 
    ld     b,a             ; 0032BC 47 
    ld     ($78a6),a       ; 0032BD 32 A6 78 
    sbc    hl,bc           ; 0032C0 ED 42 
    ld     ($7820),hl      ; 0032C2 22 20 78 
    ret                    ; 0032C5 C9 
    call   $33a8           ; 0032C6 CD A8 33 
    cp     $81             ; 0032C9 FE 81 
    jr     z,$32fe         ; 0032CB 28 31 
    ld     a,($78a6)       ; 0032CD 3A A6 78 
    cp     $1f             ; 0032D0 FE 1F 
    jr     z,$32f9         ; 0032D2 28 25 
    ld     c,a             ; 0032D4 4F 
    xor    a               ; 0032D5 AF 
    ld     b,a             ; 0032D6 47 
    ld     hl,($7820)      ; 0032D7 2A 20 78 
    sbc    hl,bc           ; 0032DA ED 42 
    ld     bc,$001f        ; 0032DC 01 1F 00 
    add    hl,bc           ; 0032DF 09 
    call   $3ee9           ; 0032E0 CD E9 3E 
    jr     nz,$32f9        ; 0032E3 20 14 
    push   hl              ; 0032E5 E5 
    pop    de              ; 0032E6 D1 
    dec    hl              ; 0032E7 2B 
    ld     a,($78a6)       ; 0032E8 3A A6 78 
    ld     c,a             ; 0032EB 4F 
    ld     a,$1f           ; 0032EC 3E 1F 
    sub    c               ; 0032EE 91 
    ld     c,a             ; 0032EF 4F 
    lddr                   ; 0032F0 ED B8 
    call   $3ef6           ; 0032F2 CD F6 3E 
    ld     ($783c),a       ; 0032F5 32 3C 78 
    ret                    ; 0032F8 C9 
    call   $33a8           ; 0032F9 CD A8 33 
    or     a               ; 0032FC B7 
    ret    z               ; 0032FD C8 
    cp     $80             ; 0032FE FE 80 
    jr     z,$3320         ; 003300 28 1E 
    ld     a,($78a6)       ; 003302 3A A6 78 
    ld     c,a             ; 003305 4F 
    xor    a               ; 003306 AF 
    ld     b,a             ; 003307 47 
    ld     hl,($7820)      ; 003308 2A 20 78 
    sbc    hl,bc           ; 00330B ED 42 
    ld     bc,$003f        ; 00330D 01 3F 00 
    add    hl,bc           ; 003310 09 
    call   $3ee9           ; 003311 CD E9 3E 
    ret    nz              ; 003314 C0 
    push   hl              ; 003315 E5 
    pop    de              ; 003316 D1 
    dec    hl              ; 003317 2B 
    ld     a,($78a6)       ; 003318 3A A6 78 
    ld     c,a             ; 00331B 4F 
    ld     a,$3f           ; 00331C 3E 3F 
    jr     $32ee           ; 00331E 18 CE 
    push   hl              ; 003320 E5 
    call   $332c           ; 003321 CD 2C 33 
    pop    hl              ; 003324 E1 
    ld     a,$81           ; 003325 3E 81 
    ld     (hl),a          ; 003327 77 
    inc    hl              ; 003328 23 
    xor    a               ; 003329 AF 
    ld     (hl),a          ; 00332A 77 
    ret                    ; 00332B C9 
    ld     hl,($7820)      ; 00332C 2A 20 78 
    ld     a,h             ; 00332F 7C 
    cp     $71             ; 003330 FE 71 
    jr     nz,$335f        ; 003332 20 2B 
    ld     a,l             ; 003334 7D 
    cp     $e0             ; 003335 FE E0 
    jp     c,$335f         ; 003337 DA 5F 33 
    ld     a,($78a6)       ; 00333A 3A A6 78 
    push   af              ; 00333D F5 
    ld     a,($7ad7)       ; 00333E 3A D7 7A 
    cp     $81             ; 003341 FE 81 
    jr     nz,$334d        ; 003343 20 08 
    push   hl              ; 003345 E5 
    call   $33f3           ; 003346 CD F3 33 
    pop    hl              ; 003349 E1 
    call   $0317           ; 00334A CD 17 03 
    push   hl              ; 00334D E5 
    call   $33f3           ; 00334E CD F3 33 
    pop    hl              ; 003351 E1 
    call   $0317           ; 003352 CD 17 03 
    pop    af              ; 003355 F1 
    ld     ($78a6),a       ; 003356 32 A6 78 
    pop    de              ; 003359 D1 
    pop    hl              ; 00335A E1 
    dec    hl              ; 00335B 2B 
    push   hl              ; 00335C E5 
    push   de              ; 00335D D5 
    ret                    ; 00335E C9 
    ld     a,($78a6)       ; 00335F 3A A6 78 
    ld     c,a             ; 003362 4F 
    xor    a               ; 003363 AF 
    ld     b,a             ; 003364 47 
    sbc    hl,bc           ; 003365 ED 42 
    ld     bc,$0040        ; 003367 01 40 00 
    add    hl,bc           ; 00336A 09 
    push   hl              ; 00336B E5 
    ex     de,hl           ; 00336C EB 
    ld     hl,$7200        ; 00336D 21 00 72 
    sbc    hl,de           ; 003370 ED 52 
    push   hl              ; 003372 E5 
    pop    bc              ; 003373 C1 
    ld     hl,$71df        ; 003374 21 DF 71 
    ld     de,$71ff        ; 003377 11 FF 71 
    ld     a,c             ; 00337A 79 
    or     b               ; 00337B B0 
    jr     z,$3380         ; 00337C 28 02 
    lddr                   ; 00337E ED B8 
    pop    hl              ; 003380 E1 
    call   $3f02           ; 003381 CD 02 3F 
    nop                    ; 003384 00 
    ld     (de),a          ; 003385 12 
    dec    de              ; 003386 1B 
    djnz   $3385           ; 003387 10 FC 
    call   $33a8           ; 003389 CD A8 33 
    push   hl              ; 00338C E5 
    pop    bc              ; 00338D C1 
    ld     hl,$7ae6        ; 00338E 21 E6 7A 
    push   hl              ; 003391 E5 
    or     a               ; 003392 B7 
    sbc    hl,bc           ; 003393 ED 42 
    push   hl              ; 003395 E5 
    pop    bc              ; 003396 C1 
    pop    hl              ; 003397 E1 
    push   hl              ; 003398 E5 
    pop    de              ; 003399 D1 
    dec    hl              ; 00339A 2B 
    lddr                   ; 00339B ED B8 
    ld     a,($7ae6)       ; 00339D 3A E6 7A 
    cp     $81             ; 0033A0 FE 81 
    ret    nz              ; 0033A2 C0 
    ld     hl,($7820)      ; 0033A3 2A 20 78 
    jr     $335f           ; 0033A6 18 B7 
    ld     a,($78a6)       ; 0033A8 3A A6 78 
    ld     c,a             ; 0033AB 4F 
    xor    a               ; 0033AC AF 
    ld     b,a             ; 0033AD 47 
    ld     hl,($7820)      ; 0033AE 2A 20 78 
    sbc    hl,bc           ; 0033B1 ED 42 
    push   hl              ; 0033B3 E5 
    pop    bc              ; 0033B4 C1 
    ld     a,b             ; 0033B5 78 
    and    $0f             ; 0033B6 E6 0F 
    srl    a               ; 0033B8 CB 3F 
    ld     b,a             ; 0033BA 47 
    rr     c               ; 0033BB CB 19 
    srl    c               ; 0033BD CB 39 
    srl    c               ; 0033BF CB 39 
    srl    c               ; 0033C1 CB 39 
    srl    c               ; 0033C3 CB 39 
    ld     hl,$7ad7        ; 0033C5 21 D7 7A 
    add    hl,bc           ; 0033C8 09 
    ld     a,(hl)          ; 0033C9 7E 
    ret                    ; 0033CA C9 
    call   $33a8           ; 0033CB CD A8 33 
    cp     $81             ; 0033CE FE 81 
    ld     hl,($7820)      ; 0033D0 2A 20 78 
    push   hl              ; 0033D3 E5 
    pop    de              ; 0033D4 D1 
    inc    hl              ; 0033D5 23 
    ld     a,($78a6)       ; 0033D6 3A A6 78 
    ld     c,a             ; 0033D9 4F 
    jr     z,$33ef         ; 0033DA 28 13 
    cp     $1f             ; 0033DC FE 1F 
    jr     z,$33e8         ; 0033DE 28 08 
    ld     a,$1f           ; 0033E0 3E 1F 
    sub    c               ; 0033E2 91 
    ld     c,a             ; 0033E3 4F 
    xor    a               ; 0033E4 AF 
    ld     b,a             ; 0033E5 47 
    ldir                   ; 0033E6 ED B0 
    call   $3ef6           ; 0033E8 CD F6 3E 
    call   $0050           ; 0033EB CD 50 00 
    ret                    ; 0033EE C9 
    ld     a,$3f           ; 0033EF 3E 3F 
    jr     $33e2           ; 0033F1 18 EF 
    ld     de,$7000        ; 0033F3 11 00 70 
    ld     hl,$7020        ; 0033F6 21 20 70 
    ld     bc,$01e0        ; 0033F9 01 E0 01 
    ldir                   ; 0033FC ED B0 
    call   $3f02           ; 0033FE CD 02 3F 
    nop                    ; 003401 00 
    ld     (de),a          ; 003402 12 
    inc    de              ; 003403 13 
    djnz   $3402           ; 003404 10 FC 
    ld     hl,$7ad7        ; 003406 21 D7 7A 
    push   hl              ; 003409 E5 
    pop    de              ; 00340A D1 
    inc    hl              ; 00340B 23 
    ld     bc,$000f        ; 00340C 01 0F 00 
    ldir                   ; 00340F ED B0 
    ld     a,(de)          ; 003411 1A 
    cp     $81             ; 003412 FE 81 
    jr     nz,$3419        ; 003414 20 03 
    xor    a               ; 003416 AF 
    jr     $341b           ; 003417 18 02 
    ld     a,$80           ; 003419 3E 80 
    ld     (de),a          ; 00341B 12 
    xor    a               ; 00341C AF 
    ld     ($78a6),a       ; 00341D 32 A6 78 
    ld     hl,$71e0        ; 003420 21 E0 71 
    ret                    ; 003423 C9 
    ld     a,($7ad7)       ; 003424 3A D7 7A 
    cp     $81             ; 003427 FE 81 
    call   z,$33f3         ; 003429 CC F3 33 
    call   $33f3           ; 00342C CD F3 33 
    ret                    ; 00342F C9 
    ld     hl,$7839        ; 003430 21 39 78 
    or     a               ; 003433 B7 
    jr     nz,$3441        ; 003434 20 0B 
    set    1,(hl)          ; 003436 CB CE 
    ld     bc,$03ff        ; 003438 01 FF 03 
    dec    bc              ; 00343B 0B 
    ld     a,c             ; 00343C 79 
    or     b               ; 00343D B0 
    jr     nz,$343b        ; 00343E 20 FB 
    ret                    ; 003440 C9 
    bit    0,(hl)          ; 003441 CB 46 
    ret    nz              ; 003443 C0 
    cp     $0d             ; 003444 FE 0D 
    jr     z,$344e         ; 003446 28 06 
    cp     $01             ; 003448 FE 01 
    jr     nz,$3450        ; 00344A 20 04 
    set    2,(hl)          ; 00344C CB D6 
    set    0,(hl)          ; 00344E CB C6 
    push   hl              ; 003450 E5 
    ld     hl,$00a0        ; 003451 21 A0 00 
    ld     bc,$0006        ; 003454 01 06 00 
    call   $345c           ; 003457 CD 5C 34 
    pop    hl              ; 00345A E1 
    ret                    ; 00345B C9 
    ld     a,($783b)       ; 00345C 3A 3B 78 
    ld     d,a             ; 00345F 57 
    call   $3469           ; 003460 CD 69 34 
    dec    bc              ; 003463 0B 
    ld     a,c             ; 003464 79 
    or     b               ; 003465 B0 
    jr     nz,$3460        ; 003466 20 F8 
    ret                    ; 003468 C9 
    push   bc              ; 003469 C5 
    ld     a,d             ; 00346A 7A 
    xor    $21             ; 00346B EE 21 
    ld     ($6800),a       ; 00346D 32 00 68 
    push   hl              ; 003470 E5 
    pop    bc              ; 003471 C1 
    dec    bc              ; 003472 0B 
    ld     a,c             ; 003473 79 
    or     b               ; 003474 B0 
    jr     nz,$3472        ; 003475 20 FB 
    ld     a,d             ; 003477 7A 
    ld     ($6800),a       ; 003478 32 00 68 
    push   hl              ; 00347B E5 
    pop    bc              ; 00347C C1 
    dec    bc              ; 00347D 0B 
    ld     a,c             ; 00347E 79 
    or     b               ; 00347F B0 
    jr     nz,$347d        ; 003480 20 FB 
    pop    bc              ; 003482 C1 
    ret                    ; 003483 C9 
    call   $3fa0           ; 003484 CD A0 3F 
    ld     a,$20           ; 003487 3E 20 
    ld     ($783b),a       ; 003489 32 3B 78 
    ld     ($6800),a       ; 00348C 32 00 68 
    ld     a,$3c           ; 00348F 3E 3C 
    ld     ($783a),a       ; 003491 32 3A 78 
    ld     a,$10           ; 003494 3E 10 
    ld     ($7841),a       ; 003496 32 41 78 
    xor    a               ; 003499 AF 
    ld     ($7aaf),a       ; 00349A 32 AF 7A 
    ld     hl,$7ab2        ; 00349D 21 B2 7A 
    ld     ($7ab0),hl      ; 0034A0 22 B0 7A 
    ld     a,$c9           ; 0034A3 3E C9 
    jp     $3e37           ; 0034A5 C3 37 3E 
    ret                    ; 0034A8 C9 
    di                     ; 0034A9 F3 
    ld     c,$f0           ; 0034AA 0E F0 
    call   $3558           ; 0034AC CD 58 35 
    jp     c,$3afe         ; 0034AF DA FE 3A 
    push   hl              ; 0034B2 E5 
    ld     bc,$019a        ; 0034B3 01 9A 01 
    dec    bc              ; 0034B6 0B 
    ld     a,c             ; 0034B7 79 
    or     b               ; 0034B8 B0 
    jr     nz,$34b6        ; 0034B9 20 FB 
    call   $3af8           ; 0034BB CD F8 3A 
    ld     ix,$7823        ; 0034BE DD 21 23 78 
    ld     hl,($78a4)      ; 0034C2 2A A4 78 
    ld     a,l             ; 0034C5 7D 
    call   $3511           ; 0034C6 CD 11 35 
    ld     (ix+$00),a      ; 0034C9 DD 77 00 
    xor    a               ; 0034CC AF 
    ld     (ix+$01),a      ; 0034CD DD 77 01 
    ld     a,h             ; 0034D0 7C 
    call   $3511           ; 0034D1 CD 11 35 
    call   $388e           ; 0034D4 CD 8E 38 
    ex     de,hl           ; 0034D7 EB 
    ld     hl,($78f9)      ; 0034D8 2A F9 78 
    ld     a,l             ; 0034DB 7D 
    call   $3511           ; 0034DC CD 11 35 
    call   $388e           ; 0034DF CD 8E 38 
    ld     a,h             ; 0034E2 7C 
    call   $3511           ; 0034E3 CD 11 35 
    call   $388e           ; 0034E6 CD 8E 38 
    call   $3af8           ; 0034E9 CD F8 3A 
    ld     a,(de)          ; 0034EC 1A 
    inc    de              ; 0034ED 13 
    call   $3511           ; 0034EE CD 11 35 
    call   $388e           ; 0034F1 CD 8E 38 
    call   $3af8           ; 0034F4 CD F8 3A 
    rst    18h             ; 0034F7 DF 
    jr     nz,$34ec        ; 0034F8 20 F2 
    ld     a,(ix+$00)      ; 0034FA DD 7E 00 
    call   $3511           ; 0034FD CD 11 35 
    ld     a,(ix+$01)      ; 003500 DD 7E 01 
    call   $3511           ; 003503 CD 11 35 
    ld     b,$14           ; 003506 06 14 
    xor    a               ; 003508 AF 
    call   $3511           ; 003509 CD 11 35 
    djnz   $3509           ; 00350C 10 FB 
    pop    hl              ; 00350E E1 
    ei                     ; 00350F FB 
    ret                    ; 003510 C9 
    push   af              ; 003511 F5 
    push   bc              ; 003512 C5 
    push   hl              ; 003513 E5 
    ld     l,$08           ; 003514 2E 08 
    ld     h,a             ; 003516 67 
    call   $3542           ; 003517 CD 42 35 
    rlc    h               ; 00351A CB 04 
    jr     nc,$352b        ; 00351C 30 0D 
    call   $3542           ; 00351E CD 42 35 
    call   $3542           ; 003521 CD 42 35 
    dec    l               ; 003524 2D 
    jr     nz,$3517        ; 003525 20 F0 
    pop    hl              ; 003527 E1 
    pop    bc              ; 003528 C1 
    pop    af              ; 003529 F1 
    ret                    ; 00352A C9 
    ld     a,($783b)       ; 00352B 3A 3B 78 
    or     $06             ; 00352E F6 06 
    ld     ($6800),a       ; 003530 32 00 68 
    ld     b,$99           ; 003533 06 99 
    djnz   $3535           ; 003535 10 FE 
    and    $f9             ; 003537 E6 F9 
    ld     ($6800),a       ; 003539 32 00 68 
    ld     b,$99           ; 00353C 06 99 
    djnz   $353e           ; 00353E 10 FE 
    jr     $3524           ; 003540 18 E2 
    ld     a,($783b)       ; 003542 3A 3B 78 
    or     $06             ; 003545 F6 06 
    ld     ($6800),a       ; 003547 32 00 68 
    ld     b,$4c           ; 00354A 06 4C 
    djnz   $354c           ; 00354C 10 FE 
    and    $f9             ; 00354E E6 F9 
    ld     ($6800),a       ; 003550 32 00 68 
    ld     b,$4c           ; 003553 06 4C 
    djnz   $3555           ; 003555 10 FE 
    ret                    ; 003557 C9 
    call   $358c           ; 003558 CD 8C 35 
    ld     b,$ff           ; 00355B 06 FF 
    ld     a,$80           ; 00355D 3E 80 
    call   $3511           ; 00355F CD 11 35 
    call   $3ae8           ; 003562 CD E8 3A 
    ret    c               ; 003565 D8 
    djnz   $355d           ; 003566 10 F5 
    ld     b,$05           ; 003568 06 05 
    ld     a,$fe           ; 00356A 3E FE 
    call   $3511           ; 00356C CD 11 35 
    call   $3ae8           ; 00356F CD E8 3A 
    ret    c               ; 003572 D8 
    djnz   $356a           ; 003573 10 F5 
    ld     a,c             ; 003575 79 
    call   $3511           ; 003576 CD 11 35 
    call   $3ae8           ; 003579 CD E8 3A 
    ret    c               ; 00357C D8 
    ld     a,($7ad6)       ; 00357D 3A D6 7A 
    ld     b,a             ; 003580 47 
    ld     de,$7a9d        ; 003581 11 9D 7A 
    ld     a,(de)          ; 003584 1A 
    inc    de              ; 003585 13 
    call   $3511           ; 003586 CD 11 35 
    djnz   $3584           ; 003589 10 F9 
    ret                    ; 00358B C9 
    ld     b,$10           ; 00358C 06 10 
    ld     de,$7a9d        ; 00358E 11 9D 7A 
    ld     a,(hl)          ; 003591 7E 
    cp     $3a             ; 003592 FE 3A 
    jr     z,$35a8         ; 003594 28 12 
    or     a               ; 003596 B7 
    jr     z,$35a8         ; 003597 28 0F 
    rst    08h             ; 003599 CF 
    ld     ($b77e),hl      ; 00359A 22 7E B7 
    jr     z,$35a8         ; 00359D 28 09 
    inc    hl              ; 00359F 23 
    cp     $22             ; 0035A0 FE 22 
    jr     z,$35a8         ; 0035A2 28 04 
    ld     (de),a          ; 0035A4 12 
    inc    de              ; 0035A5 13 
    djnz   $359b           ; 0035A6 10 F3 
    xor    a               ; 0035A8 AF 
    ld     (de),a          ; 0035A9 12 
    ld     a,$11           ; 0035AA 3E 11 
    sub    b               ; 0035AC 90 
    ld     ($7ad6),a       ; 0035AD 32 D6 7A 
    ret                    ; 0035B0 C9 
    ld     a,($784c)       ; 0035B1 3A 4C 78 
    or     a               ; 0035B4 B7 
    ret    nz              ; 0035B5 C0 
    ld     a,($783b)       ; 0035B6 3A 3B 78 
    bit    3,a             ; 0035B9 CB 5F 
    jr     z,$35c8         ; 0035BB 28 0B 
    and    $f7             ; 0035BD E6 F7 
    ld     ($783b),a       ; 0035BF 32 3B 78 
    ld     ($6800),a       ; 0035C2 32 00 68 
    call   $3292           ; 0035C5 CD 92 32 
    ld     hl,$71ff        ; 0035C8 21 FF 71 
    ld     ($7820),hl      ; 0035CB 22 20 78 
    ld     a,$1f           ; 0035CE 3E 1F 
    ld     ($78a6),a       ; 0035D0 32 A6 78 
    ld     a,($7ae5)       ; 0035D3 3A E5 7A 
    cp     $81             ; 0035D6 FE 81 
    ret    nz              ; 0035D8 C0 
    dec    a               ; 0035D9 3D 
    ld     ($7ae5),a       ; 0035DA 32 E5 7A 
    ld     ($7ae6),a       ; 0035DD 32 E6 7A 
    ret                    ; 0035E0 C9 
    ld     hl,$3842        ; 0035E1 21 42 38 
    call   $37f4           ; 0035E4 CD F4 37 
    call   $3af8           ; 0035E7 CD F8 3A 
    ld     a,($6800)       ; 0035EA 3A 00 68 
    bit    6,a             ; 0035ED CB 77 
    jr     nz,$35e7        ; 0035EF 20 F6 
    call   $378f           ; 0035F1 CD 8F 37 
    jr     c,$35e7         ; 0035F4 38 F1 
    bit    0,a             ; 0035F6 CB 47 
    jr     z,$35f1         ; 0035F8 28 F7 
    ld     b,$07           ; 0035FA 06 07 
    call   $378f           ; 0035FC CD 8F 37 
    jr     c,$35e7         ; 0035FF 38 E6 
    djnz   $35fc           ; 003601 10 F9 
    cp     $80             ; 003603 FE 80 
    jr     nz,$35e7        ; 003605 20 E0 
    call   $3775           ; 003607 CD 75 37 
    jp     c,$35e7         ; 00360A DA E7 35 
    cp     $80             ; 00360D FE 80 
    jr     z,$3607         ; 00360F 28 F6 
    ld     b,$04           ; 003611 06 04 
    cp     $fe             ; 003613 FE FE 
    jp     nz,$35e7        ; 003615 C2 E7 35 
    call   $3775           ; 003618 CD 75 37 
    jp     c,$35e7         ; 00361B DA E7 35 
    djnz   $3613           ; 00361E 10 F3 
    call   $3775           ; 003620 CD 75 37 
    ld     ($7ad2),a       ; 003623 32 D2 7A 
    ld     hl,$7ab2        ; 003626 21 B2 7A 
    ld     b,$12           ; 003629 06 12 
    call   $3775           ; 00362B CD 75 37 
    ld     (hl),a          ; 00362E 77 
    or     a               ; 00362F B7 
    jr     z,$3638         ; 003630 28 06 
    inc    hl              ; 003632 23 
    djnz   $362b           ; 003633 10 F6 
    jp     $35e7           ; 003635 C3 E7 35 
    ld     hl,$385a        ; 003638 21 5A 38 
    call   $37f4           ; 00363B CD F4 37 
    ld     hl,$7ab2        ; 00363E 21 B2 7A 
    call   $3814           ; 003641 CD 14 38 
    ld     hl,$7ab2        ; 003644 21 B2 7A 
    ld     de,$7a9d        ; 003647 11 9D 7A 
    ld     a,(de)          ; 00364A 1A 
    or     a               ; 00364B B7 
    ret    z               ; 00364C C8 
    cp     (hl)            ; 00364D BE 
    jp     nz,$35e7        ; 00364E C2 E7 35 
    inc    hl              ; 003651 23 
    inc    de              ; 003652 13 
    jr     $364a           ; 003653 18 F5 
    ret                    ; 003655 C9 
    push   hl              ; 003656 E5 
    ld     hl,$7839        ; 003657 21 39 78 
    res    6,(hl)          ; 00365A CB B6 
    res    3,(hl)          ; 00365C CB 9E 
    pop    hl              ; 00365E E1 
    di                     ; 00365F F3 
    call   $358c           ; 003660 CD 8C 35 
    push   hl              ; 003663 E5 
    call   $35b1           ; 003664 CD B1 35 
    ld     hl,$3842        ; 003667 21 42 38 
    call   $37f4           ; 00366A CD F4 37 
    call   $35e7           ; 00366D CD E7 35 
    ld     a,($7ad2)       ; 003670 3A D2 7A 
    cp     $f2             ; 003673 FE F2 
    jr     z,$366d         ; 003675 28 F6 
    ld     hl,$3860        ; 003677 21 60 38 
    call   $3804           ; 00367A CD 04 38 
    ld     ix,$7823        ; 00367D DD 21 23 78 
    call   $3868           ; 003681 CD 68 38 
    jp     c,$3711         ; 003684 DA 11 37 
    push   hl              ; 003687 E5 
    sbc    hl,de           ; 003688 ED 52 
    jp     c,$3711         ; 00368A DA 11 37 
    ld     ($781e),de      ; 00368D ED 53 1E 78 
    push   hl              ; 003691 E5 
    pop    bc              ; 003692 C1 
    pop    hl              ; 003693 E1 
    ld     a,($7839)       ; 003694 3A 39 78 
    bit    3,a             ; 003697 CB 5F 
    jp     nz,$3742        ; 003699 C2 42 37 
    call   $3f73           ; 00369C CD 73 3F 
    ld     (de),a          ; 00369F 12 
    call   $388e           ; 0036A0 CD 8E 38 
    inc    de              ; 0036A3 13 
    dec    bc              ; 0036A4 0B 
    ld     a,c             ; 0036A5 79 
    or     b               ; 0036A6 B0 
    jr     nz,$369c        ; 0036A7 20 F3 
    call   $3775           ; 0036A9 CD 75 37 
    cp     (ix+$00)        ; 0036AC DD BE 00 
    jp     nz,$3711        ; 0036AF C2 11 37 
    call   $3775           ; 0036B2 CD 75 37 
    cp     (ix+$01)        ; 0036B5 DD BE 01 
    jp     nz,$3711        ; 0036B8 C2 11 37 
    ld     ($78f9),hl      ; 0036BB 22 F9 78 
    ei                     ; 0036BE FB 
    ld     a,$0d           ; 0036BF 3E 0D 
    call   $308b           ; 0036C1 CD 8B 30 
    ld     a,($7ad2)       ; 0036C4 3A D2 7A 
    cp     $f1             ; 0036C7 FE F1 
    jr     nz,$36cf        ; 0036C9 20 04 
    ld     hl,($781e)      ; 0036CB 2A 1E 78 
    jp     (hl)            ; 0036CE E9 
    ld     hl,$1929        ; 0036CF 21 29 19 
    call   $28a7           ; 0036D2 CD A7 28 
    ld     hl,($78a4)      ; 0036D5 2A A4 78 
    push   hl              ; 0036D8 E5 
    ld     hl,$7839        ; 0036D9 21 39 78 
    bit    6,(hl)          ; 0036DC CB 76 
    jr     nz,$36e3        ; 0036DE 20 03 
    jp     $1ae8           ; 0036E0 C3 E8 1A 
    ld     hl,$7839        ; 0036E3 21 39 78 
    res    6,(hl)          ; 0036E6 CB B6 
    pop    de              ; 0036E8 D1 
    call   $1afc           ; 0036E9 CD FC 1A 
    call   $79b5           ; 0036EC CD B5 79 
    call   $1b5d           ; 0036EF CD 5D 1B 
    call   $79b8           ; 0036F2 CD B8 79 
    ld     hl,$ffff        ; 0036F5 21 FF FF 
    ld     ($78a2),hl      ; 0036F8 22 A2 78 
    ld     hl,$79e8        ; 0036FB 21 E8 79 
    ld     de,$0570        ; 0036FE 11 70 05 
    ld     a,(de)          ; 003701 1A 
    ld     (hl),a          ; 003702 77 
    or     a               ; 003703 B7 
    jr     z,$370a         ; 003704 28 04 
    inc    hl              ; 003706 23 
    inc    de              ; 003707 13 
    jr     $3701           ; 003708 18 F7 
    ld     hl,$79e7        ; 00370A 21 E7 79 
    xor    a               ; 00370D AF 
    jp     $1a81           ; 00370E C3 81 1A 
    ld     hl,$384a        ; 003711 21 4A 38 
    ei                     ; 003714 FB 
    call   $28a7           ; 003715 CD A7 28 
    di                     ; 003718 F3 
    ld     a,($784c)       ; 003719 3A 4C 78 
    or     a               ; 00371C B7 
    jp     nz,$3667        ; 00371D C2 67 36 
    ld     hl,$71ff        ; 003720 21 FF 71 
    ld     ($7820),hl      ; 003723 22 20 78 
    ld     a,$1f           ; 003726 3E 1F 
    ld     ($78a6),a       ; 003728 32 A6 78 
    jp     $3667           ; 00372B C3 67 36 
    push   hl              ; 00372E E5 
    ld     hl,$7839        ; 00372F 21 39 78 
    set    6,(hl)          ; 003732 CB F6 
    pop    hl              ; 003734 E1 
    jp     $365f           ; 003735 C3 5F 36 
    push   hl              ; 003738 E5 
    ld     hl,$7839        ; 003739 21 39 78 
    set    3,(hl)          ; 00373C CB DE 
    pop    hl              ; 00373E E1 
    jp     $365f           ; 00373F C3 5F 36 
    ex     de,hl           ; 003742 EB 
    call   $3775           ; 003743 CD 75 37 
    cp     (hl)            ; 003746 BE 
    jr     z,$3752         ; 003747 28 09 
    ld     hl,$376c        ; 003749 21 6C 37 
    call   $28a7           ; 00374C CD A7 28 
    jp     $0183           ; 00374F C3 83 01 
    inc    hl              ; 003752 23 
    dec    bc              ; 003753 0B 
    ld     a,c             ; 003754 79 
    or     b               ; 003755 B0 
    jr     nz,$3743        ; 003756 20 EB 
    ld     hl,$7839        ; 003758 21 39 78 
    res    3,(hl)          ; 00375B CB 9E 
    ld     hl,$376c        ; 00375D 21 6C 37 
    call   $28a7           ; 003760 CD A7 28 
    ld     hl,$0380        ; 003763 21 80 03 
    call   $28a7           ; 003766 CD A7 28 
    jp     $36cf           ; 003769 C3 CF 36 
    dec    c               ; 00376C 0D 
    ld     d,(hl)          ; 00376D 56 
    ld     b,l             ; 00376E 45 
    ld     d,d             ; 00376F 52 
    ld     c,c             ; 003770 49 
    ld     b,(hl)          ; 003771 46 
    ld     e,c             ; 003772 59 
    jr     nz,$3775        ; 003773 20 00 
    push   bc              ; 003775 C5 
    push   de              ; 003776 D5 
    ld     b,$08           ; 003777 06 08 
    call   $378f           ; 003779 CD 8F 37 
    jr     c,$378c         ; 00377C 38 0E 
    djnz   $3779           ; 00377E 10 F9 
    pop    de              ; 003780 D1 
    pop    bc              ; 003781 C1 
    ld     ($7ad3),a       ; 003782 32 D3 7A 
    call   $3af8           ; 003785 CD F8 3A 
    ld     a,($7ad3)       ; 003788 3A D3 7A 
    ret                    ; 00378B C9 
    pop    de              ; 00378C D1 
    pop    bc              ; 00378D C1 
    ret                    ; 00378E C9 
    push   bc              ; 00378F C5 
    ld     bc,$07ff        ; 003790 01 FF 07 
    ld     a,($6800)       ; 003793 3A 00 68 
    bit    6,a             ; 003796 CB 77 
    jr     z,$37a2         ; 003798 28 08 
    dec    bc              ; 00379A 0B 
    ld     a,c             ; 00379B 79 
    or     b               ; 00379C B0 
    jr     nz,$3793        ; 00379D 20 F4 
    pop    bc              ; 00379F C1 
    scf                    ; 0037A0 37 
    ret                    ; 0037A1 C9 
    ld     a,($6800)       ; 0037A2 3A 00 68 
    bit    6,a             ; 0037A5 CB 77 
    jr     nz,$3793        ; 0037A7 20 EA 
    ld     a,($6800)       ; 0037A9 3A 00 68 
    bit    6,a             ; 0037AC CB 77 
    jr     nz,$3793        ; 0037AE 20 E3 
    ld     b,$52           ; 0037B0 06 52 
    djnz   $37b2           ; 0037B2 10 FE 
    ld     a,($6800)       ; 0037B4 3A 00 68 
    bit    6,a             ; 0037B7 CB 77 
    jr     nz,$37c4        ; 0037B9 20 09 
    ld     a,($6800)       ; 0037BB 3A 00 68 
    bit    6,a             ; 0037BE CB 77 
    jr     z,$37bb         ; 0037C0 28 F9 
    jr     $3790           ; 0037C2 18 CC 
    ld     b,$5a           ; 0037C4 06 5A 
    ld     c,$00           ; 0037C6 0E 00 
    ld     a,($6800)       ; 0037C8 3A 00 68 
    bit    6,a             ; 0037CB CB 77 
    jr     z,$37da         ; 0037CD 28 0B 
    djnz   $37c8           ; 0037CF 10 F7 
    ld     a,c             ; 0037D1 79 
    dec    a               ; 0037D2 3D 
    rra                    ; 0037D3 1F 
    rl     d               ; 0037D4 CB 12 
    pop    bc              ; 0037D6 C1 
    ld     a,d             ; 0037D7 7A 
    or     a               ; 0037D8 B7 
    ret                    ; 0037D9 C9 
    ld     a,($6800)       ; 0037DA 3A 00 68 
    bit    6,a             ; 0037DD CB 77 
    jr     nz,$37cf        ; 0037DF 20 EE 
    ld     a,($6800)       ; 0037E1 3A 00 68 
    bit    6,a             ; 0037E4 CB 77 
    jr     nz,$37cf        ; 0037E6 20 E7 
    inc    c               ; 0037E8 0C 
    ld     a,($6800)       ; 0037E9 3A 00 68 
    bit    6,a             ; 0037EC CB 77 
    jr     nz,$37cf        ; 0037EE 20 DF 
    djnz   $37e9           ; 0037F0 10 F7 
    jr     $37d1           ; 0037F2 18 DD 
    ld     a,($784c)       ; 0037F4 3A 4C 78 
    or     a               ; 0037F7 B7 
    ret    nz              ; 0037F8 C0 
    ld     de,$71e0        ; 0037F9 11 E0 71 
    ld     b,$20           ; 0037FC 06 20 
    call   $3ef6           ; 0037FE CD F6 3E 
    inc    de              ; 003801 13 
    djnz   $37fe           ; 003802 10 FA 
    ld     a,($784c)       ; 003804 3A 4C 78 
    or     a               ; 003807 B7 
    ret    nz              ; 003808 C0 
    call   $3f0e           ; 003809 CD 0E 3F 
    ld     a,(hl)          ; 00380C 7E 
    or     a               ; 00380D B7 
    ret    z               ; 00380E C8 
    ld     (de),a          ; 00380F 12 
    inc    de              ; 003810 13 
    inc    hl              ; 003811 23 
    jr     $380c           ; 003812 18 F8 
    ld     a,($784c)       ; 003814 3A 4C 78 
    or     a               ; 003817 B7 
    ret    nz              ; 003818 C0 
    ld     de,$71e9        ; 003819 11 E9 71 
    push   hl              ; 00381C E5 
    ld     a,($7ad2)       ; 00381D 3A D2 7A 
    and    $0f             ; 003820 E6 0F 
    ld     hl,$383f        ; 003822 21 3F 38 
    add    a,l             ; 003825 85 
    ld     l,a             ; 003826 6F 
    ld     a,$00           ; 003827 3E 00 
    adc    a,h             ; 003829 8C 
    ld     h,a             ; 00382A 67 
    call   $3f21           ; 00382B CD 21 3F 
    nop                    ; 00382E 00 
    nop                    ; 00382F 00 
    ld     (de),a          ; 003830 12 
    inc    de              ; 003831 13 
    inc    de              ; 003832 13 
    pop    hl              ; 003833 E1 
    ld     a,(hl)          ; 003834 7E 
    or     a               ; 003835 B7 
    ret    z               ; 003836 C8 
    call   $3f33           ; 003837 CD 33 3F 
    inc    de              ; 00383A 13 
    inc    hl              ; 00383B 23 
    jr     $3834           ; 00383C 18 F6 
    ret                    ; 00383E C9 
    inc    d               ; 00383F 14 
    ld     (bc),a          ; 003840 02 
    inc    b               ; 003841 04 
    ld     d,a             ; 003842 57 
    ld     b,c             ; 003843 41 
    ld     c,c             ; 003844 49 
    ld     d,h             ; 003845 54 
    ld     c,c             ; 003846 49 
    ld     c,(hl)          ; 003847 4E 
    ld     b,a             ; 003848 47 
    nop                    ; 003849 00 
    dec    c               ; 00384A 0D 
    ld     c,h             ; 00384B 4C 
    ld     c,a             ; 00384C 4F 
    ld     b,c             ; 00384D 41 
    ld     b,h             ; 00384E 44 
    ld     c,c             ; 00384F 49 
    ld     c,(hl)          ; 003850 4E 
    ld     b,a             ; 003851 47 
    jr     nz,$3899        ; 003852 20 45 
    ld     d,d             ; 003854 52 
    ld     d,d             ; 003855 52 
    ld     c,a             ; 003856 4F 
    ld     d,d             ; 003857 52 
    dec    c               ; 003858 0D 
    nop                    ; 003859 00 
    ld     b,(hl)          ; 00385A 46 
    ld     c,a             ; 00385B 4F 
    ld     d,l             ; 00385C 55 
    ld     c,(hl)          ; 00385D 4E 
    ld     b,h             ; 00385E 44 
    nop                    ; 00385F 00 
    ld     c,h             ; 003860 4C 
    ld     c,a             ; 003861 4F 
    ld     b,c             ; 003862 41 
    ld     b,h             ; 003863 44 
    ld     c,c             ; 003864 49 
    ld     c,(hl)          ; 003865 4E 
    ld     b,a             ; 003866 47 
    nop                    ; 003867 00 
    call   $3775           ; 003868 CD 75 37 
    ret    c               ; 00386B D8 
    ld     e,a             ; 00386C 5F 
    ld     (ix+$00),a      ; 00386D DD 77 00 
    xor    a               ; 003870 AF 
    ld     (ix+$01),a      ; 003871 DD 77 01 
    call   $3775           ; 003874 CD 75 37 
    ret    c               ; 003877 D8 
    ld     d,a             ; 003878 57 
    call   $388e           ; 003879 CD 8E 38 
    call   $3775           ; 00387C CD 75 37 
    ret    c               ; 00387F D8 
    ld     l,a             ; 003880 6F 
    call   $388e           ; 003881 CD 8E 38 
    call   $3775           ; 003884 CD 75 37 
    ret    c               ; 003887 D8 
    ld     h,a             ; 003888 67 
    call   $388e           ; 003889 CD 8E 38 
    or     a               ; 00388C B7 
    ret                    ; 00388D C9 
    add    a,(ix+$00)      ; 00388E DD 86 00 
    ld     (ix+$00),a      ; 003891 DD 77 00 
    ld     a,$00           ; 003894 3E 00 
    adc    a,(ix+$01)      ; 003896 DD 8E 01 
    ld     (ix+$01),a      ; 003899 DD 77 01 
    ret                    ; 00389C C9 
    ld     a,(hl)          ; 00389D 7E 
    cp     $2c             ; 00389E FE 2C 
    jr     z,$38c2         ; 0038A0 28 20 
    call   $2b1c           ; 0038A2 CD 1C 2B 
    or     a               ; 0038A5 B7 
    jp     z,$1e4a         ; 0038A6 CA 4A 1E 
    cp     $09             ; 0038A9 FE 09 
    jp     nc,$1e4a        ; 0038AB D2 4A 1E 
    dec    a               ; 0038AE 3D 
    and    $07             ; 0038AF E6 07 
    sla    a               ; 0038B1 CB 27 
    sla    a               ; 0038B3 CB 27 
    sla    a               ; 0038B5 CB 27 
    sla    a               ; 0038B7 CB 27 
    ld     ($7846),a       ; 0038B9 32 46 78 
    ld     a,(hl)          ; 0038BC 7E 
    or     a               ; 0038BD B7 
    ret    z               ; 0038BE C8 
    cp     $3a             ; 0038BF FE 3A 
    ret    z               ; 0038C1 C8 
    rst    08h             ; 0038C2 CF 
    inc    l               ; 0038C3 2C 
    call   $2b1c           ; 0038C4 CD 1C 2B 
    or     a               ; 0038C7 B7 
    jr     nz,$38d6        ; 0038C8 20 0C 
    ld     a,($783b)       ; 0038CA 3A 3B 78 
    res    4,a             ; 0038CD CB A7 
    ld     ($783b),a       ; 0038CF 32 3B 78 
    ld     ($6800),a       ; 0038D2 32 00 68 
    ret                    ; 0038D5 C9 
    cp     $01             ; 0038D6 FE 01 
    jp     nz,$1e4a        ; 0038D8 C2 4A 1E 
    ld     a,($783b)       ; 0038DB 3A 3B 78 
    set    4,a             ; 0038DE CB E7 
    ld     ($783b),a       ; 0038E0 32 3B 78 
    ld     ($6800),a       ; 0038E3 32 00 68 
    ret                    ; 0038E6 C9 
    ld     c,$c0           ; 0038E7 0E C0 
    rrc    c               ; 0038E9 CB 09 
    djnz   $38e9           ; 0038EB 10 FC 
    ld     a,(de)          ; 0038ED 1A 
    and    c               ; 0038EE A1 
    ld     b,a             ; 0038EF 47 
    ld     a,c             ; 0038F0 79 
    rrc    b               ; 0038F1 CB 08 
    rrc    a               ; 0038F3 CB 0F 
    cp     $03             ; 0038F5 FE 03 
    jr     nz,$38f1        ; 0038F7 20 F8 
    ld     a,b             ; 0038F9 78 
    inc    a               ; 0038FA 3C 
    push   hl              ; 0038FB E5 
    call   $098d           ; 0038FC CD 8D 09 
    pop    hl              ; 0038FF E1 
    jp     $390f           ; 003900 C3 0F 39 
    ld     b,a             ; 003903 47 
    ld     a,(de)          ; 003904 1A 
    and    c               ; 003905 A1 
    ld     (de),a          ; 003906 12 
    pop    af              ; 003907 F1 
    or     a               ; 003908 B7 
    jp     p,$390f         ; 003909 F2 0F 39 
    ld     a,(de)          ; 00390C 1A 
    or     b               ; 00390D B0 
    ld     (de),a          ; 00390E 12 
    rst    08h             ; 00390F CF 
    add    hl,hl           ; 003910 29 
    ret                    ; 003911 C9 
    di                     ; 003912 F3 
    push   hl              ; 003913 E5 
    ld     a,($783b)       ; 003914 3A 3B 78 
    bit    3,a             ; 003917 CB 5F 
    jp     nz,$398e        ; 003919 C2 8E 39 
    ld     hl,$7000        ; 00391C 21 00 70 
    ld     c,$10           ; 00391F 0E 10 
    ld     b,$20           ; 003921 06 20 
    ld     a,(hl)          ; 003923 7E 
    or     a               ; 003924 B7 
    jp     p,$392d         ; 003925 F2 2D 39 
    call   $2c73           ; 003928 CD 73 2C 
    jr     $3943           ; 00392B 18 16 
    jp     $3f44           ; 00392D C3 44 3F 
    nop                    ; 003930 00 
    and    $3f             ; 003931 E6 3F 
    call   $3956           ; 003933 CD 56 39 
    jr     $3943           ; 003936 18 0B 
    and    $3f             ; 003938 E6 3F 
    bit    5,a             ; 00393A CB 6F 
    jr     nz,$3940        ; 00393C 20 02 
    or     $40             ; 00393E F6 40 
    call   $3aba           ; 003940 CD BA 3A 
    inc    hl              ; 003943 23 
    djnz   $3923           ; 003944 10 DD 
    ld     a,$0d           ; 003946 3E 0D 
    call   $3aba           ; 003948 CD BA 3A 
    call   $3af8           ; 00394B CD F8 3A 
    dec    c               ; 00394E 0D 
    ld     a,c             ; 00394F 79 
    or     a               ; 003950 B7 
    jr     nz,$3921        ; 003951 20 CE 
    pop    hl              ; 003953 E1 
    ei                     ; 003954 FB 
    ret                    ; 003955 C9 
    push   af              ; 003956 F5 
    push   bc              ; 003957 C5 
    push   de              ; 003958 D5 
    push   hl              ; 003959 E5 
    ld     l,a             ; 00395A 6F 
    ld     h,$00           ; 00395B 26 00 
    ld     a,$08           ; 00395D 3E 08 
    call   $3aba           ; 00395F CD BA 3A 
    ld     b,$04           ; 003962 06 04 
    push   hl              ; 003964 E5 
    pop    de              ; 003965 D1 
    or     a               ; 003966 B7 
    adc    hl,de           ; 003967 ED 5A 
    djnz   $3967           ; 003969 10 FC 
    push   hl              ; 00396B E5 
    pop    bc              ; 00396C C1 
    ld     hl,$3b94        ; 00396D 21 94 3B 
    add    hl,bc           ; 003970 09 
    ld     a,$ff           ; 003971 3E FF 
    call   $3aba           ; 003973 CD BA 3A 
    ld     b,$05           ; 003976 06 05 
    ld     a,(hl)          ; 003978 7E 
    inc    hl              ; 003979 23 
    call   $3aba           ; 00397A CD BA 3A 
    djnz   $3978           ; 00397D 10 F9 
    ld     a,$ff           ; 00397F 3E FF 
    call   $3aba           ; 003981 CD BA 3A 
    ld     a,$0f           ; 003984 3E 0F 
    call   $3aba           ; 003986 CD BA 3A 
    pop    hl              ; 003989 E1 
    pop    de              ; 00398A D1 
    pop    bc              ; 00398B C1 
    pop    af              ; 00398C F1 
    ret                    ; 00398D C9 
    xor    a               ; 00398E AF 
    ld     ($7ad6),a       ; 00398F 32 D6 7A 
    ld     ($7ad6),a       ; 003992 32 D6 7A 
    ld     a,$08           ; 003995 3E 08 
    call   $3aba           ; 003997 CD BA 3A 
    ld     ix,$7ad2        ; 00399A DD 21 D2 7A 
    ld     hl,$7000        ; 00399E 21 00 70 
    ld     de,$0000        ; 0039A1 11 00 00 
    ld     c,$c0           ; 0039A4 0E C0 
    call   $3af8           ; 0039A6 CD F8 3A 
    push   hl              ; 0039A9 E5 
    call   $05c9           ; 0039AA CD C9 05 
    ld     b,$03           ; 0039AD 06 03 
    ld     a,(hl)          ; 0039AF 7E 
    and    c               ; 0039B0 A1 
    push   bc              ; 0039B1 C5 
    ld     b,a             ; 0039B2 47 
    rrc    b               ; 0039B3 CB 08 
    rrc    b               ; 0039B5 CB 08 
    rrc    c               ; 0039B7 CB 09 
    rrc    c               ; 0039B9 CB 09 
    ld     a,c             ; 0039BB 79 
    cp     $03             ; 0039BC FE 03 
    jp     nz,$39b3        ; 0039BE C2 B3 39 
    ld     a,b             ; 0039C1 78 
    pop    bc              ; 0039C2 C1 
    cp     $03             ; 0039C3 FE 03 
    jr     z,$39d4         ; 0039C5 28 0D 
    cp     $02             ; 0039C7 FE 02 
    jr     z,$39d9         ; 0039C9 28 0E 
    cp     $01             ; 0039CB FE 01 
    jr     z,$39df         ; 0039CD 28 10 
    ld     de,$0000        ; 0039CF 11 00 00 
    jr     $39e3           ; 0039D2 18 0F 
    ld     de,$e0e0        ; 0039D4 11 E0 E0 
    jr     $39e3           ; 0039D7 18 0A 
    ld     d,$40           ; 0039D9 16 40 
    ld     e,$a0           ; 0039DB 1E A0 
    jr     $39e3           ; 0039DD 18 04 
    ld     d,$a0           ; 0039DF 16 A0 
    ld     e,$40           ; 0039E1 1E 40 
    ld     a,(ix+$00)      ; 0039E3 DD 7E 00 
    srl    a               ; 0039E6 CB 3F 
    srl    a               ; 0039E8 CB 3F 
    srl    a               ; 0039EA CB 3F 
    push   hl              ; 0039EC E5 
    ld     hl,$7ad3        ; 0039ED 21 D3 7A 
    call   $3a6a           ; 0039F0 CD 6A 3A 
    pop    hl              ; 0039F3 E1 
    or     d               ; 0039F4 B2 
    ld     (ix+$00),a      ; 0039F5 DD 77 00 
    ld     a,(ix+$02)      ; 0039F8 DD 7E 02 
    srl    a               ; 0039FB CB 3F 
    srl    a               ; 0039FD CB 3F 
    srl    a               ; 0039FF CB 3F 
    push   hl              ; 003A01 E5 
    ld     hl,$7ad5        ; 003A02 21 D5 7A 
    call   $3a6a           ; 003A05 CD 6A 3A 
    pop    hl              ; 003A08 E1 
    or     e               ; 003A09 B3 
    ld     (ix+$02),a      ; 003A0A DD 77 02 
    ld     a,$20           ; 003A0D 3E 20 
    add    a,l             ; 003A0F 85 
    ld     l,a             ; 003A10 6F 
    ld     a,$00           ; 003A11 3E 00 
    adc    a,h             ; 003A13 8C 
    ld     h,a             ; 003A14 67 
    djnz   $3a67           ; 003A15 10 50 
    call   $3a73           ; 003A17 CD 73 3A 
    pop    hl              ; 003A1A E1 
    srl    c               ; 003A1B CB 39 
    srl    c               ; 003A1D CB 39 
    ld     a,c             ; 003A1F 79 
    or     a               ; 003A20 B7 
    jr     nz,$39a6        ; 003A21 20 83 
    inc    hl              ; 003A23 23 
    ld     a,l             ; 003A24 7D 
    and    $1f             ; 003A25 E6 1F 
    jp     nz,$39a4        ; 003A27 C2 A4 39 
    call   $3ae2           ; 003A2A CD E2 3A 
    ld     a,($7ad6)       ; 003A2D 3A D6 7A 
    inc    a               ; 003A30 3C 
    cp     $03             ; 003A31 FE 03 
    jr     nz,$3a36        ; 003A33 20 01 
    xor    a               ; 003A35 AF 
    ld     ($7ad6),a       ; 003A36 32 D6 7A 
    jr     nz,$3a3f        ; 003A39 20 04 
    ld     a,$40           ; 003A3B 3E 40 
    jr     $3a41           ; 003A3D 18 02 
    ld     a,$20           ; 003A3F 3E 20 
    add    a,l             ; 003A41 85 
    ld     l,a             ; 003A42 6F 
    ld     a,$00           ; 003A43 3E 00 
    adc    a,h             ; 003A45 8C 
    ld     h,a             ; 003A46 67 
    cp     $78             ; 003A47 FE 78 
    jp     nc,$3a5f        ; 003A49 D2 5F 3A 
    cp     $77             ; 003A4C FE 77 
    jp     nz,$39a4        ; 003A4E C2 A4 39 
    ld     a,l             ; 003A51 7D 
    cp     $e0             ; 003A52 FE E0 
    jp     c,$39a4         ; 003A54 DA A4 39 
    ld     a,$ff           ; 003A57 3E FF 
    ld     ($7ad6),a       ; 003A59 32 D6 7A 
    jp     $39a4           ; 003A5C C3 A4 39 
    ld     a,$0f           ; 003A5F 3E 0F 
    call   $3aba           ; 003A61 CD BA 3A 
    pop    hl              ; 003A64 E1 
    ei                     ; 003A65 FB 
    ret                    ; 003A66 C9 
    jp     $39af           ; 003A67 C3 AF 39 
    jp     nc,$3a70        ; 003A6A D2 70 3A 
    set    0,(hl)          ; 003A6D CB C6 
    ret                    ; 003A6F C9 
    res    0,(hl)          ; 003A70 CB 86 
    ret                    ; 003A72 C9 
    call   $3a85           ; 003A73 CD 85 3A 
    inc    ix              ; 003A76 DD 23 
    inc    ix              ; 003A78 DD 23 
    call   $3a85           ; 003A7A CD 85 3A 
    dec    ix              ; 003A7D DD 2B 
    dec    ix              ; 003A7F DD 2B 
    call   $3a85           ; 003A81 CD 85 3A 
    ret                    ; 003A84 C9 
    ld     a,(ix+$01)      ; 003A85 DD 7E 01 
    rrc    a               ; 003A88 CB 0F 
    ld     a,(ix+$00)      ; 003A8A DD 7E 00 
    push   af              ; 003A8D F5 
    ld     a,($7ad6)       ; 003A8E 3A D6 7A 
    cp     $02             ; 003A91 FE 02 
    jr     z,$3ab2         ; 003A93 28 1D 
    cp     $01             ; 003A95 FE 01 
    jr     z,$3aaf         ; 003A97 28 16 
    pop    af              ; 003A99 F1 
    rla                    ; 003A9A 17 
    push   af              ; 003A9B F5 
    ld     a,($7ad6)       ; 003A9C 3A D6 7A 
    cp     $ff             ; 003A9F FE FF 
    jr     nz,$3aa8        ; 003AA1 20 05 
    pop    af              ; 003AA3 F1 
    and    $07             ; 003AA4 E6 07 
    jr     $3aa9           ; 003AA6 18 01 
    pop    af              ; 003AA8 F1 
    or     $80             ; 003AA9 F6 80 
    call   $3aba           ; 003AAB CD BA 3A 
    ret                    ; 003AAE C9 
    pop    af              ; 003AAF F1 
    jr     $3a9b           ; 003AB0 18 E9 
    pop    af              ; 003AB2 F1 
    rra                    ; 003AB3 1F 
    jr     $3a9b           ; 003AB4 18 E5 
    or     a               ; 003AB6 B7 
    jp     m,$3ad8         ; 003AB7 FA D8 3A 
    push   af              ; 003ABA F5 
    call   $3ae8           ; 003ABB CD E8 3A 
    jp     nc,$3ac4        ; 003ABE D2 C4 3A 
    pop    af              ; 003AC1 F1 
    scf                    ; 003AC2 37 
    ret                    ; 003AC3 C9 
    in     a,($00)         ; 003AC4 DB 00 
    bit    0,a             ; 003AC6 CB 47 
    jr     nz,$3abb        ; 003AC8 20 F1 
    pop    af              ; 003ACA F1 
    out    ($0e),a         ; 003ACB D3 0E 
    out    ($0d),a         ; 003ACD D3 0D 
    cp     $0d             ; 003ACF FE 0D 
    scf                    ; 003AD1 37 
    ccf                    ; 003AD2 3F 
    ret    nz              ; 003AD3 C0 
    ld     a,$0a           ; 003AD4 3E 0A 
    jr     $3aba           ; 003AD6 18 E2 
    bit    6,a             ; 003AD8 CB 77 
    jp     z,$2c73         ; 003ADA CA 73 2C 
    and    $3f             ; 003ADD E6 3F 
    jp     $3956           ; 003ADF C3 56 39 
    ld     a,$0d           ; 003AE2 3E 0D 
    call   $3aba           ; 003AE4 CD BA 3A 
    ret                    ; 003AE7 C9 
    or     a               ; 003AE8 B7 
    ld     a,($68fd)       ; 003AE9 3A FD 68 
    bit    2,a             ; 003AEC CB 57 
    ret    nz              ; 003AEE C0 
    ld     a,($68df)       ; 003AEF 3A DF 68 
    scf                    ; 003AF2 37 
    bit    2,a             ; 003AF3 CB 57 
    ret    z               ; 003AF5 C8 
    ccf                    ; 003AF6 3F 
    ret                    ; 003AF7 C9 
    call   $3ae8           ; 003AF8 CD E8 3A 
    ret    nc              ; 003AFB D0 
    pop    hl              ; 003AFC E1 
    pop    hl              ; 003AFD E1 
    ld     a,($7839)       ; 003AFE 3A 39 78 
    and    $b7             ; 003B01 E6 B7 
    ld     ($7839),a       ; 003B03 32 39 78 
    ld     a,$01           ; 003B06 3E 01 
    ei                     ; 003B08 FB 
    jp     $1da0           ; 003B09 C3 A0 1D 
    ld     a,($789c)       ; 003B0C 3A 9C 78 
    or     a               ; 003B0F B7 
    jp     nz,$2164        ; 003B10 C2 64 21 
    ld     a,($7aaf)       ; 003B13 3A AF 7A 
    or     a               ; 003B16 B7 
    jr     nz,$3b13        ; 003B17 20 FA 
    jp     $2164           ; 003B19 C3 64 21 
    ld     a,($7aaf)       ; 003B1C 3A AF 7A 
    or     a               ; 003B1F B7 
    ret    nz              ; 003B20 C0 
    ld     a,($78a6)       ; 003B21 3A A6 78 
    ret                    ; 003B24 C9 
    ld     hl,$68ef        ; 003B25 21 EF 68 
    bit    4,(hl)          ; 003B28 CB 66 
    jr     nz,$3b44        ; 003B2A 20 18 
    call   $3b48           ; 003B2C CD 48 3B 
    bit    4,(hl)          ; 003B2F CB 66 
    jr     z,$3b2f         ; 003B31 28 FC 
    call   $3b48           ; 003B33 CD 48 3B 
    call   $3af8           ; 003B36 CD F8 3A 
    bit    4,(hl)          ; 003B39 CB 66 
    jr     nz,$3b36        ; 003B3B 20 F9 
    call   $3b48           ; 003B3D CD 48 3B 
    bit    4,(hl)          ; 003B40 CB 66 
    jr     z,$3b40         ; 003B42 28 FC 
    ld     hl,$ffff        ; 003B44 21 FF FF 
    ret                    ; 003B47 C9 
    ld     hl,$07ff        ; 003B48 21 FF 07 
    dec    hl              ; 003B4B 2B 
    ld     a,l             ; 003B4C 7D 
    or     h               ; 003B4D B4 
    jr     nz,$3b4b        ; 003B4E 20 FB 
    ld     hl,$68ef        ; 003B50 21 EF 68 
    ret                    ; 003B53 C9 
    call   $3511           ; 003B54 CD 11 35 
    ret                    ; 003B57 C9 
    di                     ; 003B58 F3 
    inc    hl              ; 003B59 23 
    ld     c,$f2           ; 003B5A 0E F2 
    call   $3558           ; 003B5C CD 58 35 
    jp     c,$3afe         ; 003B5F DA FE 3A 
    dec    hl              ; 003B62 2B 
    rst    08h             ; 003B63 CF 
    ld     ($2ccf),hl      ; 003B64 22 CF 2C 
    ret                    ; 003B67 C9 
    di                     ; 003B68 F3 
    inc    hl              ; 003B69 23 
    call   $358c           ; 003B6A CD 8C 35 
    dec    hl              ; 003B6D 2B 
    rst    08h             ; 003B6E CF 
    ld     ($2ccf),hl      ; 003B6F 22 CF 2C 
    push   hl              ; 003B72 E5 
    call   $35b1           ; 003B73 CD B1 35 
    ld     hl,$3842        ; 003B76 21 42 38 
    call   $37f4           ; 003B79 CD F4 37 
    call   $35e7           ; 003B7C CD E7 35 
    ld     a,($7ad2)       ; 003B7F 3A D2 7A 
    cp     $f2             ; 003B82 FE F2 
    jr     nz,$3b7c        ; 003B84 20 F6 
    pop    hl              ; 003B86 E1 
    ret                    ; 003B87 C9 
    call   $3775           ; 003B88 CD 75 37 
    cp     $0d             ; 003B8B FE 0D 
    ret    nz              ; 003B8D C0 
    push   af              ; 003B8E F5 
    call   $20f9           ; 003B8F CD F9 20 
    pop    af              ; 003B92 F1 
    ret                    ; 003B93 C9 
    pop    bc              ; 003B94 C1 
    cp     (hl)            ; 003B95 BE 
    and    d               ; 003B96 A2 
    xor    (hl)            ; 003B97 AE 
    or     c               ; 003B98 B1 
    add    a,e             ; 003B99 83 
    db     $ed,$ee         ; 003B9A ED EE 
    db     $ed,$83         ; 003B9C ED 83 
    add    a,b             ; 003B9E 80 
    or     (hl)            ; 003B9F B6 
    or     (hl)            ; 003BA0 B6 
    or     (hl)            ; 003BA1 B6 
    pop    bc              ; 003BA2 C1 
    pop    bc              ; 003BA3 C1 
    cp     (hl)            ; 003BA4 BE 
    cp     (hl)            ; 003BA5 BE 
    cp     (hl)            ; 003BA6 BE 
    db     $dd             ; 003BA7 DD 
    add    a,b             ; 003BA8 80 
    cp     (hl)            ; 003BA9 BE 
    cp     (hl)            ; 003BAA BE 
    cp     (hl)            ; 003BAB BE 
    pop    bc              ; 003BAC C1 
    add    a,b             ; 003BAD 80 
    or     (hl)            ; 003BAE B6 
    or     (hl)            ; 003BAF B6 
    or     (hl)            ; 003BB0 B6 
    cp     (hl)            ; 003BB1 BE 
    add    a,b             ; 003BB2 80 
    or     $f6             ; 003BB3 F6 F6 
    or     $fe             ; 003BB5 F6 FE 
    pop    bc              ; 003BB7 C1 
    cp     (hl)            ; 003BB8 BE 
    cp     (hl)            ; 003BB9 BE 
    xor    (hl)            ; 003BBA AE 
    adc    a,h             ; 003BBB 8C 
    add    a,b             ; 003BBC 80 
    rst    30h             ; 003BBD F7 
    rst    30h             ; 003BBE F7 
    rst    30h             ; 003BBF F7 
    add    a,b             ; 003BC0 80 
    rst    38h             ; 003BC1 FF 
    cp     (hl)            ; 003BC2 BE 
    add    a,b             ; 003BC3 80 
    cp     (hl)            ; 003BC4 BE 
    rst    38h             ; 003BC5 FF 
    rst    18h             ; 003BC6 DF 
    cp     a               ; 003BC7 BF 
    cp     a               ; 003BC8 BF 
    ret    nz              ; 003BC9 C0 
    cp     $80             ; 003BCA FE 80 
    rst    30h             ; 003BCC F7 
    ex     de,hl           ; 003BCD EB 
    cp     (ix-$80)        ; 003BCE DD BE 80 
    cp     a               ; 003BD1 BF 
    cp     a               ; 003BD2 BF 
    cp     a               ; 003BD3 BF 
    cp     a               ; 003BD4 BF 
    add    a,b             ; 003BD5 80 
    db     $fd             ; 003BD6 FD 
    di                     ; 003BD7 F3 
    db     $fd             ; 003BD8 FD 
    add    a,b             ; 003BD9 80 
    add    a,b             ; 003BDA 80 
    db     $fd             ; 003BDB FD 
    ei                     ; 003BDC FB 
    rst    30h             ; 003BDD F7 
    add    a,b             ; 003BDE 80 
    pop    bc              ; 003BDF C1 
    cp     (hl)            ; 003BE0 BE 
    cp     (hl)            ; 003BE1 BE 
    cp     (hl)            ; 003BE2 BE 
    pop    bc              ; 003BE3 C1 
    add    a,b             ; 003BE4 80 
    or     $f6             ; 003BE5 F6 F6 
    or     $f9             ; 003BE7 F6 F9 
    pop    bc              ; 003BE9 C1 
    cp     (hl)            ; 003BEA BE 
    xor    (hl)            ; 003BEB AE 
    sbc    a,$a1           ; 003BEC DE A1 
    add    a,b             ; 003BEE 80 
    or     $e6             ; 003BEF F6 E6 
    sub    $b9             ; 003BF1 D6 B9 
    exx                    ; 003BF3 D9 
    or     (hl)            ; 003BF4 B6 
    or     (hl)            ; 003BF5 B6 
    or     (hl)            ; 003BF6 B6 
    call   $fefe           ; 003BF7 CD FE FE 
    add    a,b             ; 003BFA 80 
    cp     $fe             ; 003BFB FE FE 
    ret    nz              ; 003BFD C0 
    cp     a               ; 003BFE BF 
    cp     a               ; 003BFF BF 
    cp     a               ; 003C00 BF 
    ret    nz              ; 003C01 C0 
    ret    m               ; 003C02 F8 
    rst    20h             ; 003C03 E7 
    sbc    a,a             ; 003C04 9F 
    rst    20h             ; 003C05 E7 
    ret    m               ; 003C06 F8 
    add    a,b             ; 003C07 80 
    rst    18h             ; 003C08 DF 
    rst    20h             ; 003C09 E7 
    rst    18h             ; 003C0A DF 
    add    a,b             ; 003C0B 80 
    sbc    a,h             ; 003C0C 9C 
    db     $ed,$f7         ; 003C0D ED F7 
    ex     de,hl           ; 003C0F EB 
    sbc    a,h             ; 003C10 9C 
    call   m,$87fb         ; 003C11 FC FB 87 
    ei                     ; 003C14 FB 
    call   m,$ae9e         ; 003C15 FC 9E AE 
    or     (hl)            ; 003C18 B6 
    cp     d               ; 003C19 BA 
    cp     h               ; 003C1A BC 
    rst    38h             ; 003C1B FF 
    add    a,b             ; 003C1C 80 
    cp     (hl)            ; 003C1D BE 
    cp     (hl)            ; 003C1E BE 
    rst    38h             ; 003C1F FF 
    db     $fd             ; 003C20 FD 
    ei                     ; 003C21 FB 
    rst    30h             ; 003C22 F7 
    rst    28h             ; 003C23 EF 
    rst    18h             ; 003C24 DF 
    rst    38h             ; 003C25 FF 
    cp     (hl)            ; 003C26 BE 
    cp     (hl)            ; 003C27 BE 
    add    a,b             ; 003C28 80 
    rst    38h             ; 003C29 FF 
    ei                     ; 003C2A FB 
    db     $fd             ; 003C2B FD 
    add    a,b             ; 003C2C 80 
    db     $fd             ; 003C2D FD 
    ei                     ; 003C2E FB 
    rst    30h             ; 003C2F F7 
    ex     (sp),hl         ; 003C30 E3 
    sub    $f7             ; 003C31 D6 F7 
    rst    30h             ; 003C33 F7 
    rst    38h             ; 003C34 FF 
    rst    38h             ; 003C35 FF 
    rst    38h             ; 003C36 FF 
    rst    38h             ; 003C37 FF 
    rst    38h             ; 003C38 FF 
    rst    38h             ; 003C39 FF 
    rst    38h             ; 003C3A FF 
    and    b               ; 003C3B A0 
    rst    38h             ; 003C3C FF 
    rst    38h             ; 003C3D FF 
    rst    38h             ; 003C3E FF 
    ret    m               ; 003C3F F8 
    rst    38h             ; 003C40 FF 
    ret    m               ; 003C41 F8 
    rst    38h             ; 003C42 FF 
    ex     de,hl           ; 003C43 EB 
    add    a,b             ; 003C44 80 
    ex     de,hl           ; 003C45 EB 
    add    a,b             ; 003C46 80 
    db     $ed,$db         ; 003C47 ED DB 
    sub    $80             ; 003C49 D6 80 
    sub    $ed             ; 003C4B D6 ED 
    exx                    ; 003C4D D9 
    jp     (hl)            ; 003C4E E9 
    rst    30h             ; 003C4F F7 
    set    1,l             ; 003C50 CB CD 
    ret                    ; 003C52 C9 
    sub    $a9             ; 003C53 D6 A9 
    rst    18h             ; 003C55 DF 
    xor    a               ; 003C56 AF 
    rst    30h             ; 003C57 F7 
    ret    m               ; 003C58 F8 
    call   m,$ffff         ; 003C59 FC FF FF 
    rst    38h             ; 003C5C FF 
    ex     (sp),hl         ; 003C5D E3 
    cp     (ix-$01)        ; 003C5E DD BE FF 
    rst    38h             ; 003C61 FF 
    cp     (hl)            ; 003C62 BE 
    ex     (sp),ix         ; 003C63 DD E3 
    rst    38h             ; 003C65 FF 
    sub    $e3             ; 003C66 D6 E3 
    add    a,b             ; 003C68 80 
    ex     (sp),hl         ; 003C69 E3 
    push   de              ; 003C6A D5 
    rst    30h             ; 003C6B F7 
    rst    30h             ; 003C6C F7 
    pop    bc              ; 003C6D C1 
    rst    30h             ; 003C6E F7 
    rst    30h             ; 003C6F F7 
    rst    18h             ; 003C70 DF 
    rst    00h             ; 003C71 C7 
    rst    30h             ; 003C72 F7 
    rst    38h             ; 003C73 FF 
    rst    38h             ; 003C74 FF 
    rst    30h             ; 003C75 F7 
    rst    30h             ; 003C76 F7 
    rst    30h             ; 003C77 F7 
    rst    30h             ; 003C78 F7 
    rst    30h             ; 003C79 F7 
    rst    38h             ; 003C7A FF 
    sbc    a,a             ; 003C7B 9F 
    sbc    a,a             ; 003C7C 9F 
    rst    38h             ; 003C7D FF 
    rst    38h             ; 003C7E FF 
    rst    18h             ; 003C7F DF 
    rst    28h             ; 003C80 EF 
    rst    30h             ; 003C81 F7 
    ei                     ; 003C82 FB 
    db     $fd             ; 003C83 FD 
    pop    bc              ; 003C84 C1 
    xor    (hl)            ; 003C85 AE 
    or     (hl)            ; 003C86 B6 
    cp     d               ; 003C87 BA 
    pop    bc              ; 003C88 C1 
    rst    38h             ; 003C89 FF 
    cp     l               ; 003C8A BD 
    add    a,b             ; 003C8B 80 
    cp     a               ; 003C8C BF 
    rst    38h             ; 003C8D FF 
    sbc    a,l             ; 003C8E 9D 
    xor    (hl)            ; 003C8F AE 
    or     (hl)            ; 003C90 B6 
    cp     d               ; 003C91 BA 
    cp     l               ; 003C92 BD 
    db     $dd             ; 003C93 DD 
    cp     e               ; 003C94 BB 
    cp     e               ; 003C95 BB 
    cp     e               ; 003C96 BB 
    ret                    ; 003C97 C9 
    rst    20h             ; 003C98 E7 
    ex     de,hl           ; 003C99 EB 
    db     $ed,$80         ; 003C9A ED 80 
    rst    28h             ; 003C9C EF 
    ret    c               ; 003C9D D8 
    cp     d               ; 003C9E BA 
    jp     c,$c6da         ; 003C9F DA DA C6 
    pop    bc              ; 003CA2 C1 
    or     (hl)            ; 003CA3 B6 
    or     (hl)            ; 003CA4 B6 
    or     (hl)            ; 003CA5 B6 
    rst    08h             ; 003CA6 CF 
    call   m,$86fe         ; 003CA7 FC FE 86 
    jp     m,$c9fc         ; 003CAA FA FC C9 
    or     (hl)            ; 003CAD B6 
    or     (hl)            ; 003CAE B6 
    or     (hl)            ; 003CAF B6 
    ret                    ; 003CB0 C9 
    ld     sp,hl           ; 003CB1 F9 
    or     (hl)            ; 003CB2 B6 
    or     (hl)            ; 003CB3 B6 
    or     (hl)            ; 003CB4 B6 
    pop    bc              ; 003CB5 C1 
    rst    38h             ; 003CB6 FF 
    ret                    ; 003CB7 C9 
    ret                    ; 003CB8 C9 
    rst    38h             ; 003CB9 FF 
    rst    38h             ; 003CBA FF 
    cp     a               ; 003CBB BF 
    call   nz,$ffe4        ; 003CBC C4 E4 FF 
    rst    38h             ; 003CBF FF 
    rst    30h             ; 003CC0 F7 
    ex     de,hl           ; 003CC1 EB 
    db     $dd             ; 003CC2 DD 
    sbc    a,$de           ; 003CC3 DE DE 
    ex     de,hl           ; 003CC5 EB 
    ex     de,hl           ; 003CC6 EB 
    ex     de,hl           ; 003CC7 EB 
    ex     de,hl           ; 003CC8 EB 
    ex     de,hl           ; 003CC9 EB 
    sbc    a,$de           ; 003CCA DE DE 
    db     $dd             ; 003CCC DD 
    ex     de,hl           ; 003CCD EB 
    rst    30h             ; 003CCE F7 
    db     $fd             ; 003CCF FD 
    cp     $a6             ; 003CD0 FE A6 
    jp     m,$cbfd         ; 003CD2 FA FD CB 
    dec    sp              ; 003CD5 3B 
    inc    e               ; 003CD6 1C 
    ld     a,(hl)          ; 003CD7 7E 
    inc    hl              ; 003CD8 23 
    or     a               ; 003CD9 B7 
    jp     p,$3cd7         ; 003CDA F2 D7 3C 
    dec    e               ; 003CDD 1D 
    jr     nz,$3cd7        ; 003CDE 20 F7 
    and    $7f             ; 003CE0 E6 7F 
    call   $032a           ; 003CE2 CD 2A 03 
    ld     a,(hl)          ; 003CE5 7E 
    inc    hl              ; 003CE6 23 
    or     a               ; 003CE7 B7 
    jp     p,$3ce2         ; 003CE8 F2 E2 3C 
    ret                    ; 003CEB C9 
    adc    a,$45           ; 003CEC CE 45 
    ld     e,b             ; 003CEE 58 
    ld     d,h             ; 003CEF 54 
    jr     nz,$3d49        ; 003CF0 20 57 
    ld     c,c             ; 003CF2 49 
    ld     d,h             ; 003CF3 54 
    ld     c,b             ; 003CF4 48 
    ld     c,a             ; 003CF5 4F 
    ld     d,l             ; 003CF6 55 
    ld     d,h             ; 003CF7 54 
    jr     nz,$3d40        ; 003CF8 20 46 
    ld     c,a             ; 003CFA 4F 
    ld     d,d             ; 003CFB 52 
    out    ($59),a         ; 003CFC D3 59 
    ld     c,(hl)          ; 003CFE 4E 
    ld     d,h             ; 003CFF 54 
    ld     b,c             ; 003D00 41 
    ld     e,b             ; 003D01 58 
    jp     nc,$5445        ; 003D02 D2 45 54 
    daa                    ; 003D05 27 
    ld     c,(hl)          ; 003D06 4E 
    jr     nz,$3d60        ; 003D07 20 57 
    ld     c,c             ; 003D09 49 
    ld     d,h             ; 003D0A 54 
    ld     c,b             ; 003D0B 48 
    ld     c,a             ; 003D0C 4F 
    ld     d,l             ; 003D0D 55 
    ld     d,h             ; 003D0E 54 
    jr     nz,$3d58        ; 003D0F 20 47 
    ld     c,a             ; 003D11 4F 
    ld     d,e             ; 003D12 53 
    ld     d,l             ; 003D13 55 
    ld     b,d             ; 003D14 42 
    rst    08h             ; 003D15 CF 
    ld     d,l             ; 003D16 55 
    ld     d,h             ; 003D17 54 
    jr     nz,$3d69        ; 003D18 20 4F 
    ld     b,(hl)          ; 003D1A 46 
    jr     nz,$3d61        ; 003D1B 20 44 
    ld     b,c             ; 003D1D 41 
    ld     d,h             ; 003D1E 54 
    ld     b,c             ; 003D1F 41 
    add    a,$55           ; 003D20 C6 55 
    ld     c,(hl)          ; 003D22 4E 
    ld     b,e             ; 003D23 43 
    ld     d,h             ; 003D24 54 
    ld     c,c             ; 003D25 49 
    ld     c,a             ; 003D26 4F 
    ld     c,(hl)          ; 003D27 4E 
    jr     nz,$3d6d        ; 003D28 20 43 
    ld     c,a             ; 003D2A 4F 
    ld     b,h             ; 003D2B 44 
    ld     b,l             ; 003D2C 45 
    rst    08h             ; 003D2D CF 
    ld     d,(hl)          ; 003D2E 56 
    ld     b,l             ; 003D2F 45 
    ld     d,d             ; 003D30 52 
    ld     b,(hl)          ; 003D31 46 
    ld     c,h             ; 003D32 4C 
    ld     c,a             ; 003D33 4F 
    ld     d,a             ; 003D34 57 
    rst    08h             ; 003D35 CF 
    ld     d,l             ; 003D36 55 
    ld     d,h             ; 003D37 54 
    jr     nz,$3d89        ; 003D38 20 4F 
    ld     b,(hl)          ; 003D3A 46 
    jr     nz,$3d8a        ; 003D3B 20 4D 
    ld     b,l             ; 003D3D 45 
    ld     c,l             ; 003D3E 4D 
    ld     c,a             ; 003D3F 4F 
    ld     d,d             ; 003D40 52 
    ld     e,c             ; 003D41 59 
    push   de              ; 003D42 D5 
    ld     c,(hl)          ; 003D43 4E 
    ld     b,h             ; 003D44 44 
    ld     b,l             ; 003D45 45 
    ld     b,(hl)          ; 003D46 46 
    daa                    ; 003D47 27 
    ld     b,h             ; 003D48 44 
    jr     nz,$3d9e        ; 003D49 20 53 
    ld     d,h             ; 003D4B 54 
    ld     b,c             ; 003D4C 41 
    ld     d,h             ; 003D4D 54 
    ld     b,l             ; 003D4E 45 
    ld     c,l             ; 003D4F 4D 
    ld     b,l             ; 003D50 45 
    ld     c,(hl)          ; 003D51 4E 
    ld     d,h             ; 003D52 54 
    jp     nz,$4441        ; 003D53 C2 41 44 
    jr     nz,$3dab        ; 003D56 20 53 
    ld     d,l             ; 003D58 55 
    ld     b,d             ; 003D59 42 
    ld     d,e             ; 003D5A 53 
    ld     b,e             ; 003D5B 43 
    ld     d,d             ; 003D5C 52 
    ld     c,c             ; 003D5D 49 
    ld     d,b             ; 003D5E 50 
    ld     d,h             ; 003D5F 54 
    jp     nc,$4445        ; 003D60 D2 45 44 
    ld     c,c             ; 003D63 49 
    ld     c,l             ; 003D64 4D 
    daa                    ; 003D65 27 
    ld     b,h             ; 003D66 44 
    jr     nz,$3daa        ; 003D67 20 41 
    ld     d,d             ; 003D69 52 
    ld     d,d             ; 003D6A 52 
    ld     b,c             ; 003D6B 41 
    ld     e,c             ; 003D6C 59 
    call   nz,$5649        ; 003D6D C4 49 56 
    ld     c,c             ; 003D70 49 
    ld     d,e             ; 003D71 53 
    ld     c,c             ; 003D72 49 
    ld     c,a             ; 003D73 4F 
    ld     c,(hl)          ; 003D74 4E 
    jr     nz,$3db9        ; 003D75 20 42 
    ld     e,c             ; 003D77 59 
    jr     nz,$3dd4        ; 003D78 20 5A 
    ld     b,l             ; 003D7A 45 
    ld     d,d             ; 003D7B 52 
    ld     c,a             ; 003D7C 4F 
    ret                    ; 003D7D C9 
    ld     c,h             ; 003D7E 4C 
    ld     c,h             ; 003D7F 4C 
    ld     b,l             ; 003D80 45 
    ld     b,a             ; 003D81 47 
    ld     b,c             ; 003D82 41 
    ld     c,h             ; 003D83 4C 
    jr     nz,$3dca        ; 003D84 20 44 
    ld     c,c             ; 003D86 49 
    ld     d,d             ; 003D87 52 
    ld     b,l             ; 003D88 45 
    ld     b,e             ; 003D89 43 
    ld     d,h             ; 003D8A 54 
    call   nc,$5059        ; 003D8B D4 59 50 
    ld     b,l             ; 003D8E 45 
    jr     nz,$3dde        ; 003D8F 20 4D 
    ld     c,c             ; 003D91 49 
    ld     d,e             ; 003D92 53 
    ld     c,l             ; 003D93 4D 
    ld     b,c             ; 003D94 41 
    ld     d,h             ; 003D95 54 
    ld     b,e             ; 003D96 43 
    ld     c,b             ; 003D97 48 
    rst    08h             ; 003D98 CF 
    ld     d,l             ; 003D99 55 
    ld     d,h             ; 003D9A 54 
    jr     nz,$3dec        ; 003D9B 20 4F 
    ld     b,(hl)          ; 003D9D 46 
    jr     nz,$3df3        ; 003D9E 20 53 
    ld     d,b             ; 003DA0 50 
    ld     b,c             ; 003DA1 41 
    ld     b,e             ; 003DA2 43 
    ld     b,l             ; 003DA3 45 
    out    ($54),a         ; 003DA4 D3 54 
    ld     d,d             ; 003DA6 52 
    ld     c,c             ; 003DA7 49 
    ld     c,(hl)          ; 003DA8 4E 
    ld     b,a             ; 003DA9 47 
    jr     nz,$3e00        ; 003DAA 20 54 
    ld     c,a             ; 003DAC 4F 
    ld     c,a             ; 003DAD 4F 
    jr     nz,$3dfc        ; 003DAE 20 4C 
    ld     c,a             ; 003DB0 4F 
    ld     c,(hl)          ; 003DB1 4E 
    ld     b,a             ; 003DB2 47 
    add    a,$4f           ; 003DB3 C6 4F 
    ld     d,d             ; 003DB5 52 
    ld     c,l             ; 003DB6 4D 
    ld     d,l             ; 003DB7 55 
    ld     c,h             ; 003DB8 4C 
    ld     b,c             ; 003DB9 41 
    jr     nz,$3e10        ; 003DBA 20 54 
    ld     c,a             ; 003DBC 4F 
    ld     c,a             ; 003DBD 4F 
    jr     nz,$3e03        ; 003DBE 20 43 
    ld     c,a             ; 003DC0 4F 
    ld     c,l             ; 003DC1 4D 
    ld     d,b             ; 003DC2 50 
    ld     c,h             ; 003DC3 4C 
    ld     b,l             ; 003DC4 45 
    ld     e,b             ; 003DC5 58 
    jp     $4e41           ; 003DC6 C3 41 4E 
    daa                    ; 003DC9 27 
    ld     d,h             ; 003DCA 54 
    jr     nz,$3e10        ; 003DCB 20 43 
    ld     c,a             ; 003DCD 4F 
    ld     c,(hl)          ; 003DCE 4E 
    ld     d,h             ; 003DCF 54 
    adc    a,$4f           ; 003DD0 CE 4F 
    jr     nz,$3e26        ; 003DD2 20 52 
    ld     b,l             ; 003DD4 45 
    ld     d,e             ; 003DD5 53 
    ld     d,l             ; 003DD6 55 
    ld     c,l             ; 003DD7 4D 
    ld     b,l             ; 003DD8 45 
    jp     nc,$5345        ; 003DD9 D2 45 53 
    ld     d,l             ; 003DDC 55 
    ld     c,l             ; 003DDD 4D 
    ld     b,l             ; 003DDE 45 
    jr     nz,$3e38        ; 003DDF 20 57 
    ld     c,c             ; 003DE1 49 
    ld     d,h             ; 003DE2 54 
    ld     c,b             ; 003DE3 48 
    ld     c,a             ; 003DE4 4F 
    ld     d,l             ; 003DE5 55 
    ld     d,h             ; 003DE6 54 
    push   de              ; 003DE7 D5 
    ld     c,(hl)          ; 003DE8 4E 
    ld     d,b             ; 003DE9 50 
    ld     d,d             ; 003DEA 52 
    ld     c,c             ; 003DEB 49 
    ld     c,(hl)          ; 003DEC 4E 
    ld     d,h             ; 003DED 54 
    ld     b,c             ; 003DEE 41 
    ld     b,d             ; 003DEF 42 
    ld     c,h             ; 003DF0 4C 
    ld     b,l             ; 003DF1 45 
    call   $5349           ; 003DF2 CD 49 53 
    ld     d,e             ; 003DF5 53 
    ld     c,c             ; 003DF6 49 
    ld     c,(hl)          ; 003DF7 4E 
    ld     b,a             ; 003DF8 47 
    jr     nz,$3e4a        ; 003DF9 20 4F 
    ld     d,b             ; 003DFB 50 
    ld     b,l             ; 003DFC 45 
    ld     d,d             ; 003DFD 52 
    ld     b,c             ; 003DFE 41 
    ld     c,(hl)          ; 003DFF 4E 
    ld     b,h             ; 003E00 44 
    jp     nz,$4441        ; 003E01 C2 41 44 
    jr     nz,$3e4c        ; 003E04 20 46 
    ld     c,c             ; 003E06 49 
    ld     c,h             ; 003E07 4C 
    ld     b,l             ; 003E08 45 
    jr     nz,$3e4f        ; 003E09 20 44 
    ld     b,c             ; 003E0B 41 
    ld     d,h             ; 003E0C 54 
    ld     b,c             ; 003E0D 41 
    call   nz,$5349        ; 003E0E C4 49 53 
    ld     c,e             ; 003E11 4B 
    jr     nz,$3e57        ; 003E12 20 43 
    ld     c,a             ; 003E14 4F 
    ld     c,l             ; 003E15 4D 
    ld     c,l             ; 003E16 4D 
    ld     b,c             ; 003E17 41 
    ld     c,(hl)          ; 003E18 4E 
    ld     b,h             ; 003E19 44 
    ccf                    ; 003E1A 3F 
    ld     d,e             ; 003E1B 53 
    ld     e,c             ; 003E1C 59 
    ld     c,(hl)          ; 003E1D 4E 
    ld     d,h             ; 003E1E 54 
    ld     b,c             ; 003E1F 41 
    ld     e,b             ; 003E20 58 
    jr     nz,$3e68        ; 003E21 20 45 
    ld     d,d             ; 003E23 52 
    ld     d,d             ; 003E24 52 
    ld     c,a             ; 003E25 4F 
    ld     d,d             ; 003E26 52 
    dec    c               ; 003E27 0D 
    nop                    ; 003E28 00 
    ld     a,(hl)          ; 003E29 7E 
    or     a               ; 003E2A B7 
    jr     nz,$3e34        ; 003E2B 20 07 
    ld     a,$20           ; 003E2D 3E 20 
    ld     (hl),a          ; 003E2F 77 
    inc    hl              ; 003E30 23 
    xor    a               ; 003E31 AF 
    ld     (hl),a          ; 003E32 77 
    dec    hl              ; 003E33 2B 
    dec    hl              ; 003E34 2B 
    pop    af              ; 003E35 F1 
    ret                    ; 003E36 C9 
    ld     ($787d),a       ; 003E37 32 7D 78 
    ld     a,$10           ; 003E3A 3E 10 
    ld     ($7846),a       ; 003E3C 32 46 78 
    ret                    ; 003E3F C9 
    ld     a,(hl)          ; 003E40 7E 
    bit    6,a             ; 003E41 CB 77 
    jr     z,$3e4a         ; 003E43 28 05 
    cp     $80             ; 003E45 FE 80 
    jp     c,$3e5d         ; 003E47 DA 5D 3E 
    pop    bc              ; 003E4A C1 
    ld     de,$3e53        ; 003E4B 11 53 3E 
    push   de              ; 003E4E D5 
    push   bc              ; 003E4F C5 
    jp     $0502           ; 003E50 C3 02 05 
    ret    c               ; 003E53 D8 
    ld     hl,$3e1a        ; 003E54 21 1A 3E 
    call   $28a7           ; 003E57 CD A7 28 
    jp     $03e3           ; 003E5A C3 E3 03 
    cp     $62             ; 003E5D FE 62 
    jr     nz,$3e9a        ; 003E5F 20 39 
    and    $bf             ; 003E61 E6 BF 
    ld     (de),a          ; 003E63 12 
    inc    hl              ; 003E64 23 
    inc    de              ; 003E65 13 
    dec    b               ; 003E66 05 
    jp     z,$04ee         ; 003E67 CA EE 04 
    ld     a,(hl)          ; 003E6A 7E 
    bit    7,a             ; 003E6B CB 7F 
    jr     nz,$3e75        ; 003E6D 20 06 
    bit    6,a             ; 003E6F CB 77 
    jr     nz,$3e7f        ; 003E71 20 0C 
    jr     $3e7b           ; 003E73 18 06 
    and    $8f             ; 003E75 E6 8F 
    or     $80             ; 003E77 F6 80 
    jr     $3e92           ; 003E79 18 17 
    or     $c0             ; 003E7B F6 C0 
    jr     $3e92           ; 003E7D 18 13 
    cp     $62             ; 003E7F FE 62 
    jr     nz,$3e8c        ; 003E81 20 09 
    push   hl              ; 003E83 E5 
    ld     hl,$7839        ; 003E84 21 39 78 
    bit    4,(hl)          ; 003E87 CB 66 
    pop    hl              ; 003E89 E1 
    jr     z,$3e9a         ; 003E8A 28 0E 
    bit    5,a             ; 003E8C CB 6F 
    jr     z,$3e92         ; 003E8E 28 02 
    and    $bf             ; 003E90 E6 BF 
    ld     (de),a          ; 003E92 12 
    inc    hl              ; 003E93 23 
    inc    de              ; 003E94 13 
    djnz   $3e6a           ; 003E95 10 D3 
    jp     $04ee           ; 003E97 C3 EE 04 
    bit    5,a             ; 003E9A CB 6F 
    jr     z,$3ea0         ; 003E9C 28 02 
    and    $bf             ; 003E9E E6 BF 
    ld     (de),a          ; 003EA0 12 
    inc    hl              ; 003EA1 23 
    inc    de              ; 003EA2 13 
    djnz   $3e40           ; 003EA3 10 9B 
    jp     $04ee           ; 003EA5 C3 EE 04 
    ld     a,($7818)       ; 003EA8 3A 18 78 
    or     a               ; 003EAB B7 
    jp     nz,$04b8        ; 003EAC C2 B8 04 
    jp     $3e6a           ; 003EAF C3 6A 3E 
    ld     a,($7818)       ; 003EB2 3A 18 78 
    or     a               ; 003EB5 B7 
    jr     nz,$3ebb        ; 003EB6 20 03 
    res    6,(hl)          ; 003EB8 CB B6 
    ret                    ; 003EBA C9 
    set    6,(hl)          ; 003EBB CB F6 
    ret                    ; 003EBD C9 
    ld     a,($7818)       ; 003EBE 3A 18 78 
    or     a               ; 003EC1 B7 
    ld     a,$20           ; 003EC2 3E 20 
    jr     nz,$3ec8        ; 003EC4 20 02 
    or     $40             ; 003EC6 F6 40 
    ld     (hl),a          ; 003EC8 77 
    ret                    ; 003EC9 C9 
    push   af              ; 003ECA F5 
    ld     a,($7818)       ; 003ECB 3A 18 78 
    or     a               ; 003ECE B7 
    jr     z,$3ed8         ; 003ECF 28 07 
    pop    af              ; 003ED1 F1 
    and    $3f             ; 003ED2 E6 3F 
    push   hl              ; 003ED4 E5 
    jp     $31ab           ; 003ED5 C3 AB 31 
    pop    af              ; 003ED8 F1 
    or     $40             ; 003ED9 F6 40 
    push   hl              ; 003EDB E5 
    ld     hl,$7838        ; 003EDC 21 38 78 
    bit    1,(hl)          ; 003EDF CB 4E 
    pop    hl              ; 003EE1 E1 
    jr     z,$3ee6         ; 003EE2 28 02 
    and    $bf             ; 003EE4 E6 BF 
    jp     $31b5           ; 003EE6 C3 B5 31 
    ld     a,($7818)       ; 003EE9 3A 18 78 
    or     a               ; 003EEC B7 
    ld     a,(hl)          ; 003EED 7E 
    jr     nz,$3ef3        ; 003EEE 20 03 
    cp     $60             ; 003EF0 FE 60 
    ret                    ; 003EF2 C9 
    cp     $20             ; 003EF3 FE 20 
    ret                    ; 003EF5 C9 
    ld     a,($7818)       ; 003EF6 3A 18 78 
    or     a               ; 003EF9 B7 
    ld     a,$20           ; 003EFA 3E 20 
    jr     nz,$3f00        ; 003EFC 20 02 
    or     $40             ; 003EFE F6 40 
    ld     (de),a          ; 003F00 12 
    ret                    ; 003F01 C9 
    ld     b,$20           ; 003F02 06 20 
    ld     a,($7818)       ; 003F04 3A 18 78 
    or     a               ; 003F07 B7 
    ld     a,$20           ; 003F08 3E 20 
    ret    nz              ; 003F0A C0 
    or     $40             ; 003F0B F6 40 
    ret                    ; 003F0D C9 
    ld     de,$71e0        ; 003F0E 11 E0 71 
    ld     a,($7818)       ; 003F11 3A 18 78 
    or     a               ; 003F14 B7 
    ret    nz              ; 003F15 C0 
    pop    af              ; 003F16 F1 
    ld     a,(hl)          ; 003F17 7E 
    or     a               ; 003F18 B7 
    ret    z               ; 003F19 C8 
    res    6,a             ; 003F1A CB B7 
    ld     (de),a          ; 003F1C 12 
    inc    de              ; 003F1D 13 
    inc    hl              ; 003F1E 23 
    jr     $3f17           ; 003F1F 18 F6 
    ld     a,($7818)       ; 003F21 3A 18 78 
    or     a               ; 003F24 B7 
    ld     a,(hl)          ; 003F25 7E 
    jr     nz,$3f2f        ; 003F26 20 07 
    set    6,a             ; 003F28 CB F7 
    ld     (de),a          ; 003F2A 12 
    inc    de              ; 003F2B 13 
    ld     a,$7a           ; 003F2C 3E 7A 
    ret                    ; 003F2E C9 
    ld     (de),a          ; 003F2F 12 
    ld     a,$3a           ; 003F30 3E 3A 
    ret                    ; 003F32 C9 
    push   af              ; 003F33 F5 
    ld     a,($7818)       ; 003F34 3A 18 78 
    or     a               ; 003F37 B7 
    jr     nz,$3f3f        ; 003F38 20 05 
    pop    af              ; 003F3A F1 
    or     $40             ; 003F3B F6 40 
    ld     (de),a          ; 003F3D 12 
    ret                    ; 003F3E C9 
    pop    af              ; 003F3F F1 
    and    $3f             ; 003F40 E6 3F 
    ld     (de),a          ; 003F42 12 
    ret                    ; 003F43 C9 
    push   af              ; 003F44 F5 
    ld     a,($7818)       ; 003F45 3A 18 78 
    or     a               ; 003F48 B7 
    jr     nz,$3f54        ; 003F49 20 09 
    pop    af              ; 003F4B F1 
    bit    6,a             ; 003F4C CB 77 
    jp     nz,$3938        ; 003F4E C2 38 39 
    jp     $3931           ; 003F51 C3 31 39 
    pop    af              ; 003F54 F1 
    bit    6,a             ; 003F55 CB 77 
    jp     z,$3938         ; 003F57 CA 38 39 
    jp     $3931           ; 003F5A C3 31 39 
    jp     $3931           ; 003F5D C3 31 39 
    push   af              ; 003F60 F5 
    ld     a,($7818)       ; 003F61 3A 18 78 
    or     a               ; 003F64 B7 
    jr     nz,$3f6d        ; 003F65 20 06 
    pop    af              ; 003F67 F1 
    and    $3f             ; 003F68 E6 3F 
    jp     $3154           ; 003F6A C3 54 31 
    pop    af              ; 003F6D F1 
    and    $7f             ; 003F6E E6 7F 
    jp     $3154           ; 003F70 C3 54 31 
    call   $3775           ; 003F73 CD 75 37 
    ret    nc              ; 003F76 D0 
    pop    hl              ; 003F77 E1 
    jp     $3711           ; 003F78 C3 11 37 
    ld     a,($7819)       ; 003F7B 3A 19 78 
    ld     b,a             ; 003F7E 47 
    ld     a,($7818)       ; 003F7F 3A 18 78 
    cp     b               ; 003F82 B8 
    jp     z,$30e8         ; 003F83 CA E8 30 
    ld     ($7819),a       ; 003F86 32 19 78 
    ld     hl,$7000        ; 003F89 21 00 70 
    ld     bc,$0200        ; 003F8C 01 00 02 
    ld     a,(hl)          ; 003F8F 7E 
    or     a               ; 003F90 B7 
    jp     m,$3f97         ; 003F91 FA 97 3F 
    xor    $40             ; 003F94 EE 40 
    ld     (hl),a          ; 003F96 77 
    inc    hl              ; 003F97 23 
    dec    bc              ; 003F98 0B 
    ld     a,b             ; 003F99 78 
    or     c               ; 003F9A B1 
    jr     nz,$3f8f        ; 003F9B 20 F2 
    jp     $30e8           ; 003F9D C3 E8 30 
    ld     a,($68fd)       ; 003FA0 3A FD 68 
    bit    2,a             ; 003FA3 CB 57 
    ld     a,$20           ; 003FA5 3E 20 
    jr     nz,$3fb1        ; 003FA7 20 08 
    or     $40             ; 003FA9 F6 40 
    ld     ($7818),a       ; 003FAB 32 18 78 
    ld     ($7819),a       ; 003FAE 32 19 78 
    ld     ($783c),a       ; 003FB1 32 3C 78 
    jp     $01c9           ; 003FB4 C3 C9 01 
    nop                    ; 003FB7 00 
    nop                    ; 003FB8 00 
    nop                    ; 003FB9 00 
    nop                    ; 003FBA 00 
    nop                    ; 003FBB 00 
    nop                    ; 003FBC 00 
    nop                    ; 003FBD 00 
    nop                    ; 003FBE 00 
    nop                    ; 003FBF 00 
    nop                    ; 003FC0 00 
    nop                    ; 003FC1 00 
    nop                    ; 003FC2 00 
    nop                    ; 003FC3 00 
    nop                    ; 003FC4 00 
    nop                    ; 003FC5 00 
    nop                    ; 003FC6 00 
    nop                    ; 003FC7 00 
    nop                    ; 003FC8 00 
    nop                    ; 003FC9 00 
    nop                    ; 003FCA 00 
    nop                    ; 003FCB 00 
    nop                    ; 003FCC 00 
    nop                    ; 003FCD 00 
    nop                    ; 003FCE 00 
    nop                    ; 003FCF 00 
    nop                    ; 003FD0 00 
    nop                    ; 003FD1 00 
    nop                    ; 003FD2 00 
    nop                    ; 003FD3 00 
    nop                    ; 003FD4 00 
    nop                    ; 003FD5 00 
    nop                    ; 003FD6 00 
    nop                    ; 003FD7 00 
    nop                    ; 003FD8 00 
    nop                    ; 003FD9 00 
    nop                    ; 003FDA 00 
    nop                    ; 003FDB 00 
    nop                    ; 003FDC 00 
    nop                    ; 003FDD 00 
    nop                    ; 003FDE 00 
    nop                    ; 003FDF 00 
    nop                    ; 003FE0 00 
    nop                    ; 003FE1 00 
    nop                    ; 003FE2 00 
    nop                    ; 003FE3 00 
    nop                    ; 003FE4 00 
    nop                    ; 003FE5 00 
    nop                    ; 003FE6 00 
    nop                    ; 003FE7 00 
    nop                    ; 003FE8 00 
    nop                    ; 003FE9 00 
    nop                    ; 003FEA 00 
    nop                    ; 003FEB 00 
    nop                    ; 003FEC 00 
    nop                    ; 003FED 00 
    nop                    ; 003FEE 00 
    nop                    ; 003FEF 00 
    rst    38h             ; 003FF0 FF 
    rst    38h             ; 003FF1 FF 
    rst    38h             ; 003FF2 FF 
    rst    38h             ; 003FF3 FF 
    rst    38h             ; 003FF4 FF 
    rst    38h             ; 003FF5 FF 
    rst    38h             ; 003FF6 FF 
    rst    38h             ; 003FF7 FF 
    rst    38h             ; 003FF8 FF 
    rst    38h             ; 003FF9 FF 
    rst    38h             ; 003FFA FF 
    rst    38h             ; 003FFB FF 
    rst    38h             ; 003FFC FF 
    rst    38h             ; 003FFD FF 
    rst    38h             ; 003FFE FF 
    rst    38h             ; 003FFF FF 
