///////////////////////// TECLADO PS2 -> Laser200 ////////////////////
//
// Lectura de scancodes y detección de pulsado/soltado
// Conversión a matriz de datos con estado del teclado
// Lectura dependiente de los bits del bus de dirección:
//   A[7:0] seleccionan fila de teclas en el VZ200

module keybps2(
input  clk,			//reloj principal
input  kclk,		// reloj PS2
input  kdat,		// datos PS2
input  [7:0]a,		// selección de fila 
output [5:0]row,	// salida de fila de teclado
output resetk,		// tecla de reset pulsada (F12)
output resetk2		// tecla de reset pulsada (F9)
);

//////////////////////////// PS2 serial receiver ///////////////////////////
reg [1:0]krck=2'b11;			// sampled (registered) keyboard clock
wire kfall=(~krck[0])&krck[1];	// falling clock

reg [10:0]kreg=11'h7FF;			// shift register, 11-bit
reg rel=0;						// key released (if last scancode was 0xF0)
wire newsc=~kreg[0];			// zero start bit => scancode received
wire [7:0]scancode=kreg[8:1];	// Sólo válido durante un ciclo de clk

reg [11:0]toutc=0;				// timeout counter (4096 ciclos = 1.14ms @ 3.57MHz)
wire tout=(&toutc)&(~kfall);	// no timeout si coincide con flanco en este ciclo

// shift reg.gets filled with ones after a key is received or on timeouts
always @(posedge clk) begin
	krck<={krck[0],kclk};
	toutc<= kfall? 0: toutc+1;
	kreg<=(newsc|tout) ? 11'h7FF : ( kfall ? {kdat,kreg[10:1]} : kreg);
	if (newsc) rel<=(scancode==8'hF0);
end

assign resetk=(scancode==8'h7)&newsc&(~rel)&(~clk);		// F12
assign resetk2=(scancode==8'h1)&newsc&(~rel)&(~clk);	// F9

/////////////// Tabla de traducción de scancodes /////////////
reg [5:0]keypos;	// No es registro
always@*
 casex (scancode)
 8'h2c: keypos<=6'd00;	// T
 8'h1D: keypos<=6'd01;	// W
 8'h24: keypos<=6'd03;	// E
 8'h15: keypos<=6'd04;	// Q
 8'h2D: keypos<=6'd05;	// R

 8'h34: keypos<=6'd06;	// G
 8'h1B: keypos<=6'd07;	// S
 8'h14: keypos<=6'd08;	// ctrl
 8'h23: keypos<=6'd09;	// D
 8'h1C: keypos<=6'd10;	// A
 8'h2B: keypos<=6'd11;	// F

 8'h32: keypos<=6'd12;	// B
 8'h22: keypos<=6'd13;	// X
 8'h12: keypos<=6'd14;	// shift
 8'h59: keypos<=6'd14;	// shift
 8'h21: keypos<=6'd15;	// C
 8'h1A: keypos<=6'd16;	// Z
 8'h2A: keypos<=6'd17;	// V

 8'h2E: keypos<=6'd18;	// 5
 8'h1E: keypos<=6'd19;	// 2
 8'h26: keypos<=6'd21;	// 3
 8'h16: keypos<=6'd22;	// 1
 8'h25: keypos<=6'd23;	// 4

 8'h31: keypos<=6'd24;	// N
 8'h49: keypos<=6'd25;	// .
 8'h41: keypos<=6'd27;	// ,
 8'h29: keypos<=6'd28;	// space
 8'h3A: keypos<=6'd29;	// M

 8'h36: keypos<=6'd30;	// 6
 8'h46: keypos<=6'd31;	// 9
 8'h4A: keypos<=6'd32;	// -
 8'h3E: keypos<=6'd33;	// 8
 8'h45: keypos<=6'd34;	// 0
 8'h3d: keypos<=6'd35;	// 7

 8'h35: keypos<=6'd36;	// Y
 8'h44: keypos<=6'd37;	// O
 8'h5A: keypos<=6'd38;	// return
 8'h43: keypos<=6'd39;	// I
 8'h4D: keypos<=6'd40;	// P
 8'h3C: keypos<=6'd41;	// U

 8'h33: keypos<=6'd42;	// H
 8'h4B: keypos<=6'd43;	// L
 8'h27: keypos<=6'd44;	// :  (windows menu)
 8'h42: keypos<=6'd45;	// K
 8'h11: keypos<=6'd46;	// ;  (alt gr)
 8'h3B: keypos<=6'd47;	// J


 default: keypos<=6'b111111; // fuera de la matriz de teclas
endcase

////////////////// Matriz de teclado emulado //////////////////
reg [47:0]karray=48'hFFFF_FFFF_FFFF; // sin pulsar al inicio
wire wrk;
assign wrk=newsc; //&(keypos<48);
always @(posedge clk) begin
	if (wrk)karray[keypos] <= rel;
end

// Lectura dependiente de bits de dirección
// Ojo, si más de un bit está en 0 se hace la AND lógica de las filas
// correspondientes
assign row=	((~a[0])? karray[ 5: 0] : 6'b111111) &
			((~a[1])? karray[11: 6] : 6'b111111) &
			((~a[2])? karray[17:12] : 6'b111111) &
			((~a[3])? karray[23:18] : 6'b111111) &
			((~a[4])? karray[29:24] : 6'b111111) &
			((~a[5])? karray[35:30] : 6'b111111) &
			((~a[6])? karray[41:36] : 6'b111111) &
			((~a[7])? karray[47:42] : 6'b111111) ;

endmodule

