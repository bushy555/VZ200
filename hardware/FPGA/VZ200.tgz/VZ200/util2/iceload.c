#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <asm/termios.h>
#include <fcntl.h>
#include <stdio.h>
#include <signal.h>

unsigned int serial_fd;
//#include "jedec.c"
#include "chips.c"

// Reads one byte from serial port
int ugetch()
{
	int j;
	unsigned char a;
	j=read(serial_fd,&a,1); if (j!=1) return -1;
	return a;
}

// Writes one byte to serial port
void uputch(unsigned char d)
{
	write(serial_fd,&d,1);	
}

// multi-byte write to serial port
void swrite(unsigned char *pdata,unsigned int len)
{
	int j,i=0;
	do	{
		j=write(serial_fd,&pdata[i],len);
		if (j>0) {i+=j; len-=j;}
	} while(len);
}

// multi-byte read from serial port
void sread(unsigned char *pdata,unsigned int len)
{
	int j,i=0;
	do	{
		j=read(serial_fd,&pdata[i],len);
		if (j>0) {i+=j; len-=j;}
	} while(len);
}

///-----------------------------------------------------

// Write a 32-bit word (big endian)
void uputw(unsigned int d)
{
	unsigned char a;

	uputch(d>>24);
	uputch((d>>16)&0xff);
	uputch((d>>8)&0xff);
	uputch(d&0xff);
}

// Write a 24-bit word (big endian)
void uputw3(unsigned int d)
{
	unsigned char a;

	uputch((d>>16)&0xff);
	uputch((d>>8)&0xff);
	uputch(d&0xff);
}

// Read a 32-bit word (big endian)
int ugetw()
{
    int i,j;
    unsigned char a;

	j=ugetch();	if (j==-1) return -1; i =j<<24; 
	j=ugetch();	if (j==-1) return -1; i|=j<<16; 
	j=ugetch();	if (j==-1) return -1; i|=j<<8; 
	j=ugetch();	if (j==-1) return -1; i|=j; 		
	
    return i;
}

// Value with multiplier (ASCII) to integer
int amtoi(char *p)
{
	int val=0;
	char a;

	while(1) {
		a=*p++;
		if (a>='0' && a<='9') {val*=10; val+=a-'0';}
		else if (a=='k' || a=='K') return val<<10;
		else if (a=='M') return val<<20;
		else return val;
	}
}

void exitprog()
{
	struct termios term;
	// set STDIN as before
	tcgetattr(0,&term);
	term.c_lflag|=ICANON;
	term.c_lflag|=ECHO;
	if (tcsetattr(0,TCSANOW,&term))
		fprintf(stderr,"Error.tcsetattr\n");
	exit(0);
}

int sendcc=0;

void crtl_c_handler()
{
	if (sendcc) uputch(3);
	else exitprog();
}

////////////////////////////////////////////////////////////////////////////////
// 				MAIN
////////////////////////////////////////////////////////////////////////////////


int main(int argc, char **argv)
{
        int i,j,k,l,len,maxlen,dir,com,divi;
        struct termios term;
		char *fname="flash.bin",*fdev="/dev/ttyACM0";
        static unsigned char buf[1<<24];	// Buffer (whole flash size 16MB)
		FILE *fp;
		int baud=115200,paridad=0;
        static const int baudtable[][2]={
            50,B50,
            75,B75,
            110,B110,
            150,B150,
            200,B200,
            300,B300,
            600,B600,
            1200,B1200,
            2400,B2400,
            4800,B2400,
            9600,B9600,
            19200,B19200,
            38400,B38400,
            57600,B57600,
            115200,B115200,
			230400,B230400,
			460800,B460800,
			500000,B500000,
			576000,B576000,
            921600,B921600,
			1000000,B1000000,
            1500000,B1500000,
			3000000,B3000000,
            0,0
        };
		int sl, fdin, fdlog, crlf=0;
		char a,oa,*logn=NULL,fn[256];
		memset(buf,0xFF,1<<24);	// buffer filled with 0xFF
		// Command line parsing
		com=len=dir=divi=0;

		for (i=1;i<argc;i++) {
			if (argv[i][0]=='-') {
				switch(argv[i][1]) {
				case 'd':	if (i<argc-1) fdev=argv[++i]; break;
				case 'b':	com='b'; break;
				case 'r':	com='r'; if (i<argc-1) fname=argv[++i]; break;
				case 'P':	com='P'; goto rdfilein;
				case 'p':
					com='p';
rdfilein:			if ((fp=fopen(argv[++i],"rb"))==NULL) {perror("fopen(read)"); exit(1);}
					len=fread(buf,1,1<<24,fp);
					fclose(fp);
					break;
				case 'q':	com='q'; goto rdfilein;					
				case 'C':	com='C'; goto rdfilein;
				case 'c':	com='c'; goto rdfilein;
				case 'l':	len=amtoi(argv[++i]); break;
				case 'a':	dir=amtoi(argv[++i]); break;
				case 's':   baud=atoi(argv[++i]); break;
				case 't':	com='t'; break;
				case 'f':
					divi=atoi(argv[++i]); 
					divi=(48 + divi/2)/divi;
					break;
				case 'g':	logn=argv[++i]; break;	
				case 'e':	
					crlf=atoi(argv[++i]);
					if (crlf>2) crlf=2;
					break;
				default:
					printf("Use %s <options>, with <options>=\n",argv[0]);
					printf("------------------------------------------------------------------------\n");
					printf("-d <device>   serial Device to use (/dev/ttyUSB...)\n");
					printf("-c <file>     Configure the FPGA with file (bitstream to config RAM)\n");
					printf("              and then enter a serial terminal\n");
					printf("-C <file>     Configure the FPGA with file (bitstream to config RAM)\n");
					printf("              without terminal\n");
					printf("-b            Bulk erase: Erase all the SPI Flash\n");
					printf("-p <file>     Program flash (required sectors erased before programming)\n");
					printf("-P <file>     Program flash (without sector erasing)\n");
					printf("-r <file>     Read SPI Flash to file\n");
					printf("-a <address>  start Address for programming and reading (defaults to 0)\n");
					printf("-l <length>   Length of the data for reading (defaults to all Flash)\n");
                    printf("              sufixes ..k (*1024) and ..M (*1024k) can be used with\n");
					printf("              addresses and/or lengths\n");
					printf("-t            just start a serial Terminal\n");
					printf("-s <baud>     Speed for the serial terminal\n");
					printf("-f <MHz>      Frequency to apply to FPGA pin #21 (defaults to 12MHz)\n");
					printf("              possible frequencies: 48MHz/N (N integer)\n");
					printf("              (not supported by the PRGICE board)\n");
					printf("-g <file>     loG terminal data to file\n");
					printf("-e <val>      Terminal: Enter key sends (0: NL) (1: CR) (2: CR,NL)\n");
					printf("\nTerminal control keys:\n");
					printf("---------------------------------------------------\n");
					printf("   <esc>,<esc> : exit terminal\n");
					printf("   <ctrl-F>    : ask for File and send its contents\n");
					printf("---------------------------------------------------\n");
					break;
				}
			}
		}

		printf("\niceload 1.2 (J. Arias 2022...)\n");
		// Open serial port
        printf("\n--------------------- LPC-FPGA loader --------------------\n");
		printf("Device: %s\n",fdev);
		if ((serial_fd=open(fdev,O_RDWR|O_NOCTTY))==-1) {perror("open"); exit(1);}
		
        // set attributes
        bzero(&term,sizeof(term)); // todos los flags en cero por defecto
//        term.c_cflag = B3000000 | CS8 | CSTOPB | CLOCAL | CREAD; // baud, bits, sin control de flujo, RX on
        term.c_cflag = B3000000 | CS8 | CLOCAL | CREAD; // baud, bits, sin control de flujo, RX on
		term.c_cc[VMIN]=1;
        if (tcsetattr(serial_fd,TCSANOW,&term)) { fprintf(stderr,"Error.tcsetattr\n"); exit(1); }
        // Flush input 
        if (tcflush(serial_fd,TCIFLUSH)) { fprintf(stderr,"Error.tcflush\n"); exit(1); }

        // RESET
		// Pins: reset: /DTR, bootloader: /RTS
        if(ioctl(serial_fd, TIOCMGET, &i)) {fprintf(stderr,"Error.ioctl TIOCMGET\n"); exit(1);}
        i|=TIOCM_DTR|TIOCM_RTS; // Reset L Bootloader L
        if(ioctl(serial_fd, TIOCMSET, &i)) {fprintf(stderr,"Error.ioctl TIOCMSET\n"); exit(1);}
        usleep(100000);
        i&=~TIOCM_RTS;        // bootloader H
        if(ioctl(serial_fd, TIOCMSET, &i)) {fprintf(stderr,"Error.ioctl TIOCMSET\n"); exit(1);}
        usleep(100000);
        i&=~TIOCM_DTR;        // Reset H
        if(ioctl(serial_fd, TIOCMSET, &i)) {fprintf(stderr,"Error.ioctl TIOCMSET\n"); exit(1);}
        usleep(100000);
		
		// Flush input 
        if (tcflush(serial_fd,TCIFLUSH)) { fprintf(stderr,"Error.tcflush\n"); exit(1); }

		if (com=='t') goto terminal;

		// Autobaud
		uputch('A');
		
		while(1) {
			i=ugetch();
			if (i==0x00) continue;
			if (i==0x80) continue;
			if (i==0xC0) continue;
			if (i==0xE0) continue;
			if (i==0xF0) continue;
			if (i==0xF8) continue;
			if (i==0xFC) continue;
			if (i==0xFE) continue;
			if (i==0xFF) continue;

			if (i=='A') {printf("Autobaud OK\n"); break;}
			printf("Autobaud Error\n\n"); exit(1);
		}

		// Firmware Version
		uputch('V');
		j=ugetch(); k=ugetch();
		printf("Firmware rev: %d.%02d\n",j,k);

		// Flash ID/size
		uputch('I');
		i =ugetch()<<16;
		i|=ugetch()<<8;
		i|=ugetch();

		j=(i>>16);
		//printf("Flash ID=0x%06x: %s,",i,(j<127)?jedec_id[j]:"Desconocido");	
		printf("Flash ID=0x%06x: %s,",i,chipid(i));	
		maxlen=1<<(i&0xff);	// Flash Size
		printf(" %d KBytes\n",maxlen>>10);

		if (divi) {
			uputch('F');
			uputch(divi);
			if (ugetch()) printf("Error on Frequency set (pin 21)\n");
			else printf("Pin 21: %f MHz\n",(float)48.0/divi);
		}


		switch(com) {
		case 'b':	// Bulk Erase
			printf("Bulk Erase Flash, be patient ..."); fflush(stdout);
			uputch('B');
			ugetch();
			uputch('T');
			j=ugetw(); k=ugetw();
			printf("(%.3f s)\n",((float)j)*1e-6);
			goto final;

		case 'r':	// Read Flash
			if (!len) len=maxlen;
			com=101;
			printf("Read Flash addr=0x%06x len=%d bytes >%s\n",dir,len,fname); 
			uputch('R');
			uputw3(dir);	// Base Address
			uputw3(len);	// Block length
			i=0; k=len;
			do {
				j=k; if(j>256) j=256;
				sread(&buf[i],j);
				i+=j;
				k-=j;
				l=((i+1)*100/len);
				if (l!=com) {com=l; printf("\r %3d%%",l); fflush(stdout);}
				uputch('-'); 
			} while (k);

			uputch('T');
			j=ugetw(); k=ugetw();
			if (j>=1000000) printf("  (%.2f s)\n",((float)j)*1e-6);
			else if (j>1000) printf("  (%.2f ms)\n",((float)j)*1e-3);
			else printf("  (%d us)\n",j);
			if((fp=fopen(fname,"wb"))==NULL) {perror("fopen(write)"); exit(1);}
			fwrite(buf,1,len,fp);
			fclose(fp);
			break;

		case 'P':
		case 'p':		// SPI Flash Programming
			len=(len+255)&0x00FFFF00;	// pad to multiple of 256
			if (dir&0xff) {printf("Error: Address must be multiple of 256\n\n"); exit(1);}
			printf("Program Flash addr=0x%06x len=%d bytes\n",dir,len);
			if (com=='p') {
				i=dir>>16;			// Start Sector
				j=(dir+len-1)>>16;	// End Sector
				for (;i<=j;i++) {
					printf("\r  Erasing sector %d",i); fflush(stdout);
					uputch('E');uputch(i);
					if (ugetch()) exit(2);
				}
				uputch('T');
				j=ugetw(); k=ugetw();
				printf("  (sector erase: ");
				if (j>=1000000) printf("%.2f s)\n",((float)j)*1e-6);
				else if (j>1000) printf("%.2f ms)\n",((float)j)*1e-3);
				else printf("%d us)\n",j);
			}
			printf("  Programming\n"); 
			j=len; k=0; com=101;
			do {
				uputch('P');
				uputch(dir>>16);
				uputch(dir>>8);
				//for (i=0;i<256;i++) uputch(buf[k++]);
				swrite(&buf[k],256); k+=256;
				if (ugetch()) exit(2);
				dir+=256; j-=256;
				i=100-(j*100/len);
				if (i!=com) {com=i; printf("\r  %3d%%",i); fflush(stdout);}
			} while (j);
			uputch('T');
			j=ugetw(); k=ugetw();
			printf("  (page data: %d us, page program: %dus)\n",j,k);
			break;

		case 'q':
			printf("Config FPGA len=%d bytes (Flash SQI)\n",len);
			uputch('Q');
			goto labconf;
			
		case 'C':
		case 'c':	//	Config RAM (load directly to FPGA)
			printf("Config FPGA len=%d bytes\n",len);
			uputch('C');
labconf:	uputw3(len);
			if (ugetch()!=1) exit(2);	// Wait for FPGA RESET
			swrite(buf,len);	// Send Image

			if (ugetch()) {printf("Error: CDONE not set\n\n"); exit(2);}
			if (com=='c') goto terminal;
			goto final;
			
		case 't':
			uputch('X');
			if (ugetch()!='X') {printf("FPGA exec error\n\n"); exit(1);}
			goto terminal;

		default:
			printf("Nothing to do: Hasta luego Lucas :)\n");
			break;
		}
		uputch('X');
		if (ugetch()!='X') {printf("FPGA exec error\n\n"); exit(1);}
final:
		printf("----------------------------------------------------------\n");
		exit(0);

/////////////////////////////////////////////////////////////////////////////////////
//                                TERMINAL
/////////////////////////////////////////////////////////////////////////////////////

terminal:
		signal(SIGINT, crtl_c_handler);

        for (i=0;baudtable[i][0];i++) {
            if (baud==baudtable[i][0]) break;
        }
        if (!baudtable[i][0]) {printf("Serial speed unsupported\n"); exit(0);}

		tcgetattr(serial_fd,&term);
        term.c_cflag&=~CBAUD;
        term.c_cflag|=baudtable[i][1];
		if (paridad) {
			term.c_cflag|=PARENB;
			if (paridad&1) term.c_cflag|=PARODD;
		}

        if (tcsetattr(serial_fd,TCSANOW,&term)) {
                fprintf(stderr,"Error.tcsetattr\n");
                exit(0);
        }
		// Flush input 
        if (tcflush(serial_fd,TCIFLUSH)) { fprintf(stderr,"Error.tcflush\n"); exit(1); }

		printf("-----------------------------------------------\n");
        printf("Terminal: Speed: %d baud\n",baud);		
        printf("-----------------------------------------------\n");
        // non blocking uart
        i=fcntl(serial_fd,F_GETFL); fcntl(serial_fd,F_SETFL,i|O_NONBLOCK);

        // STDIN non-blocking, no canon, no eco
        i=fcntl(0,F_GETFL); fcntl(0,F_SETFL,i|O_NONBLOCK);
        tcgetattr(0,&term);
        term.c_lflag&=~ICANON;
        term.c_lflag&=~ECHO;
        if (tcsetattr(0,TCSANOW,&term)) {
                fprintf(stderr,"Error.tcsetattr\n");
                exit(0);
        }

		// Create log file if requested
		if (logn) {
			if ((fdlog=creat(logn,0666))<=0) {perror("creat log"); exit(0);}
		}

        fdin=0; // reading from stdin by default
        sendcc=1;	// ctrl-c sends ascii 3
        for (;;) {
                sl=2; // Sleep Counter
                if ((j=read(serial_fd,buf,1024))>0) { // data from serial port
					write(1,buf,j);
					if (logn) write(fdlog,buf,j); // to Log file
                } else sl--;
				oa=a;
                j=read(fdin,&a,1);	// data from stdin or file
                if (j==0 && fdin) {
                        close(fdin);
                        fdin=0; // file end: go back to stdin
                }
                if (j==1) {
                        switch (a) {
                        case    27:	// <esc><esc> => exit program
								if (oa==27) {
									if(logn) close(fdlog);
									exitprog();
								}
								break;
//                        case    'V'-64: a=3; // <ctrl>-V translated as <ctrl>-C
//                                break;
                        case    '\n':   if (crlf) a='\r'; // LF -> CR,LF if requested
                                break;
                        case    'X'-64: 	// <ctrl>-X => Upload file with XON/XOFF
								printf("\nInclude File: ");
                                fflush(stdout);
                                tcgetattr(0,&term);	// stdin blocking and echo on
                                term.c_lflag|=ECHO;
                                tcsetattr(0,TCSANOW,&term);
                                i=fcntl(0,F_GETFL); fcntl(0,F_SETFL,i&(~O_NONBLOCK));
								// get the file name from stdin
                                fgets(fn,255,stdin); fn[strlen(fn)-1]=0;

								if ((fp=fopen(fn,"rb"))!=NULL) {
									sendcc=0;	// ctrl-c exits program
							        i=fcntl(serial_fd,F_GETFL); // for blocking/unblocking UART
							        fcntl(serial_fd,F_SETFL,i&(~O_NONBLOCK)); // blocking uart
							        k=192;
									while(1) {
										j=fread(buf,1,k,fp);
										if (j) swrite(buf,j);
										if(feof(fp)) break;
										k=128;
										//wait for XON
										do {j=read(serial_fd,&a,1);
											if (j==1 && a==19) {putchar('|'); fflush(stdout);}
										} while (j!=1 || a!=17);
										putchar('.'); fflush(stdout);
									}
									fclose(fp);
							        fcntl(serial_fd,F_SETFL,i|O_NONBLOCK); // non-blocking uart
							        printf("-done-\n");
								} else printf("worng file\n");

								// stdin non-blocking, no echo
                                fcntl(0,F_SETFL,i|O_NONBLOCK);
                                term.c_lflag&=~ECHO;
                                tcsetattr(0,TCSANOW,&term);
                                sendcc=1;	// ctrl-c sends ascii 3
                                continue;
                                
                        case    'F'-64: 	// <ctrl>-F => Upload File
								printf("\nInclude File: ");
                                fflush(stdout);
                                tcgetattr(0,&term);	// stdin blocking and echo on
                                term.c_lflag|=ECHO;
                                tcsetattr(0,TCSANOW,&term);
                                i=fcntl(0,F_GETFL); fcntl(0,F_SETFL,i&(~O_NONBLOCK));
								// get the file name from stdin
                                fgets(fn,255,stdin); fn[strlen(fn)-1]=0;

								if ((fp=fopen(fn,"rb"))!=NULL) {
									sendcc=0;	// ctrl-c exits program
									// blocking uart
							        i=fcntl(serial_fd,F_GETFL); fcntl(serial_fd,F_SETFL,i&(~O_NONBLOCK));
									while(1) {
										j=fread(buf,1,(1<<12),fp);
										if (j) swrite(buf,j);
										if(feof(fp)) break;
									}
									fclose(fp);
									// non-blocking uart
							        i=fcntl(serial_fd,F_GETFL); fcntl(serial_fd,F_SETFL,i|O_NONBLOCK);
							        printf("-done-\n");
								}else printf("worng file\n");

								// stdin non-blocking, no echo
                                fcntl(0,F_SETFL,i|O_NONBLOCK);
                                term.c_lflag&=~ECHO;
                                tcsetattr(0,TCSANOW,&term);
								sendcc=1;	// ctrl-c sends ascii 3
                                continue;


                        case    'T'-64: 	// <ctrl>-T => "Type" File
								printf("\nInclude File to type: ");
                                fflush(stdout);
                                tcgetattr(0,&term);	// stdin bloqueante y con eco
                                term.c_lflag|=ECHO;
                                tcsetattr(0,TCSANOW,&term);
                                i=fcntl(0,F_GETFL); fcntl(0,F_SETFL,i&(~O_NONBLOCK));
								// lee de stdin el nombre del fichero
                                fgets(fn,255,stdin); fn[strlen(fn)-1]=0;
								// stdin de nuevo no bloqueante y sin eco
                                fcntl(0,F_SETFL,i|O_NONBLOCK);
                                term.c_lflag&=~ECHO;
                                tcsetattr(0,TCSANOW,&term);
								// Abrimos el fichero. 
                                if ((fdin=open(fn,O_RDONLY))==-1) fdin=0;
								//A partir de ahora se leen datos del fichero en lugar
								//de stdin
                                continue;
                        }
                        uputch(a); 		
                        usleep(20000); 	// delay between characters (do not flood the receiver)
						// CR,LF: longer delay
						if (a=='\r') usleep(200000);
                        if (a=='\r' && crlf>1) {uputch('\n'); usleep(200000);}
                } else sl--;
                if (!sl) usleep(10000); // Sleep process if no data is available
        }

}

