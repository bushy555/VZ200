/////////////////////////////////////////////////////////////////////////
// 					MC6847-like Video Controller
// 						J. Arias (2025)
//
// VESA 640x480 timing
// Write-only video memory
// Partial MC6847 recreation, only VTech Laser200 modes:
//   gr=0 -> Text mode 32x16, internal 5x7 font, 6-line high semigraphics
//   gr=1 -> Graphics mode, 128x64, 2bpp, 3-line high pixels

module vz6847 ( 
	input clk,		// clock input @ 12.5MHz
	input clkw,		// CPU clock (for writes)
	input [7:0]di,	// data to write
	input [10:0]aw,	// address for write
	input we,		// write enable
	input gr,		// 0: Text 1: Graphics
	input css,		// Color selection for text (0:green 1:Orange) / graphics
	output hsyn,	// horizontal sync
	output vsyn,	// vertical sync
	output [3:0]irgb,	// IGRB video output
	output fs		// frame sync (vertical display enable)
);

assign fs=vde;

//////////////////// VGA timing //////////////////////

reg [8:0]hc=0;	// horizontal counter
reg hsyn=1;

wire hmaxc = &((~9'd399)|hc);

always @(posedge clk) begin
	if (hmaxc) hc<=0; else hc<=hc+1;
	if (hc==10'd295) hsyn<=0;
	if (hc==10'd343) hsyn<=1;
end
wire hde=~hc[8];

reg [9:0]vc=382;	// vertical counter
reg vsyn=1;
reg vde=1;
wire vmaxc = &((~10'd524)|vc);

always @(negedge hde) begin
	if (vmaxc) begin vc<=0; vde<=1; end else vc<=vc+1;
	if (vc==10'd441) vsyn<=0;
	if (vc==10'd443) vsyn<=1;
	if (vc==10'd383) vde<=0;
end

// Display Enable
wire de;
assign de=hde&vde;
reg [2:0]dde;	// delayed
always @(posedge clk) dde<={dde[1:0],de};

///////////////// ghost video memory (2KB) //////////////////
wire [10:0]va;	// video address

reg [7:0]gram[0:2047];
integer i;
initial begin
	for (i=0;i<256;i=i+1) gram[i]=i;
end
always @(posedge clkw) if (we) gram[aw]<=di;
reg [7:0]gramo;
wire vrd;
always @(posedge clk) if (vrd) gramo<=gram[va];

// Character generator ROM
reg [4:0]chgen[0:511];
initial $readmemh("6847chargen.list",chgen);

//////////// Vertical addressing counters ///////////
// character line counter. 
//  Text mode: modulus 24, Graphics mode: modulus 6
//  Stars counting at #28 (#0 : first character row)
//  modulus 24: (28-31, 0-19, 28...) modulus 6: (28-31, 0, 1, 28...)
reg [4:0]chline=5'd28;		
wire chlmxc = (chline==19) | (gr&(~chline[4])&chline[0]); // max count
always @(negedge hde) chline<= ((~vde)|chlmxc) ? 5'd28 : chline+1;
wire halfch=(chline<5'd8) | (chline>=5'd28); // First half of character

// Vertical Character/graphics-line counter
//   up to #15 in text mode
//   up to #63 in grahics mode
reg[5:0]chcount=0;
always @(negedge hde) chcount <= (~vde) ? 0: chcount + chlmxc;

//////// Video read & shift reg. load ////////
assign va={ chcount,hc[7:3] }; 
assign vrd= de & (hc[2:0]==0);
reg load;
always @(posedge clk) load<=vrd;

/////// shift register for text mode //////
reg [7:0]tsh;

wire [7:0]apix8= gramo[7] ? 
	(halfch ? {gramo[3],gramo[3],gramo[3],gramo[3],gramo[2],gramo[2],gramo[2],gramo[2]} :
			  {gramo[1],gramo[1],gramo[1],gramo[1],gramo[0],gramo[0],gramo[0],gramo[0]} ) :
				(chline[4] ? 0 : {2'b00,chgen[{gramo[5:0],chline[3:1]}],1'b0});
always @(posedge clk)
	if (load) tsh<=apix8;
	else tsh<={tsh[6:0],1'b0};

reg invert;
always @(posedge clk) invert<=(gramo[7:6]==2'b01);
wire pixel = gr ? dde[2] : ( dde[1] & (tsh[7]^invert));

/////// shift register for graphics ///////
reg [7:0]gsh;
always @(posedge clk)
	if (load) gsh<=gramo;
	else if (hc[0]) gsh<={gsh[5:0],2'b00};

/////// Chroma and (imperfect) IRGB translation ///////
reg [2:0]chroma;
always @(posedge clk) 
	chroma<= gr ? {css,gsh[7:6]}: 	// Graphics
			 gramo[7] ? gramo[6:4] : {css,css,css};	// Text

reg [3:0]irgbt[0:7];
initial begin
	irgbt[0]=4'b0010;	// Green
	irgbt[1]=4'b0110;	// Yellow
	irgbt[2]=4'b0001;	// Blue
	irgbt[3]=4'b0100;	// Red
	irgbt[4]=4'b0111;	// Buff
	irgbt[5]=4'b0011;	// Cyan
	irgbt[6]=4'b0101;	// Magenta
	irgbt[7]=4'b1100;	// Orange (pink)
end
 
assign irgb= pixel ? irgbt[chroma] : 4'b0000;

endmodule


