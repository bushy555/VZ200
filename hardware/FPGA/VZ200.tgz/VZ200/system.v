///////////////////////////////////////////////////////
// Vtech Laser 200 computer recreated
//  by Jesus Arias (2025)
//

`include "video6847.v"
`include "flashcache16b.v"
`include "keyb.v"
`include "tv80s.v"
`include "tv80_core.v"
`include "tv80_alu.v"
`include "tv80_reg.v"
`include "tv80_mcode.v"

`include "bac03.v"
`include "uart_simple.v"

//`define TST6847

module SYSTEM (
	input clk,		// 50 MHz
	input reset,

	output xwe,			// external RAM: WE
	output xoe,			// external RAM: OE
	output [15:0]xa,	// external RAM: address
	output [15:0]xdo,	// external RAM: data output
	input  [15:0]xdi,	// external RAM: data input
	output xbhe,		// external RAM: high byte
	output xble,		// external RAM: low byte 
	// Serial port
	output txd,		
	input rxd,
	// VGA signals
	output hsyn,		
	output vsyn,
	output [11:0]video,	// RGB444 (4 bits per color)
	// SPI bus (To Flash and SD card)
	output sck,
	output mosi,
	output ss1,		// Flash /CS
	output ss2,		// SD card /CS
	input  miso,
	// Audio
	output sound,

	// Keyboard
	input	kclk,
	input	kdat
	
	, output [7:0]debug
	
);

assign ss2=1'b1;
// pixel clock divider ( x 1/2 = 12.5MHz)
reg pclk=0;
always @(posedge clk) pclk<=~pclk;

// CPU clock divider ( x 1/7 = 3.57MHz)
reg [2:0]ckcnt=0;
always @(posedge clk) ckcnt <= ckcnt[2]&ckcnt[1] ? 0 : ckcnt+1;
wire ckr=ckcnt[2];

wire cclk= ckr | waitrom;

//////////////////////////// Video //////////////////////////////

wire vi,vr,vg,vb,fs;
vz6847 video0 ( .clk(pclk), .clkw(cclk),
			.we(ramvsel & we), .di(cdo), .aw(ca[10:0]),
			.gr(ls174[3]), .css(ls174[4]),
			.hsyn(hsyn), .vsyn(vsyn), .irgb({vi,vr,vg,vb}), .fs(fs) );
wire [3:0]R={vr,vi,vr,vr};
wire [3:0]G={vg,vi,vg,vg};
wire [3:0]B={vb,vi,vb,vb};

assign video={R,G,B};

/////////////////////////////// Z80 CPU ////////////////////////////////
wire reset_n,wait_n,int_n,nmi_n,busrq_n,cen;
wire m1_n,mreq_n,iorq_n,rd_n,wr_n,rfsh_n,halt_n,busak_n;
wire [7:0]cdi;	// CPU Data bus, Input
wire [7:0]cdo;	// CPU Data bus, Output
wire [15:0]ca;	// CPU Address bus

assign reset_n=~(reset | resetk);
// always inactive signals
assign wait_n=1'b1;
assign nmi_n=1'b1;
assign busrq_n=1'b1;
assign int_n=fs;
// always active signals
assign cen=1'b1;		// Clock enable

tv80s Z80CPU(
  // Outputs
  m1_n, mreq_n, iorq_n, rd_n, wr_n, rfsh_n, halt_n, busak_n, ca, cdo,
  // Inputs
  reset_n, cclk , wait_n, int_n, nmi_n, busrq_n, cdi, cen
  );

// some active high lines...
wire we = ~wr_n;
wire rd = ~rd_n;
wire mreq = ~mreq_n;

/////// Memory space decoding

wire romsel = mreq & (ca[15:14]==2'b00);
wire iosel  = mreq & (ca[15:11]==5'b0110_1); // $6800
wire ramvsel= mreq & (ca[15:11]==5'b0111_0); // $7000 (video)
wire ram1sel= mreq & (ca[15:11]==5'b0111_1); // $7800
wire ram2sel= mreq & (ca[15:13]==3'b100); 	 // $8000 (8KB more RAM)

// RAM
wire [7:0]ramvo;	// Video memory
SRAM #(.AW(11)) ramv( .clk(cclk), .we(ramvsel & we), .d(cdo), .q(ramvo), .a(ca[10:0]) );
wire [7:0]ram1o;	// Main 2KB memory for Laser 100 and Laser 200
SRAM #(.AW(11)) ram1( .clk(cclk), .we(ram1sel & we), .d(cdo), .q(ram1o), .a(ca[10:0]) );
wire [7:0]ram2o;	// Extra memory (Laser 110, Laser 210, ...)
SRAM #(.AW(13)) ram2( .clk(cclk), .we(ram2sel & we), .d(cdo), .q(ram2o), .a(ca[12:0]) );

// Output Register (video control + sound + cassette output)
reg [5:0]ls174=6'b111111;
always @(posedge cclk) if (iosel & we) ls174 <= cdo[5:0];
	// Cassette (2 bits, 3 levels. But only 2 levels actually used)
wire casso = ls174[2];	// Bits 1 & 2 have the same waveform 
	// sound 3-level: Low, fast_square_wave, high
		//assign sound=ls174[0];
reg [4:0]snddiv=0;	// ckr / 32 = 111.6kHz
reg sound;
always @(posedge ckr) begin
	snddiv<=snddiv+1;
	sound<=(ls174[0]==ls174[5])? snddiv[4] : ls174[0];
end
// Input Register (keyboard + cassette input + Frame sync)
wire [7:0]ls244;
assign ls244[7]=fs;		// Vertical retrace (frame sync)
assign ls244[6]=cassi;	// Cassette input
// Keyboard emulation
wire resetk,resetk2;	// reset keys pressed
keybps2 keyb0(	.clk(cclk), .kclk(kclk), .kdat(kdat), 
				.a(ca[7:0]), .row(ls244[5:0]), .resetk(resetk), .resetk2(resetk2) );

// Cached ROM (at flash address 0x0B0000)
wire [15:0]rom16;	// This emulated ROM is 16-bit wide 
wire wai;			// Stop CPU while reading flash
reg wair=0;			// stop a whole CPU clock cycle
always @(negedge clk) if (ckr) wair<=wai;
wire waitrom=wai|wair;
	
flashcache spirom ( .clk(clk), .flush(reset),
					.addr({8'h0B,2'b00,ca[13:0]}),
					.do(rom16),
					.strobe(romsel&rd), 
					.sck(sck), .sdo(mosi), .sdi(miso), .csn(ss1),
					.wai(wai)
);
wire [7:0]romo= ca[0] ? rom16[15:8] : rom16[7:0];

// CPU input data bus
assign cdi =(romsel  ? romo  : 8'hff) &
			(iosel   ? ls244 : 8'hff) &
			(ramvsel ? ramvo : 8'hff) &
			(ram1sel ? ram1o : 8'hff) &
			(ram2sel ? ram2o : 8'hff) ; 

////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
// Cassette emulator with BAC CPU
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////

wire [7:0]bacdo;
wire [7:0]bacaddr;
wire bacout,bacin;

bac_computer 
`ifdef SIM
	#(.ROMFILE("BACROM.hex"))
`else
	#(.ROMFILE("rand.hex"))
`endif
bac0 ( 
	.clk(ckr), .reset(reset|resetk2), .din(bacdi), .dout(bacdo),
	.out(bacout), .addr(bacaddr), .in(bacin)
);

// BAC's input bus multiplexer (for IN instructions)
wire [7:0]bacindata[0:3];
assign bacindata[0]=uartq;
assign bacindata[1]={capflg,cassi,casso,1'b0 ,rxoverr,rxframeer,txrdy,rxvalid};
assign bacindata[2]=cclkcnt[14:7];
assign bacindata[3]=capture;

wire [7:0]bacdi = bacindata[bacaddr[1:0]];

//----------- BAC's peripherals -----------
wire [7:0]uartq;
wire txrdy,rxvalid,rxoverr,rxframeer;

UART_core #(.DIVIDER(31)) uartbac0( 
	.clk(ckr), .d(bacdo), .wr(bacout & (bacaddr[1:0]==0)),
	.rd(bacin & (bacaddr[1:0]==0)), .q(uartq), .txrdy(txrdy),
	.rxvalid(rxvalid), .rxoverr(rxoverr), .rxframeer(rxframeer),
	.nstop(1'b0), .rxd(rxd), .txd(txd)
);

// CCLK counter (counts Z80 cycles)
reg [14:0]cclkcnt=0;
always @(posedge cclk) cclkcnt<=cclkcnt+1;
// Capture on rising "casso" edges
reg ocasso=0;		// Last value for edge detection
reg capflg=0;		// Capture flag (set on ris. edges, clear on capture reads)
reg [7:0]capture;	// Capture register
wire capevent=casso & (~ocasso);	// rising edge
reg emcas=0; 		// Emulated cassette output
assign cassi=emcas;
reg [7:0]gpo;		// LEDs for debug
assign debug=gpo;

always @(posedge ckr) begin
	ocasso<=casso;
	capflg<= capevent ? 1: (bacin & (bacaddr[1:0]==2'b11)? 0 : capflg);
	if (capevent) capture<=cclkcnt[14:7];
	if (bacout & (bacaddr[1:0]==2'b01)) emcas<=bacdo[6];
	if (bacout & (bacaddr[1:0]==2'b10)) gpo<=bacdo;
end
  
endmodule

////////////////////////////////////////////////////////////////
// SRAM modules 

module SRAM(
	input clk,
	input we,
	input [7:0]d,
	input [AW-1:0]a,
	output reg [7:0]q
);

parameter AW=11;

reg [7:0]mem[0:(1<<AW)-1];

always @(negedge clk) q<=mem[a];
always @(posedge clk) if (we) mem[a]<=d;

endmodule

