#include <stdlib.h>
#include <stdio.h>

#define NDAT (256)

unsigned short mem[NDAT];

main(int argc, char **argv)
{
	int i,dir,dato;
	char buf[256];
	FILE *fp;
	
	if ((fp=fopen(argv[1],"r"))==NULL) exit(1);
	dir=0;
	while(1){
		fgets(buf,256, fp);
		if (feof(fp)) break;
		//printf("%s",buf);
		if (buf[0]=='@') {
			dir = strtoul(&buf[1],NULL,16);
			printf("dir=0x%04X\n",dir);
		} else {
			dato=strtoul(buf,NULL,16);
			mem[dir++]=dato;
		}
	}
	fclose(fp);
	if ((fp=fopen(argv[2],"w"))==NULL) exit(1);
	for (dir=0;dir<NDAT;dir++) {
		fprintf(fp,"%04X\n",mem[dir]);
	}
	fclose(fp);

}
