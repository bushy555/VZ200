;------------------------ BAC03 code -----------------------
;
;    Vtech Laser 200 cassette emulator  J. Arias (2025)
;
; TX: generates the cassette waveforms from .CAS files dumped over
;     the serial port with XON/XOFF flow control
;   Modulation:
;     Ones: 3 square cycles with period around 600us
;     Zeroes: one 600us cycle plus one 1200us cycle
;     A gap about the time of 4 bits (7.2ms) is required between the
;     filename header and the data.
;
; RX: measures the cycle lengths, decodes the bits, and generates
;     a data dump (.CAS file format)
;
; Automatic switch from RX to TX
;

; I/O addresses

UARTDAT=	0
FLAGS=		1
TIMER=		2
CAPTURE=	3
GPO=		2

; Flags
RXVAL=		1
TXRDY=		2
CASIN=		0x20
CASSOUT=	0x40
CAPF=		0x80

; Variables
ra1=	0	; return address: 1st level routines (no stack here ;)
ra2=	1	;   2nd level
ra3=	2	;   3rd level 
ra4=	3	;   4rd level
var1=	4	; general usage: parameters, results, local vars...
var2=	5
var3=	6
var4=	7
var5=	8
tim0=	9	; previous time value 
sdata=	10	; shift register for data
rdix=	11	; serial input FIFO: read pointer
wrix=	12	; serial input FIFO: write pointer
fxoff=	13	; XOFF flag: active after sending XOFF, cleared after XON
fgap=	14	; if zero, and data==0, insert a gap (after the filename terminator) 

; code
		org 0
		ldpg	1			; serial buffer page for indexed addressing [x]
		
bm0:	lda		0x18
		out		[GPO]	
		in		[CAPTURE]	; clear flag
bm1:	in		[FLAGS]
		jmi		rx0			; Capture active => save to cassette
		tst		1
		jz		bm1

; cassette TX (CLOAD)
;  half fill the buffer before start
tx0:
		lda		0xff		; flush TX FIFO
		sta		[wrix]
		sta		[rdix]
		lda		0
		sta		[fgap]		; initial gap flag 
		sta		[fxoff]		; initial xoff flag
		lda		1
		sta		[var1]		; minimum delay
		out		[GPO]		; signal TX, waiting more data
tx1:	lda		.+2			; get first data (128 bytes) 
		jmp		delz80
		in		[FLAGS]		; if edges on cassette switch to RX
		jmi		rx0
		lda		[fxoff]		; fill until XOFF
		jz		tx1
		lda		3
		out		[GPO]		; signal start
; Now, start TX
tx2:	incx	[rdix]
		lda		[x]
		sta		[sdata]
		lda		.+2
		jmp		putbyte
		ldx		[rdix]	
		lda		[x]			; 0x00 means insert gap
		jnz		tx3
		lda		[fgap]		; but only for first 0x00
		jnz		tx3
		inc		[fgap]
		lda		7
		out		[GPO]		; signal end of header
		lda		192			; 4 bit time (4 x 6 x 8) 
		sta		[var1]
		lda		.+2
		jmp		delz80	
tx3:	lda		[rdix]
		suba	[wrix]
		jz		bm0			; end of data
		adda	256-64
		jc		tx2			; less than 64 bytes in buffer
		lda		[fxoff]		; ... and XOFF was sent
		jz		tx2
		lda		17			; send XON
		out		[UARTDAT]
		lda		0			; and clear "XOFF sent" flag
		sta		[fxoff]
		jmp		tx2

; cassette RX (CSAVE)

rx0:	lda		[CAPTURE]	; save current time stamp
		sta		[tim0]
		lda		0xc0
		out		[GPO]		; signal RX
		lda		.+2			; read bits until we get 0x80
		jmp		bitsync
		out		[UARTDAT]
rx1:	lda		.+2			; and keep receiving bytes...
		jmp		getbyte
		jmpd	rx1
		out		[UARTDAT]



;-----------------------------------------------------
;-------------------- ROUTINES -----------------------
; [var1] -> UART
putch:	sta		[ra1]
pc1:	in		[FLAGS]
		tst		TXRDY
		jz		pc1
		lda		[var1]
		jmpd	[ra1]
		out		[UARTDAT]
		
; delay: [var1]*128 Z80 cycles. Also reads incoming serial data
delz80:	sta		[ra1]
		lda		[var1]
		addm	[tim0]
dlz1:	in		[FLAGS]
		tst		1
		jz		dlz2
		in		[UARTDAT]
		incx	[wrix]
		sta		[x]
		lda		[rdix]
		suba	[wrix]
		jpl		dlz2		; if >128 bytes inside FIFO...
		lda		[fxoff]		; ...and xoff flag still deasserted
		jnz		dlz2
		lda		19
		sta		[fxoff]		; set flag
		out		[UARTDAT]	; and send XOFF
		
dlz2:	in		[TIMER]
		cmp		[tim0]		
		jz		[ra1]		; TIMER==tim0 (return)
		jmp		dlz1

; modulates the byte in [sdata]
putbyte:
		sta		[ra2]		; second level
		lda		8
		sta		[var3]		; bit counter

pb0:	lda		6			; number of semicycles (2 x pulses)
		sta		[var2]		
		lda		8			; 8 cycles = short pulse
		sta		[var1]
		out		[FLAGS]		; start as low
pb1:		
		in		[FLAGS]		; toggle cassete bit
		xora	CASSOUT
		out		[FLAGS]
		lda		.+2			; delay, (units: x 128 Z80 cycles)
		jmp		delz80
		deca	[var2]
		jz		pb2
		cmp		4
		jnz		pb1
		
		lda		[sdata]		; shift bit to carry
		addm	[sdata]
		jc		pb1			; 1: keep sending short pulses
		lda		16			; 0: single long pulse
		sta		[var1]
		lda		2			; only 2 semicycles until ending
		jmpd	pb1
		sta		[var2]

pb2:	dec		[var3]		; next bit
		jnz		pb0
		jmp		[ra2]


; get the cycle length in Acc
getlen:	sta		[ra1]
gln1:	in		[FLAGS]
		jmi		gln2		; cassette edge: measure
		tst		1			; serial data: Abort RX
		jnz		bm0
		jmp		gln1
gln2:	in		[CAPTURE]
		suba	[tim0]		; time diference
		suba	0			; change sign
		jmpd	[ra1]
		addm	[tim0]		; update the time of last edge

; demodulate a bit. Get value in Carry

getbit:	sta		[ra2]
		lda		3			; pulse counter
		sta		[var1]
gb1:	lda		.+2			; measure cycle length
		jmp		getlen
		adda	256-24		; short or long?
		jnc		gb2
		jmpd	[ra2]		; long cycle: clear carry & return
		adda	0
gb2:	dec		[var1]		; short cycle: keep counting
		jnz		gb1
		lda		0xff
		jmpd	[ra2]
		adda	1			; set carry

; Bit-Sync: waits until a 0x80 is shifted in (returns 0x80 in Acc)
bitsync:
		sta		[ra3]
		lda		0
		sta		[sdata]
bs1:	lda		.+2
		jmp		getbit
		lda		[sdata]
		adcm	[sdata]
		lda		0x80
		cmp		[sdata]
		jnz		bs1
		jmp		[ra3]
		
; get byte in [sdata] and Acc
getbyte:
		sta		[ra3]
		lda		8
		sta		[var2]
gby1:	lda		.+2
		jmp		getbit
		lda		[sdata]
		adcm	[sdata]
		dec		[var2]
		jnz		gby1
		jmpd	[ra3]
		lda		[sdata]

