///////////////////////////////////////////////////////
// Vtech Laser computer recreated
//  by Jesus Arias (2025)
//
//-------------------------------------------------------------------
//-- Test Bench
//-------------------------------------------------------------------
`include "system.v"

module tb();	// TOP module for simulations

//-- Input stimula
reg clk;
reg rxd;
reg reset;

wire sck,miso,mosi,fssb;
//
SYSTEM sys( .clk(clk), .reset(reset), .sck(sck), .mosi(mosi), .miso(miso), .ss1(fssb) );

FLASHSPI flashmem (
	.sck(sck), .mosi(mosi), .miso(miso), .ssb(fssb)
);

// Clock cycle of 10 units (simulation time/10 = cycles)
always #5 clk=~clk;

initial begin
	//-- output file with waveforms
	$dumpfile("tb.vcd");
	$dumpvars(0, tb);

	clk=0;
	reset=1;
	#30 reset=0;
	//# 319 $display("FIN de la simulacion");
	# 150000 $finish;
end

endmodule

/////////////////////////////////////////////////////////////////////////////////////////////////////////

module FLASHSPI(
	input sck,
	input mosi,
	output miso,
	input ssb
);

reg [10:0]cnt=0;
always @(posedge sck or posedge ssb) if (ssb) cnt<=0; else cnt<=cnt+1;

reg [23:0]sh;
always @(posedge sck) sh<={sh[22:0],mosi};
reg [7:0]cmd;
reg[23:0]addr;
always @(posedge sck or posedge ssb) if (ssb) cmd<=0; else if (cnt==8) cmd<=sh[7:0];

always @(negedge sck or posedge ssb)
  if (ssb) addr<=0; else 
	if ((cmd==3)&(cnt==32)) addr<=sh; else
	if ((cnt>31) & (bit==0) & (cmd==3)) begin
		addr<=addr+1;
	end
reg [2:0]bit;
always @(negedge sck) bit<=~cnt[2:0];
wire [7:0]do=mem[addr];
assign miso=do[bit];

reg [7:0]mem[0:(1<<20)-1];
//integer i;
//initial begin
//	for (i=0;i<(1<<20); i=i+1) mem[i]=i;
//end
initial begin
  $readmemh("FlashROM.hex", mem);
end

endmodule


