; Stripper 117.    22/11/2022
;
; VZ SD Loader .DAT file image reverser. 
; Starting off with reverse images for RED pixels.
; 22/11/2022
; 23/11/2022
;
;
;
;
; *** TO DO: clean up last bit of OR'ing for all six routines.
;
;
;
;
;

        IDEAL
        MODEL   small
        STACK   256
cr      	EQU     13              ; ASCII carriage return
lf      	EQU     10              ; ASCII line feed

        DATASEG
exCode          DB      0
inFile          DW      0       ; Input file handle
outFile         DW      0       ; Output file handle
oneByte         DB      0       
nibble1         DB      0       
nibble2         DB      0       
nibble3         DB      0       
nibble4         DB      0       
diskFull        DB      cr,lf,'**ERROR: Disk is full', 0
crlf		db	cr,lf,0
notes   	DB      cr,lf,'Stripper117  /djm,  23/11/22', cr,lf
        	DB      cr,lf,'Stripper117  <in-file>  <out-file> <selection-number>',cr,lf,cr,lf
		db	' VZ COLOUR TRANSFER.  For use with video DAT files for VZ SD Loader.'
		db	cr,lf,cr,lf
		db	' Call this a VZ MODE(1) colour manipulator. Has the ability to change any of',cr,lf
		db	' the four colours to any of the other three colours, within either',cr,lf
		db	' standalone image, or, a video .DAT file such as for the SD Loader.'
		db	cr,lf,cr,lf
		db	cr,lf, 'PRESS <ANY> key to contine.',0

notes2		db	cr,lf,cr,lf
		db	'   <selection parameter>',cr,lf
		db	'	01	GREEN --> YELLOW.	YELLOW --> GREEN'  ,cr,lf
		db	'	02	GREEN --> BLUE.		BLUE   --> GREEN.' ,cr,lf
		db	'	03	GREEN --> RED.		RED    --> GREEN.' ,cr,lf
		db	'	04	YELLOW--> GREEN.	GREEN  --> YELLOW.',cr,lf
		db	'	05	YELLOW--> BLUE.		BLUE   --> YELLOW.',cr,lf
		db	'	06	YELLOW--> RED.		RED    --> YELLOW.',cr,lf
		db	'	07	BLUE  --> GREEN.	GREEN  --> BLUE.'  ,cr,lf
		db	'	08	BLUE  --> YELLOW.	YELLOW --> BLUE.'  ,cr,lf
		db	'	09	BLUE  --> RED.		RED    --> BLUE.'  ,cr,lf
		db	'	10	RED   --> GREEN.	GREEN  --> RED.'   ,cr,lf
		db	'	11	RED   --> YELLOW.	YELLOW --> RED.'   ,cr,lf
		db	'	12	RED   --> BLUE.		BLUE   --> RED.'   ,cr,lf
		db	'	13	ALL GREEN --> YELLOW ONLY.' ,cr,lf
		db	'	14	ALL GREEN --> BLUE ONLY.'   ,cr,lf
		db	'	15	ALL GREEN --> RED ONLY.'    ,cr,lf
		db	'	16	ALL YELLOW--> GREEN ONLY. ' ,cr,lf
		db	'	17	ALL YELLOW--> BLUE ONLY.'   ,cr,lf
		db	'	18	ALL YELLOW--> RED ONLY.'    ,cr,lf
		db	'	19	ALL BLUE  --> GREEN ONLY.'  ,cr,lf
		db	'	20	ALL BLUE  --> YELLOW ONLY.' ,cr,lf
		db	'	21	ALL BLUE  --> RED ONLY.'    ,cr,lf
		db	'	22	ALL RED   --> GREEN ONLY.'  ,cr,lf
		db	'	23	ALL RED   --> YELLOW ONLY.' ,cr,lf
		db	'	24	ALL RED   --> BLUE ONLY.'
        	DB      0

display01	db	'Colour change : GREEN -->YELLOW.  YELLOW-->GREEN.' ,cr,lf,0
display02	db	'Colour change : GREEN -->BLUE.    BLUE  -->GREEN.' ,cr,lf,0
display03	db	'Colour change : GREEN -->RED.     RED   -->GREEN.' ,cr,lf,0
display04	db	'Colour change : YELLOW-->BLUE.    BLUE  -->YELLOW.',cr,lf,0
display05	db	'Colour change : YELLOW-->RED.     RED   -->YELLOW.',cr,lf,0
display06	db	'Colour change : BLUE  -->RED.     RED   -->BLUE.'  ,cr,lf,0

display13	db	'colour change : ALL GREEN --> YELLOW ONLY.',cr,lf,0
display14	db	'colour change : ALL GREEN --> BLUE ONLY.'  ,cr,lf,0
display15	db	'colour change : ALL GREEN --> RED ONLY.'   ,cr,lf,0
display16	db	'colour change : ALL YELLOW--> GREEN ONLY.' ,cr,lf,0
display17	db	'colour change : ALL YELLOW--> BLUE ONLY.'  ,cr,lf,0
display18	db	'colour change : ALL YELLOW--> RED ONLY.'   ,cr,lf,0
display19	db	'colour change : ALL BLUE  --> GREEN ONLY.' ,cr,lf,0
display20	db	'colour change : ALL BLUE  --> YELLOW ONLY.',cr,lf,0
display21	db	'colour change : ALL BLUE  --> RED ONLY.'   ,cr,lf,0
display22	db	'colour change : ALL RED   --> GREEN ONLY.' ,cr,lf,0
display23	db	'colour change : ALL RED   --> YELLOW ONLY.',cr,lf,0
display24	db	'colour change : ALL RED   --> BLUE ONLY.'  ,cr,lf,0



        CODESEG
        EXTRN StrLength:proc, StrUpper:proc
        EXTRN StrWrite:Proc, NewLine:Proc				;-----  From STRIO.OBJ
        EXTRN DiskErr:Proc						;-----  From DISKERR.OBJ
        EXTRN GetParams:Proc, ParamCount:Proc, GetOneParam:Proc		;-----  From PARAMS.OBJ
Start:  				;-----  Initialize and display notes if no parameters entered
        mov     ax, @data               ; Set ax to data segment
        mov     es, ax                  ; Set es to data segment
        call    GetParams               ; Get parameters with ds = PSP
        call    ParamCount              ; Get number of parameters (dx)
        cmp     dx, 3                   ; Does count = 3?
        je      @@01                    ; Continue if param count = 3
        mov     di, offset notes        ; Address text with di
        call    StrWrite                ; Display notes
	xor	ah, ah
	mov	ax, ax			; press any key to continue.
	int	16h	
        mov     di, offset notes2       ; Address text with di
        call    StrWrite                ; Display notes
        jmp     Exit                    ; Exit program  -  Attempt to open the input file
@@01:   xor     cx, cx                  ; Specify parameter number 0
        call    GetOneParam             ; Get address of parameter string
        mov     dx, di                  ; Address file name with ds:dx
        xor     al, al                  ; Specify read-only access
        mov     ah, 3Dh                 ; DOS Open-file function
        int     21h                     ; Open the input file
        jnc     @@02                    ; Continue if no error
        jmp     Errors                  ; Else jump to error handler  -  Check whether the output file already exists
@@02:   mov     [inFile], ax            ; Save input file handle  -  Attempt to create the output file
@@03:   mov     cx, 1                   ; Specify parameter number 1
        call    GetOneParam             ; Get address of parameter string
        mov     dx, di                  ; Address file name with ds:dx
        xor     cx, cx                  ; Specify normal attributes
        mov     ah, 3Ch                 ; DOS Create-file function
        int     21h                     ; Create the output file
        jnc     @@04                    ; Continue if no error
        jmp     Errors                  ; Else jump to error handler
@@04:   mov     [outFile], ax           ; Save output file handle
	mov	cx, 2                   ; Specify parameter number 2
        call    GetOneParam             ; Get address of parameter string. Address filename  DS:DX


	xor	ax, ax
	xor	bx, bx
	xor	cx, cx
	xor	dx, dx
	mov	bh, [di]
	inc	di
	mov	bl, [di]
	cmp	bl, 0
	je	@@42
	cmp	bl, 20
	je	@@42
	mov	cl, bh
	xor	cl, 30h
	mov	al, 10
	mul	cx
	xor	cx, cx
	mov	cl, al
	xor	bl, 30h
	add	cl, bl
	jmp	@@43
@@42:	xor	bh, 30h
	mov	cl, bh
@@43:	mov	ch, 0
	mov	al, cl



	cmp	al, 01
	je	@@_JMP_08
	cmp	al, 02
	je	@@_JMP_09
	cmp	al, 03
	je	@@_JMP_10
	cmp	al, 04
	je	@@_JMP_08
	cmp	al, 05
	je	@@_JMP_15
	cmp	al, 06
	je	@@_JMP_20
	cmp	al, 07
	je	@@_JMP_09
	cmp	al, 08
	je	@@_JMP_15
	cmp	al, 09
	je	@@_JMP_25
	cmp	al, 10
	je	@@_JMP_10
	cmp	al, 11
	je	@@_JMP_20
	cmp	al, 12
	je	@@_JMP_25
	cmp	al, 13
	je	@@_JMP_30
	cmp	al, 14
	je	@@_JMP_31
	cmp	al, 15
	je	@@_JMP_32
	cmp	al, 16
	je	@@_JMP_33
	cmp	al, 17
	je	@@_JMP_34
	cmp	al, 18
	je	@@_JMP_35
	cmp	al, 19
	je	@@_JMP_36
	cmp	al, 20
	je	@@_JMP_37
	cmp	al, 21
	je	@@_JMP_38
	cmp	al, 22
	je	@@_JMP_39
	cmp	al, 23
	je	@@_JMP_40
	cmp	al, 24
	je	@@_JMP_41






	jmp	@@80			; ERROR and exit if parameter 4 is not correct


@@_JMP_08:	jmp	@@_08			; JUMP TABLE. (128 byte limit on local jumps)
@@_JMP_09:	jmp	@@_09
@@_JMP_10:	jmp	@@_10
@@_JMP_15:	jmp	@@_15
@@_JMP_20:	jmp	@@_20
@@_JMP_25:	jmp	@@_25
@@_JMP_30:	jmp	@@_30
@@_JMP_31:	jmp	@@_31
@@_JMP_32:	jmp	@@_32
@@_JMP_33:	jmp	@@_33
@@_JMP_34:	jmp	@@_34
@@_JMP_35:	jmp	@@_35
@@_JMP_36:	jmp	@@_36
@@_JMP_37:	jmp	@@_37
@@_JMP_38:	jmp	@@_38
@@_JMP_39:	jmp	@@_39
@@_JMP_40:	jmp	@@_40
@@_JMP_41:	jmp	@@_41




;  @@_08	01	GREEN --> YELLOW.	YELLOW --> GREEN.
;  @@_09	02	GREEN --> BLUE.		BLUE   --> GREEN.
;  @@_10	03	GREEN --> RED.		RED    --> GREEN.
;  @@_15	04	YELLOW--> BLUE.		BLUE   --> YELLOW.
;  @@_20	05	YELLOW--> RED.		RED    --> YELLOW.
;  @@_25	06	BLUE  --> RED.		RED    --> BLUE.
;
;
;	01	GREEN --> YELLOW.	YELLOW --> GREEN.	1	@@_08
;	02	GREEN --> BLUE.		BLUE   --> GREEN.	2	@@_09
;	03	GREEN --> RED.		RED    --> GREEN.	3	@@_10
;	04	YELLOW--> GREEN.	GREEN  --> YELLOW.  	1	@@_08
;	05	YELLOW--> BLUE.		BLUE   --> YELLOW.	4	@@_15
;	06	YELLOW--> RED.		RED    --> YELLOW.	5	@@_20	
;	07	BLUE  --> GREEN.	GREEN  --> BLUE.	2	@@_09
;	08	BLUE  --> YELLOW.	YELLOW --> BLUE.	4	@@_15
;	09	BLUE  --> RED.		RED    --> BLUE.	6	@@_25
;	10	RED   --> GREEN.	GREEN  --> RED.		3	@@_10
;	11	RED   --> YELLOW.	YELLOW --> RED.		5	@@_20
;	12	RED   --> BLUE.		BLUE   --> RED.		6	@@_25
;	13	ALL GREEN --> YELLOW ONLY.',cr,lf
;	14	ALL GREEN --> BLUE ONLY.',cr,lf
;	15	ALL GREEN --> RED ONLY.',cr,lf
;	16	ALL YELLOW--> GREEN ONLY. ',cr,lf
;	17	ALL YELLOW--> BLUE ONLY.',cr,lf
;	18	ALL YELLOW--> RED ONLY.',cr,lf
;	19	ALL BLUE  --> GREEN ONLY.',cr,lf
;	20	ALL BLUE  --> YELLOW ONLY.',cr,lf
;	21	ALL BLUE  --> RED ONLY.	',cr,lf
;	22	ALL RED   --> GREEN ONLY.',cr,lf
;	23	ALL RED   --> YELLOW.',cr,lf
;	24	ALL RED   --> BLUE.',cr,lf



	
;-----------------------------------------------------
; @@_08. (01)	GREEN --> YELLOW.	YELLOW --> GREEN.
;-----------------------------------------------------

@@_08:	mov     di, offset display01
        call    StrWrite     

@@_080:	call	readbyte		
	mov	[onebyte], al		; NIBBLE ONE
	and 	al, 11000000b		; get first nibble
	cmp	al, 01000000b		; is red?, then jump to make it green. Goto next nibble.
	je	@@_081a
	cmp	al, 00000000b		; is green? then jump to make it red. Goto next nibble.
	je	@@_081b
	jmp	@@_081c
@@_081a:mov	al, 00000000b		; was red, now green. Store, Go to next nibble.
	je	@@_081c
@@_081b:mov	al, 01000000b		; was green, is now red.  Store. Go to next nibble.
@@_081c:mov	[nibble1], al

	mov	al, [onebyte]		; NIBBLE TWO
	and 	al, 00110000b		; get second nibble
	cmp	al, 00010000b		; is red?, then jump to make it green. Goto next nibble.
	je	@@_082a
	cmp	al, 00000000b		; is green? then jump to make it red. Goto next nibble.
	je	@@_082b
	jmp	@@_082c
@@_082a:mov	al, 00000000b		; was red, now green. Store, Go to next nibble.
	je	@@_082c
@@_082b:mov	al, 00010000b		; was green, is now red.  Store. Go to next nibble.
@@_082c:mov	[nibble2], al

	mov	al, [onebyte]		; NIBBLE THREE
	and 	al, 00001100b		; get third nibble
	cmp	al, 00000100b		; is red?, then jump to make it green. Goto next nibble.
	je	@@_083a
	cmp	al, 00000000b		; is green? then jump to make it red. Goto next nibble.
	je	@@_083b
	jmp	@@_083c
@@_083a:mov	al, 00000000b		; was red, now green. Store, Go to next nibble.
	je	@@_083c
@@_083b:mov	al, 00000100b		; was green, is now red.  Store. Go to next nibble.
@@_083c:mov	[nibble3], al

	mov	al, [onebyte]		; NIBBLE FOUR
	and 	al, 00000011b		; get third nibble
	cmp	al, 00000001b		; is red?, then jump to make it green. Goto next nibble.
	je	@@_084a
	cmp	al, 00000000b		; is green? then jump to make it red. Goto next nibble.
	je	@@_084b
	jmp	@@_084c
@@_084a:mov	al, 00000000b		; was red, now green. Store, Go to next nibble.
	je	@@_084c
@@_084b:mov	al, 00000001b		; was green, is now red.  Store. Go to next nibble.
@@_084c:
;mov	[nibble4], al
;	mov	cl, al
;	mov	al, [nibble3]
;	or	al, cl
;	mov	cl, al
;	mov	al, [nibble2]
;	or	al, cl
;	mov	cl, al
;	mov	al, [nibble1]
;	or	al, cl
	




	or	al, [nibble3]
	or	al, [nibble2]
	or	al, [nibble1]
















	call	writebyte
	jmp	@@_080





;-----------------------------------------------------
; @@_09. (02)	GREEN --> BLUE.		BLUE   --> GREEN.
;-----------------------------------------------------

@@_09:	mov     di, offset display02
        call    StrWrite     

@@_090:	call	readbyte		
	mov	[onebyte], al		; NIBBLE ONE
	and 	al, 11000000b		; get first nibble
	cmp	al, 10000000b		; is red?, then jump to make it green. Goto next nibble.
	je	@@_091a
	cmp	al, 00000000b		; is green? then jump to make it red. Goto next nibble.
	je	@@_091b
	jmp	@@_091c
@@_091a:mov	al, 00000000b		; was red, now green. Store, Go to next nibble.
	je	@@_091c
@@_091b:mov	al, 10000000b		; was green, is now red.  Store. Go to next nibble.
@@_091c:mov	[nibble1], al

	mov	al, [onebyte]		; NIBBLE TWO
	and 	al, 00110000b		; get second nibble
	cmp	al, 00100000b		; is red?, then jump to make it green. Goto next nibble.
	je	@@_092a
	cmp	al, 00000000b		; is green? then jump to make it red. Goto next nibble.
	je	@@_092b
	jmp	@@_092c
@@_092a:mov	al, 00000000b		; was red, now green. Store, Go to next nibble.
	je	@@_092c
@@_092b:mov	al, 00100000b		; was green, is now red.  Store. Go to next nibble.
@@_092c:mov	[nibble2], al

	mov	al, [onebyte]		; NIBBLE THREE
	and 	al, 00001100b		; get third nibble
	cmp	al, 00001000b		; is red?, then jump to make it green. Goto next nibble.
	je	@@_093a
	cmp	al, 00000000b		; is green? then jump to make it red. Goto next nibble.
	je	@@_093b
	jmp	@@_093c
@@_093a:mov	al, 00000000b		; was red, now green. Store, Go to next nibble.
	je	@@_093c
@@_093b:mov	al, 00001000b		; was green, is now red.  Store. Go to next nibble.
@@_093c:mov	[nibble3], al

	mov	al, [onebyte]		; NIBBLE FOUR
	and 	al, 00000011b		; get third nibble
	cmp	al, 00000010b		; is red?, then jump to make it green. Goto next nibble.
	je	@@_094a
	cmp	al, 00000000b		; is green? then jump to make it red. Goto next nibble.
	je	@@_094b
	jmp	@@_094c
@@_094a:mov	al, 00000000b		; was red, now green. Store, Go to next nibble.
	je	@@_094c
@@_094b:mov	al, 00000010b		; was green, is now red.  Store. Go to next nibble.
@@_094c:mov	[nibble4], al

	mov	cl, al
	mov	al, [nibble3]
	or	al, cl
	mov	cl, al
	mov	al, [nibble2]
	or	al, cl
	mov	cl, al
	mov	al, [nibble1]
	or	al, cl
	
	call	writebyte
	jmp	@@_090






;-----------------------------------------------------
; @@_10 (03)	GREEN --> RED	RED --> GREEN.   
;-----------------------------------------------------
@@_10:	mov     di, offset display03
        call    StrWrite     

@@_100:	call	readbyte		
	mov	[onebyte], al		; NIBBLE ONE
	and 	al, 11000000b		; get first nibble
	cmp	al, 11000000b		; is red?, then jump to make it green. Goto next nibble.
	je	@@_10a
	cmp	al, 00000000b		; is green? then jump to make it red. Goto next nibble.
	je	@@_10b
	jmp	@@_10c
@@_10a:	mov	al, 00000000b		; was red, now green. Store, Go to next nibble.
	je	@@_10c
@@_10b:	mov	al, 11000000b		; was green, is now red.  Store. Go to next nibble.
@@_10c: mov	[nibble1], al

	mov	al, [onebyte]		; NIBBLE TWO
	and 	al, 00110000b		; get second nibble
	cmp	al, 00110000b		; is red?, then jump to make it green. Goto next nibble.
	je	@@_11a
	cmp	al, 00000000b		; is green? then jump to make it red. Goto next nibble.
	je	@@_11b
	jmp	@@_11c
@@_11a:	mov	al, 00000000b		; was red, now green. Store, Go to next nibble.
	je	@@_11c
@@_11b:	mov	al, 00110000b		; was green, is now red.  Store. Go to next nibble.
@@_11c: mov	[nibble2], al

	mov	al, [onebyte]		; NIBBLE THREE
	and 	al, 00001100b		; get third nibble
	cmp	al, 00001100b		; is red?, then jump to make it green. Goto next nibble.
	je	@@_12a
	cmp	al, 00000000b		; is green? then jump to make it red. Goto next nibble.
	je	@@_12b
	jmp	@@_12c
@@_12a:	mov	al, 00000000b		; was red, now green. Store, Go to next nibble.
	je	@@_12c
@@_12b:	mov	al, 00001100b		; was green, is now red.  Store. Go to next nibble.
@@_12c: mov	[nibble3], al

	mov	al, [onebyte]		; NIBBLE FOUR
	and 	al, 00000011b		; get third nibble
	cmp	al, 00000011b		; is red?, then jump to make it green. Goto next nibble.
	je	@@_13a
	cmp	al, 00000000b		; is green? then jump to make it red. Goto next nibble.
	je	@@_13b
	jmp	@@_13c
@@_13a:	mov	al, 00000000b		; was red, now green. Store, Go to next nibble.
	je	@@_13c
@@_13b:	mov	al, 00000011b		; was green, is now red.  Store. Go to next nibble.
@@_13c: mov	[nibble4], al

	mov	cl, al
	mov	al, [nibble3]
	or	al, cl
	mov	cl, al
	mov	al, [nibble2]
	or	al, cl
	mov	cl, al
	mov	al, [nibble1]
	or	al, cl
	
	call	writebyte
	jmp	@@_100





  
;-----------------------------------------------------
; @@_15	(04)	YELLOW--> BLUE.		BLUE   --> YELLOW.
;-----------------------------------------------------
@@_15:	mov     di, offset display04
        call    StrWrite     

@@_150:	call	readbyte		
	mov	[onebyte], al		; NIBBLE ONE
	and 	al, 11000000b		; get first nibble
	cmp	al, 10000000b		; is red?, then jump to make it green. Goto next nibble.
	je	@@_151a
	cmp	al, 01000000b		; is green? then jump to make it red. Goto next nibble.
	je	@@_151b
	jmp	@@_151c
@@_151a:mov	al, 01000000b		; was red, now green. Store, Go to next nibble.
	je	@@_151c
@@_151b:mov	al, 10000000b		; was green, is now red.  Store. Go to next nibble.
@@_151c:mov	[nibble1], al

	mov	al, [onebyte]		; NIBBLE TWO
	and 	al, 00110000b		; get second nibble
	cmp	al, 00100000b		; is red?, then jump to make it green. Goto next nibble.
	je	@@_152a
	cmp	al, 00010000b		; is green? then jump to make it red. Goto next nibble.
	je	@@_152b
	jmp	@@_152c
@@_152a:mov	al, 00010000b		; was red, now green. Store, Go to next nibble.
	je	@@_152c
@@_152b:mov	al, 00100000b		; was green, is now red.  Store. Go to next nibble.
@@_152c:mov	[nibble2], al

	mov	al, [onebyte]		; NIBBLE THREE
	and 	al, 00001100b		; get third nibble
	cmp	al, 00001000b		; is red?, then jump to make it green. Goto next nibble.
	je	@@_153a
	cmp	al, 00000100b		; is green? then jump to make it red. Goto next nibble.
	je	@@_153b
	jmp	@@_153c
@@_153a:mov	al, 00000100b		; was red, now green. Store, Go to next nibble.
	je	@@_153c
@@_153b:mov	al, 00001000b		; was green, is now red.  Store. Go to next nibble.
@@_153c:mov	[nibble3], al

	mov	al, [onebyte]		; NIBBLE FOUR
	and 	al, 00000011b		; get third nibble
	cmp	al, 00000010b		; is red?, then jump to make it green. Goto next nibble.
	je	@@_154a
	cmp	al, 00000001b		; is green? then jump to make it red. Goto next nibble.
	je	@@_154b
	jmp	@@_154c
@@_154a:mov	al, 00000001b		; was red, now green. Store, Go to next nibble.
	je	@@_154c
@@_154b:mov	al, 00000010b		; was green, is now red.  Store. Go to next nibble.
@@_154c:mov	[nibble4], al

	mov	cl, al
	mov	al, [nibble3]
	or	al, cl
	mov	cl, al
	mov	al, [nibble2]
	or	al, cl
	mov	cl, al
	mov	al, [nibble1]
	or	al, cl
	
	call	writebyte
	jmp	@@_150








  
;-----------------------------------------------------
; @@_20	(05)	YELLOW--> RED.		RED    --> YELLOW.
;-----------------------------------------------------
@@_20:	mov     di, offset display05
        call    StrWrite     

@@_200:	call	readbyte		
	mov	[onebyte], al		; NIBBLE ONE
	and 	al, 11000000b		; get first nibble
	cmp	al, 11000000b		; is red?, then jump to make it green. Goto next nibble.
	je	@@_201a
	cmp	al, 01000000b		; is green? then jump to make it red. Goto next nibble.
	je	@@_201b
	jmp	@@_201c
@@_201a:mov	al, 01000000b		; was red, now green. Store, Go to next nibble.
	je	@@_201c
@@_201b:mov	al, 11000000b		; was green, is now red.  Store. Go to next nibble.
@@_201c:mov	[nibble1], al

	mov	al, [onebyte]		; NIBBLE TWO
	and 	al, 00110000b		; get second nibble
	cmp	al, 00110000b		; is red?, then jump to make it green. Goto next nibble.
	je	@@_202a
	cmp	al, 00010000b		; is green? then jump to make it red. Goto next nibble.
	je	@@_202b
	jmp	@@_202c
@@_202a:mov	al, 00010000b		; was red, now green. Store, Go to next nibble.
	je	@@_202c
@@_202b:mov	al, 00110000b		; was green, is now red.  Store. Go to next nibble.
@@_202c:mov	[nibble2], al

	mov	al, [onebyte]		; NIBBLE THREE
	and 	al, 00001100b		; get third nibble
	cmp	al, 00001100b		; is red?, then jump to make it green. Goto next nibble.
	je	@@_203a
	cmp	al, 00000100b		; is green? then jump to make it red. Goto next nibble.
	je	@@_203b
	jmp	@@_203c
@@_203a:mov	al, 00000100b		; was red, now green. Store, Go to next nibble.
	je	@@_203c
@@_203b:mov	al, 00001100b		; was green, is now red.  Store. Go to next nibble.
@@_203c:mov	[nibble3], al

	mov	al, [onebyte]		; NIBBLE FOUR
	and 	al, 00000011b		; get third nibble
	cmp	al, 00000011b		; is red?, then jump to make it green. Goto next nibble.
	je	@@_204a
	cmp	al, 00000001b		; is green? then jump to make it red. Goto next nibble.
	je	@@_204b
	jmp	@@_204c
@@_204a:mov	al, 00000001b		; was red, now green. Store, Go to next nibble.
	je	@@_204c
@@_204b:mov	al, 00000011b		; was green, is now red.  Store. Go to next nibble.
@@_204c:mov	[nibble4], al

	mov	cl, al
	mov	al, [nibble3]
	or	al, cl
	mov	cl, al
	mov	al, [nibble2]
	or	al, cl
	mov	cl, al
	mov	al, [nibble1]
	or	al, cl
	
	call	writebyte
	jmp	@@_200







;-----------------------------------------------------
; @@_25. (06)	BLUE  --> RED.		RED    --> BLUE.
;-----------------------------------------------------
@@_25:	mov     di, offset display06
        call    StrWrite     

@@_250:	call	readbyte		
	mov	[onebyte], al		; NIBBLE ONE
	and 	al, 11000000b		; get first nibble
	cmp	al, 11000000b		; is red?, then jump to make it green. Goto next nibble.
	je	@@_251a
	cmp	al, 10000000b		; is green? then jump to make it red. Goto next nibble.
	je	@@_251b
	jmp	@@_251c
@@_251a:mov	al, 10000000b		; was red, now green. Store, Go to next nibble.
	je	@@_251c
@@_251b:mov	al, 11000000b		; was green, is now red.  Store. Go to next nibble.
@@_251c:mov	[nibble1], al

	mov	al, [onebyte]		; NIBBLE TWO
	and 	al, 00110000b		; get second nibble
	cmp	al, 00110000b		; is red?, then jump to make it green. Goto next nibble.
	je	@@_252a
	cmp	al, 00100000b		; is green? then jump to make it red. Goto next nibble.
	je	@@_252b
	jmp	@@_252c
@@_252a:mov	al, 00100000b		; was red, now green. Store, Go to next nibble.
	je	@@_252c
@@_252b:mov	al, 00110000b		; was green, is now red.  Store. Go to next nibble.
@@_252c:mov	[nibble2], al

	mov	al, [onebyte]		; NIBBLE THREE
	and 	al, 00001100b		; get third nibble
	cmp	al, 00001100b		; is red?, then jump to make it green. Goto next nibble.
	je	@@_253a
	cmp	al, 00001000b		; is green? then jump to make it red. Goto next nibble.
	je	@@_253b
	jmp	@@_253c
@@_253a:mov	al, 00001000b		; was red, now green. Store, Go to next nibble.
	je	@@_253c
@@_253b:mov	al, 00001100b		; was green, is now red.  Store. Go to next nibble.
@@_253c:mov	[nibble3], al

	mov	al, [onebyte]		; NIBBLE FOUR
	and 	al, 00000011b		; get third nibble
	cmp	al, 00000011b		; is red?, then jump to make it green. Goto next nibble.
	je	@@_254a
	cmp	al, 00000010b		; is green? then jump to make it red. Goto next nibble.
	je	@@_254b
	jmp	@@_254c
@@_254a:mov	al, 00000010b		; was red, now green. Store, Go to next nibble.
	je	@@_254c
@@_254b:mov	al, 00000011b		; was green, is now red.  Store. Go to next nibble.
@@_254c:mov	[nibble4], al

	mov	cl, al
	mov	al, [nibble3]
	or	al, cl
	mov	cl, al
	mov	al, [nibble2]
	or	al, cl
	mov	cl, al
	mov	al, [nibble1]
	or	al, cl
	
	call	writebyte
	jmp	@@_250







;-----------------------------------------------------
; @@_30. (13)	ALL GREEN --> YELLOW ONLY
;-----------------------------------------------------
@@_30:	mov     di, offset display13
        call    StrWrite     
@@_300:	call	readbyte		
	mov	[onebyte], al		; NIBBLE ONE
	and 	al, 11000000b		; get first nibble
	cmp	al, 00000000b		
	jne	@@_301
	mov	al, 01000000b		
@@_301:	mov	[nibble1], al
	mov	al, [onebyte]		; NIBBLE TWO
	and 	al, 00110000b		; get second nibble
	cmp	al, 00000000b		
	jne	@@_302
	mov	al, 00010000b		
@@_302:	mov	[nibble2], al
	mov	al, [onebyte]		; NIBBLE THREE
	and 	al, 00001100b		; get third nibble
	cmp	al, 00000000b		
	jne	@@_303
	mov	al, 00000100b		
@@_303:	mov	[nibble3], al
	mov	al, [onebyte]		; NIBBLE FOUR
	and 	al, 00000011b		; get fourth nibble
	cmp	al, 00000000b		
	jne	@@_304
	mov	al, 00000001b		
@@_304:	mov	[nibble4], al
	mov	cl, al
	mov	al, [nibble3]
	or	al, cl
	mov	cl, al
	mov	al, [nibble2]
	or	al, cl
	mov	cl, al
	mov	al, [nibble1]
	or	al, cl
	call	writebyte
	jmp	@@_300








;-----------------------------------------------------
; @@_31. (14)	ALL GREEN --> BLUE ONLY
;-----------------------------------------------------
@@_31:	mov     di, offset display14
        call    StrWrite     
@@_310:	call	readbyte		
	mov	[onebyte], al		; NIBBLE ONE
	and 	al, 11000000b		; get first nibble
	cmp	al, 00000000b		
	jne	@@_311
	mov	al, 10000000b		
@@_311:	mov	[nibble1], al
	mov	al, [onebyte]		; NIBBLE TWO
	and 	al, 00110000b		; get second nibble
	cmp	al, 00000000b		
	jne	@@_312
	mov	al, 00100000b		
@@_312:	mov	[nibble2], al
	mov	al, [onebyte]		; NIBBLE THREE
	and 	al, 00001100b		; get third nibble
	cmp	al, 00000000b		
	jne	@@_313
	mov	al, 00001000b		
@@_313:	mov	[nibble3], al
	mov	al, [onebyte]		; NIBBLE FOUR
	and 	al, 00000011b		; get fourth nibble
	cmp	al, 00000000b		
	jne	@@_314
	mov	al, 00000010b		
@@_314:	mov	[nibble4], al
	mov	cl, al
	mov	al, [nibble3]
	or	al, cl
	mov	cl, al
	mov	al, [nibble2]
	or	al, cl
	mov	cl, al
	mov	al, [nibble1]
	or	al, cl
	call	writebyte
	jmp	@@_310







;-----------------------------------------------------
; @@_32. (15)	ALL GREEN --> RED ONLY.
;-----------------------------------------------------
@@_32:	mov     di, offset display15
        call    StrWrite     

@@_320:	call	readbyte		
	mov	[onebyte], al		; NIBBLE ONE
	and 	al, 11000000b		; get first nibble
	cmp	al, 00000000b		
	jne	@@_321
	mov	al, 11000000b		
@@_321:	mov	[nibble1], al
	mov	al, [onebyte]		; NIBBLE TWO
	and 	al, 00110000b		; get second nibble
	cmp	al, 00000000b		
	jne	@@_322
	mov	al, 00110000b		
@@_322:	mov	[nibble2], al
	mov	al, [onebyte]		; NIBBLE THREE
	and 	al, 00001100b		; get third nibble
	cmp	al, 00000000b		
	jne	@@_323
	mov	al, 00001100b		
@@_323:	mov	[nibble3], al
	mov	al, [onebyte]		; NIBBLE FOUR
	and 	al, 00000011b		; get fourth nibble
	cmp	al, 00000000b		
	jne	@@_324
	mov	al, 00000011b		
@@_324:	mov	[nibble4], al
	mov	cl, al
	mov	al, [nibble3]
	or	al, cl
	mov	cl, al
	mov	al, [nibble2]
	or	al, cl
	mov	cl, al
	mov	al, [nibble1]
	or	al, cl
	call	writebyte
	jmp	@@_320

;-----------------------------------------------------
; @@_33. (16)	ALL YELLOW--> GREEN ONLY. 
;-----------------------------------------------------
@@_33:	mov     di, offset display16
        call    StrWrite     

@@_330:	call	readbyte		
	mov	[onebyte], al		; NIBBLE ONE
	and 	al, 11000000b		; get first nibble
	cmp	al, 01000000b		
	jne	@@_331
	mov	al, 00000000b		
@@_331:	mov	[nibble1], al
	mov	al, [onebyte]		; NIBBLE TWO
	and 	al, 00110000b		; get second nibble
	cmp	al, 00010000b		
	jne	@@_332
	mov	al, 00000000b		
@@_332:	mov	[nibble2], al
	mov	al, [onebyte]		; NIBBLE THREE
	and 	al, 00001100b		; get third nibble
	cmp	al, 00000100b		
	jne	@@_333
	mov	al, 00000000b		
@@_333:	mov	[nibble3], al
	mov	al, [onebyte]		; NIBBLE FOUR
	and 	al, 00000011b		; get fourth nibble
	cmp	al, 00000001b		
	jne	@@_334
	mov	al, 00000000b		
@@_334:	mov	[nibble4], al
	mov	cl, al
	mov	al, [nibble3]
	or	al, cl
	mov	cl, al
	mov	al, [nibble2]
	or	al, cl
	mov	cl, al
	mov	al, [nibble1]
	or	al, cl
	call	writebyte
	jmp	@@_330


;-----------------------------------------------------
; @@_34. (17)	ALL YELLOW--> BLUE ONLY.
;-----------------------------------------------------
@@_34:	mov     di, offset display17
        call    StrWrite     

@@_340:	call	readbyte		
	mov	[onebyte], al		; NIBBLE ONE
	and 	al, 11000000b		; get first nibble
	cmp	al, 01000000b		
	jne	@@_341
	mov	al, 10000000b		
@@_341:	mov	[nibble1], al
	mov	al, [onebyte]		; NIBBLE TWO
	and 	al, 00110000b		; get second nibble
	cmp	al, 00010000b		
	jne	@@_342
	mov	al, 00100000b		
@@_342:	mov	[nibble2], al
	mov	al, [onebyte]		; NIBBLE THREE
	and 	al, 00001100b		; get third nibble
	cmp	al, 00000100b		
	jne	@@_343
	mov	al, 00001000b		
@@_343:	mov	[nibble3], al
	mov	al, [onebyte]		; NIBBLE FOUR
	and 	al, 00000011b		; get fourth nibble
	cmp	al, 00000001b		
	jne	@@_344
	mov	al, 00000010b		
@@_344:	mov	[nibble4], al
	mov	cl, al
	mov	al, [nibble3]
	or	al, cl
	mov	cl, al
	mov	al, [nibble2]
	or	al, cl
	mov	cl, al
	mov	al, [nibble1]
	or	al, cl
	call	writebyte
	jmp	@@_340


;-----------------------------------------------------
; @@_35. (18)	ALL YELLOW--> RED ONLY.
;-----------------------------------------------------
@@_35:	mov     di, offset display18
        call    StrWrite     

@@_350:	call	readbyte		
	mov	[onebyte], al		; NIBBLE ONE
	and 	al, 11000000b		; get first nibble
	cmp	al, 01000000b		
	jne	@@_351
	mov	al, 11000000b		
@@_351:	mov	[nibble1], al
	mov	al, [onebyte]		; NIBBLE TWO
	and 	al, 00110000b		; get second nibble
	cmp	al, 00010000b		
	jne	@@_352
	mov	al, 00110000b		
@@_352:	mov	[nibble2], al
	mov	al, [onebyte]		; NIBBLE THREE
	and 	al, 00001100b		; get third nibble
	cmp	al, 00000100b		
	jne	@@_353
	mov	al, 00001100b		
@@_353:	mov	[nibble3], al
	mov	al, [onebyte]		; NIBBLE FOUR
	and 	al, 00000011b		; get fourth nibble
	cmp	al, 00000001b		
	jne	@@_354
	mov	al, 00000011b		
@@_354:	mov	[nibble4], al
	mov	cl, al
	mov	al, [nibble3]
	or	al, cl
	mov	cl, al
	mov	al, [nibble2]
	or	al, cl
	mov	cl, al
	mov	al, [nibble1]
	or	al, cl
	call	writebyte
	jmp	@@_350


;-----------------------------------------------------
; @@_36. (19)	ALL BLUE  --> GREEN ONLY.
;-----------------------------------------------------
@@_36:	mov     di, offset display19
        call    StrWrite     

@@_360:	call	readbyte		
	mov	[onebyte], al		; NIBBLE ONE
	and 	al, 11000000b		; get first nibble
	cmp	al, 10000000b		
	jne	@@_361
	mov	al, 00000000b		
@@_361:	mov	[nibble1], al
	mov	al, [onebyte]		; NIBBLE TWO
	and 	al, 00110000b		; get second nibble
	cmp	al, 00100000b		
	jne	@@_362
	mov	al, 00000000b		
@@_362:	mov	[nibble2], al
	mov	al, [onebyte]		; NIBBLE THREE
	and 	al, 00001100b		; get third nibble
	cmp	al, 00001000b		
	jne	@@_363
	mov	al, 00000000b		
@@_363:	mov	[nibble3], al
	mov	al, [onebyte]		; NIBBLE FOUR
	and 	al, 00000011b		; get fourth nibble
	cmp	al, 00000010b		
	jne	@@_364
	mov	al, 00000000b		
@@_364:	mov	[nibble4], al
	mov	cl, al
	mov	al, [nibble3]
	or	al, cl
	mov	cl, al
	mov	al, [nibble2]
	or	al, cl
	mov	cl, al
	mov	al, [nibble1]
	or	al, cl
	call	writebyte
	jmp	@@_360


;-----------------------------------------------------
; @@_37. (20)	ALL BLUE  --> YELLOW ONLY.
;-----------------------------------------------------
@@_37:	mov     di, offset display20
        call    StrWrite     

@@_370:	call	readbyte		
	mov	[onebyte], al		; NIBBLE ONE
	and 	al, 11000000b		; get first nibble
	cmp	al, 10000000b		
	jne	@@_371
	mov	al, 01000000b		
@@_371:	mov	[nibble1], al
	mov	al, [onebyte]		; NIBBLE TWO
	and 	al, 00110000b		; get second nibble
	cmp	al, 00100000b		
	jne	@@_372
	mov	al, 00010000b		
@@_372:	mov	[nibble2], al
	mov	al, [onebyte]		; NIBBLE THREE
	and 	al, 00001100b		; get third nibble
	cmp	al, 00001000b		
	jne	@@_373
	mov	al, 00000100b		
@@_373:	mov	[nibble3], al
	mov	al, [onebyte]		; NIBBLE FOUR
	and 	al, 00000011b		; get fourth nibble
	cmp	al, 00000010b		
	jne	@@_374
	mov	al, 00000001b		
@@_374:	mov	[nibble4], al
	mov	cl, al
	mov	al, [nibble3]
	or	al, cl
	mov	cl, al
	mov	al, [nibble2]
	or	al, cl
	mov	cl, al
	mov	al, [nibble1]
	or	al, cl
	call	writebyte
	jmp	@@_370


;-----------------------------------------------------
; @@_38. (21)	ALL BLUE  --> RED ONLY.	
;-----------------------------------------------------
@@_38:	mov     di, offset display21
        call    StrWrite     

@@_380:	call	readbyte		
	mov	[onebyte], al		; NIBBLE ONE
	and 	al, 11000000b		; get first nibble
	cmp	al, 10000000b		
	jne	@@_381
	mov	al, 11000000b		
@@_381:	mov	[nibble1], al
	mov	al, [onebyte]		; NIBBLE TWO
	and 	al, 00110000b		; get second nibble
	cmp	al, 00100000b		
	jne	@@_382
	mov	al, 00110000b		
@@_382:	mov	[nibble2], al
	mov	al, [onebyte]		; NIBBLE THREE
	and 	al, 00001100b		; get third nibble
	cmp	al, 00001000b		
	jne	@@_383
	mov	al, 00001100b		
@@_383:	mov	[nibble3], al
	mov	al, [onebyte]		; NIBBLE FOUR
	and 	al, 00000011b		; get fourth nibble
	cmp	al, 00000010b		
	jne	@@_384
	mov	al, 00000011b		
@@_384:	mov	[nibble4], al
	mov	cl, al
	mov	al, [nibble3]
	or	al, cl
	mov	cl, al
	mov	al, [nibble2]
	or	al, cl
	mov	cl, al
	mov	al, [nibble1]
	or	al, cl
	call	writebyte
	jmp	@@_380


;-----------------------------------------------------
; @@_39. (22)	ALL RED   --> GREEN ONLY.
;-----------------------------------------------------
@@_39:	mov     di, offset display22
        call    StrWrite     

@@_390:	call	readbyte		
	mov	[onebyte], al		; NIBBLE ONE
	and 	al, 11000000b		; get first nibble
	cmp	al, 11000000b		
	jne	@@_391
	mov	al, 00000000b		
@@_391:	mov	[nibble1], al
	mov	al, [onebyte]		; NIBBLE TWO
	and 	al, 00110000b		; get second nibble
	cmp	al, 00110000b		
	jne	@@_392
	mov	al, 00000000b		
@@_392:	mov	[nibble2], al
	mov	al, [onebyte]		; NIBBLE THREE
	and 	al, 00001100b		; get third nibble
	cmp	al, 00001100b		
	jne	@@_393
	mov	al, 00000000b		
@@_393:	mov	[nibble3], al
	mov	al, [onebyte]		; NIBBLE FOUR
	and 	al, 00000011b		; get fourth nibble
	cmp	al, 00000011b		
	jne	@@_394
	mov	al, 00000000b		
@@_394:	mov	[nibble4], al
	mov	cl, al
	mov	al, [nibble3]
	or	al, cl
	mov	cl, al
	mov	al, [nibble2]
	or	al, cl
	mov	cl, al
	mov	al, [nibble1]
	or	al, cl
	call	writebyte
	jmp	@@_390

;-----------------------------------------------------
; @@_40. (23)	ALL RED   --> YELLOW.
;-----------------------------------------------------
@@_40:	mov     di, offset display23
        call    StrWrite     

@@_400:	call	readbyte		
	mov	[onebyte], al		; NIBBLE ONE
	and 	al, 11000000b		; get first nibble
	cmp	al, 00000000b		
	jne	@@_401
	mov	al, 01000000b		
@@_401:	mov	[nibble1], al
	mov	al, [onebyte]		; NIBBLE TWO
	and 	al, 00110000b		; get second nibble
	cmp	al, 00000000b		
	jne	@@_402
	mov	al, 00010000b		
@@_402:	mov	[nibble2], al
	mov	al, [onebyte]		; NIBBLE THREE
	and 	al, 00001100b		; get third nibble
	cmp	al, 00000000b		
	jne	@@_403
	mov	al, 00000100b		
@@_403:	mov	[nibble3], al
	mov	al, [onebyte]		; NIBBLE FOUR
	and 	al, 00000011b		; get fourth nibble
	cmp	al, 00000000b		
	jne	@@_404
	mov	al, 00000001b		
@@_404:	mov	[nibble4], al
	mov	cl, al
	mov	al, [nibble3]
	or	al, cl
	mov	cl, al
	mov	al, [nibble2]
	or	al, cl
	mov	cl, al
	mov	al, [nibble1]
	or	al, cl
	call	writebyte
	jmp	@@_400


;-----------------------------------------------------
; @@_41. (24)	ALL RED   --> BLUE.
;-----------------------------------------------------
@@_41:	mov     di, offset display24
        call    StrWrite     

@@_410:	call	readbyte		
	mov	[onebyte], al		; NIBBLE ONE
	and 	al, 11000000b		; get first nibble
	cmp	al, 11000000b		
	jne	@@_411
	mov	al, 10000000b		
@@_411:	mov	[nibble1], al
	mov	al, [onebyte]		; NIBBLE TWO
	and 	al, 00110000b		; get second nibble
	cmp	al, 00110000b		
	jne	@@_412
	mov	al, 00100000b		
@@_412:	mov	[nibble2], al
	mov	al, [onebyte]		; NIBBLE THREE
	and 	al, 00001100b		; get third nibble
	cmp	al, 00001100b		
	jne	@@_413
	mov	al, 00001000b		
@@_413:	mov	[nibble3], al
	mov	al, [onebyte]		; NIBBLE FOUR
	and 	al, 00000011b		; get fourth nibble
	cmp	al, 00000011b		
	jne	@@_414
	mov	al, 00000010b		
@@_414:	mov	[nibble4], al
	mov	cl, al
	mov	al, [nibble3]
	or	al, cl
	mov	cl, al
	mov	al, [nibble2]
	or	al, cl
	mov	cl, al
	mov	al, [nibble1]
	or	al, cl
	call	writebyte
	jmp	@@_410







	

@@80:   mov     bx, [inFile]            ; Get input file handle
        mov     ah, 3Eh                 ; DOS Close-file function
        int     21h                     ; Close input file
        mov     bx, [outFile]           ; Get output file handle
        mov     ah, 3Eh                 ; DOS Close-file function
        int     21h                     ; Close output file
        jnc     Exit3                   ; Exit if no errors detected
        jmp     Errors                  ; Else jump to error handler
Exit3:
        mov     ah, 04Ch                ; DOS function: Exit program
        mov     al, [exCode]            ; Return exit code value
        int     21h                     ; Call DOS. Terminate program





Exit:   mov     ah, 04Ch                ; DOS function: Exit program
        mov     al, [exCode]            ; Return exit code value
        int     21h                     ; Call DOS. Terminate program



Errors: mov     [exCode], al            ; Save error code
        call    DiskErr                 ; Display error message
        jmp     Exit                    ; Exit program

PROC 	readbyte
	push	bx
	mov     ah, 3Fh                 ; DOS Read-file function
        mov     bx, [inFile]            ; Set bx to input file handle
        mov     cx, 1                   ; Specify one byte to read
        mov     dx, offset oneByte      ; Address variable with ds:dx
        int     21h                     ; Call DOS to read from file
  	or      ax, ax                  ; Check for end of input file
        je     	@@802                   ; ax=0=end of file; jump
	mov	di, offset onebyte
	mov	al, [di]
	pop	bx
	ret

@@802:  mov     bx, [inFile]            ; Get input file handle
        mov     ah, 3Eh                 ; DOS Close-file function
        int     21h                     ; Close input file
        mov     bx, [outFile]           ; Get output file handle
        mov     ah, 3Eh                 ; DOS Close-file function
        int     21h                     ; Close output file
        jnc     Exit2                   ; Exit if no errors detected
        jmp     Errors                  ; Else jump to error handler
Exit2:
        mov     ah, 04Ch                ; DOS function: Exit program
        mov     al, [exCode]            ; Return exit code value
        int     21h                     ; Call DOS. Terminate program
ENDP	readbyte



PROC	writebyte
	push	bx
	push	cx
	push	dx
	push	di
	push	si
	mov	di, offset oneByte
	mov	[di], al
	push	ax
        mov     ah, 40h                 ; DOS Write-file function
        mov     bx, [outFile]           ; Set bx to output file handle
        mov     cx, 1                   ; Specify one byte to write
        mov     dx, offset onebyte      ; Address variable with ds:dx
        int     21h			; Call DOS to write to file
	pop	ax
	pop	si
	pop	di
	pop	dx
	pop	cx
	pop	bx
	ret
ENDP	writebyte


END     start
