IN:	;Read Port value in Arg1
	ld HL,CLIBUFFER+03h ;start of data arguments
	call Arg2Byte ;point HL to argument, return byte in A
	ld b,0
	ld c,a
	in a,(c)
	call Hex2SCR
	ld a,0dh
	call DrawaChr
	jp MAIN	
	
