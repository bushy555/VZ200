DIRbasic: ;DIR called from basic
	call DIRmain
;	call Debug
	ret

DIR:

	call DIRmain
	jp MAIN

DIRmain:

	
;Pass over E5h entries
;00 entried indicates end of directory
;512 bytes per sector
;32bytes per entry
;16 entries per sector
	call Fat32_Root ;Change this!!!! Needs to point to Current Directory Cluster
	xor a;
	ld (DirWidthCount),a
	ld (DIR_FileCount),a	;zero file counter
	ld (DIR_EntryCount),a
	ld (DIR_FolderCount),a
	ld a,36
	ld (DirListCount),a
DIR_FileLoopUpper:
	ld HL,RAMBUFFER
DIR_FileLoop:
	ld a,(HL)
	cp 00
	jp z, DIR_EndOfDirectory
	cp 0E5h
	jp z, DIR_DeletedEntry
	cp 01h ;LFN
	jp z, DIR_DeletedEntry
	
	push HL
	ld DE,11
	add hl,de
	ld a,(HL)
	pop HL
	cp 20h
	jp z, DIR_IsFile
	cp 08h
	jp z, DIR_IsLabel
	cp 10h
	jp z, DIR_IsFolder
	;else
	jp DIR_DeletedEntry
	
DIR_IsFile:	
	ld a,(DIR_FileCount)
	inc a
	ld (DIR_FileCount),a
	call DIR_ShowFileInfo
	jp DIR_DeletedEntry

DIR_IsLabel:	
	call DIR_ShowLabelInfo
	jp DIR_DeletedEntry
	
DIR_IsFolder:	
	ld a,(DIR_FolderCount)
	inc a
	ld (DIR_FolderCount),a
	call DIR_ShowFolderInfo
	jp DIR_DeletedEntry


DIR_DeletedEntry:
	;increment HL by 15
	ld de,0032
	add HL,de
	;Check sector overflow
	ld a,(DIR_EntryCount)
	inc a
	ld (DIR_EntryCount),a
	cp 15
	jp nz, DIR_FileLoop
	xor a
	ld (DIR_EntryCount),a
	call FAT_NextSector
	jp DIR_FileLoopUpper
	
DIR_ShowFileInfo: ;Write filename, size, attributes

;check for .VZ extension
	push HL
	ld b,8 ;8.3
DIR_SFI:
	ld a,(HL)
	call DrawChr
	inc HL
	djnz DIR_SFI
;	ld a,'.'
;	call DrawChr
;	ld b,3 ;8.3
DIR_SFI2:
;	ld a,(HL)
;	call DrawChr
;	inc HL
;	djnz DIR_SFI2

	ld a,' '
	call DrawChr
	
	
	ld a,(DirWidthCount)
	inc a
	ld (DirWidthCount),a
	cp 3
	jr nz,NoNewLine

	ld a,0dh
	call DrawChr
	ld a,0
	ld (DirWidthCount),a
	
NoNewLine
;	ld a,LF
;	call DrawChr
	
	ld a,(DirListCount)
	dec a
	ld (DirListCount),a
	cp 0
	jr nz, ContDir

	push af
	push hl
	push bc
	push de
	ld a,36 ;how many files per listing. 14?
	ld (DirListCount),a
	
	ld HL,DirPauseMSG
	call DrawString
	
DirWait:
	call GETKEY
	cp 45
	jp z,DIRsafeReturn
	cp ' '
	jr nz, DirWait
	pop de
	pop bc
	pop hl
	pop af

ContDir


	pop HL
	ret


DIRsafeReturn:
	pop de
	pop bc
	pop hl
	pop af
	pop HL

DIRsafeReturn2:

	pop af ;double pop to return from a call. 
	pop af ;When was your last desk pop?
	ret
	


DIR_ShowFolderInfo: ;Write <Foldername>
	push HL
	ld b,8 ;8
	ld a,'<'
	call DrawChr
DIR_SFoI:
	ld a,(HL)
	call DrawChr
	inc HL
	djnz DIR_SFoI
	ld a,'>'
	call DrawChr
	ld a,0dh
	call DrawChr
;	ld a,LF
;	call DrawChr
	pop HL
	ret
	

DIR_ShowLabelInfo: ;Write Label
;	push HL

;	LD DE,MSG_Volume
;	CALL DrawString

;	ld b,8 ;8
;DIR_SLI:
;	ld a,(HL)
;	call DrawaChr
;	inc HL
;	djnz DIR_SLI
;	ld a,0dh
;	call DrawaChr
;	ld a,LF
;	call PUTKEY
;	pop HL
	ret


DIR_EndOfDirectory:
;	ld a,(DIR_FileCount)
;	call Hex2SCR;Hex8Dec
;	LD DE,MSG_FilesFound
;	CALL DrawString

;	ld a,(DIR_FolderCount)
;	call Hex2SCR;Hex8Dec
;	LD DE,MSG_FoldersFound
;	CALL DrawString
	 ;???? lets see
	ld a,0dh
	call DrawChr
	ret
	JP MAIN

MSG_Volume:
.DB "VOLUME",0dh,00
MSG_FilesFound:
.DB "FILES FOUND",0dh,00
DirPauseMSG:
.DB 0dh,"** PRESS SPACE OR BREAK **",0dh,00
MSG_FoldersFound:
.DB "FOLDERS FOUND",0dh,00
