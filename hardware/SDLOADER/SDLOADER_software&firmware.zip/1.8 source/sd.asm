;This really, really needs to be optimised for a real Z80 vs the Gameboy cpu code...

InitSD:
	call SD_Flush
	call SD_CMD0
	cp 0
	JP z,NoResponseFromSD
	call SD_CMD8

InitTry:
	
	call SD_CMD55
	call SD_CMD41
	cp 01
	jr z, InitTry
	
	ld HL,InitOK
	call DrawString

	call SD_CMD58
	
SD_Init_Continue:

	Call SD_SetBlkSize
	
	call Fat32_Init

	cp 01
	jr z, FatInitFail

	ld HL,FATInitMSG
	call DrawString
	
	call Fat32_Root

	RET

NoResponseFromSD:
	ld HL,NOresponsemsg
	call DrawString
	ld a,1
	ld (ErrorLevel),a
	ret

FatInitFail:

	jp BASIC
	

SD_Flush: ;As per SD protocol, send 80 clk pusles with CS High
	ld a,1 ;
	out (SDCFG),a ;CFG port- D1=Speed (1=sysclk, 0=100khz) D2=CS
	ld a,0FFh
	out (SDIO),a ;IO R/W. Upon Write, it will auto send 8 bits.
	ld b,10
SD_F1:
	ld a,0FFh
	out (SDIO),a
	dec b
	jr nz,SD_F1
	ret

SD_ReSync:	;Some SD cards need 8 clks after a command to finish the 
	ld a,1  ;Last instruction and prepare for the next.
	out (SDCFG),a
	ld a,0FFh
	out (SDIO),a
	nop
	nop
	nop
	ld a,3
	out (SDCFG),a
	ret
	
SD_CMD0:
	ld BC,1000 ;Tries before failure
	call SD_ReSync
	ld a,040H
	out (SDIO),a
	nop
	nop
	nop
	ld a,00H
	out (SDIO),a
	nop
	nop
	nop
	ld a,00H
	out (SDIO),a
	nop
	nop
	nop
	ld a,00H
	out (SDIO),a
	nop
	nop
	nop
	ld a,00H
	out (SDIO),a
	nop
	nop
	nop
	ld a,95H
	out (SDIO),a
	nop
	nop
	nop

SD_C01:

	dec bc
	ld a,b
	or c
	ret z
	ld a,0FFh
	out (SDIO),a
	nop
	nop
	nop
	in a,(SDIO)
	cp 01
	jr nz,SD_C01
	ret	
	
	
	
	
SD_CMD8:
	call SD_ReSync
	ld a,048H
	out (SDIO),a
	ld a,00H
	out (SDIO),a
	ld a,00H
	out (SDIO),a
	ld a,01H
	out (SDIO),a
	ld a,0AAH
	out (SDIO),a
	ld a,87H
	out (SDIO),a


SD_C81:
	ld a,0FFh
	out (SDIO),a
	nop
	nop
	nop
	in a,(SDIO)
	cp 0AAh
	jr nz,SD_C81
	ret	


SD_CMD55:
	call SD_ReSync
	ld a,077H
	out (SDIO),a
	ld a,00H
	out (SDIO),a
	ld a,00H
	out (SDIO),a
	ld a,00H
	out (SDIO),a
	ld a,00H
	out (SDIO),a
	ld a,65H
	out (SDIO),a


SD_C51:
	ld a,0FFh
	out (SDIO),a
	nop
	nop
	nop
	nop
	in a,(SDIO)
	cp 00h
	ret z
	cp 01h
	ret z
	jr SD_C51



SD_CMD41:
	call SD_ReSync
	ld a,069H
	out (SDIO),a
	ld a,040H
	out (SDIO),a
	ld a,00H
	out (SDIO),a
	ld a,00H
	out (SDIO),a
	ld a,00H
	out (SDIO),a
	ld a,77H
	out (SDIO),a

SD_C411:
	ld a,0FFh
	out (SDIO),a
	nop
	nop
	nop
	in a,(SDIO)
	cp 0h
	ret z
	cp 1h
	ret z
	jr SD_C411


SD_CMD58:
	call SD_ReSync
	ld a,07AH
	out (SDIO),a
	ld a,040H
	out (SDIO),a
	ld a,00H
	out (SDIO),a
	ld a,00H
	out (SDIO),a
	ld a,00H
	out (SDIO),a
	ld a,0FFH
	out (SDIO),a

SD_C581:
	ld a,0FFh
	out (SDIO),a
	nop
	nop
	nop
	in a,(SDIO)
	cp 0h
	jr nz, SD_C581

	ld a,0FFh
	out (SDIO),a
	nop
	nop
	nop
	in a,(SDIO) ;This is the address mode
	and 040H
	ld (SD_SECbyteMode),a
	
	ld a,0FFh
	out (SDIO),a
	nop
	nop
	nop

	ld a,0FFh
	out (SDIO),a
	nop
	nop
	nop

	ld a,0FFh
	out (SDIO),a
	nop
	nop
	nop
	
	ret
	
SD_SetBlkSize:
	call SD_ReSync
	ld a,050H
	out (SDIO),a
	ld a,000H
	out (SDIO),a
	ld a,00H
	out (SDIO),a
	ld a,02H
	out (SDIO),a
	ld a,00H
	out (SDIO),a
	ld a,0FFH
	out (SDIO),a

SD_Blk1:
	ld a,0FFh
	out (SDIO),a
	nop
	nop
	nop
	in a,(SDIO)
	cp 0h
	ret z
	jr SD_Blk1

CF_WriteSector:
	

	ld a,L
	ld (FAT_CurrentSector),a
	ld a,H
	ld (FAT_CurrentSector+1),a
	ld a,E
	ld (FAT_CurrentSector+2),a
	ld a,0
	ld (FAT_CurrentSector+3),a

SD_WriteSector ;
	;0x51 SECTOR(32:0) 0x01 >...> 0xFE > DATA > 2bytes Checksum
FAT_Write_Sector:	;Get sector # in Address FAT_CurrentSector, 
					;put in address RAMBUFFER
	ld a,(FAT_CurrentSector)
	push AF
	ld a,(FAT_CurrentSector+1)
	push AF
	ld a,(FAT_CurrentSector+2)
	push AF
	ld a,(FAT_CurrentSector+3)
	push AF
	
	call SD_ReSync
	
	ld a,(SD_SECbyteMode)
	cp 40h
	jp z, FAT_WriteSectorAddressing

	;mul by 512
	or a
	
	ld a,(FAT_CurrentSector)
	rl a
	ld (FAT_CurrentSector),a

	ld a,(FAT_CurrentSector+1)
	rl a
	ld (FAT_CurrentSector+1),a

	ld a,(FAT_CurrentSector+2)
	rl a
	ld (FAT_CurrentSector+2),a

	ld a,(FAT_CurrentSector+3)
	rl a
	ld (FAT_CurrentSector+3),a

	ld a,(FAT_CurrentSector+2)
	ld (FAT_CurrentSector+3),a
	ld a,(FAT_CurrentSector+1)
	ld (FAT_CurrentSector+2),a
	ld a,(FAT_CurrentSector+0)
	ld (FAT_CurrentSector+1),a
	ld a,0
	ld (FAT_CurrentSector+0),a

FAT_WriteSectorAddressing:

	ld a,58h
	out (SDIO),a
	nop
	nop
	nop
	nop
	nop

	ld a,(FAT_CurrentSector+3)
	out (SDIO),a
	nop
	nop
	nop
	nop
	nop
	
	ld a,(FAT_CurrentSector+2)
	out (SDIO),a
	nop
	nop
	nop
	nop
	nop
	
	ld a,(FAT_CurrentSector+1)
	out (SDIO),a
	nop
	nop
	nop
	nop
	nop

	ld a,(FAT_CurrentSector)
	out (SDIO),a
	nop
	nop
	nop
	nop
	nop

	ld a,01h ;CRC
	out (SDIO),a
	nop
	nop
	nop

FAT_WriteWait4ResponseSec:
	ld a,0FFh
	out (SDIO),a
	nop
	nop
	nop
	nop
	nop
	nop
	nop
	nop
	
	in a,(SDIO)

	cp 00h
	jr nz, FAT_WriteWait4ResponseSec
	nop
	nop
	nop
	nop
	ld a,0FEh
	out (SDIO),a
	nop
	nop
	nop
	nop
	

	ld hl, RAMBUFFER
	ld de, 512
	
FAT_WritecopySectorToRam:
	ld a,(HL)
	out (SDIO),a
	nop
	nop
	nop
	nop
	inc HL
	dec e
	jp nz, FAT_WritecopySectorToRam
	dec d
	jp nz, FAT_WritecopySectorToRam
	
	ld a,0FFh
	out (SDIO),a
	nop
	nop
	nop
	nop
	nop


	ld a,0FFh
	out (SDIO),a

	nop
	nop
	nop
	nop
	nop	
	nop

W4Write:
	ld a,0FFh
	out (SDIO),a

	nop
	nop
	nop
	nop
	nop	
	nop
	
	in a,(SDIO)
	cp 0ffh
	jr nz,W4Write


	
	pop AF
	ld (FAT_CurrentSector+3),a
	pop AF
	ld (FAT_CurrentSector+2),a
	pop AF
	ld (FAT_CurrentSector+1),a
	pop AF
	ld (FAT_CurrentSector),a
	
	ret






CF_GetSector ;SAme as SD but use EHL
	push HL
	push DE
	
	ld a,(FAT_LastSector)
	cp l
	jr nz,CF_GetSector1
	ld a,(FAT_LastSector+1)
	cp h
	jr nz,CF_GetSector1
	ld a,(FAT_LastSector+2)
	cp E
	jr nz,CF_GetSector1
	ld a,(FAT_LastSector+3)
	cp 0
	jr nz,CF_GetSector1
	;We already have the current sector in RAMBUFFER
	pop DE
	pop HL
	ret
	

CF_GetSector1:
	pop DE
	pop HL

	ld a,L
	ld (FAT_CurrentSector),a
	ld a,H
	ld (FAT_CurrentSector+1),a
	ld a,E
	ld (FAT_CurrentSector+2),a
	ld a,0
	ld (FAT_CurrentSector+3),a

SD_GetSector ;
	;0x51 SECTOR(32:0) 0x01 >...> 0xFE > DATA > 2bytes Checksum
FAT_Get_Sector:	;Get sector # in Address FAT_CurrentSector, 
					;put in address RAMBUFFER
	
	ld a,(FAT_CurrentSector)
	push AF
	ld a,(FAT_CurrentSector+1)
	push AF
	ld a,(FAT_CurrentSector+2)
	push AF
	ld a,(FAT_CurrentSector+3)
	push AF
	
	call SD_ReSync
	
	ld a,(SD_SECbyteMode)
	cp 40h
	jp z, FAT_SectorAddressing

	
	
	;mul by 512
	scf
	ccf
	
	ld a,(FAT_CurrentSector)
	rl a
	ld (FAT_CurrentSector),a

	ld a,(FAT_CurrentSector+1)
	rl a
	ld (FAT_CurrentSector+1),a

	ld a,(FAT_CurrentSector+2)
	rl a
	ld (FAT_CurrentSector+2),a

	ld a,(FAT_CurrentSector+3)
	rl a
	ld (FAT_CurrentSector+3),a

	ld a,(FAT_CurrentSector+2)
	ld (FAT_CurrentSector+3),a
	ld a,(FAT_CurrentSector+1)
	ld (FAT_CurrentSector+2),a
	ld a,(FAT_CurrentSector+0)
	ld (FAT_CurrentSector+1),a
	ld a,0
	ld (FAT_CurrentSector+0),a

FAT_SectorAddressing:

	ld a,51h
	out (SDIO),a
	nop
	nop
	nop
;	call Hex2SCR

	ld a,(FAT_CurrentSector+3)
	out (SDIO),a
	nop
	nop
	nop
;	call Hex2SCR
	
	ld a,(FAT_CurrentSector+2)
	out (SDIO),a
	nop
	nop
	nop
;	call Hex2SCR
	
	ld a,(FAT_CurrentSector+1)
	out (SDIO),a
	nop
	nop
	nop
;	call Hex2SCR

	ld a,(FAT_CurrentSector)
	out (SDIO),a
	nop
	nop
	nop
;	call Hex2SCR

	ld a,01h ;CRC
	out (SDIO),a
	nop
	nop
	nop
;	call Hex2SCR

FAT_Wait4ResponseSec:
	ld a,0FFh
	out (SDIO),a
	nop
	nop
	nop
	nop
	nop
	nop
	nop
	nop
;	call Hex2SCR
	
	in a,(SDIO)

	cp 0FEh
	jr nz, FAT_Wait4ResponseSec

	ld hl, RAMBUFFER
	ld de, 512
	ld a,0FFh
	out (SDIO),a
	nop
	nop
	nop
	nop
	
FAT_copySectorToRam:
	in a,(SDIO)
	
;	call Hex2SCR
	
	ld (HL),A
	inc HL
	ld a,0FFh
	out (SDIO),a
	dec e
	jp nz, FAT_copySectorToRam
	dec d
	jp nz, FAT_copySectorToRam
	
	ld a,0FFh
	out (SDIO),a
	nop
	nop
	nop

	ld a,0FFh
	out (SDIO),a

	nop
	nop
	nop	
	nop

	ld a,0FFh
	out (SDIO),a

	nop
	nop
	nop	
	nop
	
	;Checksum flushed
	
	pop AF
	ld (FAT_CurrentSector+3),a
	ld (FAT_LastSector+3),a
	pop AF
	ld (FAT_CurrentSector+2),a
	ld (FAT_LastSector+2),a
	pop AF
	ld (FAT_CurrentSector+1),a
	ld (FAT_LastSector+1),a
	pop AF
	ld (FAT_CurrentSector),a
	ld (FAT_LastSector+0),a
	
	ret

NOresponsemsg:
		.DB "NO RESPONSE FROM SD",0DH,00
