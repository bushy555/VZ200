CLSsub .equ 01C9H 		;Basic CLS routine
DrawString .equ 28A7H	;Basic Draw String routine
DrawChr .equ 033AH		;Basic Draw Character Routine
InKey .equ 2EF4H		;Basic Inkey routine
Beep .equ 3450H			;Basic Beep routine

CR .equ 0Dh				;Carriage return

MAPPER .equ 55				;Hardware IO Port
SDCFG .equ 56			;Hardware IO Port
SDIO .equ 57			;Hardware IO Port
VZMAP	.equ 58		;write 0 if a vz200, 1 if 300. 0 is default

RAMBUFFER   		.equ 0F800H ;512 bytes from F800 - F9FF
RAMBUFFERhi			.equ 0f8h; used for compares
RAMBUFFERlo			.equ 00h;


;FAT32 Registers
FAT_Begin_LBA     	.equ 0FA00h ;2 bytes
FAT_SecPerFatH    	.equ 0FA02h ;2 bytes
FAT_SecPerFatL 		.equ 0FA04h ; 2 bytes
FAT_RootDir1stH 	.equ 0FA06h ;2 bytes
FAT_RootDir1stL 	.equ 0FA08h ;2 bytes
FAT_Sector_Begin_L 	.equ 0FA0Ah ;2 bytes
FAT_Sector_Begin_H 	.equ 0FA0Ch ;2 bytes
FAT_NextClusterL 	.equ 0FA0Eh ;2 bytes
FAT_NextClusterH 	.equ 0FA10h ; 2 bytes
FAT_CurrentClusterL .equ 0FA12h ;2bytes
FAT_CurrentClusterH .equ 0FA14h ;2bytes
FAT_FAT1LBAL		.equ 0FA16h;2 bytes
FAT_FAT1LBAH		.equ 0FA18h; 2bytes
FAT_SecPerCluster 	.equ 0FA20h; 1 bytes
FAT_SectorOfCluster .equ 0FA21h; 1 bytes
FAT_TempRegL 		.equ 0FA22h ;2bytes
FAT_TempRegH 		.equ 0FA24h ;2bytes
FAT_CurrentSector 	.equ 0FA26h ;4 bytes
FAT_CurrentSectorL 	.equ 0FA26h ;2 bytes
FAT_CurrentSectorH 	.equ 0FA28h ;2 bytes
SD_SECbyteMode 		.equ 0FA2Ah; 1 byte
BootFileFound 		.equ 0FA2Bh; 1 byte, 0=not found, 1=found
BootFileSize 		.equ 0FA30h; 4 bytes
BootFileCluster 	.equ 0FA34h;4 bytes

CurrentRAMsector 	.equ 0FA38h;1 byte
FileSizeIn256 		.equ 0FA39h ;3 bytes
FileReadComplete 	.equ 0FA3Ch ;1 byte. 1=in use, 0=read
FileBaseAddress 	.equ 0FA3Dh ;2 bytes

;File Registers
DIR_FileCount 		.equ 0FB00h ; 1 byte - used to count files in dir
DIR_EntryCount 		.equ 0FB01h; 1 byte - used to change sectors
DIR_FolderCount 	.equ 0FB02h; 1 byte - used to change sectors

FileFound			.equ 0FB03h; file found flag

LastKeyPressed		.equ 0FB04h;

ErrorLevel			.equ 0FB05h; Error flag

FAT_LastSector		.equ 0FB06h ;last sector loaded

Dec0 				.equ 0FB10h; Hex 2 Decimal registers
Dec1 				.equ 0FB11h; 
Dec2 				.equ 0FB12h; 
Dec3 				.equ 0FB13h; 
Dec4 				.equ 0FB14h; 
Dec5 				.equ 0FB15h; 
Dec6 				.equ 0FB16h; 
Dec7 				.equ 0FB17h; 
Dec8 				.equ 0FB18h; 
Dec9 				.equ 0FB19h; 

FileSize			.equ 0FB20h;
FileCluster			.equ 0FB24h;
FileName			.equ 0FB28h; 11 bytes

FileType			.equ 0FB40h ; t or b

DirListCount		.equ 0FB41h;
DirWidthCount		.equ 0FB42h;


CLIBUFFER 			.equ 0FC00h; 512 byte CLI buffer

NewFileSize				.equ 0FE00h; 4 bytes
NewFileCurrentCluster 	.equ 0FE04h; 4 bytes, current file cluster
NewFileClusters			.equ 0FE08h; 1 byte, number of clusters to allocate
NewFileClusterCount		.equ 0FE09h; 1 byte, counts the clusters being linked

FindDirectoryEntry 		.equ 0FE0Ah; 1 byte flag, set when searching for blank file

BasicListingStartAdd	.equ 0FE10h; 2 bytes
BasicListingEndAdd		.equ 0FE12h; 2 bytes
BasicListingSize		.equ 0FE14h; 2 bytes



