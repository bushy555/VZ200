

Debug:
	push af
	push bc
	push de
	push HL
	
	push HL
	push HL
	push DE
	push DE
	push BC
	push BC
	push af
	
	ld a,'A'
	call DrawaChr
	ld a,':'
	call DrawaChr
	pop af
	call Hex2SCR
	ld a,' '
	call DrawaChr
	
	ld a,'B'
	call DrawaChr
	ld a,'C'
	call DrawaChr
	ld a,':'
	call DrawaChr
	pop bc
	ld a,b
	call Hex2SCR
	pop bc
	ld a,c
	call Hex2SCR
	ld a,' '
	call DrawaChr
	
	ld a,'D'
	call DrawaChr
	ld a,'E'
	call DrawaChr
	ld a,':'
	call DrawaChr
	pop de
	ld a,d
	call Hex2SCR
	pop de
	ld a,e
	call Hex2SCR
	ld a,' '
	call DrawaChr

	ld a,'H'
	call DrawaChr
	ld a,'L'
	call DrawaChr
	ld a,':'
	call DrawaChr
	pop hl
	ld a,h
	call Hex2SCR
	pop hl
	ld a,l
	call Hex2SCR
	ld a,0dh
	call DrawaChr
		
	LD HL,SecMSG
	call DrawString
	ld a,(FAT_CurrentSector+3)
	call Hex2SCR
	ld a,(FAT_CurrentSector+2)
	call Hex2SCR
	ld a,(FAT_CurrentSector+1)
	call Hex2SCR
	ld a,(FAT_CurrentSector+0)
	call Hex2SCR
	ld a,' '
	call DrawaChr
	
	LD HL,ClusMSG
	call DrawString
	ld a,(FAT_CurrentClusterL+3)
	call Hex2SCR
	ld a,(FAT_CurrentClusterL+2)
	call Hex2SCR
	ld a,(FAT_CurrentClusterL+1)
	call Hex2SCR
	ld a,(FAT_CurrentClusterL+0)
	call Hex2SCR
;	ld a,0dh
;	call DrawaChr
	

	LD HL,SPCMSG
	call DrawString
	ld a,(FAT_SecPerCluster)
	call Hex2SCR
	ld a,' '
	call DrawaChr
	
	LD HL,FSBMSG
	call DrawString
	ld a,(FAT_Sector_Begin_L+3)
	call Hex2SCR
	ld a,(FAT_Sector_Begin_L+2)
	call Hex2SCR
	ld a,(FAT_Sector_Begin_L+1)
	call Hex2SCR
	ld a,(FAT_Sector_Begin_L+0)
	call Hex2SCR
	ld a,' '
	call DrawaChr
	
	LD HL,SOCMSG
	call DrawString
	ld a,(FAT_SectorOfCluster)
	call Hex2SCR
	ld a,' '
	call DrawaChr

	LD HL,SPCMSG
	call DrawString
	ld a,(FAT_SecPerCluster)
	call Hex2SCR
	ld a,0dh
	call DrawaChr
	





	call GETKEY
	cp ' '
	jr z, endroutine2
	
	
	pop HL
	pop de
	pop bc
	pop af
	ret

endroutine2:
	pop HL
	pop de
	pop bc
	pop af
	jp MAIN

SOCMSG:
	.DB "SOC:",00
SPCMSG:
	.DB "SPC:",00
FSBMSG:
	.DB "FSB:",00
SecMSG:
	.DB "SECTOR:",00
ClusMSG:
	.DB "CLUSTER:",00
