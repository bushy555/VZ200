SAVE: 

	;Things we need to do behind the scenes to save a 'file' to SD
	
	;Get the file name
	;Get the file Size
	;Work out how many sectors we'll need 
	;Work out how many clusters we'll need
	;Find unused clusters, link them
	;Look for a blank entry in the file table
	;If there is none, we link a new cluster to the file table
	;Make an entry into the file table. Name, Size, First Cluster
	;Build the .VZ header
	;Start saving to sectors, following the cluster chains.

;1. Get the File name
	ld HL,CLIBUFFER + 5
	ld DE,FileName
	ld b,8
S1:
	ld a,(HL)
	cp 0
	jr nz,S2
	ld a,' '
S2:
	ld (DE),a
	inc hl
	inc de
	dec b
	jr nz,S1
	ld a,'V'
	ld (DE),a
	inc de
	ld a,'Z'
	ld (DE),a
	inc de
	ld a,' '
	ld (DE),a
	
;2. Get the file Size
;	We can use the Basic Start and End address for a Basic save
;	Or we can use user-input to overwrite
;   Or we can use the detected memory size from Basic







FindFile:
	ld a,0
	ld (FileFound),a ;Set the default as not found

fDIR:
;Pass over E5h entries
;00 entried indicates end of directory
;512 bytes per sector
;32bytes per entry
;16 entries per sector
	call Fat32_Root ;Change this!!!! Needs to point to Current Directory Cluster
	xor a;
	ld (DIR_FileCount),a	;zero file counter
	ld (DIR_EntryCount),a
	ld (DIR_FolderCount),a
fDIR_FileLoopUpper:
	ld HL,RAMBUFFER
fDIR_FileLoop:
	ld a,(HL)
	cp 00
	jp z, fDIR_EndOfDirectory
	cp 0E5h
	jp z, fDIR_DeletedEntry
	cp 01h ;LFN
	jp z, fDIR_DeletedEntry
	
	push HL
	ld DE,11
	add hl,de
	ld a,(HL)
	pop HL
	cp 20h
	jp z, fDIR_IsFile
	cp 08h
	jp z, fDIR_IsLabel
	cp 10h
	jp z, fDIR_IsFolder
	;else
	jp fDIR_DeletedEntry
	
fDIR_IsFile:	
	ld a,(DIR_FileCount)
	inc a
	ld (DIR_FileCount),a
	call fDIR_ShowFileInfo
	jp fDIR_DeletedEntry

fDIR_IsLabel:	
	jp fDIR_DeletedEntry
	
fDIR_IsFolder:	
	jp fDIR_DeletedEntry

fDIR_DeletedEntry:
	;increment HL by 15
	ld de,0032
	add HL,de
	;Check sector overflow
	ld a,(DIR_EntryCount)
	inc a
	ld (DIR_EntryCount),a
	cp 16
	jp nz, fDIR_FileLoop
	xor a
	ld (DIR_EntryCount),a
	call FAT_NextSector
	jp fDIR_FileLoopUpper
	
fDIR_ShowFileInfo: ;Write filename, size, attributes
;	push HL
;	ld b,8 ;8.3
;DIR_SFI:
;	ld a,(HL)
;	call DrawChr
;	cp 32
;	jp z,NoTXspace
;	call SerialChr
;NoTXspace:
;	inc HL
;	djnz DIR_SFI
;	ld a,'.'
;	call DrawChr
;	call SerialChr
;	ld b,3 ;8.3
;DIR_SFI2:
;	ld a,(HL)
;	call DrawChr
;	call SerialChr
;	inc HL
;	djnz DIR_SFI2

;	ld a,CR
;	call SerialChr
;	ld a,LF
;	call SerialChr
	
;	ld a,' '
;	call DrawChr
;	ld a,' '
;	call DrawChr
;
;	pop HL
	push HL
	push DE
	push BC
	ld c,11 ;file name len
	ld DE,FileName
FileSearchLoop:
	ld a,(DE)
	ld b,a
	ld a,(HL)
	cp b
	jr nz, FileMissmatch
	inc DE
	inc HL
	dec c
	jr nz,FileSearchLoop
	ld a,1
	ld (FileFound),a ;Mark as file found
	;Preserve all the stuff
	
	ld de,10
	add hl,de
	ld de,FileCluster+3
	ld a,(HL)
	ld (DE),a
	DEC HL
	ld de,FileCluster+2
	ld a,(HL)
	ld (DE),a
	
	ld de,07
	add hl,de
	ld de,FileCluster+1
	ld a,(HL)
	ld (DE),a
	dec hl
	ld de,FileCluster
	ld a,(HL)
	ld (DE),a
	
	inc hl
	inc hl
	ld a,(hl)
	ld (FileSize),a
	
	inc hl
	ld a,(hl)
	ld (FileSize+1),a
	
	inc hl
	ld a,(hl)
	ld (FileSize+2),a
	
	inc hl
	ld a,(hl)
	ld (FileSize+3),a

	ld HL,FFmsg
	call DrawString

	jp SD2RAM

FileMissmatch:	
	pop BC
	pop DE
	pop HL
		
	ret

fDIR_EndOfDirectory:
	;show error msg
	ld HL,FNFmsg
	call DrawString
	jp MAIN


SD2RAM: ;Copy the file from the SD to RAM 

	ld a,(FileCluster)
	ld (FAT_CurrentClusterL),a
;	call Hex2SCR
	ld a,(FileCluster+1)
	ld (FAT_CurrentClusterL+1),a
;	call Hex2SCR
	ld a,(FileCluster+2)
	ld (FAT_CurrentClusterH),a
;	call Hex2SCR
	ld a,(FileCluster+3)
	ld (FAT_CurrentClusterH+1),a
;	call Hex2SCR

 ;   ld a,' '
 ;  call DrawaChr
    	
	call FAT_Cluster2Sector

	call FAT_Get_Sector

	ld a,1 ;File in use
	ld (FileReadComplete),a

	ld a,(FileSize+1)
	ld (FileSizeIn256),a
	


FileLoadBankLoop:




	ld a,(RAMBUFFER+17H)
	ld d,a
	ld (FileBaseAddress+1),a
	ld a,(RAMBUFFER+16H)
	ld (FileBaseAddress),a
	ld e,a

	ld (78A4h),DE

;	ld DE,7AE9h ;Destination

	ld a,(RAMBUFFER+15H)
	ld (FileType),a
	

	
	;set up for first sector, skip the header info.
	ld HL,RAMBUFFER+18h
	ld b,255-17h
	jr FileLoadLoop1
	
FileLoadSectorLoop:
	ld b,0
FileLoadLoop1Pre:
	ld HL,RAMBUFFER
FileLoadLoop1:


	ld a,(HL)
	ld (DE),a
	inc HL
	inc DE
	dec b
	jr nz,FileLoadLoop1

	ld a,(FileSizeIn256)
	dec a
	ld (FileSizeIn256),a
	inc a
	cp 0
	jp z,FileLoadComplete


FileLoadLoop2:
	ld a,(HL)
	ld (DE),a
	inc HL
	inc DE
	dec b
	jr nz,FileLoadLoop2


	call FAT_NextSector
;	call Debug ;Show registers and sec/clusters

	ld a,(FileSizeIn256)
	dec a
	ld (FileSizeIn256),a
	inc a
	cp 0
	jp z,FileLoadComplete

	ld a,'.'
	call DrawaChr
	
	
	jr FileLoadLoop1Pre
		
	
FileLoadComplete:	

	;Calculate end of program in basic (7AF4)
	;FileSize - 17h + (7AE9 or 8000 ) - RAMHI seems to work.

	ld a,(FileType)
	cp 0F0h
	jp z,FileTypeBasic
	cp 0F1h
	jp z,FileTypeBinary
		
;	CALL Hex2SCR
	
	ld HL,UnknownMSG
	call DrawString
	jp FLCC
	
FileTypeBasic:
	ld HL,FTBMSG
	call DrawString
	
	;calc file size, start address, fill end address

	;File Size - 
	ld a,(FileSize+1)
	ld d,a
	ld a,(FileSize)
	ld e,a
	;DE contains file size
	ld HL,(FileBaseAddress)
	add HL,DE
	ld (78f9h),HL
	
;	ld a,(FileSize+1)
;	call Hex2SCR
;	ld a,(FileSize)
;	call Hex2SCR
;	ld a,' '
;	call DrawaChr

;	ld a,(FileBaseAddress+1) 
;	call Hex2SCR
;	ld a,(FileBaseAddress)
;	call Hex2SCR
;	ld a,' '
;	call DrawaChr
	
;	ld a,(78fAh)
;	call Hex2SCR
;	ld a,(78f9h)
;	call Hex2SCR
;	ld a,' '
;	call DrawaChr


;	ld a,(FileSizeIn256)
;	call Hex2SCR
;	ld a,' '
;	call DrawaChr
	
	jp FLCC
	
FileTypeBinary:
	ld HL,FTBinMSG
	call DrawString
	jp FLCC
	
	
	
FLCC:

	ld HL,RAMaddMSG
	call DrawString
	ld a,(FileBaseAddress+1)
	call Hex2SCR
	ld a,(FileBaseAddress)
	call Hex2SCR
	LD A,0DH
	call DrawaChr

	ld hl,PressSpace2BootMSG
	CALL DrawString
	
FLCC2:
		call GETKEY
		cp ' '
		jp z, RUNGAME
	
;	jp BASIC
	jp MAIN
;	ret

RUNGAME: ;If binary, jump to FileBaseAddress, else BASIC
	ld a,(FileType)
	cp 0F0h
	jr z, BasicGame
BinaryGame:
	ld HL,(FileBaseAddress)
	
	jp (HL)

BasicGame:
	call BASIC

PressSpace2BootMSG:
	.db "PRESS SPACE TO RUN",0DH,00
FTBinMSG:
	.db 0dh,"FILE TYPE BINARY",0dh,00
FTBMSG:
	.db 0dh,"FILE TYPE BASIC",0dh,00
UnknownMSG:
	.db 0dh,"FILE TYPE UNKNOWN",0dh,00
RAMaddMSG:
	.db "AT ADDRESS:",00h
FNFmsg:
	.db "FILE NOT FOUND",0dh,00
FFmsg:
	.db "FILE FOUND",0dh,00

