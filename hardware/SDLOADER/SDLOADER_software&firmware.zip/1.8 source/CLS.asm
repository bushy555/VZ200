CLS:	;Clear sCReen, No arguments
	CALL CLSsub
	jp MAIN
