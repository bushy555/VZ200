
OUT:	;WRITE Arg2 to Port Arg1
	ld HL,CLIBUFFER+04h ;start of data arguments
	call Arg2Byte ;point HL to argument, return byte in A
	ld c,a

	ld HL,CLIBUFFER+07h ;start of data arguments
	call Arg2Byte ;point HL to argument, return byte in A
	

	out (c),a
	jp MAIN	
