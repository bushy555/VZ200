
WRITE:	;WRITE AAAA:DDDDDDDDDDD
	ld HL,CLIBUFFER+6
	call Arg2Word ;point HL to argument, return word in DE
	ld HL,CLIBUFFER+0bh ;start of data arguments
WRITEWord:
	ld a,(HL)
	cp 0
	jr z,EndOfData
	cp 20h
	jr z,EndOfData
	call Arg2Byte ;Point HL to argument, return in A
	ld (DE),A
	inc DE
	jr WRITEWord	

EndOfData:
	jp MAIN

