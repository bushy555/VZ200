COPY:	;Copy Arg1 to Arg2, Arg3 bytes
	ld HL,CLIBUFFER+5
	call Arg2Word ;point HL to argument, return word in DE
	push DE ;The source address
	ld HL,CLIBUFFER+0Ah ;start of data arguments
	call Arg2Word ;point HL to argument, return word in DE
	push DE ;The Destnaton address
	ld HL,CLIBUFFER+0Fh ;start of data arguments
	call Arg2Word ;point HL to argument, return word in DE
	push DE ;The number of bytes

	pop BC ;num of byptes
	pop HL ;Destinaton
	pop DE ;Source

	ld a,b
	or c
	cp 0 
	jp z,MAIN ;Bytes = 0
	
CopyByte:
	ld a,(DE)
	ld (HL),a
	inc DE
	inc HL
	dec bc
	ld a,b
	or c
	cp 0
	jr nz,CopyByte

	jp MAIN
