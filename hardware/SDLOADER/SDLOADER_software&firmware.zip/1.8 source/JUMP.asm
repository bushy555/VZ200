
JUMP:	;Jump to Arg1
	ld HL,CLIBUFFER+05h
	call Arg2Word ;point HL to argument, return word in DE
	ex de,hl
	jp (HL)
