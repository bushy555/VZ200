Hi!

Foremost, apologies for the state of this code! It is a mashup of Gameboy assembly and Zilog which although close to the Z80, it's very much not! Note: I'm not an expert in this!

Best experienced in Geany text editor. Run make.bat and it should compile right away without any issues. I've heard TASM has issues in win10, not sure. Maybe use compatibility mode?

It is somewhat modular, most commands are split into their own asm files.

If you want to add code, CLI is my command line interperter. You can add to the two lookup tables and include your own asm. Hopefully you can gather what is going on from the various commands I've added.

If you want to add BASIC instructions, take a look in VZDOS.ASM. It isn't a full lookup table because every time basic steps through a line of code, it will call this function. Keep it fast! or your basic programs will suffer.

Save a file with SaveFile - Populate FileName first, it'll use Basic start and end address offsets for file size.

LoadFile is the same more or less.

It all looks reasonable to me but to others it's probably a bit of a mess. Happy to answer any questions.

Oh the main asm file is VZDOS.ASM and all my definitions are in the Includes file.

Don't forget to comment out the Look4VZDOS call if you're making a SD bootable firmware, and add it if you're flashing to an EPROM.

I think that's it. Please don't share this code beyond our FB group. 

Feel free to optimise my code!
