LOAD: ;Find the file
	;Read CLIBUFER + 5-13
	ld HL,CLIBUFFER + 5
	ld DE,FileName
	ld b,8
L1:
	ld a,(HL)
	cp 0
	jr nz,L2
	ld a,' '
L2:
	ld (DE),a
	inc hl
	inc de
	dec b
	jr nz,L1
	ld a,'V'
	ld (DE),a
	inc de
	ld a,'Z'
	ld (DE),a
	inc de
	ld a,' '
	ld (DE),a
	
;	jp MAIN

	call FindFile

	LD hl,FFmsg
	call DrawString

	ld a,(FileFound)
	cp 0
	jp z, MAIN

	;file is found
	call SD2RAM ;Move it from SD to RAM in accordance with VZ header

	call FileLoadAskToBoot ;Ask if we want to boot it, or return to CLI
	ret
	
FindFile:
	ld a,0
	ld (FileFound),a ;Set the default as not found

fDIR:
;Pass over E5h entries
;00 entried indicates end of directory
;512 bytes per sector
;32bytes per entry
;16 entries per sector
	call Fat32_Root ;Change this!!!! Needs to point to Current Directory Cluster
	xor a;
	ld (DIR_FileCount),a	;zero file counter
	ld (DIR_EntryCount),a
	ld (DIR_FolderCount),a
fDIR_FileLoopUpper:
	ld HL,RAMBUFFER
fDIR_FileLoop:
	ld a,(HL)
	cp 00
	jp z, fDIR_EndOfDirectory
	cp 0E5h
	jp z, fDIR_DeletedEntry
	cp 01h ;LFN
	jp z, fDIR_LongFileName
	
	push HL
	ld DE,11
	add hl,de
	ld a,(HL)
	pop HL
	cp 20h
	jp z, fDIR_IsFile
	cp 08h
	jp z, fDIR_OtherType;fDIR_IsLabel
	cp 10h
	jp z, fDIR_OtherType;fDIR_IsFolder
	;else
	jp fDIR_OtherType
	
fDIR_IsFile:	
	ld a,(DIR_FileCount)
	inc a
	ld (DIR_FileCount),a
	call fDIR_ShowFileInfo
	jp fDIR_OtherType;fDIR_DeletedEntry

fDIR_IsLabel:	
	jp fDIR_DeletedEntry
	
fDIR_IsFolder:	
	jp fDIR_DeletedEntry

fDIR_DeletedEntry:

	ld a,(FindDirectoryEntry)
	cp 1
	ret z
fDIR_OtherType:

fDIR_LongFileName:
	ld a,(FileFound)
	cp 1
	ret z
	;increment HL by 15
	ld de,0032
	add HL,de
	;Check sector overflow
	ld a,(DIR_EntryCount)
	inc a
	ld (DIR_EntryCount),a
	cp 16
	jp nz, fDIR_FileLoop
	xor a
	ld (DIR_EntryCount),a
	call FAT_NextSector
	jp fDIR_FileLoopUpper
	
fDIR_ShowFileInfo: ;Write filename, size, attributes
	push HL
	push DE
	push BC
	ld c,11 ;file name len
	ld DE,FileName
FileSearchLoop:
	ld a,(DE)
	ld b,a
	ld a,(HL)
	cp b
	jr nz, FileMissmatch
	inc DE
	inc HL
	dec c
	jr nz,FileSearchLoop
	ld a,1
	ld (FileFound),a ;Mark as file found
	;Preserve all the stuff
	
	ld de,10
	add hl,de
	ld de,FileCluster+3
	ld a,(HL)
	ld (DE),a
	DEC HL
	ld de,FileCluster+2
	ld a,(HL)
	ld (DE),a
	
	ld de,07
	add hl,de
	ld de,FileCluster+1
	ld a,(HL)
	ld (DE),a
	dec hl
	ld de,FileCluster
	ld a,(HL)
	ld (DE),a
	
	inc hl
	inc hl
	ld a,(hl)
	ld (FileSize),a
	
	inc hl
	ld a,(hl)
	ld (FileSize+1),a
	
	inc hl
	ld a,(hl)
	ld (FileSize+2),a
	
	inc hl
	ld a,(hl)
	ld (FileSize+3),a

;	ld HL,FFmsg
;	call DrawString

	;File Found
	pop BC
	pop DE
	pop HL
		
	ret

FileMissmatch:	
	pop BC
	pop DE
	pop HL
		
	ret

fDIR_EndOfDirectory:
	ld a,(FindDirectoryEntry)
	cp 1
	jr nz,NotLookingForBlankEntry
	;Current sector, HL is the offset to the file entry.
	ret
	
	
NotLookingForBlankEntry:
	;show error msg
	ld HL,FNFmsg
	call DrawString
	;Fie not found

	ret


SD2RAM: ;Copy the file from the SD to RAM 

	ld a,(FileCluster)
	ld (FAT_CurrentClusterL),a
	ld a,(FileCluster+1)
	ld (FAT_CurrentClusterL+1),a
	ld a,(FileCluster+2)
	ld (FAT_CurrentClusterH),a
	ld a,(FileCluster+3)
	ld (FAT_CurrentClusterH+1),a

    	
	call FAT_Cluster2Sector

	call FAT_Get_Sector

	ld a,1 ;File in use
	ld (FileReadComplete),a

	ld a,(FileSize+1)
	ld (FileSizeIn256),a
	
FileLoadBankLoop:
	ld a,(RAMBUFFER+17H)
	ld d,a
	ld (FileBaseAddress+1),a
	ld a,(RAMBUFFER+16H)
	ld (FileBaseAddress),a
	ld e,a

	ld (78A4h),DE
;	ld DE,7AE9h ;Destination

	ld a,(RAMBUFFER+15H)
	ld (FileType),a
	
	;set up for first sector, skip the header info.
	ld HL,RAMBUFFER+18h
	ld b,255-17h
	jr FileLoadLoop1
	
FileLoadSectorLoop:
	ld b,0
FileLoadLoop1Pre:
	ld HL,RAMBUFFER
FileLoadLoop1:

	ld a,(HL)
	ld (DE),a
	inc HL
	inc DE
	dec b
	jr nz,FileLoadLoop1

	ld a,(FileSizeIn256)
	dec a
	ld (FileSizeIn256),a
	inc a
	cp 0
	jp z,FileLoadComplete

FileLoadLoop2:
	ld a,(HL)
	ld (DE),a
	inc HL
	inc DE
	dec b
	jr nz,FileLoadLoop2

	call FAT_NextSector

	ld a,(FileSizeIn256)
	dec a
	ld (FileSizeIn256),a
	inc a
	cp 0
	jp z,FileLoadComplete

	ld a,'.'
	call DrawaChr
	
	jr FileLoadLoop1Pre
			
FileLoadComplete:	

	ret

FileLoadAskToBoot:

	;Calculate end of program in basic (7AF4)
	;FileSize - 17h + (7AE9 or 8000 ) - RAMHI seems to work.

	ld a,(FileType)
	cp 0F0h
	jp z,FileTypeBasic
	cp 0F1h
	jp z,FileTypeBinary
			
	ld HL,UnknownMSG
	call DrawString
	jp FLCC
	
FileTypeBasic:
	ld HL,FTBMSG
	call DrawString
	;calc file size, start address, fill end address
	;File Size - 
	ld a,(FileSize+1)
	ld d,a
	ld a,(FileSize)
	ld e,a
	;DE contains file size
	
	ld HL,(FileBaseAddress)
	add HL,DE
	
;we need to subtract 24 (VZheader) from file size

	ld b,24
FTB1:
	dec HL
	dec b
	jr nz,FTB1
	
	ld (78f9h),HL
	jp FLCC
	
FileTypeBinary:
	ld HL,FTBinMSG
	call DrawString
	jp FLCC
	
FLCC:

	ld HL,RAMaddMSG
	call DrawString
	ld a,(FileBaseAddress+1)
	call Hex2SCR
	ld a,(FileBaseAddress)
	call Hex2SCR
	LD A,0DH
	call DrawaChr

	ld hl,PressSpace2BootMSG
	CALL DrawString
	
FLCC2:
		call GETKEY
		cp ' '
		jp z, RUNGAME
	
	jp MAIN

RUNGAME: ;If binary, jump to FileBaseAddress, else BASIC
	ld a,(FileType)
	cp 0F0h
	jr z, BasicGame
BinaryGame:
	DI
	ld HL,(FileBaseAddress)
	
	jp (HL)

BasicGame:
	call BASIC

PressSpace2BootMSG:
	.db "PRESS SPACE TO RUN",0DH,00
FTBinMSG:
	.db 0dh,"FILE TYPE BINARY",0dh,00
FTBMSG:
	.db 0dh,"FILE TYPE BASIC",0dh,00
UnknownMSG:
	.db 0dh,"FILE TYPE UNKNOWN",0dh,00
RAMaddMSG:
	.db "AT ADDRESS:",00h
FNFmsg:
	.db "FILE NOT FOUND",0dh,00
FFmsg:
	.db "FILE FOUND",0dh,00
