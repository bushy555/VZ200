TASM VZDOS.ASM -80 -b
copy /b header.bin + vzdos.obj VZDOS.VZ
pause