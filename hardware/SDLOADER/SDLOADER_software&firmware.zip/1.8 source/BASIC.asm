
BASIC:	;Jump to Basic Warmstart
	jp 06A0h
