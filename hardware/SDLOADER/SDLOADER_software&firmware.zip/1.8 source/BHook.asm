BasicInterpreter:
	;Command and arguments are in 0x2000 "Command",0x20,"Agr1",0x20,"Arg2",0x20,"Arg...",0x00
	;If match, jump to routine
	LD HL,CommandList
	LD B,00H ;Command number count
BCommandSearchAlpha:
	ld DE,79E8h;CLIBUFFER ;Source String Location 
BCommandSearch:
	LD a,(DE) ;Get Source value
	
	;force upper case
	bit 5,a
	jr z,Bnumesc
	and 0DFh
	
Bnumesc:
	cp (HL) ;Compare with CommandList value
	inc HL
	inc DE
	jp z,BLetterMatch
	ld a,(DE)
	cp 20H ;compare for space chr (assumed argument)
	jp z,BNoCommandFound ;End of command reached
	cp 0H ;compare for nul chr (assumed no argument)
	jp z,BNoCommandFound ;End of command reached
	
BAdvanceCommand:
	ld a,(HL)
	inc HL
	cp 0FFH ;check for end of command list
	jp z,BNoCommandFound
	cp 00H
	jp nz,BAdvanceCommand
	inc b
	JP BCommandSearchAlpha	

BLetterMatch:
	ld a,(DE)
	cp 20H ;compare for space chr
	jp z,BCommandMatch
	cp 0H ;compare for space chr
	jp z,BCommandMatch
	ld a,(HL)
	cp 0FFH
	JP z,BNoCommandFound	
	jp BCommandSearch

BCommandMatch: ;match for all chrs up to the space
	ld a,(HL)
	cp 00 ; compare for CR/LF
	jp z, BContinueMatch
	jp BCommandSearchAlpha
BContinueMatch:
	ld DE,CommandRoutineAddress
	inc b
BCM1:	dec b
	jp z,BCMJump
	inc DE
	inc DE
	jp BCM1
BCMJump:
	ld a,(DE)
	ld L,a
	inc DE
	ld a,(DE)
	ld H,a
	JP (HL)
BNoCommandFound:
	LD HL,InvalidCmd
	CALL DrawString
	jp 1D78h
BNoCommand:
	ld a,CR
	call DrawChr
	jp 1D78h
