MAIN: ;Return is only CR, not LF. Add that too.
	;Command ram is $2000, clear it with nulls
	xor a
	ld b,255
	ld hl,CLIBUFFER

ClrBuff:
	ld (HL),a
	inc HL
	djnz ClrBuff
	;CRam Count is $2100
	ld HL,CLIBUFFER+100h
	ld a,0 ;zero it
	ld (HL),a
	;Prompt will be >
	ld a,'>'
	call DrawChr


MAINChrParser: ;gets keys and sorts the good from the bad
	call GETKEY
	cp 13
	jp z,MAIN_CR_Detect
;	cp LF
;	jp z,MAIN_LF_Detect
	cp 8
	jp z,MAIN_BS_Detect
		;else 
	ld b,a
	ld HL,CLIBUFFER+100h
	ld a,(HL)
	ld hl,CLIBUFFER
	add a,l
	ld l,a
	ld (HL),b    ;calculate location and store chr
	ld a,b
	ld HL,CLIBUFFER+100h
	inc (HL)
	call DrawChr


	jp MAINChrParser

MAIN_BS_Detect:
	;BAck Space detected, bs, space, bs
	ld HL,CLIBUFFER+100h
	ld a,(HL)
	cp 0
	jp z, MAINChrParser
	
	ld a,8;BS
	call DrawChr
	ld a,' '
	call DrawChr
	ld a,8;BS
	call DrawChr ;the lcd is one chr cleared
			;now lets do the buffer
	ld HL,CLIBUFFER+100h
	ld a,(HL)
	cp 0
	jp z, SkipDeCRement
	dec (HL) ;dec the buffer count
SkipDeCRement:
	ld HL,CLIBUFFER+100h
	ld a,(HL)
	ld hl,CLIBUFFER
	add a,l
	ld l,a
	ld b,0
	ld (HL),b    ;calculate location and store chr
	;should be done here?
	
	jp MAINChrParser		
		

MAIN_CR_Detect:
MAIN_LF_Detect:
	LD a,(CLIBUFFER) ;Get Source value
	cp 00
	jp z,NoCommand	

	ld a,CR
	call DrawChr
;	ld a,LF
;	call DrawChr
	call Interpreter
	jp MAIN
	
	
Interpreter:
	;Command and arguments are in 0x2000 "Command",0x20,"Agr1",0x20,"Arg2",0x20,"Arg...",0x00
	;If match, jump to routine
	LD HL,CommandList
	LD B,00H ;Command number count
CommandSearchAlpha:
	ld DE,CLIBUFFER ;Source String Location 
CommandSearch:
	LD a,(DE) ;Get Source value
	
	;force upper case
	bit 5,a
	jr z,numesc
	and 0DFh
	
numesc:
	cp (HL) ;Compare with CommandList value
	inc HL
	inc DE
	jp z,LetterMatch
	ld a,(DE)
	cp 20H ;compare for space chr (assumed argument)
	jp z,NoCommandFound ;End of command reached
	cp 0H ;compare for nul chr (assumed no argument)
	jp z,NoCommandFound ;End of command reached
	
AdvanceCommand:
	ld a,(HL)
	inc HL
	cp 0FFH ;check for end of command list
	jp z,NoCommandFound
	cp 00H
	jp nz,AdvanceCommand
	inc b
	JP CommandSearchAlpha	

LetterMatch:
	ld a,(DE)
	cp 20H ;compare for space chr
	jp z,CommandMatch
	cp 0H ;compare for space chr
	jp z,CommandMatch
	ld a,(HL)
	cp 0FFH
	JP z,NoCommandFound	
	jp CommandSearch

CommandMatch: ;match for all chrs up to the space
	ld a,(HL)
	cp 00 ; compare for CR/LF
	jp z, ContinueMatch
	jp CommandSearchAlpha
ContinueMatch:
	ld DE,CommandRoutineAddress
	inc b
CM1:	dec b
	jp z,CMJump
	inc DE
	inc DE
	jp CM1
CMJump:
	ld a,(DE)
	ld L,a
	inc DE
	ld a,(DE)
	ld H,a
	JP (HL)
NoCommandFound:
	LD HL,InvalidCmd
	CALL DrawString
	JP MAIN
NoCommand:
	ld a,CR
	call DrawChr
	JP MAIN
	
CommandList:
.DB "BASIC",00h
;.DB "NEXT",00H
.DB "CLS",00H
.DB "IN",00H
.DB "OUT",00H
;.DB "BEEP",00H
;.DB "READ",00H
.DB "WRITE",00H
.DB "JUMP",00H
;.DB "CALL",00H
;.DB "SerIn",00H
;.DB "SerOut",00H
.DB "LOAD",00H
;.DB "Save",00H
.DB "FILL",00H
.DB "COPY",00H
.DB "HEXVIEW",00H
;.DB "CFINIT",00H
;.DB "CFINFO",00H
;.DB "CFREAD",00H
;.DB "CFWRITE",00H
;.DB "CFSTATUS",00H
.DB "HELP",00H
;.DB "FAT",00H
;.DB "ROOT",00H
.DB "DIR",00H
.DB "RUN",00H
.DB 0FFH

CommandRoutineAddress:
.DW BASIC
;.DW FATNEXT
.DW CLS
.DW IN
.DW OUT
.DW BACKUP
;.DW BEEP
;.DW READ
.DW WRITE
.DW JUMP
;.DW CALLr
;.DW SerIn
;.DW SerOut
.DW LOAD
;.DW Save
.DW Fill
.DW COPY
.DW HEXVIEW
;.DW CFINIT
;.DW CFINFO
;.DW CFREAD
;.DW CFWRITE
;.DW CFSTATUS
.DW HELP
;.DW FAT32
;.DW ROOT
.DW DIR
.DW RUNGAME

;MSG_Beep:
;.DB "Boop!"
;.DB 0DH,0AH,'$'
;MSG_CLS:
;.DB "Clear!"
;.DB 0DH,0AH,'$'
;MSG_Peek:
;.DB "Whats in there?"
;.DB 0DH,0AH,'$'
MSG_ArgErr
.DB "ARGUMENT ERROR",0dh,00


MSG_Boot:
.DB "CLI V0.0",0dh,0
InvalidCmd:
.DB "INVALID COMMAND",0dh,00
	
	

.include "BASIC.asm"
.include "CLS.asm"
.include "IN.asm"
.include "Out.asm"
.include "Backup.asm"
;.include "Beep.asm"
;.include "Read.asm"
.include "Write.asm"
.include "JUMP.asm"
;.include "Call.asm"
;.include "SerIn.asm"
;.include "SerOut.asm"
.include "Load.asm"
;.include "Save.asm"
.include "Fill.asm"
.include "Copy.asm"
;.include "Type.asm"
.include "HexView.asm"
;.include "CF.asm"
.include "Help.asm"
.include "Dir.asm"

