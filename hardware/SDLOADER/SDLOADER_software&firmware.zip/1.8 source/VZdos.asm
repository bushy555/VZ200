
.org 4000h
	.DB 0AaH,055H,0E7h,018H ;Magic String

DOSstart:

	DI
	ld HL,7ae9h
	ld (78A4h),HL ;reset the basic start pointer
	
	ld HL,BasicCommandInterpreter
	ld (7804h),HL ;1d78
	
	LD sp,0ffffH
			
	call CLSsub

	call RAMTEST

	ld HL,BootMSG
	call DrawString

	call InitSD

	ld a,(ErrorLevel)
	cp 1
	jr z,VZDOSnotFound

	;If you are compiling this for a SD boot file, comment the next line 
	;out or else it'll get stuck in a constant boot loop
	call Look4VZDOS ;Don't look for it again or it'll be a boot loop!

VZDOSnotFound:

	CALL InKey
	
	CP ' '
	JP Z,MAIN

	JP BASIC
	
Look4VZDOS:
	ld HL,LOOK4VZ
	call DrawString
	
	ld HL,VZdosfilename
	ld DE,FileName
	ld b,11
Ld1:
	ld a,(HL)
	ld (DE),a
	inc HL
	inc DE
	dec b
	jr nz,Ld1
		
	call FindFile
	ld a,(FileFound)
	cp 1
	jp z, VZDOSfound

	ret

VZDOSfound:

	call SD2RAM ;Move it from SD to RAM in accordance with VZ header
	;We now have the new VZDOS at $8000. 
	;Disable the EPROM from a safe address

	ld HL,0A000h ;Somewhere safe to execute code from
	ld DE,CodeCopy
	ld b,100
CC0:
	ld a,(DE)
	ld (HL),a
	inc HL
	inc DE
	dec b
	jr nz,CC0
	jp 0A000h
	
CodeCopy:
		ld a,1
		out (MAPPER),a
		
		ld HL,8000h
		ld DE,4000h
CC1:
		ld a,(HL)
		ld (DE),a
		inc HL
		inc DE
		ld a,D
		cp 60h
		jr nz,CC1
		jp 4004h
	

BasicCommandInterpreter: ;This is called every basic instruction.

	;HL contains the first byte of the instruction
	push HL
	ld a,(HL)

	cp 'D'
	jr z,PossibleDIR

	cp 'S'
	jr nz,NoSMatch
	inc HL
	ld a,(HL)

;	cp 'D' ;This was to get back to CLI from Basic. Keypad routine was flakey though
;	jp z, BVentryPoint ;command = SD

	cp 'A'
	jr nz,NoMatch
	inc HL
	ld a,(HL)
	cp 'V'
	jr nz,NoMatch
	inc HL
	ld a,(HL)
	cp 'E'
	jr nz,NoMatch

	Call SaveFile
	ld a,(ErrorLevel)
	cp 1
	jr z,NoMatch
	
	pop HL
	JP 1A19h

PossibleDIR:
	inc HL
	ld a,(HL)
	cp 'I'
	jr nz,NoMatch
	inc HL
	ld a,(HL)
	cp 'R'
	jr nz,NoMatch
	call DIRbasic
	pop HL
	JP 1A19h

NoSMatch:
	cp 'L'
	jr nz,NoMatch
	inc HL
	ld a,(HL)
	cp 'O'
	jr nz,NoMatch
	inc HL
	ld a,(HL)
	cp 'A'
	jr nz,NoMatch
	inc HL
	ld a,(HL)
	cp 'D'
	jr nz,NoMatch
	inc HL
	ld a,(HL)

	call LoadFile
	ld a,(ErrorLevel)
	cp 1
	jr z,NoMatch

	pop HL
	JP 1A19h
	

NoMatch:
	pop HL
	jp 1D78h ;Original command interpereter retrun address
	;	jp 1A19h ;Return address to basic to skip the basic error detect
	
NotOnMyWatch:
	jp 1D78h ;Return address to basic to parse command in basic

GETaKEY: ;Same as GetKey but preserves regs
	push HL
	push DE
	push BC
GK0:
	call InKey
	call InKey
	cp 0
	jr z,GK2 ;
	ld b,a
	ld a, (LastKeyPressed)
	cp b
	jr z,GK0
	ld a,b
	ld (LastKeyPressed),a
	pop BC
	pop DE
	pop HL
	ret
GK2:
	ld (LastKeyPressed),a
	jp GK0

GETKEY: ;returns when a key is pressed
	
	call InKey
	call InKey
	cp 0
	jr z,GETKEY2 ;
	ld b,a
	ld a, (LastKeyPressed)
	cp b
	jr z,GETKEY
	ld a,b
	ld (LastKeyPressed),a
	
	ret
GETKEY2:
	ld (LastKeyPressed),a
	jp GETKEY

	
DrawaChr:
	push AF
	push BC
	push HL
	push DE
	call DrawChr
	pop DE
	pop HL
	pop bc
	pop AF
	ret
.include "loadsave.asm"
.include "Includes.asm"
.include "BHook.asm"
.include "debug.asm"	
.include "FAT32.ASM"
.include "CLI.asm"
.include "SD.asm"
.include "RAMTEST.asm"

BootMSG:
	.DB "SD LOADER V1.4 BY BENNVENN",0DH
	.DB "HOLD SPACE & RST TO START CLI",0DH,00h
ErrorMSG
	.DB "SD INIT ERROR!",0DH,00H
InitOK
	.DB "SD INIT OK!",0DH,00H
FATInitMSG
	.DB "FAT INIT OK",0DH,00H
LOOK4VZ
	.DB "LOOKING FOR VZDOS.VZ",0DH,00H
VZdosfilename
	.DB "VZDOS   VZ "
RootSetMSG
	.DB "STARTING BASIC",0DH,00H

	.END	
	
