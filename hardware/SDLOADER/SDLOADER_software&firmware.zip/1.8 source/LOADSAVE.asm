LoadFile:

	DI	
	;HL contains the argument after LOAD command
	call SetFileName
	ld a,(ErrorLevel)
	cp 1
	ret z ;If there is an error, return
	
	ld a,0
	ld (FindDirectoryEntry),a ;we're not looking for a empty slot
	
	call FindFile

	ld a,(FileFound)
	cp 0
	ret z

	;file is found
	call SD2RAM ;Move it from SD to RAM in accordance with VZ header
	EI ;re enable interrupts
	;If the file is a basic file, return
	;If it is a binary, boot it

	;Calculate end of program in basic (7AF4)
	;FileSize - 17h + (7AE9 or 8000 ) - RAMHI seems to work.

	ld a,(FileType)
	cp 0F0h
	jp z,FileTypeBasic2
	cp 0F1h
	jp z,FileTypeBinary2

	ld HL,UnknownMSG
	call DrawString
	
	ld a,1
	ld (ErrorLevel),a
	ret
			
	
FileTypeBasic2:
	;calc file size, start address, fill end address
	;File Size - 
	ld a,(FileSize+1)
	ld d,a
	ld a,(FileSize)
	ld e,a
	;DE contains file size
	ld HL,(FileBaseAddress)
	add HL,DE

	ld b,24
FTB2:
	dec HL
	dec b
	jr nz,FTB2
	
	
	ld (78f9h),HL
	ret
	
FileTypeBinary2:
	ld HL,FTBinMSG
	call DrawString
	DI
	ld HL,(FileBaseAddress)
	jp (HL)

	
	ret
	
SaveFile

	;Get filename and store in FileName buffer
	;try find it first before we make a new entry
	;If exist, ask if overwrite
	;
	;Find blank entry in file table
	;if none, extend the file table one cluster
	;
	;
	;
	;
	DI
	
	call SetFileName
	ld a,(ErrorLevel)
	cp 1
	ret z ;If there is an error, return
	
	call FindFile

	ld a,(FileFound) ;See if the file is already there
	cp 1
	jP z,AskOverwrite

SF1:
		;Overwrite?? Hmmmm
		;Perhaps just delete the file and make a new entry
		;seems easier than re-sizing a cluster chain.
		;To do: Add a file delete function

	call CalculateFileSize
	
	call CalculateRequiredClusters
	
	call BuildClusterChain

	call CreateFileEntry
	
	call FillFileWithData

	ld HL,SavedMSG
	call DrawString
	
	call Fat32_Root

	ret

FillFileWithData:

	
	;NEW file is made. Cluster chains linked. Now we need to FindFile 
	;to get the cluster start address and save our data.
	call FindFile

	ld a,(FileCluster)
	ld (FAT_CurrentClusterL),a
	ld a,(FileCluster+1)
	ld (FAT_CurrentClusterL+1),a
	ld a,(FileCluster+2)
	ld (FAT_CurrentClusterH),a
	ld a,(FileCluster+3)
	ld (FAT_CurrentClusterH+1),a
    	
	call FAT_Cluster2Sector

	call FAT_Get_Sector
	
	;We have the basic start address
	;We have the basic program length
	;we just need to start writing the data

	;FAT_NextSector will increment the sector and follow chains.
	;It reads but thats ok
	
	;Populate RAMBUFFER with the VZ header 024h bytes

	ld HL,RAMBUFFER
	ld DE,VZheader
	ld b,22

FFWD:
	ld a,(DE)
	ld (HL),a
	inc HL
	inc DE
	dec b
	jr nz,FFWD
	
	ld A,(BasicListingStartAdd)
	ld (HL),A
	inc HL
	ld A,(BasicListingStartAdd+1)
	ld (HL),A
	
	;VZ header is written. File name blank for now...

	ld HL,RAMBUFFER+4
	ld DE,FileName
	ld b,11

FFWD2:
	ld a,(DE)
	ld (HL),a
	inc HL
	inc DE
	dec b
	jr nz,FFWD2
	
	;FIle name populated

	;we now have 512 - 24 bytes of this sector to fill. Lets do it!
	
	ld bc,(BasicListingSize)
	ld HL,RAMBUFFER+24
	ld DE,(BasicListingStartAdd)
FFWD3:
	ld a,(DE)
	ld (HL),a
	inc DE
	inc HL
	dec bc
	
	;test if we have filled the buffer
	ld a,H
	dec a
	dec a
	cp RAMBUFFERhi ;compare with high bytes of RAMbuffer address
	jr z,FFWD4 ;Buffer is full
	ld a,b
	or C
	jr z,FFWD5 ;We're done!
	;test if no more file data remains
	jr FFWD3
	
FFWD4:


	;if we're here that means we need to fill the next sector.
	;call Next sector then fill er up
	push DE
	push BC
	call FAT_Write_Sector ;
	call FAT_NextSector
	pop BC
	pop DE
	ld HL,RAMBUFFER
FFWD4a:
	ld a,(DE)
	ld (HL),a
	inc DE
	inc HL
	dec bc
	
	;test if we have filled the buffer
	ld a,H
	dec a
	dec a
	cp RAMBUFFERhi ;compare with high bytes of RAMbuffer address
	jr z,FFWD4b ;Buffer is full
	ld a,b
	or C
	jr z,FFWD5 ;We're done!
	;test if no more file data remains
	jr FFWD4a

FFWD4b:
	
	push DE
	push BC
	call FAT_Write_Sector ;
	call FAT_NextSector
	pop BC
	pop DE
	ld HL,RAMBUFFER
	jr FFWD4a
	
	

FFWD5:

	call FAT_Write_Sector ;
	
	ret
	
	
CreateFileEntry:
	;Find Blank entry or deleted entry and use that
	ld a,1
	ld (FindDirectoryEntry),a ;we're looking for a empty slot
							  ;FindFile will return on first detection
							  
	call FindFile

	push HL
	ld HL,CreatingMSG
	call DrawString
	pop HL

	;Current Sector and HL points to sector and offset of blank entry
	;Lets fill that entry
	ld DE,FileEntryTemplate
	ld b,32
	push HL
CFE1:
	ld a,(DE)
	ld (HL),a
	inc DE
	inc HL
	dec b
	jr nz,CFE1
	pop HL
	;Populate the File size and Location entries then write sector
	
	ld DE,FileName
	ld b,8
CFE2:
	ld a,(DE)
	ld (HL),a
	inc hl
	inc de
	dec b
	jr nz,CFE2

	ld a,'V'
	ld (HL),a
	inc hl
	ld a,'Z'
	ld (HL),a
	inc hl
	ld a,' '
	ld (HL),a
	inc hl

	;Filename has been populated. Next up is
	or a
	ld a,9 ;add 9 to get to High Cluster
	add a,l
	ld l,a
	ld a,0
	adc a,h
	ld h,a
	
	ld DE,NewFileCurrentCluster+2
	ld a,(DE)
	ld (HL),a
	inc DE
	inc HL
	ld a,(DE)
	ld (HL),a
	inc DE
	inc HL

	inc HL
	inc HL
	inc HL
	inc HL
	;file cluster low word
	ld DE,NewFileCurrentCluster
	ld a,(DE)
	ld (HL),a
	inc DE
	inc HL
	ld a,(DE)
	ld (HL),a
	inc DE
	inc HL
	;File size
	ld DE,NewFileSize
	ld a,(DE)
	ld (HL),a
	inc HL
	inc DE
	ld a,(DE)
	ld (HL),a
	inc HL
	inc DE
	ld a,0
	ld (HL),a
	inc HL
	ld a,0
	ld (HL),a
	inc HL
	
	;
	
	call FAT_Write_Sector
	
	ret


CalculateFileSize:	;Calculate file size

	;File begin address in (78A4h)
	;File end address in (78f9h)
	
	ld HL,(78A4h)
	ld (BasicListingStartAdd),HL
	ld DE,(78F9h)
	ld (BasicListingEndAdd),DE
	or a
	ld a,e
	sub L
	ld c,a	
	jr nc, NoSubCarry
	inc H
NoSubCarry:
	ld a,D
	sub H
	ld b,a

	ld (BasicListingSize),BC
		
	ld HL,024h ;size of the VZ header
	add HL,BC
	
	ld (NewFileSize),HL

	ret

CalculateRequiredClusters: ;work out how many clusters for file size
	ld a,(FAT_SecPerCluster) ; 1 bytes
							;Cluster sizes 512, 1k, 2k, 4k, 8k, 16k,32k
	
	ld b,0
CRC0:
	inc b
	or a
	rr a
	cp 0
	jr nz,CRC0
	
	ld HL,(NewFileSize)

	ld a,b
	add a,8

;	call Hex2SCR

	ld b,a

CRC:
	or a
	RR H
	RR L
	dec b
	jr nz,CRC
	ld a,L
	add a,1
	ld (NewFileClusters),a
;	call Hex2SCR ;;How how many sectors we need

	
;	ld a,' '
;	call DrawaChr
	ret

BuildClusterChain: ; Find empty clusters and link them
	DI
		;First empty cluster, mark it as the last, we'll work backwards

;	ld B,(NewFileClusters) ;number of clusters to link
	xor a
	ld (NewFileClusterCount),a
	
	ld HL,0
	ld DE,2h ;cluster entry 00000002h. 

Look4FreeCluster:
	
	push HL
	push DE
	call FAT_GetClusterValue ;Returns 0 if free, else not free
	pop DE
	pop HL
	cp 0
	jp z, FoundFreeCluster
	
	ex DE,HL ;Add 1 to Cluster counter
	ld bc,1
	or a
	add HL,BC
	ld bc,0
	ex DE,HL
	adc HL,BC
	
	jr Look4FreeCluster
	ret

FoundFreeCluster:
	;HL:DE contains free cluster.
	;If NewFileClusterCount = 0 then mark FFFFFF0F
		
	ld a,(NewFileClusterCount)
	cp 0
	jr z,MarkLastCluster
	jr MarkNextCluster
	
ContMarkingClusters:
	ld a,(NewFileClusters)
	dec a	
	ld (NewFileClusters),a
	cp 0
	jr nz,Look4FreeCluster
	
	ret
MarkLastCluster:
	ld a,(NewFileClusterCount)
	inc a
	ld (NewFileClusterCount),a
	;HL:DE is location of cluster to mark
	;NewFileCurrentCluster is the data to write
	ld a,0ffh
	ld (NewFileCurrentCluster),a
	ld (NewFileCurrentCluster+1),a
	ld (NewFileCurrentCluster+2),a
	ld a,0Fh
	ld (NewFileCurrentCluster+3),a

MarkNextCluster:	
	push HL
	push DE
	call FAT_SetClusterValue
	pop DE
	pop HL
	
	ld a,H
	ld (NewFileCurrentCluster+3),a
	ld a,l
	ld (NewFileCurrentCluster+2),a
	ld a,d
	ld (NewFileCurrentCluster+1),a
	ld a,e
	ld (NewFileCurrentCluster+0),a
	jr ContMarkingClusters



AskOverwrite:
	ld HL,OverwriteMSG
	call DrawString
AO1:
	call GETKEY2
	cp 'N'
	ret z
	
	cp 'Y'
	jp z,DeleteFile
	jr AO1

DeleteFile:
	;FindFile
	;Mark HL with E5, save sector
	;Find cluster chain and wipe them.
	DI

	call FindFile ;Find the file, populate the FileCluster registers
	ld hl,ColapsingChain
	call DrawString
	;Need to preset HLDE wth FileCluster data

DeleteClusterChain: ; Find clusters and set them to 0000

	ld a,(FileCluster+3)
	ld H,a
	ld a,(FileCluster+2)
	ld L,a
	ld a,(FileCluster+1)
	ld D,a
	ld a,(FileCluster+0)
	ld E,a

Look4Cluster:
	
	
	push HL
	push DE
	call FAT_GetClusterValue ;Cluster in HLDE, Returns A=0 if empty and FAT_NextCluster
	pop DE
	pop HL
	
	;Record the cluster value. if its the last
	
	xor a
	ld (NewFileCurrentCluster),a
	ld (NewFileCurrentCluster+1),a
	ld (NewFileCurrentCluster+2),a
	ld (NewFileCurrentCluster+3),a
	
	push HL
	push DE
	call FAT_SetClusterValue
	pop DE
	pop HL
	
	;Test if the cluster was the last or there is another to seek and destroy!
	;FFFFFF0F is the last cluster in a chain
	
	ld a,(FAT_NextClusterL+3)
	ld H,a
	ld a,(FAT_NextClusterL+2)
	ld L,a
	ld a,(FAT_NextClusterL+1)
	ld D,a
	ld a,(FAT_NextClusterL+0)
	ld E,a

;	call Debug

	ld a,h
	cp 0Fh
	jr z,ThatWasTheLast

;	There's more!!!	Let's get 'em
	jr Look4Cluster
	
ThatWasTheLast:
	;mark entry as deleted
	Call FindFile

	ld hl,RemovingFileEntry
	call DrawString

	;current cluster
	;HL
	ld a,0E5h
	LD (HL),A
	call FAT_Write_Sector
	
	jp SF1


SetFileName:
	ld a,0 ;Clear error flag
	ld (ErrorLevel),a

	;Look though HL for " 
	push DE
	push BC
	push HL
	
	ld HL,FileTemplate
	ld de,FileName
	ld b,11
SFN1:
	ld a,(HL)
	ld (de),a
	inc hl
	inc de
	dec b
	jr nz,SFN1
	;Filename is cleared and VZ extension set
	
	ld de,FileName
	pop HL
	ld b,8
SFN2:
	dec b
	jr z,SFNerror
	ld a,(HL)
	inc HL
	cp '"'
	jr nz,SFN2
	ld b,9
SFN3:
	ld a,(HL)
	cp '"'
	jr z,SFN4
	ld (de),a
	inc de
	inc hl
	dec b
	jr nz,SFN3
SFNerror:
	;MORE THAN 8 characters. Abort!!!
	ld a,1
	ld (ErrorLevel),a

	
SFN4:
	
	pop HL
	pop BC
	ret

FileEntryTemplate:
	.db "           ", 20h, 00h, 3Ch, 0Bh, 91h, 64h, 4Fh, 64h, 4Fh, 0AAh, 0AAh
	.db 0ABh, 01h, 09h, 27h, 0AAh, 0AAh, 55h, 55h, 00h, 00h
VZheader:
	.db 20h,20h,0h,0h,"                 ",0F0h
CreatingMSG:
	.db "CREATING...",0dh,00
FileTemplate:
	.db "        VZ "
OverwriteMSG:
	.db "OVERWRITE? Y/N",0dh,00
SavedMSG:
	.db "SAVED!",0dh,00
ColapsingChain:
	.db "BREAKING CLUSTER CHAIN",0DH,00
RemovingFileEntry:
	.db "REMOVING FILE ENTRY",0DH,00
