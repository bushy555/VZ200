BACKUP: ;Find the file
	;Read CLIBUFER + 5-13
	ld HL,CLIBUFFER + 7
	ld DE,FileName
	ld b,8
B1:
	ld a,(HL)
	cp 0
	jr nz,B2
	ld a,' '
B2:
	ld (DE),a
	inc hl
	inc de
	dec b
	jr nz,B1
	ld a,'V'
	ld (DE),a
	inc de
	ld a,'Z'
	ld (DE),a
	inc de
	ld a,' '
	ld (DE),a

;	filename set
;	Disable Interrupts
	DI
;	patch the interrupt vector 

	ld HL,INTHOOK
	ld (787Eh),HL
	ld a,0C3; jp
	ld (787Dh),a ;Is the interrupt vector, when we're done, put C9 back in there (ret)


	call 3656h ;CLOAD routine

	;Right before launching the binary, interrupts are enabled in the CLOAD
	;Routine. this will call IntHook

	JP MAIN


INTHOOK:
	;Some registers:
	;(781Eh)	;Start address of Binary
	;(7AD2h)	;BASIC/BINARY Byte

	ld a,(7ad2h)
	cp 0F0h
	jr z,FileIsBasic
	cp 0f1h
	jr z,FileIsBinary
	jr EndRoutine
	;check if its a binary
	;if yes, populate the start and end addresses
	;if no, continue on to the save routine.

	
FileIsBasic:
	call SaveFile
	jp EndRoutine

FileIsBinary:
	ld HL,(781Eh)
	ld (78A4h),HL ;Put the binary start address in Basic Start Address
					;This will probably crash Basic.
	
	ld HL,0F000h	;	We'll do a full RAM dump just to be sure to be sure
	ld (78F9h),HL	;Basic End Address
	
					
	call SaveFile
	
	jp EndRoutine


EndRoutine:
;	restore Interrupt Vector	
	ld a,0C9h
	ld (787Dh),a ;Is the interrupt vector
	
	ret
