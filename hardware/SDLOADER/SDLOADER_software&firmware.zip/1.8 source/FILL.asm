Fill:	;Fill Address, Value , Count
	ld HL,CLIBUFFER+5
	call Arg2Word ;point HL to argument, return word in DE
	push DE ;The byte Value
	ld HL,CLIBUFFER+0Ah ;start of data arguments
	call Arg2Byte ;point HL to argument, return word in DE
	push AF ;The number of bytes
	ld HL,CLIBUFFER+0Dh
	call Arg2Word ;point HL to argument, return word in DE
	push DE ;The byte Value

	pop BC ;byte count
	pop AF ;A=value
	pop HL ;Destinaton
	
	ld d,a
	ld a,b
	or c
	cp 0 
	jp z,MAIN ;Bytes = 0

	
FillByte:
	ld a,d
	ld (HL),a
	inc HL
	dec bc
	ld d,a
	ld a,b
	or c
	cp 0
	jr nz,FillByte


	jp MAIN
