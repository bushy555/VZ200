PocketVZ
VZ200/VZ300 Emulator for PocketPC
Written by Guy Thomason
Email: intertek00@netspace.net.au
Build 20080929


INSTALLATION

1. Create a folder called PocketVZ in the Program Files directory
2. Using ActiveSync/Windows Mobile Device Centre, copy the contents of this zip to Program Files\PocketVZ
3. Snapshots/Disk Images/Wav files can be moved to a storage card to save space on the device. 


INTRODUCTION

VZEM is an emulator for the VZ200/VZ300 computers, also known as the Laser 200/ Laser 310 (Europe), Texet TX8000 (UK), and Salora Fellow (Finland).

The VZ200 was manufactured by Video Technology in Hong Kong in 1983. It was distributed in Australia by Dick Smith electronics, and was a popular first computer for many users due to its low cost. In 1983 the VZ200 sold for $199, the Commodore 64 by comparison sold for around $800.


HARDWARE EMULATION

Build 20080916 emulates the following hardware:

* Up to 34k RAM 
* Mode 0 and Mode 1 graphics
* Sound
* Printer 
* Disk Drive
* Cassette Interface


EXTENDED GRAPHICS

In addition the �Super VZ Graphics� hardware modification is emulated. This provides support for all the graphics modes the video chip is capable of (Motorola 6847)

To active the extended graphics modes, type the following from the emulator:

GM0	OUT 32,0	64x64		Color			1024 bytes
GM1	OUT 32,4	128x64		Monochrome		1024 bytes
GM2	OUT 32,8	128x64		Color			2048 bytes
GM3	OUT 32,12	128x96		Monochrome		1536 bytes
GM4	OUT 32,16	128x96		Color			3072 bytes
GM5	OUT 32,20	128x192		Monochrome		3072 bytes
GM6	OUT 32,24	128x192		Color			6144 bytes
GM7	OUT 32,28	256x192		Monochrome		6144 bytes

Then activate the mode using the MODE(1) command or POKE 26624,8.

The VZ200 memory map can only access 2k video ram. For graphics modes that occupy more than 2k (eg GM7), bank switching is used. 

The byte written to port 32 is decoded via the following bits

xxxmmmbb

Where xxx is not used, mmm is the graphics mode, and bb is the bank. So to activate GM7 bank 0, the output byte would be 0011100 binary or 28 decimal. To activate GM7 bank 1, the output byte would be 0011101 binary or 29 decimal. 

For whatever bank is active, reads/writes to the 2k video memory at 7000h will affect the screen. For GM7, pixel rows 0-63 are active for bank 0, 64-127 for bank 1 and 128-191 for bank 2. 

For further information on extended vz graphics, read the following articles (available from VZAlive)

VZ Super Graphics by Joe Leon
Ultra Graphics Adapter by Matthew Sorrell.  

EXTENDED GRAPHICS UPDATED - 27/9/2008
=====================================

Support has been added for the German Graphics Mod. 
From the main menu, select options -> extended graphics -> german.
The German modification only supports GM7, the 256x192 monochrome mode. To enable the mode, set bit 4 of address 30779, eg POKE 30779,8
Then activate the hi-res screen by either the MODE(1) command or POKE 26624,8.

The bank switching is controlled by port 222, eg

OUT 222,0	selects bank 0
OUT 222,1	selects bank 1
OUT 222,2	selects bank 2
OUT 222,3	selects bank 3



USAGE

PocketVZ requires the following files to exist in \Program Files\PocketVZ

* vzrom.v20		VZ200 rom image
* vzdos.rom		Dos rom image (if disk emulation is required)


LOADING/SAVING files

Programs can be loaded or saved by:

* Snapshots (.VZ files)
* Cassette emulation using Windows Wav files
* Disk emulation using a disk image

To save a BASIC program to a Wav file, follow the following steps
1. In the emulator, type CSAVE �filename� but do not press enter
2. Tap the disk icon in the menu bar to display the device control panel
3. Tap the red record button on the cassette player image
3. Enter the name of the PC file you wish to create and click OK
4. Press enter from the emulator

5. Once the save is complete, tap the black "stop" button on the cassette player icon
      
It is very important to �stop� the recording just as you would if you physically saved a program to tape. If you do not stop, the file length is indeterminate and the file will not be a valid wav file.

To save a program to disk, tap the disk drive icon. Select an existing disk image from the filesystem.  If using an existing disk image, the program can be saved with the SAVE �filename� command. When creating a new disk image, the disk must first be formatted with the INIT command. 


CREDITS

Thanks to the following people who directly supplied me with information, or that I have stolen ideas and code from:

Marat Fayzullin		Z80 Emulation library. His MSX emulator motived me to develop a VZ200 emulator   	 

Juergen Buchmueller	Disk emulation routines and other bits and pieces

Richard Wilson		Screen timing information for use in split screen modes


OTHER VZ200 EMULATORS

MESS				VZ200 driver by Juergen Buchmueller and Dirk Best
				http://www.mess.org/download.php

JEMU				VZ200 emulation in a browser! By Richard Wilson
				http://jemu.winape.net/

James VZ200			Lots of cool features like QuickType and configurable CPU Speed. By James Tamer
				http://www.geocities.com/emucompboy/

That�s a total of 4 emulators for the VZ! Quite a good turnout for an old 8 bitter


LINKS

Thanks to the work of VZ enthusiasts everywhere a google search of VZ200 returns pages of links. The major ones are:

http://vzalive.bangrocks.com/			downloads & discussion forum
http://www.vz200.org/ 				Archive of manuals and newsletters
http://archivz.all2ezy.com/			Archive of manuals and newsletters	

My own website, containing latest downloads of the emulator
http://intertek00.customer.netspace.net.au/vz200/

