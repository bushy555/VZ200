Turn Word Wrap ON if you're using Notepad.

James's VZ200 (hereinafter also called "JVZ200") for Windows95/98, by James the Animal Tamer.  It is not called "Virtual VZ200" because there were three pre-existing emulators for the VZ200.


HOME PAGE:
==========
www.geocities.com/emucompboy
Home of the Virtual Aquarius

CONTACT:
========
emucompboy@yahoo.com

NOTE to ROM IMAGE COLLECTORS:
=============================
Howdy.  I'd prefer you reference my website, rather than putting my files up for download on your site.  These emulators are works in progress, and I will randomly be updating them.  Now, you wouldn't want to have an inferior version on your website, would you?  Oh, don't link directly to my file names either.  I change them with each upate!
	Thanks.


System Requirements:
====================
Fast system, Celeron 400MHz or equivalent recommended
Windows95/98
DirectX
16-bit video card (James's VZ200 will work in other modes, but may be slow or not look right)
Sound card compatible with DirectX


Known Bugs
==========
1.  You must configure the printer filename before trying to LPRINT or LLIST or COPY.
2.  CLOAD is far more finicky about the WAVs it will load than a real VZ200.

Preliminary Note:
=================
Here's James's VZ200 version 0.2.  The low number indicates that it's working but missing some features/conveniences.

An important feature for BASIC programmers is Quicktype (from the file menu).  This automatically types a text file.  The best way to use this is to edit a BASIC program as a text file using NOTEPAD.  Save it (from NOTEPAD).  Then use Quicktype to load it into  JVZ200.  This is much easier than trying to type in a program on JVZ200 itself (although that can be done -- beware, the suckiness of the original VZ200 keyboard is emulated in JVZ200).

If you prefer to use the JVZ200's keyboard anyway, you can LLIST your program, then use NOTEPAD to extract your program from the printer output file.  Save out the extracted program to another text file, and you can use the Quicktype feature to load that in.

CSAVE works, for CVZ and WAV files.  Do not try to save a TPD file.  You won't be able to load it back in.

Please note that Quicktype works only with strictly ASCII single keystrokes;  it will not work with graphics characters or inverse.  Sorry.  I'll work on it later.


What works:
=====================
CPU
Memory (with configuration)
Keyboard (emulated and sensible;  can be configured)
Video (Colors can be configured)
Quicktype (provides a means of loading in BASIC programs from text files  -- works with ASCII characters and uppercase only, not the graphics or inverse characters, sorry)
LPRINT/LLIST/COPY (To file.  Note that COPY isn't useful -- SORRY! -- use Windows to Printscreen instead.)
BASIC CLOAD (partial support for WAV files, 8-bit mono Microsoft/Creative format, will try to work with any speed, but recommended speed for best results is 44,100 samples per second)
BASIC CSAVE (WAV and CVZ files only -- ignore other options)
Character set (good but not perfect)
Insertion/removal of game cartridges (you need to Hard Reset to start the cartridge)
Video border 
Accurate timing (NTSC is close enough, or configure your own)
Optional loading of other ROM OS
Sound (mostly working)
Window size configuration
Joystick (sort of -- based on guesswork from Tech Ref Manual)


What does NOT work:
=====================
BASIC CLOAD (CVZ files;  also need better support for WAV files)
BASIC CSAVE (CVZ files)
Timers (if any)
Interrupts (other than VBlank, if any)
Disk Drive
Other peripherals
I/O ports


What will NEVER work:
=====================
Modem or other RS-232c interface
Any peripheral I can't analyze
Pokemon (sorry, that's for the GAME BOY)


Still left to be done:
======================
CSAVE/CLOAD TPD files
Utility save for .VZ
Drag and drop of supported file types (don't hold your breath)
Joystick for undocumented ports
Joystick config
Set default configuration to the right stuff
Utility loaders for Intel Hex, Motorola S
Remove more Virtual Aquarius/Virtual NEC Trek legacy code
Double check the colors for graphics modes
Find out about the hardware hack for other graphics modes and install it as an option



NOTES:
=====================
0.  Many things are not implemented or only partially implemented in this early version.  I/O ports, for example, has a lot of legacy code from the Virtual Aquarius that I have not removed.  Also, I have not removed the AY-3-8910 module.

1.  Joysticks.  They sort of work, with some of the games -- I don't know how to make them better because I do not own the joystick plugin for my real VZ200.  JVZ200 uses DirectX for joystick input.  JVZ200 is tuned for using "joypads" with two buttons.  The joypads I'm using are Microsoft Sidewinder Game Pads.

2.  Sound.  Uses DirectSound.  It is mostly working.  Known problems include:  The Directsound and CPU emulation are not perfectly in sync, so there can be static or an odd echo effect.  Note that if your computer is not running the emulator at a fairly steady 100%, then the sound won't be right and may have problems.  The sound can be VERY LOUD;  in the Sound Configuration box, the default is 50%.  I recommend you don't make it any louder (I am not responsible for damage to your speakers in any case).

3.  Keyboard.  The keyboard operates in one of two modes:  Emulated or Sensible.  Emulated mode is most like the real VZ200 keyboard;  use this mode for playing games.  Sensible makes it easier to type from the PC keyboard.  You can switch back and forth in the same session.

4.  CLOAD.  This supports CVZ files, and has partial support for WAV files.  "Partial" in this case means 8-bit mono Microsoft/Creative .WAV format.  Also, the WAV file must be very clean (noise free), and with no "wow/flutter."  I have successfully loaded in files that were digitized from my real NTSC VZ200's CSAVE.  Unfortunately I have not been able to load ANY commercial software this way (my real VZ200 can load only 50% of those, so I'm thinking that there's too much static and "wow/flutter" on those cassettes).
To CLOAD a file from BASIC, first type CLOAD and press the ENTER key.  Then select Play Cassette File from the File menu.  Choose your file type (WAV or CVZ), and choose your cassette file.

5.  Game cartridges.  To use these ROMs, from JVZ200's file menu, select Load Game ROM.  Select an appropriate cartridge image (binary  file, 16384 bytes long) to load.  To start the software on the cartridge, then select Hard Reset from JVZ200's file menu.  This works with the DOS ROM that's floating around the Internet.


Versions:
=========
March 22, 2002:  0.2
	CSAVEs and CLOADs .CVZ files.  Considerable amount of code clean-up, removing fossil MC-10 stuff.

February 27, 2002: 0.11
	CSAVEs WAV files.  It's set to use 22050 samples per second, out of deference to the pre-existing emulators and tools.

February 17, 2002: 0.1
	First working version, including Quicktype, keyboard, memory, printer, proper speed, sound, limited support for loading .WAV files, etc. etc. etc.  Not bad for a two day conversion from Virtual Aquarius and Virtual NEC Trek!


Credits
=======
Me (James the Animal Tamer) -- Everything that's not mentioned separately below

Z80Em:		Portable Z80 emulator Copyright (C) Marcel de Kogel 1996,1997
	(I grabbed this from MAME)

ay8910.c	From MAME, credited to Ville Hallik, Michael Cuddy,Tatsuyuki Satoh, Fabrice Frances, Nicola Salmoria.

Character set	Data by camennie (from his Radio Shack Microcolor Computer MC-10 emulator source)

Microsoft	DirectX, Microsoft Visual C++, Microsoft Development Studio, Windows 95/98.  Thanks, Bill.

ROMs and .VZ files:	See those for their respective credits.

The real VZ200:		VTECH.  I seriously considered working for you guys (love at first sight with the rep you sent to E3 a few years ago), but I didn't want to relocate to Chicago!

