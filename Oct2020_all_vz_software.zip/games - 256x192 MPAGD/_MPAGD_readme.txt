These are a collection of games converted from a few platforms for the VZ that were originally written with Multi Platform Arcade Game Development suite of programs and libraries.
These will run in either the VZEM or WinDSVZ300 emulators with the appropriate settings configured for 256x192 graphics resolution.
These will also run on real hardware with the "German" and/or "Australian" high resolution graphics modification performed.

"German" mod is 256x192 2-colour.
"Australian" mod is 128x96 and 128x192 4-colour mode.

Further information about these can be found either on the official MPAGD website, forum or on the "VZ200/VZ300 fans" Facebook group.

