#define SCRSIZE     2048 
char scr[128*64];
/* char scr2[128*64*2]; */
char *mem;
main(argc, argv)
int argc;
int *argv;

{	int a,b,c,d,e,f,g,h,i,j,x,y,z;

    	mode(1);
	c=0;
        d=1;
        e=2;
        f=3;
	a=0;
	x=0;
	y=63;
	i=0;
	j=0;
        z=1;
	setbase(scr); 
	asm("di\n");
	while(!(z==2)){
           for(i=0;i<5;i++){
	   dis(63,31,c,d,e,f);
	   dis(63,30,c,d,e,f);
	   dis(63,29,c,d,e,f);
	   dis(63,28,c,d,e,f);
	   dis(62,27,c,d,e,f);
	   dis(62,26,c,d,e,f);
	   dis(62,25,c,d,e,f);
	   dis(61,24,c,d,e,f);
	   dis(60,23,c,d,e,f);
	   dis(59,22,c,d,e,f);
	   dis(58,21,c,d,e,f);
	   dis(57,21,c,d,e,f);
	   dis(56,20,c,d,e,f);
	   dis(55,20,c,d,e,f);
	   dis(54,19,c,d,e,f);
	   dis(53,19,c,d,e,f);
	   dis(52,18,c,d,e,f);
	   dis(51,18,c,d,e,f);
	   dis(50,18,c,d,e,f);
	   dis(49,17,c,d,e,f);
	   dis(48,17,c,d,e,f);
	   dis(47,17,c,d,e,f);
	   dis(46,17,c,d,e,f);
	   dis(45,17,c,d,e,f);
	   dis(44,16,c,d,e,f);
	   dis(43,16,c,d,e,f);
	   dis(42,16,c,d,e,f);
	   dis(41,16,c,d,e,f);
	   dis(40,17,c,d,e,f);
	   dis(39,17,c,d,e,f);
	   dis(38,17,c,d,e,f);
	   dis(37,17,c,d,e,f);
	   dis(36,18,c,d,e,f);
	   dis(35,18,c,d,e,f);
	   dis(34,18,c,d,e,f);
	   dis(33,19,c,d,e,f);
	   dis(32,19,c,d,e,f);
	   dis(31,19,c,d,e,f);
	   dis(30,20,c,d,e,f);
	   dis(29,20,c,d,e,f);
	   dis(28,21,c,d,e,f);
	   dis(27,21,c,d,e,f);
	   dis(26,22,c,d,e,f);
	   dis(25,23,c,d,e,f);
	   dis(24,24,c,d,e,f);
	   dis(23,25,c,d,e,f);
	   dis(22,26,c,d,e,f);
	   dis(22,27,c,d,e,f);
	   dis(21,28,c,d,e,f);
	   dis(21,29,c,d,e,f);
	   dis(21,30,c,d,e,f);
	   dis(21,31,c,d,e,f);
	   dis(21,32,c,d,e,f);
	   dis(21,33,c,d,e,f);
	   dis(22,34,c,d,e,f);
	   dis(22,35,c,d,e,f);
	   dis(22,36,c,d,e,f);
	   dis(23,37,c,d,e,f);
	   dis(23,38,c,d,e,f);
	   dis(24,39,c,d,e,f);
	   dis(25,40,c,d,e,f);
	   dis(26,41,c,d,e,f);
	   dis(27,42,c,d,e,f);
	   dis(28,42,c,d,e,f);
	   dis(29,43,c,d,e,f);
	   dis(30,43,c,d,e,f);
	   dis(31,44,c,d,e,f);
	   dis(32,44,c,d,e,f);
	   dis(33,44,c,d,e,f);
	   dis(34,44,c,d,e,f);
	   dis(35,45,c,d,e,f);
	   dis(36,45,c,d,e,f);
	   dis(37,45,c,d,e,f);
	   dis(38,45,c,d,e,f);
	   dis(39,45,c,d,e,f);
	   dis(40,46,c,d,e,f);
	   dis(41,46,c,d,e,f);
	   dis(42,46,c,d,e,f);
	   dis(43,46,c,d,e,f);
	   dis(44,45,c,d,e,f);
	   dis(45,45,c,d,e,f);
	   dis(46,45,c,d,e,f);
	   dis(47,45,c,d,e,f);
	   dis(48,45,c,d,e,f);
	   dis(49,44,c,d,e,f);
	   dis(50,44,c,d,e,f);
	   dis(51,44,c,d,e,f);
	   dis(52,44,c,d,e,f);
	   dis(53,43,c,d,e,f);
	   dis(54,43,c,d,e,f);
	   dis(55,42,c,d,e,f);
	   dis(56,42,c,d,e,f);
	   dis(57,41,c,d,e,f);
	   dis(58,40,c,d,e,f);
	   dis(59,40,c,d,e,f);
	   dis(60,39,c,d,e,f);
	   dis(61,38,c,d,e,f);
	   dis(61,37,c,d,e,f);
	   dis(62,36,c,d,e,f);
	   dis(62,35,c,d,e,f);
	   dis(62,34,c,d,e,f);
	   dis(63,33,c,d,e,f);
	   dis(63,32,c,d,e,f);
	   c++;
           if (c>3) {c=0;}
	   }
        }
}

dis(x,y,c,d,e,f)
int x,y,c,d,e,f;
{
	line(x+(63-21),y,63-(x/2),31-(y/2),c);
	soundcopy(0x7000,scr,SCRSIZE,0,0);           
	return 0;
}






























/*
	   for(a=0;a<10;a++){
              memset(scr, 108, 2048); 
              soundcopy(0x7000,scr,SCRSIZE,0,0);
    	      for(i=0;i<1000;i++);
              memset(scr, 177, 2048); 
              soundcopy(0x7000,scr,SCRSIZE,0,0);
 	      for(i=0;i<1000;i++);
              memset(scr, 198, 2048); 
              soundcopy(0x7000,scr,SCRSIZE,0,0);
	      for(i=0;i<1000;i++);
              memset(scr, 27, 2048); 
              soundcopy(0x7000,scr,SCRSIZE,0,0);
	      for(i=0;i<1000;i++);
           }
	   for(a=0;a<10;a++){
              memset(scr, 27, 2048); 
              soundcopy(0x7000,scr,SCRSIZE,0,0);
    	      for(i=0;i<1000;i++);
              memset(scr, 198, 2048); 
              soundcopy(0x7000,scr,SCRSIZE,0,0);
 	      for(i=0;i<1000;i++);
              memset(scr, 177, 2048); 
              soundcopy(0x7000,scr,SCRSIZE,0,0);
	      for(i=0;i<1000;i++);
              memset(scr, 108, 2048); 
              soundcopy(0x7000,scr,SCRSIZE,0,0);
	      for(i=0;i<1000;i++);
           }
*/