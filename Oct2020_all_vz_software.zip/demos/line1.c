
#define SCRSIZE     2048
char scr[128*64];
/* char scr2[128*64*2]; */
char *mem;
main(argc, argv)
int argc;
int *argv;
{	int a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x;
    	setbase(0x7000);
	
    	mode(1);
	a=1;
	b=1;
	c=30;
	d=10;
	e=60;
	f=40;
	g=85;
	h=20;
	i=100;
	j=25;
	k=120;
	l=55;
	m=1;
	n=1;
	o=1;
	p=1;
	q=1;
	r=1;
	s=1;
	t=1;
	u=1;
	v=1;
	w=1;
	x=1;
	setbase(scr); 
	asm("di\n");


	while(!inch())
{
	a=a+m;
	b=b+n;
	c=c+o;
	d=d+p;
	e=e+q;
	f=f+r;
	g=g+s;
	h=h+t;
	i=i+u;
	j=j+v;
	k=k+w;
	l=l+x;

	if (a==0)   m=1;
	if (a==127) m=-1;
	if (b==0)   n=1;
	if (b==63)  n=-1;
	if (c==0)   o=1;
	if (c==127) o=-1;
	if (d==0)   p=1;
	if (d==63)  p=-1;
	if (e==0)   q=1;
	if (e==127) q=-1;
	if (f==0)   r=1;
	if (f==63)  r=-1;
	if (g==0)   s=1;
	if (g==127) s=-1;
	if (h==0)   t=1;
	if (h==63)  t=-1;
	if (i==0)   u=1;
	if (i==127) u=-1;
	if (j==0)   v=1;
	if (j==63)  v=-1;
	if (k==0)   w=1;
	if (k==127) w=-1;
	if (l==0)   x=1;
	if (l==63)  x=-1;

	line(a,b, c,d, 2);
	line(c,d, e,f, 2);
	line(e,f, g,h, 2);
	line(g,h, i,j, 2);
	line(i,j, k,l, 2);
	soundcopy(0x7000,scr,SCRSIZE,0,0);
	memset(scr, 0, 2048);

};

	getch();
    mode(0);
    bgrd(0);
    return 0;
}
