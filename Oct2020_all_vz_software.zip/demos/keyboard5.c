#include <sound.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <vz.h>


#include <sound.h>
	int duration;
	int keyboard;







update(){
	int	j;
//	vz_mode(0);
	vz_clrscr();

        printf(" +++++ V Z  -  O R G A N +++++\n\n");
	printf(" duration      sound\n");
	printf("1 = shorter   5 = normal\n");
	printf("2 = longer    6 = distortion\n");
	printf("              7 = fully sik\n");
	printf("3 = FX\n");
	printf("4 = organ   keyboard %d :", keyboard);


	printf("\n-----------------------------\n");

        if (keyboard == 3) 
        {
 	   printf("sound fx: \n\n");
	   printf("Q W E R T Y U I O P [ \n");
	   printf(" A S D F G H J K L ; \n");
	   printf("  Z X C V B N M , . / \n");              
        }
        if (keyboard > 3)
        {
 	   printf("Keyboard: ");
	   if (keyboard == 5) {printf("normal\n");}
	   if (keyboard == 6) {printf("distortion\n");}
	   if (keyboard == 7) {printf("fully sik\n");}
           printf("duration: %d", duration);
        }
}



int keys()
{

     


           if (keyboard==5){
              switch( vz_inch() ) {
	         case 'Q' :      bit_synth (duration,200,200,60,60); break;
	         case 'W' :      bit_synth (duration,200,200,53,53); break;
	         case 'E' :      bit_synth (duration,200,200,50,50); break;
	         case 'R' :      bit_synth (duration,200,200,44,44); break;
	         case 'T' :      bit_synth (duration,200,200,40,40); break;
	         case 'Y' :      bit_synth (duration,200,200,33,33); break;
	         case 'U' :      bit_synth (duration,177,177,60,60); break;
	         case 'I' :      bit_synth (duration,177,177,50,50); break;
	         case 'O' :      bit_synth (duration,177,177,44,44); break;
	         case 'P' :      bit_synth (duration,177,177,40,40); break;
	         case 'A' :      bit_synth (duration,177,177,37,37); break;
	         case 'S' :      bit_synth (duration,160,160,60,60); break;
	         case 'D' :      bit_synth (duration,160,160,53,53); break;
	         case 'F' :      bit_synth (duration,160,160,50,50); break;
	         case 'G' :      bit_synth (duration,160,160,44,44); break;
	         case 'H' :      bit_synth (duration,160,160,40,40); break;
	         case 'J' :      bit_synth (duration,150,150,60,60); break;
	         case 'K' :      bit_synth (duration,150,150,53,53); break;
	         case 'L' :      bit_synth (duration,150,150,50,50); break;
	         case 'Z' :      bit_synth (duration,150,150,44,44); break;
	         case 'X' :      bit_synth (duration,150,150,40,40); break;
	         case 'C' :      bit_synth (duration,133,133,60,60); break;
	         case 'V' :      bit_synth (duration,133,133,53,53); break;
	         case 'B' :      bit_synth (duration,133,133,50,50); break;
	         case 'N' :      bit_synth (duration,133,133,44,44); break;
	         case 'M' :      bit_synth (duration,133,133,40,40); break;
	         case '1' :	 duration -= 5;
				 if (duration < 20) {duration = 20;}
				 update();
				 break;
	         case '2' :	 duration += 5;
				 if (duration > 240) {duration = 240;}
				 update();
				 break;
		 case '3' :      
				 keyboard = 3;
				 update();
				 break;
		 case '4' :      
				 keyboard = 5;
				 update();
				 break;
		 case '5' :      keyboard = 5;
				 update();
				 break;
		 case '6' :      keyboard = 6;
				 update();
				 break;
		 case '7' :      keyboard = 7;
				 update();
				 break;

              }
              }



           if (keyboard==6){
              switch( vz_inch() ) {
	         case 'Q' :      bit_synth (duration,200,201,60,61); break;
	         case 'W' :      bit_synth (duration,200,201,53,54); break;
	         case 'E' :      bit_synth (duration,200,201,50,51); break;
	         case 'R' :      bit_synth (duration,200,201,44,45); break;
	         case 'T' :      bit_synth (duration,200,201,40,41); break;
	         case 'Y' :      bit_synth (duration,200,201,33,34); break;
	         case 'U' :      bit_synth (duration,177,178,60,61); break;
	         case 'I' :      bit_synth (duration,177,178,50,51); break;
	         case 'O' :      bit_synth (duration,177,178,44,45); break;
	         case 'P' :      bit_synth (duration,177,178,40,41); break;
	         case 'A' :      bit_synth (duration,177,178,37,38); break;
	         case 'S' :      bit_synth (duration,160,161,60,61); break;
	         case 'D' :      bit_synth (duration,160,161,53,54); break;
	         case 'F' :      bit_synth (duration,160,161,50,51); break;
	         case 'G' :      bit_synth (duration,160,161,44,45); break;
	         case 'H' :      bit_synth (duration,160,161,40,41); break;
	         case 'J' :      bit_synth (duration,150,151,60,61); break;
	         case 'K' :      bit_synth (duration,150,151,53,54); break;
	         case 'L' :      bit_synth (duration,150,151,50,51); break;
	         case 'Z' :      bit_synth (duration,150,151,44,45); break;
	         case 'X' :      bit_synth (duration,150,151,40,41); break;
	         case 'C' :      bit_synth (duration,133,134,60,61); break;
	         case 'V' :      bit_synth (duration,133,134,53,54); break;
	         case 'B' :      bit_synth (duration,133,134,50,51); break;
	         case 'N' :      bit_synth (duration,133,134,44,45); break;
	         case 'M' :      bit_synth (duration,133,134,40,41); break;
	         case '1' :	 duration -= 5;
				 if (duration < 20) {duration = 20;}
				 update();
				 break;
	         case '2' :	 duration += 5;
				 if (duration > 240) {duration = 240;}
				 update();
				 break;
		 case '3' :      
				 keyboard = 3;
				 update();
				 break;
		 case '4' :      
				 keyboard = 6;
				 update();
				 break;
		 case '5' :      keyboard = 5;
				 update();
				 break;
		 case '6' :      keyboard = 6;
				 update();
				 break;
		 case '7' :      keyboard = 7;
				 update();
				 break;
		}
		}


           if (keyboard==7){
              switch( vz_inch() ) {
	         case 'Q' :      bit_synth (duration,200,202,60,62); break;
	         case 'W' :      bit_synth (duration,200,202,53,55); break;
	         case 'E' :      bit_synth (duration,200,202,50,52); break;
	         case 'R' :      bit_synth (duration,200,202,44,46); break;
	         case 'T' :      bit_synth (duration,200,202,40,42); break;
	         case 'Y' :      bit_synth (duration,200,202,33,35); break;
	         case 'U' :      bit_synth (duration,177,179,60,62); break;
	         case 'I' :      bit_synth (duration,177,179,50,52); break;
	         case 'O' :      bit_synth (duration,177,179,44,46); break;
	         case 'P' :      bit_synth (duration,177,179,40,43); break;
	         case 'A' :      bit_synth (duration,177,179,37,39); break;
	         case 'S' :      bit_synth (duration,160,162,60,62); break;
	         case 'D' :      bit_synth (duration,160,162,53,56); break;
	         case 'F' :      bit_synth (duration,160,162,50,52); break;
	         case 'G' :      bit_synth (duration,160,162,44,47); break;
	         case 'H' :      bit_synth (duration,160,162,40,42); break;
	         case 'J' :      bit_synth (duration,150,152,60,62); break;
	         case 'K' :      bit_synth (duration,150,152,53,55); break;
	         case 'L' :      bit_synth (duration,150,152,50,53); break;
	         case 'Z' :      bit_synth (duration,150,152,44,46); break;
	         case 'X' :      bit_synth (duration,150,152,40,42); break;
	         case 'C' :      bit_synth (duration,133,135,60,62); break;
	         case 'V' :      bit_synth (duration,133,135,53,55); break;
	         case 'B' :      bit_synth (duration,133,135,50,52); break;
	         case 'N' :      bit_synth (duration,133,135,44,46); break;
	         case 'M' :      bit_synth (duration,133,135,40,42); break;
	         case '1' :	 duration -= 5;
				 if (duration < 20) {duration = 20;}
				 update();
				 break;
	         case '2' :	 duration += 5;
				 if (duration > 240) {duration = 240;}
				 update();
				 break;
		 case '3' :      
				 keyboard = 3;
				 update();
				 break;
		 case '4' :      
				 keyboard = 7;
				 update();
				 break;
		 case '5' :      keyboard = 5;
				 update();
				 break;
		 case '6' :      keyboard = 6;
				 update();
				 break;
		 case '7' :      keyboard = 7;
				 update();
				 break;

              }
          }

      if (keyboard==3){
              switch( vz_inch() ) {
                 case 'Q' : bit_fx(0);break;
                 case 'W' : bit_fx(1);break;
                 case 'E' : bit_fx(2);break;
                 case 'R' : bit_fx(3);break;
                 case 'T' : bit_fx(4);break;
                 case 'Y' : bit_fx(5);break;
                 case 'U' : bit_fx(6);break;
                 case 'I' : bit_fx(7);break;
                 case 'O' : bit_fx2(0);break;
                 case 'P' : bit_fx2(1);break;
                 case '[' : bit_fx2(2);break;
                 case ']' : bit_fx2(3);break;
                 case 'A' : bit_fx2(4);break;
                 case 'S' : bit_fx2(5);break;
                 case 'D' : bit_fx2(6);break;
                 case 'F' : bit_fx2(7);break;
                 case 'G' : bit_fx3(0);break;
                 case 'H' : bit_fx3(1);break;
                 case 'J' : bit_fx3(2);break;
                 case 'K' : bit_fx3(3);break;
                 case 'L' : bit_fx3(4);break;
                 case ';' : bit_fx3(5);break;
                 case 'Z' : bit_fx3(6);break;
                 case 'X' : bit_fx3(7);break;
                 case 'C' : bit_fx4(0);break;
                 case 'V' : bit_fx4(1);break;
                 case 'B' : bit_fx4(2);break;
                 case 'N' : bit_fx4(3);break;
                 case 'M' : bit_fx4(4);break;
                 case ',' : bit_fx4(5);break;
                 case '.' : bit_fx4(6);break;
                 case '/' : bit_fx4(7);break;

		 case '3' :     
				 keyboard = 3;
				 update();
				 break;
		 case '4' :      
				 keyboard = 5;
				 update();
				 break;
		 case '5' :      keyboard = 5;
				 update();
				 break;
		 case '6' :      keyboard = 6;
				 update();
				 break;
		 case '7' :      keyboard = 7;
				 update();
				 break;

	      }
	   }

}    


int main()
{

	int i;
	int j;
	int k;
	int l;
	int m;
	int	quit;


	quit = 0;
	duration = 50;
	keyboard = 5;
	update();


	while (quit == 0) {
		keys();
	}	
}
