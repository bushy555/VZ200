#define SCRSIZE     2048 
char scr[128*64];
char *mem;
main(argc, argv)
int argc;
int *argv;

{	int a,b,c,d,e,f,g,h,i,j,x,y,z;


	a=0;
	b=0;
	c=127;
        d=0;
        e=63;
        f=63;
	x=0;
	y=63;
	i=0;
	j=0;
        z=1;
    	mode(1);
	setbase(scr); 
	asm("di\n");
	while(!(z==2)){
           for (i=0;i<600;i++){
              g=rand(3);
              if (g==0) {
                 x=x+a;
                 y=y+b;
              }
              if (g==1) {
                 x=x+c;
                 y=y+d;
              }
              if (g==2) {
                 x=x+e;
                 y=y+f;
              }
              x=x/2;
              y=y/2;
              plot (x,y,3);
           }
           soundcopy(0x7000,scr,SCRSIZE,0,0);
           memset(scr,0,2048);
           a=a+3;
           d=d+3;
           e=e-3;        

	}
}

	
