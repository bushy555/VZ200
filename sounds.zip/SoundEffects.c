#pragma output nostreams
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <vz.h>
#include <sound.h>


main() {
   int	i;
   i=1;
   
   /* vz_clrscr; */

   bit_fx2(4);
   bit_fx2(4);
   bit_fx2(7);


/*   vz_sound(24,50);
   vz_sound(25,50);
   vz_sound(26,50);
   vz_sound(25,50);
   vz_sound(26,50);
   vz_sound(27,50);
   vz_sound(32,100);
   vz_sound(24,100);
   vz_sound(20,100);  
   vz_sound(24,100);
   vz_sound(28,100);
   vz_sound(24,100);
   vz_sound(32,100);
   vz_sound(24,100);
   vz_sound(20,100);  
   vz_sound(24,100);
   vz_sound(28,100);
   vz_sound(24,100);
   vz_sound(32,100);
   vz_sound(24,100);
   vz_sound(20,600);  
*/



   while ( i==1) {

	   printf("\n\n\n\n\n\n\n\n");
	   printf("\n\n\n\n\n\n\n\n");
	   printf(" Sound Effects library\n\n");
	   printf("1 - library#1   \n");
	   printf("2 - library#2   \n");
	   printf("3 - library#3   \n");
	   printf("4 - library#4   \n");
	   printf("\n\n\n\n\n\n\n\n");

      switch( toupper(vz_getch()) ) {      

        case '1':
             vz_getch();
             library1();
             break;
        case '2':
             vz_getch();
             library2();
             break;
        case '3':
             vz_getch();
             library3();
             break;
        case '4':
             vz_getch();
             library4();
             break;
        }
      }
   }





library1()
{
   printf("Sound effects - library #1\n");
   printf("...effect 0 \n");
   bit_fx(0);
   bit_fx(0);
   bit_fx(0);
   bit_fx(0);
   bit_fx(0);
   bit_fx(0);
   bit_fx(0);
   bit_fx(0);
   bit_fx(0);
   printf("...effect 1 \n");
   bit_fx(1);
   bit_fx(1);
   bit_fx(1);
   bit_fx(1);
   printf("...effect 2 \n");
   bit_fx(2);
   bit_fx(2);
   bit_fx(2);
   bit_fx(2);
   bit_fx(2);
   bit_fx(2);
   printf("...effect 3 \n");
   bit_fx(3);
   bit_fx(3);
   bit_fx(3);
   bit_fx(3);
   printf("...effect 4 \n");
   bit_fx(4);
   bit_fx(4);
   bit_fx(4);
   bit_fx(4);
   printf("...effect 5 \n");
   bit_fx(5);
   bit_fx(5);
   bit_fx(5);
   bit_fx(5);
   bit_fx(5);
   bit_fx(5);
   printf("...effect 6 \n");
   bit_fx(6);
   bit_fx(6);
   bit_fx(6);
   bit_fx(6);
   bit_fx(6);
   bit_fx(6);
   printf("...effect 7 \n");
   bit_fx(7);
   bit_fx(7);
   bit_fx(7);
   bit_fx(7);
   bit_fx(7);
   bit_fx(7);
}


library2()
{
   printf("Sound effects - library #2\n");
   printf("...effect 0 \n");
   bit_fx2(0);
   bit_fx2(0);
   bit_fx2(0);
   bit_fx2(0);
   bit_fx2(0);
   bit_fx2(0);
   printf("...effect 1 \n");
   bit_fx2(1);
   bit_fx2(1);
   bit_fx2(1);
   bit_fx2(1);
   bit_fx2(1);
   bit_fx2(1);
   printf("...effect 2 \n");
   bit_fx2(2);
   bit_fx2(2);
   bit_fx2(2);
   bit_fx2(2);
   bit_fx2(2);
   bit_fx2(2);
   bit_fx2(2);
   bit_fx2(2);
   bit_fx2(2);
   bit_fx2(2);
   bit_fx2(2);
   bit_fx2(2);
   bit_fx2(2);
   printf("...effect 3 \n");
   bit_fx2(3);
   bit_fx2(3);
   bit_fx2(3);
   bit_fx2(3);
   bit_fx2(3);
   bit_fx2(3);
   printf("...effect 4 \n");
   bit_fx2(4);
   bit_fx2(4);
   bit_fx2(4);
   bit_fx2(4);
   bit_fx2(4);
   bit_fx2(4);
   printf("...effect 5 \n");
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   printf("...effect 6 \n");
   bit_fx2(6);
   bit_fx2(6);
   bit_fx2(6);
   bit_fx2(6);
   bit_fx2(6);
   bit_fx2(6);
   printf("...effect 7 \n");
   bit_fx2(7);
   bit_fx2(7);
   bit_fx2(7);
}


library3()
{
   printf("Sound effects - library #3\n");
   printf("...effect 0 \n");
   bit_fx3(0);
   bit_fx3(0);
   bit_fx3(0);
   bit_fx3(0);
   bit_fx3(0);
   bit_fx3(0);
   printf("...effect 1 \n");
   bit_fx3(1);
   bit_fx3(1);
   bit_fx3(1);
   bit_fx3(1);
   bit_fx3(1);
   bit_fx3(1);
   printf("...effect 2 \n");
   bit_fx3(2);
   bit_fx3(2);
   bit_fx3(2);
   bit_fx3(2);
   bit_fx3(2);
   bit_fx3(2);
   printf("...effect 3 \n");
   bit_fx3(3);
   bit_fx3(3);
   bit_fx3(3);
   bit_fx3(3);
   bit_fx3(3);
   bit_fx3(3);
   printf("...effect 4 \n");
   bit_fx3(4);
   bit_fx3(4);
   bit_fx3(4);
   bit_fx3(4);
   printf("...effect 5 \n");
   bit_fx3(5);
   bit_fx3(5);
   bit_fx3(5);
   bit_fx3(5);
   bit_fx3(5);
   bit_fx3(5);
   printf("...effect 6 \n");
   bit_fx3(6);
   bit_fx3(6);
   bit_fx3(6);
   bit_fx3(6);
   bit_fx3(6);
   bit_fx3(6);
   printf("...effect 7\n");
   bit_fx3(7);
   bit_fx3(7);
   bit_fx3(7);
   bit_fx3(7);
   bit_fx3(7);
   bit_fx3(7); 
   bit_fx3(7);
   bit_fx3(7);
   bit_fx3(7); 
}


library4()
{
   printf("Sound effects - library #4\n");
   printf("...effect 0 \n");
   bit_fx4(0);
   bit_fx4(0);
   bit_fx4(0);
   bit_fx4(0);
   bit_fx4(0);
   bit_fx4(0);
   printf("...effect 1 \n");
   bit_fx4(1);
   bit_fx4(1);
   bit_fx4(1);
   printf("...effect 2 \n");
   bit_fx4(2);
   bit_fx4(2);
   bit_fx4(2);
   bit_fx4(2);
   bit_fx4(2);
   bit_fx4(2);
   printf("...effect 3 \n");
   bit_fx4(3);
   bit_fx4(3);
   bit_fx4(3);
   printf("...effect 4 \n");
   bit_fx4(4);
   bit_fx4(4);
   bit_fx4(4);
   printf("...effect 5 \n");
   bit_fx4(5);
   bit_fx4(5);
   bit_fx4(5);
   bit_fx4(5);
   bit_fx4(5);
   bit_fx4(5);
   printf("...effect 6 \n");
   bit_fx4(6);
   bit_fx4(6);
   bit_fx4(6);
   bit_fx4(6);
   bit_fx4(6);
   bit_fx4(6);
   printf("...effect 7 \n");
   bit_fx4(7);
   bit_fx4(7);
   bit_fx4(7);
   bit_fx4(7);
   bit_fx4(7);
   bit_fx4(7);
   bit_fx4(7);
   bit_fx4(7);
   bit_fx4(7);
   bit_fx4(7);
   bit_fx4(7);
   bit_fx4(7);
}





}