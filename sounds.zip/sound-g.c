#pragma output nostreams
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <vz.h>

#include <sound.h>


main() {
   int	i;
   i=1;
   
   /* vz_clrscr; */


   bit_fx2(4);
   bit_fx2(4);
   bit_fx2(7);
/*
   vz_sound(24,50);
   vz_sound(25,50);
   vz_sound(26,50);
   vz_sound(25,50);
   vz_sound(26,50);
   vz_sound(27,50);
   vz_sound(32,100);
   vz_sound(24,100);
   vz_sound(20,100);  
   vz_sound(24,100);
   vz_sound(28,100);
   vz_sound(24,100);
   vz_sound(32,100);
   vz_sound(24,100);
   vz_sound(20,100);  
   vz_sound(24,100);
   vz_sound(28,100);
   vz_sound(24,100);
   vz_sound(32,100);
   vz_sound(24,100);
   vz_sound(20,600);  
*/

   while ( i==1) {

	   printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nSound Effects and music v2.2\n");

	   printf("1 - library#1   e ! tune #11\n");
	   printf("2 - library#2   f ! tune #12\n");
	   printf("3 - library#3   g ! tune #13\n");
	   printf("4 - library#4   h ! tune #14\n");
	   printf("5 - tune #1  (tune)\n");
	   printf("6 - tune #2  (tune)\n");
	   printf("7 - tune #3  (end music 1)\n");
	   printf("8 - tune #4  (end music 2)\n");  
	   printf("9 - tune #5  (vz teckno)\n");  
	   printf("0 ! tune #6  (         )\n");  
	   printf("A ! tune #7  (          \n");  
	   printf("B ! tune #8  (         )\n");  
	   printf("C ! tune #9  (         )\n");  
	   printf("D ! tune #10 (         )\n");  


/*      switch( toupper(getk()) ) {      */
      switch( toupper(vz_getch()) ) {      

        case '1':
             vz_getch();
             library1();
             break;
        case '2':
             vz_getch();
             library2();
             break;
        case '3':
             vz_getch();
             library3();
             break;
        case '4':
             vz_getch();
             library4();
             break;
        case '5':
             vz_getch();
             tunes1();
             break;
        case '6':
             vz_getch();
             tunes2();
             break;
        case '7':
             vz_getch();
             tunes3();
             break;
        case '8':
             vz_getch();
             tunes4();
             break;
        case '9':
             vz_getch();
             tunes5();
             break;             
        case '0':
             vz_getch();
             tunes6();
             break;             
        case 'A':
             vz_getch();
             tunes7();
             break;             
        case 'B':
             vz_getch();
             tunes8();
             break;             
        case 'C':
             vz_getch();
             tunes9();
             break;             
        case 'D':
             vz_getch();
             tunes10();
             break;             
        case 'E':
             vz_getch();
             tunes11();
             break;             
        case 'F':
             vz_getch();
             tunes12();
             break;             
        case 'G':
             vz_getch();
             tunes13();
             break;             
        }
      }
   }





library1()
{
   printf("Sound effects - library #1\n");
   printf("...effect 0 \n");
   bit_fx(0);
   bit_fx(0);
   bit_fx(0);
   bit_fx(0);
   bit_fx(0);
   bit_fx(0);
   bit_fx(0);
   bit_fx(0);
   bit_fx(0);
   printf("...effect 1 \n");
   bit_fx(1);
   bit_fx(1);
   bit_fx(1);
   bit_fx(1);
   printf("...effect 2 \n");
   bit_fx(2);
   bit_fx(2);
   bit_fx(2);
   bit_fx(2);
   bit_fx(2);
   bit_fx(2);
   printf("...effect 3 \n");
   bit_fx(3);
   bit_fx(3);
   bit_fx(3);
   bit_fx(3);
   printf("...effect 4 \n");
   bit_fx(4);
   bit_fx(4);
   bit_fx(4);
   bit_fx(4);
   printf("...effect 5 \n");
   bit_fx(5);
   bit_fx(5);
   bit_fx(5);
   bit_fx(5);
   bit_fx(5);
   bit_fx(5);
   printf("...effect 6 \n");
   bit_fx(6);
   bit_fx(6);
   bit_fx(6);
   bit_fx(6);
   bit_fx(6);
   bit_fx(6);
   printf("...effect 7 \n");
   bit_fx(7);
   bit_fx(7);
   bit_fx(7);
   bit_fx(7);
   bit_fx(7);
   bit_fx(7);
}


library2()
{
   printf("Sound effects - library #2\n");
   printf("...effect 0 \n");
   bit_fx2(0);
   bit_fx2(0);
   bit_fx2(0);
   bit_fx2(0);
   bit_fx2(0);
   bit_fx2(0);
   printf("...effect 1 \n");
   bit_fx2(1);
   bit_fx2(1);
   bit_fx2(1);
   bit_fx2(1);
   bit_fx2(1);
   bit_fx2(1);
   printf("...effect 2 \n");
   bit_fx2(2);
   bit_fx2(2);
   bit_fx2(2);
   bit_fx2(2);
   bit_fx2(2);
   bit_fx2(2);
   bit_fx2(2);
   bit_fx2(2);
   bit_fx2(2);
   bit_fx2(2);
   bit_fx2(2);
   bit_fx2(2);
   bit_fx2(2);
   printf("...effect 3 \n");
   bit_fx2(3);
   bit_fx2(3);
   bit_fx2(3);
   bit_fx2(3);
   bit_fx2(3);
   bit_fx2(3);
   printf("...effect 4 \n");
   bit_fx2(4);
   bit_fx2(4);
   bit_fx2(4);
   bit_fx2(4);
   bit_fx2(4);
   bit_fx2(4);
   printf("...effect 5 \n");
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   printf("...effect 6 \n");
   bit_fx2(6);
   bit_fx2(6);
   bit_fx2(6);
   bit_fx2(6);
   bit_fx2(6);
   bit_fx2(6);
   printf("...effect 7 \n");
   bit_fx2(7);
   bit_fx2(7);
   bit_fx2(7);
}


library3()
{
   printf("Sound effects - library #3\n");
   printf("...effect 0 \n");
   bit_fx3(0);
   bit_fx3(0);
   bit_fx3(0);
   bit_fx3(0);
   bit_fx3(0);
   bit_fx3(0);
   printf("...effect 1 \n");
   bit_fx3(1);
   bit_fx3(1);
   bit_fx3(1);
   bit_fx3(1);
   bit_fx3(1);
   bit_fx3(1);
   printf("...effect 2 \n");
   bit_fx3(2);
   bit_fx3(2);
   bit_fx3(2);
   bit_fx3(2);
   bit_fx3(2);
   bit_fx3(2);
   printf("...effect 3 \n");
   bit_fx3(3);
   bit_fx3(3);
   bit_fx3(3);
   bit_fx3(3);
   bit_fx3(3);
   bit_fx3(3);
   printf("...effect 4 \n");
   bit_fx3(4);
   bit_fx3(4);
   bit_fx3(4);
   bit_fx3(4);
   printf("...effect 5 \n");
   bit_fx3(5);
   bit_fx3(5);
   bit_fx3(5);
   bit_fx3(5);
   bit_fx3(5);
   bit_fx3(5);
   printf("...effect 6 \n");
   bit_fx3(6);
   bit_fx3(6);
   bit_fx3(6);
   bit_fx3(6);
   bit_fx3(6);
   bit_fx3(6);
   printf("...effect 7\n");
   bit_fx3(7);
   bit_fx3(7);
   bit_fx3(7);
   bit_fx3(7);
   bit_fx3(7);
   bit_fx3(7); 
   bit_fx3(7);
   bit_fx3(7);
   bit_fx3(7); 
}


library4()
{
   printf("Sound effects - library #4\n");
   printf("...effect 0 \n");
   bit_fx4(0);
   bit_fx4(0);
   bit_fx4(0);
   bit_fx4(0);
   bit_fx4(0);
   bit_fx4(0);
   printf("...effect 1 \n");
   bit_fx4(1);
   bit_fx4(1);
   bit_fx4(1);
   printf("...effect 2 \n");
   bit_fx4(2);
   bit_fx4(2);
   bit_fx4(2);
   bit_fx4(2);
   bit_fx4(2);
   bit_fx4(2);
   printf("...effect 3 \n");
   bit_fx4(3);
   bit_fx4(3);
   bit_fx4(3);
   printf("...effect 4 \n");
   bit_fx4(4);
   bit_fx4(4);
   bit_fx4(4);
   printf("...effect 5 \n");
   bit_fx4(5);
   bit_fx4(5);
   bit_fx4(5);
   bit_fx4(5);
   bit_fx4(5);
   bit_fx4(5);
   printf("...effect 6 \n");
   bit_fx4(6);
   bit_fx4(6);
   bit_fx4(6);
   bit_fx4(6);
   bit_fx4(6);
   bit_fx4(6);
   printf("...effect 7 \n");
   bit_fx4(7);
   bit_fx4(7);
   bit_fx4(7);
   bit_fx4(7);
   bit_fx4(7);
   bit_fx4(7);
   bit_fx4(7);
   bit_fx4(7);
   bit_fx4(7);
   bit_fx4(7);
   bit_fx4(7);
   bit_fx4(7);
}



tunes1()
{
  printf("bit_synth \n");

/* bit_synth(int duration, int frequency1, int frequency2, int frequency3, int frequency4); */


printf("testing blank 1 \n");
        bit_synth (50,160,163,50,50);
        bit_synth (50,160,163,50,50);
        bit_synth (20,0,0,0,0);
        bit_synth (50,177,180,44,44);
        bit_synth (50,177,180,44,44);
        bit_synth (20,0,0,0,0);
        bit_synth (50,177,180,50,50);
        bit_synth (50,177,180,50,50);
        bit_synth (20,0,0,0,0);
        bit_synth (50,160,163,53,53);
        bit_synth (50,160,163,53,53);



printf("testing blank 2 \n");
        bit_synth (20,160,163,50,50);
        bit_synth (20,160,163,50,50);
        bit_synth (20,177,180,44,44);
        bit_synth (20,177,180,44,44);
        bit_synth (20,177,180,50,50);
        bit_synth (20,177,180,50,50);
        bit_synth (20,160,163,53,53);
        bit_synth (20,160,163,53,53);
        bit_synth (20,177,180,44,44);
        bit_synth (20,177,180,44,44);
        bit_synth (20,160,163,53,53);
        bit_synth (20,160,163,53,53);
        bit_synth (20,160,163,50,50);
        bit_synth (20,160,163,50,50);
        bit_synth (20,160,163,50,50);
        bit_synth (20,160,163,50,50);
        bit_synth (20,160,163,53,53);
        bit_synth (20,160,163,53,53);
        bit_synth (20,160,163,50,50);
        bit_synth (20,160,163,50,50);
        bit_synth (20,177,180,44,44);
        bit_synth (20,177,180,44,44);
        bit_synth (20,177,180,50,50);
        bit_synth (20,177,180,50,50);
        bit_synth (20,160,163,53,53);
        bit_synth (20,160,163,53,53);
        bit_synth (20,177,180,44,44);
        bit_synth (20,177,180,44,44);
        bit_synth (20,160,163,53,53);
        bit_synth (20,160,163,53,53);
        bit_synth (20,160,163,50,50);
        bit_synth (20,160,163,50,50);
        bit_synth (20,160,163,50,50);
        bit_synth (20,160,163,50,50);
        bit_synth (20,160,163,53,53);
        bit_synth (20,160,163,53,53);


        bit_synth (20,133,136,53,53);
        bit_synth (20,133,136,60,60);
        bit_synth (20,133,136,53,53);
        bit_synth (20,133,136,60,60);
        bit_synth (20,133,136,53,53);
        bit_synth (20,133,136,50,50);
        bit_synth (20,133,136,53,53);
        bit_synth (20,133,136,50,50);

        bit_synth (20,150,153,44,44);
        bit_synth (20,150,153,50,50);
        bit_synth (20,150,153,44,44);
        bit_synth (20,150,153,50,50);
        bit_synth (20,150,153,44,44);
        bit_synth (20,150,153,53,53);
        bit_synth (20,150,153,44,44);
        bit_synth (20,150,153,53,53);

        bit_synth (20,160,163,50,50);
        bit_synth (20,160,163,53,53);
        bit_synth (20,160,163,50,50);
        bit_synth (20,160,163,53,53);
        bit_synth (20,177,180,50,50);
        bit_synth (20,177,180,44,44);
        bit_synth (20,177,180,50,50);
        bit_synth (20,177,180,44,44);

        bit_synth (20,200,203,40,40);
        bit_synth (20,200,203,44,44);
        bit_synth (20,200,203,40,40);
        bit_synth (20,200,203,44,44);
        bit_synth (20,160,163,50,50);
        bit_synth (20,160,163,53,53);
        bit_synth (20,160,163,50,50);
        bit_synth (20,160,163,53,53);


printf("1 \n");
        bit_synth (20,0,0,160,0);
        bit_synth (20,0,0,161,0);
        bit_synth (20,0,0,161,0);
        bit_synth (20,0,0,162,0);

        bit_synth (50,0,0,160,0);
        bit_synth (50,0,0,161,0);
        bit_synth (50,0,0,161,0);
        bit_synth (50,0,0,162,0);

        bit_synth (20,0,0,160,0);
        bit_synth (20,0,0,161,0);
        bit_synth (20,0,0,161,0);
        bit_synth (20,0,0,162,0);


        bit_synth (50,160,163,50,50);
        bit_synth (50,160,163,50,50);
        bit_synth (50,177,180,44,44);
        bit_synth (50,177,180,44,44);
        bit_synth (50,177,180,50,50);
        bit_synth (50,177,180,50,50);
        bit_synth (50,160,163,53,53);
        bit_synth (50,160,163,53,53);
        bit_synth (50,160,163,50,50);
        bit_synth (50,160,163,50,50);
        bit_synth (50,177,180,44,44);
        bit_synth (50,177,180,44,44);
        bit_synth (50,177,180,50,50);
        bit_synth (50,177,180,50,50);
        bit_synth (50,160,163,53,53);
        bit_synth (50,160,163,53,53);


printf("2 \n");

        bit_synth (50,160,163,50,50);
        bit_synth (50,160,163,50,50);
        bit_synth (50,177,180,44,44);
        bit_synth (50,177,180,44,44);
        bit_synth (50,177,180,50,50);
        bit_synth (50,177,180,50,50);
        bit_synth (50,160,163,53,53);
        bit_synth (50,160,163,53,53);






        bit_synth (50,133,136,53,53);
        bit_synth (50,133,136,60,60);
        bit_synth (50,133,136,53,53);
        bit_synth (50,133,136,50,50);

        bit_synth (50,150,153,44,44);
        bit_synth (50,150,153,50,50);
        bit_synth (50,150,153,44,44);
        bit_synth (50,150,153,53,53);

        bit_synth (50,160,163,50,50);
        bit_synth (50,160,163,53,53);
        bit_synth (50,177,180,50,50);
        bit_synth (50,177,180,44,44);

        bit_synth (50,200,203,40,40);
        bit_synth (50,200,203,44,44);
        bit_synth (50,160,163,50,50);
        bit_synth (50,160,163,53,53);

}


tunes2()
{

printf("\n\n\nmore experimental \n");
        bit_synth (50,160,163,50,50);
        bit_synth (50,160,163,50,50);
        bit_synth (50,177,180,44,44);
        bit_synth (50,177,180,44,44);
        bit_synth (50,177,180,50,50);
        bit_synth (50,177,180,50,50);
        bit_synth (50,160,163,53,53);
        bit_synth (50,160,163,53,53);


        bit_synth (50,0,0,0,0);


        bit_synth (50,160,163,50,50);
        bit_synth (50,160,163,50,50);
        bit_synth (50,177,180,44,44);
        bit_synth (50,177,180,44,44);
        bit_synth (50,177,180,50,50);
        bit_synth (50,177,180,50,50);
        bit_synth (50,160,163,53,53);
        bit_synth (50,160,163,53,53);






        bit_synth (50,133,136,53,53);
        bit_synth (50,133,136,60,60);
        bit_synth (50,133,136,53,53);
        bit_synth (50,133,136,50,50);

        bit_synth (50,150,153,44,44);
        bit_synth (50,150,153,50,50);
        bit_synth (50,150,153,44,44);
        bit_synth (50,150,153,53,53);

        bit_synth (50,160,163,50,50);
        bit_synth (50,160,163,53,53);
        bit_synth (50,177,180,50,50);
        bit_synth (50,177,180,44,44);

        bit_synth (50,200,203,40,40);
        bit_synth (50,200,203,44,44);
        bit_synth (50,160,163,50,50);
        bit_synth (50,160,163,53,53);

        bit_synth (30,133,136,53,53);
        bit_synth (30,133,136,60,60);
        bit_synth (30,133,136,53,53);
        bit_synth (30,133,136,50,50);
        bit_synth (30,150,153,44,44);
        bit_synth (30,150,153,50,50);
        bit_synth (30,150,153,44,44);
        bit_synth (30,150,153,53,53);
        bit_synth (30,160,163,50,50);
        bit_synth (30,160,163,53,53);
        bit_synth (30,177,180,50,50);
        bit_synth (30,177,180,44,44);
        bit_synth (30,200,203,40,40);
        bit_synth (30,200,203,44,44);
        bit_synth (30,160,163,50,50);
        bit_synth (30,160,163,53,53);


        bit_synth (30,133,137,53,53);
        bit_synth (30,133,137,60,60);
        bit_synth (30,133,137,53,53);
        bit_synth (30,133,137,50,50);
        bit_synth (30,150,154,44,44);
        bit_synth (30,150,154,50,50);
        bit_synth (30,150,154,44,44);
        bit_synth (30,150,154,53,53);
        bit_synth (30,160,164,50,50);
        bit_synth (30,160,164,53,53);
        bit_synth (30,177,181,50,50);
        bit_synth (30,177,181,44,44);
        bit_synth (30,200,204,40,40);
        bit_synth (30,200,204,44,44);
        bit_synth (30,160,164,50,50);
        bit_synth (30,160,164,53,53);

printf("\n\n...and the beat kicks in \n");
//--------

        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,61,60);
        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,54,53);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,177,180,51,50);
        bit_synth (30,177,180,45,44);
        bit_synth (30,200,203,41,40);
        bit_synth (30,200,203,45,44);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);

        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,61,60);
        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,54,53);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,177,180,51,50);
        bit_synth (30,177,180,45,44);
        bit_synth (30,200,203,41,40);
        bit_synth (30,200,203,45,44);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);

        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,61,60);
        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,54,53);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,177,180,51,50);
        bit_synth (30,177,180,45,44);
        bit_synth (30,200,203,41,40);
        bit_synth (30,200,203,45,44);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);

        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,177,180,51,50);
        bit_synth (30,177,180,45,44);
        bit_synth (30,200,203,41,40);
        bit_synth (30,200,203,45,44);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,177,180,51,50);
        bit_synth (30,177,180,45,44);
        bit_synth (30,200,203,41,40);
        bit_synth (30,200,203,45,44);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);

        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,61,60);
        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,54,53);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,177,180,51,50);
        bit_synth (30,177,180,45,44);
        bit_synth (30,200,203,41,40);
        bit_synth (30,200,203,45,44);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);

        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,61,60);
        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,54,53);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,177,180,51,50);
        bit_synth (30,177,180,45,44);
        bit_synth (30,200,203,41,40);
        bit_synth (30,200,203,45,44);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);

        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,61,60);
        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,54,53);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,177,180,51,50);
        bit_synth (30,177,180,45,44);
        bit_synth (30,200,203,41,40);
        bit_synth (30,200,203,45,44);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);

        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,61,60);
        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,54,53);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,177,180,51,50);
        bit_synth (30,177,180,45,44);
        bit_synth (30,200,203,41,40);
        bit_synth (30,200,203,45,44);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);

        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,61,60);
        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,54,53);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,177,180,51,50);
        bit_synth (30,177,180,45,44);
        bit_synth (30,200,203,41,40);
        bit_synth (30,200,203,45,44);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);

        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,177,180,51,50);
        bit_synth (30,177,180,45,44);
        bit_synth (30,200,203,41,40);
        bit_synth (30,200,203,45,44);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,177,180,51,50);
        bit_synth (30,177,180,45,44);
        bit_synth (30,200,203,41,40);
        bit_synth (30,200,203,45,44);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);

        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,61,60);
        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,54,53);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,177,180,51,50);
        bit_synth (30,177,180,45,44);
        bit_synth (30,200,203,41,40);
        bit_synth (30,200,203,45,44);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);

        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,61,60);
        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,54,53);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,177,180,51,50);
        bit_synth (30,177,180,45,44);
        bit_synth (30,200,203,41,40);
        bit_synth (30,200,203,45,44);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);

        bit_synth (50,133,136,54,53);
        bit_synth (50,133,136,61,60);
        bit_synth (50,133,136,54,53);
        bit_synth (50,133,136,51,50);
        bit_synth (50,150,153,45,44);
        bit_synth (50,150,153,51,50);
        bit_synth (50,150,153,45,44);
        bit_synth (50,150,153,54,53);
        bit_synth (50,160,163,51,50);
        bit_synth (50,160,163,54,53);
        bit_synth (50,177,180,51,50);
        bit_synth (50,177,180,45,44);
        bit_synth (50,200,203,41,40);
        bit_synth (50,200,203,45,44);
        bit_synth (50,160,163,51,50);
        bit_synth (50,160,163,54,53);

        bit_synth (50,133,136,54,53);
        bit_synth (50,133,136,61,60);
        bit_synth (50,133,136,54,53);
        bit_synth (50,133,136,51,50);
        bit_synth (50,150,153,45,44);
        bit_synth (50,150,153,51,50);
        bit_synth (50,150,153,45,44);
        bit_synth (50,150,153,54,53);
        bit_synth (50,160,163,51,50);
        bit_synth (50,160,163,54,53);
        bit_synth (50,177,180,51,50);
        bit_synth (50,177,180,45,44);
        bit_synth (50,200,203,41,40);
        bit_synth (50,200,203,45,44);
        bit_synth (50,160,163,51,50);
        bit_synth (50,160,163,54,53);

}


tunes3()
{
	printf("\n\nsoft - End music to Microman\n");
	printf("a game by steffano that wont\n");
	printf("compile correctly for me.\n\n");
    // MUSIC
    bit_synth (50,200,200,40,40);
    bit_synth (25,160,160,50,50);
    bit_synth (9,160,160,162,162);
    bit_synth (50,200,200,33,33);
    bit_synth (100,200,200,40,40);
    bit_synth (50,160,160,50,50);
    bit_synth (50,177,177,37,37);
    bit_synth (25,150,150,44,44);
    bit_synth (9,150,150,152,152);
    bit_synth (50,160,160,33,33);
    bit_synth (100,177,177,37,37);
    bit_synth (50,150,150,44,44);
    bit_synth (20,160,160,50,50);
    bit_synth (20,160,160,44,44);
    bit_synth (20,200,200,40,40);
    bit_synth (20,150,150,44,44);
    bit_synth (20,150,150,40,40);
    bit_synth (25,160,160,33,33);
    bit_synth (20,150,150,40,40);
    bit_synth (25,160,160,33,33);
    bit_synth (20,200,200,50,50);
    bit_synth (25,160,160,33,33);
    bit_synth (20,200,200,50,50);
    bit_synth (70,160,160,29,29);
    bit_synth (255,100,100,25,25);
    // LOUD MUSIC

	printf("\nloud version\n\n\n");
    bit_synth (50,200,201,40,41);
    bit_synth (25,160,161,50,51);
    bit_synth (9,160,161,162,163);
    bit_synth (50,200,201,33,34);
    bit_synth (100,200,201,40,41);
    bit_synth (50,160,161,50,51);

    bit_synth (50,177,178,37,38);
    bit_synth (25,150,151,44,45);
    bit_synth (9,150,151,152,153);
    bit_synth (50,160,161,33,34);
    bit_synth (100,177,178,37,38);

    bit_synth (50,150,151,44,45);

    bit_synth (20,160,161,50,51);
    bit_synth (20,160,161,44,45);
    bit_synth (20,200,201,40,41);
    bit_synth (20,150,151,44,45);
    bit_synth (20,150,151,40,41);
    bit_synth (25,160,161,33,34);
    bit_synth (20,150,151,40,41);
    bit_synth (25,160,161,33,34);
    bit_synth (40,200,201,50,51);
    bit_synth (9,150,151,152,153);
    bit_synth (180,200,201,50,51);
}







tunes4()
{
	printf("other End music - Microman\n");
    // LOUD MUSIC
    bit_synth (50,200,201,40,41);
    bit_synth (25,160,161,50,51);
    bit_synth (9,160,161,162,163);
    bit_synth (50,200,201,33,34);
    bit_synth (100,200,201,40,41);
    bit_synth (50,160,161,50,51);
    bit_synth (50,177,178,37,38);
    bit_synth (25,150,151,44,45);
    bit_synth (9,150,151,152,153);
    bit_synth (50,160,161,33,34);
    bit_synth (100,177,178,37,38);
    bit_synth (50,150,151,44,45);
    bit_fx2(7);
    bit_synth (20,160,161,50,51);
    bit_synth (20,160,161,44,45);
    bit_synth (20,200,201,40,41);
    bit_synth (20,150,151,44,45);
    bit_synth (20,150,151,40,41);
    bit_synth (25,160,161,33,34);
    bit_synth (20,150,151,40,41);
    bit_synth (25,160,161,33,34);
    bit_synth (40,200,201,50,51);
    bit_synth (9,150,151,152,153);
    bit_synth (70,160,161,29,28);
    bit_synth (180,200,201,50,51);
}



tunes5()  					// VZ techno piece...
{
//         123456789012345678901234567890
   printf("\n\n\nThe vz going all out with a \n");
   printf("techno beat of 160 beats per\n ");
   printf("minute.\n\n");
   printf("    ever heard your vz do\n");
   printf("         this before?\n\n");
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(6);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(6);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(6);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(6);
   bit_fx2(6);
   bit_fx2(6);
   bit_fx2(5);
   bit_fx2(6);
   bit_fx2(6);
   bit_fx2(6);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(6);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(6);
   bit_fx2(5);
   bit_fx2(6);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(6);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);

printf("2\n");
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx(2);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx(2);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx(2);
   bit_fx2(6);
   bit_fx2(6);
   bit_fx2(6);
   bit_fx(2);
   bit_fx2(6);
   bit_fx2(6);
   bit_fx2(6);

printf("3\n");
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx3(6);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx3(6);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx3(6);


}

tunes6()
{}
tunes7()
{}
tunes8()
{}
tunes9()
{}
tunes10()
{}
tunes11()
{}
tunes12()
{}
tunes13()
{}

}