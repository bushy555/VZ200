
Stefano Bodrato wrote some sound routines which are both sound effects and synth type music for 1 bit sound
for multiple target platforms within the Z88 Development Kit back in version 1.6 around the 23/May/2006.
(He be a talented smart bloke)
With a few changes, these programs should run on heaps of other targets that the Z88 targets to.
Spectrum, ZX, CPC, heaps of stuff that run the Z80 processor.

---------------------------------------------------------

SOUND EFFECTS:

bit_fx(0)    Short hi-pitch decreasing "gulp/fall" sound
bit_fx(1)    Fast increasing scale
bit_fx(2)    Fast increasing squeak, mid duration, high pitch
bit_fx(3)    Crash sound, mid duration
bit_fx(4)    Fast increasing squeak/jump, short duration
bit_fx(5)    Short two tones clackson sound
bit_fx(6)    Two tones mid/high pitch bright beep
bit_fx(7)    Medium duration moving down, then up

bit_fx2(0)    Sort of electronic synth, mid-low tone, mid duration
bit_fx2(1)    Mid duration low tone, beating waves effect
bit_fx2(2)    Quick low pitch electronic buzz/noise
bit_fx2(3)    Long two tones truck clackson
bit_fx2(4)    Two tones increasing sound, electr. fx, mid duration
bit_fx2(5)    Two tones bounce sound
bit_fx2(6)    Alt. two tones bounce sound
bit_fx2(7)    Long low explosion sound

bit_fx3(0)    Quick noisy high pitch buzz / break noise
bit_fx3(1)    Longer very noisy high pitch buzz
bit_fx3(2)    Very quick low electronic noise / explosion / drum
bit_fx3(3)    Short low explosion sound
bit_fx3(4)    Electronic zap, mid duration
bit_fx3(5)    Noisy high pitch short increasing sound
bit_fx3(6)    Low level noise (AM radio noise)
bit_fx3(7)    Quick high pitch tremolo sound

bit_fx4(0)    Very quick squeaky sound
bit_fx4(1)    Tape rewind effect, long duration
bit_fx4(2)    Fast squeak/bounce/duck sound
bit_fx4(3)    Fall-down, mid duration
bit_fx4(4)    High pitch fall-down sound, long duration
bit_fx4(5)    Short high pitch slightly noisy decreasing sound
bit_fx4(6)    Short jump sound
bit_fx4(7)    Very quick duck squeak

-----------------------------------------------------------------------
//
// VZ Orchestra. or VZ Organ. or VZ NOISE.
//
// /dave.                                dave.maunder@gmail.com
// 15 August 2013.
// First release of any  C  programming  in  over ten years, so 
// please excuse my RAGE (Rough As Guts Engineering) structure,
// layout and thought process.
//
// Graphics intro made in Paint Shop Pro 7  and  converted over
// to POKE statements via my own ten year old written-in-intel-
// assembly conversion utilitys. Was surprised that  they still 
// worked! I think that these are in 'utils' in the yahoogroups 
// files section.
//
// This be written in C for  the VZ/Laser/Sanyo/Texet/Salarion.
// 
// 
// KNOWN BUG:
// * Music notes on  each key are currently in the wrong place.
//   I roughly and  very quickly assigned  various unique notes
//   to  keys  sort   of   randomly,   and   not  in any order. 
//   NEEDS FIXING.
//
//  * keyboard input.  NEEDS FIXING.  (keyboard buffer overrun)
//
//
// Compile with Z88DK v1.10.1
// with the following:
//             call z88dkenv.bat
//             zcc +vz -O3 -vn %1.c -o %1.vz -create-app -lndos
//
//
//
// Keys:
//      1 - shorter sound duration
//      2 - longer sound duration
//      3 - Sound effects keyboard
//      4 - normal piano/organ keyboard
//      5 - normal sounding organ
//      6 - distortion sounding organ
//      7 - "FULLY SIK" sounding organ
//      Rest of keys - press them to make noise
//
// --------------------------------------------------------