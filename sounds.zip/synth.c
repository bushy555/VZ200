#pragma output nostreams
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <vz.h>
#include <sound.h>


main() {
   int	i;
   i=1;
   
   /* vz_clrscr; */

//   bit_fx2(4);
//   bit_fx2(4);
//   bit_fx2(7);


/*   vz_sound(24,50);
   vz_sound(25,50);
   vz_sound(26,50);
   vz_sound(25,50);
   vz_sound(26,50);
   vz_sound(27,50);
   vz_sound(32,100);
   vz_sound(24,100);
   vz_sound(20,100);  
   vz_sound(24,100);
   vz_sound(28,100);
   vz_sound(24,100);
   vz_sound(32,100);
   vz_sound(24,100);
   vz_sound(20,100);  
   vz_sound(24,100);
   vz_sound(28,100);
   vz_sound(24,100);
   vz_sound(32,100);
   vz_sound(24,100);
   vz_sound(20,600);  
*/



   while ( i==1) {

	   printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
	   printf("Sound music\n");


	   printf("1 - tune demo\n");
	   printf("2 - tune #1  (tune)\n");
	   printf("3 - tune #2  (tune)\n");
	   printf("4 - tune #3  (end music 1)\n");
	   printf("5 - tune #4  (end music 2)\n");  
	   printf("6 - tune #5  (vz teckno)\n");  
	   printf("7 - tune #6  (elec organ)\n");  
	   printf("8 - tune #7  (TEST)     \n");  
	   printf("9 - tune #8  (TEST 2)\n");  
	   printf("0 - tune #9  (rand 1)\n");  
	   printf("A - tune #10 (rand 2)\n");  

      switch( toupper(vz_getch()) ) {      

	case '1':
             vz_getch();
             tunesdemo();
             break;
        case '2':
             vz_getch();
             tunes1();
             break;
        case '3':
             vz_getch();
             tunes2();
             break;
        case '4':
             vz_getch();
             tunes3();
             break;
        case '5':
             vz_getch();
             tunes4();
             break;
        case '6':
             vz_getch();
             tunes5();
             break;             
        case '7':
             vz_getch();
             tunes6();
             break;             
        case '8':
             vz_getch();
             tunes7();
             break;             
        case '9':
             vz_getch();
             tunes8();
             break;             
        case '0':
             vz_getch();
             tunes9();
             break;             
        case 'A':
             vz_getch();
             tunes10();
             break;             
        }
      }
   }






tunesdemo()
{
/* $Id: synthdemo.c,v 1.1 2006/05/23 20:42:51 stefano Exp $
The Synth library generates many waveforms basing on sound duration and 4 harmonics.
It is possible to simulate several instruments or even two voices 

Synth demo #1: By varying the dinstance between harmonics it is possible to emulate polyphonic ensembles.
In this case we almost neutralize the vibrations to get very low and clean sounds.
Higher frequencies are emphasized.

Synth demo #2 (second section): Now we play the same melody using the same trick,
but the phases have been chosen to get as much harmonics as possible.
The effect is very similar to what we can get with distortion.

Note: in both the samples the note duration isn't accurate.. I still haven't found a
formula for that, and obviously lower frequencies last longer.
I set the values experimentally.

Stefano Bodrato - 23/5/2006
*/

	printf("\n\nLow tones \n");
	printf("1st theme \n");

        bit_synth (100,200,200,40,40);
        bit_synth (100,200,200,33,33);

        bit_synth (100,177,177,37,37);
        bit_synth (100,150,150,44,44);

        bit_synth (100,160,160,50,50);
        bit_synth (100,200,200,40,40);

        bit_synth (100,133,133,44,44);
        bit_synth (100,150,150,44,44);

        bit_synth (100,160,160,50,50);
        bit_synth (100,200,200,40,40);

        bit_synth (100,150,150,44,44);
        bit_synth (100,177,177,37,37);

        bit_synth (100,133,133,40,40);
        bit_synth (100,133,133,44,44);

        bit_synth (150,200,200,50,50);



	printf("2nd theme \n");

        bit_synth (100,133,133,53,53);
        bit_synth (100,133,133,50,50);

        bit_synth (100,150,150,44,44);
        bit_synth (100,150,150,53,53);

        bit_synth (100,160,160,50,50);
        bit_synth (100,177,177,44,44);

        bit_synth (100,200,200,40,40);
        bit_synth (100,160,160,40,40);

        bit_synth (100,150,150,60,60);
        bit_synth (100,150,150,44,44);

        bit_synth (100,133,133,53,53);
        bit_synth (100,160,160,50,50);

        bit_synth (100,150,150,44,44);
        bit_synth (100,133,133,53,53);

        bit_synth (150,200,200,50,50);


	printf("Variation on 1st theme \n");

        bit_synth (50,200,200,40,40);
        bit_synth (50,200,200,37,37);
        bit_synth (50,200,200,33,33);
        bit_synth (50,200,200,40,40);

        bit_synth (50,177,177,33,33);
        bit_synth (50,177,177,37,37);
        bit_synth (50,150,150,40,40);
        bit_synth (50,150,150,44,44);

        bit_synth (50,160,160,50,50);
        bit_synth (50,160,160,44,44);
        bit_synth (50,200,200,40,40);
        bit_synth (50,200,200,50,50);

        bit_synth (50,133,133,44,44);
        bit_synth (50,133,133,50,50);
        bit_synth (50,150,150,44,44);
        bit_synth (50,150,150,40,40);

        bit_synth (50,160,160,50,50);
        bit_synth (50,160,160,33,33);
        bit_synth (50,200,200,37,37);
        bit_synth (50,200,200,40,40);

        bit_synth (50,150,150,44,44);
        bit_synth (50,150,150,40,40);
        bit_synth (50,177,177,37,37);
        bit_synth (50,177,177,44,44);

        bit_synth (50,133,133,40,40);
        bit_synth (50,133,133,37,37);
        bit_synth (50,133,133,44,44);
        bit_synth (50,133,133,40,40);

        bit_synth (50,200,200,50,50);
        bit_synth (50,200,200,40,40);
        bit_synth (50,200,200,50,50);

	printf("Variation on 2nd theme \n");

        bit_synth (50,133,133,53,53);
        bit_synth (50,133,133,60,60);
        bit_synth (50,133,133,53,53);
        bit_synth (50,133,133,50,50);

        bit_synth (50,150,150,44,44);
        bit_synth (50,150,150,50,50);
        bit_synth (50,150,150,44,44);
        bit_synth (50,150,150,53,53);

        bit_synth (50,160,160,50,50);
        bit_synth (50,160,160,53,53);
        bit_synth (50,177,177,50,50);
        bit_synth (50,177,177,44,44);

        bit_synth (50,200,200,40,40);
        bit_synth (50,200,200,44,44);
        bit_synth (50,160,160,50,50);
        bit_synth (50,160,160,53,53);

        bit_synth (50,150,150,60,60);
        bit_synth (50,150,150,53,53);
        bit_synth (50,150,150,50,50);
        bit_synth (50,150,150,44,44);

        bit_synth (50,133,133,50,50);
        bit_synth (50,133,133,53,53);
        bit_synth (50,160,160,44,44);
        bit_synth (50,160,160,50,50);

        bit_synth (50,150,150,40,40);
        bit_synth (50,150,150,44,44);
        bit_synth (50,133,133,50,50);
        bit_synth (50,133,133,53,53);

        bit_synth (150,200,200,50,50);


	printf("\n\nDistortion \n");
	printf("1st theme \n");

        bit_synth (100,200,201,40,41);
        bit_synth (100,200,201,33,34);

        bit_synth (100,177,178,37,38);
        bit_synth (100,150,151,44,45);

        bit_synth (100,160,161,50,51);
        bit_synth (100,200,201,40,41);

        bit_synth (100,133,134,44,45);
        bit_synth (100,150,151,44,45);

        bit_synth (100,160,161,50,51);
        bit_synth (100,200,201,40,41);

        bit_synth (100,150,151,44,45);
        bit_synth (100,177,178,37,38);

        bit_synth (100,133,134,40,41);
        bit_synth (100,133,134,44,45);

        bit_synth (150,200,201,50,51);



	printf("2nd theme \n");

        bit_synth (100,133,134,53,54);
        bit_synth (100,133,134,50,51);

        bit_synth (100,150,151,44,45);
        bit_synth (100,150,151,53,54);

        bit_synth (100,160,161,50,51);
        bit_synth (100,177,178,44,45);

        bit_synth (100,200,201,40,41);
        bit_synth (100,160,161,40,41);

        bit_synth (100,150,151,60,61);
        bit_synth (100,150,151,44,45);

        bit_synth (100,133,134,53,54);
        bit_synth (100,160,161,50,51);

        bit_synth (100,150,151,44,45);
        bit_synth (100,133,134,53,54);

        bit_synth (150,200,201,50,51);


	printf("Variation on 1st theme \n");

        bit_synth (50,200,201,40,41);
        bit_synth (50,200,201,37,38);
        bit_synth (50,200,201,33,34);
        bit_synth (50,200,201,40,41);

        bit_synth (50,177,178,33,34);
        bit_synth (50,177,178,37,38);
        bit_synth (50,150,151,40,41);
        bit_synth (50,150,151,44,45);

        bit_synth (50,160,161,50,51);
        bit_synth (50,160,161,44,45);
        bit_synth (50,200,201,40,41);
        bit_synth (50,200,201,50,51);

        bit_synth (50,133,134,44,45);
        bit_synth (50,133,134,50,51);
        bit_synth (50,150,151,44,45);
        bit_synth (50,150,151,40,41);

        bit_synth (50,160,161,50,51);
        bit_synth (50,160,161,33,34);
        bit_synth (50,200,201,37,38);
        bit_synth (50,200,201,40,41);

        bit_synth (50,150,151,44,45);
        bit_synth (50,150,151,40,41);
        bit_synth (50,177,178,37,38);
        bit_synth (50,177,178,44,45);

        bit_synth (50,133,134,40,41);
        bit_synth (50,133,134,37,38);
        bit_synth (50,133,134,44,45);
        bit_synth (50,133,134,40,41);

        bit_synth (50,200,201,50,51);
        bit_synth (50,200,201,40,41);
        bit_synth (50,200,201,50,51);

	printf("Variation on 2nd theme \n");

        bit_synth (50,133,134,53,54);
        bit_synth (50,133,134,60,61);
        bit_synth (50,133,134,53,54);
        bit_synth (50,133,134,50,51);

        bit_synth (50,150,151,44,45);
        bit_synth (50,150,151,50,51);
        bit_synth (50,150,151,44,45);
        bit_synth (50,150,151,53,54);

        bit_synth (50,160,161,50,51);
        bit_synth (50,160,161,53,54);
        bit_synth (50,177,178,50,51);
        bit_synth (50,177,178,44,45);

        bit_synth (50,200,201,40,41);
        bit_synth (50,200,201,44,45);
        bit_synth (50,160,161,50,51);
        bit_synth (50,160,161,53,54);

        bit_synth (50,150,151,60,61);
        bit_synth (50,150,151,53,54);
        bit_synth (50,150,151,50,51);
        bit_synth (50,150,151,44,45);

        bit_synth (50,133,134,50,51);
        bit_synth (50,133,134,53,54);
        bit_synth (50,160,161,44,45);
        bit_synth (50,160,161,50,51);

        bit_synth (50,150,151,40,41);
        bit_synth (50,150,151,44,45);
        bit_synth (50,133,134,50,51);
        bit_synth (50,133,134,53,54);

        bit_synth (150,200,201,50,51);
}




tunes1()
{
  printf("bit_synth \n");

/* bit_synth(int duration, int frequency1, int frequency2, int frequency3, int frequency4); */


        bit_synth (50,160,163,50,50);
        bit_synth (50,160,163,50,50);
        bit_synth (20,0,0,0,0);
        bit_synth (50,177,180,44,44);
        bit_synth (50,177,180,44,44);
        bit_synth (20,0,0,0,0);
        bit_synth (50,177,180,50,50);
        bit_synth (50,177,180,50,50);
        bit_synth (20,0,0,0,0);
        bit_synth (50,160,163,53,53);
        bit_synth (50,160,163,53,53);

        bit_synth (20,160,163,50,50);
        bit_synth (20,160,163,50,50);
        bit_synth (20,177,180,44,44);
        bit_synth (20,177,180,44,44);
        bit_synth (20,177,180,50,50);
        bit_synth (20,177,180,50,50);
        bit_synth (20,160,163,53,53);
        bit_synth (20,160,163,53,53);
        bit_synth (20,177,180,44,44);
        bit_synth (20,177,180,44,44);
        bit_synth (20,160,163,53,53);
        bit_synth (20,160,163,53,53);
        bit_synth (20,160,163,50,50);
        bit_synth (20,160,163,50,50);
        bit_synth (20,160,163,50,50);
        bit_synth (20,160,163,50,50);
        bit_synth (20,160,163,53,53);
        bit_synth (20,160,163,53,53);
        bit_synth (20,160,163,50,50);
        bit_synth (20,160,163,50,50);
        bit_synth (20,177,180,44,44);
        bit_synth (20,177,180,44,44);
        bit_synth (20,177,180,50,50);
        bit_synth (20,177,180,50,50);
        bit_synth (20,160,163,53,53);
        bit_synth (20,160,163,53,53);
        bit_synth (20,177,180,44,44);
        bit_synth (20,177,180,44,44);
        bit_synth (20,160,163,53,53);
        bit_synth (20,160,163,53,53);
        bit_synth (20,160,163,50,50);
        bit_synth (20,160,163,50,50);
        bit_synth (20,160,163,50,50);
        bit_synth (20,160,163,50,50);
        bit_synth (20,160,163,53,53);
        bit_synth (20,160,163,53,53);


        bit_synth (20,133,136,53,53);
        bit_synth (20,133,136,60,60);
        bit_synth (20,133,136,53,53);
        bit_synth (20,133,136,60,60);
        bit_synth (20,133,136,53,53);
        bit_synth (20,133,136,50,50);
        bit_synth (20,133,136,53,53);
        bit_synth (20,133,136,50,50);

        bit_synth (20,150,153,44,44);
        bit_synth (20,150,153,50,50);
        bit_synth (20,150,153,44,44);
        bit_synth (20,150,153,50,50);
        bit_synth (20,150,153,44,44);
        bit_synth (20,150,153,53,53);
        bit_synth (20,150,153,44,44);
        bit_synth (20,150,153,53,53);

        bit_synth (20,160,163,50,50);
        bit_synth (20,160,163,53,53);
        bit_synth (20,160,163,50,50);
        bit_synth (20,160,163,53,53);
        bit_synth (20,177,180,50,50);
        bit_synth (20,177,180,44,44);
        bit_synth (20,177,180,50,50);
        bit_synth (20,177,180,44,44);

        bit_synth (20,200,203,40,40);
        bit_synth (20,200,203,44,44);
        bit_synth (20,200,203,40,40);
        bit_synth (20,200,203,44,44);
        bit_synth (20,160,163,50,50);
        bit_synth (20,160,163,53,53);
        bit_synth (20,160,163,50,50);
        bit_synth (20,160,163,53,53);




        bit_synth (50,160,163,50,50);
        bit_synth (50,160,163,50,50);
        bit_synth (50,177,180,44,44);
        bit_synth (50,177,180,44,44);
        bit_synth (50,177,180,50,50);
        bit_synth (50,177,180,50,50);
        bit_synth (50,160,163,53,53);
        bit_synth (50,160,163,53,53);
        bit_synth (50,160,163,50,50);
        bit_synth (50,160,163,50,50);
        bit_synth (50,177,180,44,44);
        bit_synth (50,177,180,44,44);
        bit_synth (50,177,180,50,50);
        bit_synth (50,177,180,50,50);
        bit_synth (50,160,163,53,53);
        bit_synth (50,160,163,53,53);



        bit_synth (50,160,163,50,50);
        bit_synth (50,160,163,50,50);
        bit_synth (50,177,180,44,44);
        bit_synth (50,177,180,44,44);
        bit_synth (50,177,180,50,50);
        bit_synth (50,177,180,50,50);
        bit_synth (50,160,163,53,53);
        bit_synth (50,160,163,53,53);






        bit_synth (50,133,136,53,53);
        bit_synth (50,133,136,60,60);
        bit_synth (50,133,136,53,53);
        bit_synth (50,133,136,50,50);

        bit_synth (50,150,153,44,44);
        bit_synth (50,150,153,50,50);
        bit_synth (50,150,153,44,44);
        bit_synth (50,150,153,53,53);

        bit_synth (50,160,163,50,50);
        bit_synth (50,160,163,53,53);
        bit_synth (50,177,180,50,50);
        bit_synth (50,177,180,44,44);

        bit_synth (50,200,203,40,40);
        bit_synth (50,200,203,44,44);
        bit_synth (50,160,163,50,50);
        bit_synth (50,160,163,53,53);

}


tunes2()
{

printf("\n\n\nmore experimental \n");
        bit_synth (50,160,163,50,50);
        bit_synth (50,160,163,50,50);
        bit_synth (50,177,180,44,44);
        bit_synth (50,177,180,44,44);
        bit_synth (50,177,180,50,50);
        bit_synth (50,177,180,50,50);
        bit_synth (50,160,163,53,53);
        bit_synth (50,160,163,53,53);




        bit_synth (50,160,163,50,50);
        bit_synth (50,160,163,50,50);
        bit_synth (50,177,180,44,44);
        bit_synth (50,177,180,44,44);
        bit_synth (50,177,180,50,50);
        bit_synth (50,177,180,50,50);
        bit_synth (50,160,163,53,53);
        bit_synth (50,160,163,53,53);






        bit_synth (50,133,136,53,53);
        bit_synth (50,133,136,60,60);
        bit_synth (50,133,136,53,53);
        bit_synth (50,133,136,50,50);

        bit_synth (50,150,153,44,44);
        bit_synth (50,150,153,50,50);
        bit_synth (50,150,153,44,44);
        bit_synth (50,150,153,53,53);

        bit_synth (50,160,163,50,50);
        bit_synth (50,160,163,53,53);
        bit_synth (50,177,180,50,50);
        bit_synth (50,177,180,44,44);

        bit_synth (50,200,203,40,40);
        bit_synth (50,200,203,44,44);
        bit_synth (50,160,163,50,50);
        bit_synth (50,160,163,53,53);

        bit_synth (30,133,136,53,53);
        bit_synth (30,133,136,60,60);
        bit_synth (30,133,136,53,53);
        bit_synth (30,133,136,50,50);
        bit_synth (30,150,153,44,44);
        bit_synth (30,150,153,50,50);
        bit_synth (30,150,153,44,44);
        bit_synth (30,150,153,53,53);
        bit_synth (30,160,163,50,50);
        bit_synth (30,160,163,53,53);
        bit_synth (30,177,180,50,50);
        bit_synth (30,177,180,44,44);
        bit_synth (30,200,203,40,40);
        bit_synth (30,200,203,44,44);
        bit_synth (30,160,163,50,50);
        bit_synth (30,160,163,53,53);


        bit_synth (30,133,137,53,53);
        bit_synth (30,133,137,60,60);
        bit_synth (30,133,137,53,53);
        bit_synth (30,133,137,50,50);
        bit_synth (30,150,154,44,44);
        bit_synth (30,150,154,50,50);
        bit_synth (30,150,154,44,44);
        bit_synth (30,150,154,53,53);
        bit_synth (30,160,164,50,50);
        bit_synth (30,160,164,53,53);
        bit_synth (30,177,181,50,50);
        bit_synth (30,177,181,44,44);
        bit_synth (30,200,204,40,40);
        bit_synth (30,200,204,44,44);
        bit_synth (30,160,164,50,50);
        bit_synth (30,160,164,53,53);

printf("\n\nand then the bass line drops... \n");
//--------

        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,61,60);
        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,54,53);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,177,180,51,50);
        bit_synth (30,177,180,45,44);
        bit_synth (30,200,203,41,40);
        bit_synth (30,200,203,45,44);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);

        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,61,60);
        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,54,53);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,177,180,51,50);
        bit_synth (30,177,180,45,44);
        bit_synth (30,200,203,41,40);
        bit_synth (30,200,203,45,44);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);

        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,61,60);
        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,54,53);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,177,180,51,50);
        bit_synth (30,177,180,45,44);
        bit_synth (30,200,203,41,40);
        bit_synth (30,200,203,45,44);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);

        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,177,180,51,50);
        bit_synth (30,177,180,45,44);
        bit_synth (30,200,203,41,40);
        bit_synth (30,200,203,45,44);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,177,180,51,50);
        bit_synth (30,177,180,45,44);
        bit_synth (30,200,203,41,40);
        bit_synth (30,200,203,45,44);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);

        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,61,60);
        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,54,53);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,177,180,51,50);
        bit_synth (30,177,180,45,44);
        bit_synth (30,200,203,41,40);
        bit_synth (30,200,203,45,44);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);

        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,61,60);
        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,54,53);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,177,180,51,50);
        bit_synth (30,177,180,45,44);
        bit_synth (30,200,203,41,40);
        bit_synth (30,200,203,45,44);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);

        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,61,60);
        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,54,53);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,177,180,51,50);
        bit_synth (30,177,180,45,44);
        bit_synth (30,200,203,41,40);
        bit_synth (30,200,203,45,44);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);

        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,61,60);
        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,54,53);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,177,180,51,50);
        bit_synth (30,177,180,45,44);
        bit_synth (30,200,203,41,40);
        bit_synth (30,200,203,45,44);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);

        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,61,60);
        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,54,53);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,177,180,51,50);
        bit_synth (30,177,180,45,44);
        bit_synth (30,200,203,41,40);
        bit_synth (30,200,203,45,44);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);

        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,177,180,51,50);
        bit_synth (30,177,180,45,44);
        bit_synth (30,200,203,41,40);
        bit_synth (30,200,203,45,44);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,177,180,51,50);
        bit_synth (30,177,180,45,44);
        bit_synth (30,200,203,41,40);
        bit_synth (30,200,203,45,44);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);

        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,61,60);
        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,54,53);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,177,180,51,50);
        bit_synth (30,177,180,45,44);
        bit_synth (30,200,203,41,40);
        bit_synth (30,200,203,45,44);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);

        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,61,60);
        bit_synth (30,133,136,54,53);
        bit_synth (30,133,136,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,51,50);
        bit_synth (30,150,153,45,44);
        bit_synth (30,150,153,54,53);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);
        bit_synth (30,177,180,51,50);
        bit_synth (30,177,180,45,44);
        bit_synth (30,200,203,41,40);
        bit_synth (30,200,203,45,44);
        bit_synth (30,160,163,51,50);
        bit_synth (30,160,163,54,53);

        bit_synth (50,133,136,54,53);
        bit_synth (50,133,136,61,60);
        bit_synth (50,133,136,54,53);
        bit_synth (50,133,136,51,50);
        bit_synth (50,150,153,45,44);
        bit_synth (50,150,153,51,50);
        bit_synth (50,150,153,45,44);
        bit_synth (50,150,153,54,53);
        bit_synth (50,160,163,51,50);
        bit_synth (50,160,163,54,53);
        bit_synth (50,177,180,51,50);
        bit_synth (50,177,180,45,44);
        bit_synth (50,200,203,41,40);
        bit_synth (50,200,203,45,44);
        bit_synth (50,160,163,51,50);
        bit_synth (50,160,163,54,53);

        bit_synth (50,133,136,54,53);
        bit_synth (50,133,136,61,60);
        bit_synth (50,133,136,54,53);
        bit_synth (50,133,136,51,50);
        bit_synth (50,150,153,45,44);
        bit_synth (50,150,153,51,50);
        bit_synth (50,150,153,45,44);
        bit_synth (50,150,153,54,53);
        bit_synth (50,160,163,51,50);
        bit_synth (50,160,163,54,53);
        bit_synth (50,177,180,51,50);
        bit_synth (50,177,180,45,44);
        bit_synth (50,200,203,41,40);
        bit_synth (50,200,203,45,44);
        bit_synth (50,160,163,51,50);
        bit_synth (50,160,163,54,53);




        bit_synth (30,133,137,54,53);
        bit_synth (30,133,137,61,60);
        bit_synth (30,133,137,54,53);
        bit_synth (30,133,137,51,50);
        bit_synth (30,150,154,45,44);
        bit_synth (30,150,154,51,50);
        bit_synth (30,150,154,45,44);
        bit_synth (30,150,154,54,53);
        bit_synth (30,160,164,51,50);
        bit_synth (30,160,164,54,53);
        bit_synth (30,177,181,51,50);
        bit_synth (30,177,181,45,44);
        bit_synth (30,200,204,41,40);
        bit_synth (30,200,204,45,44);
        bit_synth (30,160,164,51,50);
        bit_synth (30,160,164,54,53);

        bit_synth (30,133,137,54,53);
        bit_synth (30,133,137,61,60);
        bit_synth (30,133,137,54,53);
        bit_synth (30,133,137,51,50);
        bit_synth (30,150,154,45,44);
        bit_synth (30,150,154,51,50);
        bit_synth (30,150,154,45,44);
        bit_synth (30,150,154,54,53);
        bit_synth (30,160,164,51,50);
        bit_synth (30,160,164,54,53);
        bit_synth (30,177,181,51,50);
        bit_synth (30,177,181,45,44);
        bit_synth (30,200,204,41,40);
        bit_synth (30,200,204,45,44);
        bit_synth (30,160,164,51,50);
        bit_synth (30,160,164,54,53);

}


tunes3()
{
	printf("\n\nsoft - End music to Microman\n");
	printf("a game by steffano that wont\n");
	printf("CORECTLY COmpile for me.\n\n");
    // MUSIC
    bit_synth (50,200,200,40,40);
    bit_synth (25,160,160,50,50);
    bit_synth (9,160,160,162,162);
    bit_synth (50,200,200,33,33);
    bit_synth (100,200,200,40,40);
    bit_synth (50,160,160,50,50);
    bit_synth (50,177,177,37,37);
    bit_synth (25,150,150,44,44);
    bit_synth (9,150,150,152,152);
    bit_synth (50,160,160,33,33);
    bit_synth (100,177,177,37,37);
    bit_synth (50,150,150,44,44);
    bit_synth (20,160,160,50,50);
    bit_synth (20,160,160,44,44);
    bit_synth (20,200,200,40,40);
    bit_synth (20,150,150,44,44);
    bit_synth (20,150,150,40,40);
    bit_synth (25,160,160,33,33);
    bit_synth (20,150,150,40,40);
    bit_synth (25,160,160,33,33);
    bit_synth (20,200,200,50,50);
    bit_synth (25,160,160,33,33);
    bit_synth (20,200,200,50,50);
    bit_synth (70,160,160,29,29);
    bit_synth (255,100,100,25,25);
    // LOUD MUSIC

	printf("\nloud version\n\n\n");
    bit_synth (50,200,201,40,41);
    bit_synth (25,160,161,50,51);
    bit_synth (9,160,161,162,163);
    bit_synth (50,200,201,33,34);
    bit_synth (100,200,201,40,41);
    bit_synth (50,160,161,50,51);

    bit_synth (50,177,178,37,38);
    bit_synth (25,150,151,44,45);
    bit_synth (9,150,151,152,153);
    bit_synth (50,160,161,33,34);
    bit_synth (100,177,178,37,38);

    bit_synth (50,150,151,44,45);

    bit_synth (20,160,161,50,51);
    bit_synth (20,160,161,44,45);
    bit_synth (20,200,201,40,41);
    bit_synth (20,150,151,44,45);
    bit_synth (20,150,151,40,41);
    bit_synth (25,160,161,33,34);
    bit_synth (20,150,151,40,41);
    bit_synth (25,160,161,33,34);
    bit_synth (40,200,201,50,51);
    bit_synth (9,150,151,152,153);
    bit_synth (180,200,201,50,51);
}







tunes4()
{
	printf("other End music - Microman\n");
    // LOUD MUSIC
    bit_synth (50,200,201,40,41);
    bit_synth (25,160,161,50,51);
    bit_synth (9,160,161,162,163);
    bit_synth (50,200,201,33,34);
    bit_synth (100,200,201,40,41);
    bit_synth (50,160,161,50,51);
    bit_synth (50,177,178,37,38);
    bit_synth (25,150,151,44,45);
    bit_synth (9,150,151,152,153);
    bit_synth (50,160,161,33,34);
    bit_synth (100,177,178,37,38);
    bit_synth (50,150,151,44,45);
    bit_fx2(7);
    bit_synth (20,160,161,50,51);
    bit_synth (20,160,161,44,45);
    bit_synth (20,200,201,40,41);
    bit_synth (20,150,151,44,45);
    bit_synth (20,150,151,40,41);
    bit_synth (25,160,161,33,34);
    bit_synth (20,150,151,40,41);
    bit_synth (25,160,161,33,34);
    bit_synth (40,200,201,50,51);
    bit_synth (9,150,151,152,153);
    bit_synth (70,160,161,29,28);
    bit_synth (180,200,201,50,51);
}



tunes5()  					// VZ techno piece...
{
//         123456789012345678901234567890
   printf("\n\n\nThe vz going all out with a \n");
   printf("techno beat of 160 beats per\n ");
   printf("minute.\n\n");
   printf("    ever heard your vz do\n");
   printf("         this before?\n\n");
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(6);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(6);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(6);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(6);
   bit_fx2(6);
   bit_fx2(6);
   bit_fx2(5);
   bit_fx2(6);
   bit_fx2(6);
   bit_fx2(6);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(6);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(6);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(6);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(6);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);

   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx(2);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx(2);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx(2);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);

   bit_fx2(6);
   bit_fx2(6);
   bit_fx2(6);
   bit_fx(2);
   bit_fx2(6);
   bit_fx2(6);
   bit_fx2(6);

   bit_fx2(5);
   bit_fx3(6);
   bit_fx3(6);
   bit_fx3(6);

   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(6);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(6);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(6);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(5);
   bit_fx2(6);
   bit_fx2(6);
   bit_fx2(6);
   bit_fx2(5);



}

tunes6()
{
// bit_synth(int duration, int frequency1, int frequency2, int frequency3, int frequency4); */



printf("End game....");

bit_synth (50,200,200,40,40);
   bit_synth (25,160,160,50,50);
   bit_synth (9,160,160,162,162);
   bit_synth (50,200,200,33,33);
   bit_synth (100,200,200,40,40);
   bit_synth (50,160,160,50,50);

   bit_synth (50,177,177,37,37);
   bit_synth (25,150,150,44,44);
   bit_synth (9,150,150,152,152);
   bit_synth (50,160,160,33,33);
   bit_synth (100,177,177,37,37);

   bit_synth (50,200,200,40,40);
   bit_synth (25,160,160,50,50);
   bit_synth (9,160,160,162,162);
   bit_synth (50,200,200,33,33);
   bit_synth (100,200,200,40,40);
   bit_synth (50,160,160,50,50);

   bit_synth (50,137,137,37,37);
   bit_synth (25,140,140,44,44);
   bit_synth (9,150,150,152,152);
   bit_synth (50,140,140,33,33);
   bit_synth (100,150,150,37,37);

   bit_synth (50,200,200,40,40);
   bit_synth (25,160,160,50,50);
   bit_synth (9,160,160,162,162);
   bit_synth (50,200,200,33,33);
   bit_synth (100,200,200,40,40);
   bit_synth (50,160,160,50,50);

   bit_synth (50,177,177,37,37);
   bit_synth (25,150,150,44,44);
   bit_synth (9,150,150,152,152);
   bit_synth (50,160,160,33,33);
   bit_synth (100,177,177,37,37);

   bit_synth (50,200,200,40,40);
   bit_synth (25,160,160,50,50);
   bit_synth (9,160,160,162,162);
   bit_synth (50,200,200,33,33);
   bit_synth (100,200,200,40,40);
   bit_synth (50,160,160,50,50);

   bit_synth (50,137,137,37,37);
   bit_synth (25,140,140,44,44);
   bit_synth (9,150,150,152,152);
   bit_synth (50,140,140,33,33);
   bit_synth (100,150,150,37,37);




   bit_synth (50,150,150,44,44);


   bit_synth (20,160,160,50,50);
   bit_synth (20,160,160,44,44);
   bit_synth (20,200,200,40,40);

   bit_synth (20,150,150,44,44);
   bit_synth (20,150,150,40,40);
   bit_synth (25,160,160,33,33);

   bit_synth (20,150,150,40,40);
   bit_synth (25,160,160,33,33);
   bit_synth (20,200,200,50,50);

   bit_synth (25,160,160,33,33);
   bit_synth (20,200,200,50,50);

   bit_synth (70,160,160,29,29);
   bit_synth (255,100,100,25,25);




printf("-----------------------------------");
 
//    	bit_synth (700,170,171,60,61);
//    	bit_synth (700,170,171,60,62);
//    	bit_synth (700,170,171,60,63);
    	bit_synth (700,170,171,60,64);
    	bit_synth (700,170,171,60,65);
    	bit_synth (700,170,171,60,66);
    	bit_synth (700,170,171,60,67);
//    	bit_synth (700,170,171,60,68);
//    	bit_synth (700,170,171,60,69);


    	bit_synth (700,170,172,60,64);
    	bit_synth (700,170,172,60,65);
    	bit_synth (700,170,172,60,66);
    	bit_synth (700,170,172,60,67);


    	bit_synth (700,170,173,60,64);
    	bit_synth (700,170,173,60,65);
    	bit_synth (700,170,173,60,66);
    	bit_synth (700,170,173,60,67);

    	bit_synth (700,170,172,60,64);
    	bit_synth (700,170,172,60,65);
    	bit_synth (700,170,172,60,66);
    	bit_synth (700,170,172,60,67);

    	bit_synth (700,170,171,60,64);
    	bit_synth (700,170,171,60,65);
    	bit_synth (700,170,171,60,66);
    	bit_synth (700,170,171,60,67);

}


tunes7()
{
printf("low\n");
    	bit_synth (50,150,151,110,111);
    	bit_synth (50,150,151,120,121);
    	bit_synth (50,150,151,130,131);
    	bit_synth (50,160,161,110,111);
    	bit_synth (50,160,161,120,121);
    	bit_synth (50,160,161,130,131);
    	bit_synth (50,140,141,110,111);
    	bit_synth (50,140,141,120,121);
    	bit_synth (50,140,141,130,131);
printf("2\n");
    	bit_synth (50,150,151,110,111);
    	bit_synth (50,150,151,120,121);
    	bit_synth (50,150,151,130,131);

 
	vz_getch();


    	bit_synth (50,150,151,150,151);
    	bit_synth (50,150,151,160,161);
    	bit_synth (50,150,151,170,171);
 
	vz_getch();			//mary had a little lamb

    	bit_synth (50,120,121,110,111);
    	bit_synth (50,140,141,130,131);
    	bit_synth (50,160,161,150,151);
    	bit_synth (50,140,141,130,131);
    	bit_synth (50,120,121,110,111);
    	bit_synth (50,120,121,110,111);
    	bit_synth (50,120,121,110,111);
    	bit_synth (50,140,141,130,131);
    	bit_synth (50,140,141,130,131);
    	bit_synth (50,140,141,130,131);
    	bit_synth (50,120,121,110,111);
    	bit_synth (50,110,111,100,101);
    	bit_synth (50,110,111,100,101);
    	bit_synth (50,120,121,110,111);
    	bit_synth (50,140,141,130,131);
    	bit_synth (50,160,161,150,151);
    	bit_synth (50,140,141,130,131);
    	bit_synth (50,120,121,110,111);
    	bit_synth (50,120,121,110,111);
    	bit_synth (50,120,121,110,111);
    	bit_synth (50,140,141,130,131);
    	bit_synth (50,140,141,130,131);
    	bit_synth (50,120,121,110,111);
    	bit_synth (50,140,141,130,131);
    	bit_synth (50,160,161,150,151);


	vz_getch();

    	bit_synth (50,170,172,160,162);
    	bit_synth (50,180,182,170,172);
    	bit_synth (50,190,192,180,182);
 
	vz_getch();

    	bit_synth (700,160,161,150,151);
    	bit_synth (700,170,171,160,161);
    	bit_synth (700,180,181,170,171);
    	bit_synth (700,190,191,180,181);

    	bit_synth (300,160,162,150,151);
    	bit_synth (300,170,172,160,161);
    	bit_synth (300,180,182,170,171);
    	bit_synth (300,190,192,180,181);

    	bit_synth (300,160,162,150,152);
    	bit_synth (300,170,172,160,162);
    	bit_synth (300,180,182,170,172);
    	bit_synth (300,190,192,180,182);
 
	vz_getch();


    	bit_synth (50,120,122,110,112);
    	bit_synth (50,140,142,130,132);

    	bit_synth (50,160,162,150,152);
    	bit_synth (50,170,172,160,162);
    	bit_synth (50,180,182,170,172);
    	bit_synth (50,190,192,180,182);
	vz_getch();

printf("2\n");
    	bit_synth (700,160,161,50,50);
    	bit_synth (700,161,162,50,50);
    	bit_synth (700,162,163,50,50);
    	bit_synth (700,163,164,50,50);
    	bit_synth (700,164,165,50,50);
    	bit_synth (700,165,166,50,50);
    	bit_synth (700,166,167,50,50);
    	bit_synth (700,167,168,50,50);
    	bit_synth (700,168,169,50,50);
	vz_getch();
printf("4\n");
    	bit_synth (400,160,160,50,51);
    	bit_synth (400,160,160,51,52);
    	bit_synth (400,160,160,52,53);
    	bit_synth (400,160,160,53,54);
    	bit_synth (400,160,160,54,55);
    	bit_synth (400,160,160,55,56);
    	bit_synth (400,160,160,56,57);
    	bit_synth (400,160,160,57,58);
	vz_getch();
printf("a\n");
    	bit_synth (400,160,161,150,150);
printf("b\n");
    	bit_synth (400,160,160,150,151);
printf("c\n");
    	bit_synth (400,160,161,150,151);
printf("d\n");
    	bit_synth (400,160,162,150,150);
printf("e\n");
    	bit_synth (400,160,163,150,150);
printf("f\n");
    	bit_synth (400,160,164,150,150);
	vz_getch();
printf("5\n");
    	bit_synth (400,165,165,50,50);
    	bit_synth (400,165,166,50,50);
	vz_getch();
printf("5\n");
    	bit_synth (400,170,171,60,60);
    	bit_synth (400,170,172,60,60);
    	bit_synth (400,170,173,60,60);
    	bit_synth (400,170,174,60,60);
    	bit_synth (400,170,175,60,60);
    	bit_synth (400,170,176,60,60);
    	bit_synth (400,170,177,60,60);
    	bit_synth (400,170,178,60,60);
    	bit_synth (400,170,179,60,60);
    	bit_synth (400,170,180,60,60);
    	bit_synth (400,170,170,60,60);
    	bit_synth (400,170,170,60,61);
    	bit_synth (400,170,170,60,62);
    	bit_synth (400,170,170,60,63);
    	bit_synth (400,170,170,60,64);
    	bit_synth (400,170,170,60,65);
    	bit_synth (400,170,170,60,66);
    	bit_synth (400,170,170,60,67);
    	bit_synth (400,170,170,60,68);
    	bit_synth (400,170,170,60,69);
    	bit_synth (400,170,170,60,70);
    	bit_synth (400,170,180,60,60);
    	bit_synth (400,170,170,61,60);
    	bit_synth (400,170,170,62,60);
    	bit_synth (400,170,170,63,60);
    	bit_synth (400,170,170,64,60);
    	bit_synth (400,170,170,65,60);
    	bit_synth (400,170,170,66,60);
    	bit_synth (400,170,170,67,60);
    	bit_synth (400,170,170,68,60);
    	bit_synth (400,170,170,69,60);
    	bit_synth (400,170,170,70,60);
printf("6\n");
    	bit_synth (400,170,171,60,60);
    	bit_synth (400,170,171,60,61);
    	bit_synth (400,170,171,60,62);
    	bit_synth (400,170,171,60,63);
    	bit_synth (400,170,171,60,64);
    	bit_synth (400,170,171,60,65);
    	bit_synth (400,170,171,60,66);
    	bit_synth (400,170,171,60,67);
    	bit_synth (400,170,171,60,68);
    	bit_synth (400,170,171,60,69);
    	bit_synth (400,170,171,60,70);
    	bit_synth (400,170,171,60,60);
    	bit_synth (400,170,171,61,60);
    	bit_synth (400,170,171,62,60);
    	bit_synth (400,170,171,63,60);
    	bit_synth (400,170,171,64,60);
    	bit_synth (400,170,171,65,60);
    	bit_synth (400,170,171,66,60);
    	bit_synth (400,170,171,67,60);
    	bit_synth (400,170,171,68,60);
    	bit_synth (400,170,171,69,60);
    	bit_synth (400,170,171,70,60);


    	bit_synth (400,170,171,60,60);
    	bit_synth (400,170,172,60,61);
    	bit_synth (400,170,173,60,62);
    	bit_synth (400,170,174,60,63);
    	bit_synth (400,170,175,60,64);
    	bit_synth (400,170,176,60,65);
    	bit_synth (400,170,177,60,66);
    	bit_synth (400,170,178,60,67);
    	bit_synth (400,170,179,60,68);
    	bit_synth (400,170,180,60,69);
    	bit_synth (400,170,181,60,70);
    	bit_synth (400,170,182,60,60);
    	bit_synth (400,170,183,61,60);
    	bit_synth (400,170,184,62,60);
    	bit_synth (400,170,185,63,60);
    	bit_synth (400,170,186,64,60);
    	bit_synth (400,170,187,65,60);
    	bit_synth (400,170,188,66,60);
    	bit_synth (400,170,189,67,60);
    	bit_synth (400,170,190,68,60);
    	bit_synth (400,170,191,69,60);
    	bit_synth (400,170,192,70,60);
	vz_getch();
}


tunes8()
{
printf("a\n");
	bit_synth(200,200,170,50,50);
	bit_synth(200,200,170,60,60);
	bit_synth(200,200,170,70,70);
	bit_synth(200,200,170,80,80);

	bit_synth(200,200,200,50,50);
	bit_synth(200,200,200,60,60);
	bit_synth(200,200,200,70,70);
	bit_synth(200,200,200,80,80);

	bit_synth(200,210,210,50,50);
	bit_synth(200,210,210,60,60);
	bit_synth(200,210,210,70,70);
	bit_synth(200,210,210,80,80);

	bit_synth(200,220,220,50,50);
	bit_synth(200,220,220,55,55);
	bit_synth(200,220,220,60,60);
	bit_synth(200,220,220,65,65);
	bit_synth(200,220,220,70,70);
	bit_synth(200,220,220,75,75);
	bit_synth(200,220,220,80,80);
	bit_synth(200,220,220,85,85);
printf("a2\n");


        bit_synth (100,200,200,40,40);
        bit_synth (100,200,200,33,33);
        bit_synth (100,200,200,40,40);
        bit_synth (100,200,200,33,33);
        bit_synth (100,200,200,40,40);
        bit_synth (100,200,200,33,33);
        bit_synth (100,200,200,40,40);
        bit_synth (100,200,200,33,33);

        bit_synth (100,177,177,37,37);
        bit_synth (100,150,150,44,44);
        bit_synth (100,177,177,37,37);
        bit_synth (100,150,150,44,44);
        bit_synth (100,177,177,37,37);
        bit_synth (100,150,150,44,44);
        bit_synth (100,177,177,37,37);
        bit_synth (100,150,150,44,44);

        bit_synth (100,160,160,50,50);
        bit_synth (100,200,200,40,40);
        bit_synth (100,160,160,50,50);
        bit_synth (100,200,200,40,40);
        bit_synth (100,160,160,50,50);
        bit_synth (100,200,200,40,40);
        bit_synth (100,160,160,50,50);
        bit_synth (100,200,200,40,40);

        bit_synth (100,133,133,44,44);
        bit_synth (100,150,150,44,44);
        bit_synth (100,133,133,44,44);
        bit_synth (100,150,150,44,44);
        bit_synth (100,133,133,44,44);
        bit_synth (100,150,150,44,44);
        bit_synth (100,133,133,44,44);
        bit_synth (100,150,150,44,44);

        bit_synth (100,160,160,50,50);
        bit_synth (100,200,200,40,40);
        bit_synth (100,160,160,50,50);
        bit_synth (100,200,200,40,40);
        bit_synth (100,160,160,50,50);
        bit_synth (100,200,200,40,40);
        bit_synth (100,160,160,50,50);
        bit_synth (100,200,200,40,40);

        bit_synth (100,150,150,44,44);
        bit_synth (100,177,177,37,37);
        bit_synth (100,150,150,44,44);
        bit_synth (100,177,177,37,37);
        bit_synth (100,150,150,44,44);
        bit_synth (100,177,177,37,37);
        bit_synth (100,150,150,44,44);
        bit_synth (100,177,177,37,37);
        bit_synth (100,150,150,44,44);
        bit_synth (100,177,177,37,37);

        bit_synth (100,133,133,40,40);
        bit_synth (100,133,133,44,44);
        bit_synth (100,133,133,40,40);
        bit_synth (100,133,133,44,44);
        bit_synth (100,133,133,40,40);
        bit_synth (100,133,133,44,44);
        bit_synth (100,133,133,40,40);
        bit_synth (100,133,133,44,44);
        bit_synth (100,133,133,40,40);
        bit_synth (100,133,133,44,44);




printf("0\n");
	bit_synth(100,100,100,10,10);
	bit_synth(100,100,100,20,20);
	bit_synth(100,100,100,30,30);
	bit_synth(100,100,100,40,40);
	bit_synth(100,100,100,50,50);
	bit_synth(100,100,100,60,60);
	bit_synth(100,100,100,70,70);
	bit_synth(100,100,100,80,80);
	bit_synth(100,100,100,90,90);
	bit_synth(100,100,100,100,100);
	bit_synth(100,100,100,110,110);
	bit_synth(100,100,100,120,120);
	bit_synth(100,100,100,130,130);
	bit_synth(100,100,100,140,140);
	bit_synth(100,100,100,150,150);
	bit_synth(100,100,100,160,160);
	bit_synth(100,100,100,170,170);
	bit_synth(100,100,100,180,180);
	bit_synth(100,100,100,190,190);
	bit_synth(100,100,100,200,200);

printf("2\n");
	bit_synth(100,150,150,10,10);
	bit_synth(100,150,150,20,20);
	bit_synth(100,150,150,30,30);
	bit_synth(100,150,150,40,40);
	bit_synth(100,150,150,50,50);
	bit_synth(100,150,150,60,60);
	bit_synth(100,150,150,70,70);
	bit_synth(100,150,150,80,80);
	bit_synth(100,150,150,90,90);
	bit_synth(100,150,150,100,100);
	bit_synth(100,150,150,110,110);
	bit_synth(100,150,150,120,120);
	bit_synth(100,150,150,130,130);
	bit_synth(100,150,150,140,140);
	bit_synth(100,150,150,150,150);
	bit_synth(100,150,150,160,160);
	bit_synth(100,150,150,170,170);
	bit_synth(100,150,150,180,180);
	bit_synth(100,150,150,190,190);
	bit_synth(100,150,150,200,200);
printf("3\n");
	bit_synth(100,200,100,10,10);
	bit_synth(100,200,100,20,20);
	bit_synth(100,200,100,30,30);
	bit_synth(100,200,100,40,40);
	bit_synth(100,200,100,50,50);
	bit_synth(100,200,100,60,60);
	bit_synth(100,200,100,70,70);
	bit_synth(100,200,100,80,80);
	bit_synth(100,200,100,90,90);
	bit_synth(100,200,100,100,100);
	bit_synth(100,200,100,110,110);
	bit_synth(100,200,100,120,120);
	bit_synth(100,200,100,130,130);
	bit_synth(100,200,100,140,140);
	bit_synth(100,200,100,150,150);
	bit_synth(100,200,100,160,160);
	bit_synth(100,200,100,170,170);
	bit_synth(100,200,100,180,180);
	bit_synth(100,200,100,190,190);
	bit_synth(100,200,100,200,200);
printf("4\n");
	bit_synth(100,200,150,10,10);
	bit_synth(100,200,150,20,20);
	bit_synth(100,200,150,30,30);
	bit_synth(100,200,150,40,40);
	bit_synth(100,200,150,50,50);
	bit_synth(100,200,150,60,60);
	bit_synth(100,200,150,70,70);
	bit_synth(100,200,150,80,80);
	bit_synth(100,200,150,90,90);
	bit_synth(100,200,150,100,100);
	bit_synth(100,200,150,110,110);
	bit_synth(100,200,150,120,120);
	bit_synth(100,200,150,130,130);
	bit_synth(100,200,150,140,140);
	bit_synth(100,200,150,150,150);
	bit_synth(100,200,150,160,160);
	bit_synth(100,200,150,170,170);
	bit_synth(100,200,150,180,180);
	bit_synth(100,200,150,190,190);
	bit_synth(100,200,150,200,200);
printf("5\n");
	bit_synth(100,200,200,10,10);
	bit_synth(100,200,200,20,20);
	bit_synth(100,200,200,30,30);
	bit_synth(100,200,200,40,40);
	bit_synth(100,200,200,50,50);
	bit_synth(100,200,200,60,60);
	bit_synth(100,200,200,70,70);
	bit_synth(100,200,200,80,80);
	bit_synth(100,200,200,90,90);
	bit_synth(100,200,200,100,100);
	bit_synth(100,200,200,110,110);
	bit_synth(100,200,200,120,120);
	bit_synth(100,200,200,130,130);
	bit_synth(100,200,200,140,140);
	bit_synth(100,200,200,150,150);
	bit_synth(100,200,200,160,160);
	bit_synth(100,200,200,170,170);
	bit_synth(100,200,200,180,180);
	bit_synth(100,200,200,190,190);
	bit_synth(100,200,200,200,200);

}


tunes9(){
	int i;
	int j;
	int k;
	int l;

	i = rand(200)+100;
	j = rand(200)+100;
	k = rand(200)+100;
	l = rand(200)+100;

	while (vz_inch() =="")	{bit_synth(80, i, j, k, l);} 
}


tunes10(){
	int i;
	int j;
	int k;
	int l;
	int m;

	i = rand(100) + 100;
	j = rand(100) + 100;
	k = rand(50) + 50;
	l = rand(50) + 50;
	m = rand (100)+100;

	while (vz_inch() =="")	{bit_synth(m, i, j, k, l);} 
}


tunes11()
{}
tunes12()
{}
tunes13()
{}

}