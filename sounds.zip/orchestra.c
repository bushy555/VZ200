// --------------------------------------------------------
// --------------------------------------------------------
// --------------------------------------------------------
// --------------------------------------------------------
//
// VZ Orchestra. or VZ Organ. or VZ NOISE.
//
// /dave.                                dave.maunder@gmail.com
// 15 August 2013.
// First release of any  C  programming  in  over ten years, so 
// please excuse my RAGE (Rough As Guts Engineering) structure,
// layout and thought process.
//
// Graphics intro made in Paint Shop Pro 7  and  converted over
// to POKE statements via my own ten year old written-in-intel-
// assembly conversion utilitys. Was surprised that  they still 
// worked! I think that these are in 'utils' in the yahoogroups 
// files section.
//
// This be written in C for  the VZ/Laser/Sanyo/Texet/Salarion.
// 
// 
// KNOWN BUG:
// * Music notes on  each key are currently in the wrong place.
//   I roughly and  very quickly assigned  various unique notes
//   to  keys  sort   of   randomly,   and   not  in any order. 
//   NEEDS FIXING.
//
//  * keyboard input.  NEEDS FIXING.  (keyboard buffer overrun)
//
//
// Compile with Z88DK v1.10.1
// with the following:
//             call z88dkenv.bat
//             zcc +vz -O3 -vn %1.c -o %1.vz -create-app -lndos
//
//
//
// Keys:
//      1 - shorter sound duration
//      2 - longer sound duration
//      3 - Sound effects keyboard
//      4 - normal piano/organ keyboard
//      5 - normal sounding organ
//      6 - distortion sounding organ
//      7 - "FULLY SIK" sounding organ
//      Rest of keys - press them to make noise
//
// --------------------------------------------------------
// --------------------------------------------------------
// --------------------------------------------------------
// --------------------------------------------------------


#include <sound.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <vz.h>
#include <graphics.h>


	int duration;
	int keyboard;



intro()
{
	int	k;
    	vz_mode(1);
    	asm("di\n");
	vz_setbase(0x7000);


	for (k=28672;k<30720;k++)
	{
		bpoke(k,255);
	}

bpoke(0x7002,250);bpoke(0x7003,186);bpoke(0x7004,175);bpoke(0x7005,250);
bpoke(0x7006,250);bpoke(0x7007,175);bpoke(0x7009,250);bpoke(0x700A,191);
bpoke(0x7022,234);bpoke(0x7023,250);
bpoke(0x7024,175);bpoke(0x7025,234);bpoke(0x7027,170);bpoke(0x7029,234);bpoke(0x702A,170);bpoke(0x702B,175);
bpoke(0x7042,171);bpoke(0x7043,250);bpoke(0x7044,175);bpoke(0x7045,234);bpoke(0x7047,234);
bpoke(0x7049,234);bpoke(0x704A,170);bpoke(0x704B,170);bpoke(0x704C,170);bpoke(0x704D,191);
bpoke(0x7061,250);bpoke(0x7062,175);bpoke(0x7063,254);bpoke(0x7064,171);bpoke(0x7065,234);
bpoke(0x7067,170);bpoke(0x7068,191);bpoke(0x7069,171);bpoke(0x706B,170);
bpoke(0x706C,170);bpoke(0x706D,170);bpoke(0x706E,171);
bpoke(0x7081,234);bpoke(0x7082,191);bpoke(0x7083,254);
bpoke(0x7084,171);bpoke(0x7085,235);bpoke(0x7086,171);bpoke(0x7087,170);bpoke(0x7088,191);bpoke(0x7089,171);
bpoke(0x708C,254);bpoke(0x708D,170);bpoke(0x708E,170);
bpoke(0x7095,240);bpoke(0x7096,63);bpoke(0x70A1,170);
bpoke(0x70A3,174);bpoke(0x70A4,171);bpoke(0x70A5,171);bpoke(0x70A6,170);bpoke(0x70A7,170);
bpoke(0x70A8,174);bpoke(0x70A9,175);bpoke(0x70AA,170);
bpoke(0x70AE,234);bpoke(0x70B5,240);bpoke(0x70B7,252);
bpoke(0x70C1,171);bpoke(0x70C2,254);bpoke(0x70C3,174);bpoke(0x70C4,170);bpoke(0x70C5,171);
bpoke(0x70C6,170);bpoke(0x70C7,170);bpoke(0x70C8,174);bpoke(0x70C9,175);bpoke(0x70CA,170);bpoke(0x70CB,170);
bpoke(0x70CE,234);bpoke(0x70CF,191);bpoke(0x70D5,195);bpoke(0x70D7,252);bpoke(0x70D8,15);
bpoke(0x70E1,235);bpoke(0x70E2,250);bpoke(0x70E3,175);
bpoke(0x70E4,170);bpoke(0x70E5,175);bpoke(0x70E6,170);bpoke(0x70E7,170);bpoke(0x70E8,170);bpoke(0x70E9,175);
bpoke(0x70EA,170);bpoke(0x70EB,170);bpoke(0x70EC,170);bpoke(0x70ED,191);bpoke(0x70EE,234);bpoke(0x70EF,191);
bpoke(0x70F5,3);bpoke(0x70F7,252);bpoke(0x70F8,15);bpoke(0x7101,234);
bpoke(0x7102,234);bpoke(0x7103,175);bpoke(0x7104,170);bpoke(0x7105,174);bpoke(0x7106,170);bpoke(0x7107,170);
bpoke(0x7108,186);bpoke(0x7109,190);bpoke(0x710A,170);bpoke(0x710B,170);bpoke(0x710C,170);
bpoke(0x710E,170);bpoke(0x710F,175);
bpoke(0x7114,252);bpoke(0x7115,15);bpoke(0x7116,192);bpoke(0x7118,63);
bpoke(0x7121,250);bpoke(0x7122,170);bpoke(0x7123,175);bpoke(0x7124,170);bpoke(0x7125,174);bpoke(0x7126,170);
bpoke(0x7127,170);bpoke(0x7128,170);bpoke(0x7129,190);bpoke(0x712A,170);bpoke(0x712B,170);bpoke(0x712C,171);
bpoke(0x712D,250);bpoke(0x712E,170);bpoke(0x712F,175);
bpoke(0x7134,252);bpoke(0x7135,63);bpoke(0x7138,63);bpoke(0x7139,63);
bpoke(0x7141,250);bpoke(0x7142,170);bpoke(0x7143,171);bpoke(0x7144,170);bpoke(0x7145,174);bpoke(0x7146,170);
bpoke(0x7147,170);bpoke(0x7148,186);bpoke(0x7149,170);bpoke(0x714A,170);bpoke(0x714B,170);bpoke(0x714C,175);
bpoke(0x714D,234);bpoke(0x714E,170);bpoke(0x714F,175);
bpoke(0x7154,240);bpoke(0x7155,252);bpoke(0x7156,3);bpoke(0x7157,240);bpoke(0x7158,60);
bpoke(0x715A,15);bpoke(0x7161,254);bpoke(0x7162,170);bpoke(0x7163,171);bpoke(0x7164,170);bpoke(0x7165,190);
bpoke(0x7166,170);bpoke(0x7167,170);bpoke(0x7168,250);bpoke(0x7169,170);bpoke(0x716A,170);bpoke(0x716B,170);
bpoke(0x716C,191);bpoke(0x716D,170);bpoke(0x716E,170);bpoke(0x716F,175);
bpoke(0x7174,192);bpoke(0x7175,252);bpoke(0x7176,15);bpoke(0x7177,240);
bpoke(0x7178,63);bpoke(0x7179,192);bpoke(0x717A,3);bpoke(0x717B,3);
bpoke(0x7182,170);bpoke(0x7183,171);
bpoke(0x7184,234);bpoke(0x7185,190);bpoke(0x7186,170);bpoke(0x7187,191);bpoke(0x7188,254);bpoke(0x7189,170);
bpoke(0x718A,170);bpoke(0x718B,170);bpoke(0x718C,254);bpoke(0x718D,170);bpoke(0x718E,170);bpoke(0x718F,175);
bpoke(0x7194,3);bpoke(0x7195,252);
bpoke(0x7196,15);bpoke(0x7197,192);bpoke(0x7198,63);bpoke(0x719A,3);bpoke(0x719B,192);
bpoke(0x719C,240);bpoke(0x719D,63);
bpoke(0x71A2,170);bpoke(0x71A3,171);bpoke(0x71A4,234);bpoke(0x71A5,190);bpoke(0x71A6,170);
bpoke(0x71A8,254);bpoke(0x71A9,170);bpoke(0x71AA,170);bpoke(0x71AB,171);bpoke(0x71AC,234);bpoke(0x71AD,170);
bpoke(0x71AE,170);bpoke(0x71AF,175);bpoke(0x71B3,252);
bpoke(0x71B4,15);bpoke(0x71B5,252);bpoke(0x71B6,15);bpoke(0x71B7,192);bpoke(0x71B8,60);bpoke(0x71BA,3);
bpoke(0x71BB,192);bpoke(0x71BC,240);bpoke(0x71BD,48);
bpoke(0x71C2,234);bpoke(0x71C3,171);bpoke(0x71C4,234);bpoke(0x71C5,186);bpoke(0x71C6,170);
bpoke(0x71C9,170);bpoke(0x71CA,170);bpoke(0x71CB,175);bpoke(0x71CC,170);bpoke(0x71CD,170);
bpoke(0x71CE,170);bpoke(0x71D3,252);bpoke(0x71D4,63);bpoke(0x71D8,240);bpoke(0x71DA,3);bpoke(0x71DB,192);bpoke(0x71DC,192);
bpoke(0x71DD,192);bpoke(0x71E2,250);bpoke(0x71E3,235);
bpoke(0x71E4,250);bpoke(0x71E5,186);bpoke(0x71E6,170);bpoke(0x71E9,250);
bpoke(0x71EA,170);bpoke(0x71EB,190);bpoke(0x71EC,170);bpoke(0x71ED,170);bpoke(0x71EE,175);
bpoke(0x71F3,240);bpoke(0x71F6,192);bpoke(0x71F7,192);bpoke(0x71F8,192);bpoke(0x71F9,60);bpoke(0x71FA,3);bpoke(0x71FB,192);
bpoke(0x71FC,192);bpoke(0x71FD,192);bpoke(0x71FE,240);bpoke(0x71FF,63);
bpoke(0x7203,234);bpoke(0x7204,250);bpoke(0x7205,250);bpoke(0x7206,170);
bpoke(0x720A,234);bpoke(0x720B,254);bpoke(0x720C,170);bpoke(0x720D,170);
bpoke(0x720E,191);bpoke(0x7213,192);
bpoke(0x7217,252);bpoke(0x7218,240);bpoke(0x721A,15);
bpoke(0x721B,192);bpoke(0x721C,3);bpoke(0x721D,192);bpoke(0x721E,240);bpoke(0x721F,63);
bpoke(0x7223,234);bpoke(0x7224,250);bpoke(0x7225,250);bpoke(0x7226,170);
bpoke(0x722A,171);bpoke(0x722B,250);bpoke(0x722C,170);bpoke(0x722D,170);
bpoke(0x7233,3);bpoke(0x7239,12);bpoke(0x723A,15);bpoke(0x723B,192);bpoke(0x723C,15);bpoke(0x723D,192);bpoke(0x723F,63);
bpoke(0x7243,234);bpoke(0x7244,250);bpoke(0x7245,250);
bpoke(0x7246,170);bpoke(0x7249,254);bpoke(0x724A,175);bpoke(0x724B,234);
bpoke(0x724C,170);bpoke(0x724D,175);
bpoke(0x7252,87);bpoke(0x725B,240);bpoke(0x725C,15);bpoke(0x725D,192);
bpoke(0x7263,250);bpoke(0x7264,250);bpoke(0x7265,250);bpoke(0x7266,171);bpoke(0x7269,254);
bpoke(0x726A,175);bpoke(0x726B,170);bpoke(0x726C,170);bpoke(0x726D,171);
bpoke(0x7271,253);bpoke(0x7272,85);bpoke(0x7273,127);
bpoke(0x727B,240);bpoke(0x727C,63);bpoke(0x727D,192);bpoke(0x727E,3);
bpoke(0x7283,250);bpoke(0x7285,250);bpoke(0x7286,171);
bpoke(0x7289,250);bpoke(0x728A,190);bpoke(0x728B,170);bpoke(0x728C,175);bpoke(0x728D,170);
bpoke(0x7291,253);bpoke(0x7292,85);bpoke(0x7293,95);
bpoke(0x729D,252);bpoke(0x729E,3);
bpoke(0x72A3,250);bpoke(0x72A4,191);bpoke(0x72A5,234);
bpoke(0x72A6,171);bpoke(0x72A9,234);bpoke(0x72AA,250);bpoke(0x72AB,170);
bpoke(0x72AC,175);bpoke(0x72AD,170);bpoke(0x72AF,213);bpoke(0x72B0,85);bpoke(0x72B1,245);
bpoke(0x72B2,125);bpoke(0x72B3,95);bpoke(0x72C3,250);
bpoke(0x72C4,191);bpoke(0x72C5,234);bpoke(0x72C6,171);bpoke(0x72C9,171);
bpoke(0x72CA,234);bpoke(0x72CB,170);bpoke(0x72CC,191);bpoke(0x72CD,170);bpoke(0x72CE,189);bpoke(0x72CF,85);
bpoke(0x72D0,85);bpoke(0x72D1,117);bpoke(0x72D2,125);bpoke(0x72D3,87);bpoke(0x72D5,85);bpoke(0x72D6,95);
bpoke(0x72E2,253);bpoke(0x72E3,90);bpoke(0x72E4,159);bpoke(0x72E5,234);bpoke(0x72E6,171);
bpoke(0x72E9,171);bpoke(0x72EA,170);bpoke(0x72EB,170);bpoke(0x72EC,191);bpoke(0x72ED,170);
bpoke(0x72EE,165);bpoke(0x72EF,95);bpoke(0x72F0,245);bpoke(0x72F1,85);bpoke(0x72F2,245);bpoke(0x72F3,87);
bpoke(0x72F4,245);bpoke(0x72F5,85);bpoke(0x72F6,85);
bpoke(0x72FA,253);bpoke(0x72FB,127);bpoke(0x72FC,85);bpoke(0x72FD,87);
bpoke(0x7302,245);bpoke(0x7303,90);bpoke(0x7304,149);bpoke(0x7305,234);
bpoke(0x7306,171);bpoke(0x7308,86);bpoke(0x7309,175);
bpoke(0x730D,170);bpoke(0x730E,165);bpoke(0x730F,127);bpoke(0x7311,85);
bpoke(0x7312,245);bpoke(0x7313,85);bpoke(0x7314,213);bpoke(0x7315,127);bpoke(0x7316,85);
bpoke(0x731A,245);bpoke(0x731B,85);bpoke(0x731C,85);bpoke(0x731D,85);
bpoke(0x7322,85);bpoke(0x7323,126);
bpoke(0x7324,149);bpoke(0x7325,106);bpoke(0x7326,165);bpoke(0x7327,85);bpoke(0x7328,90);bpoke(0x7329,149);
bpoke(0x732A,87);bpoke(0x732C,254);bpoke(0x732D,170);bpoke(0x732E,151);
bpoke(0x7331,87);bpoke(0x7332,213);bpoke(0x7333,85);bpoke(0x7334,87);
bpoke(0x7336,245);bpoke(0x7337,127);bpoke(0x733A,85);bpoke(0x733B,85);
bpoke(0x733C,95);bpoke(0x733D,245);bpoke(0x733E,127);bpoke(0x7341,253);
bpoke(0x7342,87);bpoke(0x7343,254);bpoke(0x7344,189);bpoke(0x7345,106);bpoke(0x7346,165);bpoke(0x7347,127);
bpoke(0x7348,250);bpoke(0x7349,149);bpoke(0x734A,85);bpoke(0x734C,254);bpoke(0x734D,170);
bpoke(0x734E,159);bpoke(0x7351,95);bpoke(0x7352,85);bpoke(0x7353,85);
bpoke(0x7354,95);bpoke(0x7356,253);bpoke(0x7357,95);bpoke(0x7359,245);
bpoke(0x735A,85);bpoke(0x735B,85);bpoke(0x735D,253);bpoke(0x735E,95);
bpoke(0x7361,253);bpoke(0x7362,95);bpoke(0x7363,214);bpoke(0x7364,170);bpoke(0x7365,170);
bpoke(0x7366,165);bpoke(0x7367,127);bpoke(0x7368,234);bpoke(0x7369,170);bpoke(0x736A,170);bpoke(0x736B,175);
bpoke(0x736C,254);bpoke(0x736D,170);bpoke(0x736E,191);
bpoke(0x7372,85);bpoke(0x7373,85);bpoke(0x7374,95);bpoke(0x7375,213);bpoke(0x7376,125);bpoke(0x7377,95);
bpoke(0x7379,213);bpoke(0x737A,127);bpoke(0x737B,87);
bpoke(0x737E,87);bpoke(0x7381,245);bpoke(0x7382,125);bpoke(0x7383,86);
bpoke(0x7384,170);bpoke(0x7385,170);bpoke(0x7386,165);bpoke(0x7387,127);bpoke(0x7388,234);bpoke(0x7389,170);
bpoke(0x738A,170);bpoke(0x738B,170);bpoke(0x738C,170);bpoke(0x738D,170);bpoke(0x738E,191);bpoke(0x738F,85);
bpoke(0x7390,87);bpoke(0x7391,253);bpoke(0x7392,85);bpoke(0x7393,85);bpoke(0x7394,127);bpoke(0x7395,85);
bpoke(0x7396,95);bpoke(0x7397,87);bpoke(0x7398,253);bpoke(0x7399,85);bpoke(0x739B,95);
bpoke(0x739E,87);bpoke(0x73A1,213);
bpoke(0x73A2,117);bpoke(0x73A3,85);bpoke(0x73A4,170);bpoke(0x73A5,170);bpoke(0x73A6,165);bpoke(0x73A7,127);
bpoke(0x73A8,234);bpoke(0x73A9,170);bpoke(0x73AA,170);bpoke(0x73AB,170);bpoke(0x73AC,170);bpoke(0x73AD,170);
bpoke(0x73AE,245);bpoke(0x73AF,85);bpoke(0x73B0,85);bpoke(0x73B1,253);bpoke(0x73B2,85);bpoke(0x73B3,85);
bpoke(0x73B4,127);bpoke(0x73B5,85);bpoke(0x73B6,87);bpoke(0x73B7,87);bpoke(0x73B8,253);bpoke(0x73B9,95);
bpoke(0x73BB,95);bpoke(0x73BC,85);bpoke(0x73BD,95);bpoke(0x73BE,85);
bpoke(0x73C1,213);bpoke(0x73C2,213);bpoke(0x73C3,85);bpoke(0x73C4,170);bpoke(0x73C5,170);
bpoke(0x73C6,165);bpoke(0x73C7,117);bpoke(0x73C8,218);bpoke(0x73C9,170);bpoke(0x73CA,170);bpoke(0x73CB,170);
bpoke(0x73CC,170);bpoke(0x73CD,170);bpoke(0x73CE,213);bpoke(0x73CF,85);bpoke(0x73D0,85);bpoke(0x73D1,245);
bpoke(0x73D2,85);bpoke(0x73D3,85);bpoke(0x73D4,127);bpoke(0x73D5,85);bpoke(0x73D6,87);bpoke(0x73D7,85);
bpoke(0x73D9,95);bpoke(0x73DA,95);bpoke(0x73DB,253);bpoke(0x73DC,85);bpoke(0x73DD,95);
bpoke(0x73DE,85);bpoke(0x73E1,213);bpoke(0x73E2,213);bpoke(0x73E3,85);
bpoke(0x73E4,106);bpoke(0x73E5,170);bpoke(0x73E6,173);bpoke(0x73E7,85);bpoke(0x73E8,94);bpoke(0x73E9,170);
bpoke(0x73EA,170);bpoke(0x73EB,170);bpoke(0x73EC,170);bpoke(0x73ED,170);bpoke(0x73EE,213);bpoke(0x73EF,85);
bpoke(0x73F0,85);bpoke(0x73F1,117);bpoke(0x73F2,85);bpoke(0x73F3,117);bpoke(0x73F4,127);bpoke(0x73F5,85);
bpoke(0x73F6,87);bpoke(0x73F7,85);bpoke(0x73F9,85);bpoke(0x73FA,87);bpoke(0x73FB,245);
bpoke(0x73FC,85);bpoke(0x73FD,87);bpoke(0x73FE,85);bpoke(0x73FF,127);bpoke(0x7401,87);
bpoke(0x7402,85);bpoke(0x7403,85);bpoke(0x7404,90);bpoke(0x7405,170);bpoke(0x7406,189);bpoke(0x7407,85);
bpoke(0x7408,254);bpoke(0x7409,170);bpoke(0x740A,170);bpoke(0x740B,170);bpoke(0x740C,170);bpoke(0x740D,171);
bpoke(0x740E,85);bpoke(0x740F,85);bpoke(0x7410,85);bpoke(0x7411,85);bpoke(0x7412,85);bpoke(0x7413,253);
bpoke(0x7414,85);bpoke(0x7415,85);bpoke(0x7416,85);bpoke(0x7417,85);bpoke(0x7418,127);bpoke(0x7419,85);
bpoke(0x741A,87);bpoke(0x741B,245);bpoke(0x741C,85);bpoke(0x741D,87);bpoke(0x741E,85);bpoke(0x741F,127);
bpoke(0x7421,87);bpoke(0x7422,85);bpoke(0x7423,85);bpoke(0x7424,215);bpoke(0x7425,213);
bpoke(0x7426,127);bpoke(0x7427,85);bpoke(0x7428,245);bpoke(0x7429,85);bpoke(0x742B,85);
bpoke(0x742C,170);bpoke(0x742D,169);bpoke(0x742E,85);bpoke(0x742F,85);bpoke(0x7430,93);bpoke(0x7431,85);
bpoke(0x7432,85);bpoke(0x7433,253);bpoke(0x7434,85);bpoke(0x7435,87);bpoke(0x7436,85);bpoke(0x7437,85);
bpoke(0x7438,127);bpoke(0x7439,213);bpoke(0x743A,87);bpoke(0x743B,245);bpoke(0x743C,85);bpoke(0x743D,95);
bpoke(0x743E,85);bpoke(0x743F,127);bpoke(0x7441,85);bpoke(0x7442,85);bpoke(0x7443,95);
bpoke(0x7444,215);bpoke(0x7445,213);bpoke(0x7446,95);bpoke(0x7447,85);bpoke(0x7448,245);bpoke(0x7449,85);
bpoke(0x744B,85);bpoke(0x744C,125);bpoke(0x744D,93);bpoke(0x744E,85);bpoke(0x744F,85);
bpoke(0x7450,85);bpoke(0x7451,85);bpoke(0x7452,87);bpoke(0x7454,85);bpoke(0x7455,85);
bpoke(0x7456,87);bpoke(0x7457,85);bpoke(0x7458,127);bpoke(0x7459,245);bpoke(0x745A,87);bpoke(0x745B,245);
bpoke(0x745C,85);bpoke(0x745D,95);bpoke(0x745E,85);bpoke(0x745F,127);bpoke(0x7460,253);bpoke(0x7461,93);
bpoke(0x7462,85);bpoke(0x7463,95);bpoke(0x7464,215);bpoke(0x7465,213);bpoke(0x7466,95);bpoke(0x7467,213);
bpoke(0x7468,213);bpoke(0x7469,85);bpoke(0x746A,125);bpoke(0x746B,85);bpoke(0x746C,117);bpoke(0x746D,125);
bpoke(0x746E,85);bpoke(0x746F,87);bpoke(0x7470,213);bpoke(0x7471,85);bpoke(0x7472,87);
bpoke(0x7474,213);bpoke(0x7475,85);bpoke(0x7476,87);bpoke(0x7477,85);bpoke(0x7478,127);bpoke(0x7479,245);
bpoke(0x747A,85);bpoke(0x747B,245);bpoke(0x747C,85);bpoke(0x747D,95);bpoke(0x747E,85);bpoke(0x747F,127);
bpoke(0x7480,253);bpoke(0x7481,93);bpoke(0x7482,85);bpoke(0x7483,127);bpoke(0x7484,87);bpoke(0x7485,213);
bpoke(0x7486,95);bpoke(0x7487,215);bpoke(0x7488,213);bpoke(0x7489,85);bpoke(0x748A,85);bpoke(0x748B,85);
bpoke(0x748C,117);bpoke(0x748D,117);bpoke(0x748E,85);bpoke(0x748F,87);bpoke(0x7490,253);bpoke(0x7491,85);
bpoke(0x7492,87);bpoke(0x7493,253);bpoke(0x7494,87);bpoke(0x7496,215);bpoke(0x7497,85);
bpoke(0x7498,127);bpoke(0x7499,253);bpoke(0x749A,85);bpoke(0x749B,245);bpoke(0x749C,85);bpoke(0x749D,93);
bpoke(0x749E,85);bpoke(0x749F,127);bpoke(0x74A0,253);bpoke(0x74A1,93);bpoke(0x74A2,85);bpoke(0x74A3,127);
bpoke(0x74A4,87);bpoke(0x74A5,213);bpoke(0x74A6,95);bpoke(0x74A7,215);bpoke(0x74A8,213);bpoke(0x74A9,85);
bpoke(0x74AA,85);bpoke(0x74AB,85);bpoke(0x74AC,117);bpoke(0x74AD,117);bpoke(0x74AE,85);bpoke(0x74AF,85);
bpoke(0x74B0,127);bpoke(0x74B1,213);bpoke(0x74B2,87);bpoke(0x74B3,245);bpoke(0x74B4,95);
bpoke(0x74B7,85);bpoke(0x74B8,127);bpoke(0x74B9,253);bpoke(0x74BA,85);bpoke(0x74BB,245);
bpoke(0x74BC,93);bpoke(0x74BD,125);bpoke(0x74BE,85);bpoke(0x74BF,127);bpoke(0x74C0,253);bpoke(0x74C1,93);
bpoke(0x74C2,85);bpoke(0x74C3,253);bpoke(0x74C4,95);bpoke(0x74C5,213);bpoke(0x74C6,95);bpoke(0x74C7,215);
bpoke(0x74C8,213);bpoke(0x74C9,85);bpoke(0x74CA,85);bpoke(0x74CB,85);bpoke(0x74CC,117);bpoke(0x74CD,117);
bpoke(0x74CE,85);bpoke(0x74CF,85);bpoke(0x74D0,95);bpoke(0x74D1,245);bpoke(0x74D2,87);bpoke(0x74D3,213);
bpoke(0x74D4,127);bpoke(0x74D7,85);bpoke(0x74D8,127);
bpoke(0x74DA,213);bpoke(0x74DB,245);bpoke(0x74DC,85);bpoke(0x74DD,125);bpoke(0x74DE,85);bpoke(0x74DF,127);
bpoke(0x74E0,253);bpoke(0x74E1,93);bpoke(0x74E2,85);bpoke(0x74E3,253);bpoke(0x74E4,95);bpoke(0x74E5,85);
bpoke(0x74E6,95);bpoke(0x74E7,215);bpoke(0x74E8,213);bpoke(0x74E9,93);bpoke(0x74EA,85);bpoke(0x74EB,85);
bpoke(0x74EC,245);bpoke(0x74ED,117);bpoke(0x74EE,87);bpoke(0x74EF,85);bpoke(0x74F0,95);bpoke(0x74F1,245);
bpoke(0x74F2,87);bpoke(0x74F3,213);bpoke(0x74F4,245);bpoke(0x74F5,87);bpoke(0x74F7,85);
bpoke(0x74F8,127);bpoke(0x74FA,213);bpoke(0x74FB,245);bpoke(0x74FC,85);bpoke(0x74FD,117);
bpoke(0x74FE,85);bpoke(0x74FF,127);bpoke(0x7500,253);bpoke(0x7501,93);bpoke(0x7502,85);bpoke(0x7503,245);
bpoke(0x7504,127);bpoke(0x7505,85);bpoke(0x7506,95);bpoke(0x7507,87);bpoke(0x7508,85);bpoke(0x7509,95);
bpoke(0x750A,85);bpoke(0x750B,85);bpoke(0x750C,245);bpoke(0x750D,117);bpoke(0x750E,87);bpoke(0x750F,213);
bpoke(0x7510,95);bpoke(0x7511,245);bpoke(0x7512,87);bpoke(0x7513,87);bpoke(0x7514,213);bpoke(0x7515,87);
bpoke(0x7517,85);bpoke(0x7518,127);bpoke(0x751A,245);bpoke(0x751B,245);
bpoke(0x751C,85);bpoke(0x751D,117);bpoke(0x751E,85);bpoke(0x7520,253);bpoke(0x7521,93);
bpoke(0x7522,85);bpoke(0x7523,213);bpoke(0x7524,127);bpoke(0x7525,85);bpoke(0x7526,95);bpoke(0x7527,87);
bpoke(0x7528,85);bpoke(0x7529,95);bpoke(0x752A,213);bpoke(0x752B,95);bpoke(0x752C,245);bpoke(0x752D,125);
bpoke(0x752E,87);bpoke(0x752F,213);bpoke(0x7530,87);bpoke(0x7531,245);bpoke(0x7532,87);bpoke(0x7533,87);
bpoke(0x7534,85);bpoke(0x7535,87);bpoke(0x7536,245);bpoke(0x7537,85);bpoke(0x7538,127);
bpoke(0x753A,245);bpoke(0x753B,245);bpoke(0x753C,85);bpoke(0x753D,245);bpoke(0x753E,85);
bpoke(0x7540,253);bpoke(0x7541,95);bpoke(0x7542,85);bpoke(0x7543,85);bpoke(0x7544,253);bpoke(0x7545,85);
bpoke(0x7546,95);bpoke(0x7547,87);bpoke(0x7548,85);bpoke(0x7549,127);
bpoke(0x754C,245);bpoke(0x754D,93);bpoke(0x754E,85);bpoke(0x754F,85);bpoke(0x7550,213);bpoke(0x7551,245);
bpoke(0x7552,87);bpoke(0x7553,87);bpoke(0x7554,85);bpoke(0x7555,95);bpoke(0x7556,245);bpoke(0x7557,85);
bpoke(0x7558,127);bpoke(0x755A,245);bpoke(0x755B,245);bpoke(0x755C,85);bpoke(0x755D,213);
bpoke(0x755E,85);bpoke(0x7561,87);bpoke(0x7562,213);bpoke(0x7563,95);
bpoke(0x7564,245);bpoke(0x7565,85);bpoke(0x7566,85);bpoke(0x7567,87);bpoke(0x7568,85);bpoke(0x7569,87);
bpoke(0x756C,253);bpoke(0x756D,95);bpoke(0x756E,85);bpoke(0x756F,87);
bpoke(0x7570,85);bpoke(0x7571,213);bpoke(0x7572,87);bpoke(0x7573,87);bpoke(0x7574,85);bpoke(0x7575,127);
bpoke(0x7576,213);bpoke(0x7577,85);bpoke(0x7578,87);bpoke(0x757A,85);bpoke(0x757B,245);
bpoke(0x757C,87);bpoke(0x757D,215);bpoke(0x757E,213);bpoke(0x7581,87);
bpoke(0x7584,245);bpoke(0x7585,85);bpoke(0x7586,85);bpoke(0x7587,87);
bpoke(0x7588,85);bpoke(0x7589,87);bpoke(0x758C,253);bpoke(0x758D,87);
bpoke(0x758F,253);bpoke(0x7590,85);bpoke(0x7591,213);bpoke(0x7592,87);bpoke(0x7593,87);
bpoke(0x7594,213);bpoke(0x7596,85);bpoke(0x7597,85);bpoke(0x7598,85);bpoke(0x7599,253);
bpoke(0x759A,87);bpoke(0x759B,253);bpoke(0x759C,87);bpoke(0x759E,213);
bpoke(0x75A1,87);bpoke(0x75A4,213);bpoke(0x75A5,85);
bpoke(0x75A6,87);bpoke(0x75A9,85);bpoke(0x75AD,85);bpoke(0x75AF,245);bpoke(0x75B0,85);bpoke(0x75B1,213);
bpoke(0x75B2,87);bpoke(0x75B3,87);bpoke(0x75B6,85);
bpoke(0x75B8,213);bpoke(0x75B9,125);bpoke(0x75BA,95);bpoke(0x75BB,253);bpoke(0x75BC,87);
bpoke(0x75BE,213);bpoke(0x75BF,127);bpoke(0x75C1,213);bpoke(0x75C3,253);
bpoke(0x75C4,85);bpoke(0x75C5,85);bpoke(0x75C6,87);bpoke(0x75C8,253);bpoke(0x75C9,85);
bpoke(0x75CD,85);bpoke(0x75CE,127);bpoke(0x75CF,85);
bpoke(0x75D0,85);bpoke(0x75D1,213);bpoke(0x75D2,87);bpoke(0x75D3,213);bpoke(0x75D5,245);
bpoke(0x75D6,87);bpoke(0x75D8,213);bpoke(0x75D9,125);bpoke(0x75DA,95);bpoke(0x75DB,85);
bpoke(0x75DC,95);bpoke(0x75DE,213);bpoke(0x75DF,127);bpoke(0x75E1,213);
bpoke(0x75E2,127);bpoke(0x75E3,245);bpoke(0x75E4,85);bpoke(0x75E5,85);bpoke(0x75E6,85);bpoke(0x75E7,85);
bpoke(0x75E8,253);bpoke(0x75E9,85);bpoke(0x75EA,127);bpoke(0x75ED,213);
bpoke(0x75EE,85);bpoke(0x75EF,85);bpoke(0x75F0,85);bpoke(0x75F1,213);bpoke(0x75F2,87);bpoke(0x75F3,213);
bpoke(0x75F4,127);bpoke(0x75F5,213);bpoke(0x75F6,87);bpoke(0x75F8,213);bpoke(0x75F9,93);
bpoke(0x75FA,85);bpoke(0x75FB,85);bpoke(0x75FC,85);bpoke(0x75FD,85);bpoke(0x75FE,85);bpoke(0x75FF,95);
bpoke(0x7601,245);bpoke(0x7602,85);bpoke(0x7603,85);bpoke(0x7604,85);bpoke(0x7605,87);
bpoke(0x7606,85);bpoke(0x7607,85);bpoke(0x7608,85);bpoke(0x7609,85);bpoke(0x760A,127);
bpoke(0x760D,213);bpoke(0x760E,85);bpoke(0x760F,85);bpoke(0x7610,85);bpoke(0x7611,213);
bpoke(0x7612,95);bpoke(0x7613,245);bpoke(0x7614,85);bpoke(0x7615,85);bpoke(0x7616,85);
bpoke(0x7618,213);bpoke(0x7619,93);bpoke(0x761A,85);bpoke(0x761B,85);bpoke(0x761C,85);bpoke(0x761D,85);
bpoke(0x761E,85);bpoke(0x761F,95);bpoke(0x7621,245);bpoke(0x7622,85);bpoke(0x7623,85);
bpoke(0x7624,85);bpoke(0x7625,87);bpoke(0x7626,213);bpoke(0x7627,85);bpoke(0x7628,85);bpoke(0x7629,85);
bpoke(0x762C,213);bpoke(0x762D,85);bpoke(0x762E,85);bpoke(0x762F,85);
bpoke(0x7630,85);bpoke(0x7631,213);bpoke(0x7632,95);bpoke(0x7633,245);bpoke(0x7634,85);bpoke(0x7635,85);
bpoke(0x7636,85);bpoke(0x7637,85);bpoke(0x7638,85);bpoke(0x7639,85);bpoke(0x763A,85);bpoke(0x763B,85);
bpoke(0x763C,85);bpoke(0x763D,85);bpoke(0x763E,85);bpoke(0x763F,95);bpoke(0x7641,253);
bpoke(0x7642,85);bpoke(0x7643,85);bpoke(0x7644,85);bpoke(0x7645,95);bpoke(0x7646,213);bpoke(0x7647,85);
bpoke(0x7648,85);bpoke(0x7649,85);bpoke(0x764C,85);bpoke(0x764D,85);
bpoke(0x764E,85);bpoke(0x764F,85);bpoke(0x7650,85);bpoke(0x7651,213);bpoke(0x7652,95);bpoke(0x7653,253);
bpoke(0x7654,85);bpoke(0x7655,85);bpoke(0x7656,85);bpoke(0x7657,85);bpoke(0x7658,85);bpoke(0x7659,85);
bpoke(0x765A,85);bpoke(0x765B,85);bpoke(0x765C,85);bpoke(0x765D,85);bpoke(0x765E,85);bpoke(0x765F,95);
bpoke(0x7662,85);bpoke(0x7663,85);bpoke(0x7664,85);bpoke(0x7665,127);
bpoke(0x7666,245);bpoke(0x7667,85);bpoke(0x7668,85);bpoke(0x7669,85);
bpoke(0x766C,87);bpoke(0x7671,213);
bpoke(0x7672,95);bpoke(0x7674,85);bpoke(0x7675,85);bpoke(0x7676,85);bpoke(0x7677,85);
bpoke(0x7678,85);bpoke(0x7679,85);bpoke(0x767A,85);bpoke(0x767B,85);bpoke(0x767C,85);bpoke(0x767D,85);
bpoke(0x767E,85);bpoke(0x767F,95);bpoke(0x7682,213);bpoke(0x7683,85);
bpoke(0x7684,87);bpoke(0x7686,245);bpoke(0x7687,85);bpoke(0x7688,85);bpoke(0x7689,85);
bpoke(0x768C,87);bpoke(0x7691,213);bpoke(0x7692,95);bpoke(0x7694,85);bpoke(0x7695,85);
bpoke(0x7696,93);bpoke(0x7697,85);bpoke(0x7698,85);bpoke(0x7699,95);bpoke(0x769A,85);bpoke(0x769B,85);
bpoke(0x769D,85);bpoke(0x769E,85);bpoke(0x769F,95);
bpoke(0x76A2,245);bpoke(0x76A3,85);bpoke(0x76A4,127);
bpoke(0x76A8,245);bpoke(0x76A9,87);bpoke(0x76AC,87);
bpoke(0x76B1,213);bpoke(0x76B2,95);
bpoke(0x76B4,245);bpoke(0x76B5,85);bpoke(0x76B7,85);bpoke(0x76B8,85);bpoke(0x76B9,95);
bpoke(0x76BA,213);bpoke(0x76BB,95);bpoke(0x76CC,87);bpoke(0x76D1,213);
bpoke(0x76D2,95);bpoke(0x76D7,245);bpoke(0x76D8,85);bpoke(0x76D9,95);bpoke(0x76DA,215);
bpoke(0x76EC,85);bpoke(0x76ED,85);bpoke(0x76EE,87);
bpoke(0x76F1,213);bpoke(0x76F2,95);bpoke(0x770C,213);bpoke(0x770D,85);
bpoke(0x770E,85);bpoke(0x770F,85);bpoke(0x7710,95);bpoke(0x7711,213);bpoke(0x7712,95);
bpoke(0x772C,213);bpoke(0x772D,85);bpoke(0x772E,85);bpoke(0x772F,85);bpoke(0x7730,85);bpoke(0x7731,85);
bpoke(0x7732,95);bpoke(0x774C,245);bpoke(0x774D,85);bpoke(0x774E,85);bpoke(0x774F,85);bpoke(0x7750,85);
bpoke(0x7751,85);bpoke(0x7752,95);bpoke(0x776C,245);bpoke(0x776D,85);bpoke(0x776E,85);bpoke(0x776F,85);
bpoke(0x7770,85);bpoke(0x7771,85);bpoke(0x7772,95);bpoke(0x778C,253);bpoke(0x778D,85);bpoke(0x778E,85);
bpoke(0x778F,85);bpoke(0x7790,85);bpoke(0x7791,85);bpoke(0x7792,95);
bpoke(0x77AF,213);bpoke(0x77B0,85);bpoke(0x77B1,85);bpoke(0x77B2,95);bpoke(0x77D1,85);bpoke(0x77D2,95);



bit_fx2(7);
bit_fx3(0);
bit_fx3(1);
bit_fx3(2);
bit_fx3(3);
bit_fx3(4);
bit_fx3(5);
bit_fx3(6);


}



update(){
	int	j;
	vz_clrscr();

        printf(" +++++ V Z  -  O R G A N +++++\n\n");
	printf(" duration      sound\n");
	printf("1 = shorter   5 = normal\n");
	printf("2 = longer    6 = distortion\n");
	printf("              7 = fully sik\n");
	printf("3 = FX\n");
	printf("4 = organ   keyboard %d :", keyboard);


	printf("\n-----------------------------\n");

        if (keyboard == 3) 
        {
 	   printf("sound fx: \n\n");
	   printf("Q W E R T Y U I O P [ \n");
	   printf(" A S D F G H J K L ; \n");
	   printf("  Z X C V B N M , . / \n");              
        }
        if (keyboard > 3)
        {
 	   printf("Keyboard: ");
	   if (keyboard == 5) {printf("normal\n");}
	   if (keyboard == 6) {printf("distortion\n");}
	   if (keyboard == 7) {printf("fully sik\n");}
           printf("duration: %d", duration);
        }
}



int keys()
{

     


           if (keyboard==5){
              switch( vz_inch() ) {
	         case 'Q' :      bit_synth (duration,200,200,60,60); break;
	         case 'W' :      bit_synth (duration,200,200,53,53); break;
	         case 'E' :      bit_synth (duration,200,200,50,50); break;
	         case 'R' :      bit_synth (duration,200,200,44,44); break;
	         case 'T' :      bit_synth (duration,200,200,40,40); break;
	         case 'Y' :      bit_synth (duration,200,200,33,33); break;
	         case 'U' :      bit_synth (duration,177,177,60,60); break;
	         case 'I' :      bit_synth (duration,177,177,50,50); break;
	         case 'O' :      bit_synth (duration,177,177,44,44); break;
	         case 'P' :      bit_synth (duration,177,177,40,40); break;
	         case 'A' :      bit_synth (duration,177,177,37,37); break;
	         case 'S' :      bit_synth (duration,160,160,60,60); break;
	         case 'D' :      bit_synth (duration,160,160,53,53); break;
	         case 'F' :      bit_synth (duration,160,160,50,50); break;
	         case 'G' :      bit_synth (duration,160,160,44,44); break;
	         case 'H' :      bit_synth (duration,160,160,40,40); break;
	         case 'J' :      bit_synth (duration,150,150,60,60); break;
	         case 'K' :      bit_synth (duration,150,150,53,53); break;
	         case 'L' :      bit_synth (duration,150,150,50,50); break;
	         case 'Z' :      bit_synth (duration,150,150,44,44); break;
	         case 'X' :      bit_synth (duration,150,150,40,40); break;
	         case 'C' :      bit_synth (duration,133,133,60,60); break;
	         case 'V' :      bit_synth (duration,133,133,53,53); break;
	         case 'B' :      bit_synth (duration,133,133,50,50); break;
	         case 'N' :      bit_synth (duration,133,133,44,44); break;
	         case 'M' :      bit_synth (duration,133,133,40,40); break;
	         case '1' :	 duration -= 10;
				 if (duration < 10) {duration = 10;}
				 update();
				 break;
	         case '2' :	 duration += 10;
				 if (duration > 250) {duration = 250;}
				 update();
				 break;
		 case '3' :      
				 keyboard = 3;
				 update();
				 break;
		 case '4' :      
				 keyboard = 5;
				 update();
				 break;
		 case '5' :      keyboard = 5;
				 update();
				 break;
		 case '6' :      keyboard = 6;
				 update();
				 break;
		 case '7' :      keyboard = 7;
				 update();
				 break;

              }
              }



           if (keyboard==6){
              switch( vz_inch() ) {
	         case 'Q' :      bit_synth (duration,200,201,60,61); break;
	         case 'W' :      bit_synth (duration,200,201,53,54); break;
	         case 'E' :      bit_synth (duration,200,201,50,51); break;
	         case 'R' :      bit_synth (duration,200,201,44,45); break;
	         case 'T' :      bit_synth (duration,200,201,40,41); break;
	         case 'Y' :      bit_synth (duration,200,201,33,34); break;
	         case 'U' :      bit_synth (duration,177,178,60,61); break;
	         case 'I' :      bit_synth (duration,177,178,50,51); break;
	         case 'O' :      bit_synth (duration,177,178,44,45); break;
	         case 'P' :      bit_synth (duration,177,178,40,41); break;
	         case 'A' :      bit_synth (duration,177,178,37,38); break;
	         case 'S' :      bit_synth (duration,160,161,60,61); break;
	         case 'D' :      bit_synth (duration,160,161,53,54); break;
	         case 'F' :      bit_synth (duration,160,161,50,51); break;
	         case 'G' :      bit_synth (duration,160,161,44,45); break;
	         case 'H' :      bit_synth (duration,160,161,40,41); break;
	         case 'J' :      bit_synth (duration,150,151,60,61); break;
	         case 'K' :      bit_synth (duration,150,151,53,54); break;
	         case 'L' :      bit_synth (duration,150,151,50,51); break;
	         case 'Z' :      bit_synth (duration,150,151,44,45); break;
	         case 'X' :      bit_synth (duration,150,151,40,41); break;
	         case 'C' :      bit_synth (duration,133,134,60,61); break;
	         case 'V' :      bit_synth (duration,133,134,53,54); break;
	         case 'B' :      bit_synth (duration,133,134,50,51); break;
	         case 'N' :      bit_synth (duration,133,134,44,45); break;
	         case 'M' :      bit_synth (duration,133,134,40,41); break;
	         case '1' :	 duration -= 10;
				 if (duration < 10) {duration = 10;}
				 update();
				 break;
	         case '2' :	 duration += 10;
				 if (duration > 250) {duration = 250;}
				 update();
				 break;
		 case '3' :      
				 keyboard = 3;
				 update();
				 break;
		 case '4' :      
				 keyboard = 6;
				 update();
				 break;
		 case '5' :      keyboard = 5;
				 update();
				 break;
		 case '6' :      keyboard = 6;
				 update();
				 break;
		 case '7' :      keyboard = 7;
				 update();
				 break;
		}
		}


           if (keyboard==7){
              switch( vz_inch() ) {
	         case 'Q' :      bit_synth (duration,200,202,60,62); break;
	         case 'W' :      bit_synth (duration,200,202,53,55); break;
	         case 'E' :      bit_synth (duration,200,202,50,52); break;
	         case 'R' :      bit_synth (duration,200,202,44,46); break;
	         case 'T' :      bit_synth (duration,200,202,40,42); break;
	         case 'Y' :      bit_synth (duration,200,202,33,35); break;
	         case 'U' :      bit_synth (duration,177,179,60,62); break;
	         case 'I' :      bit_synth (duration,177,179,50,52); break;
	         case 'O' :      bit_synth (duration,177,179,44,46); break;
	         case 'P' :      bit_synth (duration,177,179,40,43); break;
	         case 'A' :      bit_synth (duration,177,179,37,39); break;
	         case 'S' :      bit_synth (duration,160,162,60,62); break;
	         case 'D' :      bit_synth (duration,160,162,53,56); break;
	         case 'F' :      bit_synth (duration,160,162,50,52); break;
	         case 'G' :      bit_synth (duration,160,162,44,47); break;
	         case 'H' :      bit_synth (duration,160,162,40,42); break;
	         case 'J' :      bit_synth (duration,150,152,60,62); break;
	         case 'K' :      bit_synth (duration,150,152,53,55); break;
	         case 'L' :      bit_synth (duration,150,152,50,53); break;
	         case 'Z' :      bit_synth (duration,150,152,44,46); break;
	         case 'X' :      bit_synth (duration,150,152,40,42); break;
	         case 'C' :      bit_synth (duration,133,135,60,62); break;
	         case 'V' :      bit_synth (duration,133,135,53,55); break;
	         case 'B' :      bit_synth (duration,133,135,50,52); break;
	         case 'N' :      bit_synth (duration,133,135,44,46); break;
	         case 'M' :      bit_synth (duration,133,135,40,42); break;
	         case '1' :	 duration -= 10;
				 if (duration < 10) {duration = 10;}
				 update();
				 break;
	         case '2' :	 duration += 10;
				 if (duration > 250) {duration = 250;}
				 update();
				 break;
		 case '3' :      
				 keyboard = 3;
				 update();
				 break;
		 case '4' :      
				 keyboard = 7;
				 update();
				 break;
		 case '5' :      keyboard = 5;
				 update();
				 break;
		 case '6' :      keyboard = 6;
				 update();
				 break;
		 case '7' :      keyboard = 7;
				 update();
				 break;

              }
          }

      if (keyboard==3){
              switch( vz_inch() ) {
                 case 'Q' : bit_fx(0);break;
                 case 'W' : bit_fx(1);break;
                 case 'E' : bit_fx(2);break;
                 case 'R' : bit_fx(3);break;
                 case 'T' : bit_fx(4);break;
                 case 'Y' : bit_fx(5);break;
                 case 'U' : bit_fx(6);break;
                 case 'I' : bit_fx(7);break;
                 case 'O' : bit_fx2(0);break;
                 case 'P' : bit_fx2(1);break;
                 case '[' : bit_fx2(2);break;
                 case ']' : bit_fx2(3);break;
                 case 'A' : bit_fx2(4);break;
                 case 'S' : bit_fx2(5);break;
                 case 'D' : bit_fx2(6);break;
                 case 'F' : bit_fx2(7);break;
                 case 'G' : bit_fx3(0);break;
                 case 'H' : bit_fx3(1);break;
                 case 'J' : bit_fx3(2);break;
                 case 'K' : bit_fx3(3);break;
                 case 'L' : bit_fx3(4);break;
                 case ';' : bit_fx3(5);break;
                 case 'Z' : bit_fx3(6);break;
                 case 'X' : bit_fx3(7);break;
                 case 'C' : bit_fx4(0);break;
                 case 'V' : bit_fx4(1);break;
                 case 'B' : bit_fx4(2);break;
                 case 'N' : bit_fx4(3);break;
                 case 'M' : bit_fx4(4);break;
                 case ',' : bit_fx4(5);break;
                 case '.' : bit_fx4(6);break;
                 case '/' : bit_fx4(7);break;

		 case '3' :     
				 keyboard = 3;
				 update();
				 break;
		 case '4' :      
				 keyboard = 5;
				 update();
				 break;
		 case '5' :      keyboard = 5;
				 update();
				 break;
		 case '6' :      keyboard = 6;
				 update();
				 break;
		 case '7' :      keyboard = 7;
				 update();
				 break;

	      }
	   }

}    


int main()
{

	int i;
	int j;
	int k;
	int l;
	int m;
	int	quit;


	quit = 0;
	duration = 50;
	keyboard = 5;

	intro();
	update();

	while (quit == 0) {
		keys();
	}	
}
